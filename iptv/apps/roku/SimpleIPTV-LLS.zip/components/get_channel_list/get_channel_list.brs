sub init()
	m.top.functionName = "getContent"
end sub

sub getContent()
	feedurl = m.global.feedurl
	if feedurl = invalid or feedurl = "" then feedurl = "https://lls-ws.github.io/iptv/LLS_TV.m3u"

	searchRequest = CreateObject("roUrlTransfer")
	searchRequest.setURL(feedurl)
	searchRequest.EnableEncodings(true)
	httpsReg = CreateObject("roRegex", "^https:", "")
	if httpsReg.isMatch(feedurl)
		searchRequest.SetCertificatesFile("common:/certs/ca-bundle.crt")
		searchRequest.AddHeader("X-Roku-Reserved-Dev-Id", "")
		searchRequest.InitClientCertificates()
	end if

	text = searchRequest.getToString()

	reHasGroups = CreateObject("roRegex", "group-title=" + chr(34) + "?([^" + chr(34) + "]*)" + chr(34) + "?", "")
	reTvgId = CreateObject("roRegex", "tvg-id=" + chr(34) + "?([^" + chr(34) + "]*)" + chr(34) + "?", "")
	hasGroups = reHasGroups.isMatch(text)

	reLineSplit = CreateObject("roRegex", "(?>\r\n|[\r\n])", "")
	reExtinf = CreateObject("roRegex", "(?i)^#EXTINF:\s*(\d+|-1|-0).*,\s*(.*)$", "")
	rePath = CreateObject("roRegex", "^([^#].*)$", "")

	inExtinf = false
	title = ""
	tvgId = ""
	con = CreateObject("roSGNode", "ContentNode")
	if not hasGroups
		group = con
	end if

	for each line in reLineSplit.Split(text)
		if inExtinf
			maPath = rePath.Match(line)
			if maPath.Count() = 2
				item = group.CreateChild("ContentNode")
				item.url = maPath[1].Trim()
				item.title = title.Trim()
				item.id = tvgId.Trim()
				inExtinf = false
			end if
		end if
		maExtinf = reExtinf.Match(line)
		if maExtinf.Count() = 3
			if hasGroups
				maGrp = reHasGroups.Match(line)
				groupName = "Geral"
				if maGrp.Count() >= 2 and maGrp[1] <> "" then groupName = maGrp[1]
				group = invalid
				for x = 0 to con.getChildCount() - 1
					node = con.getChild(x)
					if node.id = groupName
						group = node
						exit for
					end if
				end for
				if group = invalid
					group = con.CreateChild("ContentNode")
					group.contenttype = "SECTION"
					group.title = groupName
					group.id = groupName
				end if
			end if
			tvgId = ""
			maId = reTvgId.Match(line)
			if maId.Count() >= 2 then tvgId = maId[1]
			title = maExtinf[2]
			inExtinf = true
		end if
	end for

	m.top.content = con
end sub
