sub init()
	m.top.functionName = "fetchEpg"
end sub

function parseXmltvTime(ts as string) as integer
	if len(ts) < 14 then return 0
	dt = CreateObject("roDateTime")
	iso = left(ts, 4) + "-" + mid(ts, 5, 2) + "-" + mid(ts, 7, 2) + "T" + mid(ts, 9, 2) + ":" + mid(ts, 11, 2) + ":" + mid(ts, 13, 2) + "Z"
	dt.FromISO8601String(iso)
	secs = dt.AsSeconds()
	if len(ts) >= 20
		tzPart = mid(ts, 16, 5)
		sign = left(tzPart, 1)
		tzH = val(mid(tzPart, 2, 2))
		tzM = val(mid(tzPart, 4, 2))
		offset = (tzH * 3600) + (tzM * 60)
		if sign = "-" then secs = secs + offset
		if sign = "+" then secs = secs - offset
	end if
	return secs
end function

function formatLocalHHMM(secs as integer) as string
	dt = CreateObject("roDateTime")
	dt.FromSeconds(secs)
	dt.ToLocalTime()
	h = dt.GetHours().ToStr()
	m = dt.GetMinutes().ToStr()
	if len(h) = 1 then h = "0" + h
	if len(m) = 1 then m = "0" + m
	return h + ":" + m
end function

sub fetchEpg()
	req = CreateObject("roUrlTransfer")
	req.SetURL("https://lls-ws.github.io/iptv/guide.xml")
	req.EnableEncodings(true)
	req.SetCertificatesFile("common:/certs/ca-bundle.crt")
	req.InitClientCertificates()

	xmlStr = req.GetToString()
	if xmlStr = "" then return

	xml = CreateObject("roXMLElement")
	if not xml.Parse(xmlStr) then return

	nowDt = CreateObject("roDateTime")
	nowSec = nowDt.AsSeconds()

	epgMap = {}
	progs = xml.GetNamedElements("programme")
	for each p in progs
		ch = p@channel
		if ch <> invalid and ch <> ""
			startSec = parseXmltvTime(p@start)
			stopSec = parseXmltvTime(p@stop)
			if stopSec > nowSec
				if not epgMap.DoesExist(ch)
					epgMap[ch] = { nowTitle: "", nowTime: "", nowDesc: "", nextTitle: "", nextTime: "", nextDesc: "" }
				end if
				entry = epgMap[ch]
				titleNodes = p.GetNamedElements("title")
				pTitle = ""
				if titleNodes.Count() > 0 then pTitle = titleNodes[0].GetText()

				descNodes = p.GetNamedElements("desc")
				pDesc = ""
				if descNodes.Count() > 0 then pDesc = descNodes[0].GetText()

				hhmmStart = formatLocalHHMM(startSec)
				hhmmStop = formatLocalHHMM(stopSec)

				if startSec <= nowSec and stopSec > nowSec
					entry.nowTitle = pTitle
					entry.nowTime = hhmmStart + " - " + hhmmStop
					entry.nowDesc = pDesc
				else if startSec > nowSec and entry.nextTitle = ""
					entry.nextTitle = pTitle
					entry.nextTime = hhmmStart + " - " + hhmmStop
					entry.nextDesc = pDesc
				end if
			end if
		end if
	end for

	m.top.epgData = epgMap
end sub
