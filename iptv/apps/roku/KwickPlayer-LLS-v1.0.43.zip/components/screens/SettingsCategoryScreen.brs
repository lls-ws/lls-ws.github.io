' One category of Settings. The tile that opened this screen decides which
' rows get built; everything a row can then do — the dialogs, the PIN flow,
' the sync actions, Export Logs, the guide checker, the USB reader, sign
' out — lives in this file, moved here wholesale from the old single-screen
' Settings so that behaviour is unchanged row for row.
'
' Back or Left closes this screen and hands focus back to the grid.

sub init()
    m.theme = KwickTheme()
    m.branding = KwickBranding()
    m.top.findNode("bg").color = m.theme.background
    ' This screen is a scene-level overlay, so its own backdrop covers
    ' AppScene's grid wash. See AddPageGrid() in Theme.brs — the mesh
    ' goes in at child 1, just above the backdrop declared first in the
    ' XML above, and under everything this screen draws.
    AddPageGrid(m.top)

    m.header = m.top.findNode("header")
    m.header.font = UiBoldFont(46)
    m.header.color = m.theme.textPrimary

    m.subhead = m.top.findNode("subhead")
    ' No width, so this auto-sizes and cannot truncate. Longest is the
    ' Categories line at 75 chars = 1125px at 25 mono, ending at x 1317 —
    ' comfortably inside the title-safe right edge at 1726.
    m.subhead.font = UiFont(25)
    m.subhead.color = m.theme.textSecondary

    m.sectionTitle = m.top.findNode("sectionTitle")
    m.sectionTitle.font = UiBoldFont(26)
    m.sectionTitle.color = m.theme.accent

    m.note = m.top.findNode("note")
    ' 1400px at 24 mono is 97 characters a line, 194 over the two lines.
    ' The longest note in this file (the guide-order explanation) is 134,
    ' so it still fits in two lines after the switch.
    m.note.font = UiFont(24)
    m.note.color = m.theme.textSecondary
    m.note.width = 1400
    m.note.wrap = true
    m.note.maxLines = 2

    m.deviceKey = m.top.findNode("deviceKey")

    ' JB-4 — the accent block behind the open group. The XML says what the
    ' two nodes are; layoutLines() puts them where the rows ended up.
    m.wash = m.top.findNode("wash")
    ' 1A is 26/255, i.e. 10.2% — the 10% the owner approved on Windows, and
    ' the ceiling rather than a starting point: the Windows theme sweep
    ' found 14% drops one theme's header under the 3:1 floor. Mixed off the
    ' theme's own accent instead of written out, so a reskin carries it.
    m.wash.color = Left(m.theme.accent, 8) + "1A"
    m.rule = m.top.findNode("rule")
    m.rule.color = m.theme.accent

    m.list = m.top.findNode("list")
    m.list.observeField("itemSelected", "onSelected")
    m.list.observeField("itemFocused", "onItemFocused")

    m.rows = []
    m.top.observeField("focusedChild", "onFocusIn")
    m.reorder = invalid
    m.linkScreen = invalid
    m.usbBrowser = invalid
    m.usbTask = invalid
    m.usbPath = ""
    m.pinDialog = invalid
    m.syncTask = invalid
    m.syncPhase = ""
    m.exportState = ""
    m.syncMessage = ""
    ' Check for updates: what the row's value column says, and which row it
    ' is, so a late answer can put the cursor back where it was.
    m.updateState = ""
    m.updateTask = invalid
    m.updateIdx = 0
    m.deviceKeyReady = false
    m.deviceKeyShown = false
    m.deviceKeyTask = invalid
    m.resetState = ""
    m.resetTask = invalid
    ' Set up front rather than left invalid: the guide rows and the two
    ' pickers all read these back in their dialog handlers, and counting an
    ' unset member is a type mismatch rather than a zero.
    m.guideItemActions = []
    m.guideEditIdx = -1
    m.guideProviderId = ""
    m.guideCurrentUrl = ""
    m.guideRowIdx = 0
    m.pendingKind = ""
    m.retentionPick = ""
    m.retentionRowIdx = 0
    m.bgEffectRowIdx = 0
    m.controlsTimeoutRowIdx = 0
    ' The add-on's own page (AddOnDetailScreen) while it is open. Set up front
    ' like the rest of these, because onAddOnClosed reads it back.
    m.addOnScreen = invalid

    ' Refresh channel list / Refresh TV guide. Both rows carry their state in
    ' the value column for the whole visit, so a member who looked away still
    ' sees what happened. The channel row also refuses to start a second
    ' refresh while the first is still out; the guide row has nothing to
    ' refuse, because its request finishes the instant it is made.
    m.chanRefreshState = ""
    m.chanRefreshIdx = 0
    m.chanRefreshPending = 0
    m.chanRefreshTasks = {}
    m.chanRefreshOk = 0
    m.chanRefreshFail = 0
    m.chanRefreshLines = []
    ' Sources whose answer was refused by the shrink guard, each still
    ' holding the parse it was refused for, so "Use the new list" has
    ' something to apply without asking the provider a second time.
    m.chanRefuse = []
    m.guideRefreshState = ""
    m.guideRefreshIdx = 0

    ' The parent sets `category` straight after createChild, so whichever of
    ' the two arrives second is the one that builds the rows. Both orders
    ' are covered and neither builds twice.
    m.ready = true
    if m.top.category <> "" then refresh()
end sub

sub onCategoryChanged()
    if m.ready <> true then return
    if m.top.category = "" then return
    refresh()
end sub

sub onFocusIn()
    if m.top.hasFocus() and m.rows.count() > 0 then m.list.setFocus(true)
end sub

sub onItemFocused()
    if not m.sectionTitle.visible then return
    cur = m.list.itemFocused
    if cur < 0 or cur >= m.rows.count() then return
    m.sectionTitle.text = m.rows[cur].section
end sub

' ---- Building the rows ------------------------------------------------------
' Each row: { kind, [id], label, value, section }. Identical to the model the
' old single Settings list used, so every handler below reads exactly as it
' always did.

sub refresh()
    m.rows = []
    m.noteText = ""
    m.curSection = ""
    cat = m.top.category

    if cat = "sources"
        m.header.text = "Sources"
        m.subhead.text = "Where your channels and playlists come from"
        buildSourcesRows()
    else if cat = "playback"
        m.header.text = "Playback"
        ' Names the add-ons half too, for the same reason "Home & appearance"
        ' and "History & reset" name theirs: a member sent here looking for
        ' OpenSubtitles has to see the word on arrival. 80 characters at 25
        ' mono is 1200px from x 192, ending at 1392 — inside the title-safe
        ' right edge at 1726, and now the longest subhead in this file.
        m.subhead.text = "How a video starts, what it shows on screen, and your accounts on other services"
        buildPlaybackRows()
    else if cat = "home"
        ' The tile that opens this still says "Home screen"
        ' (SettingsScreen.brs owns it). The heading names both halves, the
        ' same way the Reset tile opens on "History & reset": the background
        ' effect is drawn on every screen in the app, not only this one, and
        ' a member sent here looking for it has to see the word on arrival.
        m.header.text = "Home & appearance"
        m.subhead.text = "How the app looks, the Media Bar at the top, and which rows appear underneath it"
        buildHomeRows()
    else if cat = "categories"
        m.header.text = "Categories"
        m.subhead.text = "Hide the categories you never watch, and put the rest in the order you like"
        buildCategoriesRows()
    else if cat = "parental"
        m.header.text = "Parental controls"
        m.subhead.text = "Lock categories behind a 4-digit PIN"
        buildParentalRows()
    else if cat = "sync"
        m.header.text = "KwickSync"
        m.subhead.text = "Keep your profiles, favorites and history the same on every device"
        buildSyncRows()
    else if cat = "reset"
        ' The tile that opens this still says "Reset" (SettingsScreen.brs
        ' owns it). The heading names both halves, because a member sent here
        ' looking for their watch history has to see the word when they
        ' arrive.
        m.header.text = "History & reset"
        m.subhead.text = "See what you've watched, and start parts of the app over"
        buildResetRows()
    else if cat = "account"
        m.header.text = "Account & help"
        m.subhead.text = accountSubhead()
        buildAccountRows()
    end if

    ' The key line only exists on Sources, and only in the store edition, so
    ' it is set up the first time those rows are built rather than at init,
    ' when the category isn't known yet.
    if not m.deviceKeyReady
        m.deviceKeyReady = true
        initDeviceKey()
    end if

    layoutLines()

    content = CreateObject("roSGNode", "ContentNode")
    for each r in m.rows
        node = content.createChild("ContentNode")
        node.title = r.label
        node.description = r.value
    end for
    m.list.content = content
    if m.rows.count() > 0 then m.sectionTitle.text = m.rows[0].section
end sub

' SOURCES.
' The custom guide rows live here rather than with Live TV: the address is
' saved against ONE source, there is a row per source, and the dialog's own
' words are "point this source at a guide of your own". Sitting directly
' under the source rows they belong to, they read as part of that source.
sub buildSourcesRows()
    providers = LoadProviders()

    addSection("SOURCES")
    ' Merged lineup: every source is always on, so there's no "Active" tag
    ' and no Set Active (Android parity). The KwickTV login is tagged "Your
    ' account" — it is the sign-in this app is running under, which is why
    ' its row offers Sign out where a playlist's row offers Remove.
    '
    ' It used to say "Required" and that word had to go. It meant "you can't
    ' remove it from here", but every member read it as "you need a KwickTV
    ' account to use this app" — the owner's own words — and that is simply
    ' not true: an Xtream login, an M3U address or a USB playlist runs the
    ' whole app on its own. It was also the worst possible word to put in
    ' front of a Roku reviewer, who would see our paid service marked
    ' Required in Settings and read the app as a Subscription Application.
    ' The tag now states what the row IS instead of putting an obligation on
    ' the member. Nothing reads this string — it is display only.
    for each p in providers
        mark = ""
        if ToStr(p.ptype) = "kwicktv" then mark = "Your account"
        ' A media server says WHOSE shelf it is showing rather than repeating
        ' the brand, which the row already carries: an API key can see every
        ' account on the server, so which one was picked is the fact a member
        ' would come here to check.
        if MsIsMediaServer(p)
            un = ToStr(p.userName)
            if un <> "" then mark = "as " + un
        end if
        addRow("provider", p.id, ToStr(p.name) + "  (" + ToStr(p.ptype) + ")", mark)
    end for
    if AllowWebAddressEntry()
        addRow("addSource", "", "Add another source", "+")
        ' Jellyfin/Emby. Sideload only, and it sits in THIS branch rather than
        ' beside the store edition's pairing row for the reason that branch
        ' exists at all: the screen behind it takes a typed server address,
        ' which Roku's Distribution Agreement 10.3(a) forbids a store build
        ' from offering. A store build adds a media server the same way it
        ' adds everything else — pairing at kwickplayer.tv, which now takes
        ' one and hands it over with the rest.
        addRow("addMediaServer", "", "Add a media server (Jellyfin or Emby)", ">")
        addRefreshRows(providers)
    else
        ' Store edition: ONE way to add a source of the member's own — an
        ' Xtream login, an M3U playlist, or their own Jellyfin or Emby — and
        ' this is it. The pairing screen behind the row collects whatever they
        ' added on kwickplayer.tv, because §10.3(a) forbids taking a typed web
        ' address here.
        '
        ' "Add another source" is deliberately gone from this build. It
        ' opened Connect Your Provider, whose only two tabs here are the
        ' KwickTV sign-in — which has a row of its own directly below when
        ' there isn't one yet, and is tagged "Your account" above when there
        ' is — and the USB picker, which has a plainly named row too. So
        ' nothing is orphaned, nothing opens a screen with nothing useful on
        ' it, and there is no second, competing way to add the same kind of
        ' source.
        '
        ' SIGN IN WITH KWICKTV, and why it is here at all. This build used to
        ' assume the KwickTV account was already connected, because the first
        ' screen offers it — but a member who set the TV up with an Xtream
        ' playlist alone and bought KwickTV afterwards had no way back to
        ' that sign-in. The owner's words: they "would have to logout, then
        ' login with kwicktv, and readd their stuff". It cost sales.
        '
        ' Shown ONLY while there is no KwickTV login on the box. Once there
        ' is one the row disappears, because the account is already sitting
        ' at the top of this same list tagged "Your account", and offering to
        ' add a second one would be offering something that cannot happen —
        ' a box has one KwickTV login.
        '
        ' It cannot live on kwickplayer.tv with the other two: certification
        ' 2.2 wants the sign-in to happen on the television, so it has to be
        ' a row here. What it opens is the first screen's own sign-in, not a
        ' copy of it — see showKwickTvSignIn() below.
        if KwickTvProvider() = invalid
            addRow("addKwickTv", "", "Sign in with KwickTV", ">")
        end if
        addRow("linkSource", "", "Add Xtream, M3U or a media server", ">")
        addRow("usbSource", "", "Add a playlist from a USB drive", "+")

        addRefreshRows(providers)

        ' RESET LINK KEY — the sold-the-Roku / handed-down-TV valve, and the
        ' TV half of an action kwickplayer.tv has always been able to do.
        '
        ' IT IS ON THIS SCREEN BECAUSE THE KEY IS ON THIS SCREEN. The key
        ' line sits three lines above these rows, says "TV key ... enter it
        ' at kwickplayer.tv/link", and this row is the only thing in the app
        ' that changes it. A member who wants to stop an old phone — or the
        ' person they sold the Roku to — from reaching this television looks
        ' at the thing they are trying to change, and it is here. It is not
        ' in Account & help: that tile is help and the clean slate, the clean
        ' slate is about what is ON this box, and this is about who can reach
        ' it from somewhere else. Two different questions, two different
        ' screens.
        '
        ' LAST, and in a section of its own, for the same reason the clean
        ' slate is the last row of Account & help: it is the biggest thing
        ' here and the first row of a list is the one the remote is already
        ' sitting on when the screen opens.
        '
        ' Only when there is something to reset. No key means this box has
        ' never paired and there is nothing to change; no secret means the
        ' service would refuse us anyway (it will not unlink a television on
        ' the word of anybody who merely knows its device id). Same silence
        ' the key line keeps in that state — a member who has never used
        ' pairing is not shown a button about it.
        if LinkDeviceKey() <> "" and LinkSecret() <> ""
            addSection("THIS TV")
            addRow("resetKey", "", "Reset link key", resetKeyValue())
        end if
    end if

    ' One row per source: an XMLTV guide matches channels by their tvg-id,
    ' and those ids belong to the source the channels came from — so the
    ' choice is per source, not per app. Most people have one, so it reads
    ' as a single setting.
    ' Labelled "Custom EPG", NOT the provider's name. Naming the row after
    ' the source read as a source rather than a setting — a member scrolled
    ' straight past it looking for exactly this feature. The provider name
    ' is only appended when there's more than one source to tell apart.
    '
    ' SIDELOAD ONLY. The row's whole job is to take the address of an XMLTV
    ' file on a keyboard, and §10.3(a) says a store channel may not "enable
    ' end users to enter web addresses". The section disappears with its
    ' rows — sections here are just a label carried on each row, so nothing
    ' is left behind. Sources set a custom guide on the Android app and it
    ' still arrives over KwickSync.
    '
    ' SEVERAL PER SOURCE, in the member's own order — the phone's model
    ' (custom_epg_screen.dart), and the reason for it is that no single XMLTV
    ' file covers a mixed lineup. One guide has the UK channels, another has
    ' the sports, and neither of them has both. Each guide claims the channels
    ' it can name and passes the rest to the next one; the provider's own
    ' guide is always last.
    '
    ' A guide is a ROW OF ITS OWN, with what it actually covered printed
    ' underneath as its value. That number is the only thing that tells
    ' somebody whether the address they typed was the right one, and it was
    ' previously shown once in a dialog and then never again.
    if AllowWebAddressEntry()
        addSection("TV GUIDE")
        for each p in providers
            ' A media server holds films and shows and no channels, so there is
            ' nothing for an XMLTV guide to name — offering one would be
            ' offering something that cannot do anything.
            if MsIsMediaServer(p) then continue for
            pid = ToStr(p.id)
            suffix = ""
            if providers.count() > 1 then suffix = "  —  " + ToStr(p.name)
            guides = ProviderCustomEpgGuides(p)
            if guides.count() = 0
                addRow("guideAdd", pid, "Custom EPG" + suffix, "Off")
            else
                for i = 0 to guides.count() - 1
                    label = "Guide " + (i + 1).toStr() + "  ·  " + guideHostOf(ToStr(guides[i].u))
                    if suffix <> "" and i = 0 then label = label + suffix
                    addRow("guideItem", pid + "|" + i.toStr(), label, CustomEpgCoverageLabel(guides[i]))
                end for
                if guides.count() < CustomEpgMaxGuides()
                    addRow("guideAdd", pid, "Add another guide" + suffix, "+")
                end if
            end if
        end for
        if providers.count() > 0
            m.noteText = "Guides are tried in this order — the first one that knows a channel fills it in, and anything left over uses your provider's own guide."
        end if
    end if
end sub

' REFRESH — the two rows that go and ask again.
'
' WHY THEY ARE ON SOURCES. The owner's words were "i dont see a way to
' refresh my iptv playlist or channel guide", and both of those things come
' out of a source. The rows sit directly under the list of sources they act
' on, which is also the one place in Settings a member is already thinking
' about where their channels come from. The alternative was a tenth Settings
' tile, and there isn't one: the grid is a fixed 3x3 fitted to the
' title-safe box to the pixel (SettingsScreen.brs works it out), so a tenth
' tile means shrinking all nine — the same reasoning that put Background
' effect on Home & appearance.
'
' NOT FIRST IN THE LIST, deliberately. The first row of a category is the one
' the remote is already sitting on when the screen opens, and pressing OK on
' arrival must not fire a request at somebody's provider. They go after the
' sources and the ways of adding one, and before the last section of either
' edition (TV GUIDE on sideload, THIS TV on the store build).
'
' Nothing to refresh with no sources, so the section disappears with them.
sub addRefreshRows(providers as object)
    if providers.count() = 0 then return
    addSection("REFRESH")
    addRow("refreshChans", "", "Refresh channel list", chanRefreshValue())
    addRow("refreshGuide", "", "Refresh TV guide", guideRefreshValue())
end sub

' PLAYBACK. Start-muted had a section to itself and the three caption rows
' had another; they are all answers to "how does a video play", so they are
' one short screen now.
sub buildPlaybackRows()
    addSection("PLAYBACK")
    addRow("toggle", "pref_start_muted", "Start playback muted", boolVal("pref_start_muted", false))
    addRow("toggle", "pref_captions_auto", "Captions/Subtitles auto on (live TV + movies & series)", boolVal("pref_captions_auto", false))
    addRow("capLang", "", "Preferred subtitle language", LangName(PreferredCaptionLang()))
    addRow("capStyle", "", "Caption style (size, color, background...)", ">")
    ' JB-10, in the words Mason asked for it in: "how long the player controls
    ' show before they fade out". Five, ten or fifteen seconds, and nothing
    ' else. The player reads ControlsTimeoutSecs() when it arms its own hide
    ' timer, so a change here lands on the very next press rather than after a
    ' restart.
    addRow("controlsTimeout", "", "How long the controls stay on screen", ControlsTimeoutSecs().toStr() + " seconds")

    ' ADD-ONS (JB-7, JB-9) — the member's own accounts on other services.
    '
    ' WHY THEY ARE ON THIS SCREEN AND NOT ON A TILE OF THEIR OWN. The Settings
    ' grid is a fixed 3 x 3 whose nine frames fit the title-safe box to the
    ' pixel (the geometry is worked out in SettingsScreen.brs), and a tenth
    ' tile needs a fourth column — every tile 26% narrower and two font sizes
    ' down, on a grid Mason has already approved. The background effect was
    ' put inside a category for the same reason, so this is the second time
    ' the answer has been the same one. Of the nine, Playback is where a
    ' member goes looking: all three add-ons act on what is playing, and the
    ' tile already says "subtitles" on it. If Mason wants a tile, the grid has
    ' to be re-laid first — that is his call, not one to take here.
    '
    ' SUBDL IS DELIBERATELY ABSENT, and AddOnIds() is where that is enforced.
    ' Mason, 2026-09-16: "if people aren't logging into their own subdl
    ' account, it should be baked in and not actually listed in Add-ons." It
    ' has no member login at all, so it has no row, no page and no switch —
    ' only a search row in the player's subtitle menu, which is Gus's half.
    addSection("ADD-ONS")
    for each addOnId in AddOnIds()
        addRow("addon", addOnId, addOnRowLabel(addOnId), ">")
    end for
    ' TRUE OF TWO OF THE THREE, and the sentence used to claim all three.
    ' OpenSubtitles signs in on the television with a username and password,
    ' which is what Roku's own certification 4.12 asks for; Trakt and Simkl
    ' offer no password to an app at all, so those two go to the phone.
    m.noteText = "Add-ons use your own account on each service. OpenSubtitles signs in here; Trakt and Simkl sign in on your phone, with the code the add-on's page shows you."
end sub

' "OpenSubtitles — Signed in as kwickflix", or "OpenSubtitles — Not signed in".
'
' THE WHOLE STATE IS IN THE LABEL, not in the value column, and that is a
' measurement rather than a preference: the value column is 276px wide at 23
' mono (SettingRow.brs:23-26), which is 20 characters before it is cut off,
' and "Signed in as kwickflix" is 22. The label box is 852px, 56 characters,
' so the name is capped below at 24 to leave room for the longest add-on name.
function addOnRowLabel(addOnId as string) as string
    acct = AddOnAccount(addOnId)
    if acct.signedIn <> true then return AddOnLabel(addOnId) + " — Not signed in"
    who = acct.name.trim()
    ' A service that gave us a token but no username still has to read as
    ' signed in — the alternative is a row that says "Signed in as" and then
    ' stops.
    if who = "" then return AddOnLabel(addOnId) + " — Signed in"
    if Len(who) > 24 then who = Left(who, 21) + "..."
    return AddOnLabel(addOnId) + " — Signed in as " + who
end function

' HOME SCREEN. The Media Bar, then the home-row switches, and then the
' member's own lists — because the only thing a list does from Settings is
' turn its home row on or off, which is the same question the switches
' above ask.
sub buildHomeRows()
    ' APPEARANCE first, because it is not about Home at all — the wash it
    ' picks is drawn behind every screen in the app. It sits on this
    ' category because the nine Settings tiles are a fixed 3x3 that fills
    ' the title-safe box exactly (SettingsScreen.brs works the geometry
    ' out): there is no room for a tenth tile without shrinking all nine,
    ' and this is the tile whose subject is what the member is looking at.
    addSection("APPEARANCE")
    addRow("bgEffect", "", "Background effect", BgEffectLabel(BgEffect()))

    ' MEDIA BAR next, because it is the first thing on Home.
    '
    ' Its own switch rather than riding on Show Recently Watched: somebody
    ' can reasonably want the rows and not the big rotating panel, or the
    ' reverse. Same four settings the Android app has, under the same names,
    ' so a choice made on either device means the same thing when it travels
    ' over KwickSync.
    addSection("MEDIA BAR")
    addRow("toggle", "pref_media_bar_enabled", "Show the Media Bar", boolVal("pref_media_bar_enabled", true))
    ' The three below only mean anything while it is switched on, so they
    ' are simply not there when it isn't — a row you can focus and press and
    ' that then does nothing is a trap on a remote.
    if MediaBarEnabled()
        addRow("mediaBarCount", "", "How many to show", MediaBarCount().toStr() + " titles")
        addRow("mediaBarSeconds", "", "Change every", MediaBarSeconds().toStr() + " seconds")
        addRow("mediaBarContent", "", "Show", mediaBarContentLabel())
    end if

    addSection("ROWS ON HOME")
    addRow("toggle", "pref_show_recents", "Show Recently Watched", boolVal("pref_show_recents", true))
    ' Only offered while the rows it folds are actually on screen — a switch
    ' about the shape of a row that isn't there is a row you can press that
    ' then does nothing, which this screen has spent a while getting rid of.
    if GetPrefBool("pref_show_recents", true)
        addRow("toggle", "pref_merge_recently_watched", "Merge Recently Watched into one row", boolVal("pref_merge_recently_watched", false))
    end if
    addRow("toggle", "pref_show_favorites", "Show Favorites", boolVal("pref_show_favorites", true))
    if GetPrefBool("pref_show_favorites", true)
        addRow("toggle", "pref_merge_favorites", "Merge Favorites into one row", boolVal("pref_merge_favorites", false))
    end if
    addRow("toggle", "pref_show_picks", "Show Kwick Picks", boolVal("pref_show_picks", true))

    ' TWO DOORS, ONE PREFERENCE. Android puts "Show my Trakt watchlist on Home"
    ' on the add-on's own page AND here, and both write the same key
    ' (pref_<svc>_watchlist_row). There is no second preference and there must
    ' never be one — two switches that disagree about the same row is a support
    ' call nobody can answer.
    '
    ' ONLY WHILE SIGNED IN, because a row about a watchlist this television has
    ' no account for is a row a member can focus and press and that then does
    ' nothing, which is exactly what the rest of this screen has spent a long
    ' time getting rid of. It also means the switch is never read on a service
    ' that is signed out, where the reader answers false whatever is stored.
    '
    ' NO SUB-LABEL, unlike Android's row. Every row on this screen is a label
    ' and a value and SettingRow has nowhere else to put one; the add-on's own
    ' page carries the explanation.
    for each trackerId in TrackerIds()
        if AddOnSignedIn(trackerId)
            addRow("trackerWatchlist", trackerId, "Show my " + AddOnLabel(trackerId) + " watchlist", onOffLabel(WatchlistRowOn(trackerId)))
        end if
    end for

    ' Last in the section, because it is about all the switches above it.
    ' Mason, 2026-09-16: "on the home -> everything under the media bar we need
    ' to be able to re-order this how we want to." A page of its own rather
    ' than rows here: ten rows moved with a D-pad wants the whole screen, and
    ' every row on THIS screen is a label and a value with nowhere to put an
    ' eleventh control. Android's own title, and no verb in it — the page
    ' itself says which button moves a row once it is open.
    '
    ' ALWAYS OFFERED, even on a box with no favourites and no lists yet: the
    ' order is a taste, not a list of things, and every row on the page is
    ' present whether or not it has anything in it today.
    addRow("homeRowOrder", "", "Row order", ">")

    ' YOUR FAVORITES. Home has always shown these in the order they were
    ' added and there was no way to change it; the phone has had a screen for
    ' it all along (edit_favorites_screen.dart). Only offered where there is
    ' something to put in order — one favorite cannot be reordered and no
    ' favorites is a row that does nothing.
    favCh = LoadFavoriteChannels().count()
    favVod = LoadFavoriteVod().count()
    if favCh > 1 or favVod > 1
        addSection("YOUR FAVORITES")
        if favCh > 1 then addRow("reorderFavs", "favchannels", "Reorder Favorite Channels", favCh.toStr() + " saved")
        if favVod > 1 then addRow("reorderFavs", "favvod", "Reorder Favorite Movies & Series", favVod.toStr() + " saved")
    end if

    lists = LoadLists()
    if lists.count() = 0
        ' Was a row that could be focused and pressed and then did nothing.
        m.noteText = "No lists yet — add items from a movie, series or channel and they'll show up here."
        return
    end if
    addSection("YOUR LISTS")
    for each l in lists
        onOff = "Row OFF"
        if l.homeRow = true then onOff = "Row ON"
        addRow("manageList", l.id, ToStr(l.name), onOff)
    end for
    ' Same reasoning as the favorites above: the order the lists sit in is
    ' the order their rows appear on Home, and one list has no order.
    if lists.count() > 1
        addRow("reorderFavs", "lists", "Put your lists in order", ">")
    end if
end sub

' CATEGORIES. Live TV's reorder screen and the Movies/Series ones were under
' two different headers with the channel sort order stranded between them.
' They are the same job on three catalogues, so they are one screen.
sub buildCategoriesRows()
    addSection("LIVE TV")
    addRow("reorderCats", "live", "Hide & Reorder Live TV Categories", ">")
    ' MASON'S RULING, 2026-09-15: "every hide/reorder/sort needs a revamp to a
    ' better system cause the roku one is not great." Both screens behind
    ' these rows were rebuilt for it — the channels one is now category on the
    ' left, that category's channels in the middle and the actions on the
    ' right, and both let a member check several rows and hide them in one
    ' press instead of one at a time. The rows themselves are unchanged
    ' because the rows were never the problem.
    addRow("manageChans", "", "Hide & Reorder Channels", hiddenChanValue())
    addRow("sortChannels", "", "Channel sort order", sortLabel())

    addSection("MOVIES & SERIES")
    addRow("reorderCats", "movies", "Hide & Reorder Movie Categories", ">")
    addRow("reorderCats", "series", "Hide & Reorder Series Categories", ">")
    m.noteText = "On these screens, OK puts a check on a row. Check as many as you like, then press Right and choose what to do with all of them at once."
end sub

sub buildParentalRows()
    addSection("PARENTAL CONTROLS")
    if not HasParentalPin()
        addRow("setPin", "", "Set a PIN to lock categories", "Off")
        m.noteText = "A PIN lets you hide a category, or make it ask for the PIN before it will open."
        return
    end if
    addRow("changePin", "", "Change PIN", "Set")
    addRow("parentalMode", "", "When a category is locked", modeLabel())
    ' Adult categories are hidden until somebody with the PIN says
    ' otherwise — see the Adult block in GuideMeta.brs (certification
    ' 6.3). Only offered once a PIN exists, because the PIN is what
    ' makes turning it on a deliberate act rather than a stray click.
    addRow("adultCats", "", "Show adult categories", onOffLabel(AdultCatsAllowed()))
    addRow("removePin", "", "Turn off parental controls", "")
end sub

' The grid never opens this screen when sync isn't available — the tile
' explains it in a dialog instead — but the empty case is handled anyway so
' this file makes sense on its own.
sub buildSyncRows()
    addSection("KWICKSYNC")
    if not SyncEligible()
        m.noteText = "Sign in with KwickTV to turn cross-device sync on."
        return
    end if
    addRow("syncToggle", "", "Sync this device", onOffLabel(SyncEnabled()))
    addRow("syncNow", "", syncStatusLine(), "Sync now")
end sub

' The old DATA section, named for what it actually does.
'
' It grew a HISTORY half. There was one row here that wiped the lot and no way
' at all to LOOK at a watch history, which the phone has had for a long time
' (watch_history_screen.dart, and three separate clears in its own settings).
' The two halves sit under their own headings: history is something a member
' comes here to read and tidy, and the rest of this screen is things that
' cannot be undone.
sub buildResetRows()
    addSection("WATCH HISTORY")
    addRow("watchHistory", "", "Watch history", historyCountValue())
    ' How long rows are kept, in days, under the phone's own two settings.
    addRow("keepChannels", "", "Keep watched channels for", RetentionLabel(RecentChannelsMaxAgeDays()))
    addRow("keepVod", "", "Keep watched movies & series for", RetentionLabel(RecentVodMaxAgeDays()))
    ' One row per kind, exactly as on the phone. The old single "Clear watch
    ' history" row is gone: it only ever cleared the CHANNELS list anyway
    ' (ClearRecentChannels), so a member who pressed it expecting their films
    ' to go was told one thing and given another. The row that clears channels
    ' now says channels.
    addRow("clearKind", "live", "Clear channel history", "")
    addRow("clearKind", "movie", "Clear movie history", "")
    addRow("clearKind", "episode", "Clear series history", "")

    addSection("RESET")
    addRow("clearResume", "", "Clear resume points", "")
    addRow("unhideChans", "", "Unhide all channels", "")
    addRow("resetChanOrder", "", "Put channels back in their original order", "")
    m.noteText = "Clearing can't be undone."
end sub

' Help first and the clean slate last, deliberately. It is the biggest thing
' on this screen, and the first row of a list is the one the remote is
' already sitting on when the screen opens.
'
' THIS ROW CLEARS THE WHOLE TELEVISION, which is the owner's ruling: "i
' expect about>signout would sign out of everything ya? we resolved the issue
' with a signout button for kwicktv on sources, and everything else source
' wise is handled through the link page". So the two actions are deliberately
' different jobs and are named for the difference:
'
'   Sources > the KwickTV row > Sign out    the account, and nothing else.
'                                           Playlists stay exactly as they
'                                           are. Unchanged by this.
'   here > Sign out and clear this TV       the account AND every playlist,
'                                           back to the first screen.
'
' The row is named for what is actually on the box, because "Sign out" is a
' lie on a television that isn't signed in to anything: with a KwickTV
' account it reads "Sign out and clear this TV", and on a TV running playlists
' alone it reads "Clear this TV" and does the same one job minus the sign-out
' it has nothing to do. With nothing at all on the box there is no row —
' though a member can't get here in that state anyway, because the last source
' leaving routes straight back to onboarding. A THIS TV section with nothing
' under it leaves nothing behind — a section is just a label carried on the
' rows that follow it.
sub buildAccountRows()
    addSection("HELP")
    addRow("exportLogs", "", "Export Logs", exportLabel())
    ' Sideload only: all three rows end in an address that takes the member
    ' off this Roku (certification 2.5 / 5.3). Export Logs and the clean slate
    ' carry the screen on their own in the store edition.
    '
    ' Check for updates is gated on the SAME manifest line as the launch-time
    ' nudge (AppScene.startUpdateCheck, which bails on KwickEdition() =
    ' "store"), so the row can never appear on a build whose launch check
    ' never runs. A store build updates itself through Roku and must not be
    ' pointed at a zip somewhere else — the rule ShowOffDeviceLinks() is named
    ' for is exactly the rule that applies.
    if ShowOffDeviceLinks()
        addRow("updateCheck", "", "Check for updates", updateCheckLabel())
        addRow("discord", "", "Discord", ">")
        addRow("telegram", "", "Telegram", ">")
    end if

    if LoadProviders().count() > 0
        addSection("THIS TV")
        addRow("clearTv", "", cleanSlateLabel(), "")
    end if

    ' Was the last row of the old list, and pressing it did nothing.
    m.noteText = m.branding.fullAppName + " for Roku  ·  v" + appVersion()
end sub

' A section just labels the rows that follow it.
sub addSection(name as string)
    m.curSection = name
end sub

sub addRow(kind as string, id as string, label as string, value as string)
    m.rows.push({ kind: kind, id: id, label: label, value: value, section: m.curSection })
end sub

function sectionCount() as integer
    seen = {}
    n = 0
    for each r in m.rows
        if not seen.doesExist(r.section)
            seen[r.section] = true
            n = n + 1
        end if
    end for
    return n
end function

' The two optional lines — this TV's key, and the sticky sub-section name —
' push everything below them down. Working the positions out here rather
' than in the XML means a category that has neither doesn't leave two
' stripes of empty screen above its rows.
sub layoutLines()
    y = 212
    if m.deviceKey.visible
        m.deviceKey.translation = [192, y]
        y = y + 40
    end if
    ' A single-section category doesn't get the sticky line: it would just
    ' repeat the heading two lines above it in capitals.
    multi = (sectionCount() > 1)
    m.sectionTitle.visible = multi
    if multi
        m.sectionTitle.translation = [192, y + 4]
        y = y + 48
    end if
    listY = y + 4
    m.list.translation = [192, listY]

    shown = m.rows.count()
    if shown > 10 then shown = 10

    if m.noteText <> ""
        m.note.text = m.noteText
        m.note.translation = [192, listY + shown * 66 + 20]
        m.note.visible = true
    else
        m.note.visible = false
    end if

    ' JB-4 — the accent block, fitted to whatever the lines above worked
    ' out. Top edge 14px above the heading, bottom edge 16px under the last
    ' row that is on screen (the list shows ten at a time and scrolls, so
    ' the block is ten rows tall at most and never grows off the bottom).
    '
    ' The rule sits at x 176 and the wash runs 180..1726, so the wash's
    ' right edge lands exactly on the title-safe right edge and the rule
    ' stands 12px clear of the text column at 192 rather than under the
    ' first letter of the heading. x 176 is outside the title-safe box this
    ' file otherwise sticks to, but it is a plain rule with no text in it
    ' and it is still 80px inside Roku's own 5% action-safe edge at 96.
    '
    ' WHAT THIS ACTUALLY LOOKS LIKE, so nobody "fixes" it later: a setting
    ' row paints its own solid plate (SettingRow.brs, rowBg = surface), so
    ' the wash does not tint the rows themselves — it shows as the surround,
    ' the 10px gutters between rows and the wide margin beside them, plus
    ' the full band behind the four heading lines. The group still reads as
    ' one block. Tinting the row plates too would mean editing SettingRow,
    ' which the overlays share, so it is not done from here.
    '
    ' The footnote is deliberately OUTSIDE the block: it is an explanation
    ' printed under the group rather than part of it, and on a ten-row
    ' category it ends at y 1046, which would drag the block's bottom edge
    ' into the overscan strip a television can cut.
    blockTop = 92
    blockBottom = listY + shown * 66 + 16
    m.wash.translation = [180, blockTop]
    m.wash.width = 1546
    m.wash.height = blockBottom - blockTop
    m.rule.translation = [176, blockTop]
    m.rule.height = blockBottom - blockTop
end sub

' ---- Row value labels -------------------------------------------------------

function boolVal(key as string, dflt as boolean) as string
    if GetPrefBool(key, dflt) then return "ON"
    return "OFF"
end function

' Version straight from the manifest, so the line never goes stale.
function appVersion() as string
    ai = CreateObject("roAppInfo")
    return ai.getValue("major_version") + "." + ai.getValue("minor_version") + "." + ai.getValue("build_version")
end function

function sortLabel() as string
    mode = ChannelSort()
    if mode = "az" then return "A-Z"
    if mode = "za" then return "Z-A"
    return "Default"
end function

function modeLabel() as string
    if ParentalMode() = "hide" then return "Hidden"
    return "Ask for PIN"
end function

function exportLabel() as string
    if m.exportState = invalid then return ""
    return m.exportState
end function

' The Check for updates row's right-hand column. Nothing until it is pressed,
' then what happened. The answer also comes as a dialog, but this stays on
' screen after that is dismissed, so a member who pressed OK a second too
' quickly still has it in front of them.
function updateCheckLabel() as string
    if m.updateState = invalid then return ""
    return m.updateState
end function

' The Reset link key row's right-hand column. It says something for the two
' or three seconds the service is being asked and nothing the rest of the
' time: the answer to this one is a dialog, because the member is sitting
' there waiting for it.
function resetKeyValue() as string
    if m.resetState = invalid then return ""
    return m.resetState
end function

function onOffLabel(b as boolean) as string
    if b then return "ON"
    return "OFF"
end function

' The two refresh rows' right-hand column. Nothing until pressed, then what
' is happening and then what happened — a refresh takes seconds and a row
' that looks dead while it works is a row that gets pressed again.
function chanRefreshValue() as string
    if m.chanRefreshState = invalid then return ""
    return m.chanRefreshState
end function

function guideRefreshValue() as string
    if m.guideRefreshState = invalid then return ""
    return m.guideRefreshState
end function

' 31052 -> "31,052". Big numbers are the point of the shrink guard's own
' message ("11 where you had 31,052" is something a member can quote at
' their provider) and unreadable without the commas.
function groupedNumber(v as integer) as string
    digits = v.toStr()
    out = ""
    n = Len(digits)
    for i = 1 to n
        if i > 1 and ((n - i + 1) mod 3) = 0 then out = out + ","
        out = out + Mid(digits, i, 1)
    end for
    return out
end function

' The right-hand column on Hide & Reorder Channels: what has actually been
' done, so the row says whether there is anything behind it before it is
' opened. Hidden channels are counted for the ACTIVE source only — the number
' is a hint, not a total, and loading every source's hidden set to build a
' Settings label would be a registry read per source per redraw.
function hiddenChanValue() as string
    hid = LoadHiddenChannels().count()
    moved = LoadChanOrder().count()
    if hid = 0 and moved = 0 then return ">"
    parts = ""
    if hid > 0 then parts = hid.toStr() + " hidden"
    if moved > 0
        if parts <> "" then parts = parts + ", "
        parts = parts + moved.toStr() + " moved"
    end if
    return parts
end function

' How much history there is to look at, so the row doesn't open an empty
' screen without warning.
function historyCountValue() as string
    n = WatchHistoryCount() + LoadRecentChannels().count()
    if n = 0 then return "Nothing yet"
    if n = 1 then return "1 item"
    return n.toStr() + " items"
end function

' ---- Background effect ------------------------------------------------------
' Four choices, shown as a list to pick from for the same reason the Media Bar
' numbers below are: a value that cycles would make a member press the row
' three times to find out what was even on offer.
'
' The four strings are Android's own and are held in Store.brs
' (BgEffectChoices / BgEffectLabel); this screen never spells one out, so the
' two lists cannot drift apart. Cancel is the last button, as it is on every
' other picker on this screen.

sub showBgEffectPicker(idx as integer)
    m.bgEffectRowIdx = idx
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Background effect"
    dialog.message = "The pattern drawn behind everything, on every screen." + Chr(10) + Chr(10) + "Grid Lines is the look this app has always had."
    btns = []
    for each c in BgEffectChoices()
        btns.push(BgEffectLabel(c))
    end for
    btns.push("Cancel")
    dialog.buttons = btns
    ' Open on the setting's CURRENT value, so the list says what it is now
    ' before it says what it could be.
    dialog.focusButton = bgEffectChoiceIndex(BgEffect())
    dialog.observeField("buttonSelected", "onBgEffectPicked")
    m.top.getScene().dialog = dialog
end sub

function bgEffectChoiceIndex(current as string) as integer
    ch = BgEffectChoices()
    for i = 0 to ch.count() - 1
        if ch[i] = current then return i
    end for
    return 0
end function

sub onBgEffectPicked()
    dialog = m.top.getScene().dialog
    choice = dialog.buttonSelected
    dialog.close = true
    opts = BgEffectChoices()
    ' Cancel is the last button.
    if choice >= 0 and choice < opts.count()
        SetBgEffect(ToStr(opts[choice]))
        KLog("settings", "background effect set to " + ToStr(opts[choice]))
    end if
    refresh()
    m.list.jumpToItem = m.bgEffectRowIdx
    m.list.setFocus(true)
end sub

' ---- Media Bar pickers ------------------------------------------------------
' Four choices each, shown as a list to pick from rather than a value that
' cycles: cycling is fine for a two-way switch, but a member wanting 20 out
' of five, ten, fifteen and twenty would have to press a row four times and
' watch the number go past to find out what the choices even were.

function mediaBarContentLabel() as string
    c = MediaBarContent()
    if c = "movies" then return "Movies only"
    if c = "series" then return "Series only"
    return "Both"
end function

sub showMediaBarPicker(which as string, idx as integer)
    m.mediaBarPick = which
    m.mediaBarRowIdx = idx
    dialog = CreateObject("roSGNode", "Dialog")
    if which = "count"
        dialog.title = "How many to show"
        dialog.message = "How many titles the Media Bar rotates through."
        dialog.buttons = ["5 titles", "10 titles", "15 titles", "20 titles", "Cancel"]
        dialog.focusButton = mediaBarChoiceIndex(MediaBarChoices(), MediaBarCount())
    else if which = "seconds"
        dialog.title = "Change every"
        dialog.message = "How long each title is shown before the next one."
        dialog.buttons = ["5 seconds", "10 seconds", "15 seconds", "20 seconds", "Cancel"]
        dialog.focusButton = mediaBarChoiceIndex(MediaBarChoices(), MediaBarSeconds())
    else
        dialog.title = "Show"
        dialog.message = "Which of your unfinished titles can appear in the Media Bar."
        dialog.buttons = ["Both", "Movies only", "Series only", "Cancel"]
        dialog.focusButton = mediaBarChoiceIndex(MediaBarContentChoices(), MediaBarContent())
    end if
    dialog.observeField("buttonSelected", "onMediaBarPicked")
    m.top.getScene().dialog = dialog
end sub

' Open on the setting's CURRENT value, so the list says what it is now
' before it says what it could be.
function mediaBarChoiceIndex(choices as object, current as dynamic) as integer
    for i = 0 to choices.count() - 1
        if ToStr(choices[i]) = ToStr(current) then return i
    end for
    return 0
end function

sub onMediaBarPicked()
    dialog = m.top.getScene().dialog
    choice = dialog.buttonSelected
    which = m.mediaBarPick
    dialog.close = true
    if which = "content"
        opts = MediaBarContentChoices()
    else
        opts = MediaBarChoices()
    end if
    ' Cancel is the last button on every one of them.
    if choice >= 0 and choice < opts.count()
        if which = "count"
            SetMediaBarCount(opts[choice])
        else if which = "seconds"
            SetMediaBarSeconds(opts[choice])
        else
            SetMediaBarContent(ToStr(opts[choice]))
        end if
        KLog("settings", "media bar " + which + " set to " + ToStr(opts[choice]))
    end if
    refresh()
    m.list.jumpToItem = m.mediaBarRowIdx
    m.list.setFocus(true)
end sub

' ---- How long the player's controls stay on screen ---------------------------
' JB-10. Shown as a list to pick from rather than a row that cycles, for the
' same reason the Media Bar numbers are: a member who wants fifteen seconds
' should not have to press a row twice to find out fifteen was on offer.
'
' The three choices and the default live in Store.brs
' (ControlsTimeoutChoices / ControlsTimeoutSecs), so this screen and the
' player cannot come to different conclusions about what is set.

sub showControlsTimeoutPicker(idx as integer)
    m.controlsTimeoutRowIdx = idx
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "How long the controls stay on screen"
    dialog.message = "How long the play, pause and progress bar stay up after you press a button, before they fade away."
    btns = []
    for each secs in ControlsTimeoutChoices()
        btns.push(ToStr(secs) + " seconds")
    end for
    btns.push("Cancel")
    dialog.buttons = btns
    ' Open on the setting's CURRENT value, so the list says what it is now
    ' before it says what it could be.
    dialog.focusButton = controlsTimeoutChoiceIndex(ControlsTimeoutSecs())
    dialog.observeField("buttonSelected", "onControlsTimeoutPicked")
    m.top.getScene().dialog = dialog
end sub

function controlsTimeoutChoiceIndex(current as integer) as integer
    ch = ControlsTimeoutChoices()
    for i = 0 to ch.count() - 1
        if ch[i] = current then return i
    end for
    return 0
end function

sub onControlsTimeoutPicked()
    dialog = m.top.getScene().dialog
    choice = dialog.buttonSelected
    dialog.close = true
    opts = ControlsTimeoutChoices()
    ' Cancel is the last button.
    if choice >= 0 and choice < opts.count()
        SetControlsTimeoutSecs(opts[choice])
        KLog("settings", "player controls stay up for " + ToStr(opts[choice]) + "s")
    end if
    refresh()
    m.list.jumpToItem = m.controlsTimeoutRowIdx
    m.list.setFocus(true)
end sub

' ---- An add-on's own page ----------------------------------------------------
' One row per add-on, each opening AddOnDetailScreen for that add-on. The
' contract is one field in and one field back — `addon` is the id string from
' AddOnIds(), `closed` says the member has finished with it — which is the
' same shape every other sub-screen this file opens uses. Nothing about what
' the page does is known here, deliberately: signing in, signing out and the
' service's own switches all live on the page.
'
' Coming back rebuilds the rows, because the state line is the thing most
' likely to have changed while it was open.

sub openAddOn(addOnId as string)
    if addOnId = "" then return
    scr = m.top.getScene().createChild("AddOnDetailScreen")
    ' A dev build where the page has not landed yet is the only way this can
    ' be invalid — createChild answers invalid for a component that isn't in
    ' the zip, and setting a field on invalid takes this screen's render
    ' thread down with it. A row that does nothing is a poor answer and this
    ' file has spent a long time getting rid of those; a locked-up Settings
    ' screen is a much worse one, and the log line says which it was.
    if scr = invalid
        KLog("settings", "add-on page for '" + addOnId + "' is not in this build")
        return
    end if
    scr.addon = addOnId
    scr.observeField("closed", "onAddOnClosed")
    scr.setFocus(true)
    m.addOnScreen = scr
end sub

sub onAddOnClosed()
    if m.addOnScreen = invalid then return
    m.top.getScene().removeChild(m.addOnScreen)
    m.addOnScreen = invalid
    keep = m.list.itemFocused
    refresh()
    if keep >= 0 and keep < m.rows.count() then m.list.jumpToItem = keep
    m.list.setFocus(true)
end sub

' ---- How long history is kept ------------------------------------------------
' The same seven choices the phone offers, in the same order, shown as a list
' to pick from for the same reason the Media Bar numbers are: a member who
' wants Forever should not have to press a row six times to find out that
' Forever was even on offer.

sub showRetentionPicker(which as string, idx as integer)
    m.retentionPick = which
    m.retentionRowIdx = idx
    cur = RecentChannelsMaxAgeDays()
    if which = "vod" then cur = RecentVodMaxAgeDays()
    dialog = CreateObject("roSGNode", "Dialog")
    if which = "channels"
        dialog.title = "Keep watched channels for"
        dialog.message = "How long a channel stays in Recently Watched after you last watched it."
    else
        dialog.title = "Keep watched movies & series for"
        dialog.message = "How long a film or show stays in Continue Watching and Recently Watched after you last played it."
    end if
    btns = []
    for each d in RetentionChoices()
        btns.push(RetentionLabel(d))
    end for
    btns.push("Cancel")
    dialog.buttons = btns
    ' Open on the setting's CURRENT value, so the list says what it is now
    ' before it says what it could be.
    dialog.focusButton = retentionChoiceIndex(cur)
    dialog.observeField("buttonSelected", "onRetentionPicked")
    m.top.getScene().dialog = dialog
end sub

function retentionChoiceIndex(current as integer) as integer
    ch = RetentionChoices()
    for i = 0 to ch.count() - 1
        if ch[i] = current then return i
    end for
    return 0
end function

sub onRetentionPicked()
    dialog = m.top.getScene().dialog
    choice = dialog.buttonSelected
    which = m.retentionPick
    dialog.close = true
    opts = RetentionChoices()
    ' Cancel is the last button.
    if choice >= 0 and choice < opts.count()
        if which = "channels"
            SetRecentChannelsMaxAgeDays(opts[choice])
        else
            SetRecentVodMaxAgeDays(opts[choice])
        end if
        KLog("settings", "history retention " + which + " set to " + ToStr(opts[choice]) + " day(s)")
    end if
    refresh()
    m.list.jumpToItem = m.retentionRowIdx
    m.list.setFocus(true)
end sub

' Said in the member's own words, and saying what SURVIVES as well as what
' goes — "clear my movie history" reads to most people like it might take
' their favorites with it.
function clearKindPrompt(kind as string) as string
    if kind = "live" then return "Clear the list of channels you've recently watched?" + Chr(10) + Chr(10) + "Your favorite channels and your lists are not touched."
    if kind = "movie" then return "Clear your movie history?" + Chr(10) + Chr(10) + "The films come out of Continue Watching and Recently Watched, and their saved positions go with them. Favorites and lists are not touched."
    return "Clear your series history?" + Chr(10) + Chr(10) + "The shows come out of Continue Watching and Recently Watched, and the saved positions in their episodes go with them. Favorites and lists are not touched."
end function

' It said "or sign out of this source", which was the whole bug written on
' the screen: there is no signing out of a source, only of the KwickTV
' account. It then said "or sign out of KwickTV", which stopped being the
' whole truth the moment this screen's action started clearing the playlists
' too. It now says what the row underneath it says, in the same three states,
' so the line and the row can't promise two different things.
function accountSubhead() as string
    if LoadProviders().count() = 0 then return "Get help from the team"
    if KwickTvProvider() <> invalid then return "Get help from the team, or sign out and clear this TV"
    return "Get help from the team, or clear this TV"
end function

function syncStatusLine() as string
    if m.syncPhase = "syncing" then return "Syncing…"
    if m.syncPhase = "error" then return m.syncMessage
    if not SyncEnabled() then return "Sync is off for this device"
    last = SyncLastAt()
    if last = 0 then return "Not synced yet"
    return "Last synced " + agoText(last)
end function

function agoText(secs as integer) as string
    now = CreateObject("roDateTime").asSeconds()
    d = now - secs
    if d < 45 then return "just now"
    if d < 3600
        mins = Int(d / 60)
        if mins <= 1 then return "1 min ago"
        return mins.toStr() + " min ago"
    end if
    if d < 86400
        h = Int(d / 3600)
        if h = 1 then return "1 hour ago"
        return h.toStr() + " hours ago"
    end if
    dd = Int(d / 86400)
    if dd = 1 then return "1 day ago"
    return dd.toStr() + " days ago"
end function

' Jump the list back to a row of the given kind after a rebuild, so the
' KwickSync rows stay put while their status updates.
sub jumpToKind(kind as string)
    for i = 0 to m.rows.count() - 1
        if m.rows[i].kind = kind
            m.list.jumpToItem = i
            return
        end if
    end for
end sub

' Kick a manual sync cycle and reflect its status inline.
sub startSyncNow()
    if m.syncTask <> invalid and m.syncTask.state = "run" then return
    m.syncPhase = "syncing"
    refresh()
    jumpToKind("syncNow")
    m.list.setFocus(true)
    m.syncTask = CreateObject("roSGNode", "SyncTask")
    m.syncTask.observeField("result", "onSyncResult")
    m.syncTask.control = "RUN"
end sub

sub onSyncResult(event as object)
    res = event.getData()
    if res = invalid then return
    m.syncPhase = ToStr(res.phase)
    if res.message <> invalid then m.syncMessage = ToStr(res.message)
    refresh()
    jumpToKind("syncNow")
    m.list.setFocus(true)
end sub

' ---- This TV's key ----------------------------------------------------------
' STORE EDITION ONLY, and Sources only. The sideload build takes a web
' address on the remote, so it has no pairing flow, no key, and nothing here
' to draw.
'
' The key is this television's permanent name at kwickplayer.tv/link — what
' a member types on a phone, months later, to sort out the playlists on this
' TV. It has moved with the pairing rows: it sits on the Sources screen now,
' directly above "Add a source", which is the row it exists to serve.
'
' HIDDEN UNTIL ASKED FOR, and that is the whole design. Anyone who can read
' the key can rearrange this TV's playlists from their own phone (they can't
' read a password or a playlist address back out — those only ever travel to
' the TV). It never expires and there is no way to change it, so once it is
' out, it is out for good. But it is only WANTED on the one visit where
' somebody is setting up their phone — and members photograph this screen to
' send to us. So it stays behind one press of * on the remote, which costs
' the member who actually wants it about a second. Being a tile deep now
' hides it from the casual Settings visit as well, which is a second lock on
' the same door rather than a replacement for the first.
sub initDeviceKey()
    if AllowWebAddressEntry() then return
    if m.top.category <> "sources" then return

    ' 24 -> 22 for the JetBrains Mono sweep. The hidden-state sentence is
    ' 104 characters, which at 24 mono is 1498px from x=192 and lands 36px
    ' short of the title-safe right edge — too close to trust on a set that
    ' overscans. At 22 it is 1373px and ends at 1565.
    m.deviceKey.font = UiFont(22)
    m.deviceKey.color = m.theme.textSecondary
    m.deviceKey.visible = true

    ' The space is reserved whether or not there is a key to put in it: a
    ' key that arrives from the background refresh a second after the screen
    ' opens must not shove the whole menu downwards under the member's thumb.
    '
    ' Cached value on screen first, always. Only a box with no cached key
    ' asks for one here — an upgrade from a build that paired before any of
    ' this existed. Every other visit costs nothing.
    drawDeviceKey()
    if LinkDeviceKey() = "" then refreshDeviceKey()
end sub

' Three states and only three: no key known (say nothing at all — a member
' who has never paired must not be shown an error, a placeholder or a
' spinner about a feature they haven't used), key known and hidden, key
' known and showing.
sub drawDeviceKey()
    if not m.deviceKey.visible then return
    keyFmt = LinkDeviceKey()
    if keyFmt = ""
        m.deviceKey.text = ""
        return
    end if
    if m.deviceKeyShown
        m.deviceKey.text = "TV key " + keyFmt + "  ·  enter it at kwickplayer.tv/link to manage this TV's playlists"
        return
    end if
    m.deviceKey.text = "TV key hidden  ·  press * to show it, then enter it at kwickplayer.tv/link to manage this TV's playlists"
end sub

' A top-up, not a load. Whatever is cached is already on screen and stays
' there until an answer arrives; nothing here is waited on and nothing here
' can make the member wait.
'
' Called on two occasions and no others: opening Sources with nothing
' cached, and the moment the member reveals the key. The second is the point
' of it — the key is permanent, so re-asking on every idle visit would be a
' request a day to be told the same thing, but the one second somebody is
' about to type it into a phone is the one second a stale copy would cost
' them anything.
'
' Needs the secret the pairing code came with — the service will not hand
' the key over without it, ever. No secret means this box has never paired,
' so there is nothing to ask about and the line simply stays blank until the
' member uses Add a source, which caches both.
sub refreshDeviceKey()
    secret = LinkSecret()
    if secret = "" then return
    ' One in the air at a time; * can be pressed faster than the service
    ' answers.
    if m.deviceKeyTask <> invalid then return
    m.deviceKeyTask = CreateObject("roSGNode", "SourceLinkTask")
    m.deviceKeyTask.action = "key"
    m.deviceKeyTask.device = LinkDeviceId()
    m.deviceKeyTask.secret = secret
    m.deviceKeyTask.observeField("result", "onDeviceKeyResult")
    m.deviceKeyTask.control = "RUN"
end sub

' Silent on every failure, exactly like the update check: a member who can't
' reach the service still has the key that was cached the day they paired,
' and a member who has no key was never being shown one.
sub onDeviceKeyResult(event as object)
    m.deviceKeyTask = invalid
    res = event.getData()
    if res = invalid or res.ok <> true then return
    keyFmt = ToStr(GetField(res, "key_fmt"))
    if keyFmt = "" then return
    SetLinkDeviceKey(keyFmt)
    drawDeviceKey()
end sub

' ---- Reset link key ---------------------------------------------------------
' The sold-the-Roku button. kwickplayer.tv has been able to do this since the
' link service was written; the television could not ask for it until now.
'
' WHAT THE SERVICE DOES when it hears "reset", all of it at once: a brand new
' key is issued and the old one is deleted so it can never be resolved again,
' every browser token for this TV is revoked, every playlist on this TV's list
' is tombstoned and its saved password wiped, the per-TV guide setting is
' emptied, the pairing code is dropped, what this TV reported about its own
' KwickTV login is forgotten, and the secret is rotated. A full unlink, not
' just a new key.
'
' THE NEW SECRET IS THE WHOLE BALLGAME. The reply carries a new key AND a new
' secret, and from the moment the service answers, the secret this box has
' been using is dead. Miss it and this television can never poll, never read
' its key back and never drop a playlist again — every one of those actions
' is refused without the secret — and nothing would say so out loud. So it is
' written FIRST, before the key and before anything else is touched, and then
' read straight back out of the registry to be sure it is really there.
'
' NOT FIRE AND FORGET, unlike every other word this screen says to the link
' service. A member who presses this is standing in front of the television
' waiting to be told whether their old key still works, and being left to
' assume is the one outcome that isn't allowed.

' Cancel is the focused button, exactly as on the KwickTV sign-out dialog and
' for the same reason: this is what a member gets for pressing a row to find
' out what it is, so OK-OK on the remote has to be the way out of it.
sub confirmResetKey()
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Reset link key"
    dialog.message = "This TV gets a brand new key, and the key you have now stops working." + Chr(10) + Chr(10) + "Any phone or computer set up to manage this TV is signed out, and the playlists you added on kwickplayer.tv come off this TV's list there — you'd add them again on the website. The playlists already on this TV stay where they are and keep playing." + Chr(10) + Chr(10) + "Do this if you're selling this Roku or passing it on, or to stop somebody else managing it."
    dialog.buttons = ["Reset key", "Cancel"]
    dialog.focusButton = 1
    dialog.observeField("buttonSelected", "onResetKeyConfirm")
    m.top.getScene().dialog = dialog
end sub

sub onResetKeyConfirm()
    dialog = m.top.getScene().dialog
    yes = (dialog.buttonSelected = 0)
    dialog.close = true
    if not yes
        m.list.setFocus(true)
        return
    end if
    startResetKey()
end sub

sub startResetKey()
    ' One at a time. The row can be pressed again while the request is in the
    ' air, and a second reset would rotate the secret a second time — leaving
    ' the first answer, when it lands, storing a secret the service has
    ' already replaced.
    if m.resetTask <> invalid then return
    secret = LinkSecret()
    if secret = ""
        ' The row isn't built without one. Belt and braces: the service would
        ' refuse us anyway, and saying so plainly beats a "forbidden" the
        ' member can do nothing with.
        showResetResult("Couldn't reset the key", "This TV hasn't been paired with kwickplayer.tv yet, so there's no key to reset.")
        return
    end if
    m.resetState = "Resetting…"
    refresh()
    jumpToKind("resetKey")
    m.list.setFocus(true)
    t = CreateObject("roSGNode", "SourceLinkTask")
    t.action = "reset"
    t.device = LinkDeviceId()
    t.secret = secret
    t.observeField("result", "onResetKeyResult")
    m.resetTask = t
    ' A second reference, off this screen, for the same reason the sign-out
    ' report keeps one: a component held only in this file's m goes when the
    ' screen goes, and a task collected halfway through this particular
    ' request would leave the service half asked — the one request in the app
    ' that must not be cut off in the middle. ONE SLOT is enough: the guard
    ' at the top of this sub means there is never a second reset in the air.
    ' (addFields refuses to overwrite a field that already exists, hence the
    ' two ways in.)
    '
    ' What it does NOT do is answer for a screen that is gone: the reply is
    ' read by this component and nothing else, so a member who backs out of
    ' Settings in the two seconds this takes loses the new key and secret.
    ' That is survivable and only that — pairing (Add a source) claims,
    ' and a claim hands back this TV's current key and current secret — which
    ' is the same way out resetOutOfStepMessage() points at below.
    if m.global.hasField("linkResetTask")
        m.global.linkResetTask = t
    else
        m.global.addFields({ linkResetTask: t })
    end if
    KLog("link", "reset link key: asking the service for a new key for this TV")
    t.control = "RUN"
end sub

sub onResetKeyResult(event as object)
    m.resetTask = invalid
    m.resetState = ""
    ' Twelve seconds is long enough for the member to have left Settings, so
    ' the dialog at the end of every path below is put up through
    ' showResetResult(), which checks there is still a scene to put it on.
    ' Nothing else here is skipped: the registry writes are what keep this box
    ' able to talk to the service at all, and they happen whether or not
    ' anybody is still looking at this screen.
    res = event.getData()
    refresh()
    jumpToKind("resetKey")

    if res = invalid or res.ok <> true
        answer = ""
        if res <> invalid then answer = ToStr(GetField(res, "code"))
        KLog("link", "reset link key: refused (" + answer + ")")
        showResetResult("Couldn't reset the key", resetFailedMessage(answer))
        return
    end if

    newSecret = ToStr(GetField(res, "secret"))
    newKey = ToStr(GetField(res, "key_fmt"))
    if newSecret = "" or newKey = ""
        ' The service has already done it — it answered ok — but it hasn't
        ' told us what with. Same hole as a lost answer, same way out.
        KLog("link", "reset link key: the answer was missing the new secret or key")
        showResetResult("This TV's key was changed", resetOutOfStepMessage())
        return
    end if

    ' THE SECRET FIRST, and nothing else until it is known to be there. Every
    ' later conversation with the service — the poll behind Add Xtream or
    ' M3U, the key top-up on this screen, the drop when a playlist is
    ' removed — is refused without it.
    SetLinkSecret(newSecret)
    SetLinkDeviceKey(newKey)
    if LinkSecret() <> newSecret or LinkDeviceKey() <> newKey
        ' The registry didn't keep it. There is no second copy anywhere and
        ' the old secret is dead, so say so and point at the one thing that
        ' fixes it: pairing hands both back.
        KLog("link", "reset link key: the new key or secret did NOT save")
        showResetResult("This TV's key was changed", resetOutOfStepMessage())
        return
    end if

    ' The service has tombstoned every playlist on this TV's website list, so
    ' this box's memory of which local source came from which website entry
    ' is about nothing at all now — and the cursor with it, for the same
    ' reason the clean slate takes both. The playlists themselves are left
    ' exactly where they are: they play from what is stored on this box, the
    ' dialog promised they would stay, and the member did not ask to lose
    ' them.
    ForgetEveryLinkedSource()
    ' The line at the top of this screen is showing the old key. It stays
    ' covered up if it was covered up — a reset is not somebody asking to see
    ' it — but it must not go on printing a key that no longer exists.
    drawDeviceKey()
    KLog("link", "reset link key: new key stored, this TV is unlinked")
    showResetResult("This TV has a new key", resetDoneMessage(res))
end sub

' Only ever says "nothing was changed" where that is actually known. A
' refusal is decided by the service before it touches anything, so those are
' safe to be certain about — but a request that never came back might have
' been carried out and lost on the way home, and telling somebody their key
' is fine when it may already be dead is the one lie that would cost them the
' feature without warning.
function resetFailedMessage(answer as string) as string
    if answer = "rate_limited" or answer = "busy"
        return "kwickplayer.tv is busy just now, so nothing was changed. Try again in a few minutes."
    end if
    if answer = "forbidden" or answer = "bad_device"
        return "kwickplayer.tv didn't recognise this TV, so nothing was changed. Open Add a source to pair this TV again, then try this once more."
    end if
    return "Couldn't reach kwickplayer.tv, so this TV can't tell you whether the key changed." + Chr(10) + Chr(10) + "Check the Roku's internet connection, then open Add a source — pairing puts this TV back in step with whatever its key is now."
end function

' The service did it and this box hasn't got the new details. Pairing is the
' cure and the only one: a claim hands back this TV's current key and current
' secret, whatever they are now.
function resetOutOfStepMessage() as string
    return "The old key has stopped working, but this TV couldn't save the new one." + Chr(10) + Chr(10) + "Open Add a source to pair this TV again — that gets it back in step and shows you the new key."
end function

' Written from what the service says it actually revoked, the same way the
' clean slate's warning is written from what is actually on the box: a TV
' nothing was managing isn't told about phones being signed out, and a TV
' with no playlists on the website isn't told about playlists.
function resetDoneMessage(res as object) as string
    revoked = GetField(res, "revoked")
    phones = ToInt(GetField(revoked, "tokens"))
    lists = ToInt(GetField(revoked, "sources"))
    out = "The key you had before has stopped working."
    if phones = 1
        out = out + " The phone or computer that was managing this TV has been signed out."
    else if phones > 1
        out = out + " The " + phones.toStr() + " phones or computers that were managing this TV have been signed out."
    end if
    if lists = 1
        out = out + Chr(10) + Chr(10) + "The playlist you added on kwickplayer.tv has come off this TV's list there. It's still on this TV and still plays."
    else if lists > 1
        out = out + Chr(10) + Chr(10) + "The " + lists.toStr() + " playlists you added on kwickplayer.tv have come off this TV's list there. They're still on this TV and still play."
    end if
    return out + Chr(10) + Chr(10) + "This TV's new key is on this screen — press * to show it."
end function

' One notice, one button, three outcomes behind it. Guarded like the Export
' Logs popup: the answer can arrive after the member has left Settings.
sub showResetResult(title as string, message as string)
    scene = m.top.getScene()
    if scene = invalid then return
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = title
    dialog.message = message
    dialog.buttons = ["OK"]
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onResetResultClosed")
    scene.dialog = dialog
end sub

sub onResetResultClosed()
    scene = m.top.getScene()
    if scene <> invalid and scene.dialog <> invalid then scene.dialog.close = true
    m.list.setFocus(true)
end sub

' ---- Selection --------------------------------------------------------------

sub onSelected()
    idx = m.list.itemSelected
    if idx < 0 or idx >= m.rows.count() then return
    r = m.rows[idx]

    if r.kind = "toggle"
        SetPrefBool(r.id, not GetPrefBool(r.id, r.id = "pref_show_recents" or r.id = "pref_show_favorites" or r.id = "pref_show_picks" or r.id = "pref_media_bar_enabled"))
        refresh()
        m.list.jumpToItem = idx
    else if r.kind = "provider"
        m.actionId = r.id
        showSourceDialog(r.label)
    else if r.kind = "addSource"
        showAddDialog()
    else if r.kind = "syncToggle"
        SetSyncEnabled(not SyncEnabled())
        refresh()
        m.list.jumpToItem = idx
        if SyncEnabled() then startSyncNow()
    else if r.kind = "syncNow"
        if SyncEnabled() then startSyncNow()
    else if r.kind = "reorderCats"
        titles = { live: "Live TV Categories", movies: "Movie Categories", series: "Series Categories" }
        m.reorder = m.top.getScene().createChild("ReorderCategoriesScreen")
        m.reorder.scope = r.id
        m.reorder.titleText = titles[r.id]
        m.reorder.observeField("closed", "onReorderClosed")
        m.reorder.setFocus(true)
    else if r.kind = "reorderFavs"
        titles = { favchannels: "Favorite Channels", favvod: "Favorite Movies & Series", lists: "Your Lists" }
        m.reorder = m.top.getScene().createChild("ReorderFavoritesScreen")
        m.reorder.scope = r.id
        m.reorder.titleText = titles[r.id]
        m.reorder.observeField("closed", "onReorderClosed")
        m.reorder.setFocus(true)
    else if r.kind = "homeRowOrder"
        m.reorder = m.top.getScene().createChild("HomeRowOrderScreen")
        m.reorder.observeField("closed", "onReorderClosed")
        m.reorder.setFocus(true)
    else if r.kind = "manageChans"
        m.reorder = m.top.getScene().createChild("ManageChannelsScreen")
        m.reorder.observeField("closed", "onReorderClosed")
        m.reorder.setFocus(true)
    else if r.kind = "watchHistory"
        m.reorder = m.top.getScene().createChild("WatchHistoryScreen")
        m.reorder.observeField("closed", "onReorderClosed")
        m.reorder.setFocus(true)
    else if r.kind = "keepChannels"
        showRetentionPicker("channels", idx)
    else if r.kind = "keepVod"
        showRetentionPicker("vod", idx)
    else if r.kind = "clearKind"
        m.pendingKind = r.id
        confirmAction(clearKindPrompt(r.id), "clearKind")
    else if r.kind = "resetChanOrder"
        confirmAction("Put every channel back in the order your provider sends them?", "resetChanOrder")
    else if r.kind = "manageList"
        m.actionListId = r.id
        showListDialog(r.label)
    else if r.kind = "addKwickTv"
        showKwickTvSignIn()
    else if r.kind = "linkSource"
        openSourceLink()
    else if r.kind = "addMediaServer"
        openAddMediaServer()
    else if r.kind = "usbSource"
        openUsbPicker()
    else if r.kind = "resetKey"
        confirmResetKey()
    else if r.kind = "refreshChans"
        startChannelRefresh(idx)
    else if r.kind = "refreshGuide"
        startGuideRefresh(idx)
    else if r.kind = "guideItem"
        showGuideItemMenu(r.id, idx)
    else if r.kind = "guideAdd"
        showGuideAddMenu(r.id, idx)
    else if r.kind = "bgEffect"
        showBgEffectPicker(idx)
    else if r.kind = "mediaBarCount"
        showMediaBarPicker("count", idx)
    else if r.kind = "mediaBarSeconds"
        showMediaBarPicker("seconds", idx)
    else if r.kind = "mediaBarContent"
        showMediaBarPicker("content", idx)
    else if r.kind = "controlsTimeout"
        showControlsTimeoutPicker(idx)
    else if r.kind = "addon"
        openAddOn(r.id)
    else if r.kind = "trackerWatchlist"
        ' The same key the add-on's own page writes. Deliberately NOT the
        ' generic "toggle" kind above: these are device-level and default ON,
        ' and that kind writes per-profile keys through SetPrefBool with a
        ' default of OFF.
        SetWatchlistRowOn(r.id, not WatchlistRowOn(r.id))
        refresh()
        m.list.jumpToItem = idx
    else if r.kind = "sortChannels"
        cycleSort()
        refresh()
        m.list.jumpToItem = idx
    else if r.kind = "capLang"
        cycleCaptionLang()
        refresh()
        m.list.jumpToItem = idx
    else if r.kind = "capStyle"
        showCaptionStyleInfo()
    else if r.kind = "setPin"
        showPinDialog("Set a 4-digit PIN", "setNew")
    else if r.kind = "changePin"
        showPinDialog("Enter current PIN", "changeVerify")
    else if r.kind = "parentalMode"
        if ParentalMode() = "hide" then SetParentalMode("pin") else SetParentalMode("hide")
        refresh()
        m.list.jumpToItem = idx
    else if r.kind = "adultCats"
        ' Turning it OFF is a safety move and costs nothing. Turning it ON
        ' asks for the PIN, so it can only be done by whoever set it.
        if AdultCatsAllowed()
            SetAdultCatsAllowed(false)
            refresh()
            m.list.jumpToItem = idx
        else
            showPinDialog("Enter your PIN to show adult categories", "adultVerify")
        end if
    else if r.kind = "removePin"
        showPinDialog("Enter current PIN", "removeVerify")
    else if r.kind = "clearResume"
        confirmAction("Clear all resume points?", "clearResume")
    else if r.kind = "unhideChans"
        confirmAction("Unhide all channels?", "unhideChans")
    else if r.kind = "clearTv"
        confirmAction(cleanSlatePrompt(), "clearTv")
    else if r.kind = "exportLogs"
        exportLogs(idx)
    else if r.kind = "updateCheck"
        checkForUpdates(idx)
    else if r.kind = "discord"
        showAddressDialog("Join us on Discord", m.branding.discordUrl)
    else if r.kind = "telegram"
        showAddressDialog("Join us on Telegram", m.branding.telegramUrl)
    end if
end sub

' ---- Refresh channel list ---------------------------------------------------
' Going back to every source and asking for its lineup again.
'
' WHAT IT ACTUALLY DOES, per kind of source, because they are not the same:
'   M3U / USB   the playlist is downloaded and parsed again and the result
'               REPLACES what the app is running on for the rest of the
'               session. This is the one that can do damage, and the one the
'               shrink guard is for.
'   Xtream /    nothing on this box stores their channels — every screen
'   KwickTV     fetches the lineup from the panel as it opens — so what goes
'               stale is the category list. One small get_live_categories
'               each, which also freshens the id->name cache the parental
'               locks and the hide/reorder lists are translated through.
'
' ONE REQUEST PER SOURCE PER PRESS. Not per row, not per tile, not per
' category — that is the shape that got this house's provider access banned
' in August 2026. On top of that: one refresh in flight at a time (the row
' refuses while it says "Refreshing..."), and five minutes between refreshes
' (ChannelRefreshCooldownSecs in Store.brs), stamped whether the refresh
' worked or not. A refusal SAYS SO — "already up to date, try again in 4
' minutes" — because a button that silently does nothing gets pressed
' harder.
'
' THE SHRINK GUARD IS ANDROID'S, and the reason it exists is in
' refresh_guard_dialog.dart: a provider having a bad minute can hand back
' eleven channels where the member had thirty-one thousand, and without a
' guard the good lineup is replaced by the junk one. The numbers live in
' Store.brs (IsDestructiveChannelShrink) so the two apps cannot drift. The
' member is still given the way through, for the rare case where a package
' genuinely shrank — but nothing is applied until they say so, which is the
' same principle as the resume rule: do not throw away what somebody has
' unless they chose to.

sub startChannelRefresh(idx as integer)
    if m.chanRefreshState = "Refreshing..." then return
    providers = LoadProviders()
    if providers.count() = 0 then return

    m.chanRefreshIdx = idx

    remaining = ChannelRefreshSecsRemaining()
    if remaining > 0
        m.chanRefreshState = "Already up to date"
        refresh()
        m.list.jumpToItem = idx
        chanRefreshDialog("Your channel list is already up to date", "It was refreshed a few minutes ago, and asking your provider over and over is the thing most likely to get your line blocked." + Chr(10) + Chr(10) + "You can refresh it again in " + plainMinutes(remaining) + ".")
        return
    end if

    SetChannelRefreshLastAt(CreateObject("roDateTime").asSeconds())
    m.chanRefreshState = "Refreshing..."
    m.chanRefreshTasks = {}
    m.chanRefreshLines = []
    m.chanRefuse = []
    m.chanRefreshOk = 0
    m.chanRefreshFail = 0
    m.chanRefreshPending = providers.count()
    ' Painted BEFORE anything is asked, so the row answers the press on this
    ' frame (certification 3.5) rather than when the network gets round to it.
    refresh()
    m.list.jumpToItem = idx

    for each p in providers
        pid = ToStr(p.id)
        if ToStr(p.ptype) = "m3u"
            task = CreateObject("roSGNode", "M3uTask")
            task.url = ToStr(p.m3uUrl)
            task.tag = pid
            task.observeField("result", "onChanRefreshM3u")
        else
            task = CreateObject("roSGNode", "ApiTask")
            task.tag = pid
            task.url = XtreamApiUrl(p, "get_live_categories")
            ' Same room the Live TV screen gives this call: several sources
            ' answer at once and the slowest is not a failure.
            task.timeoutMs = 60000
            task.observeField("result", "onChanRefreshCats")
        end if
        ' Held so nothing is collected mid-flight; dropped as each answers.
        m.chanRefreshTasks[pid] = task
        task.control = "RUN"
    end for
    KLog("settings", "channel refresh: asked " + providers.count().toStr() + " source(s), one request each")
end sub

function providerNameFor(pid as string) as string
    for each p in LoadProviders()
        if ToStr(p.id) = pid then return ToStr(p.name)
    end for
    return "This source"
end function

' The number a new playlist is measured against: what the app is running on
' now if this source has already been parsed this session, and what was
' written down at the last accepted refresh otherwise. The larger of the two,
' because the guard's job is to be hard to slip past — and because a member
' can press this row on a cold launch, before any screen has parsed anything,
' which is exactly when a guard with no baseline would wave the junk through.
function storedChannelCount(pid as string) as integer
    n = RefreshedChannelCount(pid)
    if m.global <> invalid and m.global.hasField("m3uByProv")
        slots = m.global.m3uByProv
        if slots.doesExist(pid)
            here = slots[pid].channels.count()
            if here > n then n = here
        end if
    end if
    return n
end function

sub onChanRefreshM3u(event as object)
    res = event.getData()
    pid = ToStr(event.getRoSGNode().tag)
    m.chanRefreshTasks.delete(pid)
    nm = providerNameFor(pid)
    if GetField(res, "ok") = true
        chans = ToArray(GetField(res, "channels"))
        offered = chans.count()
        stored = storedChannelCount(pid)
        if IsDestructiveChannelShrink(stored, offered)
            KLog("settings", "channel refresh: REFUSED " + pid + " - offered " + offered.toStr() + " where " + stored.toStr() + " are stored")
            m.chanRefuse.push({ pid: pid, name: nm, stored: stored, offered: offered, channels: chans, tvgUrl: ToStr(GetField(res, "tvgUrl")) })
        else
            PublishM3uParse(pid, chans, ToStr(GetField(res, "tvgUrl")))
            SetRefreshedChannelCount(pid, offered)
            m.chanRefreshOk = m.chanRefreshOk + 1
            m.chanRefreshLines.push(nm + " — " + groupedNumber(offered) + " channels")
        end if
    else
        m.chanRefreshFail = m.chanRefreshFail + 1
        m.chanRefreshLines.push(nm + " — couldn't be reached")
    end if
    chanRefreshAnswered()
end sub

sub onChanRefreshCats(event as object)
    res = event.getData()
    pid = ToStr(event.getRoSGNode().tag)
    m.chanRefreshTasks.delete(pid)
    nm = providerNameFor(pid)
    if GetField(res, "ok") = true
        cats = []
        for each c in ToArray(GetField(res, "data"))
            cid = ToStr(GetField(c, "category_id"))
            if cid <> "" then cats.push({ id: cid, name: ToStr(GetField(c, "category_name")) })
        end for
        stored = CachedCategoryCount("live", pid)
        ' Same guard, same numbers, applied to the one thing this half of the
        ' refresh overwrites. There is no "use the new list anyway" here
        ' because there is nothing of the member's to choose between — the
        ' cache is a translation table, and the honest thing to do with a
        ' panel answering nonsense is leave the good copy alone.
        if IsDestructiveChannelShrink(stored, cats.count())
            KLog("settings", "channel refresh: REFUSED categories for " + pid + " - offered " + cats.count().toStr() + " where " + stored.toStr() + " are cached")
            m.chanRefreshFail = m.chanRefreshFail + 1
            m.chanRefreshLines.push(nm + " — answered oddly, nothing changed")
        else
            SaveCatNameCacheFor("live", pid, cats)
            m.chanRefreshOk = m.chanRefreshOk + 1
            m.chanRefreshLines.push(nm + " — " + groupedNumber(cats.count()) + " categories")
        end if
    else
        m.chanRefreshFail = m.chanRefreshFail + 1
        m.chanRefreshLines.push(nm + " — couldn't be reached")
    end if
    chanRefreshAnswered()
end sub

sub chanRefreshAnswered()
    m.chanRefreshPending = m.chanRefreshPending - 1
    if m.chanRefreshPending > 0 then return

    total = m.chanRefreshOk + m.chanRefreshFail + m.chanRefuse.count()
    if m.chanRefuse.count() > 0
        m.chanRefreshState = "Needs your answer"
    else if m.chanRefreshOk = 0
        ' The value box is 276px and does not wrap — 20 characters at 23 mono
        ' — so every string this row can show is kept under that. The long
        ' version of any of them is in the dialog.
        m.chanRefreshState = "Couldn't reach it"
    else if m.chanRefreshFail > 0
        m.chanRefreshState = "Updated " + m.chanRefreshOk.toStr() + " of " + total.toStr()
    else
        m.chanRefreshState = "Up to date"
    end if
    refresh()
    m.list.jumpToItem = m.chanRefreshIdx

    if m.chanRefuse.count() > 0
        showNextChanRefusal()
        return
    end if

    body = ""
    for each ln in m.chanRefreshLines
        if body <> "" then body = body + Chr(10)
        body = body + ln
    end for
    if m.chanRefreshOk = 0
        chanRefreshDialog("Couldn't refresh", "Nothing was changed — your channels are exactly as they were." + Chr(10) + Chr(10) + body)
    else if m.chanRefreshFail > 0
        chanRefreshDialog("Partly refreshed", "Nothing was lost from the source that didn't answer." + Chr(10) + Chr(10) + body)
    else
        chanRefreshDialog("Your channel list is up to date", body)
    end if
end sub

' The answer arrives on the network's schedule, so the member may well have
' left Settings by then. A detached screen's getScene() is invalid and
' hanging a dialog off that would kill the app — the same async-teardown
' guard the Export Logs and update-check handlers make.
sub chanRefreshDialog(title as string, message as string)
    scene = m.top.getScene()
    if scene = invalid then return
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = title
    dialog.message = message
    dialog.buttons = ["OK"]
    ' House rule: a D-pad user can't click, so the primary action is focused.
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onChanRefreshDialogClosed")
    scene.dialog = dialog
end sub

sub onChanRefreshDialogClosed()
    scene = m.top.getScene()
    if scene <> invalid and scene.dialog <> invalid then scene.dialog.close = true
    m.list.setFocus(true)
end sub

' ---- The shrink guard's question --------------------------------------------
' One source at a time; two sources both collapsing in the same refresh is a
' provider having a very bad minute, and it still gets asked about one at a
' time rather than lumped into a number.

sub showNextChanRefusal()
    if m.chanRefuse.count() = 0 then return
    scene = m.top.getScene()
    if scene = invalid
        ' Left Settings while the provider was answering. Nothing was
        ' applied, so the lineup is untouched — the safe half of the guard
        ' happened on its own. Drop the held parses rather than ask a screen
        ' that is no longer there.
        m.chanRefuse = []
        return
    end if
    r = m.chanRefuse[0]
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "That refresh would have emptied most of your list"
    ' Both numbers travel deliberately: "11 where you had 31,052" is a member
    ' telling their provider something useful, where "refresh failed" is not.
    dialog.message = ToStr(r.name) + " sent back " + groupedNumber(ToInt(r.offered)) + " channels. You have " + groupedNumber(ToInt(r.stored)) + "." + Chr(10) + Chr(10) + "Your channels have been kept — nothing was deleted. This is usually a problem at the provider's end, and refreshing again in a few minutes normally fixes it." + Chr(10) + Chr(10) + "If your package really did change, you can use the new list instead."
    dialog.buttons = ["Keep my channels", "Use the new list"]
    ' The SAFE choice is the focused one: on a remote, the button under the OK
    ' key must be the one that keeps their channels.
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onChanRefusalAnswer")
    scene.dialog = dialog
end sub

sub onChanRefusalAnswer()
    scene = m.top.getScene()
    if scene = invalid then return
    dialog = scene.dialog
    if dialog = invalid then return
    useNew = (dialog.buttonSelected = 1)
    dialog.close = true
    if m.chanRefuse.count() > 0
        r = m.chanRefuse.shift()
        if useNew
            PublishM3uParse(ToStr(r.pid), r.channels, ToStr(r.tvgUrl))
            SetRefreshedChannelCount(ToStr(r.pid), ToInt(r.offered))
            m.chanRefreshState = "Using the new list"
            KLog("settings", "channel refresh: member chose the smaller list for " + ToStr(r.pid))
        else
            m.chanRefreshState = "Kept your channels"
            KLog("settings", "channel refresh: member kept their channels for " + ToStr(r.pid))
        end if
        ' A refused parse can be tens of thousands of rows. Let it go the
        ' moment it has been decided rather than carry it for the visit.
        r.channels = []
    end if
    refresh()
    m.list.jumpToItem = m.chanRefreshIdx
    if m.chanRefuse.count() > 0
        showNextChanRefusal()
        return
    end if
    m.list.setFocus(true)
end sub

' "4 minutes" / "a minute" — for a sentence, not a countdown. Deliberately the
' same shape as the guide side's own wording so the two rows sound alike.
function plainMinutes(seconds as integer) as string
    mins = Int(seconds / 60) + 1
    if mins <= 1 then return "a minute"
    return mins.toStr().trim() + " minutes"
end function

' ---- Refresh TV guide -------------------------------------------------------
' OPAL'S, not mine. GuideRefreshRequest() lives in
' source/utils/GuideRefresh.brs — which SettingsCategoryScreen.xml must list,
' or this row takes the render thread down rather than failing politely.
'
' It raises a flag and returns immediately: no network, no spinner, nothing to
' wait for. The guide is re-read the next time the member opens TV Guide or
' Live TV, through the bounded path those screens already use. So this row
' shows an answer, not a busy state — there is nothing running to be busy
' about — and the answer's own words come back from her function so the two
' halves of the feature cannot drift apart.
'
' Her side owns the one-at-a-time check and the 15-minute cooldown, and it
' keeps them in memory, so there is nothing stored on this side at all.
sub startGuideRefresh(idx as integer)
    m.guideRefreshIdx = idx
    answer = GuideRefreshRequest()
    if GetField(answer, "ok") = true
        m.guideRefreshState = "Scheduled"
    else if ToStr(GetField(answer, "code")) = "busy"
        m.guideRefreshState = "Already updating"
    else
        m.guideRefreshState = "Already up to date"
    end if
    refresh()
    m.list.jumpToItem = idx
    guideSourceResult(ToStr(GetField(answer, "title")), ToStr(GetField(answer, "message")))
end sub

' ---- Export Logs + community links (T6) -------------------------------------

sub exportLogs(idx as integer)
    if m.exportState = "Uploading..." then return
    log_ = ""
    if m.global <> invalid and m.global.hasField("diagLog") then log_ = m.global.diagLog
    if log_ = ""
        m.exportState = "Nothing to send"
        refresh()
        m.list.jumpToItem = idx
        return
    end if
    m.exportState = "Uploading..."
    refresh()
    m.list.jumpToItem = idx
    m.exportIdx = idx
    ' Identity (username + brand-led device string) comes from the shared
    ' helpers so regular exports and crash reports file identically.
    task = CreateObject("roSGNode", "ExportLogsTask")
    task.username = LogUsername()
    task.body = log_
    task.device = LogDeviceString()
    task.ver = appVersion()
    task.observeField("result", "onExportDone")
    m.exportTask = task
    task.control = "RUN"
end sub

sub onExportDone(event as object)
    res = event.getData()
    logKey = ToStr(GetField(res, "key"))
    if res <> invalid and res.ok = true
        m.exportState = "Sent - thank you!"
        ' Same as Android: hand the member their Log Key for support.
        ' The upload finishes on the network's schedule, so the member may
        ' have left Settings by now — this screen is then detached and
        ' getScene() returns invalid, which would kill the app. Skip the
        ' popup in that case. (This is the Android async-teardown class;
        ' an audit of all 31 background handlers found this one instance —
        ' see the changelog note before adding new async popups.)
        scene = m.top.getScene()
        if logKey <> "" and scene <> invalid
            dialog = CreateObject("roSGNode", "Dialog")
            dialog.title = "Logs sent!"
            dialog.message = "Give the team this Log Key when you message us — it takes them straight to your log:" + Chr(10) + Chr(10) + "        " + logKey
            dialog.buttons = ["Got it"]
            dialog.focusButton = 0
            dialog.observeField("buttonSelected", "onExportKeyClosed")
            scene.dialog = dialog
        end if
    else if res <> invalid and ToStr(GetField(res, "code")) = "cooldown"
        m.exportState = "Sent a moment ago - wait a few minutes"
    else
        m.exportState = "Couldn't send - try later"
    end if
    refresh()
    if m.exportIdx <> invalid then m.list.jumpToItem = m.exportIdx
end sub

sub onExportKeyClosed()
    m.top.getScene().dialog.close = true
    m.list.setFocus(true)
end sub

' ---- Check for updates (H9) -------------------------------------------------
' The launch-time nudge (AppScene.startUpdateCheck) speaks up only when there
' IS something newer, only once per published build, and only in the first
' seconds of a launch. Until now a member who dismissed it — or who simply
' wanted to know — had no way to ask. That matters more here than it would on
' a phone: this app is sideloaded, so nothing on the box will ever tell them
' on its own, and five of the Search memory crashes came from people still
' running a build whose fix was already published.
'
' Same task, same server file, same comparison as the nudge — UpdateCheckTask
' is reused untouched. The one real difference is that this one ALWAYS
' answers. "You're up to date" is the whole point of pressing a row called
' Check for updates, and it is the one answer the launch nudge is incapable of
' giving, because its job is to stay quiet.
'
' STORE EDITION: the row does not exist. See buildAccountRows().

sub checkForUpdates(idx as integer)
    ' One at a time. The task times out after six seconds; a member leaning on
    ' OK must not be able to stack up four of them.
    if m.updateState = "Checking..." then return
    m.updateState = "Checking..."
    m.updateIdx = idx
    ' Painted BEFORE the task starts, so the row answers the press on the same
    ' frame (certification 3.5) rather than after the network has been asked.
    refresh()
    m.list.jumpToItem = idx
    KLog("update", "on-demand check: member asked from Settings")
    task = CreateObject("roSGNode", "UpdateCheckTask")
    task.observeField("result", "onUpdateCheckAnswer")
    m.updateTask = task   ' keep a ref so the task isn't collected mid-flight
    task.control = "RUN"
end sub

sub onUpdateCheckAnswer(event as object)
    res = event.getData()
    idx = 0
    if m.updateIdx <> invalid then idx = m.updateIdx

    ' The task is deliberately silent about everything that can go wrong: no
    ' network, a server hiccup, a half-written manifest and a missing field
    ' all come back as the same { ok: false }. At launch that means say
    ' nothing. Here it cannot — the member pressed a row and is owed an
    ' answer — so a failure is named as a failure rather than quietly passed
    ' off as "up to date", which is the one thing we must never say wrongly.
    if GetField(res, "ok") <> true
        KLog("update", "on-demand check: no usable answer - telling the member so")
        m.updateState = "Couldn't check"
        finishUpdateCheck(idx, "Couldn't check", "We couldn't reach the update server just now. Check this TV's internet connection and try again in a few minutes.")
        return
    end if

    published = ToInt(GetField(res, "build"))
    mine = ToInt(CreateObject("roAppInfo").getValue("build_version"))
    label = ToStr(GetField(res, "version"))
    if published <= mine
        KLog("update", "on-demand check: build " + mine.toStr() + " is the newest published")
        m.updateState = "Up to date"
        finishUpdateCheck(idx, "You're up to date", "You have version " + appVersion() + ", which is the newest one there is.")
        return
    end if

    KLog("update", "on-demand check: build " + published.toStr() + " is published, this one is " + mine.toStr())
    m.updateState = "v" + label + " available"
    msg = "You have version " + appVersion() + ". Version " + label + " is out."
    notes = ToStr(GetField(res, "notes")).trim()
    if notes <> "" then msg = msg + Chr(10) + Chr(10) + updateNotes(notes)
    where = ToStr(GetField(res, "url")).trim()
    if where <> "" then msg = msg + Chr(10) + Chr(10) + "Get it at: " + updateAddress(where)
    ' DELIBERATELY does not call SetUpdatePromptedBuild(). That key is the
    ' launch nudge's "don't nag twice" memory, and asking once is not the same
    ' as asking to be left alone: a member who checks here and then forgets
    ' should still get the nudge next launch. For the same reason this row
    ' never READS the key either — the nudge may have been spent on this very
    ' build weeks ago, and the honest answer to "is there an update" is still
    ' yes.
    finishUpdateCheck(idx, "Update available", msg)
end sub

' The row's value column AND a dialog: the value is the lasting trace, the
' dialog is because the member is sitting in front of the TV waiting on this
' particular answer — the same call the Reset link key row makes.
'
' The answer arrives on the network's schedule, so the member may well have
' left Settings by the time it does. A detached screen's getScene() is
' invalid and hanging a dialog off that would kill the app: this is the
' async-teardown class the Export Logs handler guards against, and the note
' up there is the one to read before adding another.
sub finishUpdateCheck(idx as integer, title as string, message as string)
    refresh()
    m.list.jumpToItem = idx
    scene = m.top.getScene()
    if scene = invalid then return
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = title
    dialog.message = message
    dialog.buttons = ["OK"]
    ' House rule: a D-pad user can't click, so the primary action is focused.
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onUpdateCheckClosed")
    scene.dialog = dialog
end sub

sub onUpdateCheckClosed()
    scene = m.top.getScene()
    if scene <> invalid and scene.dialog <> invalid then scene.dialog.close = true
    m.list.setFocus(true)
end sub

' Release notes as the server wrote them, cut to something a Dialog can hold
' without pushing the address off the bottom of the box, and cut on a space so
' a word is not sliced in half. A near-copy of AppScene's shortNotes and
' plainAddress on purpose: only the scripts under source/ are shared between
' components, AppScene.brs is not one of them, and moving them out is not a
' change to make from this screen.
function updateNotes(notes as string) as string
    limit = 320
    if Len(notes) <= limit then return notes
    cut = Left(notes, limit)
    at = 0
    for i = Len(cut) to 1 step -1
        if Mid(cut, i, 1) = " "
            at = i
            exit for
        end if
    end for
    ' Only honour a break near the end — a note with no spaces at all would
    ' otherwise be cut back to almost nothing.
    if at > limit - 60 then cut = Left(cut, at - 1)
    return cut.trim() + "…"
end function

' The address as a member would type it — no scheme, no trailing slash. Roku
' has no browser, so this is something to read off the TV and type into one
' somewhere else, exactly like the Discord and Telegram rows below.
function updateAddress(url as string) as string
    s = url.trim()
    if LCase(s.left(8)) = "https://" then s = Mid(s, 9)
    if LCase(s.left(7)) = "http://" then s = Mid(s, 8)
    if s.right(1) = "/" then s = Left(s, Len(s) - 1)
    return s
end function

' Roku has no browser — show the address to type into one somewhere else.
sub showAddressDialog(title as string, address as string)
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = title
    dialog.message = "In a web browser, go to:" + Chr(10) + Chr(10) + address
    dialog.buttons = ["OK"]
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onAddressDialog")
    m.top.getScene().dialog = dialog
end sub

sub onAddressDialog()
    m.top.getScene().dialog.close = true
    m.list.setFocus(true)
end sub

' Preferred subtitle language cycles through the common set on each press.
sub cycleCaptionLang()
    ' Exactly Android's ten picker languages, so a choice made on either
    ' device always round-trips through the shared sync key.
    langs = ["eng", "spa", "fre", "ger", "ita", "por", "dut", "swe", "ara", "tur"]
    cur = PreferredCaptionLang()
    at = 0
    for i = 0 to langs.count() - 1
        if langs[i] = cur then at = i
    end for
    SetPreferredCaptionLang(langs[(at + 1) mod langs.count()])
end sub

' ---- TV Guide source (custom XMLTV per provider) ----------------------------
'
' Roku can only manage one shape of this: a link to a plain, uncompressed
' XMLTV file under 15 MB. There is no file option because a Roku channel
' cannot browse device storage or open a document picker, and no .gz support
' because Roku exposes no way to decompress one. All three are stated on the
' screen BEFORE anything is typed, rather than surfacing as an error after.

' A URL is far too long for a row label — show the host.
function guideHostOf(u as string) as string
    if u = "" then return "Off"
    host = u
    if LCase(host.left(8)) = "https://" then host = host.mid(8)
    if LCase(host.left(7)) = "http://" then host = host.mid(7)
    slash = host.instr(0, "/")
    if slash > 0 then host = host.left(slash)
    if host = "" then return "Custom guide"
    return host
end function

' A row id of "<providerId>|<index>" back into its two halves. Split on the
' FIRST bar, which is safe because a provider id can never contain one —
' AddProvider builds it out of "p" and two numbers.
function guideRowParts(id as string) as object
    at = Instr(1, id, "|")
    if at <= 0 then return { pid: id, idx: -1 }
    return { pid: Left(id, at - 1), idx: ToInt(Mid(id, at + 1)) }
end function

' ---- Guides on a source ------------------------------------------------------
' Each guide has a row and its own menu. Adding is its own row, because "add"
' and "change this one" are different things the moment there can be more than
' one of them.

sub showGuideItemMenu(rowId as string, idx as integer)
    if not AllowWebAddressEntry() then return
    parts = guideRowParts(rowId)
    guides = ProviderCustomEpgGuidesById(parts.pid)
    if parts.idx < 0 or parts.idx >= guides.count() then return
    m.guideProviderId = parts.pid
    m.guideEditIdx = parts.idx
    m.guideRowIdx = idx
    m.guideCurrentUrl = ToStr(guides[parts.idx].u)

    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Guide " + (parts.idx + 1).toStr()
    msg = m.guideCurrentUrl + Chr(10) + Chr(10) + CustomEpgCoverageLabel(guides[parts.idx]) + "."
    if guides.count() > 1
        msg = msg + Chr(10) + Chr(10) + "Guides are tried top to bottom. The first one that knows a channel fills it in, so move the one you trust most to the top."
    end if
    dialog.message = msg
    ' Buttons are built to match what this row can actually do, so no button
    ' on any dialog in this app is ever there and dead.
    btns = ["Check it now", "Change the link"]
    m.guideItemActions = ["check", "edit"]
    if parts.idx > 0
        btns.push("Move up")
        m.guideItemActions.push("up")
    end if
    if parts.idx < guides.count() - 1
        btns.push("Move down")
        m.guideItemActions.push("down")
    end if
    btns.push("Remove this guide")
    m.guideItemActions.push("remove")
    btns.push("Cancel")
    m.guideItemActions.push("cancel")
    dialog.buttons = btns
    ' House rule: a D-pad user can't click, so the primary action is focused.
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onGuideItemMenu")
    m.top.getScene().dialog = dialog
end sub

sub onGuideItemMenu()
    dialog = m.top.getScene().dialog
    choice = dialog.buttonSelected
    dialog.close = true
    if choice < 0 or choice >= m.guideItemActions.count()
        m.list.setFocus(true)
        return
    end if
    action = m.guideItemActions[choice]
    if action = "edit"
        openGuideUrlKeyboard()
        return
    else if action = "check"
        m.guideCheckUrl = m.guideCurrentUrl
        showGuideChecking()
        startGuideCheck(m.guideCurrentUrl)
        return
    else if action = "up"
        MoveProviderCustomEpgGuide(m.guideProviderId, m.guideEditIdx, -1)
    else if action = "down"
        MoveProviderCustomEpgGuide(m.guideProviderId, m.guideEditIdx, 1)
    else if action = "remove"
        RemoveProviderCustomEpgGuideAt(m.guideProviderId, m.guideEditIdx)
        KLog("guide", "custom guide removed from provider " + m.guideProviderId)
    end if
    ' Moved, or taken off: which guide fills which channel has just changed,
    ' so "your listings haven't changed" stops being true and the Refresh TV
    ' guide row must not refuse the next press. (GuideRefresh.brs)
    GuideRefreshClearCooldown()
    refresh()
    m.list.jumpToItem = m.guideRowIdx
    m.list.setFocus(true)
end sub

' The "add" row, and the explanation of what a guide has to be. Kept as a
' dialog rather than dropping straight onto the keyboard: the limits (plain
' XML, not compressed, small enough to hold) are the reason most addresses
' fail, and they have to arrive before the typing rather than after it.
sub showGuideAddMenu(providerId as string, idx as integer)
    if not AllowWebAddressEntry() then return
    m.guideProviderId = providerId
    m.guideEditIdx = -1
    m.guideRowIdx = idx
    m.guideCurrentUrl = ""
    have = ProviderCustomEpgGuidesById(providerId).count()

    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Add a TV guide"
    msg = "Point this source at an XMLTV guide of your own. Anything it doesn't cover keeps using your provider's guide."
    msg = msg + Chr(10) + Chr(10) + "It has to be a LINK to a plain XML file. It can't be a compressed .gz guide (Roku has no way to unzip one), and it has to be small enough for this Roku to hold — under 24 MB, and less than that on the smaller models."
    msg = msg + Chr(10) + Chr(10) + "You can add up to " + CustomEpgMaxGuides().toStr() + " per source, which is as many as this Roku has room to remember."
    if have > 0 then msg = msg + " This source has " + have.toStr() + "."
    msg = msg + Chr(10) + Chr(10) + "Long addresses are painful to type on a remote. If you use the Android app, you can set them there and they'll come across with KwickSync."
    dialog.message = msg
    dialog.buttons = ["Use a link", "Cancel"]
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onGuideAddMenu")
    m.top.getScene().dialog = dialog
end sub

sub onGuideAddMenu()
    dialog = m.top.getScene().dialog
    choice = dialog.buttonSelected
    dialog.close = true
    if choice = 0
        openGuideUrlKeyboard()
    else
        m.list.setFocus(true)
    end if
end sub

sub openGuideUrlKeyboard()
    if not AllowWebAddressEntry() then return
    ' Pre-filled when an existing guide is being corrected, so fixing a typo
    ' isn't a full retype on a remote. Empty when a new one is being added.
    kb = CreateObject("roSGNode", "StandardKeyboardDialog")
    kb.title = "Address of your XMLTV guide"
    kb.text = m.guideCurrentUrl
    kb.buttons = ["Save", "Cancel"]
    kb.keyboardDomain = "alphanumeric"
    edit = kb.textEditBox
    edit.voiceEnabled = true
    edit.voiceEntryType = kb.keyboardDomain
    edit.maxTextLength = 255
    kb.observeField("buttonSelected", "onGuideUrlDone")
    m.top.getScene().dialog = kb
end sub

sub onGuideUrlDone()
    kb = m.top.getScene().dialog
    save = (kb.buttonSelected = 0)
    url = StdKeyboardText(kb)
    kb.close = true
    if not save
        m.list.setFocus(true)
        return
    end if
    editing = (m.guideEditIdx >= 0)
    if url = ""
        ' An emptied address on an existing guide means "take this one off".
        ' On a new one it means nothing happened.
        if editing
            RemoveProviderCustomEpgGuideAt(m.guideProviderId, m.guideEditIdx)
            GuideRefreshClearCooldown()
            refresh()
            m.list.jumpToItem = m.guideRowIdx
            m.list.setFocus(true)
            guideSourceResult("That guide is off.", "You left the address empty, so it's been taken off this source.")
        else
            m.list.setFocus(true)
        end if
        return
    end if
    ' Caught before saving, so the reason arrives while it can still be acted
    ' on rather than as an empty guide later.
    problem = CustomEpgUrlProblem(url)
    if problem <> ""
        m.list.setFocus(true)
        guideSourceResult("That address won't work", problem)
        return
    end if

    if editing
        guides = ProviderCustomEpgGuidesById(m.guideProviderId)
        if m.guideEditIdx < guides.count()
            ' A changed address is a different guide: whatever the old one
            ' covered says nothing about this one, so the counts go with it.
            guides[m.guideEditIdx] = { u: url }
            SaveProviderCustomEpgGuides(m.guideProviderId, guides)
        end if
    else
        why = AddProviderCustomEpgGuide(m.guideProviderId, url)
        if why <> ""
            m.list.setFocus(true)
            guideSourceResult("That guide wasn't added", why)
            return
        end if
    end if
    KLog("guide", "custom guide saved for provider " + m.guideProviderId)
    GuideRefreshClearCooldown()
    refresh()
    m.list.jumpToItem = m.guideRowIdx

    ' Saving isn't the useful part — knowing whether it WORKS is. Fetch it and
    ' count how many of this source's own channels it can fill.
    m.guideCheckUrl = url
    showGuideChecking()
    startGuideCheck(url)
end sub

sub showGuideChecking()
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Checking your guide"
    dialog.message = "Looking up your channels…"
    dialog.buttons = ["Hide"]
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onGuideCheckHidden")
    m.guideDialog = dialog
    m.top.getScene().dialog = dialog
end sub

' The task reports where it's up to — downloading, then a percentage as it
' reads. A 20 MB guide takes long enough that a dialog with one fixed line
' looks like it has hung.
sub onGuideCheckProgress(event as object)
    if m.guideDialog = invalid then return
    line = ToStr(event.getData())
    if line = "" then return
    m.guideDialog.message = line
end sub

sub onGuideCheckHidden()
    m.top.getScene().dialog.close = true
    m.list.setFocus(true)
end sub

' An XMLTV file only helps if its channel ids match THIS source's channels —
' a guide for a different provider parses perfectly and yields nothing. So
' the source's channel list is fetched first purely to have something to
' match against; the file's own size proves nothing.
sub startGuideCheck(url as string)
    prov = invalid
    for each p in LoadProviders()
        if ToStr(p.id) = m.guideProviderId then prov = p
    end for
    if prov = invalid then return
    m.guideCheckProvider = prov
    if ToStr(prov.ptype) = "m3u"
        chans = []
        for each c in ToArray(m.global.m3uChannels)
            chans.push({ id: ToStr(GetField(c, "tvgId")), name: ToStr(GetField(c, "name")) })
        end for
        runGuideCheck(url, chans)
        return
    end if
    task = CreateObject("roSGNode", "ApiTask")
    task.tag = "guidechk"
    task.url = XtreamApiUrl(prov, "get_live_streams")
    task.observeField("result", "onGuideCheckChannels")
    m.guideChanTask = task
    task.control = "RUN"
end sub

sub onGuideCheckChannels(event as object)
    res = event.getData()
    chans = []
    if res <> invalid and res.ok = true
        for each s in ToArray(res.data)
            chans.push({ id: ToStr(GetField(s, "epg_channel_id")), name: ToStr(GetField(s, "name")) })
        end for
    end if
    runGuideCheck(m.guideCheckUrl, chans)
end sub

sub runGuideCheck(url as string, chans as object)
    KLog("guide", "guide check: fetching [" + url + "] against " + chans.count().toStr() + " channel(s)")
    m.guideCheckChans = chans
    task = CreateObject("roSGNode", "XmltvTask")
    task.url = url
    ' Nothing is filtered out during the read: the guide's own ids may bear
    ' no relation to this source's, and the matching happens afterwards
    ' against both ids and station names.
    task.wantedJson = "[]"
    task.observeField("progress", "onGuideCheckProgress")
    task.observeField("result", "onGuideCheckDone")
    m.guideCheckTask = task
    task.control = "RUN"
end sub

sub onGuideCheckDone(event as object)
    res = event.getData()
    KLog("guide", "guide check finished: ok=" + ToStr(GetField(res, "ok")) + " matched=" + ToStr(GetField(res, "matched")) + " inWindow=" + ToStr(GetField(res, "inWindow")) + " err=" + ToStr(GetField(res, "error")))
    m.guideDialog = invalid
    dlg = m.top.getScene().dialog
    if dlg <> invalid then dlg.close = true

    if res = invalid or res.ok <> true
        why = "It couldn't be read."
        if res <> invalid then why = plainGuideError(ToStr(GetField(res, "error")))
        guideSourceResult("That guide didn't load", why + Chr(10) + Chr(10) + "Your provider's own guide is still there — open Custom EPG again and turn it off to go back.")
        return
    end if

    inWindow = ToInt(GetField(res, "inWindow"))
    byId = GetField(res, "byId")
    aliases = GetField(res, "aliases")

    ' Count the member's CHANNELS that this guide can fill, which is the
    ' thing they care about — a programme count says nothing about whether
    ' any of it lands on a channel they have. Matched by id where the two
    ' sides agree, otherwise by station callsign / name.
    byIdHit = 0
    byName = 0
    for each c in ToArray(m.guideCheckChans)
        gid = ToStr(GetField(c, "id"))
        if gid <> "" and byId <> invalid and byId.doesExist(gid)
            byIdHit = byIdHit + 1
        else
            alt = EpgAliasLookup(aliases, ToStr(GetField(c, "name")))
            if alt <> "" and byId <> invalid and byId.doesExist(alt) then byName = byName + 1
        end if
    end for
    total = byIdHit + byName
    KLog("guide", "guide check: " + total.toStr() + " channel(s) covered (" + byIdHit.toStr() + " by id, " + byName.toStr() + " by name)")

    ' Written down against the guide, so the coverage line on its row keeps
    ' saying it. It was previously said once, in this dialog, and then lost —
    ' which meant a member with two guides had no way to tell later which of
    ' them was pulling its weight without checking both again.
    SetProviderCustomEpgCoverage(m.guideProviderId, m.guideCheckUrl, total, ToArray(m.guideCheckChans).count())
    refresh()

    if total = 0
        guideSourceResult("It didn't match any of your channels", "The guide loaded fine and has " + inWindow.toStr() + " programmes in it, but none of them line up with channels on this source — not by guide id, and not by station name either. It's most likely a guide for a different lineup. Open Custom EPG again to try another address, or turn it off to go back to your provider's own.")
    else
        extra = ""
        if byName > 0 then extra = Chr(10) + Chr(10) + "Note: " + byName.toStr() + " of those were matched on the station name because the guide numbers its channels differently to your provider."
        guideSourceResult("Guide loaded", "It covers " + total.toStr() + " of your channels, from " + inWindow.toStr() + " programmes. Every other channel keeps using your provider's own guide." + extra)
    end if
end sub

function plainGuideError(err as string) as string
    e = LCase(err)
    if e.instr(0, "too large") > -1 then return "That guide is too big for this Roku to hold. Smaller Roku models have very little memory to work with, and a guide covering many countries at once will not fit. Look for one covering just the channels you watch."
    if e.instr(0, ".gz") > -1 or e.instr(0, "compressed") > -1 then return "It's a compressed .gz file, which Roku can't unzip. Ask for the plain XML version of the same guide."
    if e.instr(0, "unreachable") > -1 then return "Nothing came back from that address. Check it for typos, and that it opens in a browser."
    if e.instr(0, "parse") > -1 then return "The file downloaded but isn't XMLTV guide data. Check the address points at the guide itself, not a web page about it."
    return "It couldn't be read."
end function

sub guideSourceResult(title as string, message as string)
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = title
    dialog.message = message
    dialog.buttons = ["OK"]
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onGuideSourceResult")
    m.top.getScene().dialog = dialog
end sub

sub onGuideSourceResult()
    m.top.getScene().dialog.close = true
    m.list.setFocus(true)
end sub

' Roku doesn't let apps change caption appearance — that's a device-wide
' accessibility setting — so point people at the right place, and explain
' the live-TV top-of-screen position while we're at it.
sub showCaptionStyleInfo()
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Caption style"
    dialog.message = "Caption text size, color, background, and opacity are set device-wide by Roku itself: press the Home button, then Settings > Accessibility > Captions style. Those settings apply to every app on this Roku, including Kwick Player." + Chr(10) + Chr(10) + "Position note: on live TV the broadcaster's caption data chooses where captions sit (news channels often place them at the top); movie and series subtitles show at the bottom."
    dialog.buttons = ["OK"]
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onCaptionStyleInfo")
    m.top.getScene().dialog = dialog
end sub

sub onCaptionStyleInfo()
    m.top.getScene().dialog.close = true
    m.list.setFocus(true)
end sub

' Cycle Default -> A-Z -> Z-A.
sub cycleSort()
    mode = ChannelSort()
    if mode = "default"
        SetChannelSort("az")
    else if mode = "az"
        SetChannelSort("za")
    else
        SetChannelSort("default")
    end if
end sub

' Merged lineup: a playlist's row offers Remove, and the KwickTV row offers
' Sign out. No Set Active anymore; everything is always on.
'
' THE KWICKTV ROW OWNS ITS OWN SIGN-OUT, in the owner's words: "in sources it
' would be easier just to have a sign out option there for kwicktv". It used
' to be a one-button "Close" that sent the member to Account & help to find
' an action with a different name on it, which was half an answer at best —
' and the thing waiting for them there removed whatever source happened to be
' active, which for a member with a playlist meant losing the playlist. Both
' halves of that are fixed: the action is here, on the row it belongs to, and
' it does the one thing its name says.
'
' The message says three things and no more: this is the account you're
' signed in with, it's what turns KwickSync on, and here is exactly what
' signing out takes off and what it leaves alone. What it must never say —
' and what an older wording said by accident — is that the app needs the
' account at all. It doesn't; an Xtream login, an M3U address or a USB
' playlist is a complete app on its own.
'
' ACCIDENT PROTECTION, which the one-button dialog used to give for free.
' Cancel is the focused button here and only here, against the house rule
' that focuses the primary action: this dialog is what a member gets for
' pressing a row to see what it IS, so OK-OK on the remote has to be a way
' out of it, not a way to lose an account. A playlist's Remove keeps the
' house rule — it is reached by the same press, but re-adding a playlist is
' a minute's work on the website and signing back in is not.
sub showSourceDialog(name as string)
    p = invalid
    for each cand in LoadProviders()
        if ToStr(cand.id) = m.actionId then p = cand
    end for
    ' Which of the two dialogs this is. Set on every open, and read by
    ' onSourceDialog below — the button counts are identical now, so the
    ' buttons themselves can no longer tell them apart.
    m.sourceIsAccount = (p <> invalid and ToStr(p.ptype) = "kwicktv")
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = name
    if m.sourceIsAccount
        dialog.message = "This is the KwickTV account you're signed in with. It's what turns on KwickSync, so your profiles, favorites and lists stay the same on your other devices." + Chr(10) + Chr(10) + signOutEffect()
        dialog.buttons = ["Sign out", "Cancel"]
        dialog.focusButton = 1
    else
        ' It used to end "Your KwickTV content is not affected", and that
        ' reassurance was wrong twice over: a member running on an Xtream
        ' playlist alone has no KwickTV content for it to be about, and the
        ' KwickTV row can never reach this branch anyway — it is the sign-out
        ' dialog above. So it only ever raised a question nobody had asked.
        ' What is left is the plain fact of what the button does.
        dialog.message = "Deleting this source will remove it from your app."
        dialog.buttons = ["Remove", "Cancel"]
        dialog.focusButton = 0
    end if
    dialog.observeField("buttonSelected", "onSourceDialog")
    m.top.getScene().dialog = dialog
end sub

sub onSourceDialog()
    dialog = m.top.getScene().dialog
    choice = dialog.buttonSelected
    dialog.close = true
    if choice <> 0
        m.list.setFocus(true)
        return
    end if
    if m.sourceIsAccount
        ' THE ACCOUNT ONLY. This is the door the owner asked for in Sources
        ' and it is deliberately the smaller of the two — the clean slate in
        ' Account & help is the one that takes the playlists as well. Both
        ' run through the same last sync, the same KwickSync backup check and
        ' the same "your data is waiting" notice, because those belong to
        ' losing the account and both doors lose it. It puts dialogs up and
        ' can route the whole app back to onboarding, so nothing follows it
        ' here — exactly as in onConfirm().
        beginSignOut()
        return
    end if
    RemoveProvider(m.actionId)
    ' Straight after the removal, so the website stops listing a playlist
    ' that is no longer on this television. Waits for nothing — what
    ' follows runs exactly as it always has, online or off. Only ever a
    ' playlist reaches this: the KwickTV login left through beginSignOut
    ' above, and the link service has never heard of it as a source anyway.
    dropSourceFromLinkService(m.actionId)
    if LoadProviders().count() = 0
        m.top.signedOut = true
    else
        refresh()
    end if
    m.list.setFocus(true)
end sub

' What signing out of the KwickTV account does to this television, in the two
' halves a member is asking about: what comes off, and what is left alone.
' Shown by the KwickTV row's dialog in Sources, and by that alone — the
' Account & help action is a different, bigger job and has its own words
' below.
'
' Only promise that favorites come back when there is a confirmed KwickSync
' backup to bring them back from; saying it otherwise would be a lie the app
' can't make good on.
function signOutEffect() as string
    lead = "Signing out takes your KwickTV account off this TV"
    if LoadProviders().count() > 1
        return lead + ". Your other sources stay exactly as they are — nothing else is removed."
    end if
    if SyncBackupIsCurrent()
        return lead + " and puts the app back to its first screen." + Chr(10) + Chr(10) + syncKeptPromise()
    end if
    return lead + " and puts the app back to its first screen."
end function

' The one sentence both dialogs use, written once. Losing the account is what
' puts the local copy at risk, both doors do it, and two wordings would
' eventually promise two different things about the same locker.
function syncKeptPromise() as string
    return "Your profiles, favorites and watch history are backed up by KwickSync and will be waiting when you sign back in."
end function

' ---- The clean slate, in the member's words ---------------------------------
' The row's name, and the first line of its confirmation, from one function so
' the button they pressed and the question they're asked can't disagree.
'
' It turns on ONE thing only — is there an account to sign out of — because
' "Sign out" has no meaning on a television that isn't signed in to anything.
' It deliberately does NOT shorten itself back to "Sign out of KwickTV" on a
' box that happens to hold nothing else: a row that renames itself as
' playlists come and go is a row a member can't learn, "clear this TV" is
' still literally true of a TV with one thing on it, and the confirmation
' underneath says plainly what is actually there.
function cleanSlateLabel() as string
    if KwickTvProvider() <> invalid then return "Sign out and clear this TV"
    return "Clear this TV"
end function

' THE HONEST PART, and the reason this action needed its own words rather than
' borrowing the sign-out's. Xtream and M3U playlists added on kwickplayer.tv
' live on the WEBSITE. Clearing this TV takes this TV's copy off and says
' nothing to the website about them, so they are not deleted and they come
' straight back — the first screen pairs on its own, so "next time you pair"
' is usually seconds later. A member not told that reads it as the clear
' having failed. USB playlists have no home on the website, so those really
' are gone, and that is the one thing here that can't be taken back.
'
' Worked out from what is on the box rather than said in general terms: a TV
' with no website playlists doesn't get a paragraph about the website, and a
' TV with no USB playlist isn't warned about losing one. It keeps a dialog
' that has a lot to say down to only the parts that are true here.
function cleanSlateEffect() as string
    fromWeb = 0
    localOnly = 0
    for each p in LoadProviders()
        ' The account isn't a playlist and gets its own half of the lead
        ' sentence below.
        if ToStr(p.ptype) <> "kwicktv"
            ' The same one question dropSourceFromLinkService asks, and the
            ' only thing that can tell the two apart: a source added on
            ' kwickplayer.tv is stored identically to one read off a USB
            ' stick, so the map behind LinkedSourceIdFor is the whole answer.
            if LinkedSourceIdFor(ToStr(p.id)) <> ""
                fromWeb = fromWeb + 1
            else
                localOnly = localOnly + 1
            end if
        end if
    end for

    if KwickTvProvider() = invalid
        out = "Every playlist comes off this TV and the app goes back to its first screen."
    else if fromWeb + localOnly > 0
        out = "Your KwickTV account and every playlist come off, and the app goes back to its first screen."
    else
        ' Nothing but the account on this box, so don't promise to take off
        ' playlists that aren't there. This is the one state where the two
        ' actions genuinely do the same thing, and it says so by saying the
        ' same thing.
        out = "Your KwickTV account comes off this TV and the app goes back to its first screen."
    end if

    if fromWeb > 0
        out = out + Chr(10) + Chr(10) + "Playlists you added on kwickplayer.tv aren't deleted. They stay on the website and come back as soon as this TV pairs again, which the first screen does on its own."
        if localOnly > 0
            out = out + " A playlist from a USB stick isn't on the website, so you'd add that one again."
        end if
    else if localOnly > 0
        out = out + Chr(10) + Chr(10) + "A playlist from a USB stick isn't saved anywhere else, so you'd add it again."
    end if

    ' The add-ons, and only when there is one to lose. This clear signs the
    ' television out of them (clearEverySource), they are NOT in the KwickSync
    ' locker, and the promise two lines below would otherwise read as covering
    ' them — so it is said plainly, before, rather than discovered after.
    addOns = addOnsSignedInText()
    if addOns <> ""
        out = out + Chr(10) + Chr(10) + "You'll also be signed out of " + addOns + ". Those aren't backed up, so you'd sign in again."
    end if

    ' Same rule as the sign-out dialog: only promise the locker when there is
    ' a confirmed backup in it. A clean slate is the moment this matters most,
    ' which is exactly why it must not be said when it isn't true.
    if KwickTvProvider() <> invalid and SyncBackupIsCurrent()
        out = out + Chr(10) + Chr(10) + syncKeptPromise()
    end if
    return out
end function

' The add-ons currently signed in, named — "Trakt", "Trakt and Simkl",
' "OpenSubtitles, Trakt and Simkl" — or "" when there are none, which is what
' keeps the sentence above off a dialog it would not be true on.
function addOnsSignedInText() as string
    names = []
    for each addOnId in AddOnIds()
        if AddOnSignedIn(addOnId) then names.push(AddOnLabel(addOnId))
    end for
    if names.count() = 0 then return ""
    if names.count() = 1 then return names[0]
    out = ""
    for i = 0 to names.count() - 1
        if i = 0
            out = names[i]
        else if i = names.count() - 1
            out = out + " and " + names[i]
        else
            out = out + ", " + names[i]
        end if
    end for
    return out
end function

function cleanSlatePrompt() as string
    return cleanSlateLabel() + "?" + Chr(10) + Chr(10) + cleanSlateEffect()
end function

sub confirmAction(message as string, action as string)
    m.pendingAction = action
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Confirm"
    dialog.message = message
    dialog.buttons = ["Yes", "Cancel"]
    ' House rule: a D-pad user can't click, so the primary action is focused.
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onConfirm")
    m.top.getScene().dialog = dialog
end sub

sub onConfirm()
    dialog = m.top.getScene().dialog
    yes = (dialog.buttonSelected = 0)
    dialog.close = true
    if yes
        if m.pendingAction = "clearKind"
            ClearHistoryKind(m.pendingKind)
            refresh()
        else if m.pendingAction = "resetChanOrder"
            ClearChannelOrder()
            refresh()
        else if m.pendingAction = "clearResume"
            ClearAllResume()
            refresh()
        else if m.pendingAction = "unhideChans"
            ClearHiddenChannels()
            refresh()
        else if m.pendingAction = "deleteList"
            DeleteList(m.actionListId)
            refresh()
        else if m.pendingAction = "clearTv"
            beginCleanSlate()
            return
        end if
    end if
    m.list.setFocus(true)
end sub

' ---- Sign out, and the clean slate ------------------------------------------
' TWO ACTIONS, ONE ENGINE. The owner's ruling split them: the KwickTV row in
' Sources signs out of the account and touches nothing else, and Account & help
' clears the whole television. They share everything that belongs to LOSING THE
' ACCOUNT — the final sync, the KwickSync backup check, the "your data was
' kept" notice, the word to the website — and differ in exactly one line, the
' playlists. So there are two ways in, one way through, and no chance of the
' careful part being written twice and drifting.
'
' SIGN OUT MEANS THE KWICKTV ACCOUNT. It is the only thing in this app anybody
' is ever signed IN to, so it is the only thing sign-out may take off.
'
' It used to remove ActiveProviderId() instead, and "active" has not chosen
' what is on screen since the merged lineup — it is whatever source was added
' or arrived last (AddProvider sets it), pinned back to the KwickTV login at
' every launch by AppScene.init. So a member who added an Xtream playlist and
' then pressed a button labelled "Sign out" silently lost the playlist and
' stayed signed in to KwickTV. In the owner's words the dialog pointing them
' at it was "like...half right lol"; the half that wasn't was destroying a
' source and calling it something else. Playlists come off through Remove on
' their own row, or all together through the clean slate, which is named for
' doing exactly that.
'
' Account data (profiles, favorites, recents, history) carries no provider id,
' so if it survives a full sign-out it reappears against whatever source is
' connected next — offering items that only existed in the old catalogue.
' It is cleared only when KwickSync is confirmed to hold a copy; otherwise the
' local copy is the only copy and is kept.

' Sources > the KwickTV row. The account and nothing else.
sub beginSignOut()
    ' Nothing to sign out of. This door can't reach it — the sign-out dialog
    ' only exists on the KwickTV row — but if it ever could, falling through
    ' would tell the website a source went away when none did.
    if KwickTvProvider() = invalid
        m.list.setFocus(true)
        return
    end if
    m.signOutAll = false
    ' Signing out while other sources remain leaves account data alone — a
    ' source is still connected and the data may well belong to it.
    m.signOutLast = (LoadProviders().count() <= 1)
    runSignOut()
end sub

' Account & help > Sign out and clear this TV. The account AND every playlist.
'
' m.signOutLast is TRUE here whatever is on the box, and it is not a shortcut:
' the flag has always meant "will anything be left when this finishes", and a
' clean slate leaves nothing by definition. So the account data gets the same
' one rule it has always had, applied to the same end state — cleared only
' with a confirmed KwickSync backup behind it, kept otherwise. A member on
' KwickTV plus a playlist now reaches that rule where the old Account & help
' sign-out didn't, because the old one left the playlist behind and this one
' doesn't.
sub beginCleanSlate()
    ' Nothing on the box to clear. The row isn't built in that state, and a
    ' member can't be on this screen in it either — the last source leaving
    ' routes back to onboarding — but a no-op beats reporting a change that
    ' didn't happen.
    if LoadProviders().count() = 0
        m.list.setFocus(true)
        return
    end if
    m.signOutAll = true
    m.signOutLast = true
    runSignOut()
end sub

sub runSignOut()
    m.signOutTried = false
    if not m.signOutLast
        KLog("app", "sign-out: other sources remain - account data untouched")
        finishSignOut(false)
        return
    end if
    ' SyncEligible() is "is there a KwickTV login", so a clean slate on a TV
    ' running playlists alone stops here — there is no locker to check and
    ' nothing was ever promised about one.
    if not (SyncEnabled() and SyncEligible())
        KLog("app", "sign-out: this account has no KwickSync backup - keeping local data")
        finishSignOut(false)
        return
    end if
    ' One last push so anything unsynced gets its chance at the locker, then
    ' re-check before deciding. Runs while the provider is still present —
    ' removing it first would make the final sync impossible.
    KLog("app", "sign-out: final sync before deciding whether to clear local data")
    m.signOutTried = true
    m.syncPhase = "syncing"
    m.syncTask = CreateObject("roSGNode", "SyncTask")
    m.syncTask.observeField("result", "onSignOutSync")
    m.syncTask.control = "RUN"
end sub

sub onSignOutSync()
    ok = SyncBackupIsCurrent()
    if not ok then KLog("app", "sign-out: backup NOT confirmed after final sync")
    finishSignOut(ok)
end sub

sub finishSignOut(clearData as boolean)
    if clearData
        KLog("app", "sign-out: KwickSync backup confirmed - clearing this device's copy")
        ClearAccountDataOnSignOut()
    else if m.signOutLast = true
        KLog("app", "sign-out: keeping profiles/favorites/history on this device")
    end if
    ' The KwickTV login BY NAME, not whatever happens to be active. This one
    ' line is the bug; everything above and below it was already right.
    p = KwickTvProvider()
    if p <> invalid
        RemoveProvider(ToStr(p.id))
        ' No word to the website about the source itself: a KwickTV login is
        ' not a playlist the member added on kwickplayer.tv, it has no entry
        ' in the linked-sources map, and the service has never known it by an
        ' id it could drop. It is the "builtin" instead, which is the next
        ' line. A playlist leaving through Remove still gets its drop — see
        ' onSourceDialog above.
        '
        ' The login is gone from the registry as of the RemoveProvider above,
        ' so this is the first moment the truth is "no KwickTV on this TV" —
        ' tell the website before anything else happens. Deliberately here and
        ' not a line earlier: asked before the removal it would still find the
        ' KwickTV login and cheerfully report it, which is the exact stale row
        ' this is meant to clear. (The mirror of the same rule on the way in:
        ' sign-in reports AFTER AddProvider — see OnboardScreen's finishAdd.)
        '
        ' INSIDE the guard, which is new: the clean slate can run on a
        ' television that never had a KwickTV account, and there the answer
        ' hasn't changed. Claiming a fresh pairing code to tell the service
        ' "still none" is a network round trip and a minted code for nothing.
        ReportBuiltinToLinkService()
    end if
    ' THE ONE LINE THE TWO ACTIONS DIFFER BY. Everything above belongs to
    ' losing the account and runs identically whichever row was pressed.
    if m.signOutAll = true then clearEverySource()
    if LoadProviders().count() = 0
        ' Tell the member their data was kept, but only when we actually
        ' tried to back it up and couldn't — a member who had turned
        ' KwickSync off was never promised a locker, so telling them we
        ' "couldn't reach KwickSync" would be nonsense.
        if m.signOutTried = true and not clearData and showSignOutKeptNotice() then return
        m.top.signedOut = true
        return
    end if
    refresh()
    m.list.setFocus(true)
end sub

' Every playlist off this television, and NOT A WORD TO THE WEBSITE about any
' of them. That is the whole shape of the clean slate and it is deliberate:
'
'   the deliberate Remove on one playlist's row says "drop it" (see
'   dropSourceFromLinkService below), because the member picked that one
'   playlist out and said take it away — and the website should stop listing
'   it as being on this TV.
'
'   the clean slate says nothing at all. It clears a TELEVISION, not the
'   member's account on kwickplayer.tv. A member wiping a box before handing
'   it to someone, or starting over after a mess, has not asked to lose the
'   playlists they built up on the website, and this must never be the button
'   that destroys them. So no drop, for any of them, ever.
'
' RemoveProvider one at a time rather than a wholesale wipe, because that is
' the same call Remove, the link service and the tombstone path all use — one
' way for a source to leave this box. LoadProviders() hands back a fresh copy
' each call, so walking the snapshot while RemoveProvider rewrites the stored
' list is safe, and the last one through deletes the active-provider key.
'
' THE MAP AND THE CURSOR GO TOO, and without them the promise the dialog makes
' would be a lie. The map is the service's id for each source against the local
' id it was saved under; the cursor is the highest change number this box has
' taken. Left behind, the next poll asks only for what is NEW — and playlists
' that haven't changed on the website since are never sent again, so they would
' sit there listed on kwickplayer.tv and never come back to this TV. Cleared,
' this box asks for the member's playlists from the beginning, which is exactly
' what "come back the next time you pair" has to mean. This is local
' forgetting: nothing is sent, and the website's copy is untouched either way.
'
' AND THE ONE-SHOT ON THE END, which is what stops the clear undoing itself.
' Everything above leaves this box looking exactly like a freshly reinstalled
' one — no sources, cursor at zero, same device id — and the first screen
' this member is about to be dropped on treats a box that looks like that as
' a box getting itself back after a reinstall: it pairs on its own, the
' service resends every playlist, and the member is carried into the app with
' the lot restored having pressed nothing since Yes. The clear looked like it
' failed. So the one thing the first screen cannot work out for itself — that
' a person just asked for this — is left here for it to read exactly once.
' See OnboardScreen's init and the skip note in LinkSession.brs.
'
' It suppresses NOTHING ELSE and nothing later. The next arrival at the first
' screen restores silently again, which is the behaviour a reinstalled box
' depends on.
sub clearEverySource()
    n = 0
    for each p in LoadProviders()
        RemoveProvider(ToStr(p.id))
        n = n + 1
    end for
    ForgetEveryLinkedSource()
    ' THE ADD-ONS GO HERE AND NOWHERE ELSE. A member's OpenSubtitles or Trakt
    ' sign-in is their login on somebody else's service, so it deliberately
    ' survives the small sign-out in Sources, which is "the account, and
    ' nothing else" (the reasoning is written out over
    ' ClearAccountDataOnSignOut in Store.brs). This action is the other thing
    ' entirely: it is the one a member runs when the television is going to
    ' somebody else, and leaving a working token behind would hand a stranger
    ' their Trakt account. Unlike everything else cleared here, an add-on
    ' sign-in is NOT in the KwickSync locker and does not come back by signing
    ' back in — which is why cleanSlateEffect says so before anything happens.
    signedOutOf = 0
    for each addOnId in AddOnIds()
        if AddOnSignedIn(addOnId)
            ClearAddOnAccount(addOnId)
            signedOutOf = signedOutOf + 1
        end if
    end for
    ' The switches that govern those sign-ins go with them, signed in or not:
    ' this is the television changing hands, and a stranger must not inherit
    ' somebody's scrobbling choices or their last-synced line. Unconditional
    ' rather than inside the test above, because a member who signed out of
    ' Trakt by hand earlier in the same session has already had its keys
    ' cleared and this simply finds nothing.
    for each trackerId in TrackerIds()
        ClearTrackerSettings(trackerId)
    end for
    if m.global <> invalid then m.global.linkJustCleared = true
    KLog("app", "clear this TV: removed " + n.toStr() + " source(s) and signed out of " + signedOutOf.toStr() + " add-on(s) - the website keeps its own copies")
end sub

' Returns true if the notice was shown (sign-out continues when it closes).
function showSignOutKeptNotice() as boolean
    ' Reached from a background sync result, so this screen may already be
    ' gone — same guard as the Export Logs popup.
    scene = m.top.getScene()
    if scene = invalid then return false
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Signed out"
    dialog.message = "Couldn't reach KwickSync, so your profiles and favorites were kept on this device."
    dialog.buttons = ["OK"]
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onSignOutKeptClosed")
    scene.dialog = dialog
    return true
end function

sub onSignOutKeptClosed()
    scene = m.top.getScene()
    if scene <> invalid and scene.dialog <> invalid then scene.dialog.close = true
    m.top.signedOut = true
end sub

' ---- Telling the website a playlist was removed here -------------------------
' The owner's bug, in his words: he removed an Xtream source in the app and
' kwickplayer.tv/link still listed it as being on the TV, so he had to delete
' it on the website as well. Removal here said nothing to the service, so the
' website's "On this TV" list quietly went stale and lied.
'
' ONLY FOR PLAYLISTS THAT CAME FROM THE SERVICE. A source added on
' kwickplayer.tv is saved exactly like one added from a USB drive — that is
' deliberate, so nothing downstream can tell them apart — so the provider
' itself is no help here. What tells them apart is the map behind
' LoadLinkedSources(): the service's id for a source against the local id
' AddProvider handed back. No entry, nothing to say, and we say nothing. A
' USB playlist therefore never reaches the wire, and neither does a source
' typed in on a sideload build.
'
' The mapping is dropped whatever happens next, and BEFORE the request goes
' out: the id belongs to a source that no longer exists on this box, and an
' id like that must never be able to travel a second time.
'
' FIRE AND FORGET, in the same strong sense as the sign-out report above.
' Nothing is observed, nothing is waited on, nothing can fail out loud, and
' no dialog exists to show. Removal finishes on the very next line whether
' the service answers { ok: true }, refuses with forbidden or not_found,
' rate-limits us, takes all twelve seconds to time out, or the box has been
' off the internet since Tuesday. There is no retry: a member offline when
' they remove a playlist still has it listed on the website, and the website
' is where they can take it off.
sub dropSourceFromLinkService(localId as string)
    linkId = LinkedSourceIdFor(localId)
    ForgetLinkedSource(localId)
    if linkId = "" then return
    ' The service will not act on a drop without the secret that came back
    ' with this box's pairing code, and there is no point minting a fresh
    ' code nobody asked for just to remove something.
    secret = LinkSecret()
    if secret = "" then return
    t = CreateObject("roSGNode", "SourceLinkTask")
    ' Nothing on this path is allowed to take a removal down with it, so even
    ' the one failure that shouldn't be possible gets a way out.
    if t = invalid then return
    t.action = "drop"
    t.device = LinkDeviceId()
    t.secret = secret
    t.sourceId = linkId
    keepDropTaskAlive(t)
    KLog("link", "removed a source that came from the website - telling the link service to drop it")
    t.control = "RUN"
end sub

' The reference has to outlive this screen. Removing the last source routes
' straight back to onboarding and the shell — this screen with it — is thrown
' away a heartbeat later; a task held only in this component's m would be
' collected mid-request. The global node lasts as long as the app does, which
' is longer than any twelve-second request.
'
' A LIST rather than the single slot the sign-out report uses, and for a
' reason: sign-out happens once, but removing three playlists is three
' presses of Remove in a row and can easily be done inside twelve seconds. A
' single slot would drop the previous task's only reference each time, which
' is precisely the stale row this whole thing exists to stop. Tasks that have
' finished are swept out on the way past, so the list can't grow forever.
' (addFields refuses to overwrite a field that already exists, hence the two
' ways in.)
sub keepDropTaskAlive(t as object)
    running = []
    if m.global.hasField("linkDropTasks")
        for each old in m.global.linkDropTasks
            if old <> invalid and ToStr(old.state) <> "done" and ToStr(old.state) <> "stop"
                running.push(old)
            end if
        end for
    end if
    running.push(t)
    if m.global.hasField("linkDropTasks")
        m.global.linkDropTasks = running
    else
        m.global.addFields({ linkDropTasks: running })
    end if
end sub

sub onReorderClosed()
    if m.reorder <> invalid
        m.top.getScene().removeChild(m.reorder)
        m.reorder = invalid
    end if
    ' Shared by every sub-screen this file opens, and they all change
    ' something a row's right-hand column reads out — how many channels are
    ' hidden, how much history is left, how many favorites there are. Rebuild
    ' rather than come back to a stale number.
    keep = m.list.itemFocused
    refresh()
    if keep >= 0 and keep < m.rows.count() then m.list.jumpToItem = keep
    m.list.setFocus(true)
end sub

' ---- Add a source (store edition) --------------------------------------
' Store edition only. The pairing screen gets a code, shows it with a QR, and
' saves whatever the member adds on kwickplayer.tv — by the time it closes,
' any new sources are already in the list, so this just rebuilds the rows.

sub openSourceLink()
    m.linkScreen = m.top.getScene().createChild("SourceLinkScreen")
    m.linkScreen.observeField("closed", "onSourceLinkClosed")
    m.linkScreen.setFocus(true)
end sub

sub onSourceLinkClosed()
    if m.linkScreen <> invalid
        m.top.getScene().removeChild(m.linkScreen)
        m.linkScreen = invalid
    end if
    refresh()
    ' The key line too. Every pairing claim caches this box's key, so the
    ' member who just paired for the very first time walks back into Sources
    ' with a key that wasn't there when this screen opened — and
    ' initDeviceKey() only runs once, on the first build of the rows, which
    ' is why the line stayed blank until the app was quit and relaunched. A
    ' registry read, no network, and it moves nothing: the slot below the
    ' description was reserved when the screen opened whether or not there
    ' was a key for it. Says nothing when there still isn't one (backed out
    ' without pairing), and leaves it covered up unless the member had
    ' already pressed * — coming back from pairing is not somebody asking to
    ' see it.
    drawDeviceKey()
    m.list.setFocus(true)
end sub

' ---- Add a playlist from a USB drive (store edition) ------------------------
' Store edition only, and it goes STRAIGHT to the file picker — there is no
' tab to pick first, because a row that says USB should open USB. The
' playlist is read before it is saved, so a file that turns out not to be a
' playlist says so here instead of quietly becoming a source with nothing in
' it. Same two steps the Connect Your Provider screen takes, in the same
' order, so a drive playlist added here is stored identically to one added
' there.

sub openAddMediaServer()
    scr = m.top.getScene().createChild("AddMediaServerScreen")
    scr.observeField("closed", "onAddMediaServerClosed")
    scr.setFocus(true)
    m.mediaServerScreen = scr
end sub

sub onAddMediaServerClosed()
    if m.mediaServerScreen = invalid then return
    added = (m.mediaServerScreen.added = true)
    m.top.getScene().removeChild(m.mediaServerScreen)
    m.mediaServerScreen = invalid
    ' A new source changes the list this screen is drawing, so rebuild it
    ' rather than just handing focus back to a stale row set.
    if added then refresh()
    m.list.setFocus(true)
end sub

sub openUsbPicker()
    br = m.top.getScene().createChild("UsbBrowserScreen")
    br.observeField("closed", "onUsbPickerClosed")
    br.setFocus(true)
    m.usbBrowser = br
end sub

sub onUsbPickerClosed()
    if m.usbBrowser = invalid then return
    picked = ToStr(m.usbBrowser.chosen)
    m.top.getScene().removeChild(m.usbBrowser)
    m.usbBrowser = invalid
    if picked = ""
        m.list.setFocus(true)
        return
    end if
    m.usbPath = picked
    ' M3uTask reads files as well as web addresses, and a channel count is
    ' proof enough that this is a playlist.
    t = CreateObject("roSGNode", "M3uTask")
    t.url = picked
    t.observeField("result", "onUsbPlaylistChecked")
    m.usbTask = t
    t.control = "RUN"
end sub

sub onUsbPlaylistChecked(event as object)
    m.usbTask = invalid
    ' Reading a big playlist takes a moment, and the member can be out of
    ' Settings by the time it finishes — a detached screen has no scene to
    ' put a dialog on (same guard as the Export Logs popup).
    scene = m.top.getScene()
    if scene = invalid then return
    res = event.getData()
    if res = invalid
        showUsbError("Something went wrong reading that file — try again.")
        return
    end if
    if res.ok <> true
        if ToStr(res.error) = "playlist file missing"
            showUsbError("That file isn't there any more — is the drive still plugged in?")
        else
            showUsbError("That doesn't look like an M3U playlist.")
        end if
        return
    end if
    if ToArray(res.channels).count() = 0
        showUsbError("That playlist has no channels in it.")
        return
    end if
    ' Built field for field the way the Connect Your Provider screen's
    ' finishAdd() builds one, dot assignment and all.
    provider = { id: "", ptype: "m3u", name: LocalPathLabel(m.usbPath) }
    provider.m3uUrl = m.usbPath
    provider.epgUrl = ""
    AddProvider(provider)
    refresh()
    m.list.setFocus(true)
end sub

sub showUsbError(msg as string)
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Can't use that playlist"
    dialog.message = msg
    dialog.buttons = ["OK"]
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onUsbErrorClosed")
    m.top.getScene().dialog = dialog
end sub

sub onUsbErrorClosed()
    m.top.getScene().dialog.close = true
    m.list.setFocus(true)
end sub

sub showListDialog(name as string)
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = name
    dialog.buttons = ["Toggle Home Row", "Rename", "Delete", "Cancel"]
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onListDialog")
    m.top.getScene().dialog = dialog
end sub

sub onListDialog()
    dialog = m.top.getScene().dialog
    choice = dialog.buttonSelected
    if choice = 0
        dialog.close = true
        ToggleListHomeRow(m.actionListId)
        refresh()
        m.list.setFocus(true)
    else if choice = 1
        dialog.close = true
        kb = CreateObject("roSGNode", "StandardKeyboardDialog")
        kb.title = "Rename list"
        kb.text = ""
        kb.buttons = ["Rename", "Cancel"]
        kb.keyboardDomain = "generic"
        edit = kb.textEditBox
        edit.voiceEnabled = true
        edit.voiceEntryType = kb.keyboardDomain
        edit.maxTextLength = 255
        kb.observeField("buttonSelected", "onRenameList")
        m.top.getScene().dialog = kb
    else if choice = 2
        dialog.close = true
        confirmAction("Delete this list?", "deleteList")
    else
        dialog.close = true
        m.list.setFocus(true)
    end if
end sub

sub onRenameList()
    kb = m.top.getScene().dialog
    name = StdKeyboardText(kb)
    if kb.buttonSelected = 0 and name <> "" then RenameList(m.actionListId, name)
    kb.close = true
    refresh()
    m.list.setFocus(true)
end sub

' ---- Parental PIN flow (Set / Change / Turn off) ----------------------------
' Sequential PinDialog overlays driven by m.pinStage:
'   setNew        store the entered value as the PIN
'   changeVerify  verify current PIN, then ask for a new one
'   removeVerify  verify current PIN, then clear PIN + all locks

sub showPinDialog(title as string, stage as string)
    m.pinStage = stage
    kb = CreateObject("roSGNode", "PinDialog")
    kb.title = title
    kb.observeField("accepted", "onSettingsPin")
    kb.observeField("cancelled", "onSettingsPinCancel")
    m.pinDialog = kb
    ' The scene's dialog slot, not a child — see PinDialog.
    m.top.getScene().dialog = kb
end sub

sub removeSettingsPin()
    if m.pinDialog <> invalid
        m.pinDialog.close = true
        m.pinDialog = invalid
    end if
end sub

sub onSettingsPin()
    entered = m.pinDialog.value
    stage = m.pinStage
    removeSettingsPin()
    if stage = "setNew"
        SetParentalPin(entered)
        refresh()
        m.list.setFocus(true)
    else if stage = "changeVerify"
        if CheckParentalPin(entered)
            showPinDialog("Enter new PIN", "setNew")
        else
            pinError()
        end if
    else if stage = "adultVerify"
        if CheckParentalPin(entered)
            SetAdultCatsAllowed(true)
            refresh()
            m.list.setFocus(true)
        else
            pinError()
        end if
    else if stage = "removeVerify"
        if CheckParentalPin(entered)
            SetParentalPin("")
            ClearAllLocks()
            SetParentalUnlocked(false)
            ' No PIN, no adult categories — the permission goes with the
            ' PIN that granted it rather than lying in wait for the next one.
            SetAdultCatsAllowed(false)
            refresh()
            m.list.setFocus(true)
        else
            pinError()
        end if
    end if
end sub

sub onSettingsPinCancel()
    removeSettingsPin()
    m.list.setFocus(true)
end sub

sub pinError()
    note = CreateObject("roSGNode", "Dialog")
    note.title = "Incorrect PIN"
    note.buttons = ["OK"]
    note.focusButton = 0
    note.observeField("buttonSelected", "onPinErrorClosed")
    m.top.getScene().dialog = note
end sub

sub onPinErrorClosed()
    m.top.getScene().dialog.close = true
    m.list.setFocus(true)
end sub

sub showAddDialog()
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Add another source"
    dialog.message = "This opens the Connect Your Provider screen. Your current sources stay saved."
    dialog.buttons = ["Continue", "Cancel"]
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onAddDialog")
    m.top.getScene().dialog = dialog
end sub

' Sign in with KwickTV, for a member who set this TV up without one.
'
' There is exactly ONE KwickTV sign-in in this app and this is not a second
' one: what "Continue" does is put the first screen back up, and the first
' screen's left half IS the sign-in — the same two fields, the same Roku
' voice keyboard (certification 4.12), the same check against the panel, the
' same finishAdd() and the same AddProvider() call. Nothing about signing in
' is written twice, and nothing about it can drift.
'
' The route is the one the sideload edition's "Add another source" row has
' always used: `signedOut` is what this screen says to be shown the first
' screen again. It is a poor name for what it does — nobody is signed out
' by it — but it is the established way back and giving the same journey a
' second mechanism would be worse than the name.
'
' AND NOTHING IS LOST ON THE WAY. Going back to the first screen removes the
' shell and nothing else: the sources are in the registry and are not touched
' by any of it, the first screen ADDS to them (AddProvider appends to
' LoadProviders() and saves the lot back), and Back on that screen comes
' straight home again because there are already sources here. The message
' below says so plainly, because this is the exact fear that made members ask
' the owner about it.
sub showKwickTvSignIn()
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Sign in with KwickTV"
    dialog.message = "This opens the sign-in screen, where you enter your KwickTV username and password." + Chr(10) + Chr(10) + "Your current sources stay exactly as they are — KwickTV is added alongside them."
    dialog.buttons = ["Continue", "Cancel"]
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onAddDialog")
    m.top.getScene().dialog = dialog
end sub

sub onAddDialog()
    dialog = m.top.getScene().dialog
    choice = dialog.buttonSelected
    dialog.close = true
    if choice = 0 then m.top.signedOut = true
    m.list.setFocus(true)
end sub

' ---- Input ------------------------------------------------------------------

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back" or key = "left"
        m.top.closed = true
        return true
    else if key = "options"
        ' Show or hide this TV's key. Falls through on any category or build
        ' that has no key to show, so * keeps doing whatever it did before
        ' there. Hidden again on the way out for free: this screen is thrown
        ' away when it closes, so the next visit starts covered up.
        if m.top.category <> "sources" then return false
        if AllowWebAddressEntry() or LinkDeviceKey() = "" then return false
        m.deviceKeyShown = not m.deviceKeyShown
        drawDeviceKey()
        ' Somebody is about to copy this onto a phone: make sure it's the
        ' key the service would recognise, not just the one we remember.
        if m.deviceKeyShown then refreshDeviceKey()
        return true
    end if
    return false
end function
