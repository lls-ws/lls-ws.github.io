' TV Guide timeline grid — the Roku port of the Android guide engine,
' carrying its hard-won rules: the cursor is a (row, time) pair so Up/Down
' never shifts the timeline sideways; horizontal reveal only ever exposes
' the START of a show; scrolling snaps to clean half-hour steps.
'
' Geometry (FHD, inside the 1810px content area):
'   logo column 200px · timeline 6px/min (180px per half hour)
'   8 visible rows of 100px (+8 gap) · 12h window from the previous half-hour

sub init()
    m.theme = KwickTheme()

    header = m.top.findNode("header")
    header.text = "TV Guide"
    header.font = UiBoldFont(42)
    header.color = m.theme.textPrimary

    m.emptyLabel = m.top.findNode("emptyLabel")
    ' 26 -> 24: JetBrains Mono is a flat 0.6em advance against Roboto-Medium's
    ' ~0.5em, so the same sentence needs ~20% more room. This label wraps to
    ' three lines inside 1600px and the longest string (the "no channel
    ' matches" hint, which also echoes what the member typed) was using most
    ' of them already.
    m.emptyLabel.font = UiFont(24)
    m.emptyLabel.color = m.theme.textSecondary

    ' --- Grid constants ---
    m.pxPerMin = 6
    m.slotPx = 180              ' 30 min
    m.logoW = 200
    m.gridX = 220               ' timeline left edge (after logo column)
    m.gridW = 1590              ' visible timeline width
    m.rowH = 100
    m.rowGap = 8
    m.visibleRows = 8
    m.gridTop = 200             ' y of rowsGroup; grows when the sub-menu shows
    m.gridBottom = 1064         ' last usable pixel row of the grid area

    ' 12h window starting at the previous half-hour, same as Android.
    nowDt = CreateObject("roDateTime")
    nowSecs = nowDt.asSeconds()
    m.windowStart = nowSecs - (nowSecs mod 1800)
    m.windowEnd = m.windowStart + 12 * 3600

    ' --- State ---
    ' The guide covers EVERY source at once (merged lineup): categories from
    ' all of them classify into the same tabs, and a channel's listings come
    ' from its OWN source's panel. The caps that keep this alive on small
    ' Rokus are unchanged and now count across all sources together: 150
    ' channels per tab, 6 requests in flight, one XMLTV guide in memory.
    ' Media servers carry no channels and no EPG - see LiveProviders().
    m.sources = LiveProviders()
    m.provider = ActiveProvider()   ' the primary (KwickTV) — account-level calls
    m.multi = (m.sources.count() > 1)
    m.srcLabels = {}
    ' --- The member's own guides ---------------------------------------------
    ' A source can now be pointed at SEVERAL guides, in an order the member
    ' set in Settings (Store.brs: ProviderCustomEpgGuides). They are read one
    ' after another and merged, EARLIER WINS: the first guide that can name a
    ' channel keeps it and the later ones pass over it. That is the same
    ' bargain the phone strikes, and it is what makes the order in Settings
    ' mean something.
    '
    ' A guide of the member's own overrides BOTH source types: it replaces the
    ' playlist's url-tvg for an M3U source, and it is preferred over the
    ' panel's per-channel EPG for an Xtream one — but only for the channels it
    ' actually covers. Everything it doesn't name still falls back to the
    ' provider's own guide, which is what "the provider's guide is always
    ' last" means here (see applyXmltvToChannels and ensureEpg).
    '
    ' m.epgChain is that reading order, flattened across every source:
    '   [{ url, provIds: [providerId...], names: "Source A" }]
    ' The SAME address set on two sources is downloaded ONCE and its coverage
    ' written back to both records — one guide file, not two of the same.
    m.epgChain = []
    chainByUrl = {}
    for each p in m.sources
        tok = SrcTokenFor(p)
        m.srcLabels[tok] = ToStr(p.name)
        pid = ToStr(p.id)
        for each g in ProviderCustomEpgGuides(p)
            u = ToStr(GetField(g, "u")).trim()
            if u <> ""
                lk = LCase(u)
                if chainByUrl.doesExist(lk)
                    chainByUrl[lk].provIds.push(pid)
                    chainByUrl[lk].names = chainByUrl[lk].names + ", " + ToStr(p.name)
                else
                    e = { url: u, provIds: [pid], names: ToStr(p.name) }
                    chainByUrl[lk] = e
                    m.epgChain.push(e)
                end if
            end if
        end for
    end for
    ' Chain bookkeeping — see startGuideXmltv.
    m.epgChainIdx = 0
    m.epgChainRunning = false
    m.epgChainOk = 0
    m.epgMergedById = {}
    m.epgMergedAliases = {}
    m.epgMergedProgrammes = 0
    m.epgWantedJson = "[]"
    m.xmltvTask = invalid
    m.buckets = []              ' [{name, catRefs:[{provId, ptype, catId, name, src}]}]
    m.bucketIdx = 0
    ' THE TAB STRIP'S STATE IS BORN HERE, NOT IN buildTabs(). This is R4, and
    ' it is the whole of it. Roku App Health, pulled 2026-09-21 for the seven
    ' days before: onKeyEvent 4x on v1.0.38 (line 2621, two devices), 1x on
    ' v1.0.37 (2580), 5x on v1.0.36 (2444, one device), 1x on v1.0.34 (2443),
    ' and redrawTabs 4x on v1.0.36 (line 1719) - 15 of that week's 31 field
    ' crashes, all on this one screen, all real members.
    '
    ' buildTabs() was the ONLY place m.tabNodes and m.tabFocus were ever
    ' created, and it does not run until the categories have come back and
    ' merged: a network round trip at best, the 6s paint timer normally, up to
    ' the 60s category deadline on a slow panel - and NEVER at all on a box
    ' with no sources (loadCategoriesInner returns on its first line) or if
    ' mergeGuideCategories falls into its own guard. The shell focuses this
    ' screen the moment init() returns, and m.focusArea is already "tabs", so
    ' every D-pad press inside that window reached m.tabNodes.count(): a dot
    ' operator on invalid, which is EXIT_BRIGHTSCRIPT_CRASH. Right/Left/OK hit
    ' it in onKeyEvent's own arithmetic; Up, Down and * hit it one frame
    ' deeper inside redrawTabs. Two dashboard entries, one cause.
    '
    ' An empty array and a zero turn every one of those presses into a
    ' harmless no-op - redrawTabs loops 0 to -1, Right finds nothing to its
    ' right, OK finds the tab it is already on - and Left still walks out to
    ' the sidebar, so nobody is ever stuck on a guide that is still loading.
    ' buildTabs() overwrites both when the real tabs exist, unchanged.
    m.tabNodes = []             ' [{lbl, underline, x, w}] - built by buildTabs()
    m.tabFocus = 0
    m.channels = []             ' channels of the active bucket
    ' Parental locks. m.catLocked marks the raw categories that are behind
    ' the PIN (lock mode "pin" — in "hide" mode they never got this far);
    ' m.chanLocked is the same flag per ROW, rebuilt alongside m.channels.
    '
    ' Why a parallel array and not a flag on the channel: M3U channels are
    ' pushed by REFERENCE out of the shared session cache, so writing a
    ' `locked` field onto them would scribble on every other screen's copy.
    m.catLocked = {}            ' "provId|catId" -> true
    m.chanLocked = []           ' index-aligned with m.channels
    m.epgCache = {}             ' streamId -> [{title, startS, stopS}]
    m.epgPending = {}
    m.inflight = {}
    m.topRow = 0
    m.cursorRow = 0
    m.cursorTime = nowSecs
    m.hOffset = 0
    m.focusArea = "tabs"        ' "filter" | "tabs" | "subtabs" | "grid"
    m.player = invalid
    m.detail = invalid          ' the channel page, while it is open
    m.dialogProgramme = invalid

    ' --- Channel-name filter -------------------------------------------------
    ' Typed (or spoken) into Roku's own keyboard dialog and applied to the
    ' channels this tab has ALREADY loaded — the same thing Android's guide
    ' does with its search field. It never starts a request and never reads
    ' the registry, so it can't blow the 150-channel cap, can't add a fetch to
    ' a tab holding 211 raw groups, and can't take a second parental snapshot.
    ' See rebuildChannelList for where it is actually applied, and
    ' showBucketEmptyState for what it says when nothing matches.
    m.query = ""
    m.queryLc = ""              ' lowercased once, not per row
    m.kbDialog = invalid        ' the open keyboard dialog, or invalid
    m.kbEdit = invalid          ' its text box — what the microphone writes into
    m.kbHasClear = false        ' is "Show all" one of its buttons this time?
    m.pendingSet = false        ' a new query is waiting for the dialog to close
    m.pendingQuery = ""

    ' --- Sub-menu (the sources' raw groups inside the selected tab) ---
    m.subStripOn = false        ' this tab holds more than one raw group
    m.subGroups = []            ' [{label, id}] — "All" is always index 0
    m.subNodes = []
    m.subIdx = 0                ' selected entry (0 = All)
    m.subFocus = 0              ' focused entry while focusArea = "subtabs"
    m.subScroll = 0             ' px the strip is slid left
    m.catQueue = []             ' raw categories still waiting to be fetched
    m.catActive = 0             ' requests in flight (Roku aborts above 100)
    m.catOrder = []             ' the categories of this load, in provider order
    m.catResults = {}           ' catId -> its channels, assembled in catOrder
    ' Bumped on every channel load. Answers carry it so a load started for
    ' the previous tab OR the previous sub-group can be thrown away — the
    ' bucket index alone can't tell those apart.
    m.loadGen = 0
    ' Progressive load: painted once the first sources are in, userMoved
    ' once the member touches anything (see mergeGuideCategories).
    m.painted = false
    m.userMoved = false
    m.paintTimer = invalid

    m.spinner = m.top.findNode("spinner")
    m.spinner.poster.uri = "pkg:/images/spinner.png"

    ' The "now" marker: one Group holding a bright core, a soft glow either
    ' side of it and the arrow at its top (the stack and its sizes are
    ' commented in GuideScreen.xml). Only the colours are set here; where it
    ' sits is updateNowLine's job and how tall it is is setNowLineHeight's.
    m.nowLine = m.top.findNode("nowLine")

    ' THE CORE IS NOT THE LIVE RED — it is the live red lifted 42% toward
    ' white, which is what makes the line read as something giving off light
    ' instead of something painted on. The glow either side is the pure live
    ' red, so the hue is still the LIVE badge's own; the lift only touches the
    ' 3px filament in the middle. 42% is the number Mason approved on the
    ' Windows preview. That build drops the lift on its two LIGHT themes
    ' because a near-white core disappears on a pale grid — this app has ONE
    ' theme and it is dark (Nord Shell, see Theme.brs), so there is nothing to
    ' branch on here. If a light theme is ever added, this is the line that
    ' has to learn about it.
    nowCore = ColorLiftToWhite(m.theme.liveBadge, 42)
    m.top.findNode("nowCore").color = nowCore
    ' The arrow takes the core's colour rather than the plain red so the two
    ' read as one marker where they touch.
    m.top.findNode("nowArrow").blendColor = nowCore

    ' The glow's peak opacity, where it meets the core, falling to nothing
    ' 12px out. 0x9E (62%) is enough to tint a programme cell red without
    ' making the title under it unreadable — the cells the line crosses are
    ' the ones showing what is on RIGHT NOW, which is the last text anyone
    ' wants to lose. Turn it down before you widen it if it reads as too much.
    nowGlow = ColorWithAlpha(m.theme.liveBadge, 158)
    m.nowGlowL = m.top.findNode("nowGlowL")
    m.nowGlowL.blendColor = nowGlow
    m.top.findNode("nowGlowR").blendColor = nowGlow

    ' Held so the height only has to be written in one place when the
    ' sub-menu appears and the grid gets shorter. The arrow is not in this
    ' list: it is a fixed 12px cap on the top of the line, not part of it.
    m.nowLineBars = [m.nowGlowL, m.top.findNode("nowGlowR"), m.top.findNode("nowCore")]

    ' Arriving on the guide means the last screen's lineup is not what the
    ' member is looking at any more. Cleared here, before anything is fetched,
    ' so a box with no sources — where loadCategories returns without ever
    ' reaching rebuildChannelList — leaves the player nothing to step through
    ' rather than Live TV's last folder. See publishGuideLineup.
    publishGuideLineup([])
    setupFilterBar()
    loadCategories()
end sub

' ---- Data: categories -> buckets -> channels --------------------------------

' Categories from every source, in parallel; the buckets are built once the
' last one answers. A source that fails contributes nothing rather than
' blanking the guide.
' THE GUIDE MUST NOT TAKE THE APP DOWN. Four boxes died with
' EXIT_BRIGHTSCRIPT_CRASH within seconds of "opened GuideScreen" on v1.0.32
' (Westinghouse WR32HX2210 twice, Roku 43R4AX, Philco PTV43VA4R) - every time
' right after a source was added, restored or removed, once with 0 tabs while
' taking over a stale guide read. A crash-on-next-launch report carries no
' stack, so the exact line could not be found from the logs, and every deref
' on this path that could be checked is guarded. Rather than guess, the three
' synchronous entry points on the open path run under try/catch: a fault
' leaves the member with an empty or partial guide and a log line naming the
' file, line and function, instead of a dead app and no line at all. Remove
' the wrappers once the next report names the culprit and it is fixed.
sub loadCategories()
    try
        loadCategoriesInner()
    catch e
        KLog("guide", "crash averted in loadCategories: " + guideCrashLine(e))
        setBusy(false)
    end try
end sub

function guideCrashLine(e as object) as string
    msg = ToStr(GetField(e, "message"))
    bt = GetField(e, "backtrace")
    where = ""
    if bt <> invalid and type(bt) = "roArray" and bt.count() > 0
        top = bt[bt.count() - 1]
        where = " @ " + ToStr(GetField(top, "filename")) + ":" + ToStr(GetField(top, "line_number")) + " " + ToStr(GetField(top, "function"))
    end if
    return msg + where
end function

sub loadCategoriesInner()
    if m.sources.count() = 0 then return
    setBusy(true)
    m.catAgg = {}          ' provId -> [{catId, name}]
    m.catPending = 0
    for each p in m.sources
        pid = ToStr(p.id)
        if ToStr(p.ptype) = "m3u"
            slots = m.global.m3uByProv
            if slots.doesExist(pid)
                m.catAgg[pid] = guideM3uGroups(slots[pid].channels)
            else
                m.catPending = m.catPending + 1
                task = CreateObject("roSGNode", "M3uTask")
                task.url = p.m3uUrl
                task.tag = pid
                task.observeField("result", "onGuideM3u")
                m.inflight["cats_" + pid] = task
                task.control = "RUN"
            end if
        else
            m.catPending = m.catPending + 1
            task = CreateObject("roSGNode", "ApiTask")
            task.tag = pid
            task.url = XtreamApiUrl(p, "get_live_categories")
            ' Generous deadline: this one answer gates the WHOLE screen, and
            ' several sources now fetch at once (a playlist being read off a
            ' USB stick alongside it). At the 25s default a slow panel timed
            ' out and the guide came up holding only the other source.
            task.timeoutMs = 60000
            task.observeField("result", "onCategories")
            m.inflight["cats_" + pid] = task
            task.control = "RUN"
        end if
    end for
    if m.catPending = 0
        mergeGuideCategories()
    else
        ' DON'T HOLD THE WHOLE GUIDE FOR THE SLOWEST SOURCE. Waiting for
        ' every source to answer meant one unreachable provider left the
        ' member staring at a spinner for 30 seconds while the channels
        ' from their other sources were already in hand. Paint what has
        ' arrived after a short grace period; anything later tops it up.
        m.paintTimer = CreateObject("roSGNode", "Timer")
        m.paintTimer.duration = 6
        m.paintTimer.repeat = false
        m.paintTimer.observeField("fire", "onPaintTimer")
        m.paintTimer.control = "start"
    end if
end sub

' Grace period is up: show whatever answered rather than nothing.
' THE THREE CALLBACKS ON THE OPEN PATH RUN UNDER THE SAME GUARD as the three
' synchronous steps above. v1.0.34 wrapped loadCategories, startGuideXmltv and
' mergeGuideCategories and expected the next crash report to name its line.
' Seven reports on v1.0.34 and v1.0.36 (2026-09-12 to 14: keys F113BD, 5DA4D6,
' E80D96, B72C2B, C95C89, AFFC55 x2, 03E3C3, C308F3) died within seconds of
' "opened GuideScreen" with NO "crash averted" line - so the fault is not in
' the wrapped steps. What was left unwrapped on the render thread is exactly
' these: the category answer, the playlist answer and the paint timer, each of
' which runs after the guarded step returned. Several of those reports also
' show a source being removed or added on the website seconds before, which is
' when an answer can arrive for a source that no longer exists.
sub onPaintTimer()
    try
        onPaintTimerInner()
    catch e
        KLog("guide", "crash averted in onPaintTimer: " + guideCrashLine(e))
        setBusy(false)
    end try
end sub

sub onPaintTimerInner()
    if m.painted = true then return
    got = 0
    for each pid in m.catAgg
        if m.catAgg[pid].count() > 0 then got = got + 1
    end for
    if got = 0 then return          ' nothing to draw yet — keep waiting
    KLog("guide", "drawing with " + got.toStr() + " of " + m.sources.count().toStr() + " source(s); the rest are still answering")
    mergeGuideCategories()
end sub

' One playlist's groups, in playlist order.
function guideM3uGroups(channels as object) as object
    seen = {}
    out = []
    for each ch in channels
        g = ToStr(ch.group)
        if g = "" then g = "Uncategorized"
        if not seen.doesExist(g)
            seen[g] = true
            out.push({ catId: g, name: g })
        end if
    end for
    return out
end function

function guideProviderById(pid as string) as dynamic
    for each p in m.sources
        if ToStr(p.id) = pid then return p
    end for
    return invalid
end function

' ---- M3U flavor (T5): playlist groups -> buckets, XMLTV -> the grid ---------

sub onGuideM3u(event as object)
    try
        onGuideM3uInner(event)
    catch e
        KLog("guide", "crash averted in onGuideM3u: " + guideCrashLine(e))
        m.catPending = m.catPending - 1
        if m.catPending <= 0 then mergeGuideCategories()
    end try
end sub

sub onGuideM3uInner(event as object)
    res = event.getData()
    pid = ToStr(event.getRoSGNode().tag)
    m.inflight.delete("cats_" + pid)
    ' A source removed on the website (or in Settings) while its playlist was
    ' still being read answers here for a provider that no longer exists.
    ' Publishing that would put a dead source's channels back into the merged
    ' line-up and file its groups under an id nothing else knows. Dropped,
    ' counted as answered, and said so.
    if guideProviderById(pid) = invalid
        KLog("guide", "playlist answered for a source that is no longer here (" + pid + ") - dropped")
        m.catAgg[pid] = []
        m.catPending = m.catPending - 1
        if m.catPending <= 0 then mergeGuideCategories()
        return
    end if
    if res <> invalid and res.ok = true
        chans = ToArray(res.channels)
        PublishM3uParse(pid, chans, ToStr(GetField(res, "tvgUrl")))
        m.catAgg[pid] = guideM3uGroups(chans)
        ' This playlist's channels have just been replaced, so anything built
        ' off the old array is stale. See m3uGroupIndex().
        if m.m3uGroupIdx <> invalid then m.m3uGroupIdx.delete(pid)
    else
        m.catAgg[pid] = []
    end if
    m.catPending = m.catPending - 1
    if m.catPending <= 0 then mergeGuideCategories()
end sub

' The most programmes the merged guide is allowed to hold.
'
' XmltvTask already caps ONE guide at 12,000 programmes because that is about
' what a cheap 720p set can carry alongside the app. Three guides merged is
' three times that, and the box is killed outright (EXIT_CHANNEL_MEM_LIMIT_FG)
' rather than warned. So the CHAIN has its own ceiling: once the merge is this
' full the guides still waiting are not downloaded at all. Earlier guides win,
' which is the same rule the merge itself follows — the member's order decides
' what fits.
function GuideMaxMergedProgrammes() as integer
    return 16000
end function

' How many of the member's channels a guide's coverage figure is measured
' against. Walking every channel of a 6,555-channel service and doing a
' callsign lookup apiece is real work on the render thread, and this runs when
' a guide lands rather than on a key press — but it is bounded all the same.
' The number stored is the number actually checked, so the line under the row
' in Settings says what was really measured.
function GuideCoverageSampleMax() as integer
    return 2500
end function

' Is the box short of memory right now? XmltvTask has its own copy of this
' (it runs on a different thread and can't call into here); the chain needs
' the same answer before it starts the NEXT download.
' MEASURED, not just asked. The coarse level is all this used to read, and
' "low" arrives far too late to stop a guide chain: on the office stick - the
' ROOMIEST box we own - the app went from 4% to 32% of its limit on the first
' guide alone, and from 46% to 77% while a chain ran behind a Live TV screen.
' The device still called that "normal" the whole way.
'
' Six members on cheap boxes (Roku Express 3960X, Streaming Stick 3840X, SEMP)
' were killed with EXIT_CHANNEL_MEM_LIMIT_FG on v1.0.30 holding as little as
' 353 channels and 5% of the device - so it was never the size of their
' line-up, it was what the guide chain piled on top.
'
' THIS RUNS ON THE RENDER THREAD, where roAppMemoryMonitor reports the whole
' app honestly. (From a Task it reports only that thread - 14-17% while the app
' was really at 47-56% - which is why XmltvTask still has to use the coarse
' reading and this no longer does.)
'
' 88%, NOT 70%. The first cut used 70 and it was wrong in the other direction:
' this app legitimately sits at 61-70% on a healthy box with a couple of
' playlists and Sports loaded, so a 70% gate refused the guide on hardware
' that was perfectly fine - the owner's own Roku came back with "could not read
' your guide". Refusing a guide is refusing the feature; it is only the right
' answer when the alternative is Roku killing the app, which is what 88 means.
function guideMemoryTight() as boolean
    lvl = LCase(ToStr(CreateObject("roDeviceInfo").GetGeneralMemoryLevel()))
    if lvl = "low" or lvl = "critical" then return true
    mon = CreateObject("roAppMemoryMonitor")
    if mon = invalid then return false
    used = mon.GetMemoryLimitPercent()
    if used = invalid then return false
    return ToInt(used) >= 88
end function

' Is the box SO full that even the member's first guide cannot be attempted?
'
' Deliberately far above guideMemoryTight()'s 70%. That one decides whether to
' read ANOTHER guide; this one decides whether to read ANY, which costs the
' member the feature entirely and is only right when the alternative is Roku
' killing the app. Measured on the office stick, the first guide alone moved
' the app 4% -> 32%, so a box already at 88% has nowhere to put one.
function guideNoRoomAtAll() as boolean
    mon = CreateObject("roAppMemoryMonitor")
    if mon = invalid then return false
    used = mon.GetMemoryLimitPercent()
    if used = invalid then return false
    return ToInt(used) >= 93
end function

' A stale guide claim can be taken over - see the long note beside the Live
' TV copies of these. Duplicated rather than shared because component scripts
' do not share statics and neither screen owns a file the other includes.
function guideXmltvClaimIsStale() as boolean
    if m.global = invalid or not m.global.hasField("xmltvClaimedAt") then return false
    at = m.global.xmltvClaimedAt
    if at = invalid or at <= 0 then return false
    return (CreateObject("roDateTime").asSeconds() - at) > 960
end function

sub stampGuideXmltvClaim()
    if m.global <> invalid and m.global.hasField("xmltvClaimedAt")
        m.global.xmltvClaimedAt = CreateObject("roDateTime").asSeconds()
    end if
end sub

' Did the app give the guide back to Roku to stay alive?
'
' AppScene.shedOnMemWarning drops m.global.xmltvById on a real Roku memory
' alarm and DELIBERATELY LEAVES xmltvState alone, because this screen, Live TV
' and the channel page all watch that field and would otherwise all start
' downloading on a box that has just said it has no room. xmltvShed is how
' they are told instead, and answering it on the next open is this screen's
' half of that bargain.
'
' THE FLAG, AND NOT "the map is empty". A guide that parses perfectly but
' matches none of the member's channels ALSO leaves an empty map with the
' state reading "ready" -- XmltvTask returns ok with byId empty, the "guide
' for a different provider" case its own comment names. Re-reading on an
' empty map would mean a fresh download every single time that member opened
' the guide, for a file that is never going to match.
'
' Never true while a guide is being read: the shed refuses to run then, and
' this refuses to act on it then, so neither half can trip over a download.
function guideWasShed() as boolean
    if m.global = invalid or not m.global.hasField("xmltvShed") then return false
    if m.global.xmltvShed <> true then return false
    return LCase(ToStr(m.global.xmltvState)) <> "loading"
end function

' Start reading the member's guides, one after another.
'
' WHAT DOESN'T CHANGE, and mustn't: m.global.xmltvState still goes
' "" -> "loading" -> "ready" (or "failed") exactly once, m.global.xmltvById is
' still written exactly once, in its existing shape, and both are written only
' when the whole chain is done. LiveTvScreen, ChannelDetailScreen,
' MultiViewScreen, PlayerScreen and SportsTask all read those two, and
' ChannelDetailScreen takes a COPY of one channel's listings the moment the
' state turns ready — so a byId that kept growing after "ready" would leave
' that screen holding a half-built guide. Everything is merged first, then
' published in one go.
sub startGuideXmltv()
    try
        startGuideXmltvInner()
    catch e
        KLog("guide", "crash averted in startGuideXmltv: " + guideCrashLine(e))
        m.epgChainRunning = false
    end try
end sub

sub startGuideXmltvInner()
    ' Did the member ask for a refresh in Settings? See the twin of this block
    ' in LiveTvScreen.startXmltv — the flag is claimed by whichever guide
    ' screen opens first, so the guide stays live until there is actually
    ' something ready to replace it.
    if GuideRefreshTake()
        KLog("guide", "reading the guide again - you asked for a refresh")
        m.global.xmltvState = ""
    end if
    ' The app let the guide go on a Roku memory alarm -- see guideWasShed
    ' above. Clearing the state here, on the render thread, at the top of the
    ' one function that starts a read, puts the recovery through the SAME
    ' path a Settings refresh uses: same claim stamp, same chain, same
    ' one-at-a-time rule, same memory gates before each download. Nothing new
    ' happens at the moment of the alarm; it happens the next time the member
    ' opens this screen.
    if guideWasShed()
        KLog("guide", "the guide was let go of to keep the app alive - reading it again")
        m.global.xmltvShed = false
        m.global.xmltvState = ""
    end if
    if m.global.xmltvState = ""
        ' The chain is the member's own guides in their own order. With none
        ' set it is the playlist's url-tvg on its own, which is exactly what
        ' this screen has always read — a source with no Custom EPG behaves
        ' today the way it did yesterday.
        chain = m.epgChain
        if chain.count() = 0
            tvg = ToStr(m.global.m3uTvgUrl)
            if tvg = "" then return
            ' No provider record behind it, so no coverage line to keep.
            chain = [{ url: tvg, provIds: [], names: "your playlist" }]
        end if
        m.epgChain = chain
        wanted = []
        seen = {}
        for each c in m.global.m3uChannels
            tid = ToStr(GetField(c, "tvgId"))
            if tid <> "" and not seen.doesExist(tid)
                seen[tid] = true
                wanted.push(tid)
            end if
        end for
        ' Xtream sources have no playlist to enumerate, so with none
        ' configured this goes out as an empty list, which XmltvTask reads as
        ' "keep everything"; channels match at render time by tvg-id. Built
        ' once and reused for every guide in the chain — it describes the
        ' member's channels, not the file.
        m.epgWantedJson = FormatJson(wanted)
        m.epgChainIdx = 0
        m.epgChainOk = 0
        m.epgMergedById = {}
        m.epgMergedAliases = {}
        m.epgMergedProgrammes = 0
        m.epgChainRunning = true
        m.global.xmltvState = "loading"
        stampGuideXmltvClaim()
        KLog("guide", "reading " + chain.count().toStr() + " guide(s) of your own, one at a time")
        runNextGuide()
    else if m.global.xmltvState = "loading" and guideXmltvClaimIsStale() and not m.epgChainRunning
        ' The screen that claimed this read was torn down mid-chain. See the
        ' note on the Live TV copy of these two helpers.
        KLog("guide", "the guide read that was in progress went away - taking it over")
        m.global.xmltvState = ""
        startGuideXmltv()
    else if m.global.xmltvState = "loading"
        ' Somebody is already reading it. If that somebody is US, the chain
        ' calls applyXmltvToChannels itself when it finishes — a second way in
        ' would only repaint the grid twice.
        if m.epgChainRunning then return
        m.global.observeField("xmltvState", "onGuideXmltvState")
    end if
end sub

' ONE XmltvTask ALIVE AT A TIME. Never a task per guide: the file is held whole
' as a string while it is scanned, so three downloads at once is three files in
' memory on a box that struggles with one. The next one is only created after
' the previous has answered and been let go of.
sub runNextGuide()
    if m.epgChainIdx >= m.epgChain.count()
        finishGuideChain("all " + m.epgChain.count().toStr() + " read")
        return
    end if
    ' Guards checked BEFORE each download except the first — the first guide
    ' is the member's top choice and is always attempted, so this can never
    ' turn into "no guide at all" on a box that was already tight.
    if m.epgChainIdx > 0
        if m.epgMergedProgrammes >= GuideMaxMergedProgrammes()
            finishGuideChain("full at " + m.epgMergedProgrammes.toStr() + " programmes - the guides further down your list were not read")
            return
        end if
        if guideMemoryTight()
            finishGuideChain("stopping early - this device is running short of memory")
            return
        end if
    else if guideNoRoomAtAll()
        ' ...EXCEPT when there is genuinely no room for it, which the rule
        ' above did not cover and which is exactly how the members with ONE
        ' source were dying. With a single guide the chain never reaches index
        ' 1, so the guard above never ran for them: the app loaded whatever
        ' was left of the box into a guide and Roku killed it.
        '
        ' A much higher bar than the between-guides check on purpose. At 70%
        ' the answer is "no more guides"; only at 93% is the answer "not even
        ' your first one", because refusing that is refusing the whole feature
        ' and is only ever the right call when the alternative is a dead app.
        finishGuideChain("not enough memory on this device to read a guide right now")
        return
    end if
    e = m.epgChain[m.epgChainIdx]
    n = m.epgChainIdx + 1
    KLog("guide", "guide " + n.toStr() + " of " + m.epgChain.count().toStr() + " (" + ToStr(e.names) + ")")
    task = CreateObject("roSGNode", "XmltvTask")
    task.url = ToStr(e.url)
    task.wantedJson = m.epgWantedJson
    task.observeField("result", "onGuideXmltv")
    m.xmltvTask = task
    task.control = "RUN"
end sub

' One guide has answered — or given up. Either way the chain moves on: a guide
' that can't be reached costs the member the channels only that guide knew
' about, not the whole guide. Its coverage line in Settings is left as it was
' (a failed download is not the same as "covers none of your channels", and
' saying the latter would be a lie the member can't tell from the truth).
' THE REST OF THE GUIDE'S CALLBACKS, guarded like the first three. v1.0.37
' wrapped the category answer, the playlist answer and the paint timer - and a
' Westinghouse WR32EX2100 on v1.0.37 (key 33F2CA, 2026-09-15) still died a
' minute after "opened GuideScreen" with no "crash averted" line. A minute in
' is when the guide file, the channel lists and the listings answer, and those
' four callbacks were the unwrapped ones. Every event handler on this screen
' now reports its line instead of taking the app down.
sub onGuideXmltv(event as object)
    try
        onGuideXmltvInner(event)
    catch e
        GuardFailed("guide/onGuideXmltv", e)
        m.epgChainRunning = false
    end try
end sub

sub onGuideXmltvInner(event as object)
    res = event.getData()
    e = invalid
    if m.epgChainIdx >= 0 and m.epgChainIdx < m.epgChain.count() then e = m.epgChain[m.epgChainIdx]
    ' Let go of the finished task BEFORE the next is made, so the box is never
    ' holding two guides' worth at once.
    if m.xmltvTask <> invalid
        m.xmltvTask.unobserveField("result")
        m.xmltvTask = invalid
    end if
    if res <> invalid and res.ok = true
        mergeGuideIntoChain(res, e)
        m.epgChainOk = m.epgChainOk + 1
    else
        why = ToStr(GetField(res, "error"))
        if why = "" then why = "no answer"
        nm = "a guide"
        if e <> invalid then nm = ToStr(e.names)
        KLog("guide", "couldn't read the guide from " + nm + " (" + why + ") - carrying on with the rest")
    end if
    m.epgChainIdx = m.epgChainIdx + 1
    runNextGuide()
end sub

' FIRST WRITER WINS. A channel already named by an earlier guide is left
' exactly as that guide left it; only channels nobody has claimed yet are
' taken from this one. That is the whole point of the order in Settings, and
' it is also why the merge is cheap: it never rewrites, only fills gaps.
sub mergeGuideIntoChain(res as object, e as dynamic)
    byId = GetField(res, "byId")
    if byId = invalid then byId = {}
    added = 0
    passed = 0
    for each k in byId
        if m.epgMergedById.doesExist(k)
            passed = passed + 1
        else
            list = byId[k]
            m.epgMergedById[k] = list
            m.epgMergedProgrammes = m.epgMergedProgrammes + list.count()
            added = added + 1
        end if
    end for
    ' Callsign/name aliases follow the same rule, or a later guide could
    ' quietly re-point a name an earlier guide had already claimed.
    al = GetField(res, "aliases")
    if al <> invalid
        for each a in al
            if not m.epgMergedAliases.doesExist(a) then m.epgMergedAliases[a] = al[a]
        end for
    end if
    nm = "a guide"
    if e <> invalid then nm = ToStr(e.names)
    KLog("guide", nm + ": " + added.toStr() + " channel(s) taken, " + passed.toStr() + " already covered by an earlier guide")

    ' Coverage, so Settings' line under this guide stays current without the
    ' member having to run the checker again. Measured against THIS guide on
    ' its own, never the merge — otherwise an earlier guide's channels would
    ' be counted as this one's work.
    if e <> invalid and e.provIds.count() > 0
        sample = guideCoverageSample()
        ' Nothing to measure against yet — an Xtream-only household whose
        ' first category hasn't answered. Leave the line as it was ("Not read
        ' yet"), because "covers none of your 0 channels" reads like a verdict
        ' on the guide when it is only a verdict on the timing.
        if sample.count() > 0
            matched = 0
            for each c in sample
                if guideFileCovers(byId, al, c.tvgId, c.name) then matched = matched + 1
            end for
            for each pid in e.provIds
                SetProviderCustomEpgCoverage(ToStr(pid), ToStr(e.url), matched, sample.count())
            end for
            KLog("guide", nm + ": covers " + matched.toStr() + " of " + sample.count().toStr() + " of your channels")
        end if
    end if
end sub

' Does one guide FILE name this channel? Same two tests the grid makes
' (xmltvKeyFor) — the guide's own id first, then the station callsign or name
' — but against the file that just arrived rather than the merged guide.
function guideFileCovers(byId as object, aliases as dynamic, tvgId as string, name as string) as boolean
    if tvgId <> "" and byId.doesExist(tvgId) then return true
    if aliases <> invalid and name <> ""
        alt = EpgAliasLookup(aliases, name)
        if alt <> "" and byId.doesExist(alt) then return true
    end if
    return false
end function

' The channels a coverage figure is measured against: every playlist channel
' already parsed, plus whatever the panel has handed over so far on this tab.
'
' EVERY source, not just the one the guide is set on. A guide is matched by
' tvg-id and callsign, which say nothing about which source a channel came
' from — an uploaded guide covers matching channels wherever they are, and the
' code that uses it (xmltvKeyFor) makes no distinction either. Counting only
' one source's channels would report a number the grid doesn't act on.
function guideCoverageSample() as object
    out = []
    seen = {}
    cap = GuideCoverageSampleMax()
    slots = m.global.m3uByProv
    if slots <> invalid
        for each pid in slots
            chans = GetField(slots[pid], "channels")
            if chans <> invalid
                for each ch in ToArray(chans)
                    tid = ToStr(GetField(ch, "tvgId"))
                    nm = ToStr(GetField(ch, "name"))
                    k = LCase(tid + "|" + nm)
                    if not seen.doesExist(k)
                        seen[k] = true
                        out.push({ tvgId: tid, name: nm })
                        if out.count() >= cap then return out
                    end if
                end for
            end if
        end for
    end if
    if m.catResults <> invalid
        for each k2 in m.catResults
            for each ch in m.catResults[k2]
                tid = ToStr(GetField(ch, "tvgId"))
                nm = ToStr(GetField(ch, "name"))
                k = LCase(tid + "|" + nm)
                if not seen.doesExist(k)
                    seen[k] = true
                    out.push({ tvgId: tid, name: nm })
                    if out.count() >= cap then return out
                end if
            end for
        end for
    end if
    return out
end function

' The chain is done. THIS is the only place the shared guide is published, and
' it publishes it the way this screen always has: byId, then aliases if there
' are any, then the state flag. One write each, one transition.
sub finishGuideChain(why as string)
    m.epgChainRunning = false
    if m.epgChainOk > 0
        m.global.xmltvById = m.epgMergedById
        if m.epgMergedAliases.count() > 0 then m.global.xmltvAliases = m.epgMergedAliases
        m.global.xmltvState = "ready"
        KLog("guide", "guide ready: " + m.epgMergedById.count().toStr() + " channels, " + m.epgMergedProgrammes.toStr() + " programmes from " + m.epgChainOk.toStr() + " guide(s) - " + why)
    else if m.global.xmltvById.count() > 0
        ' A REFRESH THAT FAILED MUST NOT COST THE MEMBER THE GUIDE THEY HAD.
        ' The twin of the block in LiveTvScreen.finishLiveGuideChain, with the
        ' full reasoning; both screens have to answer this the same way or the
        ' member gets a different result depending on which screen they
        ' happened to open. xmltvById is only overwritten on the success arm
        ' above, so a non-empty map here is a re-read of a guide that had
        ' already worked. Keep it and say "ready".
        m.global.xmltvState = "ready"
        KLog("guide", "the guide couldn't be read again - keeping the " + m.global.xmltvById.count().toStr() + " channels you already had (" + why + ")")
    else
        ' Every guide in the chain failed, and there was nothing to fall back
        ' on. Same word this screen has always used, so the screens waiting on
        ' it behave as they always have: the panel's own guide answers
        ' instead.
        m.global.xmltvState = "failed"
        KLog("guide", "no guide could be read - " + why)
    end if
    ' The global holds its own copy now, so the render thread's stops costing
    ' anything.
    m.epgMergedById = {}
    m.epgMergedAliases = {}
    applyXmltvToChannels()
end sub

sub onGuideXmltvState()
    try
        onGuideXmltvStateInner()
    catch e
        GuardFailed("guide/onGuideXmltvState", e)
    end try
end sub

sub onGuideXmltvStateInner()
    if m.global.xmltvState = "loading" then return
    m.global.unobserveField("xmltvState")
    applyXmltvToChannels()
end sub

' Move the parsed guide into the per-channel cache the grid already uses.
'
' A custom guide SUPPLEMENTS the provider's, it doesn't replace it. Someone's
' own XMLTV typically covers a hundred channels out of several thousand — the
' owner's covers 113 of 6,555 — so taking the source off the panel's guide
' entirely would blank the other 6,442. Channels the custom guide knows about
' use it; every other channel is left to fall back to the panel.
sub applyXmltvToChannels()
    m.epgPending = {}
    ' Each channel follows ITS OWN source: an M3U channel has no panel to
    ' fall back to, an Xtream one does.
    isM3u = {}
    for each p in m.sources
        isM3u[SrcTokenFor(p)] = (ToStr(p.ptype) = "m3u")
    end for
    if m.global.xmltvState = "ready"
        covered = 0
        for each ch in m.channels
            key = epgKeyFor(ch)
            if xmltvCovers(ch)
                fillEpgFromXmltv(ch)
                covered = covered + 1
            else if isM3u[ToStr(GetField(ch, "src"))] = true
                m.epgCache[key] = []              ' no panel to fall back to
            else
                ' Drop any custom-guide answer so the panel is asked instead.
                m.epgCache.delete(key)
            end if
        end for
        KLog("guide", "guide file covers " + covered.toStr() + " of " + m.channels.count().toStr() + " channels on this tab; the rest use their provider's")
    else
        for each ch in m.channels
            if isM3u[ToStr(GetField(ch, "src"))] = true then m.epgCache[epgKeyFor(ch)] = []
        end for
    end if
    rebuildRows()
end sub

' Which entry in the loaded guide is this channel, or "" if it isn't in it?
' The guide's own id first; failing that the station callsign or name, since
' an uploaded guide often numbers its channels nothing like the provider
' does (see EpgAliasLookup).
function xmltvKeyFor(ch as object) as string
    if m.global.xmltvState <> "ready" then return ""
    tid = ToStr(GetField(ch, "tvgId"))
    if tid <> "" and m.global.xmltvById.doesExist(tid) then return tid
    alt = EpgAliasLookup(m.global.xmltvAliases, ToStr(GetField(ch, "name")))
    if alt <> "" and m.global.xmltvById.doesExist(alt) then return alt
    return ""
end function

function xmltvCovers(ch as object) as boolean
    return xmltvKeyFor(ch) <> ""
end function

' Listings are cached per SOURCE + channel: stream id 61 on one source and
' 61 on another are different channels, and sharing one cache slot showed
' one source's programmes against the other's channel.
function epgKeyFor(ch as object) as string
    return ToStr(GetField(ch, "src")) + "|" + ToStr(ch.streamId)
end function

sub fillEpgFromXmltv(ch as object)
    listings = []
    tid = xmltvKeyFor(ch)
    if tid <> ""
        for each p in m.global.xmltvById[tid]
            if p.stopS > m.windowStart and p.startS < m.windowEnd
                listings.push(p)
            end if
        end for
    end if
    m.epgCache[epgKeyFor(ch)] = listings
end sub

sub onCategories(event as object)
    try
        onCategoriesInner(event)
    catch e
        KLog("guide", "crash averted in onCategories: " + guideCrashLine(e))
        m.catPending = m.catPending - 1
        if m.catPending <= 0 then mergeGuideCategories()
    end try
end sub

sub onCategoriesInner(event as object)
    res = event.getData()
    pid = ToStr(event.getRoSGNode().tag)
    m.inflight.delete("cats_" + pid)
    ' Same rule as the playlist answer: a source that went away while its
    ' category list was in flight is dropped, not filed.
    if guideProviderById(pid) = invalid
        KLog("guide", "categories answered for a source that is no longer here (" + pid + ") - dropped")
        m.catAgg[pid] = []
        m.catPending = m.catPending - 1
        if m.catPending <= 0 then mergeGuideCategories()
        return
    end if
    raw = []
    cacheCats = []
    if res <> invalid and res.ok = true
        for each c in ToArray(res.data)
            cid = ToStr(GetField(c, "category_id"))
            nm = ToStr(GetField(c, "category_name"))
            raw.push({ catId: cid, name: nm })
            cacheCats.push({ id: cid, name: nm })
        end for
        ' GUARDED, AND SILENTLY — the twin of the block in
        ' LiveTvScreen.onCategories, which carries the full reasoning. Same
        ' helper as Settings' Refresh row so the rule cannot drift, no dialog
        ' because the member did not ask for anything, and only the registry
        ' write is refused: m.catAgg below still takes the list as served, so
        ' the guide draws what the provider is actually offering.
        offered = cacheCats.count()
        stored = CachedCategoryCount("live", pid)
        if IsDestructiveChannelShrink(stored, offered)
            KLog("guide", "source " + pid + " offered " + offered.toStr() + " categories where " + stored.toStr() + " are cached - keeping the cached names, nothing overwritten")
        else
            SaveCatNameCacheFor("live", pid, cacheCats)
        end if
    else
        ' A source that can't list its categories contributes nothing rather
        ' than blanking the guide — say so, or it looks like it has none.
        KLog("guide", "category list failed for source " + pid + ": " + ToStr(GetField(res, "error")))
    end if
    m.catAgg[pid] = raw
    m.catPending = m.catPending - 1
    if m.catPending <= 0 then mergeGuideCategories()
end sub

' Every source's categories, classified into the same genre tabs. A tab's
' catRefs remember which source each raw group came from, so loading it
' asks each provider for its own groups.
' Called when the last source answers, or when the grace period expires
' with only some of them in. Safe to run twice: the second run tops up the
' first with whatever arrived late.
sub mergeGuideCategories()
    try
        mergeGuideCategoriesInner()
    catch e
        KLog("guide", "crash averted in mergeGuideCategories: " + guideCrashLine(e))
        setBusy(false)
    end try
end sub

sub mergeGuideCategoriesInner()
    setBusy(false)
    if m.paintTimer <> invalid then m.paintTimer.control = "stop"
    ' A top-up after the member has started browsing would rebuild the tabs
    ' and throw them back to the first one mid-scroll. Their place on screen
    ' is worth more than a late source's categories — those show up next
    ' time the guide is opened, by which point that source is cached.
    if m.painted = true and m.userMoved = true
        KLog("guide", "a late source answered, but you're browsing - leaving the guide as it is")
        return
    end if
    m.painted = true

    byName = {}
    m.catNames = {}
    m.catLocked = {}
    allRefs = []
    ' The guide builds its own tabs and never sees ApplyCatPrefs, so every
    ' rule that list would have applied has to be applied right here: adult
    ' categories (certification 6.3), the member's hidden categories, and
    ' the parental locks. That is exactly what the shared gate does — see
    ' the parental-gate block in GuideMeta.brs.
    '
    ' Read ONCE for the whole merge, not per category: this runs over every
    ' raw group of every source (211 in "Other" alone on this service) and a
    ' registry read apiece would stall the render thread.
    gate = ParentalGate("live")
    for each p in m.sources
        pid = ToStr(p.id)
        if not m.catAgg.doesExist(pid) then continue for
        ptype = ToStr(p.ptype)
        tok = SrcTokenFor(p)
        isM3u = (ptype = "m3u")
        ppvGroups = {}
        if isM3u
            ' The whole playlist is in memory, so PPV can be spotted exactly:
            ' a group joins the PPV tab only if it really holds a PPV channel.
            ' No guessing, and no empty PPV tab for playlists carrying none.
            slots = m.global.m3uByProv
            if slots.doesExist(pid)
                for each ch in slots[pid].channels
                    if LooksPpv(ToStr(ch.name))
                        g = ToStr(ch.group)
                        if g = "" then g = "Uncategorized"
                        ppvGroups[g] = true
                    end if
                end for
            end if
        end if
        for each c in m.catAgg[pid]
            catName = ToStr(c.name)
            if catName <> ""
                ' Dropped before it is classified OR cached, so it reaches
                ' neither the Adult tab nor the All tab nor the sub-menu —
                ' and, because it never joins a tab, its channels are never
                ' fetched and never eat into the 150-channel cap either.
                verdict = ParentalCatVerdict(gate, catName)
                if verdict = "drop" then continue for
                ref = { provId: pid, ptype: ptype, catId: ToStr(c.catId), name: catName, src: tok }
                ' Xtream ids are numeric and only mean anything on their own
                ' panel — key the display-name cache per source.
                m.catNames[pid + "|" + ToStr(c.catId)] = catName
                ' "gate" = lock mode is "pin": the category stays in the tab,
                ' but its rows are covered over and asking to watch one
                ' raises the PIN pad. Same bargain LiveTvScreen strikes —
                ' you can see that it exists, not what is in it.
                if verdict = "gate" then m.catLocked[pid + "|" + ToStr(c.catId)] = true
                bucket = GuideMetaCategory(catName)
                if not byName.doesExist(bucket) then byName[bucket] = []
                byName[bucket].push(ref)
                allRefs.push(ref)
                if isM3u and ppvGroups.doesExist(ToStr(c.catId))
                    if not byName.doesExist("PPV") then byName["PPV"] = []
                    byName["PPV"].push(ref)
                end if
            end if
        end for
    end for
    buildBucketsFromClassified(byName, allRefs)
end sub

sub buildBucketsFromClassified(byName as object, allRefs as object)
    ' The All tab follows the TAB STRIP, not the providers' own order: News
    ' channels first, then Sports, PPV, Movies... and Other last, so All
    ' reads as the tabs laid end to end. Two reasons — it's what anyone
    ' looking at the strip expects, and a panel hands its categories over
    ' in an order that isn't the same twice, which made All look like a
    ' different tab every time it was opened.
    ' Built BEFORE the PPV block below, or the sports categories PPV borrows
    ' would each appear twice.
    ordered = []
    seenCat = {}
    for each name in GuideMetaOrder()
        if byName.doesExist(name)
            for each ref in byName[name]
                k = ref.provId + "|" + ref.catId
                if not seenCat.doesExist(k)
                    seenCat[k] = true
                    ordered.push(ref)
                end if
            end for
        end if
    end for
    ' A bucket name that isn't in the tab order still gets a place, at the end.
    for each ref in allRefs
        k = ref.provId + "|" + ref.catId
        if not seenCat.doesExist(k)
            seenCat[k] = true
            ordered.push(ref)
        end if
    end for
    ' PPV events usually have no category of their own — they sit inside the
    ' sports categories with only the channel name saying PPV. So the PPV tab
    ' also scans the sports categories and keeps just the PPV-named channels
    ' (see channelBelongsHere). Sports is where they hide on this service;
    ' scanning every category would mean fetching the whole catalogue.
    if byName.doesExist("Sports")
        if not byName.doesExist("PPV") then byName["PPV"] = []
        for each ref in byName["Sports"]
            byName["PPV"].push(ref)
        end for
    end if
    m.buckets = []
    ' "All" leads the strip: everything every source carries, ordered as the
    ' tabs are. The grid still stops at 150 channels, so it's the front of
    ' the list rather than the whole of it — the genre tabs and the sub-menu
    ' are how you reach the rest.
    if ordered.count() > 0 then m.buckets.push({ name: "All", catRefs: ordered })
    for each name in GuideMetaOrder()
        if byName.doesExist(name)
            m.buckets.push({ name: name, catRefs: byName[name] })
        end if
    end for
    KLog("guide", "categories: " + ordered.count().toStr() + " raw across " + m.sources.count().toStr() + " source(s), " + m.buckets.count().toStr() + " tabs")
    ' Any source pointed at guides of its own (or an M3U carrying url-tvg)
    ' pulls in the XMLTV. Several guides are read ONE AT A TIME and merged
    ' into ONE result, matched to channels by tvg-id/callsign, which is
    ' source-agnostic: a guide uploaded for one source also covers matching
    ' channels on another. Reading them at once, or keeping one parsed guide
    ' per source, would multiply the biggest allocation in the app — which is
    ' what put v1.0.18 over the memory limit on small TVs. See
    ' startGuideXmltv for the chain and the ceiling that bounds it.
    startGuideXmltv()
    buildTabs()
    if m.buckets.count() > 0 then selectBucket(0)
end sub

sub selectBucket(idx as integer)
    if idx < 0 or idx >= m.buckets.count() then return
    m.bucketIdx = idx
    m.subIdx = 0
    redrawTabs()
    ' Rebuild resets the sub-menu's SELECTION and its SCROLL. Both matter:
    ' resetting the selection alone leaves the row parked wherever the last
    ' tab's groups had scrolled it, so you're looking at the middle of a list
    ' whose first entry is the one now selected, which reads as a bug.
    buildSubTabs()
    loadBucketChannels()
end sub

' Narrow the tab to one of the provider's own groups (or back to All).
sub selectSubGroup(i as integer)
    if not m.subStripOn then return
    if i < 0 or i >= m.subGroups.count() then return
    if i = m.subIdx then return
    m.subIdx = i
    redrawSubTabs()
    loadBucketChannels()
end sub

' The raw groups to load: the whole tab, or just the chosen sub-menu entry.
' A sub-menu entry can span sources (same group name on two of them), so it
' carries its own list of refs.
function activeCatRefs() as object
    if m.bucketIdx < 0 or m.bucketIdx >= m.buckets.count() then return []
    refs = m.buckets[m.bucketIdx].catRefs
    if not m.subStripOn then return refs
    if m.subIdx <= 0 or m.subIdx >= m.subGroups.count() then return refs
    return m.subGroups[m.subIdx].refs
end function

' A ref's key in the per-load result map — unique per source AND category.
function refKey(ref as object) as string
    return ToStr(ref.provId) + "|" + ToStr(ref.catId)
end function

' ---- The playlist's channels, filed by group ---------------------------------
'
' WHY THIS EXISTS. loadBucketChannels used to answer "which channels are in
' this category?" by walking the ENTIRE playlist once per category:
'
'     for each ref in refs                       ' every category in the tab
'         for each ch in <the whole playlist>    ' every channel, every time
'
' That is categories x channels, on the RENDER THREAD, and it is what killed
' the app. Reproduced on the office stick on 2026-08-29 with the same five
' sources a member had (a 14,281-channel list, a 14,183-channel list, a 2,059
' one, a panel and a KwickTV account - 978 raw categories across 11 tabs):
' opening the TV Guide died with
'
'     Execution timeout (runtime error &h23) in Util.brs(11)   ' ToStr
'     GuideScreen.brs(961) <- (898) <- (885) <- mergeGuideCategories
'
' i.e. the app was killed inside ToStr in the inner loop. On the member's TCL
' 43S310R it surfaced as EXIT_BRIGHTSCRIPT_TIMEOUT and, when it fell over in
' other places, EXIT_BRIGHTSCRIPT_CRASH and EXIT_OUT_OF_MEMORY.
'
' Walking the playlist ONCE and filing every channel under its group turns
' categories x channels into channels + categories. A tab of 200 groups over
' a 14,000-channel list goes from ~2.8 million iterations to ~14,200.
'
' Built per provider, on demand, and thrown away in onGuideM3u the moment that
' playlist is re-read - the index points at the old channel objects and would
' otherwise outlive them.
'
' The channel objects are SHARED, not copied. This holds references to rows the
' session cache already owns, so the index costs a map and some pointers rather
' than a second copy of the playlist - which on a 14,000-channel list is the
' difference between a few KB and several MB on a box that has already been
' killed once for memory.
function m3uGroupIndex(provId as string) as object
    if m.m3uGroupIdx = invalid then m.m3uGroupIdx = {}
    if m.m3uGroupIdx.doesExist(provId) then return m.m3uGroupIdx[provId]

    idx = {}
    ' Group names come from the playlist and are compared against category
    ' names spelled the same way, so this map is case-sensitive on purpose - a
    ' default map would silently merge two groups a provider deliberately
    ' spells differently.
    idx.SetModeCaseSensitive()
    slots = m.global.m3uByProv
    if slots <> invalid and slots.doesExist(provId)
        for each ch in slots[provId].channels
            g = ToStr(ch.group)
            if g = "" then g = "Uncategorized"
            if idx.doesExist(g)
                idx[g].push(ch)
            else
                idx[g] = [ch]
            end if
        end for
    end if
    m.m3uGroupIdx[provId] = idx
    return idx
end function

function m3uChannelsInGroup(provId as string, catId as string) as object
    idx = m3uGroupIndex(provId)
    if idx.doesExist(catId) then return idx[catId]
    return []
end function

sub loadBucketChannels()
    m.channels = []
    m.topRow = 0
    m.cursorRow = 0
    m.loadGen = m.loadGen + 1
    refs = activeCatRefs()
    clearRows()
    setBusy(true)

    ' Fetch the raw categories being shown; rows fill as answers land.
    '
    ' QUEUED, NOT FIRED ALL AT ONCE. Roku aborts an app that runs more than
    ' 100 task threads at the same time, and one tab can hold far more raw
    ' categories than that — "Other" on this service holds 211 — so starting
    ' a request per category killed the app outright the moment such a tab
    ' was opened. A few run at a time and the rest wait their turn. The cap
    ' counts every source together, since the thread ceiling is app-wide.
    '
    ' M3U groups need no request at all: that playlist is already parsed in
    ' the session cache, so they're filled in right here and only the Xtream
    ' groups ever join the queue.
    m.catQueue = []
    m.catOrder = []
    m.catResults = {}
    for each ref in refs
        k = refKey(ref)
        m.catOrder.push(k)
        if ToStr(ref.ptype) = "m3u"
            kept = []
            ' ONE LOOKUP, not a walk of the whole playlist. This used to be a
            ' nested loop - every channel of the playlist, for every category
            ' in the tab - and it is what took the app down. See
            ' m3uGroupIndex().
            for each ch in m3uChannelsInGroup(ToStr(ref.provId), ToStr(ref.catId))
                if channelBelongsHere(ToStr(ref.name), ToStr(ch.name))
                    kept.push(ch)
                end if
            end for
            m.catResults[k] = kept
        else
            m.catQueue.push(ref)
        end if
    end for
    m.catActive = 0
    rebuildChannelList()
    pumpCatQueue()
    if m.global.xmltvState = "ready"
        for each ch in m.channels
            if xmltvCovers(ch) then fillEpgFromXmltv(ch)
        end for
    end if
    rebuildRows()
end sub

' Answers come back in whatever order the network hands them over, so the
' rows are assembled from the ORIGINAL category order instead of the order
' they arrived in. Without this the same tab lists its channels differently
' on every visit — which matters most on All, where hundreds of categories
' race for 150 slots.
'
' The channel-name filter is applied HERE and nowhere else, so every path that
' rebuilds the list — a category answering, a sub-group being picked, a tab
' change, the filter itself — goes through one rule and the two arrays can
' never drift apart. Two things follow from applying it at this point rather
' than to the finished m.channels:
'   · the 150-channel cap counts MATCHES, so a filter looks at everything the
'     tab has fetched instead of only the first 150 rows of it; and
'   · m.chanLocked stays index-aligned with m.channels by construction, since
'     both are pushed in the same breath.
' ---- The lineup the player zaps through (A2) ---------------------------------
'
' The guide's half of m.global.liveLineup. LiveTvScreen carries the long note;
' read publishLiveLineup there for what the field is, why the shape is the
' player's own five keys, and why it may never cause a request. This screen
' publishes the SAME field the SAME way, because the guide is the screen the
' member was actually on when channel up/down turned out to be missing — if
' only Live TV published, zapping would work from one screen and not the other.
'
' TWO THINGS ARE DIFFERENT HERE, both deliberate:
'
'   · PIN-LOCKED ROWS ARE LEFT OUT. A locked row is drawn covered over and
'     pressing OK on it prompts for the PIN; a lineup that included it would
'     let channel-up tune straight into it with no prompt at all, which is the
'     bypass B1b closed on the detail screens. So "next" steps over a locked
'     channel, which is also what the member would expect — they cannot watch
'     it without the PIN either way. Unlocking re-merges the categories and
'     rebuilds this list, so the channels appear the moment the PIN is entered.
'     THE CONSEQUENCE FOR THE PLAYER: a published index is NOT a row index.
'     Match an entry by identity (src + streamId), never by position.
'
'   · IT IS PUBLISHED FROM HERE, the one place the displayed list is built.
'     Every path that changes what the member sees — a tab, a sub-group, a
'     category answering late, the name filter — already comes through this
'     function, so one call covers all four and none of them can drift.
'
' No extra pass: the entries are pushed in the same breath as m.channels and
' m.chanLocked, and the field is written ONCE, complete, at the end.
sub publishGuideLineup(entries as object)
    if m.global = invalid then return
    if not m.global.hasField("liveLineup") then m.global.addFields({ liveLineup: [] })
    m.global.liveLineup = entries
end sub

sub rebuildChannelList()
    m.channels = []
    m.chanLocked = []
    lineup = []
    q = m.queryLc
    filtering = (q <> "")
    ' The 150-channel cap used to be a bare `return` out of the inner loop.
    ' It is a flag now for one reason only: the publish below has to happen on
    ' the capped path too, and a capped list that published nothing would leave
    ' the previous tab's lineup standing. Same cap, same order, same 150.
    full = false
    for each k in m.catOrder
        if full then exit for
        if m.catResults.doesExist(k)
            ' One lookup per CATEGORY, not per channel.
            isLocked = m.catLocked.doesExist(k)
            ' A LOCKED CATEGORY IS LEFT OUT OF A FILTERED VIEW ENTIRELY.
            ' Browsing shows a locked row covered over ("Locked — press OK and
            ' enter your PIN") and never its name or its programmes; letting a
            ' typed name match one would hand back the very name the cover is
            ' hiding, one guess at a time. So filtering is the strict case, the
            ' same call Search and the Multi-View picker make — left out rather
            ' than shown and then refused. Clear the filter, press OK on the
            ' row and enter the PIN; the session unlock re-merges the
            ' categories and the filter reaches them from then on.
            if filtering and isLocked then continue for
            for each ch in m.catResults[k]
                if filtering
                    nm = ToStr(GetField(ch, "name"))
                    ' Case-insensitive "contains", the same test Search uses.
                    ' The query was lowercased once, up in applyChannelFilter.
                    if nm = "" then continue for
                    if LCase(nm).instr(0, q) < 0 then continue for
                end if
                if m.channels.count() >= 150
                    full = true
                    exit for
                end if
                m.channels.push(ch)
                m.chanLocked.push(isLocked)
                ' Locked rows are deliberately absent from the player's copy —
                ' see publishGuideLineup above. GetField/ToStr each way for the
                ' same reason openChannelPage does it: the M3U and Xtream rows
                ' this screen holds do not carry all the same keys.
                if not isLocked
                    lineup.push({
                        streamId: ToStr(GetField(ch, "streamId"))
                        name: ToStr(GetField(ch, "name"))
                        logo: ToStr(GetField(ch, "logo"))
                        url: ToStr(GetField(ch, "url"))
                        src: ToStr(GetField(ch, "src"))
                    })
                end if
            end for
        end if
    end for
    publishGuideLineup(lineup)
end sub

' Is the row at this index behind the PIN? Kept beside m.channels rather than
' on the channel itself — see the note in init().
function rowLocked(r as integer) as boolean
    if r < 0 or r >= m.chanLocked.count() then return false
    return m.chanLocked[r] = true
end function

' What to draw across a locked row: one block, the width of the window,
' saying how to get in. Deliberately NOT the listings — a locked category
' should not advertise what is on it, which is the same line LiveTvScreen
' draws when it refuses to fetch a locked category's channels.
function lockedBlocks() as object
    return [{ title: "Locked — press OK and enter your PIN", desc: "", startS: m.windowStart, stopS: m.windowEnd, noData: true, locked: true }]
end function

' The blocks for one row, whichever kind of row it is. Every navigation and
' render path goes through here so a locked row behaves the same on all of
' them — and a locked row never triggers an EPG fetch it isn't going to show.
function blocksForRow(r as integer) as object
    if r < 0 or r >= m.channels.count() then return []
    if rowLocked(r) then return lockedBlocks()
    ch = m.channels[r]
    ensureEpg(ch)
    return renderedFor(ch)
end function

' Channels held by the leading run of categories that have all answered —
' i.e. the part of the list that can no longer change. Once that fills the
' grid there is nothing to gain from fetching more.
function settledCount() as integer
    n = 0
    for each k in m.catOrder
        if not m.catResults.doesExist(k) then return n
        n = n + m.catResults[k].count()
        if n >= 150 then return n
    end for
    return n
end function

sub pumpCatQueue()
    while m.catActive < 6 and m.catQueue.count() > 0
        ' The grid only ever shows 150 channels, so once it's full there's
        ' nothing to gain from the remaining categories — and on a 211-group
        ' tab that's the difference between a handful of requests and all of
        ' them. Narrow it with the sub-menu to see a specific group.
        if settledCount() >= 150
            m.catQueue = []
            exit while
        end if
        ref = m.catQueue.shift()
        prov = guideProviderById(ToStr(ref.provId))
        if prov <> invalid
            key = "chan_" + m.loadGen.toStr() + "_" + refKey(ref)
            if not m.inflight.doesExist(key)
                task = CreateObject("roSGNode", "ApiTask")
                ' gen | provId | catId — the answer needs the source to know
                ' whose panel it came from and which slot to fill.
                task.tag = m.loadGen.toStr() + "|" + ToStr(ref.provId) + "|" + ToStr(ref.catId)
                task.url = XtreamApiUrl(prov, "get_live_streams") + "&category_id=" + UrlEncode(ToStr(ref.catId))
                task.observeField("result", "onChannels")
                m.inflight[key] = task
                m.catActive = m.catActive + 1
                task.control = "RUN"
            end if
        end if
    end while
    if m.catActive = 0 and m.catQueue.count() = 0
        setBusy(false)
        showBucketEmptyState()
    end if
end sub

sub onChannels(event as object)
    try
        onChannelsInner(event)
    catch e
        GuardFailed("guide/onChannels", e)
        setBusy(false)
    end try
end sub

sub onChannelsInner(event as object)
    res = event.getData()
    tag = ToStr(event.getRoSGNode().tag)
    parts = tag.split("|")
    if parts.count() < 3 then return
    gen = ToStr(parts[0])
    pid = ToStr(parts[1])
    catId = ToStr(parts[2])
    k = pid + "|" + catId
    m.inflight.delete("chan_" + gen + "_" + k)
    ' Ignore answers from a load the user has already moved off — a different
    ' tab, or a different group within the same tab.
    if gen <> m.loadGen.toStr() then return
    m.catActive = m.catActive - 1
    if m.catActive < 0 then m.catActive = 0

    prov = guideProviderById(pid)
    token = ""
    if prov <> invalid then token = SrcTokenFor(prov)
    kept = []
    if res <> invalid and res.ok = true
        catName = ""
        if m.catNames <> invalid and m.catNames.doesExist(k) then catName = ToStr(m.catNames[k])
        for each s in ToArray(res.data)
            chName = ToStr(GetField(s, "name"))
            if channelBelongsHere(catName, chName)
                kept.push({
                    streamId: ToStr(GetField(s, "stream_id"))
                    name: chName
                    logo: ToStr(GetField(s, "stream_icon"))
                    url: ""
                    ' The panel's own tvg-id. Unused on the normal path (the
                    ' panel serves EPG per stream_id), but it's what a custom
                    ' XMLTV guide matches channels on.
                    tvgId: ToStr(GetField(s, "epg_channel_id"))
                    src: token
                    provId: pid
                })
            end if
        end for
    end if
    m.catResults[k] = kept
    rebuildChannelList()
    ' Starts the next few and, when nothing is left, stops the spinner and
    ' decides the empty state.
    pumpCatQueue()
    rebuildRows()
end sub

' Which bucket does this channel really belong to? PPV channels are pulled
' out of the sports tabs and shown only under PPV; everything else follows
' its category as before.
function channelBelongsHere(catName as string, chName as string) as boolean
    ' m.buckets is emptied and rebuilt whenever a source's categories land,
    ' and activeCatRefs()/buildSubTabs() both bounds-check this same lookup.
    ' These two never did. "Keep it" is the safe answer: a channel shown in
    ' the wrong tab is a blemish, dereferencing invalid is a dead app.
    if m.bucketIdx < 0 or m.bucketIdx >= m.buckets.count() then return true
    here = ToStr(m.buckets[m.bucketIdx].name)
    if here = "All" then return true    ' All means all, PPV events included
    if here = "PPV" then return GuideMetaCategoryForChannel(catName, chName) = "PPV"
    return not LooksPpv(chName)
end function

' An empty tab used to say only "No channels in this section", which makes a
' keyword that matched nothing look exactly like a feature that was never
' installed — that ambiguity cost the Android side two rounds of debugging.
' Say plainly which it is, and log the count.
sub showBucketEmptyState()
    isEmpty = (m.channels.count() = 0)
    m.emptyLabel.visible = isEmpty
    ' A filter that matched nothing is not an empty tab, and letting "No
    ' channels in this section" stand for both is exactly the ambiguity the
    ' note above is about. Say which it is — and say plainly what the filter
    ' can and cannot reach, since it only ever looks at the channels this tab
    ' has loaded and the tab stops at 150 of them.
    if isEmpty and m.query <> ""
        m.emptyLabel.text = Chr(34) + m.query + Chr(34) + " — no channel on this tab matches. The guide loads up to 150 channels per tab, so try a genre tab, or pick a group from the row below and filter again."
        return
    end if
    if m.bucketIdx < 0 or m.bucketIdx >= m.buckets.count()
        ' No tabs at all — every source failed to list its categories. Say so
        ' instead of leaving a blank screen with the spinner already stopped.
        if isEmpty then m.emptyLabel.text = "Couldn't load the guide from any of your sources. Check your connection and try again."
        return
    end if
    if ToStr(m.buckets[m.bucketIdx].name) = "PPV"
        KLog("guide", "PPV tab matched " + m.channels.count().toStr() + " channel(s)")
        if isEmpty then m.emptyLabel.text = "No pay-per-view channels found in your provider's sports categories."
    else if isEmpty
        m.emptyLabel.text = "No channels in this section."
    end if
end sub

' ---- Data: EPG per channel ---------------------------------------------------

' Make sure a row has listings, from whichever guide actually covers it.
sub ensureEpg(ch as object)
    key = epgKeyFor(ch)
    if m.epgCache.doesExist(key) then return

    ' Which source this channel came from decides where its listings come
    ' from — an M3U source has no panel to ask, so XMLTV is all there is.
    prov = ProviderForSrcToken(ToStr(GetField(ch, "src")))
    if prov = invalid then prov = m.provider
    if prov = invalid then return
    if ToStr(prov.ptype) = "m3u"
        if m.global.xmltvState = "ready"
            fillEpgFromXmltv(ch)
        else
            m.epgCache[key] = []
        end if
        return
    end if

    ' A custom guide wins for the channels it covers; everything else falls
    ' through to the provider's own guide, so a partial XMLTV doesn't blank
    ' out the rest of the playlist. While it's still downloading, the panel
    ' answers — the custom listings replace those once it's ready, rather
    ' than leaving the grid empty for the couple of minutes a big guide
    ' takes to read.
    if xmltvCovers(ch)
        fillEpgFromXmltv(ch)
        return
    end if
    requestEpg(prov, ToStr(GetField(ch, "src")), ToStr(ch.streamId))
end sub

sub requestEpg(prov as object, srcTok as string, streamId as string)
    key = srcTok + "|" + streamId
    if m.epgCache.doesExist(key) or m.epgPending.doesExist(key) then return
    m.epgPending[key] = true
    task = CreateObject("roSGNode", "ApiTask")
    task.tag = key
    task.url = XtreamApiUrl(prov, "get_short_epg") + "&stream_id=" + UrlEncode(streamId) + "&limit=30"
    task.observeField("result", "onEpg")
    m.inflight["epg_" + key] = task
    task.control = "RUN"
end sub

sub onEpg(event as object)
    try
        onEpgInner(event)
    catch e
        GuardFailed("guide/onEpg", e)
    end try
end sub

sub onEpgInner(event as object)
    res = event.getData()
    key = ToStr(event.getRoSGNode().tag)
    m.inflight.delete("epg_" + key)
    m.epgPending.delete(key)
    listings = []
    if res <> invalid and res.ok = true
        for each e in ToArray(GetField(res.data, "epg_listings"))
            startS = ToInt(GetField(e, "start_timestamp"))
            stopS = ToInt(GetField(e, "stop_timestamp"))
            if stopS > m.windowStart and startS < m.windowEnd
                listings.push({
                    title: B64Decode(ToStr(GetField(e, "title")))
                    desc: B64Decode(ToStr(GetField(e, "description")))
                    startS: startS
                    stopS: stopS
                })
            end if
        end for
    end if
    m.epgCache[key] = listings
    ' Repaint only if that channel is currently on screen.
    for i = m.topRow to visibleEnd()
        if i < m.channels.count() and epgKeyFor(m.channels[i]) = key
            rebuildRows()
            return
        end if
    end for
end sub

' ---- Channel-name filter -----------------------------------------------------
'
' WHAT IT IS. A chip on the header line that narrows the grid to channels whose
' name contains what you typed — the Roku half of the Android guide's search
' field (epg_guide_screen.dart, which filters the loaded lineup the same way).
' Up from the tab strip focuses it; OK (or the * Options button, from anywhere
' on this screen) opens the keyboard.
'
' WHAT IT DELIBERATELY DOES NOT DO. It does not fetch. The guide's loading
' rules are not touched: the queue still stops once 150 channels have settled
' (pumpCatQueue), six requests still run at a time, and a tab holding 211 raw
' groups still costs a handful of requests rather than all of them. So the
' filter searches the channels this tab has LOADED, not the provider's whole
' catalogue — narrow the tab with the sub-menu first and the filter reaches
' further. showBucketEmptyState says that in as many words when nothing
' matches, rather than leaving "no channels" to mean two different things.
'
' PARENTAL LOCKS. A locked ("gate"-verdict) row is left out of a filtered view
' altogether — see rebuildChannelList. "drop"-verdict categories were thrown
' away back in mergeGuideCategories and were never fetched, so no view built
' here can reach them.

sub setupFilterBar()
    m.filterRing = m.top.findNode("filterRing")
    m.filterRing.color = m.theme.focusHighlight
    bg = m.top.findNode("filterBg")
    bg.color = m.theme.surface
    icon = m.top.findNode("filterIcon")
    icon.font = IconFont(30)
    icon.text = m.theme.iconSearch
    icon.color = m.theme.textSecondary
    m.filterText = m.top.findNode("filterText")
    ' 24 -> 22. The chip's text box is a fixed 316px and what goes in it is
    ' whatever the member typed, so the mono advance costs characters directly:
    ' 22pt holds ~24 of them against Roboto 24pt's ~26.
    m.filterText.font = UiFont(22)
    redrawFilterBar()
end sub

sub redrawFilterBar()
    if m.query = ""
        m.filterText.text = "Filter channels"
        m.filterText.color = m.theme.textSecondary
    else
        m.filterText.text = m.query
        m.filterText.color = m.theme.textPrimary
    end if
    m.filterRing.visible = (m.focusArea = "filter")
end sub

' Roku's StandardKeyboardDialog, set up exactly as SearchScreen.openKeyboard
' sets it up — including the `wasClosed` observer, WITHOUT which Back closes
' the dialog through no button at all and leaves this screen with focus
' nowhere, answering no key. Voice comes with the dialog: hold the microphone
' and say the channel's name.
sub openFilterKeyboard()
    kb = CreateObject("roSGNode", "StandardKeyboardDialog")
    kb.title = "Filter channels"
    ' Always a fresh, empty box, set BEFORE the text box below is touched —
    ' the order the sign-in form uses and the one known to work.
    kb.text = ""
    ' "Show all" only when there is something to clear; an always-present
    ' button that does nothing is a D-pad stop for nothing. onFilterKeyboard-
    ' Button reads the index off m.kbHasClear rather than assuming it.
    m.kbHasClear = (m.query <> "")
    if m.kbHasClear
        kb.buttons = ["Filter", "Show all", "Cancel"]
    else
        kb.buttons = ["Filter", "Cancel"]
    end if
    ' A channel name is ordinary words, not an address spelled out letter by
    ' letter. Roku's vocabulary is email / numeric / alphanumeric / generic /
    ' password and nothing else.
    kb.keyboardDomain = "generic"
    edit = kb.textEditBox
    ' Said on the box as well as on the dialog: keyboardDomain is documented as
    ' something the keyboard "may" act on, and the microphone is the point.
    edit.voiceEnabled = true
    edit.voiceEntryType = kb.keyboardDomain
    edit.maxTextLength = 128        ' Roku defaults to 15 — a spoken name is longer
    m.kbDialog = kb
    m.kbEdit = edit
    m.pendingSet = false
    m.pendingQuery = ""
    kb.observeField("buttonSelected", "onFilterKeyboardButton")
    kb.observeField("wasClosed", "onFilterKeyboardClosed")
    m.top.getScene().dialog = kb
end sub

' What was left in the box, typed or spoken. The dialog's own `text` is the
' documented place to read it from; the box is consulted only when the dialog
' says nothing, because dictation lands in the box first.
function filterKeyboardText() as string
    if m.kbDialog = invalid then return ""
    t = ToStr(m.kbDialog.text)
    if t = "" and m.kbEdit <> invalid then t = ToStr(m.kbEdit.text)
    return t
end function

' Dictation punctuates what it heard, so "history" can arrive as "History." and
' a plain "contains" test against the channel name would then match nothing.
' Only the ENDS are stripped and only on the query — the middle is left as
' spoken, and no channel name is ever normalised (that would be per-row work
' over everything the tab holds).
function cleanFilterQuery(raw as string) as string
    q = raw.trim()
    junk = ".,!?;:"
    while q.len() > 0 and junk.instr(q.right(1)) > -1
        q = q.left(q.len() - 1)
    end while
    while q.len() > 0 and junk.instr(q.left(1)) > -1
        q = q.mid(1)
    end while
    return q.trim()
end function

' ---- The rest of this screen's handlers, guarded ----------------------------
'
' A guard on one handler only moves the crash, so every entry point the render
' thread can call on this screen now runs under try/catch - not just the two
' the App Health export happened to name. That is the keyboard's two
' callbacks, the programme dialog, the player and channel-page close
' callbacks, the three parental-PIN callbacks and onKeyEvent itself. The data
' callbacks above this point were already wrapped (v1.0.34); the ones below it
' were the ones left bare. GuardFailed logs "crash averted in guide/<handler>"
' with the file, line and function, and arms the next-launch crash report, so
' whatever goes next is named instead of guessed at. The measurement behind
' all of them is on onKeyEvent at the bottom of this file.
sub onFilterKeyboardButton()
    try
        onFilterKeyboardButtonInner()
    catch e
        GuardFailed("guide/onFilterKeyboardButton", e)
    end try
end sub

sub onFilterKeyboardButtonInner()
    kb = m.kbDialog
    if kb = invalid then return
    b = kb.buttonSelected
    clearIdx = -1
    if m.kbHasClear then clearIdx = 1
    if b = 0
        ' An empty box — or speech Roku heard as nothing but punctuation —
        ' means "show everything again", not a filter of "".
        m.pendingQuery = cleanFilterQuery(filterKeyboardText())
        m.pendingSet = true
    else if b = clearIdx
        m.pendingQuery = ""
        m.pendingSet = true
    end if
    ' Cancel (and Back, which never reaches here) leave the query alone.
    kb.close = true
end sub

' Every way out of the dialog lands here: Filter, Show all, Cancel and Back.
sub onFilterKeyboardClosed()
    try
        onFilterKeyboardClosedInner()
    catch e
        GuardFailed("guide/onFilterKeyboardClosed", e)
        ' The dialog has gone either way, and it took focus with it. Take it
        ' back here too or the guide answers nothing at all afterwards.
        m.top.setFocus(true)
    end try
end sub

sub onFilterKeyboardClosedInner()
    m.kbDialog = invalid
    m.kbEdit = invalid
    apply = m.pendingSet
    q = ToStr(m.pendingQuery)
    m.pendingSet = false
    m.pendingQuery = ""
    ' Focus lives on this Group and onKeyEvent does the rest, but the dialog
    ' took it — take it back from here or the guide answers nothing after a
    ' Back out of the keyboard.
    m.top.setFocus(true)
    if not apply then return
    if q = m.query then return          ' nothing actually changed
    applyChannelFilter(q)
end sub

' Re-derive the grid from what is already in hand. No request, no registry
' read, no re-merge — m.catResults, m.catOrder and m.catLocked are all
' untouched, so this is the same work one arriving category answer already
' does, which is what keeps it inside the 250 ms a remote press is allowed.
sub applyChannelFilter(q as string)
    m.query = q
    m.queryLc = LCase(q)
    redrawFilterBar()
    ' The cursor's ROW means nothing once the list underneath it changes; its
    ' TIME is put back to now, the same as walking into the grid from the tabs.
    m.topRow = 0
    m.cursorRow = 0
    m.cursorTime = CreateObject("roDateTime").asSeconds()
    rebuildChannelList()
    ' Listings for whatever is on screen now are filled in lazily by
    ' blocksForRow -> ensureEpg, exactly as they are on an ordinary load — and
    ' a locked row still never asks for any.
    rebuildRows()
    showBucketEmptyState()
    if m.query = ""
        KLog("guide", "channel filter cleared")
    else
        KLog("guide", "channel filter " + Chr(34) + m.query + Chr(34) + " matched " + m.channels.count().toStr() + " of the channels loaded on this tab")
    end if
end sub

' ---- Tabs -------------------------------------------------------------------

' THE STRIP DOES NOT SCROLL AND DOES NOT CLIP, so it has to fit at its widest.
' GuideMetaOrder holds twelve names plus "All" — 83 characters in total, and
' twelve 46px gaps. At Roboto-Medium 26 that measured ~1631px inside the 1749px
' the strip has (x=60 to the same 1789 edge the sub-strip measures against).
' JetBrains Mono is a flat 0.6em advance, so the SAME strip at 26 would want
' ~1847px and push the last tab off the side of the screen. At 22 it wants
' ~1648px and keeps ~100px in hand. Mono's larger x-height means 22 here reads
' close to Roboto 24, so this is one visual step down, not four.
sub buildTabs()
    strip = m.top.findNode("tabStrip")
    while strip.getChildCount() > 0
        strip.removeChildIndex(0)
    end while
    m.tabNodes = []
    f = UiBoldFont(22)
    x = 0
    for each b in m.buckets
        lbl = strip.createChild("Label")
        lbl.text = b.name
        lbl.font = f
        lbl.translation = [x, 0]
        w = Int(lbl.boundingRect().width) ' measured, not estimated
        underline = strip.createChild("Rectangle")
        underline.height = 3
        underline.width = w
        underline.translation = [x, 40]
        m.tabNodes.push({ lbl: lbl, underline: underline, x: x, w: w })
        x = x + w + 46
    end for
    m.tabFocus = 0
    redrawTabs()
end sub

' THE DASHBOARD'S SECOND ENTRY, IN ITS OWN RIGHT: 4 crashes on v1.0.36 at
' line 1719, which is the m.tabNodes.count() immediately below. Up, Down and *
' on the tab strip, applyChannelFilter and selectBucket all come through here,
' so it died on the same invalid m.tabNodes that killed onKeyEvent without
' ever reaching onKeyEvent's own arithmetic. init() now creates m.tabNodes, so
' it cannot be invalid any more; the guard stays so that the next thing to go
' wrong here is named in the log instead of killing the app, and so the
' console says guide/redrawTabs rather than whichever handler called it.
sub redrawTabs()
    try
        redrawTabsInner()
    catch e
        GuardFailed("guide/redrawTabs", e)
    end try
end sub

sub redrawTabsInner()
    for i = 0 to m.tabNodes.count() - 1
        t = m.tabNodes[i]
        t.underline.width = t.w
        if m.focusArea = "tabs" and i = m.tabFocus
            t.lbl.color = m.theme.focusHighlight
        else if i = m.bucketIdx
            t.lbl.color = m.theme.textPrimary
        else
            t.lbl.color = m.theme.textSecondary
        end if
        t.underline.visible = (i = m.bucketIdx)
        t.underline.color = m.theme.accent
    end for
end sub

' ---- Sub-menu: the provider's own groups inside the selected tab -------------
'
' GuideMetaCategory sums a provider's many raw groups ("CA | NEWS",
' "UK | NEWS", "USA NEWS") into one clean tab, which is good for browsing and
' bad for finding — you can see the channel exists but can't navigate to its
' group. This second strip hands the raw groups back, without giving up the
' tidy tabs. It's a view onto data the screen already holds: catRefs IS the
' list of raw groups in the bucket (across every source), so there's no extra
' request and no extra parsing.

' (Group display names come straight off each ref — every ref carries the
' name its source gave it, so no id lookup is needed anymore.)

sub buildSubTabs()
    inner = m.top.findNode("subStripInner")
    while inner.getChildCount() > 0
        inner.removeChildIndex(0)
    end while
    m.subNodes = []
    m.subGroups = []
    m.subFocus = 0
    m.subScroll = 0
    inner.translation = [0, 0]

    raw = []
    here = ""
    if m.bucketIdx >= 0 and m.bucketIdx < m.buckets.count()
        raw = m.buckets[m.bucketIdx].catRefs
        here = ToStr(m.buckets[m.bucketIdx].name)
    end if

    ' A tab holding one raw group would show a row reading "All" and that
    ' group — no information, and a D-pad stop for nothing. Hide the node and
    ' give the space back to the grid rather than blanking the labels.
    '
    ' The All tab gets no sub-menu either: its groups are every group in the
    ' service, which is hundreds of entries on a horizontal strip nobody
    ' could sensibly scroll. Narrowing to a group is what the genre tabs and
    ' their own sub-menus are for.
    m.subStripOn = (here <> "All" and raw.count() > 1)
    layoutForSubStrip(m.subStripOn)
    if not m.subStripOn then return

    ' Groups with the SAME NAME on different sources are one entry holding
    ' both sources' refs — the same merge rule the rest of the app follows,
    ' so picking "UK | SPORTS" shows it from every source that has it.
    entries = []
    byLabel = {}
    for each ref in raw
        lbl = ToStr(ref.name)
        if lbl <> ""
            if not byLabel.doesExist(lbl)
                e = { label: lbl, refs: [] }
                byLabel[lbl] = e
                entries.push(e)
            end if
            byLabel[lbl].refs.push(ref)
        end if
    end for
    entries.sortBy("label", "i")
    ' All comes first and means what the tab means today, so nobody who never
    ' touches this row sees any change.
    m.subGroups = [{ label: "All", refs: raw }]
    for each e in entries
        m.subGroups.push(e)
    end for

    ' 24 -> 20. This strip DOES scroll, so it has no fit problem of its own;
    ' the drop is to stay a step below the genre tabs, which mono forced down
    ' to 22 (see buildTabs). Equal sizes would read as two rows of tabs.
    f = UiFont(20)
    x = 0
    for i = 0 to m.subGroups.count() - 1
        lbl = inner.createChild("Label")
        lbl.text = m.subGroups[i].label
        lbl.font = f
        lbl.translation = [x, 0]
        w = Int(lbl.boundingRect().width)   ' measured, never estimated —
        if w <= 0 then w = 60               ' group names are long and uneven
        underline = inner.createChild("Rectangle")
        underline.height = 3
        underline.width = w
        underline.translation = [x, 34]
        m.subNodes.push({ lbl: lbl, underline: underline, x: x, w: w })
        x = x + w + 40
    end for
    redrawSubTabs()
end sub

sub redrawSubTabs()
    if not m.subStripOn then return
    if m.subNodes.count() = 0 then return
    ' The shell insets this screen by the sidebar, so the guide's own width is
    ' 1809, not 1920 — the strip starts at x=60 and stops 20px short of the
    ' edge. Measured against the real screen; guessing 1920 puts the last
    ' entry half off the side.
    viewW = 1729

    ' Thirty 24/7 groups don't fit on a 1920 screen, so the strip slides to
    ' keep the focused entry in view.
    n = m.subNodes[m.subFocus]
    if n.x < m.subScroll then m.subScroll = n.x
    if n.x + n.w > m.subScroll + viewW then m.subScroll = n.x + n.w - viewW
    if m.subScroll < 0 then m.subScroll = 0
    m.top.findNode("subStripInner").translation = [-m.subScroll, 0]

    for i = 0 to m.subNodes.count() - 1
        t = m.subNodes[i]
        ' Same colour logic as the genre strip, so the two read as one control.
        if m.focusArea = "subtabs" and i = m.subFocus
            t.lbl.color = m.theme.focusHighlight
        else if i = m.subIdx
            t.lbl.color = m.theme.textPrimary
        else
            t.lbl.color = m.theme.textSecondary
        end if
        t.underline.color = m.theme.accent
        ' A Group can't be relied on to clip its children, so an entry that
        ' would hang off either edge is hidden outright rather than drawn
        ' half-way into the guide. The focused one always shows — the scroll
        ' above has just made room for it.
        lx = t.x - m.subScroll
        shown = (lx >= 0 and lx + t.w <= viewW) or i = m.subFocus
        t.lbl.visible = shown
        t.underline.visible = shown and i = m.subIdx
    end for
end sub

' One place decides where everything below the tabs sits, because the strip
' comes and goes per tab. m.visibleRows has to move with it or the bottom row
' renders off the screen edge.
sub layoutForSubStrip(showStrip as boolean)
    dy = 0
    if showStrip then dy = 52
    m.top.findNode("subStrip").visible = showStrip
    m.top.findNode("timeHeader").translation = [280, 156 + dy]
    m.top.findNode("rowsGroup").translation = [60, 200 + dy]
    m.emptyLabel.translation = [60, 240 + dy]
    m.gridTop = 200 + dy
    ' The marker is a Group now, so its height is its bars' heights — a Group
    ' has no height of its own and writing one would be quietly ignored.
    rows = Int((m.gridBottom - m.gridTop) / (m.rowH + m.rowGap))
    ' The line runs to the BOTTOM OF THE LAST VISIBLE ROW, worked out from the
    ' same arithmetic that decides how many rows there are. It used to be a
    ' fixed 830, a number left over from when the line was a bare rectangle,
    ' and that stopped it about a row short of the grid - Mason: "it doesn't
    ' extend to the bottom, it is a little short" (2026-09-12).
    setNowLineHeight(rows * (m.rowH + m.rowGap) - m.rowGap)
    if rows < 1 then rows = 1
    m.visibleRows = rows
    if m.topRow > m.cursorRow then m.topRow = m.cursorRow
    if m.cursorRow > m.topRow + m.visibleRows - 1 then m.topRow = m.cursorRow - m.visibleRows + 1
    if m.topRow < 0 then m.topRow = 0
end sub

' ---- Grid rendering ----------------------------------------------------------

function visibleEnd() as integer
    last = m.topRow + m.visibleRows - 1
    if last > m.channels.count() - 1 then last = m.channels.count() - 1
    return last
end function

' Programmes rendered for a row: EPG blocks clamped to the window, or one
' full-window "no data" block — the row is always tunable, like Android.
' No-data blocks show the CHANNEL NAME as their title with a quiet
' "No guide data available" subtext (user request, also queued for Android).
function renderedFor(ch as object) as object
    key = epgKeyFor(ch)
    listings = invalid
    if m.epgCache.doesExist(key) then listings = m.epgCache[key]
    blocks = []
    if listings <> invalid and listings.count() > 0
        for each pgm in listings
            startS = pgm.startS
            stopS = pgm.stopS
            if startS < m.windowStart then startS = m.windowStart
            if stopS > m.windowEnd then stopS = m.windowEnd
            widthPx = Int((stopS - startS) / 60) * m.pxPerMin
            if widthPx >= 12
                blocks.push({ title: pgm.title, desc: pgm.desc, startS: startS, stopS: stopS, noData: false })
            end if
        end for
    end if
    if blocks.count() = 0
        blocks.push({ title: ToStr(ch.name), desc: "", startS: m.windowStart, stopS: m.windowEnd, noData: true })
    end if
    return blocks
end function

sub clearRows()
    rows = m.top.findNode("rowsGroup")
    while rows.getChildCount() > 0
        rows.removeChildIndex(0)
    end while
    m.nowLine.visible = false
end sub

sub rebuildRows()
    clearRows()
    rows = m.top.findNode("rowsGroup")
    if m.channels.count() = 0 then return

    nowSecs = CreateObject("roDateTime").asSeconds()
    ' THE TIGHTEST TEXT IN THE APP. A programme block's width is its RUNTIME —
    ' 6px per minute — so a half-hour show gets 176px of block and 148px of
    ' label, and no amount of layout work makes that box bigger. JetBrains Mono
    ' is a flat 0.6em advance where Roboto-Medium averaged about 0.5em, so the
    ' point sizes come down to buy the characters back:
    '   title 22 -> 19   148px holds ~13 characters, against ~13.4 before
    '   time  20 -> 18   the time range is 19 characters and needs 205px, so it
    '                    still only fits a 60-minute block or longer — exactly
    '                    as it did at Roboto 20, which needed 190px
    ' Bold for the title: JetBrains Mono Bold has the same advance as Regular,
    ' so it costs no width and holds up better at 19 from ten feet.
    labelFont = UiBoldFont(19)
    smallFont = UiFont(18)

    for r = m.topRow to visibleEnd()
        ch = m.channels[r]
        y = (r - m.topRow) * (m.rowH + m.rowGap)

        ' Logo cell. A rounded plate, not a Rectangle, for the same reason the
        ' programme blocks below are (see the note there) - a square logo cell
        ' butted against a row of rounded blocks is the one thing that would
        ' make the rounding read as a rendering fault rather than a style.
        cell = rows.createChild("Poster")
        cell.uri = "pkg:/images/card_fill.9.png"
        cell.width = m.logoW - 10
        cell.height = m.rowH
        cell.translation = [0, y]
        cell.blendColor = m.theme.surface
        logo = rows.createChild("Poster")
        logo.uri = ch.logo
        logo.width = 150
        logo.height = 76
        ' CAP THE DECODE. Without loadHeight this Poster held the logo at whatever
        ' resolution the provider sent - a 1000x1500 art file is ~6 MB of texture
        ' against a ~90 MB budget, and the guide draws one per channel row. It was
        ' the only uncapped texture decode left in the grid, on the exact screen
        ' small boxes were killed on (43R4AX, v1.0.32). Pinning the decode height
        ' to the 76 px it is drawn at is invisible on every box - scaleToFit still
        ' governs how it lays out - and stops the guide hoarding oversized art.
        ' loadHeight ALONE (not loadWidth), so a wide logo keeps its aspect.
        logo.loadHeight = 76
        logo.translation = [20, y + 12]
        logo.loadDisplayMode = "scaleToFit"

        ' Programme blocks (a locked row gets its cover instead — and no
        ' EPG request, since nothing of it would be shown).
        blocks = blocksForRow(r)
        for each b in blocks
            bx = m.gridX + Int((b.startS - m.windowStart) / 60) * m.pxPerMin - m.hOffset
            bw = Int((b.stopS - b.startS) / 60) * m.pxPerMin - 4
            ' Clip to the visible timeline
            bRight = bx + bw
            if bRight > m.gridX and bx < m.gridX + m.gridW
                clippedX = bx
                if clippedX < m.gridX
                    bw = bw - (m.gridX - clippedX)
                    clippedX = m.gridX
                end if
                if clippedX + bw > m.gridX + m.gridW then bw = m.gridX + m.gridW - clippedX
                if bw >= 12
                    focused = (m.focusArea = "grid" and r = m.cursorRow and cursorInBlock(b))
                    ' ---- ROUNDED PROGRAMME BLOCKS (owner's ruling, 2026-08-26)
                    '
                    ' "round the edges of the program tiles and give them the
                    ' same rounded borders as the home, with the blue outline
                    ' and orange highlighted." The blue outline is the frost
                    ' idle frame (theme.cardIdleBorder) that PosterCard and
                    ' ChannelCard already wear at rest; the orange highlight is
                    ' theme.focusHighlight, Nord's yellow.
                    '
                    ' WHY card_fill.9.png AND NOT card_round.9.png. The poster
                    ' card rounds itself with card_round - the corner NOTCHES,
                    ' tinted with the page background and laid over finished
                    ' artwork - because a photograph cannot be rounded and
                    ' there is nothing behind it to round instead. That trick
                    ' assumes flat page background behind the card, and on a
                    ' guide grid that assumption is not safe: the blocks abut
                    ' each other across a 4px gap, sit beside the logo cell's
                    ' own plate, and the red NOW line is drawn across them.
                    ' A guide block does not need the trick. It is a FLAT
                    ' COLOUR, exactly like the channel tile's plate, so the
                    ' block itself becomes the nine-patch and the corners are
                    ' real - nothing is painted back over anything and no
                    ' assumption about what is behind it is made at all.
                    '
                    ' WHAT IT COSTS IN CHARACTERS: NOTHING. card_edge.9.png is
                    ' a 3px stroke drawn ON the block's own outline, inside its
                    ' width, and the labels are already inset 14px from that
                    ' edge - so the frame eats 3 of the 14px of air the title
                    ' already had and none of the 148px it is drawn in. A
                    ' half-hour block is 176px wide, its label 148px, and at
                    ' JetBrains Mono Bold 19 (11.4px per character) that is 12
                    ' characters before and 12 characters after. The corner arc
                    ' is 8px in a corner the text never reaches.
                    '
                    ' TEXTURE: both files are 42x42 nine-patches, 7,056 bytes
                    ' each DECODED ONCE for the whole screen however many
                    ' blocks point at them - 14,112 bytes total against a ~90MB
                    ' budget. No new image files, nothing added to the 4MB zip.
                    '
                    ' NOT "both ways on every bind": these nodes are not
                    ' recycled. rebuildRows() calls clearRows() first and
                    ' creates every child fresh, so there is no previous state
                    ' to smear. The colours are still written on every branch
                    ' below because the next person to read this should not
                    ' have to know that.
                    if focused
                        ' The focus halo, unchanged in size and position - it
                        ' was a 4px solid outset Rectangle and it still is a 4px
                        ' solid outset, only rounded to match the block it
                        ' surrounds. Drawn first so the block paints over its
                        ' middle, exactly as before.
                        halo = rows.createChild("Poster")
                        halo.uri = "pkg:/images/card_fill.9.png"
                        halo.width = bw + 8
                        halo.height = m.rowH + 8
                        halo.translation = [clippedX - 4, y - 4]
                        halo.blendColor = m.theme.focusHighlight
                    end if
                    rect = rows.createChild("Poster")
                    rect.uri = "pkg:/images/card_fill.9.png"
                    rect.width = bw
                    rect.height = m.rowH
                    rect.translation = [clippedX, y]
                    airing = (b.startS <= nowSecs and b.stopS > nowSecs)
                    if airing
                        ' "On now", the one block in the grid that is louder
                        ' than the rest. It is QUIETER than it used to be and
                        ' that is deliberate: the old blue stood 3.4x off the
                        ' block beside it, surfaceAccent stands 1.87x. Nord's
                        ' Polar Night ramp is too compressed to give both a
                        ' 3.4x step and readable text on top — more frost in
                        ' the mix drops textPrimary to 4.6:1. If it stops
                        ' reading as "on now" on the television the answer is a
                        ' SECOND cue (a rule, a badge, a weight change), not a
                        ' brighter tint.
                        rect.blendColor = m.theme.surfaceAccent
                    else
                        rect.blendColor = m.theme.surfaceElevated
                    end if
                    ' The frame, ALWAYS ON. Frost at rest, focus colour when
                    ' the cursor is in this block - one blendColor write and no
                    ' reload, which is what certification 3.5's 250ms remote
                    ' answer needs. Same file, same 8px corner and same 3px
                    ' stroke the channel tiles and the Home posters wear, so
                    ' the three read as one set of cards.
                    edge = rows.createChild("Poster")
                    edge.uri = "pkg:/images/card_edge.9.png"
                    edge.width = bw
                    edge.height = m.rowH
                    edge.translation = [clippedX, y]
                    if focused
                        edge.blendColor = m.theme.focusHighlight
                    else
                        edge.blendColor = m.theme.cardIdleBorder
                    end if
                    if bw > 40
                        t = rows.createChild("Label")
                        t.text = b.title
                        t.font = labelFont
                        t.color = m.theme.textPrimary
                        t.translation = [clippedX + 14, y + 16]
                        t.width = bw - 28
                        t.height = 30
                        tm = rows.createChild("Label")
                        if b.doesExist("locked")
                            ' A locked row spans the whole window, so the
                            ' usual time range would read as a 12-hour
                            ' programme, and "no guide data" would be a lie.
                            tm.text = "Parental lock"
                        else if b.noData
                            tm.text = "No guide data available"
                        else
                            tm.text = timeRange(b.startS, b.stopS)
                        end if
                        tm.font = smallFont
                        tm.color = m.theme.textSecondary
                        tm.translation = [clippedX + 14, y + 52]
                        tm.width = bw - 28
                        tm.height = 26
                    end if
                end if
            end if
        end for
    end for

    rebuildTimeHeader()
    updateNowLine()
end sub

function cursorInBlock(b as object) as boolean
    return (b.startS <= m.cursorTime and b.stopS > m.cursorTime)
end function

function timeRange(startS as integer, stopS as integer) as string
    return clockText(startS) + " - " + clockText(stopS)
end function

function clockText(secs as integer) as string
    dt = CreateObject("roDateTime")
    dt.fromSeconds(secs)
    dt.toLocalTime()
    h = dt.getHours()
    mins = dt.getMinutes()
    ampm = "AM"
    if h >= 12 then ampm = "PM"
    h12 = h mod 12
    if h12 = 0 then h12 = 12
    mm = mins.toStr()
    if mins < 10 then mm = "0" + mm
    return h12.toStr() + ":" + mm + " " + ampm
end function

sub rebuildTimeHeader()
    hdr = m.top.findNode("timeHeader")
    while hdr.getChildCount() > 0
        hdr.removeChildIndex(0)
    end while
    ' Stays at 22: the text is always eight characters ("10:30 PM"), which is
    ' 106px of mono against a 180px half-hour slot.
    f = UiFont(22)
    slots = Int(m.gridW / m.slotPx) + 1
    firstSlot = m.windowStart + Int(m.hOffset / m.slotPx) * 1800
    for i = 0 to slots - 1
        lbl = hdr.createChild("Label")
        lbl.text = clockText(firstSlot + i * 1800)
        lbl.font = f
        lbl.color = m.theme.textSecondary
        lbl.translation = [i * m.slotPx - (m.hOffset mod m.slotPx), 0]
    end for
end sub

' How tall the marker runs: the core and both halves of the glow together.
' The arrow is left alone — it is a fixed cap on the top of the line.
sub setNowLineHeight(h as integer)
    ' layoutForSubStrip can be reached from a data callback, and a callback
    ' that arrives before init has finished would otherwise iterate invalid
    ' and take the render thread down with it.
    if m.nowLineBars = invalid then return
    for each bar in m.nowLineBars
        bar.height = h
    end for
end sub

sub updateNowLine()
    nowSecs = CreateObject("roDateTime").asSeconds()
    ' x is the left edge of the 3px core. Everything else in the marker is
    ' positioned relative to it inside the Group — the glow hangs 12px off
    ' each side and the arrow sits 12px above — so this one write moves the
    ' whole thing, glow and arrow included.
    x = 60 + m.gridX + Int((nowSecs - m.windowStart) / 60) * m.pxPerMin - m.hOffset
    if x >= 60 + m.gridX and x <= 60 + m.gridX + m.gridW
        m.nowLine.translation = [x, m.gridTop]
        ' The window starts at the PREVIOUS half hour, so for the first few
        ' minutes of one the line sits on the timeline's left edge and the
        ' glow would spill 12px over the channel logos beside it. A Group
        ' does not clip its children, so the left half is squeezed into
        ' whatever room it has instead: it is a gradient, so a narrower one
        ' still reaches the core at full strength and fades to nothing at the
        ' edge — it just fades faster. The right-hand half is left as it is:
        ' programme blocks are sized by runtime and already run off that edge
        ' for the screen to cut, so 12px of glow doing the same changes
        ' nothing about how the grid behaves there.
        room = x - (60 + m.gridX)
        glowW = 12
        if room < glowW then glowW = room
        m.nowGlowL.visible = (glowW > 0)
        if glowW > 0
            m.nowGlowL.width = glowW
            m.nowGlowL.translation = [-glowW, 0]
        end if
        m.nowLine.visible = true
    else
        m.nowLine.visible = false
    end if
end sub

' ---- Time-cursor navigation (the Android engine's rules) ---------------------

sub moveVertical(delta as integer)
    target = m.cursorRow + delta
    if target < 0 or target > m.channels.count() - 1 then return
    m.cursorRow = target
    if m.cursorRow < m.topRow then m.topRow = m.cursorRow
    if m.cursorRow > m.topRow + m.visibleRows - 1 then m.topRow = m.cursorRow - m.visibleRows + 1
    ' The cursor keeps its TIME on vertical moves — the timeline never
    ' shifts sideways, the defining rule of the Android engine.
    rebuildRows()
end sub

sub moveHorizontal(delta as integer)
    ' Its vertical twin has always bounds-checked; this one never did.
    if m.cursorRow < 0 or m.cursorRow >= m.channels.count() then return
    blocks = blocksForRow(m.cursorRow)
    idx = -1
    for i = 0 to blocks.count() - 1
        if cursorInBlock(blocks[i]) then idx = i
    end for
    if idx = -1 then idx = 0
    target = idx + delta
    if target < 0 or target > blocks.count() - 1 then return
    b = blocks[target]
    ' Land mid-block start: cursor time = block start (clamped to window)
    m.cursorTime = b.startS
    revealCursor(b)
    rebuildRows()
end sub

' Horizontal reveal: only ever expose the START of the show, snapped to a
' half-hour — pairing start+end reveal policies raced on Android (v1.0.65).
sub revealCursor(b as object)
    startPx = Int((b.startS - m.windowStart) / 60) * m.pxPerMin
    if startPx < m.hOffset
        m.hOffset = Int(startPx / m.slotPx) * m.slotPx
    else if startPx > m.hOffset + m.gridW - m.slotPx
        m.hOffset = Int((startPx - m.gridW + m.slotPx) / m.slotPx) * m.slotPx
        if m.hOffset < 0 then m.hOffset = 0
    end if
end sub

' ---- Watch dialog ------------------------------------------------------------

sub openProgramme()
    if m.cursorRow < 0 or m.cursorRow >= m.channels.count() then return
    ch = m.channels[m.cursorRow]
    ' Parental lock (mode "pin"): OK asks for the PIN instead of opening the
    ' watch dialog — the same thing pressing OK on a locked category does on
    ' the Live TV screen. Nothing about the programme is shown first.
    if rowLocked(m.cursorRow)
        promptGuidePin()
        return
    end if
    blocks = blocksForRow(m.cursorRow)
    current = invalid
    for each b in blocks
        if cursorInBlock(b) then current = b
    end for
    if current = invalid then return

    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = ch.name
    msg = current.title
    if not current.noData
        msg = msg + Chr(10) + timeRange(current.startS, current.stopS)
        if current.desc <> "" then msg = msg + Chr(10) + Chr(10) + current.desc
    end if
    dialog.message = msg
    ' "Channel page" is the guide's way through to the channel hub — the same
    ' third action Android's programme popup carries (epg_guide_screen.dart),
    ' where the logo, the live progress bar, what's up next, Favourite / Add to
    ' List and the next 24 hours all live. Watch stays first and stays the
    ' default, so nothing about pressing OK-OK changes.
    dialog.buttons = ["Watch", "Channel page", "Close"]
    dialog.observeField("buttonSelected", "onProgrammeDialog")
    m.top.getScene().dialog = dialog
end sub

sub onProgrammeDialog()
    try
        onProgrammeDialogInner()
    catch e
        ' No recovery beyond the log: this one can fault with the player
        ' part-built, and grabbing focus back would take it off a stream that
        ' did start. Left exactly as it was a moment before.
        GuardFailed("guide/onProgrammeDialog", e)
    end try
end sub

sub onProgrammeDialogInner()
    dialog = m.top.getScene().dialog
    choice = dialog.buttonSelected
    dialog.close = true
    if choice <> 0 and choice <> 1 then return
    ' The list can have been reloaded while the dialog was open.
    if m.cursorRow < 0 or m.cursorRow >= m.channels.count() then return
    ' ...and a reload can have put a locked category under the cursor, so the
    ' last word on whether this opens is here, next to the play call. The
    ' channel page is held to the SAME test as playback, not a softer one: it
    ' shows the channel's name, its logo and its whole next 24 hours, which is
    ' everything the cover on a locked row exists to withhold.
    if rowLocked(m.cursorRow)
        promptGuidePin()
        return
    end if
    ch = m.channels[m.cursorRow]
    if choice = 1
        openChannelPage(ch)
        return
    end if
    ' M3U channels carry their address; Xtream builds one from THEIR OWN
    ' source's login. Either way the live rewrite applies (.ts /
    ' extension-less -> .m3u8 — Roku is HLS-only).
    '
    ' >>> ONLY A PANEL CAN BUILD AN ADDRESS OUT OF A STREAM ID <<<
    '
    ' The `url = ""` above is a pre-check of the CHANNEL'S OWN address, not a
    ' guard on what comes back from XtreamLiveUrl — easy to misread as though
    ' this were already handled. The test added below is POSITIVE, naming the
    ' two source kinds that can build an address from a stream id, the shape
    ' HomeScreen.resumeOrNext uses (:1149). Not a list of exclusions: the old
    ' `<> "m3u"` style test is what let a media server reach a panel-only
    ' builder on the Home page and halted the app there.
    '
    ' Both fallbacks above can hand back the wrong KIND of source. An src
    ' token whose source has been removed resolves to invalid, and m.provider
    ' is ActiveProvider() — whatever happens to be first, which may be an
    ' ordinary playlist or a member's own Jellyfin.
    '
    ' LOG KEY FCF117 — Hisense 6Series-58, v1.0.39, 29 September 2026. What
    ' happened on the member's television, in plain words: they removed their
    ' source in Settings, a different one came back from the website on its
    ' own three seconds later, and the first channel they pressed Play on was
    ' a leftover from the source they had just taken out. The app reached for
    ' the source that had just arrived — an ordinary playlist, with no panel
    ' address to build a stream from — and the television froze with the
    ' spinner still turning and nothing on screen to say why. That one landed
    ' on the channel page; this is the same six lines in the Guide.
    '
    ' Util.brs now answers "" there rather than stopping the app, and an empty
    ' address is WORSE here than anywhere else: PlayerScreen.startPlayback
    ' returns on the spot for an empty streamUrl, so the Video node is never
    ' given anything, never errors, and the retry ladder and every error
    ' message it owns stay asleep. The member watches a spinner turn for ever.
    url = LivePlayUrl(ToStr(GetField(ch, "url")))
    if url = ""
        prov = ProviderForSrcToken(ToStr(GetField(ch, "src")))
        if prov = invalid then prov = m.provider
        pt = ""
        if prov <> invalid then pt = LCase(ToStr(prov.ptype))
        if pt = "xtream" or pt = "kwicktv"
            url = XtreamLiveUrl(prov, ch.streamId)
        end if
    end if
    ' BEFORE PushRecentChannel, and that ordering is the second half of this
    ' fix. Until now the row went into Recently Watched first, so a channel
    ' that never played for one second still turned up on the member's Home
    ' page as something they had watched — and pressing it there walked into
    ' the same dead end again.
    if url = ""
        cannotPlayNote(ToStr(GetField(ch, "name")))
        return
    end if
    PushRecentChannel(ch)
    m.player = m.top.getScene().createChild("PlayerScreen")
    m.player.titleText = ch.name
    m.player.channel = ch
    m.player.streamUrl = url
    m.player.streamFormat = "hls"
    m.player.isLive = true
    m.player.observeField("closed", "onPlayerClosed")
    m.player.setFocus(true)
    m.player.start = true
end sub

' ---- Channel page ------------------------------------------------------------

' The existing hand-off, not a new one: create ChannelDetailScreen on the
' scene, hand it the channel, observe `closed`, remove it again. That is
' exactly what HomeScreen.open() does for a channel tile, and it is the chain
' every screen in this app uses to push a detail page. ChannelDetailScreen
' itself is untouched — it already takes its own parental snapshot once when
' the channel arrives, and works out the source from the `src` token below.
'
' A plain COPY of the row, never the row itself: M3U channels are pushed by
' REFERENCE out of the shared session cache (see the note in init()), so
' handing one straight to another screen's interface field would put every
' other screen's copy on it too. GetField each way, because the two channel
' shapes this screen holds don't carry all the same keys.
sub openChannelPage(ch as object)
    m.detail = m.top.getScene().createChild("ChannelDetailScreen")
    m.detail.channel = {
        streamId: ToStr(GetField(ch, "streamId"))
        name: ToStr(GetField(ch, "name"))
        logo: ToStr(GetField(ch, "logo"))
        url: ToStr(GetField(ch, "url"))
        src: ToStr(GetField(ch, "src"))
    }
    m.detail.observeField("closed", "onDetailClosed")
    m.detail.setFocus(true)
end sub

sub onDetailClosed()
    try
        onDetailClosedInner()
    catch e
        GuardFailed("guide/onDetailClosed", e)
        m.top.setFocus(true)
    end try
end sub

sub onDetailClosedInner()
    if m.detail <> invalid
        m.top.getScene().removeChild(m.detail)
        m.detail = invalid
    end if
    ' Straight back to the grid, cursor and all — the guide was never rebuilt
    ' while the page was up, so there is nothing to restore.
    m.top.setFocus(true)
end sub

' ---- Parental PIN ------------------------------------------------------------
'
' The shared gate raises the pad and checks the answer (GuideMeta.brs); all
' this screen decides is what to do afterwards. A correct PIN unlocks every
' locked category for the rest of the session, exactly as it does from the
' Live TV screen.

sub promptGuidePin()
    ParentalShowPin(m.top, "onGuidePin", "onGuidePinCancel")
end sub

sub onGuidePin()
    try
        onGuidePinInner()
    catch e
        GuardFailed("guide/onGuidePin", e)
        m.top.setFocus(true)
    end try
end sub

sub onGuidePinInner()
    if ParentalAcceptPin()
        ' Rebuild the tabs from the categories ALREADY in hand — no source is
        ' asked again, so unlocking costs nothing on the network and nothing
        ' on the render thread beyond one re-merge. The paint guards have to
        ' be cleared first or mergeGuideCategories would refuse to run: it
        ' deliberately ignores a rebuild once the member has started browsing.
        m.painted = false
        m.userMoved = false
        mergeGuideCategories()
    else
        ParentalWrongPinNote(m.top, "onGuidePinNote")
    end if
end sub

sub onGuidePinCancel()
    try
        ParentalClosePin()
    catch e
        GuardFailed("guide/onGuidePinCancel", e)
    end try
    ' Outside the guard on purpose: whatever the pad did, the guide has to be
    ' able to answer the remote again.
    m.top.setFocus(true)
end sub

sub onGuidePinNote()
    try
        m.top.getScene().dialog.close = true
    catch e
        GuardFailed("guide/onGuidePinNote", e)
    end try
    ' Outside the guard, same reason as onGuidePinCancel.
    m.top.setFocus(true)
end sub

' ---- "Can't play this right now" --------------------------------------------
'
' The refusal MovieDetailScreen (:1384) and SeriesDetailScreen (:1116) already
' use when no source can open what was asked for: one Dialog, one OK button,
' focus handed back to the grid. Written out again rather than shared, because
' a component only ever sees the scripts its own XML names.
'
' The title and the message are WORD FOR WORD the ones ChannelDetailScreen and
' LiveTvScreen put up, because all three can be reached with the same channel
' and must never give it three different answers.
'
' LOG KEY FCF117: without this the member presses Play on a channel whose
' source is gone and gets a spinner that turns for ever — the player is handed
' an empty address, so it never even tries, never fails, and never says
' anything. A spinner that never stops is the worst of the three outcomes:
' there is nothing on screen to read and nothing to press.
sub cannotPlayNote(chName as string)
    KLog("guide", "refused play - no source on this box can open [" + chName + "]")
    note = CreateObject("roSGNode", "Dialog")
    note.title = "Can't Play This Right Now"
    note.message = "Kwick Player has no working source for this channel. It was probably left behind by a source you removed. Check your sources under Settings, or pick another channel."
    note.buttons = ["OK"]
    note.observeField("buttonSelected", "onCannotPlayNote")
    m.top.getScene().dialog = note
end sub

sub onCannotPlayNote()
    try
        m.top.getScene().dialog.close = true
    catch e
        GuardFailed("guide/onCannotPlayNote", e)
    end try
    ' Outside the guard, same reason as onGuidePinNote.
    m.top.setFocus(true)
end sub

sub onPlayerClosed()
    try
        onPlayerClosedInner()
    catch e
        GuardFailed("guide/onPlayerClosed", e)
        m.top.setFocus(true)
    end try
end sub

sub onPlayerClosedInner()
    if m.player <> invalid
        m.top.getScene().removeChild(m.player)
        m.player = invalid
    end if
    m.top.setFocus(true)
end sub

sub setBusy(b as boolean)
    m.spinner.visible = b
    if b
        m.spinner.control = "start"
    else
        m.spinner.control = "stop"
    end if
end sub

' ---- Keys --------------------------------------------------------------------

' THE CRASH THIS SCREEN IS KNOWN FOR - R4, and the app's biggest one in the
' field. Roku App Health, pulled from the Developer Dashboard on 2026-09-21
' for the seven days before, names this function four separate times: 4
' crashes on v1.0.38 at line 2621 across two devices, 1 on v1.0.37 at 2580, 5
' on v1.0.36 at 2444 on a single device, 1 on v1.0.34 at 2443. With
' redrawTabs' four that is 15 of the week's 31 field crashes on this screen
' alone, and 6.5% of the devices that opened the app that week had a crash.
' The v1.0.26 hardening put these wrappers on the CHANNEL page and never came
' near the guide, which is why R4 stayed open as "hardened, not proven fixed"
' while it went on happening.
'
' THE CAUSE IS FIXED IN init(), not here: m.tabNodes and m.tabFocus are born
' there now instead of only in buildTabs(), so a key arriving before the
' categories have merged no longer dereferences invalid. The full reasoning is
' in the comment beside them. This wrapper should therefore never fire again.
'
' It stays because a fix to one field is only as good as the next field
' somebody adds. A fault here now costs the member a single ignored press and
' leaves "crash averted in guide/onKeyEvent" in the log - naming the file, the
' line and the function - plus an armed report on the next launch, instead of
' the app dying with no stack at all.
'
' FALSE, NOT TRUE, ON A CAUGHT FAULT. The key bubbles up to AppShell, so Back
' still reaches Home and Left still reaches the sidebar. Returning true would
' swallow the member's only way off a guide that has started faulting - and
' AppShell acts on nothing else, so every other key is a no-op either way.
' This is deliberately not what ChannelDetailScreen.onKeyEvent does.
function onKeyEvent(key as string, press as boolean) as boolean
    try
        return onKeyEventInner(key, press)
    catch e
        GuardFailed("guide/onKeyEvent", e)
    end try
    return false
end function

function onKeyEventInner(key as string, press as boolean) as boolean
    if not press then return false
    ' Any press means the member is browsing — a late source must not
    ' rebuild the guide underneath them from here on.
    m.userMoved = true

    ' * (Options) is the shortcut into the channel filter from anywhere on the
    ' guide — the same button LiveTvScreen and Settings already use for their
    ' own per-screen action. The chip at the top right is the visible way in;
    ' this is the fast one. Never while the keyboard is already up.
    if key = "options"
        if m.kbDialog = invalid
            m.focusArea = "filter"
            redrawTabs()
            redrawSubTabs()
            redrawFilterBar()
            rebuildRows()       ' drops the grid's focus ring
            openFilterKeyboard()
        end if
        return true
    end if

    ' The filter chip, on the header line above the tabs.
    if m.focusArea = "filter"
        if key = "OK"
            openFilterKeyboard()
            return true
        else if key = "down"
            m.focusArea = "tabs"
            redrawFilterBar()
            redrawTabs()
            return true
        else if key = "left"
            ' Left is a DIRECTION. It still walks to the sidebar.
            m.top.backToNav = true
            return true
        else if key = "back"
            ' Back is an EXIT. Let it bubble to AppShell, which takes the
            ' member to Home in one press (AppShell.onKeyEvent, cert 4.6).
            ' Returned from INSIDE the branch so nothing below can eat it.
            return false
        else if key = "up" or key = "right"
            return true         ' nothing up there, and nothing to its right
        end if
        return false
    end if

    if m.focusArea = "tabs"
        if key = "right"
            if m.tabFocus < m.tabNodes.count() - 1
                m.tabFocus = m.tabFocus + 1
                redrawTabs()
            end if
            return true
        else if key = "left"
            if m.tabFocus > 0
                m.tabFocus = m.tabFocus - 1
                redrawTabs()
                return true
            end if
            m.top.backToNav = true
            return true
        else if key = "OK"
            if m.tabFocus <> m.bucketIdx then selectBucket(m.tabFocus)
            return true
        else if key = "down"
            if m.subStripOn
                m.focusArea = "subtabs"
                m.subFocus = m.subIdx
                redrawTabs()
                redrawSubTabs()
            else if m.channels.count() > 0
                m.focusArea = "grid"
                m.cursorTime = CreateObject("roDateTime").asSeconds()
                redrawTabs()
                rebuildRows()
            end if
            return true
        else if key = "up"
            ' Up out of the tabs is the filter chip on the header line.
            m.focusArea = "filter"
            redrawTabs()
            redrawFilterBar()
            return true
        else if key = "back"
            ' Back EXITS the screen — bubbles to AppShell, which goes to Home
            ' in one press. Left, above, still walks to the sidebar instead.
            return false
        end if
        return false
    end if

    ' Sub-menu strip — sits between the tabs and the grid when it's showing.
    if m.focusArea = "subtabs"
        if key = "right"
            if m.subFocus < m.subNodes.count() - 1
                m.subFocus = m.subFocus + 1
                redrawSubTabs()
            end if
            return true
        else if key = "left"
            if m.subFocus > 0
                m.subFocus = m.subFocus - 1
                redrawSubTabs()
                return true
            end if
            m.top.backToNav = true
            return true
        else if key = "OK"
            selectSubGroup(m.subFocus)
            return true
        else if key = "up"
            m.focusArea = "tabs"
            redrawTabs()
            redrawSubTabs()
            return true
        else if key = "down"
            if m.channels.count() > 0
                m.focusArea = "grid"
                m.cursorTime = CreateObject("roDateTime").asSeconds()
                redrawSubTabs()
                rebuildRows()
            end if
            return true
        else if key = "back"
            ' Back EXITS the screen — bubbles to AppShell, which goes to Home
            ' in one press. Left, above, still walks to the sidebar instead.
            return false
        end if
        return false
    end if

    ' Grid navigation.
    '
    ' Nothing below here survives an empty grid: every one of these paths
    ' indexes m.channels[m.cursorRow], and an out-of-range index on a
    ' BrightScript array is `invalid`, not an error — so the crash lands one
    ' line later inside renderedFor()/epgKeyFor() as a dereference, which is
    ' an EXIT_BRIGHTSCRIPT_CRASH with no clue where it came from.
    '
    ' Both doors into the grid check count() > 0 today, so this should be
    ' unreachable. It is a guard rather than a fix: a member's Roku Express
    ' died on this screen (key 1AB8C3, v1.0.25) and the tail could not say
    ' what they were doing, so anything on the path that can't defend itself
    ' gets to.
    if m.channels.count() = 0
        m.focusArea = "tabs"
        redrawTabs()
        rebuildRows()
        return true
    end if

    if key = "up"
        if m.cursorRow = 0
            if m.subStripOn
                m.focusArea = "subtabs"
                m.subFocus = m.subIdx
            else
                m.focusArea = "tabs"
            end if
            redrawTabs()
            redrawSubTabs()
            rebuildRows()
        else
            moveVertical(-1)
        end if
        return true
    else if key = "down"
        moveVertical(1)
        return true
    else if key = "left"
        blocks = blocksForRow(m.cursorRow)
        atFirst = true
        for i = 1 to blocks.count() - 1
            if cursorInBlock(blocks[i]) then atFirst = false
        end for
        if atFirst and m.hOffset <= 0
            m.top.backToNav = true
        else
            moveHorizontal(-1)
        end if
        return true
    else if key = "right"
        moveHorizontal(1)
        return true
    else if key = "OK"
        openProgramme()
        return true
    else if key = "back"
        m.focusArea = "tabs"
        redrawTabs()
        rebuildRows()
        return true
    end if
    return false
end function
