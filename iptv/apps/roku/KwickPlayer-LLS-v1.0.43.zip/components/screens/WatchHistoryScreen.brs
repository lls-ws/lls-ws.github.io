' Watch history — what this profile has watched, newest first, and a way to
' take one row off it.
'
' There was no such screen. The app knew every one of these facts — the player
' writes a title, a poster and a clock beside every resume point, and the
' recently-watched list has been feeding Home for as long as there has been a
' Home — but the only thing Settings could do with any of it was wipe it, and
' the row that said "Clear watch history" actually only cleared the channels.
' The phone has had this screen for a long time (watch_history_screen.dart).
'
' NOTHING NEW IS STORED. Every row here is assembled from what is already in
' the registry; see the note above LoadWatchHistory in Store.brs.
'
' IT DOES NOT PLAY ANYTHING, and that is deliberate rather than unfinished.
' Resuming a title needs its source's own address rebuilt from this box's
' provider config — the phone has a whole file for it (resume_from_history)
' because replaying a stored URL can mean replaying another device's panel
' login. Continue Watching on Home already does that job properly. This screen
' is for reading and tidying, and it says so rather than offering a button
' that would sometimes open a player and sometimes open nothing.

sub init()
    m.theme = KwickTheme()
    m.top.findNode("bg").color = m.theme.background
    ' This screen is a scene-level overlay, so its own backdrop covers
    ' AppScene's grid wash. See AddPageGrid() in Theme.brs — the mesh
    ' goes in at child 1, just above the backdrop declared first in the
    ' XML above, and under everything this screen draws.
    AddPageGrid(m.top)

    header = m.top.findNode("header")
    header.text = "Watch history"
    header.font = UiBoldFont(42)
    header.color = m.theme.textPrimary

    sf = UiFont(24)
    m.subhead = m.top.findNode("subhead")
    m.subhead.font = sf
    m.subhead.color = m.theme.textSecondary
    m.subhead.text = "Press OK on anything here to take it off the list."

    m.empty = m.top.findNode("empty")
    m.empty.font = sf
    m.empty.color = m.theme.textSecondary

    m.list = m.top.findNode("list")
    ' 1400px rows at 24 mono is 97 characters. The longest row is a title,
    ' an episode name, and the bracket carrying kind, time left and how
    ' long ago — about 95 at worst, so it fits with two characters to
    ' spare.
    '
    ' LEFT AT 24 ON PURPOSE, and the margin is thinner than it looks. The
    ' 95-character case needs a long film title AND an episode subtitle AND
    ' a full "(Series · 1h 23m left · 3 days ago)" bracket all at once,
    ' which may never actually render; dropping the whole list a point to
    ' cover it would cost every row legibility for one that might not
    ' exist. If it does turn up on the television the answer is 22, not a
    ' wider row — this list is already the widest in its family.
    ThemeLabelList(m.list, 24)
    m.list.observeField("itemSelected", "onSelected")

    m.rows = []
    m.actions = []
    m.actionIdx = -1
    m.multiSource = (SourceCount() > 1)
    m.top.observeField("focusedChild", "onFocusIn")
    load()
end sub

sub onFocusIn()
    if m.top.hasFocus() and m.rows.count() > 0 then m.list.setFocus(true)
end sub

sub load()
    m.rows = []
    ' Films and shows first, because they carry a real clock and can be put in
    ' a true order. Channels follow in the order the recents list holds them,
    ' which is already newest-first but has no date to print.
    for each h in LoadWatchHistory()
        label = ToStr(h.title)
        if label = "" then label = "Untitled"
        if ToStr(h.sub) <> "" then label = label + " — " + ToStr(h.sub)
        bits = kindWord(ToStr(h.kind))
        ' Not `left` — that is a reserved BrightScript word and naming a
        ' variable after one fails to compile on the device.
        remain = leftText(h.positionS, h.durationS)
        if remain <> "" then bits = bits + " · " + remain
        when_ = agoText(h.atMs)
        if when_ <> "" then bits = bits + " · " + when_
        m.rows.push({ kind: "vod", label: label + "   (" + bits + ")", key: ToStr(h.key) })
    end for
    for each c in LoadRecentChannels()
        nm = ToStr(c.name)
        if nm = "" then nm = "Channel " + ToStr(c.streamId)
        if m.multiSource
            tag = SourceLabelFor(ToStr(GetField(c, "src")))
            if tag <> "" then nm = nm + "   [" + tag + "]"
        end if
        m.rows.push({
            kind: "chan"
            label: nm + "   (Live TV)"
            streamId: ToStr(c.streamId)
            src: ToStr(GetField(c, "src"))
        })
    end for
    fillList()
end sub

sub fillList()
    if m.rows.count() = 0
        m.list.visible = false
        m.empty.visible = true
        m.empty.text = "Nothing watched yet. Films, shows and channels turn up here as you watch them."
        return
    end if
    m.list.visible = true
    m.empty.visible = false
    content = CreateObject("roSGNode", "ContentNode")
    for each r in m.rows
        content.createChild("ContentNode").title = r.label
    end for
    m.list.content = content
end sub

function kindWord(kind as string) as string
    if kind = "episode" then return "Series"
    return "Movie"
end function

' "42m left", the same measure the Resume button uses, and nothing at all when
' there is no duration to work from — providers do not always report one, and
' a made-up figure is worse than a missing one.
function leftText(positionS as integer, durationS as integer) as string
    if durationS <= 0 or positionS <= 0 then return ""
    leftS = durationS - positionS
    if leftS < 60 then return "finished"
    mins = Int(leftS / 60)
    if mins >= 60
        hrs = Int(mins / 60)
        return hrs.toStr() + "h " + (mins mod 60).toStr() + "m left"
    end if
    return mins.toStr() + "m left"
end function

' "2 days ago". `atMs` arrives EXACTLY as ParseJson handed it over and is
' milliseconds, which does not fit in the 32-bit integer ToInt() returns — so
' it is divided down to seconds first and only then treated as a whole number,
' which is the same trap and the same handling as mediaBarIdxPut in Store.brs.
' A row with no clock (written before the player started stamping them) simply
' says nothing about when.
function agoText(atMs as dynamic) as string
    if atMs = invalid then return ""
    secs = Int(atMs / 1000)
    if secs <= 0 then return ""
    d = CreateObject("roDateTime").asSeconds() - secs
    if d < 0 then return "just now"
    if d < 3600
        mins = Int(d / 60)
        if mins <= 1 then return "just now"
        return mins.toStr() + " min ago"
    end if
    if d < 86400
        h = Int(d / 3600)
        if h = 1 then return "1 hour ago"
        return h.toStr() + " hours ago"
    end if
    dd = Int(d / 86400)
    if dd = 1 then return "yesterday"
    if dd < 30 then return dd.toStr() + " days ago"
    mm = Int(dd / 30)
    if mm = 1 then return "a month ago"
    return mm.toStr() + " months ago"
end function

sub onSelected()
    idx = m.list.itemSelected
    if idx < 0 or idx >= m.rows.count() then return
    m.actionIdx = idx
    r = m.rows[idx]
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = r.label
    if r.kind = "vod"
        dialog.message = "Taking this off the list also forgets how far into it you were."
    else
        dialog.message = "This only takes the channel off the recently-watched list. It stays in Live TV, and your favorites are not touched."
    end if
    dialog.buttons = ["Remove from history", "Cancel"]
    ' House rule: a D-pad user can't click, so the primary action is focused.
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onAction")
    m.top.getScene().dialog = dialog
end sub

sub onAction()
    dialog = m.top.getScene().dialog
    remove = (dialog.buttonSelected = 0)
    dialog.close = true
    if remove and m.actionIdx >= 0 and m.actionIdx < m.rows.count()
        r = m.rows[m.actionIdx]
        if r.kind = "vod"
            RemoveWatchHistoryRow(r.key)
        else
            RemoveRecentChannel(r.streamId, r.src)
        end if
        KLog("settings", "watch history: removed one " + r.kind + " row")
        keep = m.actionIdx
        load()
        if keep > m.rows.count() - 1 then keep = m.rows.count() - 1
        if keep >= 0 then m.list.jumpToItem = keep
    end if
    if m.rows.count() > 0 then m.list.setFocus(true)
    m.top.setFocus(true)
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back" or key = "left"
        m.top.closed = true
        return true
    end if
    return false
end function
