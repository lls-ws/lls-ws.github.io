' "Who's watching?" — the profile picker. A centered row of square avatar
' tiles (colored initial + optional PIN badge) followed by an "Add Profile"
' tile, with a "Manage Profiles" action below. OK enters a profile (asking
' for its PIN first if locked); on entry it sets the active profile and fires
' "done" so the shell opens for that profile.

sub init()
    m.theme = KwickTheme()
    m.top.findNode("bg").color = m.theme.background
    ' This screen is a scene-level overlay, so its own backdrop covers
    ' AppScene's grid wash. See AddPageGrid() in Theme.brs — the mesh
    ' goes in at child 1, just above the backdrop declared first in the
    ' XML above, and under everything this screen draws.
    AddPageGrid(m.top)

    title = m.top.findNode("title")
    title.font = UiBoldFont(52)
    title.color = m.theme.textPrimary
    title.text = "Who's watching?"

    m.manageLabel = m.top.findNode("manage")
    m.manageLabel.font = UiFont(26)

    m.tilesGroup = m.top.findNode("tiles")
    m.pinDialog = invalid
    m.editor = invalid
    build()
end sub

' (Re)build the tile row from the current profile list.
sub build()
    while m.tilesGroup.getChildCount() > 0
        m.tilesGroup.removeChildIndex(0)
    end while

    m.profiles = EnsureDefaultProfile()
    ' Cells: one per profile, then the "Add Profile" tile.
    m.cellCount = m.profiles.count() + 1

    ' Tile size steps down as profiles pile up so the row never overflows.
    '
    ' The CAPTION size steps down with it, which it did not have to do in
    ' Roboto. The caption box is tile + 40 wide and maxLines = 1, so at the
    ' smallest tile it is only 160px; "Add Profile" is 11 characters, which
    ' is 154px in Roboto at 28 (fits, just) and 185px in JetBrains Mono at
    ' 28 (clipped). Dropping the point size with the tile keeps every step
    ' inside its own box.
    if m.cellCount <= 6
        tile = 190
        gap = 48
        capSize = 28   ' 11 chars = 185px in a 230px box
    else if m.cellCount <= 8
        tile = 150
        gap = 36
        capSize = 24   ' 11 chars = 158px in a 190px box
    else
        tile = 120
        gap = 28
        capSize = 20   ' 11 chars = 132px in a 160px box
    end if
    m.tileSize = tile

    total = m.cellCount * tile + (m.cellCount - 1) * gap
    startX = Int((1920 - total) / 2)
    y = 360

    initFont = UiBoldFont(Int(tile * 0.42))
    labelFont = UiFont(capSize)
    badgeFont = UiBoldFont(20)

    m.cells = []
    x = startX
    for i = 0 to m.cellCount - 1
        isAdd = (i = m.profiles.count())

        ring = m.tilesGroup.createChild("Rectangle")
        ring.width = tile + 10
        ring.height = tile + 10
        ring.translation = [x - 5, y - 5]
        ring.color = m.theme.focusHighlight
        ring.visible = false

        face = m.tilesGroup.createChild("Rectangle")
        face.width = tile
        face.height = tile
        face.translation = [x, y]

        glyph = face.createChild("Label")
        glyph.width = tile
        glyph.height = tile
        glyph.horizAlign = "center"
        glyph.vertAlign = "center"

        badge = invalid
        if isAdd
            face.color = m.theme.surfaceElevated
            glyph.font = initFont
            glyph.color = m.theme.textSecondary
            glyph.text = "+"
            name = "Add Profile"
        else
            p = m.profiles[i]
            face.color = ProfileColorAt(ToInt(p.color))
            glyph.font = initFont
            ' The ink follows the square. Three of the six avatar colours
            ' are light enough that white on them was under 2:1 — see
            ' ProfileInkAt() in Theme.brs for the measurements and the rule.
            ' Blue and purple keep white by Bram's ruling.
            glyph.color = ProfileInkAt(ToInt(p.color))
            nm = ToStr(p.name)
            if nm = "" then glyph.text = "?" else glyph.text = UCase(nm.left(1))
            name = nm
            ' Pack avatar (synced from any device) draws over the colored
            ' square; the initial stays underneath as the loading fallback.
            avUri = AvatarUri(ToStr(p.avatar))
            if avUri <> ""
                av = face.createChild("Poster")
                av.width = tile
                av.height = tile
                av.uri = avUri
                av.loadDisplayMode = "scaleToZoom"
            end if
            if ToStr(p.pin) <> ""
                badge = face.createChild("Rectangle")
                badge.width = 54
                badge.height = 32
                badge.color = "0x000000B0"
                badge.translation = [tile - 60, tile - 38]
                bl = badge.createChild("Label")
                bl.width = 54
                bl.height = 32
                bl.horizAlign = "center"
                bl.vertAlign = "center"
                bl.font = badgeFont
                bl.color = "0xFFFFFFFF"
                bl.text = "PIN"
            end if
        end if

        caption = m.tilesGroup.createChild("Label")
        caption.width = tile + 40
        caption.height = 40
        caption.translation = [x - 20, y + tile + 14]
        caption.horizAlign = "center"
        caption.font = labelFont
        caption.text = name
        caption.color = m.theme.textSecondary
        caption.maxLines = 1

        m.cells.push({ ring: ring, caption: caption, isAdd: isAdd, index: i })
        x = x + tile + gap
    end for

    ' Manage row is the last focusable stop, below the tiles.
    m.manageIdx = m.cellCount
    m.focusIdx = 0
    applyFocus()
end sub

sub applyFocus()
    for i = 0 to m.cells.count() - 1
        c = m.cells[i]
        on = (i = m.focusIdx)
        c.ring.visible = on
        if on then c.caption.color = m.theme.textPrimary else c.caption.color = m.theme.textSecondary
    end for
    onManage = (m.focusIdx = m.manageIdx)
    if onManage
        m.manageLabel.color = m.theme.focusHighlight
        m.manageLabel.text = "[ Manage Profiles ]"
    else
        m.manageLabel.color = m.theme.textSecondary
        m.manageLabel.text = "Manage Profiles"
    end if
end sub

' ---- Input ------------------------------------------------------------------

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false

    if key = "back"
        if m.top.allowBack = true
            m.top.cancelled = true
            return true
        end if
        return true ' at launch there's nowhere to go back to
    else if key = "left"
        if m.focusIdx > 0 and m.focusIdx <= m.manageIdx - 1
            m.focusIdx = m.focusIdx - 1
            applyFocus()
        end if
        return true
    else if key = "right"
        if m.focusIdx < m.manageIdx - 1
            m.focusIdx = m.focusIdx + 1
            applyFocus()
        end if
        return true
    else if key = "down"
        if m.focusIdx < m.manageIdx
            m.focusIdx = m.manageIdx
            applyFocus()
        end if
        return true
    else if key = "up"
        if m.focusIdx = m.manageIdx
            m.focusIdx = 0
            applyFocus()
        end if
        return true
    else if key = "OK"
        activate()
        return true
    else if key = "options"
        ' * on a profile tile opens its editor straight away (rename, color,
        ' avatar, PIN, delete — all live there).
        if m.focusIdx < m.profiles.count() then openEditor(m.profiles[m.focusIdx])
        return true
    end if
    return false
end function

sub activate()
    if m.focusIdx = m.manageIdx
        ' Manage Profiles: straight into the editor (first profile).
        if m.profiles.count() > 0 then openEditor(m.profiles[0])
        return
    end if
    if m.focusIdx = m.profiles.count()
        openEditor(invalid) ' Add Profile
        return
    end if
    p = m.profiles[m.focusIdx]
    if ToStr(p.pin) <> ""
        m.pinTarget = p
        promptPin()
    else
        enterProfile(p)
    end if
end sub

sub enterProfile(p as object)
    SetActiveProfileId(ToStr(p.id))
    m.top.done = true
end sub

' ---- PIN gate ---------------------------------------------------------------

sub promptPin()
    kb = CreateObject("roSGNode", "PinDialog")
    kb.title = "Enter profile PIN"
    kb.observeField("accepted", "onPin")
    kb.observeField("cancelled", "onPinCancel")
    m.pinDialog = kb
    ' The scene's dialog slot, not a child — see PinDialog.
    m.top.getScene().dialog = kb
end sub

sub removePin()
    if m.pinDialog <> invalid
        m.pinDialog.close = true
        m.pinDialog = invalid
    end if
end sub

sub onPin()
    entered = m.pinDialog.value
    removePin()
    p = m.pinTarget
    if ProfilePinHash(ToStr(p.syncId), entered) = ToStr(p.pin)
        enterProfile(p)
    else
        note = CreateObject("roSGNode", "Dialog")
        note.title = "Incorrect PIN"
        note.buttons = ["OK"]
        note.observeField("buttonSelected", "onPinNote")
        m.top.getScene().dialog = note
    end if
end sub

sub onPinCancel()
    removePin()
    m.top.setFocus(true)
end sub

sub onPinNote()
    m.top.getScene().dialog.close = true
    m.top.setFocus(true)
end sub

' ---- Edit -------------------------------------------------------------------

sub openEditor(p as dynamic)
    ed = m.top.getScene().createChild("ProfileEditorScreen")
    if p <> invalid then ed.profileId = ToStr(p.id)
    ed.observeField("closed", "onEditorClosed")
    m.editor = ed
    ed.setFocus(true)
    ed.launch = true  ' configured — now build
end sub

sub onEditorClosed()
    if m.editor <> invalid
        m.top.getScene().removeChild(m.editor)
        m.editor = invalid
    end if
    build()
    m.top.setFocus(true)
end sub
