' Hide & Reorder Categories — Live TV, Movies or Series, one screen for all
' three (the `scope` field says which).
'
' MASON'S RULING, 2026-09-15, verbatim: "under categories on roku in settings
' for ALL the hide menus we need a better system than scrolling through a list
' of sometimes 30k plus and hiding 1 by one. every hide/reorder/sort needs a
' revamp to a better system cause the roku one is not great."
'
' WHAT THIS USED TO BE: one list, and OK on a row opened a dialog with Move /
' Hide / Lock in it. Two presses and a modal to hide one category, and on a
' package with eighty of them that is eighty modals.
'
' WHAT IT IS NOW: two columns.
'   CATEGORIES   the list. OK puts a check on a row and takes it off again.
'                That is the only thing OK does here, so gathering ten
'                categories is ten presses and nothing else.
'   WHAT TO DO   every action, spelled out, always in the same place. Right
'                gets there from anywhere in the list and Left comes back.
'
' The actions column always opens on the single-category action for whichever
' row the highlight is on ("Hide this category" / "Show this category"), so
' the one-category case is still Right then OK — no worse than the old dialog
' and with nothing modal in the way.
'
' WHAT THE BULK ACTIONS COST. Hiding or showing a batch is ONE SetCatsHidden
' call, which is one read and one write of the hidden list however many
' categories are in it. The old screen paid a read and a write per category.
'
' NO REQUESTS EXCEPT THE ONE THIS SCREEN ALREADY MADE. The category list is
' fetched once when the screen opens, exactly as before. Nothing is fetched
' per row, per check or per keypress. The "N of M channels hidden" figure on a
' row comes from ChannelsHiddenInCategory, which needs no request — and it is
' worked out ONCE when the list loads, not on every redraw, because a redraw
' happens on every OK press and eighty registry reads inside one keypress
' would blow the 250 ms certification 3.5 allows.
'
' THAT FIGURE IS ONLY SHOWN WHERE IT IS FREE. It needs the source's channel
' list, and this screen has one only when the source is an M3U playlist on the
' Live TV scope — the playlist is already parsed in the session cache and its
' group titles are its categories. An Xtream source would mean fetching its
' whole live list just to print a number on a row, which is exactly the
' request this app does not make. Movies and Series have no channels at all.
'
' MOVING IS OFF WHILE A SEARCH IS ON, except Move to Top — unchanged, and for
' the same reason: "up one" inside a filtered list means up past categories
' that are not on screen, which is not what anybody pressing it is asking for.
' The top is the top either way, so that one stays.
'
' CERTIFICATION 6.3 AND THE PARENTAL LOCKS ARE UNTOUCHED. Adult categories
' never reach this editor unless the member has allowed them, and locking
' still refuses to do anything until a PIN exists.

sub init()
    m.theme = KwickTheme()
    m.top.findNode("bg").color = m.theme.background
    ' This screen is a scene-level overlay, so its own backdrop covers
    ' AppScene's grid wash. See AddPageGrid() in Theme.brs.
    AddPageGrid(m.top)

    header = m.top.findNode("header")
    header.text = m.top.titleText
    header.font = UiBoldFont(42)
    header.color = m.theme.textPrimary

    sf = UiFont(22)
    m.subhead = m.top.findNode("subhead")
    m.subhead.text = "Press OK to check a category. Then press Right and choose what to do with the ones you checked."
    m.subhead.font = sf
    m.subhead.color = m.theme.textSecondary

    m.note = m.top.findNode("note")
    m.note.font = sf
    m.note.color = m.theme.textSecondary

    m.catTitle = m.top.findNode("catTitle")
    m.actTitle = m.top.findNode("actTitle")
    m.catTitle.font = UiBoldFont(22)
    m.actTitle.font = UiBoldFont(22)
    m.catTitle.color = m.theme.textSecondary
    m.actTitle.color = m.theme.textSecondary

    ' MASON, 2026-09-15: "let's put 3 columns on panels instead of floating
    ' text." One plate per column, plus the low strip the footer line sits on.
    ' m.theme.surface is the colour SettingRow paints its row on
    ' (SettingRow.brs, rowBg and inner), so a plate here is the same material
    ' as a settings row and the app looks like one app.
    '
    ' Held by reference rather than looked up on every repaint: paintTitles
    ' runs on every key press and certification 3.5 gives us 250 ms to answer
    ' one.
    m.top.findNode("footerPanel").color = m.theme.surface
    m.panels = [
        { fill: m.top.findNode("catPanel"), wash: m.top.findNode("catWash"), rule: m.top.findNode("catRule"), pane: "cats" }
        { fill: m.top.findNode("actPanel"), wash: m.top.findNode("actWash"), rule: m.top.findNode("actRule"), pane: "acts" }
    ]
    ' The accent at 10% over the plate. Taken from the theme's own accent
    ' rather than written out, so a reskin carries it — the same line
    ' SettingsCategoryScreen.brs uses for the open group's wash.
    m.washColor = Left(m.theme.accent, 8) + "1A"

    m.list = m.top.findNode("list")
    m.actList = m.top.findNode("actList")
    ' 22 point on JetBrains Mono is a flat 13.2px a character: 81 characters
    ' across the 1080px list and 40 across the 528px actions column. Every
    ' label below is cut to those, because neither list wraps. (The actions
    ' column was 600 wide and 45 characters before the plates took their 24px
    ' inset out of it; its longest label is 35, so nothing is lost.)
    ThemeLabelList(m.list, 22)
    ThemeLabelList(m.actList, 22)
    m.list.observeField("itemFocused", "onCatFocused")
    m.list.observeField("itemSelected", "onSelected")
    m.actList.observeField("itemSelected", "onActSelected")

    m.spinner = m.top.findNode("spinner")
    m.spinner.poster.uri = "pkg:/images/spinner.png"

    m.provider = ActiveProvider()
    m.scope = m.top.scope
    m.cats = []
    m.view = []
    m.actRows = []
    m.checked = {}       ' category name -> true
    m.hidInCat = {}      ' category name -> how many of its channels are hidden
    m.catTotals = {}     ' category name -> how many channels it has
    m.query = ""
    m.catAt = 0
    m.moveMode = false
    m.moveId = ""
    m.pane = "cats"
    ' Set up front, not left invalid: comparing an unset member against a
    ' string or a boolean is a type mismatch, not a false.
    m.kbDialog = invalid
    m.kbEdit = invalid
    m.kbAction = ""
    m.kbClear = false
    m.top.observeField("focusedChild", "onFocusIn")
    ' Paint the plates NOW, in init, and not only when the categories arrive.
    ' A Rectangle's default is opaque white and visible, so a wash left
    ' unpainted until the fetch answers is two white blocks across the screen
    ' for as long as it takes.
    paintPanels()
    load()
end sub

function catActionFor() as string
    if m.scope = "movies" then return "get_vod_categories"
    if m.scope = "series" then return "get_series_categories"
    return "get_live_categories"
end function

sub onFocusIn()
    if m.top.hasFocus() then focusPane(m.pane)
end sub

sub focusPane(which as string)
    m.pane = which
    if which = "acts"
        m.actList.setFocus(true)
    else
        m.pane = "cats"
        m.list.setFocus(true)
    end if
    paintTitles()
end sub

' Which column the remote is in, painted rather than left to the row
' highlight alone — one highlight in grey is not obvious from a sofa. BOTH
' titles are written every time, so a column can never be left lit.
sub paintTitles()
    m.catTitle.text = "CATEGORIES"
    if m.query <> "" then m.catTitle.text = "CATEGORIES - searching " + cut(m.query, 24)
    m.actTitle.text = "WHAT TO DO"
    m.catTitle.color = m.theme.textSecondary
    m.actTitle.color = m.theme.textSecondary
    if m.pane = "acts"
        m.actTitle.color = m.theme.accent
    else
        m.catTitle.color = m.theme.accent
    end if
    paintPanels()
end sub

' The plate under the column the remote is in wears a 4px accent edge down its
' left side and a 10% accent wash over it, and the other wears neither.
'
' That is not a look invented here: it is what SettingsCategoryScreen puts
' round the settings group you have open. Reusing it means the app says "this
' is the one you are in" the same way everywhere, which is the whole point of
' Mason asking for panels in the first place.
'
' EVERY plate gets EVERY value on EVERY paint — fill colour, wash colour, wash
' visibility, rule colour, rule visibility. A wash that is only ever switched
' ON is how both columns end up lit at once, and this sub runs on every press.
sub paintPanels()
    for each p in m.panels
        lit = (m.pane = p.pane)
        p.fill.color = m.theme.surface
        p.wash.color = m.washColor
        p.wash.visible = lit
        p.rule.color = m.theme.accent
        p.rule.visible = lit
    end for
end sub

' ---- Loading ----------------------------------------------------------------

sub load()
    if m.provider = invalid then
        fillList([])
        fillActs()
        return
    end if
    m.spinner.visible = true
    m.spinner.control = "start"
    if m.provider.ptype = "m3u"
        ' M3U: only Live TV groups exist (playlists carry no movie/series
        ' catalog split) — derive the group titles from the playlist itself.
        if m.scope <> "live"
            m.spinner.visible = false
            m.spinner.control = "stop"
            fillList([])
            fillActs()
            return
        end if
        task = CreateObject("roSGNode", "M3uTask")
        task.url = m.provider.m3uUrl
        task.observeField("result", "onM3uCats")
        m.task = task
        task.control = "RUN"
        return
    end if
    task = CreateObject("roSGNode", "ApiTask")
    task.url = XtreamApiUrl(m.provider, catActionFor())
    task.observeField("result", "onCats")
    m.task = task
    task.control = "RUN"
end sub

' M3U playlists: group titles double as category ids (same convention as
' the Live TV screen).
sub onM3uCats(event as object)
    res = event.getData()
    m.spinner.visible = false
    m.spinner.control = "stop"
    if res = invalid or res.ok <> true
        fillList([])
        fillActs()
        return
    end if
    seen = {}
    raw = []
    byGroup = {}
    for each ch in ToArray(res.channels)
        g = ToStr(ch.group)
        if g = "" then g = "Uncategorized"
        if not seen.doesExist(g)
            seen[g] = true
            raw.push({ id: g, name: g })
            byGroup[g] = []
        end if
        byGroup[g].push(ToStr(GetField(ch, "streamId")))
    end for
    ' Adult categories never reach the editor either, so their names stay
    ' off screen (certification 6.3) — see the Adult block in GuideMeta.brs.
    m.cats = ApplyCatPrefs(m.scope, FilterAdultCats(raw), true)
    ' The "N of M channels hidden" figures, worked out ONCE here. See the
    ' header: a redraw happens on every OK press and this must not be paid
    ' again on each of them.
    countHiddenChannels(byGroup)
    fillList(m.cats)
    fillActs()
end sub

sub onCats(event as object)
    res = event.getData()
    m.spinner.visible = false
    m.spinner.control = "stop"
    if res = invalid or res.ok <> true
        ' A source that did not answer must still leave a screen somebody can
        ' read and back out of, rather than an empty page with no actions on
        ' it. The old screen returned here and left it blank.
        fillList([])
        fillActs()
        return
    end if
    ' Category prefs are NAME-keyed since the merged lineup — the editor
    ' must speak names too, or every toggle here would write panel ids
    ' into the name lists and match nothing anywhere. The id->name pairs
    ' still feed the cache (legacy-pref translation + Kwick Picks).
    raw = []
    cacheCats = []
    for each c in ToArray(res.data)
        cid = ToStr(GetField(c, "category_id"))
        nm = ToStr(GetField(c, "category_name"))
        if nm <> ""
            raw.push({ id: nm, name: nm })
            cacheCats.push({ id: cid, name: nm })
        end if
    end for
    if m.provider <> invalid then SaveCatNameCacheFor(m.scope, ToStr(m.provider.id), cacheCats)
    m.cats = ApplyCatPrefs(m.scope, FilterAdultCats(raw), true)  ' includeHidden = true
    ' No channel counts on this path, and deliberately: getting them would
    ' mean fetching the source's whole live list to print a number on a row.
    m.hidInCat = {}
    m.catTotals = {}
    fillList(m.cats)
    fillActs()
end sub

' One ChannelsHiddenInCategory call per category, no requests, once per load.
sub countHiddenChannels(byGroup as object)
    m.hidInCat = {}
    m.catTotals = {}
    if m.provider = invalid then return
    pid = ToStr(m.provider.id)
    for each c in m.cats
        nm = ToStr(c.name)
        ids = []
        if byGroup.doesExist(nm) then ids = byGroup[nm]
        m.catTotals[nm] = ids.count()
        m.hidInCat[nm] = ChannelsHiddenInCategory(pid, ids)
    end for
end sub

' ---- Drawing ----------------------------------------------------------------

' Cut a string to a character budget. Both columns are fixed and the font is
' fixed-width, so a label that does not fit does not wrap — it runs under the
' next column.
function cut(s as string, n as integer) as string
    if Len(s) <= n then return s
    if n <= 1 then return Left(s, n)
    return Left(s, n - 1) + "…"
end function

' m.cats is every category, in the order Live TV will show them; m.view is
' what is actually drawn — whichever categories match the search. Each drawn
' category remembers where it sits in the FULL list, because that is the
' position a move is measured against.
sub fillList(cats as object)
    m.cats = cats
    keepAt = m.list.itemFocused
    m.view = []
    q = LCase(m.query)
    for i = 0 to cats.count() - 1
        c = cats[i]
        nm = ToStr(c.name)
        if q <> "" and Instr(1, LCase(nm), q) = 0 then continue for
        ' EVERY marker is decided both ways on EVERY row. A marker only ever
        ' written in its "on" branch leaves the previous row's state behind it.
        mark = "[ ] "
        if m.checked.doesExist(nm) then mark = "[x] "
        if m.moveMode and nm = m.moveId then mark = "-> "
        tail = ""
        if c.hidden then tail = tail + "   (Hidden)"
        if c.locked = true then tail = tail + "   (Locked)"
        if m.hidInCat.doesExist(nm) and m.catTotals.doesExist(nm)
            total = m.catTotals[nm]
            hid = m.hidInCat[nm]
            if total > 0
                if hid > 0
                    tail = tail + "   " + hid.toStr() + " of " + total.toStr() + " channels hidden"
                else
                    tail = tail + "   " + total.toStr() + " channels"
                end if
            end if
        end if
        if m.moveMode and nm = m.moveId then tail = tail + "   (moving)"
        ' 81 characters across the 1080px list at 22 point mono.
        nameRoom = 81 - Len(mark) - Len(tail) - 5
        if nameRoom < 10 then nameRoom = 10
        label = mark + (i + 1).toStr() + ". " + cut(nm, nameRoom) + tail
        m.view.push({ kind: "cat", label: label, cat: c, at: i })
    end for
    if m.view.count() = 0
        empty = "There are no categories to show."
        if m.query <> "" then empty = "Nothing matches “" + m.query + "”."
        m.view.push({ kind: "none", label: empty })
    end if
    content = CreateObject("roSGNode", "ContentNode")
    for each v in m.view
        content.createChild("ContentNode").title = v.label
    end for
    m.list.content = content
    if keepAt < 0 then keepAt = 0
    if keepAt >= m.view.count() then keepAt = m.view.count() - 1
    if keepAt < 0 then keepAt = 0
    m.list.jumpToItem = keepAt
    m.catAt = keepAt
    paintNote()
    paintTitles()
end sub

function isFiltering() as boolean
    return m.query <> ""
end function

function currentView() as dynamic
    i = m.list.itemFocused
    if i < 0 or i >= m.view.count() then return invalid
    if m.view[i].kind <> "cat" then return invalid
    return m.view[i]
end function

function checkedCount() as integer
    n = 0
    for each k in m.checked
        if m.checked[k] = true then n = n + 1
    end for
    return n
end function

' Checked categories in the order the member sees them, so the list this
' screen sends matches the list it is looking at.
function checkedIds() as object
    ids = []
    for each c in m.cats
        nm = ToStr(c.name)
        if m.checked.doesExist(nm) then ids.push(nm)
    end for
    return ids
end function

function allCatIds() as object
    ids = []
    for each cat in m.cats
        ids.push(ToStr(cat.id))
    end for
    return ids
end function

' ---- The actions column -----------------------------------------------------
'
' Rebuilt from scratch every time anything changes, and EVERY row is decided
' both ways — a "Hide" that only ever becomes a "Show" when something is
' hidden is how a column starts lying about what it will do.
'
' 40 characters across the 528px column at 22 point mono. The longest label
' here is 35 ("Searching: " plus a 24-character query), so there are five
' characters of slack.

sub fillActs()
    rows = []
    v = currentView()
    n = checkedCount()

    if m.moveMode
        rows.push({ kind: "moveDone", label: "Drop it here" })
        rows.push({ kind: "moveTop", label: "Move it to the top" })
        rows.push({ kind: "moveCancel", label: "Stop moving" })
    else
        if v <> invalid
            if v.cat.hidden
                rows.push({ kind: "one", label: "Show this category" })
            else
                rows.push({ kind: "one", label: "Hide this category" })
            end if
        end if
        if n > 0
            rows.push({ kind: "hideChecked", label: "Hide the " + n.toStr() + " checked categories" })
            rows.push({ kind: "showChecked", label: "Show the " + n.toStr() + " checked categories" })
            rows.push({ kind: "lockChecked", label: "Lock the " + n.toStr() + " checked with a PIN" })
            rows.push({ kind: "unlockChecked", label: "Unlock the " + n.toStr() + " checked" })
            rows.push({ kind: "clearChecks", label: "Clear all checks" })
        end if
        if m.view.count() > 0 and m.view[0].kind = "cat"
            rows.push({ kind: "checkAll", label: "Check every category listed" })
        end if
        rows.push({ kind: "hideAll", label: "Hide every category" })
        rows.push({ kind: "showAll", label: "Show every category" })
        if v <> invalid
            if v.cat.locked = true
                rows.push({ kind: "lockOne", label: "Unlock this category" })
            else
                rows.push({ kind: "lockOne", label: "Lock this category with a PIN" })
            end if
            if v.at > 0 then rows.push({ kind: "moveTop", label: "Move this one to the top" })
            ' Moving by one step is off while a search is on — see the header.
            if not isFiltering() and m.cats.count() > 1
                rows.push({ kind: "moveStart", label: "Move this one with Up and Down" })
            end if
        end if
        if m.query = ""
            rows.push({ kind: "search", label: "Search the categories" })
        else
            rows.push({ kind: "search", label: "Searching: " + cut(m.query, 24) })
            rows.push({ kind: "clearSearch", label: "Stop searching" })
        end if
    end if

    m.actRows = rows
    content = CreateObject("roSGNode", "ContentNode")
    for each r in rows
        content.createChild("ContentNode").title = cut(r.label, 40)
    end for
    keepAt = m.actList.itemFocused
    if keepAt < 0 then keepAt = 0
    if keepAt >= rows.count() then keepAt = rows.count() - 1
    if keepAt < 0 then keepAt = 0
    m.actList.content = content
    m.actList.jumpToItem = keepAt
end sub

sub paintNote()
    bits = []
    n = checkedCount()
    if n > 0 then bits.push(n.toStr() + " categories checked")
    if m.moveMode then bits.push("Moving a category: Up and Down move it, OK drops it, Back stops")
    hiddenNow = 0
    for each c in m.cats
        if c.hidden then hiddenNow = hiddenNow + 1
    end for
    bits.push(m.cats.count().toStr() + " categories, " + hiddenNow.toStr() + " hidden")
    txt = ""
    for each b in bits
        if txt <> "" then txt = txt + ".   "
        txt = txt + b
    end for
    m.note.text = txt
    m.note.visible = true
end sub

' ---- Pressing OK ------------------------------------------------------------

' >>> THE GUARD IS "DID THE INDEX ACTUALLY CHANGE", NOT A BUSY FLAG. <<<
' Replacing a list's content resets its highlight to row 0 and fires this
' observer, and an observer does NOT necessarily run before the function that
' triggered it returns — so a flag set and cleared around the assignment is a
' fence the event steps over. Same test SeriesDetailScreen.onSeasonFocused
' uses.
sub onCatFocused()
    i = m.list.itemFocused
    if i = m.catAt then return
    m.catAt = i
    ' The first action names the category under the highlight, so the column
    ' has to follow it.
    fillActs()
end sub

' OK checks and unchecks. That is the whole point of the rebuild: gathering a
' batch has to be one press a category, and the single-category switch lives
' in the actions column where it names the row it will act on.
sub onSelected()
    if m.moveMode
        endMove()
        return
    end if
    i = m.list.itemSelected
    if i < 0 or i >= m.view.count() then return
    v = m.view[i]
    if v.kind <> "cat" then return
    nm = ToStr(v.cat.name)
    if m.checked.doesExist(nm)
        m.checked.delete(nm)
    else
        m.checked[nm] = true
    end if
    fillList(m.cats)
    m.list.jumpToItem = i
    fillActs()
    m.list.setFocus(true)
end sub

sub onActSelected()
    i = m.actList.itemSelected
    if i < 0 or i >= m.actRows.count() then return
    runAction(m.actRows[i].kind)
end sub

' ---- Doing the thing --------------------------------------------------------

sub runAction(kind as string)
    v = currentView()
    if kind = "one"
        if v = invalid then return
        setHidden([ToStr(v.cat.name)], not v.cat.hidden)
    else if kind = "hideChecked"
        setHidden(checkedIds(), true)
    else if kind = "showChecked"
        setHidden(checkedIds(), false)
    else if kind = "hideAll"
        setHidden(allCatIds(), true)
    else if kind = "showAll"
        setHidden(allCatIds(), false)
    else if kind = "checkAll"
        for each vw in m.view
            if vw.kind = "cat" then m.checked[ToStr(vw.cat.name)] = true
        end for
        fillList(m.cats)
        fillActs()
    else if kind = "clearChecks"
        m.checked = {}
        fillList(m.cats)
        fillActs()
    else if kind = "lockOne"
        if v = invalid then return
        setLocked([ToStr(v.cat.name)], v.cat.locked <> true)
    else if kind = "lockChecked"
        setLocked(checkedIds(), true)
    else if kind = "unlockChecked"
        setLocked(checkedIds(), false)
    else if kind = "moveTop"
        if v = invalid then return
        MoveCatToTop(m.scope, ToStr(v.cat.id), allCatIds())
        afterOrderChange(ToStr(v.cat.id))
    else if kind = "moveStart"
        if v = invalid then return
        m.moveMode = true
        m.moveId = ToStr(v.cat.name)
        fillList(m.cats)
        landOn(m.moveId)
        fillActs()
        m.pane = "cats"
        m.list.setFocus(true)
        paintTitles()
        return
    else if kind = "moveDone" or kind = "moveCancel"
        endMove()
        return
    else if kind = "search"
        openKeyboard()
        return
    else if kind = "clearSearch"
        m.query = ""
        fillList(m.cats)
        m.list.jumpToItem = 0
        fillActs()
    end if
    focusPane(m.pane)
end sub

' ONE call for the whole batch, whatever its size — one read and one write of
' the hidden list however many ids are in it.
sub setHidden(ids as object, hidden as boolean)
    if ids.count() = 0 then return
    SetCatsHidden(m.scope, ids, hidden)
    KLog("settings", "categories: " + hideWord(hidden) + " " + ids.count().toStr() + " category(s) in " + m.scope)
    ' Hiding is done, so the checks on those rows have served their purpose.
    for each idTxt in ids
        m.checked.delete(ToStr(idTxt))
    end for
    reload()
end sub

function hideWord(hidden as boolean) as string
    if hidden then return "hide"
    return "show"
end function

' Locking is meaningless without a PIN — send them to set one first. ToggleCatLocked
' is a toggle, so only the rows that are on the wrong side of the wanted state
' are touched: "Lock the 4 checked" must not unlock the two that already were.
sub setLocked(ids as object, wantLocked as boolean)
    if ids.count() = 0 then return
    if wantLocked and not HasParentalPin()
        note = CreateObject("roSGNode", "Dialog")
        note.title = "Set a PIN first"
        note.message = "Go to Settings -> Parental Controls and set a PIN before locking categories."
        note.buttons = ["OK"]
        note.observeField("buttonSelected", "onNoteClosed")
        m.top.getScene().dialog = note
        return
    end if
    changed = 0
    for each idTxt in ids
        nm = ToStr(idTxt)
        if IsCatLocked(m.scope, nm) <> wantLocked
            ToggleCatLocked(m.scope, nm)
            changed = changed + 1
        end if
    end for
    KLog("settings", "categories: changed the lock on " + changed.toStr() + " category(s) in " + m.scope)
    reload()
end sub

sub onNoteClosed()
    m.top.getScene().dialog.close = true
    focusPane(m.pane)
end sub

' ---- Moving -----------------------------------------------------------------

sub moveStep(delta as integer)
    if m.moveId = "" then return
    MoveCatBy(m.scope, m.moveId, allCatIds(), delta)
    afterOrderChange(m.moveId)
end sub

sub afterOrderChange(catId as string)
    reload()
    ' Follow the category that moved, so Up can be pressed twice without
    ' looking down at the remote to find the place again.
    landOn(catId)
    fillActs()
end sub

sub endMove()
    m.moveMode = false
    m.moveId = ""
    fillList(m.cats)
    fillActs()
    focusPane("cats")
end sub

sub landOn(nm as string)
    for i = 0 to m.view.count() - 1
        if m.view[i].kind = "cat" and ToStr(m.view[i].cat.name) = nm
            m.list.jumpToItem = i
            m.catAt = i
            return
        end if
    end for
    m.list.jumpToItem = 0
    m.catAt = 0
end sub

' Re-apply prefs to the current list without re-fetching. The channel counts
' are NOT recomputed: nothing on this screen changes which channels are
' hidden, only which categories are.
sub reload()
    raw = []
    for each c in m.cats
        raw.push({ id: c.id, name: c.name })
    end for
    m.cats = ApplyCatPrefs(m.scope, raw, true)
    fillList(m.cats)
    fillActs()
end sub

' ---- Search -----------------------------------------------------------------
' Roku's own StandardKeyboardDialog, exactly as the Search screen and the
' sign-in form use it — it brings the microphone and the "use your phone as a
' keyboard" affordance with it, and nothing new is drawn for it.

sub openKeyboard()
    kb = CreateObject("roSGNode", "StandardKeyboardDialog")
    kb.title = "Search categories"
    kb.text = m.query
    kb.buttons = ["Search", "Show all", "Cancel"]
    kb.keyboardDomain = "generic"
    edit = kb.textEditBox
    edit.voiceEnabled = true
    edit.voiceEntryType = kb.keyboardDomain
    edit.maxTextLength = 64
    m.kbDialog = kb
    m.kbEdit = edit
    m.kbAction = ""
    m.kbClear = false
    kb.observeField("buttonSelected", "onKeyboardButton")
    ' Back closes the dialog without going through a button at all, so focus
    ' has to come home from here as well as from the buttons.
    kb.observeField("wasClosed", "onKeyboardClosed")
    m.top.getScene().dialog = kb
end sub

sub onKeyboardButton()
    kb = m.kbDialog
    if kb = invalid then return
    if kb.buttonSelected = 0
        t = ToStr(kb.text)
        if t = "" and m.kbEdit <> invalid then t = ToStr(m.kbEdit.text)
        m.kbAction = cleanQuery(t)
    else if kb.buttonSelected = 1
        m.kbAction = ""
        m.kbClear = true
    end if
    kb.close = true
end sub

sub onKeyboardClosed()
    apply = (m.kbAction <> "" or m.kbClear = true)
    q = m.kbAction
    m.kbDialog = invalid
    m.kbEdit = invalid
    m.kbAction = ""
    m.kbClear = false
    if apply
        m.query = q
        fillList(m.cats)
        m.list.jumpToItem = 0
        fillActs()
    end if
    focusPane("cats")
end sub

' Speech comes back as a sentence and typing does not — Roku's dictation
' punctuates what it heard. Only the ENDS are stripped, exactly as on the
' Search screen, so a name with punctuation in the middle still matches.
function cleanQuery(raw as string) as string
    q = raw.trim()
    junk = ".,!?;:"
    while q.len() > 0 and junk.instr(q.right(1)) > -1
        q = q.left(q.len() - 1)
    end while
    while q.len() > 0 and junk.instr(q.left(1)) > -1
        q = q.mid(1)
    end while
    return q.trim()
end function

' ---- Keys -------------------------------------------------------------------
'
' The whole map:
'   OK        checks and unchecks a category, or does the action.
'   Right     from the list to the actions column.
'   Left      from the actions column back to the list; from the list, out of
'             the screen — which is what Left has always done here.
'   Back      out of the screen, or out of move mode if it is on.
'   Up / Down move the highlight, or move the category while move mode is on.
'
' Nothing is on the * key. A Roku remote has one spare key and no way to tell
' anybody it does anything.

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false

    if key = "back"
        if m.moveMode
            endMove()
            return true
        end if
        m.top.closed = true
        return true
    end if

    if m.moveMode
        ' While a category is being moved the arrows belong to it. Left and
        ' Right are swallowed too: stepping away mid-move would leave a row
        ' marked "(moving)" with nothing driving it.
        if key = "up"
            moveStep(-1)
            return true
        else if key = "down"
            moveStep(1)
            return true
        else if key = "left" or key = "right"
            return true
        end if
        return false
    end if

    if key = "left"
        if m.pane = "acts"
            focusPane("cats")
            return true
        end if
        m.top.closed = true
        return true
    else if key = "right"
        if m.pane = "cats"
            focusPane("acts")
            return true
        end if
        return true
    end if
    return false
end function
