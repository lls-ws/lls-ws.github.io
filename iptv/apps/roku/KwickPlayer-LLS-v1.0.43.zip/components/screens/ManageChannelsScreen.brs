' Hide & Reorder Channels.
'
' MASON'S RULING, 2026-09-15, verbatim: "under categories on roku in settings
' for ALL the hide menus we need a better system than scrolling through a list
' of sometimes 30k plus and hiding 1 by one. every hide/reorder/sort needs a
' revamp to a better system cause the roku one is not great."
'
' He is right, and the member log that prompted it says how right: 39,357
' channels in one list. The old screen was honest work — a search, a
' hidden-only filter, a switch on every row — but every one of those switches
' hid exactly one channel, and nobody is pressing OK thirty thousand times.
'
' WHAT REPLACED IT. Three columns, left to right in the order somebody
' actually works:
'
'   CATEGORIES   the chosen source's categories, in the order Live TV shows
'                them, each saying how many channels it holds and how many are
'                already hidden. Highlighting one loads its channels on the
'                right. OK is not needed to browse.
'   CHANNELS     that category's channels ONLY. Never the whole package. OK
'                puts a check on a row; checks survive moving between
'                categories so a member can gather a batch and apply it once.
'   WHAT TO DO   every action, in words, always in the same place. A Roku
'                remote has one spare key and no way to tell anybody it does
'                anything, so nothing lives on a key.
'
' THE ONE-PRESS SWITCH SURVIVES. The first action in the third column is
' always "Hide this channel" / "Show this channel" for whichever channel is
' highlighted, so hiding a single channel is still Right then OK — the same
' two presses the old dialog took.
'
' WHAT THE BULK ACTIONS COST THE REGISTRY. Hiding a batch is ONE call
' (SetChannelsHidden), which is one read and one write of that source's hidden
' set no matter how many channels are in the batch — where the old screen paid
' a read and a write per channel. Hiding a whole category is one SetCatsHidden
' call and costs ONE id, because a hidden category hides its channels without
' listing them. That is the cheap way to make a thirty-thousand-channel
' package small, and it is why the category column is the left-hand one.
'
' THE BUDGET IS PRINTED AT THE BOTTOM. The registry holds 16-32 KB for the
' WHOLE app and a write past it fails silently, so the hidden set has a
' ceiling. HiddenChannelCount() against HiddenChannelBudget() is shown in
' plain words at all times, and when the store refuses part of a batch its own
' reason — written for members — is put on screen unchanged and the checks are
' left on the rows that did not go through, so nothing is dropped in silence.
'
' WHERE THE CHANNELS COME FROM, AND THE REQUEST BUDGET. Unchanged in spirit
' from the old screen: every source is asked ONCE when the screen opens and
' never again while it is up. There is one addition — each Xtream source is
' also asked for its category list, the same small request Live TV makes every
' time it opens, because without it the left-hand column has numbers for names.
' That is two requests per Xtream source per screen open, both at open. There
' is no request per category, per row, per check or per keypress, and switching
' source chips costs nothing because every source was already fetched.
'
' M3U sources cost nothing at all: their playlist is already parsed in the
' session cache, and a playlist's group titles ARE its categories.
'
' WHY THE RIGHT-HAND COLUMN REFILLS ON A DWELL. Moving down the category list
' would otherwise rebuild up to a thousand rows on every press, and
' certification 3.5 gives us 250 ms to answer one. So the category highlight
' and the channel column's heading move instantly, and the rows themselves are
' built a fraction of a second after the member stops moving — or immediately
' if they press Right, because then they are asking for them.
'
' ADULT AND LOCKED CATEGORIES ARE UNTOUCHED BY ALL OF THIS. Adult categories
' are dropped unless the member has allowed them (certification 6.3), and a
' locked category is listed but its channels are not, exactly as everywhere
' else in the app.

sub init()
    m.theme = KwickTheme()
    m.top.findNode("bg").color = m.theme.background
    ' This screen is a scene-level overlay, so its own backdrop covers
    ' AppScene's grid wash. See AddPageGrid() in Theme.brs.
    AddPageGrid(m.top)

    header = m.top.findNode("header")
    header.text = "Hide & Reorder Channels"
    header.font = UiBoldFont(42)
    header.color = m.theme.textPrimary

    sf = UiFont(22)
    m.subhead = m.top.findNode("subhead")
    m.subhead.font = sf
    m.subhead.color = m.theme.textSecondary
    m.subhead.text = "Pick a category on the left, check the channels you want in the middle, then choose what to do on the right."

    m.note = m.top.findNode("note")
    m.note.font = sf
    m.note.color = m.theme.textSecondary
    m.budget = m.top.findNode("budget")
    m.budget.font = sf
    m.budget.color = m.theme.textSecondary

    m.catTitle = m.top.findNode("catTitle")
    m.chanTitle = m.top.findNode("chanTitle")
    m.actTitle = m.top.findNode("actTitle")
    for each t in [m.catTitle, m.chanTitle, m.actTitle]
        t.font = UiBoldFont(22)
        t.color = m.theme.textSecondary
    end for

    ' MASON, 2026-09-15: "let's put 3 columns on panels instead of floating
    ' text." One plate per column, plus the low strip the two footer lines
    ' sit on. m.theme.surface is the colour SettingRow paints its row on
    ' (SettingRow.brs, rowBg and inner), so a plate here is the same material
    ' as a settings row and the app looks like one app.
    '
    ' Held by reference rather than looked up on every repaint: mcPaintTitles
    ' runs on every key press and certification 3.5 gives us 250 ms to answer
    ' one.
    m.top.findNode("footerPanel").color = m.theme.surface
    m.panels = [
        { fill: m.top.findNode("catPanel"), wash: m.top.findNode("catWash"), rule: m.top.findNode("catRule"), pane: "cats" }
        { fill: m.top.findNode("chanPanel"), wash: m.top.findNode("chanWash"), rule: m.top.findNode("chanRule"), pane: "chans" }
        { fill: m.top.findNode("actPanel"), wash: m.top.findNode("actWash"), rule: m.top.findNode("actRule"), pane: "acts" }
    ]
    ' The accent at 10% over the plate. Taken from the theme's own accent
    ' rather than written out, so a reskin carries it — the same line
    ' SettingsCategoryScreen.brs uses for the open group's wash.
    m.washColor = Left(m.theme.accent, 8) + "1A"

    m.catList = m.top.findNode("catList")
    m.chanList = m.top.findNode("chanList")
    m.actList = m.top.findNode("actList")
    ' 22 point on JetBrains Mono is a flat 13.2px a character. The columns are
    ' 548, 640 and 348 inside their plates, so they hold 41, 48 and 26
    ' characters. Every label this screen builds is cut to those figures
    ' rather than left to run under the next column. (They were 46, 53 and 28
    ' before the plates: the 24px inset on each side of each plate has to come
    ' from somewhere, and it comes from here.)
    ThemeLabelList(m.catList, 22)
    ThemeLabelList(m.chanList, 22)
    ThemeLabelList(m.actList, 22)
    m.catList.observeField("itemFocused", "mcOnCatFocused")
    m.catList.observeField("itemSelected", "mcOnCatSelected")
    m.chanList.observeField("itemFocused", "mcOnChanFocused")
    m.chanList.observeField("itemSelected", "mcOnChanSelected")
    m.actList.observeField("itemSelected", "mcOnActSelected")

    m.spinner = m.top.findNode("spinner")
    m.spinner.poster.uri = "pkg:/images/spinner.png"

    ' Channel management is live-only - see LiveProviders().
    m.sources = LiveProviders()
    m.multiSource = (m.sources.count() > 1)
    m.srcIdx = 0
    m.chipNodes = []

    m.parts = {}        ' provId -> [{ streamId, name, catId, provId, src }]
    m.catNames = {}     ' provId -> { catId: name }
    m.catOrder = {}     ' provId -> [catId] in the order the panel gave them
    m.need = 0
    m.inflight = {}

    m.allChans = []     ' the CURRENT source's channels, in member order
    m.cats = []         ' [{ id, name, hidden, locked, idxs, hidCount }]
    m.catAt = 0
    m.keepCat = {}      ' category name -> true, for the ones that may be listed
    m.hiddenNow = {}    ' streamId -> true, the current source's hidden set
    m.checked = {}      ' streamId -> true
    m.chanRows = []
    m.actRows = []
    m.catActions = []
    m.chanAt = -1
    m.chanOver = 0
    m.query = ""
    m.hiddenOnly = false
    m.moveMode = false
    m.moveId = ""
    m.pane = "cats"

    m.kbDialog = invalid
    m.kbEdit = invalid
    ' Set up front, not left invalid: `m.kbAction <> ""` on an unset member is
    ' a type mismatch, not a false.
    m.kbAction = ""
    m.kbClear = false
    m.letterBtns = []

    ' The dwell that keeps the category column answering inside 250 ms. While
    ' presses keep arriving it keeps going back to the start and nothing is
    ' rebuilt; see the note at the top of this file.
    m.catDwell = CreateObject("roSGNode", "Timer")
    m.catDwell.duration = 0.18
    m.catDwell.repeat = false
    m.catDwell.observeField("fire", "mcOnCatDwell")

    mcLayout()
    m.top.observeField("focusedChild", "onFocusIn")
    mcLoad()
end sub

sub onFocusIn()
    if m.top.hasFocus() then mcFocusPane(m.pane)
end sub

' THE WHOLE VERTICAL STORY, in one place.
'
' The plates always END at 912, because the footer strip always starts at 936
' and the two are 24 apart like everything else. Where they START depends on
' whether there is a chip row above them, and that is the only difference
' between the two cases:
'
'   more than one source   chips 134..194, plates 202..912, 11 rows of 56
'   exactly one source     no chips,       plates 148..912, 12 rows of 56
'
' Inside a plate: 24 to the heading, 44 more to the first row, 24 under the
' last one. The old screen fitted 12 rows in both cases because it had no
' padding to pay for; a plate with a 24px inset costs about a row and a half,
' and that is the trade Mason asked for when he asked for the panels.
sub mcLayout()
    chips = m.top.findNode("srcChips")
    chips.visible = m.multiSource
    if m.multiSource
        panelTop = 202
        rows = 11
    else
        panelTop = 148
        rows = 12
    end if
    panelH = 912 - panelTop
    ' The x of every node below is set in the XML and never touched here — the
    ' columns are where they are, only their tops and heights move.
    for each idName in ["catPanel", "catWash", "catRule", "chanPanel", "chanWash", "chanRule", "actPanel", "actWash", "actRule"]
        node = m.top.findNode(idName)
        tr = node.translation
        node.translation = [tr[0], panelTop]
        node.height = panelH
    end for
    for each idName in ["catTitle", "chanTitle", "actTitle"]
        node = m.top.findNode(idName)
        tr = node.translation
        node.translation = [tr[0], panelTop + 24]
    end for
    for each idName in ["catList", "chanList", "actList"]
        node = m.top.findNode(idName)
        tr = node.translation
        node.translation = [tr[0], panelTop + 68]
        node.numRows = rows
    end for
    ' Paint them NOW, in init, and not only when the first list arrives. A
    ' Rectangle's default is opaque white and visible, so a wash left unpainted
    ' until the sources answer is three white blocks across the screen for as
    ' long as the fetch takes.
    mcPaintPanels()
end sub

' How many channel rows are drawn at once.
'
' There is a limit because there has to be one: every drawn row is a
' ContentNode the box has to build and hold, and "All channels in this source"
' can be tens of thousands. A member past this many is not scrolling to number
' 1,400 on a remote — they are picking a category or searching, and both of
' those narrow the list below the cap immediately.
function mcMaxRows() as integer
    return 1000
end function

' ---- The source chips -------------------------------------------------------
' Same pill nine-patch the VOD chips use (images/pill.9.png, 68 x 68, 18,496
' bytes of texture shared by every pill on the row). No dots here: this is a
' management screen and only one source can be worked on at a time, so the
' selected fill is the only state the row has to carry.

sub mcBuildChips()
    if not m.multiSource then return
    chips = m.top.findNode("srcChips")
    while chips.getChildCount() > 0
        chips.removeChildIndex(0)
    end while
    m.chipNodes = []
    ' Measured first, then placed: a row cannot be centred until its total
    ' width is known, and measuring it twice is how the two answers drift.
    gapW = 16
    labels = []
    widths = []
    total = 0
    for each p in m.sources
        lbl = mcCut(ToStr(p.name), 14)
        labels.push(lbl)
        probe = CreateObject("roSGNode", "Label")
        probe.font = UiBoldFont(22)
        probe.text = lbl
        w = Int(probe.boundingRect().width) + 44
        if w < 72 then w = 72
        widths.push(w)
        total = total + w
    end for
    total = total + gapW * (m.sources.count() - 1)
    cx = Int((1920 - total) / 2)
    ' 96 is the left edge of Roku's 5% title-safe box and the left edge of the
    ' first plate, so a wide chip row lines up with the columns under it.
    if cx < 96 then cx = 96
    for i = 0 to m.sources.count() - 1
        ring = chips.createChild("Poster")
        ring.uri = "pkg:/images/pill.9.png"
        ring.width = widths[i] + 12
        ' 60/48 where this was 68/56. The plates below need every pixel they
        ' can get for their inner padding, and a pill 8px shorter is not
        ' something anybody notices from a sofa — a row two channels shorter
        ' is. Same nine-patch, so no change to the texture cost: pill.9.png is
        ' 68 x 68, 18,496 bytes, shared by every pill on the row.
        ring.height = 60
        ring.translation = [cx - 6, -6]
        pill = chips.createChild("Poster")
        pill.uri = "pkg:/images/pill.9.png"
        pill.width = widths[i]
        pill.height = 48
        pill.translation = [cx, 0]
        txt = chips.createChild("Label")
        txt.text = labels[i]
        txt.font = UiBoldFont(22)
        txt.width = widths[i]
        txt.height = 48
        txt.horizAlign = "center"
        txt.vertAlign = "center"
        txt.translation = [cx, 0]
        m.chipNodes.push({ ring: ring, pill: pill, lbl: txt })
        cx = cx + widths[i] + gapW
    end for
    mcRedrawChips()
end sub

' EVERY chip gets EVERY value written on EVERY redraw — fill, label colour and
' ring visibility, both ways. A chip that is only ever told when it is ON
' keeps the last state it was given and the row ends up with two selections.
sub mcRedrawChips()
    for i = 0 to m.chipNodes.count() - 1
        c = m.chipNodes[i]
        c.ring.blendColor = m.theme.focusHighlight
        c.ring.visible = (m.pane = "chips" and i = m.srcIdx)
        if i = m.srcIdx
            c.pill.blendColor = m.theme.accent
            ' The page colour, not white: on Nord Shell the accent is a light
            ' frost and white on it is under 2:1. See redrawModeTabs in
            ' VodScreen.brs, which had the same problem.
            c.lbl.color = m.theme.background
        else
            c.pill.blendColor = m.theme.surfaceElevated
            c.lbl.color = m.theme.textSecondary
        end if
    end for
end sub

' ---- Loading ----------------------------------------------------------------
' Every source, once, when the screen opens. Nothing here runs again while the
' screen is up: switching chips reads what is already in hand.

sub mcLoad()
    m.spinner.visible = true
    m.spinner.control = "start"
    mcBuildChips()
    m.parts = {}
    m.catNames = {}
    m.catOrder = {}
    m.need = 0
    slots = {}
    if m.global <> invalid and m.global.hasField("m3uByProv") then slots = m.global.m3uByProv
    for each p in m.sources
        pid = ToStr(p.id)
        if ToStr(p.ptype) = "m3u"
            ' A playlist's group titles ARE its categories, and it is already
            ' parsed — this source costs no request at all.
            part = []
            names = {}
            order = []
            if slots.doesExist(pid)
                for each ch in slots[pid].channels
                    g = ToStr(GetField(ch, "group"))
                    if g = "" then g = "Uncategorized"
                    if not names.doesExist(g)
                        names[g] = g
                        order.push(g)
                    end if
                    part.push({
                        streamId: ToStr(GetField(ch, "streamId"))
                        name: ToStr(GetField(ch, "name"))
                        catId: g
                        provId: pid
                        src: SrcTokenFor(p)
                    })
                end for
            end if
            m.parts[pid] = part
            m.catNames[pid] = names
            m.catOrder[pid] = order
        else
            ' Two requests, both at open: the whole live list and the small
            ' category list. Without the second the left-hand column would be
            ' a column of panel numbers.
            m.need = m.need + 2
            chanTask = CreateObject("roSGNode", "ApiTask")
            chanTask.tag = pid
            chanTask.url = XtreamApiUrl(p, "get_live_streams")
            chanTask.observeField("result", "mcOnChannels")
            ' Held by key: several sources answer at their own pace and a task
            ' with nothing referring to it can be collected mid-request.
            m.inflight["chan_" + pid] = chanTask
            chanTask.control = "RUN"

            catTask = CreateObject("roSGNode", "ApiTask")
            catTask.tag = pid
            catTask.url = XtreamApiUrl(p, "get_live_categories")
            ' Same grace the other screens give this call: several sources
            ' fetch at once and this one gates the names.
            catTask.timeoutMs = 60000
            catTask.observeField("result", "mcOnCats")
            m.inflight["cat_" + pid] = catTask
            catTask.control = "RUN"
        end if
    end for
    if m.need <= 0 then mcAssemble()
end sub

sub mcOnChannels(event as object)
    pid = ToStr(event.getRoSGNode().tag)
    m.inflight.delete("chan_" + pid)
    res = event.getData()
    prov = mcProviderById(pid)
    chans = []
    if res <> invalid and res.ok = true and prov <> invalid
        token = SrcTokenFor(prov)
        for each s in ToArray(res.data)
            cid = ToStr(GetField(s, "category_id"))
            if cid = ""
                ' Some panels answer with a list instead of a single id. The
                ' first one is the one every other screen in this app uses.
                many = GetField(s, "category_ids")
                if many <> invalid and Type(many) = "roArray" and many.count() > 0
                    cid = ToStr(many[0])
                end if
            end if
            chans.push({
                streamId: ToStr(GetField(s, "stream_id"))
                name: ToStr(GetField(s, "name"))
                catId: cid
                provId: pid
                src: token
            })
        end for
    end if
    m.parts[pid] = chans
    m.need = m.need - 1
    if m.need <= 0 then mcAssemble()
end sub

sub mcOnCats(event as object)
    pid = ToStr(event.getRoSGNode().tag)
    m.inflight.delete("cat_" + pid)
    res = event.getData()
    names = {}
    order = []
    cacheCats = []
    if res <> invalid and res.ok = true
        for each c in ToArray(res.data)
            cid = ToStr(GetField(c, "category_id"))
            nm = ToStr(GetField(c, "category_name"))
            if cid <> "" and nm <> ""
                names[cid] = nm
                order.push(cid)
                cacheCats.push({ id: cid, name: nm })
            end if
        end for
        ' Keep this source's id->name cache warm, guarded exactly as Live TV
        ' guards it: a panel having a bad minute and answering with eleven
        ' categories where the member has hundreds must not overwrite the
        ' table the parental locks and the hide lists translate through. Same
        ' helper, not a second copy of the rule, and no dialog — the member
        ' opened a screen, they did not ask a question.
        offered = cacheCats.count()
        stored = CachedCategoryCount("live", pid)
        if IsDestructiveChannelShrink(stored, offered)
            KLog("settings", "manage channels: source " + pid + " offered " + offered.toStr() + " categories where " + stored.toStr() + " are cached - keeping the cached names")
        else
            SaveCatNameCacheFor("live", pid, cacheCats)
        end if
    end if
    m.catNames[pid] = names
    m.catOrder[pid] = order
    m.need = m.need - 1
    if m.need <= 0 then mcAssemble()
end sub

function mcProviderById(pid as string) as dynamic
    for each p in m.sources
        if ToStr(p.id) = pid then return p
    end for
    return invalid
end function

sub mcAssemble()
    m.spinner.visible = false
    m.spinner.control = "stop"
    mcSelectSource(m.srcIdx)
    KLog("settings", "manage channels: " + m.sources.count().toStr() + " source(s) loaded, showing " + m.allChans.count().toStr() + " channel(s)")
    mcFocusPane("cats")
end sub

' ---- The chosen source ------------------------------------------------------

function mcProvId() as string
    if m.srcIdx < 0 or m.srcIdx >= m.sources.count() then return ""
    return ToStr(m.sources[m.srcIdx].id)
end function

sub mcSelectSource(idx as integer)
    if idx < 0 then idx = 0
    if idx >= m.sources.count() then idx = m.sources.count() - 1
    m.srcIdx = idx
    pid = mcProvId()
    merged = []
    if m.parts.doesExist(pid)
        for each c in m.parts[pid]
            if ToStr(c.streamId) <> "" then merged.push(c)
        end for
    end if
    mode = ChannelSort()
    if mode = "az" or mode = "za" then mcSortByName(merged, mode = "za")
    ' The member's own running order, so this screen lists channels in exactly
    ' the order Live TV will — the only order in which "move this one up"
    ' means anything. Hidden channels are KEPT: a screen for unhiding
    ' something cannot start by hiding it.
    m.allChans = applyChanOrder(merged)
    ' Checks belong to one source's hidden set, because that is what one bulk
    ' call can write. Changing source starts a clean batch.
    m.checked = {}
    m.query = ""
    m.hiddenOnly = false
    m.moveMode = false
    m.moveId = ""
    m.catAt = 0
    mcLoadHidden()
    mcBuildCats()
    mcFillCats()
    mcFillChans()
    mcResetChanTop()
    mcFillActs()
    mcRedrawChips()
end sub

' Same insertion sort by lowercased name Store.brs uses on channel lists, and
' the same reason: it is the sort that cannot get an index wrong.
sub mcSortByName(arr as object, descending as boolean)
    for i = 1 to arr.count() - 1
        cur = arr[i]
        curName = LCase(ToStr(cur.name))
        j = i - 1
        while j >= 0
            cmpName = LCase(ToStr(arr[j].name))
            swap = false
            if descending then swap = (cmpName < curName) else swap = (cmpName > curName)
            if not swap then exit while
            arr[j + 1] = arr[j]
            j = j - 1
        end while
        arr[j + 1] = cur
    end for
end sub

' The hidden set is read ONCE per redraw, not once per channel: IsChannelHidden
' is a registry read and a JSON parse every time it is called, and a thousand
' rows would mean a thousand of each.
sub mcLoadHidden()
    m.hiddenNow = {}
    pid = mcProvId()
    if pid = "" then return
    for each h in LoadJsonArray("chan_hidden_" + pid + ProfileScopeSuffix())
        m.hiddenNow[ToStr(h)] = true
    end for
end sub

' ---- The category column ----------------------------------------------------
'
' Built ONCE per source, and again after anything that changes what is hidden.
' It walks the channel list exactly twice: once to find which categories have
' channels at all, once to record where each category's channels sit.

sub mcBuildCats()
    pid = mcProvId()
    names = {}
    if m.catNames.doesExist(pid) then names = m.catNames[pid]
    order = []
    if m.catOrder.doesExist(pid) then order = m.catOrder[pid]

    ' Which categories actually have channels behind them. A panel will happily
    ' list categories it has nothing in, and a row that opens an empty column
    ' is a dead end.
    present = {}
    anyLoose = false
    for each c in m.allChans
        cid = ToStr(c.catId)
        nm = ""
        if cid <> "" and names.doesExist(cid) then nm = ToStr(names[cid])
        if nm = ""
            anyLoose = true
        else
            present[nm] = true
        end if
    end for

    raw = []
    seen = {}
    for each cid in order
        nm = ToStr(names[ToStr(cid)])
        if nm <> "" and present.doesExist(nm) and not seen.doesExist(nm)
            seen[nm] = true
            ' Category prefs are NAME-keyed everywhere in this app, so the
            ' editor speaks names too — see ApplyCatPrefs in Store.brs.
            raw.push({ id: nm, name: nm })
        end if
    end for
    ' A playlist group or a panel category the category call never mentioned
    ' still has to be reachable, or its channels cannot be managed at all.
    for each nm in present
        if not seen.doesExist(nm)
            seen[nm] = true
            raw.push({ id: nm, name: nm })
        end if
    end for
    if anyLoose and not seen.doesExist("Uncategorized")
        raw.push({ id: "Uncategorized", name: "Uncategorized" })
    end if

    ' Certification 6.3: adult categories never reach the editor unless the
    ' member has allowed them, so their names stay off screen.
    raw = FilterAdultCats(raw)
    ordered = ApplyCatPrefs("live", raw, true)   ' includeHidden = true

    hideMode = (ParentalMode() = "hide")
    unlocked = ParentalUnlocked()
    m.keepCat = {}
    kept = []
    for each c in ordered
        lockedNow = (c.locked = true and not unlocked)
        ' A locked category in "hide" mode vanishes everywhere else in the app
        ' and vanishes here too.
        if lockedNow and hideMode then continue for
        kept.push({
            id: ToStr(c.id)
            name: ToStr(c.name)
            hidden: (c.hidden = true)
            locked: lockedNow
            idxs: []
            hidCount: 0
        })
        ' A locked category is listed, but its channels are NOT, so it is left
        ' out of the map that decides which channels may be shown.
        if not lockedNow then m.keepCat[ToStr(c.name)] = true
    end for

    ' The pseudo-category at the top. It is how a member searches the whole
    ' source and the only place channel moves are offered — see mcFillActs.
    allCat = { id: "", name: "All channels in this source", hidden: false, locked: false, idxs: [], hidCount: 0 }
    byName = {}
    for each c in kept
        byName[c.name] = c
    end for
    for i = 0 to m.allChans.count() - 1
        ch = m.allChans[i]
        cid = ToStr(ch.catId)
        nm = ""
        if cid <> "" and names.doesExist(cid) then nm = ToStr(names[cid])
        if nm = "" then nm = "Uncategorized"
        if not m.keepCat.doesExist(nm) then continue for
        isHid = m.hiddenNow.doesExist(ToStr(ch.streamId))
        c = byName[nm]
        if c <> invalid
            c.idxs.push(i)
            if isHid then c.hidCount = c.hidCount + 1
        end if
        allCat.idxs.push(i)
        if isHid then allCat.hidCount = allCat.hidCount + 1
    end for

    m.cats = [allCat]
    for each c in kept
        m.cats.push(c)
    end for
    if m.catAt >= m.cats.count() then m.catAt = 0
end sub

' Cut a string to a character budget. The columns are fixed and the font is
' fixed-width, so a label that does not fit does not wrap — it runs under the
' next column.
function mcCut(s as string, n as integer) as string
    if Len(s) <= n then return s
    if n <= 1 then return Left(s, n)
    return Left(s, n - 1) + "…"
end function

sub mcFillCats()
    content = CreateObject("roSGNode", "ContentNode")
    for i = 0 to m.cats.count() - 1
        c = m.cats[i]
        total = c.idxs.count()
        if c.locked
            tail = "  Locked"
        else if c.hidden
            tail = "  Hidden, " + total.toStr() + " channels"
        else if c.hidCount > 0
            tail = "  " + total.toStr() + " channels, " + c.hidCount.toStr() + " hidden"
        else
            tail = "  " + total.toStr() + " channels"
        end if
        ' 41 characters across the 548px column at 22 point mono.
        nameRoom = 41 - Len(tail)
        if nameRoom < 8 then nameRoom = 8
        content.createChild("ContentNode").title = mcCut(c.name, nameRoom) + tail
    end for
    m.catList.content = content
    if m.catAt >= 0 and m.catAt < m.cats.count() then m.catList.jumpToItem = m.catAt
end sub

function mcCurrentCat() as object
    if m.catAt < 0 or m.catAt >= m.cats.count()
        return { id: "", name: "", hidden: false, locked: false, idxs: [], hidCount: 0 }
    end if
    return m.cats[m.catAt]
end function

' ---- The channel column -----------------------------------------------------

function mcIsFiltering() as boolean
    return m.query <> "" or m.hiddenOnly
end function

sub mcFillChans()
    c = mcCurrentCat()
    ' Where the member was standing. Re-assigning a list's content throws the
    ' highlight back to the first row, and being sent back to the top of a
    ' four-hundred-channel category because one channel was hidden is exactly
    ' the rudeness this screen exists to remove.
    keepAt = m.chanList.itemFocused
    m.chanRows = []
    content = CreateObject("roSGNode", "ContentNode")
    m.chanOver = 0
    if c.locked
        ' A locked category is named but never opened. Same rule as the guide,
        ' Live TV and Search.
        content.createChild("ContentNode").title = "Locked. Unlock it in"
        content.createChild("ContentNode").title = "Settings, Parental Controls."
        m.chanRows.push(-1)
        m.chanRows.push(-1)
    else
        q = LCase(m.query)
        shown = 0
        for each atIdx in c.idxs
            ch = m.allChans[atIdx]
            sid = ToStr(ch.streamId)
            isHid = m.hiddenNow.doesExist(sid)
            if m.hiddenOnly and not isHid then continue for
            if q <> "" and Instr(1, LCase(ToStr(ch.name)), q) = 0 then continue for
            if shown >= mcMaxRows()
                m.chanOver = m.chanOver + 1
                continue for
            end if
            mark = "[ ] "
            if m.checked.doesExist(sid) then mark = "[x] "
            tail = ""
            if isHid then tail = "  (Hidden)"
            if m.moveMode and sid = m.moveId
                mark = "-> "
                tail = "  (moving)"
            end if
            ' 48 characters across the 640px column at 22 point mono.
            nameRoom = 48 - Len(mark) - Len(tail)
            if nameRoom < 8 then nameRoom = 8
            m.chanRows.push(atIdx)
            content.createChild("ContentNode").title = mark + mcCut(ToStr(ch.name), nameRoom) + tail
            shown = shown + 1
        end for
        if shown = 0
            if mcIsFiltering()
                content.createChild("ContentNode").title = "Nothing matches."
            else
                content.createChild("ContentNode").title = "No channels here."
            end if
            m.chanRows.push(-1)
        end if
    end if
    m.chanList.content = content
    if keepAt < 0 then keepAt = 0
    if keepAt >= m.chanRows.count() then keepAt = m.chanRows.count() - 1
    if keepAt < 0 then keepAt = 0
    m.chanList.jumpToItem = keepAt
    mcPaintTitles()
    mcPaintNote()
end sub

' Back to the top of the channel column, for the moves that genuinely change
' what is being looked at: a different category, a new search, a filter.
sub mcResetChanTop()
    m.chanList.jumpToItem = 0
end sub

' The channel the highlight is on, or invalid on one of the printed
' "nothing here" rows. Every caller checks for invalid — the empty branch has
' to be as deliberate as the full one.
function mcFocusedChan() as dynamic
    i = m.chanList.itemFocused
    if i < 0 or i >= m.chanRows.count() then return invalid
    atIdx = m.chanRows[i]
    if atIdx < 0 then return invalid
    return m.allChans[atIdx]
end function

' ---- The actions column -----------------------------------------------------
'
' Rebuilt from scratch every time anything changes, and EVERY row is written
' both ways — a "Hide" that is only ever turned into a "Show" when something
' is hidden is how a column starts lying about what it will do.
'
' 26 characters across the 348px column at 22 point mono. Every label below is
' inside that; if one grows past it, it is cut and the member is left guessing.
' The longest one today is "Hide all other categories" at 25, so there is
' exactly one character of slack — anything longer added here has to be
' shortened, not squeezed in.

sub mcFillActs()
    m.actRows = []
    rows = []
    c = mcCurrentCat()
    checkCount = mcCheckedCount()
    ch = mcFocusedChan()
    hasChans = (m.chanRows.count() > 0 and m.chanRows[0] >= 0)

    if m.moveMode
        rows.push({ kind: "moveDone", label: "Drop it here" })
        rows.push({ kind: "moveTop", label: "Move to the very top" })
        rows.push({ kind: "moveCancel", label: "Stop moving" })
    else
        if ch <> invalid
            if m.hiddenNow.doesExist(ToStr(ch.streamId))
                rows.push({ kind: "one", label: "Show this channel" })
            else
                rows.push({ kind: "one", label: "Hide this channel" })
            end if
        end if
        if checkCount > 0
            rows.push({ kind: "hideChecked", label: "Hide " + checkCount.toStr() + " checked" })
            rows.push({ kind: "showChecked", label: "Show " + checkCount.toStr() + " checked" })
            rows.push({ kind: "clearChecks", label: "Clear all checks" })
        end if
        if hasChans
            rows.push({ kind: "checkAll", label: "Check all listed here" })
            rows.push({ kind: "letter", label: "Jump to a letter" })
        end if
        ' Moving is offered only in the whole-source view and only with no
        ' filter on. "Up one" inside a category means up past channels that are
        ' not on screen, which is not what anybody pressing it is asking for —
        ' and the stored order is a head of the WHOLE source's list, so a move
        ' made inside a category would look as though nothing happened.
        if ch <> invalid and c.id = "" and not mcIsFiltering()
            rows.push({ kind: "moveTop", label: "Move to the very top" })
            if CanMoveChannelBy(mcIndexOf(ToStr(ch.streamId)))
                rows.push({ kind: "moveStart", label: "Move with Up and Down" })
            end if
        else if ch <> invalid
            rows.push({ kind: "moveTop", label: "Move to the very top" })
        end if
        if m.query = ""
            rows.push({ kind: "search", label: "Search this source" })
        else
            rows.push({ kind: "search", label: "Searching: " + mcCut(m.query, 14) })
            rows.push({ kind: "clearSearch", label: "Stop searching" })
        end if
        if m.hiddenOnly
            rows.push({ kind: "filter", label: "Show every channel" })
        else
            rows.push({ kind: "filter", label: "Show hidden ones only" })
        end if
        if c.id = ""
            rows.push({ kind: "hideAllCats", label: "Hide every category" })
            rows.push({ kind: "showAllCats", label: "Show every category" })
        else
            if c.hidden
                rows.push({ kind: "catShow", label: "Show this whole category" })
            else
                rows.push({ kind: "catHide", label: "Hide this whole category" })
            end if
            rows.push({ kind: "catOnly", label: "Hide all other categories" })
        end if
    end if

    m.actRows = rows
    content = CreateObject("roSGNode", "ContentNode")
    for each r in rows
        ' Cut here and not at each push: one place to change if the column
        ' ever gets wider, and no label can slip past it by being added later.
        content.createChild("ContentNode").title = mcCut(r.label, 26)
    end for
    keepAt = m.actList.itemFocused
    if keepAt < 0 then keepAt = 0
    if keepAt >= rows.count() then keepAt = rows.count() - 1
    if keepAt < 0 then keepAt = 0
    m.actList.content = content
    m.actList.jumpToItem = keepAt
end sub

function mcCheckedCount() as integer
    n = 0
    for each k in m.checked
        if m.checked[k] = true then n = n + 1
    end for
    return n
end function

' Where a channel sits in the WHOLE source's running order, which is what a
' move is measured against.
function mcIndexOf(streamId as string) as integer
    for i = 0 to m.allChans.count() - 1
        if ToStr(m.allChans[i].streamId) = streamId then return i
    end for
    return -1
end function

' ---- Headings and footers ---------------------------------------------------

sub mcPaintTitles()
    c = mcCurrentCat()
    m.catTitle.text = "CATEGORIES"
    ' "CHANNELS: " is 10 and " - hidden only" is 14, so the name gets 26 of
    ' the column's 48 characters and the worst case still fits on one line.
    chanHead = mcCut(c.name, 26)
    if m.query <> "" then chanHead = chanHead + " - searching"
    if m.hiddenOnly then chanHead = chanHead + " - hidden only"
    m.chanTitle.text = "CHANNELS: " + chanHead
    m.actTitle.text = "WHAT TO DO"
    ' Which column the remote is in, painted rather than left to the row
    ' highlight alone — one highlight in grey is not obvious from a sofa. All
    ' three are written every time, so a column can never be left lit.
    m.catTitle.color = m.theme.textSecondary
    m.chanTitle.color = m.theme.textSecondary
    m.actTitle.color = m.theme.textSecondary
    if m.pane = "cats" then m.catTitle.color = m.theme.accent
    if m.pane = "chans" then m.chanTitle.color = m.theme.accent
    if m.pane = "acts" then m.actTitle.color = m.theme.accent
    mcPaintPanels()
end sub

' The plate under the column the remote is in wears a 4px accent edge down its
' left side and a 10% accent wash over it, and the other two wear neither.
'
' That is not a look invented here: it is what SettingsCategoryScreen puts
' round the settings group you have open. Reusing it means the app says "this
' is the one you are in" the same way everywhere, which is the whole point of
' Mason asking for panels in the first place.
'
' EVERY plate gets EVERY value on EVERY paint — fill colour, wash colour, wash
' visibility, rule colour, rule visibility. A wash that is only ever switched
' ON is how two columns end up lit at once, and this sub runs on every press.
sub mcPaintPanels()
    for each p in m.panels
        lit = (m.pane = p.pane)
        p.fill.color = m.theme.surface
        p.wash.color = m.washColor
        p.wash.visible = lit
        p.rule.color = m.theme.accent
        p.rule.visible = lit
    end for
end sub

sub mcPaintNote()
    bits = []
    checkCount = mcCheckedCount()
    if checkCount > 0 then bits.push(checkCount.toStr() + " channels checked")
    if m.moveMode
        bits.push("Moving a channel: Up and Down move it, OK drops it, Back stops")
    end if
    if m.chanOver > 0
        bits.push("Only the first " + mcMaxRows().toStr() + " are listed - search to reach the rest")
    end if
    moved = LoadChanOrder().count()
    if moved > 0 then bits.push(moved.toStr() + " channels pinned to the top (room for " + ChanOrderMax().toStr() + ")")
    txt = ""
    for each b in bits
        if txt <> "" then txt = txt + ".   "
        txt = txt + b
    end for
    if txt = "" then txt = "OK puts a check on a channel. Right goes to the actions."
    ' One line, 1680px wide inside the footer strip at 22 point mono — 127
    ' characters. It does not wrap, so anything longer would be cut mid-word
    ' by the renderer instead of by us.
    m.note.text = mcCut(txt, 127)
    m.note.visible = true

    ' The ceiling, in plain words, at all times. The registry holds 16-32 KB
    ' for the WHOLE app and a write past it fails SILENTLY, so a member needs
    ' to see the number before they hit it, not afterwards.
    ' READ FROM THE CACHE, NOT THE REGISTRY. HiddenChannelBudget() reads and
    ' parses one registry key per profile per source to work out what the
    ' device already spends - fifteen reads for a five-profile, three-source
    ' household - and this sub paints on every key press. So the two numbers
    ' are worked out once when the screen fills and again after every bulk
    ' write (mcRefreshBudget), and painting only prints them.
    if m.budgetUsed = invalid then mcRefreshBudget()
    m.budget.text = m.budgetUsed.toStr() + " of about " + m.budgetCap.toStr() + " hidden channels this TV can remember."
    m.budget.visible = true
end sub

sub mcRefreshBudget()
    m.budgetUsed = HiddenChannelCount()
    m.budgetCap = HiddenChannelBudget()
end sub

' ---- Focus ------------------------------------------------------------------

sub mcFocusPane(which as string)
    m.pane = which
    if which = "chips"
        m.top.setFocus(true)
    else if which = "chans"
        m.chanList.setFocus(true)
    else if which = "acts"
        m.actList.setFocus(true)
    else
        m.pane = "cats"
        m.catList.setFocus(true)
    end if
    mcPaintTitles()
    mcRedrawChips()
end sub

' ---- Focus moving through the categories ------------------------------------

' >>> THE GUARD IS "DID THE INDEX ACTUALLY CHANGE", NOT A BUSY FLAG. <<<
' Replacing a list's content resets its highlight to row 0 and fires this
' observer, and an observer does NOT necessarily run before the function that
' triggered it returns — so a "m.filling = true ... = false" fence around the
' assignment is a fence the event steps over. Comparing against the index this
' screen already believes it is on is the test that holds either way, and it
' is the same one SeriesDetailScreen.onSeasonFocused uses.
sub mcOnCatFocused()
    i = m.catList.itemFocused
    if i < 0 or i >= m.cats.count() then return
    if i = m.catAt then return
    m.catAt = i
    ' Instant: the heading names the category on this frame, inside the 250 ms
    ' certification 3.5 allows for an answer.
    mcPaintTitles()
    ' Deferred: the rows themselves, once the member stops moving.
    m.catDwell.control = "stop"
    m.catDwell.control = "start"
end sub

sub mcOnCatDwell()
    mcFillChans()
    ' A different category is a different list, so the highlight belongs at
    ' the top of it rather than wherever it happened to be in the last one.
    mcResetChanTop()
    mcFillActs()
end sub

' Anything that needs the channel column NOW rather than after the dwell.
sub mcFlushCatDwell()
    m.catDwell.control = "stop"
    mcFillChans()
    mcResetChanTop()
    mcFillActs()
end sub

sub mcOnChanFocused()
    i = m.chanList.itemFocused
    if i = m.chanAt then return
    m.chanAt = i
    ' The first action names the channel under the highlight, so it has to be
    ' rebuilt as the highlight moves.
    mcFillActs()
end sub

' ---- Pressing OK ------------------------------------------------------------

' OK on a category is the category's own menu. Browsing it needs no press at
' all, so OK is free for the things that change something.
sub mcOnCatSelected()
    i = m.catList.itemSelected
    if i < 0 or i >= m.cats.count() then return
    m.catAt = i
    mcFlushCatDwell()
    c = mcCurrentCat()
    btns = []
    m.catActions = []
    if c.id = ""
        btns.push("Hide every category in this source")
        m.catActions.push("hideAllCats")
        btns.push("Show every category in this source")
        m.catActions.push("showAllCats")
    else
        if c.hidden
            btns.push("Show this whole category")
            m.catActions.push("catShow")
        else
            btns.push("Hide this whole category")
            m.catActions.push("catHide")
        end if
        btns.push("Hide everything except this category")
        m.catActions.push("catOnly")
    end if
    btns.push("See its channels")
    m.catActions.push("open")
    btns.push("Cancel")
    m.catActions.push("cancel")
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = mcCut(c.name, 40)
    dialog.buttons = btns
    ' House rule: a D-pad user can't click, so the primary action is focused.
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "mcOnCatDialog")
    m.top.getScene().dialog = dialog
end sub

sub mcOnCatDialog()
    dialog = m.top.getScene().dialog
    choice = dialog.buttonSelected
    dialog.close = true
    if choice < 0 or choice >= m.catActions.count()
        mcFocusPane("cats")
        return
    end if
    mcRunAction(m.catActions[choice])
end sub

' OK on a channel toggles its check. That is the whole point of the rebuild:
' gathering a batch has to be one press a channel, and the one-channel switch
' lives in the actions column where it names the channel it will act on.
sub mcOnChanSelected()
    if m.moveMode
        mcEndMove()
        return
    end if
    i = m.chanList.itemSelected
    if i < 0 or i >= m.chanRows.count() then return
    atIdx = m.chanRows[i]
    if atIdx < 0 then return
    sid = ToStr(m.allChans[atIdx].streamId)
    if m.checked.doesExist(sid)
        m.checked.delete(sid)
    else
        m.checked[sid] = true
    end if
    mcFillChans()
    m.chanList.jumpToItem = i
    mcFillActs()
    m.chanList.setFocus(true)
end sub

sub mcOnActSelected()
    i = m.actList.itemSelected
    if i < 0 or i >= m.actRows.count() then return
    mcRunAction(m.actRows[i].kind)
end sub

' ---- Doing the thing --------------------------------------------------------

sub mcRunAction(kind as string)
    c = mcCurrentCat()
    if kind = "one"
        ch = mcFocusedChan()
        if ch = invalid
            mcFocusPane(m.pane)
            return
        end if
        sid = ToStr(ch.streamId)
        mcApplyChannels([sid], not m.hiddenNow.doesExist(sid))
    else if kind = "hideChecked"
        mcApplyChannels(mcCheckedIds(), true)
    else if kind = "showChecked"
        mcApplyChannels(mcCheckedIds(), false)
    else if kind = "checkAll"
        for each atIdx in mcListedIdxs()
            m.checked[ToStr(m.allChans[atIdx].streamId)] = true
        end for
        mcFillChans()
        mcFillActs()
    else if kind = "clearChecks"
        m.checked = {}
        mcFillChans()
        mcFillActs()
    else if kind = "letter"
        mcOpenLetters()
        return
    else if kind = "search"
        mcOpenKeyboard()
        return
    else if kind = "clearSearch"
        m.query = ""
        mcFillChans()
        mcResetChanTop()
        mcFillActs()
    else if kind = "filter"
        m.hiddenOnly = not m.hiddenOnly
        mcFillChans()
        mcResetChanTop()
        mcFillActs()
    else if kind = "catHide" or kind = "catShow"
        if c.id = ""
            mcFocusPane(m.pane)
            return
        end if
        ' ONE id, one call — a hidden category hides its channels without
        ' listing a single one of them, which is the cheap way to make a
        ' thirty-thousand-channel package small.
        SetCatsHidden("live", [c.id], (kind = "catHide"))
        KLog("settings", "manage channels: " + kind + " on category " + c.id)
        mcAfterCatChange(c.id)
    else if kind = "catOnly"
        if c.id = ""
            mcFocusPane(m.pane)
            return
        end if
        others = []
        for each other in m.cats
            if other.id <> "" and other.id <> c.id then others.push(other.id)
        end for
        ' One call for all the others. The second call only happens when this
        ' category was itself hidden — "keep only this one" has to leave it
        ' showing, and skipping the write when there is nothing to change
        ' keeps the ordinary case at exactly one registry write.
        SetCatsHidden("live", others, true)
        if c.hidden then SetCatsHidden("live", [c.id], false)
        KLog("settings", "manage channels: kept only category " + c.id + ", hid " + others.count().toStr())
        mcAfterCatChange(c.id)
    else if kind = "hideAllCats" or kind = "showAllCats"
        ids = []
        for each other in m.cats
            if other.id <> "" then ids.push(other.id)
        end for
        SetCatsHidden("live", ids, (kind = "hideAllCats"))
        KLog("settings", "manage channels: " + kind + " over " + ids.count().toStr() + " categories")
        mcAfterCatChange("")
    else if kind = "moveTop"
        ch = mcFocusedChan()
        if ch = invalid
            mcFocusPane(m.pane)
            return
        end if
        MoveChannelToTop(ToStr(ch.streamId))
        mcAfterMove(ToStr(ch.streamId))
    else if kind = "moveStart"
        ch = mcFocusedChan()
        if ch = invalid
            mcFocusPane(m.pane)
            return
        end if
        m.moveMode = true
        m.moveId = ToStr(ch.streamId)
        mcFillChans()
        mcLandOn(m.moveId)
        mcFillActs()
        m.chanList.setFocus(true)
        m.pane = "chans"
        mcPaintTitles()
        return
    else if kind = "moveDone" or kind = "moveCancel"
        mcEndMove()
        return
    else
        ' "open" and "cancel" both just put the member back on a column. The
        ' branch exists so that every kind has one.
        if kind = "open"
            mcFocusPane("chans")
        else
            mcFocusPane("cats")
        end if
        return
    end if
    mcFocusPane(m.pane)
end sub

' Every channel currently LISTED in the middle column — what "Check all listed
' here" means, and it means the listed ones rather than the category's whole
' contents so that a search narrows it exactly as it looks as though it does.
function mcListedIdxs() as object
    out = []
    for each atIdx in m.chanRows
        if atIdx >= 0 then out.push(atIdx)
    end for
    return out
end function

function mcCheckedIds() as object
    ids = []
    ' In the order the member sees them, not the order a hash happens to
    ' iterate, because the store answers with a COUNT of how many went through
    ' and this screen has to know WHICH ones those were.
    for each ch in m.allChans
        sid = ToStr(ch.streamId)
        if m.checked.doesExist(sid) then ids.push(sid)
    end for
    return ids
end function

' ONE call for the whole batch, whatever its size.
'
' The answer is { applied, refused, reason }. When anything is refused the
' store's own reason is put on screen UNCHANGED — it is written for members —
' and the checks are LEFT on the rows that did not go through, so a member can
' see what is still outstanding and nothing disappears quietly.
'
' >>> AN ASSUMPTION WORTH NAMING. The contract answers with a count, not with
' a list of which ids were refused, so this takes the first `applied` ids of
' the array it sent as the ones that landed and keeps the checks on the rest.
' That is right if the store applies in order and stops when the budget runs
' out, which is what a budget refusal looks like. If it ever refuses on some
' other grounds the wrong checks would be cleared. The fix is for the contract
' to return the refused ids. <<<
sub mcApplyChannels(ids as object, hidden as boolean)
    if ids.count() = 0 then return
    pid = mcProvId()
    if pid = "" then return
    res = SetChannelsHidden(ids, hidden, pid)
    mcRefreshBudget()
    applied = 0
    refused = 0
    reason = ""
    if res <> invalid
        a = GetField(res, "applied")
        if a <> invalid then applied = Int(a)
        r = GetField(res, "refused")
        if r <> invalid then refused = Int(r)
        reason = ToStr(GetField(res, "reason"))
    end if
    for i = 0 to applied - 1
        if i < ids.count() then m.checked.delete(ToStr(ids[i]))
    end for
    KLog("settings", "manage channels: asked to " + mcHideWord(hidden) + " " + ids.count().toStr() + " channel(s), " + applied.toStr() + " applied, " + refused.toStr() + " refused")
    mcLoadHidden()
    mcBuildCats()
    mcFillCats()
    mcFillChans()
    mcFillActs()
    if refused > 0
        note = CreateObject("roSGNode", "Dialog")
        note.title = "Some channels were not changed"
        if reason = "" then reason = "This TV could not remember them all. Try hiding a whole category instead."
        note.message = reason
        note.buttons = ["OK"]
        note.observeField("buttonSelected", "mcOnNoteClosed")
        m.top.getScene().dialog = note
    end if
end sub

function mcHideWord(hidden as boolean) as string
    if hidden then return "hide"
    return "show"
end function

sub mcOnNoteClosed()
    m.top.getScene().dialog.close = true
    mcFocusPane(m.pane)
end sub

' A category's hidden flag changed, so the counts, the labels and possibly
' which categories exist at all have to be rebuilt. The cursor goes back to
' the category it was on.
sub mcAfterCatChange(catId as string)
    mcBuildCats()
    if catId <> ""
        for i = 0 to m.cats.count() - 1
            if m.cats[i].id = catId
                m.catAt = i
                exit for
            end if
        end for
    end if
    mcFillCats()
    mcFillChans()
    mcFillActs()
end sub

' ---- Moving a channel -------------------------------------------------------
'
' A move changes the running order, so the list is rebuilt from it rather than
' patched — what is on screen is then always what Live TV will show, never an
' optimistic guess at it.

sub mcAfterMove(streamId as string)
    m.allChans = applyChanOrder(m.allChans)
    mcBuildCats()
    mcFillCats()
    mcFillChans()
    mcLandOn(streamId)
    mcFillActs()
end sub

sub mcMoveStep(delta as integer)
    if m.moveId = "" then return
    atIdx = mcIndexOf(m.moveId)
    if atIdx < 0 then return
    if not CanMoveChannelBy(atIdx)
        ' Past the cap the move cannot be written down at all — see
        ' CanMoveChannelBy in Store.brs. Refusing is better than a key that
        ' looks as though it worked.
        return
    end if
    MoveChannelBy(m.moveId, mcCurrentIds(), delta)
    mcAfterMove(m.moveId)
end sub

' The running order as it is drawn right now — what "move up one" is measured
' against.
function mcCurrentIds() as object
    ids = []
    for each c in m.allChans
        ids.push(ToStr(c.streamId))
    end for
    return ids
end function

sub mcEndMove()
    m.moveMode = false
    m.moveId = ""
    mcFillChans()
    mcFillActs()
    mcFocusPane("chans")
end sub

' Put the highlight back on the channel that was just acted on, wherever it
' has ended up. Pressing Up twice in move mode should not mean hunting for the
' row again.
sub mcLandOn(streamId as string)
    for i = 0 to m.chanRows.count() - 1
        atIdx = m.chanRows[i]
        if atIdx >= 0 and ToStr(m.allChans[atIdx].streamId) = streamId
            m.chanList.jumpToItem = i
            return
        end if
    end for
    m.chanList.jumpToItem = 0
end sub

' ---- Jump to a letter -------------------------------------------------------
' Only the letters that are actually in this column get a button, so nothing
' on the list does nothing. The fast-forward and rewind keys do the same job
' without the dialog, and the action row says so in words.

sub mcOpenLetters()
    seen = {}
    m.letterBtns = []
    for each atIdx in m.chanRows
        if atIdx < 0 then continue for
        ch = m.allChans[atIdx]
        firstCh = mcFirstLetter(ToStr(ch.name))
        if not seen.doesExist(firstCh)
            seen[firstCh] = true
            m.letterBtns.push(firstCh)
        end if
    end for
    if m.letterBtns.count() = 0 then return
    btns = []
    for each fl in m.letterBtns
        btns.push(fl)
    end for
    btns.push("Cancel")
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Jump to a letter"
    dialog.buttons = btns
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "mcOnLetterPicked")
    m.top.getScene().dialog = dialog
end sub

sub mcOnLetterPicked()
    dialog = m.top.getScene().dialog
    choice = dialog.buttonSelected
    dialog.close = true
    if choice >= 0 and choice < m.letterBtns.count()
        mcJumpToLetter(m.letterBtns[choice])
    end if
    mcFocusPane("chans")
end sub

function mcFirstLetter(nameTxt as string) as string
    s = nameTxt.trim()
    if s = "" then return "#"
    ch = UCase(Left(s, 1))
    if ch >= "A" and ch <= "Z" then return ch
    return "#"
end function

sub mcJumpToLetter(letter as string)
    for i = 0 to m.chanRows.count() - 1
        atIdx = m.chanRows[i]
        if atIdx < 0 then continue for
        if mcFirstLetter(ToStr(m.allChans[atIdx].name)) = letter
            m.chanList.jumpToItem = i
            mcFillActs()
            return
        end if
    end for
end sub

' Fast-forward and rewind step whole letter blocks. Dedicated keys, so they
' cannot collide with Left and Right moving between the three columns.
sub mcStepLetter(forward as boolean)
    if m.chanRows.count() = 0 then return
    at = m.chanList.itemFocused
    if at < 0 then at = 0
    here = ""
    if at < m.chanRows.count() and m.chanRows[at] >= 0
        here = mcFirstLetter(ToStr(m.allChans[m.chanRows[at]].name))
    end if
    if forward
        for i = at + 1 to m.chanRows.count() - 1
            atIdx = m.chanRows[i]
            if atIdx < 0 then continue for
            if mcFirstLetter(ToStr(m.allChans[atIdx].name)) <> here
                m.chanList.jumpToItem = i
                mcFillActs()
                return
            end if
        end for
        return
    end if
    ' Backwards: find the previous block, then its FIRST row, so rewind lands
    ' on the top of a letter and not on its last entry.
    prevLetter = ""
    prevAt = -1
    for i = at - 1 to 0 step -1
        atIdx = m.chanRows[i]
        if atIdx < 0 then continue for
        fl = mcFirstLetter(ToStr(m.allChans[atIdx].name))
        if prevLetter = "" and fl <> here
            prevLetter = fl
            prevAt = i
        else if prevLetter <> "" and fl = prevLetter
            prevAt = i
        else if prevLetter <> "" and fl <> prevLetter
            exit for
        end if
    end for
    if prevAt >= 0
        m.chanList.jumpToItem = prevAt
        mcFillActs()
    end if
end sub

' ---- Search -----------------------------------------------------------------
' Roku's own StandardKeyboardDialog, exactly as the Search screen and the
' sign-in form use it: it brings the microphone and the "use your phone as a
' keyboard" affordance with it, and nothing new is drawn for it.
'
' The search runs over the WHOLE source, not the highlighted category, because
' a member searching for "sky sports" does not know which category it is in —
' finding it is the point. A match therefore switches the middle column to the
' whole-source view.

sub mcOpenKeyboard()
    kb = CreateObject("roSGNode", "StandardKeyboardDialog")
    kb.title = "Search this source"
    kb.text = m.query
    kb.buttons = ["Search", "Show all", "Cancel"]
    kb.keyboardDomain = "generic"
    edit = kb.textEditBox
    edit.voiceEnabled = true
    edit.voiceEntryType = kb.keyboardDomain
    edit.maxTextLength = 64
    m.kbDialog = kb
    m.kbEdit = edit
    m.kbAction = ""
    m.kbClear = false
    kb.observeField("buttonSelected", "mcOnKeyboardButton")
    ' Back closes the dialog without going through a button at all, so focus
    ' has to come home from here as well as from the buttons.
    kb.observeField("wasClosed", "mcOnKeyboardClosed")
    m.top.getScene().dialog = kb
end sub

sub mcOnKeyboardButton()
    kb = m.kbDialog
    if kb = invalid then return
    if kb.buttonSelected = 0
        t = ToStr(kb.text)
        if t = "" and m.kbEdit <> invalid then t = ToStr(m.kbEdit.text)
        m.kbAction = mcCleanQuery(t)
    else if kb.buttonSelected = 1
        m.kbAction = ""
        m.kbClear = true
    end if
    kb.close = true
end sub

sub mcOnKeyboardClosed()
    apply = (m.kbAction <> "" or m.kbClear = true)
    q = m.kbAction
    m.kbDialog = invalid
    m.kbEdit = invalid
    m.kbAction = ""
    m.kbClear = false
    if apply
        m.query = q
        if q <> ""
            ' Searching the whole source is only meaningful from the
            ' whole-source view, so the left column moves with it rather than
            ' leaving the member wondering where the results went.
            m.catAt = 0
            mcFillCats()
        end if
        mcFillChans()
        mcResetChanTop()
        mcFillActs()
    end if
    mcFocusPane("chans")
end sub

' Speech comes back as a sentence and typing does not — Roku's dictation
' punctuates what it heard, so "sky sports" can arrive as "Sky Sports." and a
' plain contains test would find nothing. Only the ENDS are stripped, exactly
' as on the Search screen, so a name with a full stop in the middle still
' matches.
function mcCleanQuery(raw as string) as string
    q = raw.trim()
    junk = ".,!?;:"
    while q.len() > 0 and junk.instr(q.right(1)) > -1
        q = q.left(q.len() - 1)
    end while
    while q.len() > 0 and junk.instr(q.left(1)) > -1
        q = q.mid(1)
    end while
    return q.trim()
end function

' ---- Keys -------------------------------------------------------------------
'
' The whole map, in one place:
'   Left / Right   walk the three columns. Left from the leftmost closes the
'                  screen, which is what it has always done here.
'   Up             from the top row of any column, onto the source chips.
'   Down           from the chips, into the categories.
'   Back           closes the screen — or leaves move mode, if it is on.
'   OK             category menu / check a channel / do the action.
'   Fast-forward,
'   rewind         step a letter at a time through the channel column.
'
' Nothing is on the * key. A Roku remote has one spare key and no way to tell
' anybody it does anything.

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false

    ' The chip row is not a focusable node, so while it is selected the focus
    ' sits on this Group and EVERY press arrives here — including the ones
    ' that do nothing. Answered before the columns below, all of which ask
    ' which list has focus.
    if m.pane = "chips"
        if key = "left"
            if m.srcIdx > 0
                mcSelectSource(m.srcIdx - 1)
                mcRedrawChips()
            end if
        else if key = "right"
            if m.srcIdx < m.sources.count() - 1
                mcSelectSource(m.srcIdx + 1)
                mcRedrawChips()
            end if
        else if key = "down" or key = "OK"
            mcFocusPane("cats")
        else if key = "back"
            m.top.closed = true
        end if
        ' Up has nowhere to go; swallowed rather than passed on.
        return true
    end if

    if key = "back"
        if m.moveMode
            mcEndMove()
            return true
        end if
        m.top.closed = true
        return true
    end if

    if m.moveMode
        ' While a channel is being moved the arrows belong to it. Left and
        ' Right are swallowed too: stepping out of the column mid-move would
        ' leave a channel marked "(moving)" with nothing driving it.
        if key = "up"
            mcMoveStep(-1)
            return true
        else if key = "down"
            mcMoveStep(1)
            return true
        else if key = "left" or key = "right"
            return true
        end if
        return false
    end if

    if key = "left"
        if m.pane = "acts"
            mcFocusPane("chans")
            return true
        else if m.pane = "chans"
            mcFocusPane("cats")
            return true
        end if
        ' From the leftmost column Left leaves the screen, as it always has.
        m.top.closed = true
        return true
    else if key = "right"
        if m.pane = "cats"
            mcFlushCatDwell()
            mcFocusPane("chans")
            return true
        else if m.pane = "chans"
            mcFocusPane("acts")
            return true
        end if
        return true
    else if key = "up"
        ' Only ever reached when the list did NOT consume Up — the highlight
        ' was already on the first row. That is the way onto the chip row.
        if m.multiSource
            mcFocusPane("chips")
            return true
        end if
        return false
    else if key = "fastforward"
        if m.pane = "chans"
            mcStepLetter(true)
            return true
        end if
    else if key = "rewind"
        if m.pane = "chans"
            mcStepLetter(false)
            return true
        end if
    end if
    return false
end function
