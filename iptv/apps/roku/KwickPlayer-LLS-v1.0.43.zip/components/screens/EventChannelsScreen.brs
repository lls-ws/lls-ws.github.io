sub init()
    m.theme = KwickTheme()
    m.top.findNode("panel").color = m.theme.surfaceElevated
    m.titleLabel = m.top.findNode("titleLabel")
    m.metaLabel = m.top.findNode("metaLabel")
    ' Both sizes came down for the shell face. JetBrains Mono is a flat 0.6em
    ' advance where Roboto-Medium averaged about 0.5em, and both labels sit in
    ' fixed 680px boxes with no wrap, so the type is what gives.
    ' 33 -> 28: a fixture name gets ~40 characters, as it did before. It also
    ' clears a squeeze that was already there — mono 33 is a 44px line inside a
    ' 44px box.
    m.titleLabel.font = UiBoldFont(28)
    m.titleLabel.color = m.theme.textPrimary
    ' 23 -> 19: the competition/date/kick-off line gets ~59 characters, as
    ' before.
    m.metaLabel.font = UiFont(19)
    m.metaLabel.color = m.theme.textSecondary
    m.list = m.top.findNode("list")
    m.list.observeField("itemSelected", "onPick")
end sub

sub onHeader()
    m.titleLabel.text = m.top.eventTitle
    m.metaLabel.text = m.top.metaText
end sub

sub onRows()
    content = CreateObject("roSGNode", "ContentNode")
    for each r in m.top.rows
        node = content.createChild("ContentNode")
        node.title = r.title
        node.description = r.subtitle
    end for
    m.list.content = content
    ' Autofocus the first stream — the primary action — per the dialog rule.
    m.list.jumpToItem = 0
    m.list.setFocus(true)
end sub

sub onPick()
    m.top.picked = m.list.itemSelected
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back"
        m.top.closed = true
        return true
    end if
    return false
end function
