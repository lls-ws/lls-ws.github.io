' Create / edit a profile: name (click to edit), avatar color, and an
' optional PIN. Saving persists via the Store; closing fires "closed" so the
' picker rebuilds. A brand-new profile is created on Save so its syncId
' exists before any PIN hash is computed.

sub init()
    m.theme = KwickTheme()
    ' The panel used to be a hard-coded near-black; it is a palette surface
    ' now, painted here so the XML literal is only ever a first frame.
    m.top.findNode("panel").color = m.theme.surface
    m.content = m.top.findNode("content")
    m.pinDialog = invalid
    m.avatarPicker = invalid
    ' The parent sets profileId (optional) then launch=true to start us.
    m.top.observeField("launch", "start")
end sub

sub start()
    ' Load existing profile or seed a new one.
    m.editing = (m.top.profileId <> "")
    if m.editing
        p = ProfileById(m.top.profileId)
        if p = invalid then p = { name: "Profile", color: 0, pin: "", syncId: "", avatar: "" }
        m.name = ToStr(p.name)
        m.color = ToInt(p.color)
        m.pinHash = ToStr(p.pin)
        m.avatar = ToStr(p.avatar)
    else
        m.name = "Profile"
        m.color = 0
        m.pinHash = ""
        m.avatar = ""
    end if
    m.focusIdx = 0
    build()
end sub

sub build()
    while m.content.getChildCount() > 0
        m.content.removeChildIndex(0)
    end while

    titleFont = UiBoldFont(34)
    rowFont = mkFont(28)

    title = m.content.createChild("Label")
    title.translation = [0, 30]
    title.width = 900
    title.horizAlign = "center"
    title.font = titleFont
    title.color = m.theme.textPrimary
    if m.editing then title.text = "Edit Profile" else title.text = "New Profile"

    ' Rows: 0 Name, 1 Color, 2 Avatar, 3 PIN, 4 Save, 5 Cancel,
    ' 6 Delete Profile (existing non-default profiles only).
    m.rows = []
    addRow(0, 110, "Name", m.name, rowFont)
    m.colorRowY = 194
    addRow(1, m.colorRowY, "Color", "", rowFont)
    buildSwatches(m.colorRowY)
    addRow(2, 278, "Avatar", avatarLabel(), rowFont)
    buildAvatarPreview(278)
    addRow(3, 362, "Lock with PIN", pinLabel(), rowFont)
    addRow(4, 472, "Save", "", rowFont)
    addRow(5, 548, "Cancel", "", rowFont)
    m.maxIdx = 5
    ' Any profile can be deleted as long as another remains.
    if m.editing and LoadProfiles().count() > 1
        addRow(6, 624, "Delete Profile", "", rowFont)
        m.maxIdx = 6
    end if

    applyFocus()
end sub

function avatarLabel() as string
    ' With an avatar chosen the preview image IS the value — text under it
    ' just showed through the edges. If the stored value points at art we no
    ' longer ship we say "Colored initial", because that is what the profile
    ' tile actually draws.
    if m.avatar <> "" and avatarResolves() then return ""
    return "Colored initial"
end function

' Does the stored avatar value still point at a file inside this build?
'
' Profiles can carry an avatar chosen on another device, or one chosen before
' the old avatar pack was removed, so the path may name a file that is simply
' not here. Poster draws nothing for a missing uri (no broken-image icon), so
' the picture side already degrades cleanly — this check is what stops the
' row from showing an EMPTY value next to that blank space.
'
' The stored value is deliberately NOT rewritten when it fails to resolve:
' clearing it here would ride KwickSync out to the member's other devices and
' wipe an avatar that still renders perfectly well on them.
function avatarResolves() as boolean
    uri = AvatarUri(m.avatar)
    if uri = "" then return false
    cut = -1
    for i = uri.len() - 1 to 0 step -1
        if uri.mid(i, 1) = "/"
            cut = i
            exit for
        end if
    end for
    if cut < 1 then return false
    ' MatchFiles reads [ ] * ? as glob metacharacters. A legacy filename that
    ' contains one just fails to match, which lands on the same fallback.
    return MatchFiles(uri.left(cut), uri.mid(cut + 1)).count() > 0
end function

' A small live preview of the chosen pack avatar at the right end of the row.
sub buildAvatarPreview(rowY as integer)
    uri = AvatarUri(m.avatar)
    if uri = "" then return
    if not avatarResolves() then return
    pv = m.content.createChild("Poster")
    pv.width = 48
    pv.height = 48
    pv.translation = [40 + 820 - 24 - 48, rowY + 8]
    pv.uri = uri
    pv.loadDisplayMode = "scaleToZoom"
end sub

function mkFont(size as integer) as object
    return UiFont(size)
end function

function pinLabel() as string
    if m.pinHash <> "" then return "On"
    return "Off"
end function

sub addRow(idx as integer, y as integer, label as string, value as string, font as object)
    bg = m.content.createChild("Rectangle")
    bg.width = 820
    bg.height = 64
    bg.translation = [40, y]
    bg.color = m.theme.surfaceElevated

    lbl = bg.createChild("Label")
    lbl.translation = [24, 0]
    lbl.height = 64
    lbl.width = 500
    lbl.vertAlign = "center"
    lbl.font = font
    lbl.color = m.theme.textPrimary
    lbl.text = label

    valLabel = bg.createChild("Label")
    valLabel.translation = [300, 0]
    valLabel.width = 496
    valLabel.height = 64
    valLabel.vertAlign = "center"
    valLabel.horizAlign = "right"
    valLabel.font = font
    valLabel.color = m.theme.accentAlt
    valLabel.text = value

    m.rows.push({ bg: bg, lbl: lbl, val: valLabel, idx: idx })
end sub

sub buildSwatches(rowY as integer)
    m.swatches = []
    pal = ProfilePalette()
    sw = 42
    gap = 12
    total = pal.count() * sw + (pal.count() - 1) * gap
    startX = 40 + 820 - total - 24
    y = rowY + Int((64 - sw) / 2)
    for i = 0 to pal.count() - 1
        x = startX + i * (sw + gap)
        ring = m.content.createChild("Rectangle")
        ring.width = sw + 8
        ring.height = sw + 8
        ring.translation = [x - 4, y - 4]
        ring.color = m.theme.textPrimary
        ring.visible = (i = m.color)
        dot = m.content.createChild("Rectangle")
        dot.width = sw
        dot.height = sw
        dot.translation = [x, y]
        dot.color = pal[i]
        m.swatches.push(ring)
    end for
end sub

sub refreshSwatches()
    for i = 0 to m.swatches.count() - 1
        m.swatches[i].visible = (i = m.color)
    end for
end sub

sub applyFocus()
    for each r in m.rows
        on = (r.idx = m.focusIdx)
        if on
            r.bg.color = m.theme.focusHighlight
            ' Dark text on the focus bar. Was the old scheme's near-black
            ' page colour written out longhand; it is the palette page
            ' colour now, which is 5.5:1 on the warm-orange ring.
            r.lbl.color = m.theme.background
            r.val.color = m.theme.background
        else
            r.bg.color = m.theme.surfaceElevated
            r.lbl.color = m.theme.textPrimary
            r.val.color = m.theme.accentAlt
        end if
    end for
end sub

' ---- Input ------------------------------------------------------------------

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back"
        m.top.closed = true
        return true
    else if key = "up"
        if m.focusIdx > 0
            m.focusIdx = m.focusIdx - 1
            applyFocus()
        end if
        return true
    else if key = "down"
        if m.focusIdx < m.maxIdx
            m.focusIdx = m.focusIdx + 1
            applyFocus()
        end if
        return true
    else if key = "left" and m.focusIdx = 1
        if m.color > 0
            m.color = m.color - 1
            refreshSwatches()
        end if
        return true
    else if key = "right" and m.focusIdx = 1
        if m.color < ProfilePalette().count() - 1
            m.color = m.color + 1
            refreshSwatches()
        end if
        return true
    else if key = "OK"
        activate()
        return true
    end if
    return false
end function

sub activate()
    if m.focusIdx = 0
        editName()
    else if m.focusIdx = 2
        avatarRow()
    else if m.focusIdx = 3
        pinRow()
    else if m.focusIdx = 4
        saveProfile()
    else if m.focusIdx = 5
        m.top.closed = true
    else if m.focusIdx = 6
        confirmDelete()
    end if
end sub

' ---- Delete (non-default profiles) ------------------------------------------

sub confirmDelete()
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Delete " + m.name + "?"
    dialog.message = "This removes the profile and its favorites, lists, and resume points from this device."
    dialog.buttons = ["Delete", "Cancel"]
    dialog.observeField("buttonSelected", "onConfirmDelete")
    m.top.getScene().dialog = dialog
end sub

sub onConfirmDelete()
    dialog = m.top.getScene().dialog
    yes = (dialog.buttonSelected = 0)
    dialog.close = true
    if yes
        DeleteProfile(m.top.profileId)
        m.top.closed = true
    else
        m.top.setFocus(true)
    end if
end sub

' ---- Avatar row -------------------------------------------------------------

sub avatarRow()
    if m.avatar <> ""
        dialog = CreateObject("roSGNode", "Dialog")
        dialog.title = "Avatar"
        dialog.buttons = ["Change avatar", "Use colored initial", "Cancel"]
        dialog.observeField("buttonSelected", "onAvatarRowDialog")
        m.top.getScene().dialog = dialog
    else
        openAvatarPicker()
    end if
end sub

sub onAvatarRowDialog()
    dialog = m.top.getScene().dialog
    choice = dialog.buttonSelected
    dialog.close = true
    if choice = 0
        openAvatarPicker()
    else if choice = 1
        m.avatar = ""
        build()
        m.top.setFocus(true)
    else
        m.top.setFocus(true)
    end if
end sub

sub openAvatarPicker()
    pk = m.top.getScene().createChild("AvatarPickerScreen")
    pk.observeField("closed", "onAvatarPicked")
    m.avatarPicker = pk
    pk.setFocus(true)
end sub

sub onAvatarPicked()
    if m.avatarPicker <> invalid
        if m.avatarPicker.picked = true then m.avatar = m.avatarPicker.selected
        m.top.getScene().removeChild(m.avatarPicker)
        m.avatarPicker = invalid
    end if
    build()
    m.top.setFocus(true)
end sub

sub editName()
    kb = CreateObject("roSGNode", "StandardKeyboardDialog")
    kb.title = "Profile name"
    kb.text = m.name
    kb.buttons = ["Save", "Cancel"]
    kb.keyboardDomain = "generic"
    edit = kb.textEditBox
    edit.voiceEnabled = true
    edit.voiceEntryType = kb.keyboardDomain
    edit.maxTextLength = 255
    kb.observeField("buttonSelected", "onNameDone")
    m.top.getScene().dialog = kb
end sub

sub onNameDone()
    kb = m.top.getScene().dialog
    name = StdKeyboardText(kb)
    if kb.buttonSelected = 0 and name <> "" then m.name = name
    kb.close = true
    build()
    m.top.setFocus(true)
end sub

sub pinRow()
    if m.pinHash <> ""
        dialog = CreateObject("roSGNode", "Dialog")
        dialog.title = "Profile PIN"
        dialog.buttons = ["Change PIN", "Remove PIN", "Cancel"]
        dialog.observeField("buttonSelected", "onPinRowDialog")
        m.top.getScene().dialog = dialog
    else
        promptNewPin()
    end if
end sub

sub onPinRowDialog()
    dialog = m.top.getScene().dialog
    choice = dialog.buttonSelected
    dialog.close = true
    if choice = 0
        promptNewPin()
    else if choice = 1
        m.pinHash = ""
        build()
        m.top.setFocus(true)
    else
        m.top.setFocus(true)
    end if
end sub

sub promptNewPin()
    kb = CreateObject("roSGNode", "PinDialog")
    kb.title = "Set a 4-digit PIN"
    kb.observeField("accepted", "onNewPin")
    kb.observeField("cancelled", "onNewPinCancel")
    m.pinDialog = kb
    ' The scene's dialog slot, not a child — see PinDialog.
    m.top.getScene().dialog = kb
end sub

sub removePinDialog()
    if m.pinDialog <> invalid
        m.pinDialog.close = true
        m.pinDialog = invalid
    end if
end sub

sub onNewPin()
    entered = m.pinDialog.value
    removePinDialog()
    ' Hash against the profile's syncId. For a new profile the syncId isn't
    ' assigned until Save, so stash the raw PIN and hash at save time.
    m.pendingPin = entered
    m.pinHash = "SET" ' placeholder so the row shows On; real hash set on save
    build()
    m.top.setFocus(true)
end sub

sub onNewPinCancel()
    removePinDialog()
    m.top.setFocus(true)
end sub

sub saveProfile()
    if m.editing
        id = m.top.profileId
        UpdateProfile(id, m.name, m.color)
        p = ProfileById(id)
        syncId = ToStr(p.syncId)
        if m.pinHash = "" then
            SetProfilePinHash(id, "")
        else if m.pendingPin <> invalid
            SetProfilePinHash(id, ProfilePinHash(syncId, m.pendingPin))
        end if
    else
        id = CreateProfile(m.name, m.color)
        p = ProfileById(id)
        syncId = ToStr(p.syncId)
        if m.pinHash <> "" and m.pendingPin <> invalid
            SetProfilePinHash(id, ProfilePinHash(syncId, m.pendingPin))
        end if
    end if
    SetProfileAvatar(id, m.avatar)
    m.top.closed = true
end sub
