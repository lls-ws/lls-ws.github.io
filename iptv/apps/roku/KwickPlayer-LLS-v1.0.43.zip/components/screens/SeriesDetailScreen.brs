' Series detail: get_series_info -> seasons -> episodes. Focus moves
' season list <-> episode list; OK on an episode plays it, and * opens a
' menu for it.
'
' ---- What this screen knows about "watched", and where it gets it ----------
'
' Every watched state on this page — the tick beside an episode, the bar for a
' part-watched one, which episode the Play button names, which options the
' "..." menu offers, and which episode auto-plays next — comes from ONE scan
' (scanWatchState) run once per page build. Nothing on this page asks the
' panel about an episode.
'
' THAT IS THE RULE, NOT A PREFERENCE. This screen makes exactly one request,
' get_series_info, and it already carries every episode of every season. A
' per-row request would be the loop that got this house's provider access
' banned on 2026-08-14. So would a per-row registry read: the scan walks each
' registry section ONCE and answers the whole show out of a map, because
' twenty roRegistrySection reads in a bind loop is a documented visible
' stutter.
'
' The two stores it reads:
'   kwick_seen    finished marks (Store.brs, GAP D0) - LoadSeenSet, one walk
'   kwick_resume  saved positions - loadResumeSet below, one walk
' Their keys are identical strings by design, so one key answers both.

sub init()
    m.theme = KwickTheme()
    m.top.findNode("bg").color = m.theme.background
    ' This screen is an OVERLAY on the scene, not a page inside the shell —
    ' the backdrop above is what hides the sidebar and the screen behind it,
    ' so AppScene's grid wash cannot show through. Draw it here instead, over
    ' this screen's own background and under everything else it draws. See
    ' AddPageGrid() in Theme.brs for why the backdrop above cannot simply be
    ' deleted.
    AddPageGrid(m.top)

    ' ---- The shell theme's type, page-wide ---------------------------------
    ' JetBrains Mono via Theme.brs. TYPE AND COLOUR ONLY: the button chain on
    ' this page is hand-wired below and every number in it is load-bearing.
    ' Each label was measured at mono's flat 0.6em against its own box and
    ' every one clears, so no size on this screen changed.
    '
    ' NOTE FOR ANYONE CHANGING m.plot's SIZE: it is also m.rbFont, the font
    ' the ratings strip measures its chip widths in. Changing it changes how
    ' many badges fit per row. 24 is deliberately unchanged.

    ' ---- The hero -----------------------------------------------------------
    m.backdropArt = m.top.findNode("backdrop")
    ' The fallback panel behind the artwork, so a show with no picture at all
    ' is a flat surface rather than a hole. Android does the same
    ' (ColoredBox(color: colors.surface) in detail_hero.dart).
    m.top.findNode("heroDim").color = Left(m.theme.background, 8) + "40"
    m.top.findNode("heroFade").blendColor = m.theme.background
    m.top.findNode("heroSeal").color = m.theme.background

    m.title = m.top.findNode("title")
    ' 46, centred in 1824, matching the film page exactly - 66 characters in
    ' JetBrains Mono's flat 0.6em, where the old left-aligned 1440px box held
    ' 54. Show titles are short and the headline got roomier when it moved to
    ' the middle of the screen, so nothing had to shrink.
    m.title.font = UiBoldFont(46)
    m.title.color = m.theme.textPrimary

    ' ---- The show's own lettering -------------------------------------------
    ' Same feature, same `lg` field, same shared code as the film page. See the
    ' block in RatingBadges.brs and the geometry argument in the XML.
    m.tlLogo = m.top.findNode("titleLogo")
    m.tlLabel = m.title          ' the words, the fallback in every direction
    m.tlMaxW = 880               ' Android's 440dp maxWidth, doubled
    ' 236, where this was 120 this afternoon, 110 this morning and 88 before
    ' that. It is NOT arithmetic this file chose: an episode row is worth
    ' exactly 58px to this cap, Mason was given the three prices (7 rows -> 120,
    ' 6 -> 178, 5 -> 236) and bought two rows. The full sum is written out in
    ' the column block in the XML. Still not the film page's 260, which would
    ' have cost the synopsis a line on top of the rows - he refused that.
    m.tlMaxH = 236
    m.tlBottom = 290             ' the bottom edge the title text ends on
    m.tlCentre = 960             ' the page is one centred column
    m.tlOn = false               ' is the picture up, as opposed to merely asked for
    m.tlBad = {}                 ' urls this session has already watched fail
    m.tlLogo.observeField("loadStatus", "onTitleLogoLoad")

    m.plot = m.top.findNode("plot")
    ' 24, wrapped, LEFT-ALIGNED, TWO lines reserved in 1320: about 91 characters
    ' a line in JetBrains Mono's flat 0.6em, so ~183 over the two. STILL TWO
    ' when the lists went to five rows on 2026-08-27: the rows paid for the
    ' wordmark and the synopsis was explicitly not on the table - Mason asked
    ' for it moved and readable, not shortened.
    '
    ' IT SITS BELOW THE BUTTON ROW NOW (2026-08-27), not inside the hero -
    ' Mason, from the television: "put the decription under the buttons but
    ' above the seasons and episodes". That is where the FILM page puts its
    ' plot, and it is why the film page's plot never needed a plate: below the
    ' hero it is on flat page background rather than on the artwork. The plate
    ' this block used to sit on is GONE with the move - see the XML.
    '
    ' It got WIDER rather than narrower: 1104 inside the hero, 1320 out here,
    ' which is about 37 more characters on the same two reserved lines. Still
    ' two, and still fixed: the Seasons and Episodes headings sit at a fixed y
    ' and a block that grew with the synopsis would push the lists out of the
    ' title-safe area. UNVERIFIED on the television.
    pf = UiFont(24)
    m.plot.font = pf
    ' textPrimary, where this was textSecondary. Reported illegible on the
    ' stick when it was inside the hero. It is the same rank of information as
    ' the film page's plot, which is textPrimary on this same flat background
    ' and reads perfectly, so the two pages now match outright.
    m.plot.color = m.theme.textPrimary
    m.plot.lineSpacing = 4

    ' ---- The synopsis as a focus stop ---------------------------------------
    ' The three nodes that make the plot block pressable, plus the shared panel
    ' behind them. Everything about the arrangement - why it is an overlay
    ' rather than a reflow, and why it costs no texture - is written out at the
    ' bottom of RatingBadges.brs.
    m.dpFrame = m.top.findNode("descFrame")
    m.dpCapPlate = m.top.findNode("descCapPlate")
    m.dpCap = m.top.findNode("descCap")
    ' 20, one line in a 288px box: mono's flat 0.6em is 12px a character, so the
    ' caption's 23 characters are 276px with 12 to spare. Smaller than the film
    ' page's 22 because this caption is BESIDE the words rather than under them,
    ' and every pixel it takes comes off the synopsis's line length. Kept at 20
    ' after the block moved below the buttons: the block is wider out here, so
    ' the caption is cheaper than it was, but a different size would be a new
    ' glyph atlas in texture memory for the sake of 23 characters.
    m.dpCap.font = UiBoldFont(20)
    m.dpCap.text = dpCaptionText()
    ' The panel's three faces are ones this screen already draws, so the panel
    ' adds no glyph atlas to texture memory: bold 28 is the button face and the
    ' Seasons/Episodes headings, 24 is this plot's own face and the ratings
    ' strip's.
    m.dpHeadFont = UiBoldFont(28)
    m.dpBodyFont = pf
    m.dpBodySize = 24
    m.dpHintFont = pf
    ' Is the highlight on the synopsis rather than on a button or in the lists?
    ' All three are mutually exclusive and are repainted together.
    m.descFocus = false
    m.dpOn = false

    ' ---- Metadata chips (Android's MetaChip) --------------------------------
    ' The row itself is hcDrawChips in RatingBadges.brs, shared with the film
    ' page; these four fields are what it reads. The plate is
    ' images/card_fill.9.png rather than a Rectangle because Roku cannot round
    ' a Rectangle, and that file is ALREADY RESIDENT for every card in the app.
    m.chipsGrp = m.top.findNode("chips")
    m.chipFont = UiFont(25)
    m.chipIconFont = IconFont(28)
    ' 85% of the theme's own surfaceElevated, built from the token so a reskin
    ' carries it. Theme colours are "0xRRGGBBAA", so Left(...,8) is the RGB.
    m.chipFill = Left(m.theme.surfaceElevated, 8) + "D9"
    m.chipDefs = []

    ' ---- The ratings strip (GAP I1) -----------------------------------------
    ' The film page has had this since this morning; the owner asked for it on
    ' "the details pages", and Android draws it on both. The strip itself lives
    ' in source/utils/RatingBadges.brs and shares this component's `m` — its
    ' header lists what each screen has to set and why. This is that.
    m.metaTask = invalid
    m.badges = []        ' [{ s, v }] — what the strip draws, in order
    m.hasCert = false    ' the panel gave us a certificate of its own
    m.rbId = ""          ' which show the strip on screen belongs to
    m.rbTag = ""         ' which show a lookup is out for, if one is
    m.rbWho = "series detail"
    ' The one caller that has ever sent this. The service has mapped "series"
    ' to TMDB's "tv" and MDBList's "show" since it was written, but no screen
    ' had exercised the path, so a show that comes back with nothing is a
    ' perfectly ordinary answer here and not a sign of a fault.
    m.rbKind = "series"
    ' The PLOT's font, deliberately — this screen has four type sizes already
    ' and a fifth would be a new glyph atlas in texture memory for the sake of
    ' five characters. It is 24 where the film page's strip is 23, which is a
    ' difference nobody can see from a sofa and one atlas nobody has to pay for.
    m.rbFont = pf
    ' THE LANE THE STRIP CENTRES IN: the whole page, because the page is now
    ' ONE CENTRED COLUMN, exactly as the film page's is. The old note here said
    ' the strip had to centre on the cover's 240 because x=960 ran straight
    ' through the Shuffle and Mark Series buttons - that was true of the
    ' two-column page and is not true of this one. The cover is gone with it.
    m.rbLane = 1920
    ' ONE row, where the 240px cover needed two. rbRowY's length is the row cap,
    ' and at 1920 wide a full six-badge answer fits on one - the hero reserves
    ' exactly 34px for it, so nothing can push into the buttons below.
    m.rbRowY = [0]
    ' Drawn in clear space rather than over artwork, so no scrim.
    m.rbScrim = false
    m.rbScrimH = 0
    ' The same instrument the film page uses, for the same reason: the gate
    ' that refuses to spend anything on decoration on a box near the edge, and
    ' the "opened"/"enriched" console lines that have to be read off real
    ' hardware. Texture is not heap and this cannot see it — the arithmetic for
    ' the logos is written out at the top of RatingBadges.brs instead.
    m.memMon = CreateObject("roAppMemoryMonitor")

    ' "Seasons" / "Episodes", auto-width Labels with clear space beside them.
    sf = UiBoldFont(28)
    m.seasonsTitle = m.top.findNode("seasonsTitle")
    m.seasonsTitle.text = "Seasons"
    m.seasonsTitle.font = sf
    m.seasonsTitle.color = m.theme.textPrimary
    m.episodesTitle = m.top.findNode("episodesTitle")
    m.episodesTitle.text = "Episodes"
    m.episodesTitle.font = sf
    m.episodesTitle.color = m.theme.textPrimary

    m.seasonList = m.top.findNode("seasonList")
    ' THE SEASON LIST WAS NEVER THEMED. A LabelList draws its rows in the
    ' platform's own default font unless it is given one, and this one never
    ' was — which did not show while the rest of the app was Roboto, and shows
    ' immediately now that everything around it is JetBrains Mono. See
    ' ThemeLabelList() in Theme.brs for the four fields it sets and why the
    ' focused row can safely go bold on a mono face.
    '
    ' 26 in a 300px row: 19 characters. The rows are "Season 1", "Specials"
    ' and the like, so there is room to spare.
    ThemeLabelList(m.seasonList, 26)
    m.seasonList.observeField("itemFocused", "onSeasonFocused")
    m.seasonList.observeField("itemSelected", "onSeasonSelected")
    m.episodeList = m.top.findNode("episodeList")
    m.episodeList.observeField("itemSelected", "onEpisodeSelected")

    m.spinner = m.top.findNode("spinner")
    m.spinner.poster.uri = "pkg:/images/spinner.png"

    ' ---- Action buttons (Android's terminal DetailActionButton) -------------
    ' The five hand-placed Groups this page used to draw - a Rectangle ring, a
    ' Rectangle fill and a Label, twice over in two columns - are gone. The
    ' drawing is now hbLayout / hbMakeButton / hbPaint in RatingBadges.brs,
    ' shared with the film page, so the two pages cannot drift on the plate,
    ' the frame, the hard offset shadow, the ink rule or the focus lift.
    ' Everything below is this screen's half of that arrangement; the file's
    ' own header lists what each screen has to set and why.
    '
    ' >>> THE FRAME COLOUR IS DERIVED. Nord Shell sets the theme's border TO
    ' its accent, so an accent-filled button would have a frame and a shadow at
    ' 1.00:1 against itself. 0x4E6572 is the walk Android's detailButtonEdge
    ' does - 3.06:1 against the fill - and it is the same pair the film page
    ' passes in.
    ' m.hbEdgeOnLight, not m.hbEdgeOnAccent: since 2026-08-27 a FOCUSED button
    ' fills with focusHighlight rather than the accent, so this one derived
    ' colour now sits on two different light fills. It clears WCAG 1.4.11's 3:1
    ' against both - 3.1:1 on the accent, 3.9:1 on the focus yellow - which is
    ' why there is still only one of it. See hbPaint in RatingBadges.brs.
    m.hbEdgeOnLight = "0x4E6572FF"
    m.hbEdgeOnSurface = m.theme.surfaceBorder
    ' 28, matching the film page. The longest label is "Mark Series as Watched"
    ' at 22 characters = 370px in mono at 28; a secondary button is sized to its
    ' own widest text so nothing truncates, and hbLayout checks the row's total
    ' width rather than hoping at it.
    m.hbFont = UiBoldFont(28)
    ' Android: 19dp on the primary, 17dp on a secondary. Doubled.
    m.hbIconFontPri = IconFont(38)
    m.hbIconFont = IconFont(34)
    m.buttons = []       ' [{ key, primary, shadow, fill, edge, ico, lbl, ... }]

    ' ---- The button chain ---------------------------------------------------
    ' -1 = focus in the LISTS; 0..N-1 is a button. The whole D-pad chain is
    ' hand-wired below in onKeyEvent and every number in it is load-bearing.
    '
    ' THE SHAPE IS NOW THE FILM PAGE'S, because the buttons are now the film
    ' page's: index 0 is the primary, alone on row 0 and centred; 1..N-1 are
    ' the secondaries on row 1, left to right. hbLayout guarantees that and
    ' nothing here depends on which buttons exist. The old two-column grid
    ' (Play/Favorites/Add-to-List down the left at x=380, Shuffle/Mark down the
    ' right at x=844) is gone with the Groups that drew it.
    '
    '   y=398 ---------------- 0  Play / Resume ----------------
    '   y=510   1 Shuffle   2 Mark Series   3 Favorites   4 Add to List
    '   y=600 ------------------- the synopsis block -------------------
    '   y=684 ------------------- Seasons / Episodes -------------------
    '   y=728 ---- five visible rows, ending ON title-safe at 1018 ------
    '
    '   up     0->0 (stays)       1..N-1 -> 0
    '   down   0->1               1..N-1 -> the synopsis, else the season list
    '   left   0->0 (stays)       1->1 (stays)   i->i-1
    '   right  0->0 (stays)       i->i+1         N-1->N-1 (stays)
    '   back   always closes the page
    '
    ' THE SYNOPSIS MOVED BELOW THE BUTTON ROW (2026-08-27) and its focus stop
    ' moved with it, because directional focus on this page is decided purely
    ' by geometry and a stop that is not where it looks is a bug you cannot
    ' explain to anyone. It used to be reached by Up from the primary; it is now
    ' reached by Down from any secondary, and it hands on Down to the season
    ' list and back Up to the first secondary. Up from the primary now stays
    ' put - there is nothing focusable above it, the chips and the ratings strip
    ' being Labels and Posters.
    '
    ' It is a stop ONLY while there is something to read (m.dpOn), so a show
    ' whose details never arrived walks buttons -> lists exactly as it did
    ' before this existed.
    '
    ' THE LIST EXITS. Down out of any secondary lands on the synopsis, or on the
    ' season list when there is no synopsis. Back climbs episodes -> seasons ->
    ' synopsis (or button 1) -> close. Up out of the season list at its top row
    ' goes to the same place - see leaveListsUpward(), which is the one copy of
    ' that decision.
    '
    ' NOT SYMMETRIC ON PURPOSE, and the film page makes the same trade in the
    ' same words: down from button 3 and back up returns to button 1, not to 3.
    ' Remembering the column would be a shade nicer and it is a second
    ' behaviour to maintain on a chain two people already share. Deterministic
    ' beats clever.
    '
    ' The page OPENS on Play, like Android's autofocused detail button.
    m.btnFocus = 0
    m.keySink = m.top.findNode("keySink")

    m.provider = ActiveProvider()
    m.seasons = []          ' [{num, episodes:[{id, title, ext}]}]
    m.seasonIdx = 0
    m.player = invalid
    m.shuffleOn = false
    m.shuffleQueue = []
    m.shufflePos = 0

    ' Watched state (GAPs D1/D2/D3/D5) — filled by scanWatchState.
    m.seriesRef = ""        ' "series:<src>~<id>", the parent every mark carries
    m.resumeTarget = invalid ' {s, e, posS, durS, resume} or invalid
    m.epCount = 0
    m.optEp = invalid       ' which episode the "..." menu is about
    m.optKeys = []          ' that menu's buttons, by action, in button order

    ' Auto-play next (GAP D4).
    m.playingS = -1
    m.playingE = -1
    m.upNext = invalid      ' the countdown card, while it is on screen
    m.nextEp = invalid      ' what it is counting down to

    ' Is the show on screen one from the member's own Jellyfin or Emby, and
    ' which show is a media-server episode request out for? All of these are
    ' rewritten on EVERY show; they are only so the fields exist before the
    ' first one arrives.
    m.isMs = false
    m.msSeriesId = ""
    ' The lettering the member's OWN server holds for this show, remembered for
    ' the life of the page so it can be put back if the metadata answer takes
    ' it down — see onMsMeta.
    m.msLogo = ""
    ' The two facts the chip row needs that only the library row knows. Held
    ' rather than pushed straight onto m.chipDefs because the row is rebuilt
    ' whole every time anything about it changes — see msSeriesChips.
    m.msYear = 0
    m.msGenre = ""
    ' Which show a one-off details fetch is out for.
    m.msItemId = ""
    m.msItemTask = invalid

    ' The one-frame delay that lets this page have the last word on the
    ' lettering. It is pinned now (tlPinLogoUrl), so nothing can take it down.
    ' (The 0.1s re-assert timer is gone: the logo is pinned - tlPinLogoUrl -
    ' so there is no race left to paper over.)

    ' Parental gate (see the block at the bottom of this file).
    m.pgate = invalid    ' the snapshot, taken once when the item arrives
    m.catName = ""       ' this show's category, once get_series_info answers
    m.pendingPlay = invalid
    m.pinDialog = invalid
    ' The Media Bar's landscape artwork for this show, once get_series_info
    ' answers. See onInfo.
    m.backdrop = ""
    m.top.observeField("focusedChild", "onFocusIn")
    ' LAST BUT ONE, so the reading panel is the last child of this screen and
    ' therefore draws over the lists as well as the hero. Built ONCE, here, and
    ' never rebuilt: whatever a press reveals has to already exist in its final
    ' position, because Roku decides directional focus purely on geometry.
    dpBuild()
    ' buildButtons, not redrawButtons: the row has to EXIST before anything can
    ' be painted into it, and a member who reaches this page before
    ' get_series_info answers must still see a highlighted Play button rather
    ' than an empty hero.
    buildButtons()
end sub

' Build the action row for the show's current state.
'
' ANDROID'S ARRANGEMENT AND ANDROID'S ORDER (series_detail_screen.dart:560-710):
' the primary alone on its own line, then the secondaries wrapped in a row
' beneath it - Play, Shuffle Episodes, Mark Series as Watched, Favorites, Add
' to List. Roku has no Wrap, so hbLayout measures the row and centres it.
'
' THE SET NEVER CHANGES SHAPE. Android hides Shuffle on a one-episode show and
' hides Mark Series until something is part-watched; both stay put here, with
' labels that say which way they will go. A row that gained and lost a button
' would renumber m.buttons under the member's thumb, and the chain indexes
' straight into it - which is the hazard this page's own notes have warned
' about since the "..." menu was built.
'
' THE PARENTAL GATE IS UNTOUCHED BY ANY OF THIS. It hangs off playEpisode() and
' reads nothing from m.btnFocus, so the shape of the row cannot reach it.
sub buildButtons()
    col = m.top.findNode("buttonCol")
    while col.getChildCount() > 0
        col.removeChildIndex(0)
    end while
    m.buttons = []

    specs = []
    ' Index 0 is ALWAYS the primary and is always alone on row 0. Its words are
    ' written by redrawButtons, which is where the resume target is spelt out;
    ' `widest` is what the ROW is measured against, and the primary is not in
    ' that row, so it is left empty.
    specs.push({ key: "play", text: "", icon: m.theme.iconPlay, primary: true, widest: "" })
    ' NO ICON, and that is deliberate rather than an omission. The Material
    ' codepoints this app draws are only ever ones ALREADY PROVEN in the
    ' package - a wrong codepoint draws the wrong picture and this repo has been
    ' burned by exactly that (the E1A8/E1B8 note in PlayerScreen.brs) - and
    ' there is no proven `shuffle` glyph here. The house rule is to say it in
    ' words rather than guess at a picture, and hbMakeButton gives a button with
    ' no icon the whole width for its label.
    specs.push({ key: "shuffle", text: "Shuffle Episodes", icon: "", primary: false, widest: "Shuffle Episodes" })
    ' iconCheck (E5CA) for Android's check_circle_outline - proven here, and the
    ' same glyph the film page's Mark as Watched carries.
    specs.push({ key: "markseries", text: "Mark Series as Watched", icon: m.theme.iconCheck, primary: false, widest: "Mark Series as Watched" })
    ' THE HEART, not Android's star - the favourite mark in THIS app is a heart
    ' everywhere it appears, and the film page made the same call for the same
    ' reason. `widest` names the longer of the two states, because the label is
    ' still empty when hbLayout measures the row.
    specs.push({ key: "favorite", text: "", icon: Chr(&hE87E), primary: false, widest: "Remove from Favorites" })
    specs.push({ key: "addlist", text: "", icon: Chr(&hE03B), primary: false, widest: "Add to List" })

    ' Android's terminal geometry, doubled: primaryButtonHeight 42 -> 84,
    ' secondaryButtonHeight 36 -> 72, gapAfterPrimary 14 -> 28. Everything else
    ' - the spacing, the icon gaps, the shadow offset, the lift - lives in
    ' RatingBadges.brs so the two detail pages cannot drift on it.
    '
    ' 720 for the primary is the film page's width, inside Android's
    ' 200..440dp -> 400..880px clamp.
    '
    ' THE ROW IS CHECKED, NOT HOPED AT. The widest set here is "Shuffle
    ' Episodes" + "Mark Series as Watched" + "Remove from Favorites" + "Add to
    ' List", about 1645px in mono at 28 against the 1824 the hero column has.
    ' hbLayout tightens the gap from 36 to 12 before anything runs off the edge.
    '
    ' secY IS BACK TO 112, i.e. Android's gapAfterPrimary(14) doubled to 28. It
    ' was squeezed to 104 (a 20px gap) while the hero was 468 and every pixel
    ' was being scraped for the wordmark, and two filled button plates 14px
    ' apart looked crowded. buttonCol now sits at y=398: primary 398..482, its
    ' 6px offset shadow to 488, secondary 510..582, its shadow to 588, hero
    ' bottom 590. 22px clear between the rows and 2px under the last shadow -
    ' the same 2px of slack every version of this column has had.
    m.buttons = hbLayout(col, specs, 0, 84, 720, 112, 72)

    if m.btnFocus >= m.buttons.count() then m.btnFocus = 0
    redrawButtons()
end sub

' THE WORDS, and only the words - the plate, the frame, the shadow, the ink and
' the lift are hbPaint's job (RatingBadges.brs), shared with the film page.
'
' EVERY STATEFUL LABEL IS WRITTEN BOTH WAYS, EVERY TIME. A label written only
' inside its "on" branch smears the previous state onto the next repaint, and
' this runs on every arrow press across the row.
sub redrawButtons()
    ' The synopsis block first, and OUTSIDE the empty-row guard below: it is not
    ' part of the button row and has to be repainted even on the one frame
    ' before the row exists, or a page that got here early would draw a frame in
    ' whatever state the last show left it.
    dpPaintBlock(m.descFocus)
    if m.buttons.count() = 0 then return
    favored = false
    inList = false
    if m.top.item <> invalid
        favored = IsFavoriteVod("series", ToStr(m.top.item.seriesId), m.itemSrc)
        inList = IsInAnyList("series", ToStr(m.top.item.seriesId), m.itemSrc)
    end if

    for i = 0 to m.buttons.count() - 1
        b = m.buttons[i]
        favInk = false
        if b.key = "play"
            b.lbl.text = seriesPlayLabel()
            b.ico.text = m.theme.iconPlay
        else if b.key = "favorite"
            if favored
                b.lbl.text = "Remove from Favorites"
                b.ico.text = Chr(&hE87D)   ' favorite (filled heart)
                favInk = true
            else
                b.lbl.text = "Add to Favorites"
                b.ico.text = Chr(&hE87E)   ' favorite_border
            end if
        else if b.key = "addlist"
            if inList
                b.lbl.text = "In Lists"
                b.ico.text = Chr(&hE065)   ' playlist_add_check
            else
                b.lbl.text = "Add to List"
                b.ico.text = Chr(&hE03B)   ' playlist_add
            end if
        else if b.key = "markseries"
            ' Mark Series as Watched only ever ADDS marks, so it stays the same
            ' words whatever the show's state is. Written anyway, on every
            ' repaint, rather than left to whatever hbMakeButton first put
            ' there - this page is one node kept across shows.
            b.lbl.text = "Mark Series as Watched"
            b.ico.text = m.theme.iconCheck
        else if b.key = "shuffle"
            b.lbl.text = "Shuffle Episodes"
            b.ico.text = ""
        end if
        b.favInk = favInk
    end for
    ' -1 WHEN THE SYNOPSIS HOLDS THE HIGHLIGHT, so no button is painted focused.
    ' The stops are mutually exclusive and are repainted TOGETHER, on the same
    ' two lines, which is what makes it impossible to leave the yellow fill on a
    ' button the member has already walked off.
    idx = m.btnFocus
    if m.descFocus then idx = -1
    hbPaint(m.buttons, idx)
end sub

' ---- What the Play button says (GAP D2) -------------------------------------
' Android names the episode on it: "Resume S01E07 - 22m left"
' (series_detail_screen.dart:480). scanWatchState has already worked out WHICH
' episode that is; this only spells it.
'
' A show with somewhere to pick up gets a SERIES-level button, so the label -
' and the press - stop following the season list, exactly as on Android where
' Resume sits above a list you scroll freely. A show with nowhere to pick up
' keeps the behaviour this page has always had: the first episode of the
' SELECTED season, label included.
function seriesPlayLabel() as string
    t = m.resumeTarget
    if t <> invalid and t.s < m.seasons.count()
        s = m.seasons[t.s]
        e = s.episodes[t.e]
        tag = "S" + pad2(s.num) + "E" + pad2(e.epNum)
        if t.resume
            ' NOT "left" - that is a BrightScript built-in and package.py
            ' blocks the build over it (see its RESERVED list).
            leftTxt = epLeftText(t.posS, t.durS)
            if leftTxt <> "" then return "Resume " + tag + " - " + leftTxt
            return "Resume " + tag
        end if
        return "Play " + tag
    else if m.seasons.count() > 0 and m.seasonIdx < m.seasons.count()
        s = m.seasons[m.seasonIdx]
        return "Play  S" + s.num.toStr() + "E" + s.episodes[0].epNum.toStr()
    end if
    return "Play"
end function

' "22m left" / "1h 5m left", or "" when there is nothing worth saying.
'
' Store.brs has ResumeLeftText, but it returns the whole button label
' ("Resume - 22m left") and this one needs the episode tag in the middle of
' it. Same rules, just the tail: under a minute left is not "left", it is
' finished in all but name.
function epLeftText(positionS as integer, durationS as integer) as string
    if durationS <= 0 then return ""
    leftS = durationS - positionS
    if leftS < 60 then return ""
    mins = Int(leftS / 60)
    if mins >= 60
        hrs = Int(mins / 60)
        remMins = mins mod 60
        return hrs.toStr() + "h " + remMins.toStr() + "m left"
    end if
    return mins.toStr() + "m left"
end function

' ---- Guarded handlers (v1.0.41) ---------------------------------------------
'
' Every entry point the render thread can call on this page now runs under
' try/catch and reports through GuardFailed (Util.brs), the same way Home, the
' Media Bar, the TV Guide and the channel page already do. A fault now leaves
' one line in the log - "crash averted in series/<handler>", naming the file,
' the line and the function - and arms the next-launch crash report, instead of
' the app dying with no stack at all.
'
' WHY THIS PAGE, IN PLAIN WORDS. The 2026-10-12 log sweep found one crash in
' twenty-nine member logs that still could not say anything about itself: log
' key 96C9BD, a TCL 43S451 on v1.0.41, where the app ran for an hour and a half
' and then stopped dead with only "EXIT_BRIGHTSCRIPT_CRASH" written down - no
' file, no line, no function. That member was opening film and show pages, and
' these were the last two screens in the app with seventeen observers between
' them and not one guard. 96C9BD itself was NOT traced and probably never will
' be; the point of this block is that the next one on this page names itself.
'
' THIS PAGE HAS MORE WAYS IN THAN ANY OTHER SCREEN - twenty-one, because it
' owns two lists, a player, an Up Next card, four dialogs and the PIN pad.
' Twenty of them are in this file and all twenty are guarded below. Count them
' yourself and you will come up short, so here is the whole list: seventeen
' observeField callbacks, the `item` field's onChange in the XML, onKeyEvent,
' and - the two that no grep of this file will show you - onParentalPin and
' onParentalPinCancel, whose names go out as strings to ParentalGuardWith and
' get observed on the PIN keyboard by GuideMeta.brs:369-370.
'
' GuardFailed IS REACHABLE HERE because SeriesDetailScreen.xml names
' pkg:/source/utils/Util.brs (SeriesDetailScreen.xml:14). A component only sees
' the scripts its own XML names, and that line is what makes these calls legal.
'
' init() IS DELIBERATELY NOT GUARDED, here as on Home, VOD and the Media Bar.
' A fault in init leaves a page with half its fields missing, and a guard there
' would turn one honest crash into every handler below it faulting for the rest
' of the session. A crash in init is a crash that should be found and fixed.
'
' ONE ENTRY POINT ON THIS PAGE IS STILL UNGUARDED AND IT IS NOT IN THIS FILE:
' the title-logo observer set at :81 calls onTitleLogoLoad, which lives in
' RatingBadges.brs:745. This job was scoped to the two detail screens, so that
' one is left as it was and is still able to die without a word.
'
' WHERE A CATCH PUTS FOCUS BACK it calls restoreFocusAfterDialog(), which is
' this file's own existing split (key sink while a button is active, episode
' list otherwise). That is safe to call from a catch for one specific reason:
' it reads m.keySink and m.episodeList, both set in init, and init is NOT
' guarded - so if init had faulted the render thread would already be dead and
' none of these handlers would be running at all. A handler that is running is
' a handler whose init finished.
'
' CATCHES DO NOT REACH FOR getScene(). An orphaned page is exactly the case
' where getScene() comes back invalid, which makes it a likely cause of the
' fault being caught; a second go at it from inside a catch would fault where
' nothing is listening, and that is a real crash instead of a caught one. So no
' catch here closes a dialog or removes a child - it only sets fields on m and
' moves focus inside this page.
sub onFocusIn()
    try
        onFocusInInner()
    catch e
        GuardFailed("series/onFocusIn", e)
        ' LOGGED AND NOTHING ELSE, on purpose - the one handler in this file
        ' that gets no recovery at all. This is the focusedChild observer
        ' (set in init), so moving focus from in here fires it again: a
        ' handler that faulted every time would recurse until the stack gave
        ' out, which is a worse crash than the one being guarded.
        '
        ' Leaving it alone is safe enough to live with. Focus stays wherever
        ' the firmware already put it inside this page, so onKeyEvent still
        ' fires and the Back ladder below still gets the member off the page.
    end try
end sub

sub onFocusInInner()
    if not m.top.hasFocus() then return
    ' Buttons active -> the key sink holds focus; lists active -> seasons.
    if m.btnFocus >= 0
        m.keySink.setFocus(true)
    else
        m.seasonList.setFocus(true)
    end if
end sub

sub onItem()
    try
        onItemInner()
    catch e
        GuardFailed("series/onItem", e)
        ' TAKE THE SPINNER DOWN. onItemInner is what turns it on, and only the
        ' answer handlers below ever turn it off, so a fault in between leaves
        ' the member watching this page spin for as long as they are willing to
        ' wait. Down, they get a page missing some of its facts - which is
        ' honest about having nothing, and which Back still leaves.
        if m.spinner <> invalid
            m.spinner.visible = false
            m.spinner.control = "stop"
        end if
    end try
end sub

sub onItemInner()
    it = m.top.item
    if it = invalid then return
    ' CLEARED ON EVERY BIND, BOTH WAYS. Every opener makes a fresh node today,
    ' so these cannot currently be stale — but they are only filled in when the
    ' details answer arrives, and a node that was ever reused would carry the
    ' PREVIOUS show's catalogue id into this one. That id now decides which
    ' show gets ticked on the member's own Trakt and Simkl accounts, where a
    ' wrong one is theirs to go and unpick, so it is emptied here rather than
    ' relying on how the page happens to be opened.
    m.subsTmdb = ""
    m.subsYear = ""
    ' Baseline, before this page has built anything. Read the "opened" lines
    ' ACROSS several shows — flat is correct, ratcheting means something is
    ' being retained between pages. See the measurement note in
    ' source/utils/RatingBadges.brs.
    rbMemSample("opened")
    ' The item's own source (set by merged screens) wins over the active
    ' one — episode URLs, favorites, and resume keys all follow it.
    m.itemSrc = invalid
    if type(it) = "roAssociativeArray" and it.doesExist("src") then m.itemSrc = ToStr(it.src)
    if m.itemSrc <> invalid
        p = ProviderForSrcToken(m.itemSrc)
        if p <> invalid then m.provider = p
    end if
    ' The poster, standing in for the backdrop until get_series_info answers
    ' with a real one (onInfo swaps it). Android does exactly this -
    ' `backdropUrl ?? posterUrl` - and it looks equally soft there: a 2:3 cover
    ' cropped into a 1920 x 552 box. Parity, not an oversight.
    '
    ' tmdbSized at w780, NOT DetailPosterUrl, which is w500 and right for its
    ' callers that draw a poster at poster size. This is a poster stretched
    ' across a 1920-wide hero, so w500 would be a 3.8x upscale where w780 is
    ' 2.5x. w780 and not more because it is the largest size TMDB documents for
    ' a POSTER path; w1280 is a backdrop size, and a size token the CDN does not
    ' serve for this path is a 404, i.e. no picture at all rather than a soft
    ' one. It only bites on TMDB urls carrying the "/w600_and_h900_bestv2/"
    ' marker - anything the panel hosts itself passes through untouched.
    m.backdropArt.uri = tmdbSized(ToStr(it.icon), "w780")
    m.title.text = ToStr(it.name)
    ' The parental snapshot: ONCE per screen open, never per button or per
    ' episode row.
    m.pgate = ParentalGate("series")
    m.catName = ""
    m.pendingPlay = invalid
    ' Last show's backdrop is not this one's, and onInfo does not run at all
    ' when the request fails. An episode played before the details land simply
    ' carries none, which the Media Bar already knows how to draw.
    m.backdrop = ""
    ' Last show's watched state is not this one's. Emptied HERE rather than
    ' left for scanWatchState, because redrawButtons runs on the line below
    ' with no episodes loaded yet — and a stale resume target would put the
    ' previous show's episode number on this show's Play button for as long
    ' as get_series_info takes to answer.
    m.seasons = []
    m.resumeTarget = invalid
    m.epCount = 0
    m.playingS = -1
    m.playingE = -1
    ' Same reasoning as everything above: the last show's scores are not this
    ' one's, and onInfo does not run at all when the request fails, so a show
    ' whose details never arrive must not keep the previous one's badges under
    ' its own cover. rbReset also records WHICH show the strip is about, which
    ' is what makes a slow answer for the previous one land on the floor
    ' instead of on this page — see onTitleMeta in RatingBadges.brs.
    rbReset(ToStr(it.seriesId))
    ' The chips belong to the show whose details are in hand, so a new show
    ' clears them outright: onInfo does not run at all when the request fails,
    ' and the previous show's year and episode count under this show's title
    ' would be wrong facts rather than missing ones.
    m.chipDefs = []
    hcDrawChips(m.chipsGrp, m.chipDefs)
    ' Last show's words are not this one's, and onInfo does not run at all when
    ' the request fails - so without this a show whose details never arrive
    ' keeps the PREVIOUS show's synopsis under its own title.
    m.plot.text = ""
    ' THE READING PANEL AND ITS FURNITURE GO WITH THE WORDS, BOTH WAYS: this
    ' page is ONE node kept across shows, and a frame and a "Press OK to read
    ' it all" plate left behind on a show whose details never arrived would be
    ' a focus stop
    ' advertising an empty panel. dpSetText writes m.dpOn and dpPaintBlock (from
    ' redrawButtons, two lines down) draws the consequence. The highlight is
    ' pulled back onto the primary so it can never be sitting on a block that
    ' just stopped existing.
    dpSetText("", "")
    if m.descFocus
        m.descFocus = false
        m.btnFocus = 0
    end if
    ' buildButtons, not redrawButtons: this page is ONE node kept across shows,
    ' and the row has to exist before anything can be painted into it. It is
    ' cheap and the set never changes shape, so rebuilding per show is the
    ' simplest thing that cannot leave a stale node behind.
    ' Cleared BOTH WAYS on every show, like everything above it: this page is
    ' one node handed a second show, and a leftover "this came from Jellyfin"
    ' would send the next Xtream show's episodes down the wrong play path. The
    ' logo address and the two chip facts go with it for the same reason — a
    ' leftover logo would put the PREVIOUS show's wordmark back up the moment
    ' this show's metadata landed.
    m.isMs = false
    m.msLogo = ""
    m.msYear = 0
    m.msGenre = ""
    m.msItemId = ""
    buildButtons()

    ' ---- A show on the member's own Jellyfin or Emby ------------------------
    ' Same page, different single request: /Shows/{id}/Episodes instead of
    ' get_series_info. ONE request per page open, the whole show in it, and
    ' nothing per season and nothing per episode row — MsEpisodesUrl exists
    ' precisely so there is no /Seasons call to make first.
    if MsIsMediaServer(m.provider)
        msLoadSeries(it)
        return
    end if

    m.spinner.visible = true
    m.spinner.control = "start"
    task = CreateObject("roSGNode", "ApiTask")
    task.url = XtreamApiUrl(m.provider, "get_series_info") + "&series_id=" + UrlEncode(ToStr(it.seriesId))
    task.observeField("result", "onInfo")
    m.task = task
    task.control = "RUN"
end sub

' ---- A show on the member's own Jellyfin or Emby -----------------------------
'
' ONE request per page open and nothing else, ever. /Shows/{id}/Episodes hands
' back every episode of every season in a single answer — that is exactly why
' MsEpisodesUrl exists and why there is deliberately no /Seasons call before
' it: the season number is already on each episode as ParentIndexNumber, and a
' request per season, per row or per rotation is the traffic shape written up
' in Wiki/Roku/Roku - Anti-Share Bans.md.
'
' The synopsis, the show's name and its year are NOT waited for — the library
' read already carried them through on the row, so they are drawn before the
' request even goes out and the page is never blank while it is in flight.
'
' The synopsis, the year, the genre, the wide backdrop, the show's own
' lettering and the ratings strip all come off the library row the grid already
' paid for, so they are drawn before the episode request even goes out and the
' page is never blank while it is in flight.
'
' WHAT IS DELIBERATELY MISSING, matching the film page: no cast and no
' director. The library read does not ask for People, and adding it would make
' every library page heavier for a line most members do not read. onItem
' cleared everything before this ran, so anything absent is EMPTY rather than
' the previous show's.
sub msLoadSeries(it as object)
    m.isMs = true

    ' ---- Which door did this show come through? -----------------------------
    ' Opened from Movies & Series it arrives with the whole library row on it.
    ' Opened from Continue Watching, Search or a favourite it arrives with an
    ' id and a name, because those doors store a place in a list and were never
    ' carrying a row. `overview` is the tell — the KEY, not its contents,
    ' because VodScreen sets all of these together or not at all.
    '
    ' The fetch below is ONE request for ONE show, on page open. It is the
    ' second of at most two this page ever makes, the other being the episode
    ' list, and both are page-level: no season, no row and no rotation ever
    ' asks anybody anything.
    if type(it) = "roAssociativeArray" and it.doesExist("overview")
        msDrawSeries(it)
    else
        msFetchSeries(ToStr(GetField(it, "seriesId")))
    end if

    ' No token means every call comes back 401. Say so instead of spending a
    ' request to be told, and instead of leaving the member on a spinner.
    if MsNeedsSignIn(m.provider)
        msSeriesUnavailable("Kwick Player can't reach " + MsBrandLabel(m.provider) + " right now. Open Settings and sign in to your server again, then come back to this show.")
        return
    end if

    ' Which show this answer will be about. The page is ONE node handed a
    ' second show, and an answer that arrives after the member has moved on
    ' must land on the floor rather than on top of the show they are looking
    ' at now.
    m.msSeriesId = ToStr(GetField(it, "seriesId"))

    m.spinner.visible = true
    m.spinner.control = "start"
    t = CreateObject("roSGNode", "MediaServerTask")
    t.url = MsEpisodesUrl(m.provider, m.msSeriesId)
    t.method = "GET"
    ' The identity header. This is the ONLY place the access token appears —
    ' never in the address, because an address is printed in the diagnostic
    ' log and written into watch history.
    t.headers = MsHeaders(m.provider)
    t.timeoutMs = 25000
    t.observeField("result", "onMsEpisodes")
    m.task = t
    t.control = "RUN"
end sub

' ---- Everything a media-server show puts on this page ------------------------
'
' ONE drawing sub and not two, because both maps that reach it carry the same
' plain field names: the row the grid handed over, and the answer to the single
' fetch below mapped through MsMapItem. It runs exactly ONCE per page open.
sub msDrawSeries(row as object)
    it = m.top.item
    if it = invalid then return

    ' Already in hand — drawn now, not after a round trip.
    m.plot.text = ToStr(GetField(row, "overview"))
    dpSetText(ToStr(it.name), m.plot.text)
    dpPaintBlock(m.descFocus)

    m.msYear = ToInt(GetField(row, "year"))
    ' One line, already cut to three genres by MsGenreLine, which is the same
    ' one chip of genre the Xtream page draws from info.genre. NO runtime chip,
    ' and that matches the Xtream series page: a runtime belongs to an episode,
    ' and this row is about the show.
    m.msGenre = ToStr(GetField(row, "genres"))
    msSeriesChips()

    ' ---- The hero, step one of three ----------------------------------------
    ' Android's order is the member's own server first, the metadata match
    ' second, the portrait poster only if neither exists. This is step one;
    ' step two is in onMsMeta below; step three is the poster onItem already
    ' put up, which is simply left alone.
    '
    ' ASSIGNED DIRECTLY, NOT THROUGH BackdropUrl(). That function exists to put
    ' the host and the size back on TMDB's short stored form. What MsImageUrl
    ' builds is already a whole address on the member's own server and would
    ' pass through untouched, so the call would be noise that reads as though a
    ' conversion were happening.
    '
    ' >>> AND IT IS THE BIGGEST TEXTURE SAVING IN THE CHANGE. The hero node is
    ' loadDisplayMode="scaleToZoom" pinned at 1920 x 590, and zoom-to-cover has
    ' to decode enough picture to CROP from: a 2:3 poster forced into a
    ' 1920-wide box decodes 1920 x 2880, which is 22 MB against a budget of
    ' roughly 90 and five out-of-memory crash reports. That is exactly what the
    ' stick logged — "Loaded texture (1920 x 2880) larger than the UI
    ' resolution ... SeriesDetailScreen/Poster:backdrop". A real landscape
    ' backdrop is 16:9, so covering the same box decodes 1920 x 1080, about
    ' 8.3 MB: roughly 14 MB saved every time a media-server show is opened. The
    ' pins do not change and neither does loadDisplayMode; feeding the node the
    ' right SHAPE of picture is the fix.
    m.backdrop = ToStr(GetField(row, "backdrop"))
    if m.backdrop <> ""
        m.backdropArt.uri = m.backdrop
        ' And onto the Continue Watching row, so the Media Bar on Home stops
        ' faking a landscape picture out of this show's portrait poster. Only
        ' the SERVER's own address is ever stored — never the TMDB one from
        ' step two — because the stored copy is mirrored across devices and a
        ' TMDB path written for a media title has not been thought through yet.
        AttachRecentBackdrop("series", ToStr(it.seriesId), m.itemSrc, m.backdrop)
    end if

    ' ---- The show's own lettering -------------------------------------------
    ' tlApplyLogoUrl and not tlApplyLogo: the server's logo address is a whole
    ' url, and tlApplyLogo is the half that expands TMDB's short form first.
    ' Everything under the split is shared — the failed-url memory, the
    ' hidden-until-loaded rule, and falling back to the words. Remembered in
    ' m.msLogo as well as applied, because the metadata answer can take it down
    ' again. See tlPinLogoUrl in RatingBadges.brs.
    m.msLogo = ToStr(GetField(row, "logo"))
    ' PINNED, not merely applied - see the same line on the film page. The
    ' metadata answer must not race this Poster for the member's own lettering.
    if m.msLogo <> "" then tlPinLogoUrl(m.msLogo)

    ' ---- The ratings strip --------------------------------------------------
    ' The same two calls the Xtream branch makes, off MsInfoMap instead of the
    ' panel's info map. rbApplyProviderBadges costs nothing at all — the
    ' certificate and the server's own score are already in hand — and
    ' rbStartLookup is ONE request for the SHOW, per page open, cached for a
    ' week and refused outright on a box short of memory. NEVER one per episode:
    ' this screen's whole design note is that no episode row asks anybody
    ' anything, and the strip obeys that too.
    '
    ' The certificate cannot end up on the strip twice: rbApplyProviderBadges
    ' sets m.hasCert when the server gave one, and onTitleMeta adds the
    ' service's only when it did not. That is the Xtream rule and this path
    ' obeys it rather than inventing a second one.
    info = MsInfoMap(row)
    ' THE TMDB ID, KEPT FOR THE SUBTITLE SEARCH. The relay takes an id or a
    ' name, and a name is genuinely ambiguous - one film's id once answered
    ' with ten Dexter episodes, which is why the relay insists on a type. The
    ' panel hands the id over in this very answer and nothing was keeping it,
    ' so every subtitle search was a name search. Media-server titles have no
    ' panel id (MsInfoMap deliberately sends none), so those still search by
    ' name, which is the honest fallback rather than a wrong id.
    m.subsTmdb = rbClean(GetField(info, "tmdb_id"))
    ' AND THE ONE THE SERVER ITSELF KNOWS. Jellyfin and Emby both carry the
    ' show's TMDB id in `ProviderIds`, and this screen now asks for that field
    ' (MsItemUrl). Read straight off the row rather than through MsInfoMap on
    ' purpose - the note above that function explains why the ratings strip
    ' must not be handed an id it cannot vouch for - but everything that keys
    ' on an id wants it: the subtitle search, and the scrobbles and checkmarks
    ' that reach a member's Trakt and Simkl. THE SHOW'S ID, not the episode's:
    ' both services number the two separately and take them as different
    ' parameters, which is the same trap the relay's own note records.
    if m.subsTmdb = "" then m.subsTmdb = MsTmdbId(row)
    m.subsYear = rbYearOf(info)
    rbApplyProviderBadges(info)
    rbStartLookup(info)
    msWatchMeta()
end sub

' The chip row, REBUILT WHOLE from whatever is currently known.
'
' Two answers fill this row and either can land first — the library row brings
' the year and the genre, the episode list brings the counts — so the row is
' rebuilt from the held facts rather than appended to. Appending is how a show
' whose details arrived second ended up with its source chip printed twice.
sub msSeriesChips()
    m.chipDefs = []
    if m.msYear > 0 then m.chipDefs.push({ text: m.msYear.toStr(), icon: "", dot: "" })
    if ToStr(m.msGenre) <> "" then m.chipDefs.push({ text: ToStr(m.msGenre), icon: "", dot: "" })
    if m.seasons <> invalid and m.seasons.count() > 0
        seasonWord = " seasons"
        if m.seasons.count() = 1 then seasonWord = " season"
        epWord = " episodes"
        if m.epCount = 1 then epWord = " episode"
        m.chipDefs.push({ text: m.seasons.count().toStr() + seasonWord + "  -  " + m.epCount.toStr() + epWord, icon: "", dot: "" })
    end if
    ' The source, as one more short fact with its own colour as a DOT — the
    ' same dot every poster tag draws, and never a fill. Only when the caller
    ' actually named the source.
    it = m.top.item
    srcName = msSourceChipName(it)
        if srcName <> "" then m.chipDefs.push({ text: srcName, icon: "", dot: hcSrcDotColor() })
    hcDrawChips(m.chipsGrp, m.chipDefs)
end sub

' ---- The one fetch, for a show that came through a bare door -----------------
'
' Continue Watching, Search and favourites store an id and a name and were
' never going to store a synopsis, a backdrop or a certificate. ONE request, on
' page open, for ONE show. It does not touch the spinner: msLoadSeries has
' already started one for the episode list, which is the answer the member is
' actually waiting on, and onMsEpisodes is what stops it.
' Which source a show is on, for its chip - the caller's label when it sent
' one, else the provider's own name (m.provider is resolved from the item's
' src in onItem). Movies & Series never sent a label, so every show opened
' from the grid lost its chip.
function msSourceChipName(it as dynamic) as string
    if type(it) = "roAssociativeArray" and it.doesExist("srcLabel")
        nm = ToStr(it.srcLabel)
        if nm <> "" then return nm
    end if
    if m.provider <> invalid then return ToStr(m.provider.name)
    return ""
end function

sub msFetchSeries(itemId as string)
    if itemId = "" then return
    ' No token means a 401. Draw nothing rather than spend a request being told
    ' so — msLoadSeries says that to the member for the episode list already.
    if MsNeedsSignIn(m.provider) then return
    m.msItemId = itemId
    t = CreateObject("roSGNode", "MediaServerTask")
    t.url = MsItemUrl(m.provider, itemId)
    t.method = "GET"
    ' The identity header. This is the ONLY place the access token appears —
    ' never in the address, because an address is printed in the diagnostic log
    ' and written into watch history.
    t.headers = MsHeaders(m.provider)
    t.timeoutMs = 25000
    t.observeField("result", "onMsItem")
    ' Its own field rather than m.task, which the episode request is holding.
    ' A task nothing holds a reference to can be collected mid-flight.
    m.msItemTask = t
    t.control = "RUN"
end sub

sub onMsItem(event as object)
    try
        onMsItemInner(event)
    catch e
        GuardFailed("series/onMsItem", e)
        ' LOGGED AND NOTHING ELSE. This answer only fills in the hero - the
        ' plot, the chips, the artwork. It owns no spinner (onMsEpisodes below
        ' is what takes that down) and holds no focus, so a fault costs the
        ' member some of the show's description on a page that still lists its
        ' seasons and still plays. There is nothing to put back.
    end try
end sub

sub onMsItemInner(event as object)
    res = event.getData()
    it = m.top.item
    if it = invalid then return
    ' A late answer for the PREVIOUS show. Dropped, not drawn.
    if ToStr(it.seriesId) <> ToStr(m.msItemId) then return
    if res = invalid or res.ok <> true
        why = "the server did not answer"
        if res <> invalid and ToStr(res.error) <> "" then why = ToStr(res.error)
        KLog("series", "media server: no details for this show - " + why)
        return
    end if
    ' /Items answers with a LIST even when exactly one id was asked for.
    first = invalid
    for each e in ToArray(GetField(res.data, "Items"))
        first = e
        exit for
    end for
    if first = invalid then return
    row = MsMapItem(m.provider, first, "series")
    if row = invalid then return
    msDrawSeries(row)
end sub

' ---- The other half of the metadata answer -----------------------------------
'
' rbStartLookup above fires the SAME single cached lookup every Xtream title
' makes, and RatingBadges.brs draws the badges off it in onTitleMeta. Two
' things in that answer belong to this page rather than to the strip, and this
' is where they are picked up. It is a SECOND OBSERVER ON THE SAME TASK, not a
' second request: nothing extra is asked of anybody, and the shared file is
' untouched.
'
'   · `bd`, the TMDB backdrop — step two of the hero order above, used only
'     when the member's own server had none. Written to the NODE only, never
'     to m.backdrop, because m.backdrop is the copy that gets stored on the
'     Continue Watching row and mirrored to their other devices.
'   · the lettering, PUT BACK. onTitleMeta finishes by calling tlApplyLogo with
'     whatever the service sent, and on a title the service has no logo for
'     that call takes the member's OWN server's lettering back down and leaves
'     the words. The server's is the picture the member chose, so it wins.
sub msWatchMeta()
    ' m.rbTag is non-empty ONLY when rbStartLookup has just created a task — it
    ' refuses on a box short of memory and on a title with no name, and rbReset
    ' empties it on every new show. So this is the exact test for "there is a
    ' task of mine to listen to", and it can never attach to the last show's.
    if ToStr(m.rbTag) = "" then return
    if m.metaTask = invalid then return
    m.metaTask.observeField("result", "onMsMeta")
end sub

sub onMsMeta(event as object)
    try
        onMsMetaInner(event)
    catch e
        GuardFailed("series/onMsMeta", e)
        ' LOGGED AND NOTHING ELSE, same as onMsItem above: artwork and the
        ' ratings strip only. No spinner, no focus, nothing to restore.
    end try
end sub

sub onMsMetaInner(event as object)
    res = event.getData()
    if res = invalid or res.ok <> true then return
    if m.top.item = invalid then return
    ' The same two guards onTitleMeta uses, for the same reason: an answer that
    ' outlived its page has to land on the floor rather than on the show the
    ' member is looking at now.
    if ToStr(m.rbTag) = "" then return
    node = event.getRoSGNode()
    if node <> invalid and ToStr(node.tag) <> ToStr(m.rbTag) then return

    ' Step two of the hero order, and only when step one found nothing.
    if ToStr(m.backdrop) = ""
        ' BackdropUrl(), because THIS one really is TMDB's short form — a
        ' leading slash and a file name, exactly as the Xtream hero's is, and
        ' handing that to a Poster raw draws no hero at all. w1280 for the same
        ' reason as everywhere else: it draws 1920 wide and w500 would be a
        ' 3.8x upscale.
        bd = ToStr(GetField(res.data, "bd")).trim()
        if bd <> "" then m.backdropArt.uri = BackdropUrl(bd, "w1280")
    end if

end sub

' WHY A TIMER AND NOT JUST A LINE IN onMsMeta. Both callbacks hang on the one
' `result` field, and Roku does not promise which of two observers on a field
' runs first. If ours ran first, RatingBadges.brs would then take the server's
' lettering down again and the whole re-assert would be pointless. A tick puts
' this on the frame AFTER whatever the shared file did, whichever order they
' fired in, so the outcome is the same either way. 0.1 seconds is invisible,
' and nothing here is a keypress, so certification 3.5's 250 ms is not in play.

sub onMsEpisodes(event as object)
    try
        onMsEpisodesInner(event)
    catch e
        GuardFailed("series/onMsEpisodes", e)
        ' SPINNER DOWN. This is the handler that builds the season and episode
        ' lists, so it is the likeliest on the page to fault part-way through.
        ' The member keeps whatever it managed to build; if that is nothing,
        ' they get an empty show page they can back out of rather than one
        ' that spins at them indefinitely.
        if m.spinner <> invalid
            m.spinner.visible = false
            m.spinner.control = "stop"
        end if
    end try
end sub

sub onMsEpisodesInner(event as object)
    res = event.getData()
    m.spinner.visible = false
    m.spinner.control = "stop"
    it = m.top.item
    if it = invalid then return
    ' A late answer for the PREVIOUS show. Dropped, not drawn.
    if ToStr(GetField(it, "seriesId")) <> m.msSeriesId then return
    if res = invalid then return
    if res.ok <> true
        why = ToStr(res.error)
        if why = "" then why = "Your server didn't answer with this show's episodes."
        msSeriesUnavailable(why)
        return
    end if

    ' Group by season, because the answer is one flat list in the server's own
    ' order. ParentIndexNumber is the season and IndexNumber is the episode; a
    ' special sorts as season 0, which is what both servers mean by it.
    bySeason = {}
    nameCore = epSeriesNameCore(ToStr(GetField(it, "name")))
    for each e in ToArray(GetField(res.data, "Items"))
        id = ToStr(GetField(e, "Id"))
        if id = "" then continue for
        sn = ToInt(GetField(e, "ParentIndexNumber"))
        en = ToInt(GetField(e, "IndexNumber"))
        title = ToStr(GetField(e, "Name")).trim()
        if title = ""
            title = "Episode " + en.toStr()
        else
            ' The same trim the panel path uses. These servers usually send a
            ' clean episode name, so this almost always returns the title
            ' untouched — it earns its place on the server whose library was
            ' imported straight from filenames.
            title = epCleanTitle(title, nameCore, sn, en)
        end if
        ' The demuxer, worked out ONCE here from the container the server
        ' reported. The stream address carries no file extension, so nothing
        ' downstream could work it out from the address — see MsStreamFormat.
        key = sn.toStr()
        if not bySeason.doesExist(key) then bySeason[key] = []
        bySeason[key].push({
            id: id
            title: title
            epNum: en
            ext: MsStreamFormat(ToStr(GetField(e, "Container")))
        })
    end for

    nums = []
    for each k in bySeason
        nums.push(ToInt(k))
    end for
    nums.sort()
    m.seasons = []
    for each n in nums
        eps = bySeason[n.toStr()]
        if eps.count() > 0 then m.seasons.push({ num: n, episodes: eps })
    end for

    ' Exactly the order the panel path uses, and for the same reasons: the
    ' scan writes the watched state onto the episode maps, the lists read it,
    ' and the buttons read what the scan worked out.
    scanWatchState()
    fillSeasonList()
    redrawButtons()
    focusSeedEpisode()

    ' The whole chip row again, now that the counts exist. REBUILT rather than
    ' appended to, because the library row's year and genre may not have landed
    ' yet — see msSeriesChips, which is the one place the row is assembled.
    msSeriesChips()
    KLog("series", "media server: " + m.seasons.count().toStr() + " season(s), " + m.epCount.toStr() + " episode(s)")
end sub

' No episodes, and a sentence saying why. The lists are emptied rather than
' left holding the previous show's — fillSeasonList draws nothing on an empty
' season list, which is the same state a failed panel request leaves behind.
sub msSeriesUnavailable(why as string)
    m.seasons = []
    m.resumeTarget = invalid
    m.epCount = 0
    fillSeasonList()
    redrawButtons()
    KLog("series", "media server: " + why)
    msCannotPlayNote(why)
end sub

' "Can't play this right now", in the shape this page already uses for the
' adult-category refusal at the bottom of this file — one Dialog, one OK
' button, focus handed back. Its own handler rather than the parental one's,
' because that one also clears m.pendingPlay and this refusal never sets it.
sub msCannotPlayNote(msg as string)
    note = CreateObject("roSGNode", "Dialog")
    note.title = "Can't Play This Right Now"
    note.message = msg
    note.buttons = ["OK"]
    note.observeField("buttonSelected", "onMsNoteClosed")
    m.top.getScene().dialog = note
end sub

sub onMsNoteClosed()
    try
        m.top.getScene().dialog.close = true
        m.top.setFocus(true)
    catch e
        GuardFailed("series/onMsNoteClosed", e)
        ' FOCUS MUST END UP SOMEWHERE REAL. Dismissing the note is two
        ' statements - close it, then take the remote back - and a fault in
        ' the first leaves the member with no focus on the page and a remote
        ' that does nothing. The dialog is not closed again from here: see the
        ' note on getScene() in the block above.
        restoreFocusAfterDialog()
    end try
end sub

sub onInfo(event as object)
    try
        onInfoInner(event)
    catch e
        GuardFailed("series/onInfo", e)
        ' SPINNER DOWN, same as onItem and onMsEpisodes.
        if m.spinner <> invalid
            m.spinner.visible = false
            m.spinner.control = "stop"
        end if
    end try
end sub

sub onInfoInner(event as object)
    res = event.getData()
    m.spinner.visible = false
    m.spinner.control = "stop"
    if res = invalid or res.ok <> true then return

    info = GetField(res.data, "info")
    if info <> invalid then m.plot.text = ToStr(GetField(info, "plot"))
    ' The same words into the reading panel, and the show's own name as its
    ' heading. dpSetText takes m.dpOn false on an empty synopsis; redrawButtons
    ' below is what draws the consequence on the block.
    heading = ""
    if m.top.item <> invalid then heading = ToStr(m.top.item.name)
    dpSetText(heading, m.plot.text)
    dpPaintBlock(m.descFocus)

    ' ---- The metadata chips, Android's row ---------------------------------
    ' series_detail_screen.dart:560-580 builds the year range, the
    ' certification, and a "N seasons - M episodes" chip, plus the source with
    ' its colour dot. The CERTIFICATE IS NOT REPEATED here: it is the first chip
    ' in the ratings strip below (rbCertOf), and the same words twice on one
    ' page at ten feet reads as a bug - the film page leaves its rating out of
    ' this row for exactly that reason.
    '
    ' The seasons/episodes chip is filled in further down, once the episode
    ' maps have actually been built - the counts do not exist yet at this point
    ' in the sub.
    m.chipDefs = []
    if info <> invalid
        year = ""
        for each k in ["releaseDate", "releasedate", "release_date"]
            v = ToStr(GetField(info, k))
            if Len(v) >= 4
                year = Left(v, 4)
                exit for
            end if
        end for
        if year <> "" then m.chipDefs.push({ text: year, icon: "", dot: "" })
        genre = ToStr(GetField(info, "genre"))
        if genre <> "" then m.chipDefs.push({ text: genre, icon: "", dot: "" })
    end if
    ' ---- The Media Bar's backdrop ------------------------------------------
    ' NO NEW REQUEST. `backdrop_path` is already in this answer, beside the
    ' plot above, and the phone has read it since day one
    ' (xtream_models.dart:352). This app never did, so the Media Bar has been
    ' faking a landscape picture out of a portrait poster.
    '
    ' Stamped onto the show's recents row immediately IF it has one — which is
    ' what happens when the member presses More info on the Media Bar itself,
    ' so the panel's own button is what teaches it the picture. It creates no
    ' row, reorders nothing, and writes nothing at all when the row already
    ' knew. It is also held for playEpisode below, so a show started from this
    ' page is born with one.
    m.backdrop = ""
    if info <> invalid then m.backdrop = BackdropFromInfo(info)
    '     >>> AND, SINCE THIS PAGE BECAME ANDROID'S HERO, DRAWN AS THE HERO
    '     ITSELF. Until it arrives the hero wears the show's poster, which is
    '     Android's own fallback and looks equally soft there. Written only
    '     when there IS one: assigning "" would blank the poster standing in
    '     for it and leave the top of the page empty.
    '
    '     BackdropUrl(), NOT the raw stored value. BackdropFromInfo returns
    '     TMDB's SHORT STORED FORM - a leading slash and a file name, no host
    '     and no size - because that is the shape the registry holds. Handing
    '     that to a Poster asks the box to load a path that is not a url, which
    '     is what drew no hero at all on the film page on 2026-08-26:
    '
    '         *** ERROR: Missing or invalid PHY: '/jjfLMwJa...Y.jpg'
    '
    '     w1280, not the w500 default, because this draws 1920 wide. w500 would
    '     be a 3.8x upscale - soft enough to look broken from a sofa. The extra
    '     bytes are affordable because this is fetched once per page open, not
    '     on every rotation the way the Media Bar's is.
    '
    '     THE DECODE CAP DOES NOT MOVE. loadWidth/loadHeight are pinned at
    '     1920 x 552 in the XML, so texture stays 1920 x 552 x 4 = 4,239,360
    '     bytes whatever size comes off the wire. The size above is a download
    '     and sharpness decision, not a memory one.
    if m.backdrop <> "" then m.backdropArt.uri = BackdropUrl(m.backdrop, "w1280")
    it = m.top.item
    if it <> invalid and m.backdrop <> ""
        AttachRecentBackdrop("series", ToStr(it.seriesId), m.itemSrc, m.backdrop)
    end if
    ' The show's category rides on this same answer — see the parental block.
    resolveCatFromInfo(res)

    ' episodes: { "1": [ {id, title, episode_num, container_extension}, ... ] }
    epsBySeason = GetField(res.data, "episodes")
    m.seasons = []
    ' The show's own name, once, for the title trim below (epCleanTitle).
    nameCore = ""
    if it <> invalid then nameCore = epSeriesNameCore(ToStr(it.name))
    trimmed = 0
    totalEps = 0
    if epsBySeason <> invalid and type(epsBySeason) = "roAssociativeArray"
        ' Collect season numbers, sort numerically.
        nums = []
        for each k in epsBySeason
            nums.push(ToInt(k))
        end for
        nums.sort()
        for each n in nums
            eps = []
            for each e in ToArray(epsBySeason[n.toStr()])
                epNum = ToInt(GetField(e, "episode_num"))
                epTitle = ToStr(GetField(e, "title"))
                if epTitle = ""
                    epTitle = "Episode " + ToStr(GetField(e, "episode_num"))
                else
                    ' HERE and nowhere else: the show name and this row's own
                    ' S/E code come off the title once, while the list is
                    ' being built. EpisodeRow is recycled down the list and
                    ' would redo it on every scroll.
                    totalEps = totalEps + 1
                    clean = epCleanTitle(epTitle, nameCore, n, epNum)
                    if clean <> epTitle then trimmed = trimmed + 1
                    epTitle = clean
                end if
                eps.push({
                    id: ToStr(GetField(e, "id"))
                    title: epTitle
                    epNum: epNum
                    ext: ToStr(GetField(e, "container_extension"))
                })
            end for
            if eps.count() > 0 then m.seasons.push({ num: n, episodes: eps })
        end for
    end if
    if trimmed > 0 then KLog("series", "episode titles: trimmed " + trimmed.toStr() + " of " + totalEps.toStr() + " (show name and/or S/E code)")
    ' BEFORE the lists are filled: fillEpisodeList reads the state straight
    ' off the episode maps this puts it on, and redrawButtons reads the
    ' resume target it works out.
    scanWatchState()
    fillSeasonList()
    redrawButtons()
    focusSeedEpisode()

    ' ---- The rest of the chip row, now the counts exist ---------------------
    ' Android's "3 seasons - 42 episodes" chip, and the source with its colour
    ' dot - the same dot the VOD chip row and every poster tag draw, never a
    ' fill. Both are drawn from what is already in hand; neither costs a
    ' request. Written here rather than up with the year because m.seasons and
    ' m.epCount do not exist until the loop above has run.
    if m.seasons.count() > 0
        seasonWord = " seasons"
        if m.seasons.count() = 1 then seasonWord = " season"
        epWord = " episodes"
        if m.epCount = 1 then epWord = " episode"
        m.chipDefs.push({ text: m.seasons.count().toStr() + seasonWord + "  -  " + m.epCount.toStr() + epWord, icon: "", dot: "" })
    end if
    srcName = msSourceChipName(it)
        if srcName <> "" then m.chipDefs.push({ text: srcName, icon: "", dot: hcSrcDotColor() })
    hcDrawChips(m.chipsGrp, m.chipDefs)

    ' ---- The ratings strip (GAP I1) -----------------------------------------
    ' LAST on purpose. Everything above is what the member came for — the
    ' seasons, the episodes, which one Play means — and cert 3.5 gives the
    ' remote 250 ms. Badges are decoration arriving behind a page that has
    ' already drawn.
    '
    ' rbApplyProviderBadges costs nothing at all: the certificate and the
    ' panel's own score are already in the answer this sub is reading. Only
    ' rbStartLookup goes out, and it is ONE request for the SHOW, per page open,
    ' cached for a week and refused outright on a box short of memory. NEVER one
    ' per episode — this screen's whole design note is that no episode row ever
    ' asks anybody anything, and that rule is what the strip obeys too.
    if info <> invalid
        ' THE TMDB ID, KEPT FOR THE SUBTITLE SEARCH. The relay takes an id or a
        ' name, and a name is genuinely ambiguous - one film's id once answered
        ' with ten Dexter episodes, which is why the relay insists on a type. The
        ' panel hands the id over in this very answer and nothing was keeping it,
        ' so every subtitle search was a name search. Media-server titles have no
        ' panel id (MsInfoMap deliberately sends none), so those still search by
        ' name, which is the honest fallback rather than a wrong id.
        m.subsTmdb = rbClean(GetField(info, "tmdb_id"))
        m.subsYear = rbYearOf(info)
        rbApplyProviderBadges(info)
        rbStartLookup(info)
    end if
end sub

' ---- Episode titles: taking back off them what this page already says -------
'
' Providers hand the whole filename back as the episode title:
'
'     Demon Slayer: Kimetsu no Yaiba (2019) - S04E06 - Aren't You Going to
'     Become a Hashira?
'
' The row already draws "E6" in front of it and the page above it already
' draws the show's name, so two thirds of that line is the member being told
' twice what they can see, and the third that matters is off the right-hand
' edge.
'
' THE RULE, AND WHY IT IS THIS NARROW. This removes ONLY material this screen
' already knows to be true:
'
'   * the show's name - m.top.item.name, the very string drawn as the page
'     title, not a guess at where a name might end
'   * a season/episode code whose numbers ARE THIS ROW'S - the same two
'     numbers the list was built from, so a code that disagrees with the row
'     it is sitting on is somebody else's convention and is left alone
'   * the separator punctuation left stranded between or around those two
'
' and only where that material sits at one END of the title. It never invents
' a pattern for "what a provider's titles look like", because every such guess
' is somebody's library mangled: anything it cannot positively account for
' comes through character for character. A title that is already clean is
' returned untouched, and if the trimming would leave NOTHING, the original is
' kept - a provider that sends "S04E06" as the whole title must still show
' something.
'
' Costs one pass over each title, once, when the show's answer lands. Nothing
' here runs per scroll.

' The show's name with a trailing "(2019)"/"[2019]" taken off. Some providers
' hang the year on the show and not on the episodes, some the other way round,
' so neither side carries it into the comparison; the year on the EPISODE side
' is dealt with separately, in epCleanTitle.
function epSeriesNameCore(name as string) as string
    s = name.trim()
    n = s.len()
    if n < 7 then return s
    if epYearLen(s, n - 6) = 6 then return s.left(n - 6).trim()
    return s
end function

' ASCII letters and digits, and nothing else. Every byte of an accented or
' non-Latin character sorts outside those ranges, so it counts as "not a word
' character" - which is exactly what makes the name comparison below survive
' punctuation without ever having to know what the punctuation was.
function epIsWordChar(c as string) as boolean
    if c = "" then return false
    if c >= "a" and c <= "z" then return true
    if c >= "A" and c <= "Z" then return true
    return (c >= "0" and c <= "9")
end function

' How far to step over a separator at i, or 0 when what is there is not one.
'
' Deliberately NOT "any punctuation". A title may legitimately open with dots
' ("...And Then There Were None") or close with "?" or "." or "!", and those
' have to survive, so only the characters providers actually glue fields
' together with are listed here.
'
' The three-character test is the en/em dash. Depending on how the firmware
' counts a multi-byte character, Mid hands it back as one character or as its
' three UTF-8 bytes; checking both ways is correct under either.
function epSepLen(s as string, i as integer) as integer
    c = s.mid(i, 1)
    if c = "" then return 0
    if c = " " or c = Chr(9) or c = "-" or c = ":" or c = "|" or c = "," or c = ";" or c = "/" or c = "_" or c = "~" then return 1
    if c = "–" or c = "—" then return 1
    t = s.mid(i, 3)
    if t = "–" or t = "—" then return 3
    return 0
end function

' A separator strong enough to mean "this was a FIELD boundary". A space or a
' comma is not: "Demon Slayer Returns" and "Demon Slayer, the Movie" are
' episode titles that merely begin with the show's name, and they keep it.
function epIsStrongSep(s as string, i as integer) as boolean
    c = s.mid(i, 1)
    if c = "-" or c = ":" or c = "|" or c = "/" or c = "_" or c = "~" then return true
    if c = "–" or c = "—" then return true
    t = s.mid(i, 3)
    return (t = "–" or t = "—")
end function

function epHasStrongSep(s as string, fromIdx as integer, toIdx as integer) as boolean
    i = fromIdx
    while i < toIdx
        if epIsStrongSep(s, i) then return true
        i = i + 1
    end while
    return false
end function

' The end of a run of separators starting at i.
function epSkipSeps(s as string, i as integer) as integer
    p = i
    adv = epSepLen(s, p)
    while adv > 0
        p = p + adv
        adv = epSepLen(s, p)
    end while
    return p
end function

' How many dots in a row sit at i.
'
' A dot is NOT a separator in epSepLen and must not become one: a title may
' open with "...And Then There Were None" or close with "The End." and both
' have to survive. But the provider that writes "Demon.Slayer.S04E06.Real
' Title" is using it as one, so a dot is allowed to go ONLY where it is
' directly against material this screen positively identified, with no space
' in between - which is what separates that provider's dots from the ones in
' "Demon Slayer - ...And Then There Were None", where the dots sit behind a
' space and belong to the episode.
function epDotRunLen(s as string, i as integer) as integer
    n = 0
    while s.mid(i + n, 1) = "."
        n = n + 1
    end while
    return n
end function

' epSkipSeps with dots counting too. Used to LOOK AHEAD - to see whether what
' follows the show's name is this row's code - and BETWEEN the two halves of a
' code, where both numbers still have to match. Never used to decide what to
' throw away on its own.
function epSkipJoin(s as string, i as integer) as integer
    p = i
    adv = epSepLen(s, p)
    if adv = 0 and s.mid(p, 1) = "." then adv = 1
    while adv > 0
        p = p + adv
        adv = epSepLen(s, p)
        if adv = 0 and s.mid(p, 1) = "." then adv = 1
    end while
    return p
end function

function epFrom(s as string, i as integer) as string
    if i <= 0 then return s
    if i >= s.len() then return ""
    return s.mid(i, s.len() - i)
end function

function epTrimStart(s as string) as string
    return epFrom(s, epSkipSeps(s, 0))
end function

' Everything before i was positively identified, so it goes - and so does a
' run of dots sitting directly against the cut, per epDotRunLen.
function epCutFront(s as string, i as integer) as string
    r = epFrom(s, i)
    d = epDotRunLen(r, 0)
    if d > 0 then r = epFrom(r, d)
    return epTrimStart(r)
end function

' The same cut, made from the other end: everything from i on was identified.
function epCutBack(s as string, i as integer) as string
    j = i
    ' Two lines rather than one condition: "and" does not short-circuit here,
    ' so a single "while j > 0 and s.mid(j - 1, 1)" would still read position
    ' -1 on the last turn.
    while j > 0
        if s.mid(j - 1, 1) <> "." then exit while
        j = j - 1
    end while
    return epTrimEnd(s.left(j))
end function

' Trailing separators only - see epSepLen for why "?" and "." are not among
' them. Walks forwards, remembering where the last thing worth keeping ended,
' because walking backwards over a multi-byte character is not safe.
function epTrimEnd(s as string) as string
    n = s.len()
    if n = 0 then return s
    ' Cheap out first. Nearly every title ends in a letter, a digit or a "?",
    ' and walking the whole string to find that out is not free when it runs
    ' once per episode of a show with three hundred of them. Two tests,
    ' because in byte mode a trailing en dash's LAST byte is not the one that
    ' identifies it.
    tail = epSepLen(s, n - 1)
    if tail = 0 and n >= 3
        if epSepLen(s, n - 3) = 3 then tail = 3
    end if
    if tail = 0 then return s

    keep = 0
    i = 0
    while i < n
        adv = epSepLen(s, i)
        if adv > 0
            i = i + adv
        else
            i = i + 1
            keep = i
        end if
    end while
    if keep >= n then return s
    return s.left(keep)
end function

' The run of digits at i, as { v: value, n: how many }. n = 0 for none, and a
' run longer than four digits is refused outright so that a year or a stream
' id can never be read as a season or an episode number.
function epDigitsAt(s as string, i as integer) as object
    n = 0
    v = 0
    c = s.mid(i, 1)
    while c <> "" and c >= "0" and c <= "9"
        v = v * 10 + (Asc(c) - 48)
        n = n + 1
        c = s.mid(i + n, 1)
    end while
    if n = 0 or n > 4 then return { v: -1, n: 0 }
    return { v: v, n: n }
end function

' "(2019)" or "[2019]" at i, or 0. Only ever called where a bracketed year can
' only be part of the show's naming - directly behind the show's name that was
' just removed. A bracketed year anywhere else is somebody's episode title.
function epYearLen(s as string, i as integer) as integer
    ob = s.mid(i, 1)
    if ob <> "(" and ob <> "[" then return 0
    d = epDigitsAt(s, i + 1)
    if d.n <> 4 then return 0
    if d.v < 1900 or d.v > 2200 then return 0
    cb = s.mid(i + 5, 1)
    if ob = "(" and cb <> ")" then return 0
    if ob = "[" and cb <> "]" then return 0
    return 6
end function

' A bare four-figure year at i - "2019", no brackets. NOT the same claim as
' epYearLen: four digits on their own could perfectly well BE an episode's
' title, so epCleanTitle only ever accepts one that is wedged between the
' show's name and this row's own code, where it cannot be.
function epBareYearLen(s as string, i as integer) as integer
    d = epDigitsAt(s, i)
    if d.n <> 4 then return 0
    if d.v < 1900 or d.v > 2200 then return 0
    if epIsWordChar(s.mid(i + 4, 1)) then return 0
    return 4
end function

' Does a season/episode code start at i, and is it THIS row's? The forms
' accepted are the ones built out of the two numbers the screen already
' parsed, in whatever shape the punctuation arrives:
'
'   S04E06   s4e6   S04 E06   S04.E06   Season 4 Episode 6   E06   Ep 6   4x06
'
' Every one of them has to carry numbers equal to this row's season and
' episode, and has to end on a non-word character, so "S04E061" and a code for
' some other episode both come back 0. Returns how far the code reaches, or 0.
function epCodeLen(s as string, i as integer, seasonNum as integer, epNum as integer) as integer
    ' "4x06": season, an x, episode. Tested first because it opens with a
    ' digit and nothing else here does.
    d = epDigitsAt(s, i)
    if d.n > 0
        if d.v <> seasonNum then return 0
        q = i + d.n
        if LCase(s.mid(q, 1)) <> "x" then return 0
        d2 = epDigitsAt(s, q + 1)
        if d2.n = 0 or d2.v <> epNum then return 0
        q = q + 1 + d2.n
        if epIsWordChar(s.mid(q, 1)) then return 0
        return q - i
    end if

    ' An optional season part: "Season 4", "S04", "S4".
    p = i
    sawSeason = false
    q = -1
    if LCase(s.mid(p, 6)) = "season"
        q = p + 6
    else if LCase(s.mid(p, 1)) = "s"
        q = p + 1
    end if
    if q >= 0
        q = epSkipJoin(s, q)
        d = epDigitsAt(s, q)
        if d.n > 0 and d.v = seasonNum
            p = q + d.n
            sawSeason = true
        end if
    end if

    ' The episode part: "Episode 6", "Ep 6", "E06". Longest word first, or
    ' "Episode" is read as "Ep" and the rest never matches.
    p2 = p
    if sawSeason then p2 = epSkipJoin(s, p)
    q = -1
    if LCase(s.mid(p2, 7)) = "episode"
        q = p2 + 7
    else if LCase(s.mid(p2, 2)) = "ep"
        q = p2 + 2
    else if LCase(s.mid(p2, 1)) = "e"
        q = p2 + 1
    end if
    if q >= 0
        q = epSkipJoin(s, q)
        d = epDigitsAt(s, q)
        if d.n > 0 and d.v = epNum
            q = q + d.n
            if epIsWordChar(s.mid(q, 1)) then return 0
            return q - i
        end if
    end if

    ' A season on its own still counts when it is this row's season, and stops
    ' at the season number - the separators after it are the trim's business,
    ' not this function's.
    if sawSeason
        if epIsWordChar(s.mid(p, 1)) then return 0
        return p - i
    end if
    return 0
end function

' A code at the very END of the title ("Aren't You... - S04E06"). Matching
' backwards is the same matcher run FORWARDS from each of the last few
' separator boundaries: it is a tail code only when it starts just after a
' separator and reaches exactly the end of the string.
function epTrimTailCode(s as string, seasonNum as integer, epNum as integer) as string
    n = s.len()
    if n < 2 then return s
    ' Cheap out: every shape epCodeLen accepts ends in a digit, so a title
    ' that does not cannot be carrying one at the end. Spares the scan below
    ' on almost every title there is.
    lastCh = s.mid(n - 1, 1)
    if lastCh < "0" or lastCh > "9" then return s
    first = n - 24
    if first < 1 then first = 1
    for i = first to n - 1
        if epSepLen(s, i - 1) > 0 or s.mid(i - 1, 1) = "."
            c = epCodeLen(s, i, seasonNum, epNum)
            if c > 0 and i + c = n then return epCutBack(s, i)
        end if
    end for
    return s
end function

' Where the show's own name stops, if the title opens with it, or 0.
'
' Walks both strings a word character at a time and skips everything that is
' not one on either side, which is what lets "Demon Slayer: Kimetsu no Yaiba"
' match "demon slayer - kimetsu no yaiba" and whatever else a provider does to
' the punctuation in between. The match must also stop ON a word boundary, so
' the show "Demon Slayer" does not eat the front of "Demon Slayers".
function epNamePrefixLen(t as string, nameCore as string) as integer
    n = nameCore.len()
    tn = t.len()
    if n < 2 or tn = 0 then return 0
    ti = 0
    ni = 0
    matched = 0
    while ni < n
        cn = nameCore.mid(ni, 1)
        if not epIsWordChar(cn)
            ni = ni + 1
        else
            ' Split the same way epCutBack is, and for the same reason.
            while ti < tn
                if epIsWordChar(t.mid(ti, 1)) then exit while
                ti = ti + 1
            end while
            if ti >= tn then return 0
            if LCase(t.mid(ti, 1)) <> LCase(cn) then return 0
            ti = ti + 1
            ni = ni + 1
            matched = matched + 1
        end if
    end while
    if matched < 2 then return 0
    ' Stopped mid-word - "Demon Slayer" against "Demon Slayers".
    if epIsWordChar(t.mid(ti, 1)) then return 0
    return ti
end function

' The whole rule, applied to one title. See the block comment above.
function epCleanTitle(raw as string, nameCore as string, seasonNum as integer, epNum as integer) as string
    t = raw.trim()
    if t = "" then return raw

    ' Three passes at most: "Show - S04E06 - Show - Title" is not a shape
    ' anybody sends, but a loop that cannot run away is cheaper than being
    ' sure of that.
    for pass = 1 to 3
        was = t

        ' ---- the front --------------------------------------------------
        t = epTrimStart(t)
        if nameCore <> ""
            cut = epNamePrefixLen(t, nameCore)
            if cut > 0
                after = epSkipJoin(t, cut)
                ' The name only comes off when what FOLLOWS it says it was a
                ' field and not the first two words of a sentence.
                ok = epHasStrongSep(t, cut, after)
                if epYearLen(t, after) > 0 then ok = true
                if epCodeLen(t, after, seasonNum, epNum) > 0 then ok = true
                ' ...or this row's code one step further along, behind a bare
                ' year: "Demon.Slayer.2019.S04E06.Real Title" has nothing at
                ' all between the name and the year to go on.
                b0 = epBareYearLen(t, after)
                if b0 > 0 and epCodeLen(t, epSkipJoin(t, after + b0), seasonNum, epNum) > 0 then ok = true
                if ok
                    t = epCutFront(t, cut)
                    ' A "(2019)" is only ever taken off directly behind the
                    ' show's name that just came off...
                    y = epYearLen(t, 0)
                    if y = 0
                        ' ...and a bare "2019" only when this row's own code
                        ' is behind it as well. Wedged between two things the
                        ' screen knows for certain, four digits cannot be the
                        ' episode's title; anywhere else they are left alone.
                        b = epBareYearLen(t, 0)
                        if b > 0 and epCodeLen(t, epSkipJoin(t, b), seasonNum, epNum) > 0 then y = b
                    end if
                    if y > 0 then t = epCutFront(t, y)
                end if
            end if
        end if
        c = epCodeLen(t, 0, seasonNum, epNum)
        if c > 0 then t = epCutFront(t, c)

        ' ---- the back ---------------------------------------------------
        t = epTrimEnd(t)
        t = epTrimTailCode(t, seasonNum, epNum)
        t = epTrimEnd(t)

        if t = was then exit for
    end for

    ' Trimmed away to nothing: the title was only ever the code, or only ever
    ' the show's name. Give the original back rather than an empty row.
    if t.trim() = "" then return raw
    return t
end function

' The Media Bar's "More info" arrives carrying WHICH episode its tile was
' about (item.episodeId, already src-stripped by Home). Honour it the way
' Android's detail deep-link does: land the season list on that episode's
' season and park the episode list on its row, so one press of OK plays
' exactly the episode the panel was showing. No id match (the show changed,
' the episode fell off the panel) degrades to the screen's normal start.
' Focus itself is not stolen - the button column keeps it, same as always.
'
' Since GAP D2 it seeds the PLAY BUTTON as well, not only the two lists. The
' Play button now names an episode of its own accord, and a button naming one
' episode above a list parked on another is two answers to the same question
' — the deep link is the more specific of the two, so it wins.
'
' ---- EXCEPT on an episode that is already FINISHED (GAP H12) ----------------
' Then the deep link is the LESS useful answer and the scan wins instead.
' seedResumeTarget has always refused to put "Play" on an episode somebody
' just finished, leaving the button pointing at whatever comes next — but the
' two lists still jumped to the finished one, so the button said S01E08 above
' a list sitting on S01E07. Same question, two answers, which is the exact
' thing the paragraph above exists to prevent.
'
' So a finished deep link lands everything on the scan's target: the episode
' after the last finished one, worked out from the marks store by
' scanWatchState. That is also what Home does with the tile that sends us here
' — it deliberately deep-links to nothing on a finished episode precisely so
' this rule, and only this rule, decides (HomeScreen.seedContinueEpisodes).
' The end of a show has no next; there the lists stay on the finished episode,
' because there is nothing better to point at.
sub focusSeedEpisode()
    it = m.top.item
    if type(it) <> "roAssociativeArray" or not it.doesExist("episodeId") then return
    epId = ToStr(it.episodeId)
    if epId = "" then return
    for si = 0 to m.seasons.count() - 1
        eps = m.seasons[si].episodes
        for ei = 0 to eps.count() - 1
            if ToStr(eps[ei].id) = epId
                landS = si
                landE = ei
                st = "none"
                if eps[ei].doesExist("st") then st = ToStr(eps[ei].st)
                if st = "done" and m.resumeTarget <> invalid and m.resumeTarget.s < m.seasons.count()
                    ' Follow the scan, and leave m.resumeTarget exactly as it
                    ' is — seedResumeTarget would only re-answer the question
                    ' the scan has already answered better.
                    landS = m.resumeTarget.s
                    landE = m.resumeTarget.e
                else
                    seedResumeTarget(si, ei)
                end if
                if landS <> m.seasonIdx
                    m.seasonIdx = landS
                    fillEpisodeList()
                end if
                redrawButtons()
                m.seasonList.jumpToItem = landS
                m.episodeList.jumpToItem = landE
                return
            end if
        end for
    end for
end sub

' Point the Play button at the deep-linked episode, with the right verb on
' it: "Resume ... - 22m left" if it is part-watched, plain "Play SxxEyy"
' otherwise.
'
' One LoadResume, once, and only on a deep link — the scan does not keep
' every position around, only the state and the percentage, and the button
' needs the actual seconds to say how long is left.
sub seedResumeTarget(si as integer, ei as integer)
    e = m.seasons[si].episodes[ei]
    st = "none"
    if e.doesExist("st") then st = ToStr(e.st)
    ' Already finished: leave the scan's answer alone. It is pointing at
    ' whatever comes NEXT, which is the more useful offer, and "Play" on an
    ' episode somebody has just finished is the one thing nobody wants.
    if st = "done" then return
    posS = 0
    durS = 0
    if st = "part"
        r = LoadResume(ResumeKeyEpisode(ToStr(e.id), m.itemSrc))
        if r <> invalid
            posS = r.positionS
            durS = r.durationS
        end if
    end if
    m.resumeTarget = { s: si, e: ei, posS: posS, durS: durS, resume: (st = "part") }
end sub

sub fillSeasonList()
    content = CreateObject("roSGNode", "ContentNode")
    for each s in m.seasons
        node = content.createChild("ContentNode")
        node.title = "Season " + s.num.toStr()
    end for
    m.seasonList.content = content
    if m.seasons.count() > 0
        m.seasonIdx = 0
        fillEpisodeList()
    end if
end sub

sub onSeasonFocused()
    try
        onSeasonFocusedInner()
    catch e
        GuardFailed("series/onSeasonFocused", e)
        ' LOGGED AND NOTHING ELSE, and there is a visible cost to be honest
        ' about: if fillEpisodeList() faults the highlight is sitting on the
        ' new season while the list below it still shows the PREVIOUS season's
        ' episodes. That is a wrong list rather than a missing one.
        '
        ' It is still the right call. m.seasonIdx has already moved, so the
        ' only ways to make the two agree again are to rebuild the list (the
        ' thing that just faulted) or to move the highlight back - and moving
        ' the highlight back fires this same observer, which is the recursion
        ' trap. Moving the season list under the member's thumb from an error
        ' path is also exactly the "focus must not move on its own" rule.
        ' Pressing up or down once rebuilds the list correctly.
    end try
end sub

sub onSeasonFocusedInner()
    idx = m.seasonList.itemFocused
    if idx >= 0 and idx < m.seasons.count() and idx <> m.seasonIdx
        m.seasonIdx = idx
        fillEpisodeList()
        redrawButtons() ' keep the Play label on the selected season
    end if
end sub

sub onSeasonSelected()
    try
        m.episodeList.setFocus(true)
    catch e
        GuardFailed("series/onSeasonSelected", e)
        ' One statement, so a fault means the episode list would not take
        ' focus. The remote stays on the season list, which is where it
        ' already was - nothing moves, and Right or OK can be pressed again.
    end try
end sub

sub fillEpisodeList()
    content = CreateObject("roSGNode", "ContentNode")
    for each e in m.seasons[m.seasonIdx].episodes
        node = content.createChild("ContentNode")
        node.title = "E" + e.epNum.toStr() + "  ·  " + e.title
        ' The watched marker rides IN on the node, already worked out — see
        ' the header of this file on why nothing is looked up per row.
        ' BOTH fields are added on EVERY row, in every state: EpisodeRow is
        ' recycled down the list, and a field left off one row leaves the
        ' previous episode's tick sitting on it.
        st = "none"
        if e.doesExist("st") then st = ToStr(e.st)
        pct = 0
        if e.doesExist("pct") then pct = ToInt(e.pct)
        node.addFields({ wstate: st, wpct: pct })
    end for
    m.episodeList.content = content
end sub

' ---- The watched scan (GAPs D1/D2) -------------------------------------------
'
' One pass over the whole show, from two registry walks, run once per page
' build and once more after playback. It writes three things onto each
' episode map in m.seasons — st ("none"/"part"/"done"), pct (0..100, or -1 for
' "started, length unknown") and flat (its index in show order) — and works
' out m.resumeTarget from them.
'
' THE RULES ARE ANDROID'S, in watch_state.dart:
'   a stored mark wins outright (isFinished, marked: true);
'   failing that, past 95% counts as finished — kept as a second answer for
'     the same reason Android keeps it: positions written before marks
'     existed carry no mark, and a tick that disagreed with the bar beside it
'     would be worse than no tick;
'   anything else with a position is part-watched;
'   nothing at all is untouched, and untouched draws nothing.
sub scanWatchState()
    m.resumeTarget = invalid
    m.epCount = 0
    it = m.top.item
    if it = invalid or m.seasons.count() = 0 then return
    m.seriesRef = "series:" + SrcQualifiedId(ToStr(it.seriesId), m.itemSrc)

    seen = LoadSeenSet(ActiveProfileId())
    resumes = loadResumeSet()

    lastDone = -1        ' flat index of the LAST finished episode
    partial = invalid    ' the first part-watched one, in show order
    flat = 0
    for si = 0 to m.seasons.count() - 1
        eps = m.seasons[si].episodes
        for ei = 0 to eps.count() - 1
            e = eps[ei]
            ' One key answers both stores: Store.brs builds SeenKeyEpisode
            ' and ResumeKeyEpisode from the same characters on purpose, and
            ' says so.
            key = SeenKeyEpisode(ToStr(e.id), m.itemSrc)
            posS = 0
            durS = 0
            if resumes.doesExist(key)
                r = resumes[key]
                posS = r.positionS
                durS = r.durationS
            end if
            st = "none"
            pct = 0
            if seen.doesExist(key)
                st = "done"
            else if durS > 0 and posS > Int(durS * 0.95)
                st = "done"
            else if posS > 0
                st = "part"
                if durS > 0
                    pct = Int(posS * 100 / durS)
                    if pct > 100 then pct = 100
                else
                    pct = -1
                end if
            end if
            e.st = st
            e.pct = pct
            e.flat = flat
            if st = "done"
                lastDone = flat
            else if st = "part" and partial = invalid
                partial = { s: si, e: ei, posS: posS, durS: durS, resume: true }
            end if
            flat = flat + 1
        end for
    end for
    m.epCount = flat

    ' Where to pick the show up, in the order Android asks the question.
    ' A part-watched episode is the answer whenever there is one: watching in
    ' order leaves exactly one, because finishing an episode throws its
    ' position away (SaveResume clears past 95%).
    ' Failing that, the one AFTER the last finished episode — which is what
    ' the finished marks were written down for, and the only way this page
    ' can answer "what's next" without a request.
    ' Failing both, nothing: a show nobody has touched keeps the plain Play
    ' button, and so does a show watched all the way through.
    if partial <> invalid
        m.resumeTarget = partial
    else if lastDone >= 0
        nx = episodeAtFlat(lastDone + 1)
        if nx <> invalid then m.resumeTarget = { s: nx.s, e: nx.e, posS: 0, durS: 0, resume: false }
    end if
end sub

' Every saved resume point on the box, in ONE registry walk.
'
' Store.brs has LoadSeenSet for finished marks but nothing like it for
' positions — LoadResume answers one key at a time, and a season of twenty
' episodes is twenty roRegistrySection reads on a screen build. Rather than
' add a helper to Store.brs (owned elsewhere) this walks the same section the
' same way LoadSeenSet walks its own.
'
' No profile filtering, and none needed: the keys handed back are the FULL
' keys ResumeKeyEpisode returns, profile prefix included, so a key belonging
' to another profile is simply a key nothing on this page ever asks for.
function loadResumeSet() as object
    out = {}
    sec = CreateObject("roRegistrySection", "kwick_resume")
    for each k in sec.getKeyList()
        ks = ToStr(k)
        ' Value is "<positionS>|<durationS>". The KEY may contain a bar too
        ' (named profiles are prefixed "<id>|"), which is why only the value
        ' is ever split.
        parts = sec.read(ks).split("|")
        if parts.count() >= 2 then out[ks] = { positionS: ToInt(parts[0]), durationS: ToInt(parts[1]) }
    end for
    return out
end function

' The episode at a given index in SHOW order (season by season), or invalid
' past the end.
function episodeAtFlat(target as integer) as dynamic
    if target < 0 then return invalid
    n = 0
    for si = 0 to m.seasons.count() - 1
        eps = m.seasons[si].episodes
        for ei = 0 to eps.count() - 1
            if n = target then return { s: si, e: ei }
            n = n + 1
        end for
    end for
    return invalid
end function

' Re-scan and repaint after something changed a mark or a position.
'
' Keeps the member where they were standing: re-assigning a list's content
' resets it to the first row, and being thrown back to E1 because an episode
' finished is the same rudeness refillNowPlaying refuses to commit on the
' channel grid.
sub refreshWatchState()
    if m.seasons.count() = 0 then return
    keepIdx = m.episodeList.itemFocused
    scanWatchState()
    fillEpisodeList()
    if keepIdx > 0 and keepIdx < m.seasons[m.seasonIdx].episodes.count() then m.episodeList.jumpToItem = keepIdx
    redrawButtons()
end sub

sub onEpisodeSelected()
    try
        playEpisode(m.seasonIdx, m.episodeList.itemSelected)
    catch e
        GuardFailed("series/onEpisodeSelected", e)
        ' THE HELD PLAY IS DROPPED, defensively. On the paths that run to
        ' completion this is already invalid - parentalOkToPlay only sets it on
        ' the branch that returns false cleanly, and flushPendingPlay clears it
        ' first - so this is not fixing a leak anyone has traced. It is here
        ' because a parental gate that faults PART-WAY is the one case nobody
        ' can reason about from the outside, and a stale pendingPlay means the
        ' next flushPendingPlay() starts an episode the member never confirmed
        ' past the PIN. Cheap to clear, and the cost of being wrong is one
        ' ignored press.
        '
        ' Focus is left exactly where it is - on the episode list, where the
        ' press came from - so OK can simply be pressed again.
        m.pendingPlay = invalid
    end try
end sub

sub playEpisode(seasonIdx as integer, epIdx as integer, shuffled = false as boolean, fromStart = false as boolean)
    if seasonIdx < 0 or seasonIdx >= m.seasons.count() then return
    eps = m.seasons[seasonIdx].episodes
    if epIdx < 0 or epIdx >= eps.count() then return
    ' Parental gate. Every way into playback lands here — the Play button, an
    ' episode row, the "..." menu, each shuffled pick and the auto-play-next
    ' countdown — so this one line covers them all, ahead of the Kwick Picks
    ' seed a refused press must not write.
    if not parentalOkToPlay({ kind: "episode", s: seasonIdx, e: epIdx, shuffled: shuffled, fromStart: fromStart }) then return
    e = eps[epIdx]
    ' A media server this app has not signed in to yet has no access token, so
    ' the stream would come back 401 and the member would read a decoder error
    ' about a file that is perfectly fine. Checked BEFORE the Kwick Picks seed
    ' and before Continue Watching, exactly like the parental refusal above.
    if m.isMs and MsNeedsSignIn(m.provider)
        msCannotPlayNote("Kwick Player can't reach " + MsBrandLabel(m.provider) + " right now. Open Settings and sign in to your server again, then try this episode once more.")
        return
    end if
    ' The address, and how to open it. A panel bakes the credentials into the
    ' path; a media server never does — its token rides in a HEADER, because
    ' an address is printed in the diagnostic log and written into watch
    ' history, and a token in either of those is a token in a support email.
    ' e.ext already holds the demuxer for a media-server episode, worked out
    ' from the container when the list was built (the address has no file
    ' extension to read one off).
    hdrs = []
    if m.isMs
        url = MsStreamUrl(m.provider, ToStr(e.id))
        fmt = ToStr(e.ext)
        hdrs = MsHeaders(m.provider)
    else
        ' ONLY A PANEL CAN HAVE A STREAM ADDRESS BUILT HERE, and this is a
        ' POSITIVE test for the two kinds that can rather than a list of the kinds
        ' that cannot. A plain playlist has no server field at all, so Util.brs
        ' answers "" — but a member's own Jellyfin HAS a server, a username and a
        ' password, so the panel builder would hand back a real-looking address
        ' that is simply wrong, and the member would read a decoder error about
        ' something that is perfectly fine.
        '
        ' It is needed because m.provider is this show's OWN source only while
        ' its src token still resolves (onItem). When it does not, m.provider
        ' is left as whatever source happens to be active, which can be any
        ' kind at all.
        pt = ""
        if m.provider <> invalid then pt = LCase(ToStr(m.provider.ptype))
        if pt = "xtream" or pt = "kwicktv"
            url = XtreamSeriesEpisodeUrl(m.provider, e.id, e.ext)
        else
            url = ""
        end if
        fmt = StreamFormatFor(url, e.ext)
    end if
    ' LOG KEY FCF117 — Hisense 6Series-58, v1.0.39, 29 September 2026. What
    ' happened on the member's television, in plain words: they removed their
    ' source in Settings, a different one came back from the website on its own
    ' three seconds later, and the first thing they pressed was a leftover from
    ' the source they had just taken out. The app had nothing left to match it
    ' against, so it reached for the source that had just arrived — an
    ' ordinary playlist, which has no panel address to build a stream from —
    ' and the television froze with the spinner still turning and nothing on
    ' screen to say why. Util.brs now answers "" there instead of stopping the
    ' app; this is the half that tells the member something. Without it the
    ' press is simply dead: the player bails on an empty address before the
    ' Video node is ever handed anything to fail on, so no error and no retry
    ' ever happens, and the member is left watching a spinner turn forever.
    '
    ' Checked HERE, above everything that follows: the Kwick Picks seed and
    ' Continue Watching below must not record an episode the member never
    ' watched, and m.playingS / m.playingE must not start pointing at an
    ' episode that never went on — that pair is what the auto-play-next scan
    ' reads when something finishes.
    if url = ""
        KLog("series", "FCF117: refused play — no source on this box can open [" + ToStr(GetField(m.top.item, "name")) + "]")
        msCannotPlayNote("Kwick Player has no working source for this episode. It was probably left behind by a source you removed. Check your sources under Settings, or pick something else to watch.")
        return
    end if
    resumeKey = ResumeKeyEpisode(ToStr(e.id), m.itemSrc)
    startAt = 0
    ' Episodes auto-resume where you left off (the movie page has the
    ' explicit Resume / Play from Beginning choice) — EXCEPT a shuffled pick,
    ' which always starts at the beginning, and "Play from Beginning" off the
    ' "..." menu, which is the whole point of that entry.
    if not shuffled and not fromStart
        resume = LoadResume(resumeKey)
        if resume <> invalid then startAt = resume.positionS
    end if
    ' Which episode is on screen, for the auto-play-next scan when it ends.
    m.playingS = seasonIdx
    m.playingE = epIdx

    ' Seed for Kwick Picks — the SERIES (not the episode) is the seed.
    it = m.top.item
    if it <> invalid
        rec = { kind: "series", id: ToStr(it.seriesId), name: ToStr(it.name), icon: ToStr(it.icon), ext: "" }
        if m.itemSrc <> invalid then rec.src = m.itemSrc
        ' The landscape artwork for the Media Bar, off the get_series_info
        ' answer this page already had (see onInfo). Left off entirely when the
        ' details never arrived — PushRecentVod then keeps whatever the old row
        ' knew rather than blanking it.
        if m.backdrop <> "" then rec.bd = m.backdrop
        PushRecentVod(rec)
    end if

    m.player = m.top.getScene().createChild("PlayerScreen")
    m.player.titleText = ToStr(m.top.item.name) + " - S" + m.seasons[seasonIdx].num.toStr() + "E" + e.epNum.toStr()
    m.player.streamUrl = url
    m.player.streamFormat = fmt
    ' Empty for every panel and playlist source; the media-server identity
    ' header for a member's own server. The player appends these to the
    ' User-Agent it always sends rather than replacing it.
    m.player.streamHeaders = hdrs
    m.player.isLive = false
    m.player.resumeKey = resumeKey
    m.player.resumeFrom = startAt
    ' History metadata for KwickSync's hist push — same shapes as Android:
    ' title = the SERIES name, sub = "S01E03", parent = series:<id>. The
    ' parent id is source-qualified like the media id, so Continue Watching
    ' on the phone never groups two sources' same-numbered series together.
    m.player.histTitle = ToStr(m.top.item.name)
    m.player.subText = "S" + pad2(m.seasons[seasonIdx].num) + "E" + pad2(e.epNum)
    m.player.posterUrl = ToStr(m.top.item.icon)
    m.player.parentId = "series:" + SrcQualifiedId(ToStr(m.top.item.seriesId), m.itemSrc)
    ' The SHOW's id, not the episode's: the relay takes a parent id with a
    ' season and an episode number, which the player reads off subText.
    m.player.parentTmdbId = ToStr(m.subsTmdb)
    m.player.titleYear = ToStr(m.subsYear)
    m.player.observeField("closed", "onPlayerClosed")
    m.player.observeField("ended", "onPlayerEnded")
    m.player.setFocus(true)
    m.player.start = true
end sub

' ---- Shuffle Episodes (Kevin's request) -------------------------------------
' Plays the whole series in random order until you stop it. The queue is one
' shuffled pass over every episode, so nothing repeats while anything is still
' unseen; when the pass runs out a FRESH pass starts rather than stopping.
' Shuffled picks always start at the beginning — landing mid-episode on a
' random pick is not what "shuffle" means.

sub startShuffle()
    ' Gated BEFORE any shuffle state is set: a press that ends up at the PIN
    ' pad must not leave the screen believing it is shuffling with no player.
    ' The replay after a correct PIN comes back through here.
    if not parentalOkToPlay({ kind: "shuffle" }) then return
    m.shuffleQueue = buildShuffleQueue()
    if m.shuffleQueue.count() = 0 then return
    m.shufflePos = 0
    m.shuffleOn = true
    KLog("series", "shuffle started over " + m.shuffleQueue.count().toStr() + " episode(s)")
    playShuffleCurrent()
end sub

' Every episode of every season, in one shuffled order (Fisher-Yates).
function buildShuffleQueue() as object
    all = []
    for si = 0 to m.seasons.count() - 1
        eps = m.seasons[si].episodes
        for ei = 0 to eps.count() - 1
            all.push({ s: si, e: ei })
        end for
    end for
    for i = all.count() - 1 to 1 step -1
        j = Rnd(i + 1) - 1      ' Rnd(n) gives 1..n
        tmp = all[i]
        all[i] = all[j]
        all[j] = tmp
    end for
    return all
end function

sub playShuffleCurrent()
    if m.shufflePos >= m.shuffleQueue.count()
        ' Pass exhausted — reshuffle and keep going, don't stop.
        m.shuffleQueue = buildShuffleQueue()
        m.shufflePos = 0
        KLog("series", "shuffle pass complete - starting a fresh pass")
        if m.shuffleQueue.count() = 0 then return
    end if
    pick = m.shuffleQueue[m.shufflePos]
    playEpisode(pick.s, pick.e, true)
end sub

' The player finished an episode on its own.
'
' TWO OWNERS, AND SHUFFLE GOES FIRST. While Shuffle Episodes is running it
' owns the end of an episode outright: straight to the next random pick, no
' card, no countdown. That branch is character for character what it was
' before auto-play-next existed, and it returns before anything new can run —
' "random episodes until you stop it" must not turn into "random episodes,
' five seconds apart, if you keep pressing OK".
'
' Everything below it is GAP D4, and only ever reached on an ordinary
' episode.
sub onPlayerEnded()
    try
        onPlayerEndedInner()
    catch e
        GuardFailed("series/onPlayerEnded", e)
        ' SHUFFLE IS SWITCHED OFF, and that is the whole recovery.
        '
        ' This fires when an episode finishes. If the shuffle branch faults it
        ' faults on EVERY episode end, and shuffle's job is to keep starting
        ' new ones - so the page would sit there arming another episode, hitting
        ' the same fault, and writing to the registry each time. That is the
        ' Media Bar rotation problem wearing different clothes.
        '
        ' The player is deliberately NOT removed from here: that needs
        ' getScene(). So the member is left looking at the episode that just
        ' finished, with the remote still in the player, and Back gets them out
        ' to this page the ordinary way - onPlayerClosed below does the tidying.
        ' What they lose is the auto-play of the next episode, once.
        m.shuffleOn = false
    end try
end sub

sub onPlayerEndedInner()
    if m.shuffleOn
        if m.player <> invalid
            m.top.getScene().removeChild(m.player)
            m.player = invalid
        end if
        m.shufflePos = m.shufflePos + 1
        playShuffleCurrent()
        return
    end if
    armAutoNext()
end sub

' ---- Auto-play next episode (GAP D4) ----------------------------------------
'
' Android's AutoNextOverlay, driven from vod_player_screen.dart:338: an
' episode ends, the next one is named, five seconds tick by, and it starts.
'
' NOTHING IN THE PLAYER CHANGED. PlayerScreen already publishes "ended" —
' Shuffle has been reading it since the day it was added — so this hangs off
' the same field and off the same observer. The countdown itself is a
' separate component (UpNextOverlay), attached to the SCENE like the player
' so that it draws over the top of it.
'
' The next episode is the next one in SHOW order: the next row of this
' season, or the first of the season after. The last episode of the last
' season has no next, and stops exactly as it always did.
sub armAutoNext()
    ' One card per finished episode. "ended" is alwaysNotify, so a second
    ' write of the same value fires this again; without the guard a card
    ' could stack on top of a card.
    if m.upNext <> invalid then return
    if not GetPrefBool("pref_auto_play_next", true) then return
    if m.playingS < 0 then return
    nx = nextEpisodeAfter(m.playingS, m.playingE)
    if nx = invalid
        KLog("series", "auto-play next: that was the last episode - stopping")
        return
    end if
    s = m.seasons[nx.s]
    e = s.episodes[nx.e]
    m.nextEp = nx
    ov = m.top.getScene().createChild("UpNextOverlay")
    ov.epLabel = "S" + pad2(s.num) + "E" + pad2(e.epNum) + "  " + ToStr(e.title)
    ov.observeField("result", "onUpNextResult")
    m.upNext = ov
    ov.setFocus(true)
    ov.start = true
    KLog("series", "auto-play next: up next is S" + pad2(s.num) + "E" + pad2(e.epNum))
end sub

' The next episode in show order, or invalid at the end of the show.
function nextEpisodeAfter(si as integer, ei as integer) as dynamic
    if si < 0 or si >= m.seasons.count() then return invalid
    if ei + 1 < m.seasons[si].episodes.count() then return { s: si, e: ei + 1 }
    for s2 = si + 1 to m.seasons.count() - 1
        if m.seasons[s2].episodes.count() > 0 then return { s: s2, e: 0 }
    end for
    return invalid
end function

sub onUpNextResult()
    try
        onUpNextResultInner()
    catch e
        GuardFailed("series/onUpNextResult", e)
        ' STATE AND FOCUS HAVE TO AGREE, and this handler changes both. The
        ' inner version takes the Up Next card off the scene, takes the
        ' finished player off too, then sets m.btnFocus = -1 and hands the
        ' remote to the episode list. A fault part-way can leave m.btnFocus
        ' still saying "a button is active" while the lists hold focus, and
        ' onKeyEvent branches on exactly that - the member would be pressing
        ' arrows at the button row while the highlight sits in the list.
        '
        ' So both are set here, in the same order and for the same reason the
        ' inner version does it. m.nextEp is cleared too: it names the episode
        ' the card offered, and a stale one is an offer to play the wrong
        ' thing later.
        m.nextEp = invalid
        m.btnFocus = -1
        restoreFocusAfterDialog()
    end try
end sub

sub onUpNextResultInner()
    res = ""
    if m.upNext <> invalid
        res = ToStr(m.upNext.result)
        m.top.getScene().removeChild(m.upNext)
        m.upNext = invalid
    end if
    nx = m.nextEp
    m.nextEp = invalid
    ' The finished player goes either way. That is also what keeps "ended"
    ' firing exactly once per episode: the next one gets a brand new
    ' PlayerScreen with its own observer, never a re-used node.
    if m.player <> invalid
        m.top.getScene().removeChild(m.player)
        m.player = invalid
    end if
    if res = "play" and nx <> invalid
        ' Land the lists on what is about to play, so backing out of it
        ' arrives somewhere that makes sense rather than three episodes back.
        ' m.seasonIdx is set FIRST so onSeasonFocused sees no change and does
        ' not rebuild the episode list underneath this.
        if nx.s <> m.seasonIdx
            m.seasonIdx = nx.s
            fillEpisodeList()
            m.seasonList.jumpToItem = nx.s
        end if
        m.episodeList.jumpToItem = nx.e
        playEpisode(nx.s, nx.e)
        return
    end if
    ' Same as onPlayerClosed: the remote is going to the episode list, so
    ' m.btnFocus has to say so before onKeyEvent sees another press.
    m.btnFocus = -1
    refreshWatchState()
    m.episodeList.setFocus(true)
end sub

' Two-digit season/episode numbers, Android style ("S01E03").
function pad2(n as integer) as string
    if n < 10 then return "0" + n.toStr()
    return n.toStr()
end function

sub onPlayerClosed()
    try
        onPlayerClosedInner()
    catch e
        GuardFailed("series/onPlayerClosed", e)
        ' FOCUS AND STATE HAVE TO AGREE - the same pairing the inner version
        ' spells out. It removes the player, then sets m.btnFocus = -1, then
        ' refreshes the ticks, then hands the remote to the episode list. A
        ' fault in refreshWatchState() leaves the player gone and focus
        ' nowhere: this page on screen with a remote that does nothing.
        '
        ' THE UP NEXT CARD IS CHECKED FIRST, exactly as the inner version
        ' does. If that card is up it holds the remote and onUpNextResult is
        ' what tidies up after it; pulling focus out from under it from an
        ' error path would take the member's countdown away mid-count.
        if m.upNext = invalid
            m.btnFocus = -1
            restoreFocusAfterDialog()
        end if
    end try
end sub

sub onPlayerClosedInner()
    if m.player <> invalid
        m.top.getScene().removeChild(m.player)
        m.player = invalid
    end if
    ' Backing out of a shuffled episode is how you stop shuffling — the
    ' feature is "random episodes until you stop it".
    if m.shuffleOn
        m.shuffleOn = false
        KLog("series", "shuffle stopped")
    end if
    ' The Up Next card is on screen and holds the remote. Do not pull focus
    ' out from under it just because the finished player behind it went away
    ' — onUpNextResult tidies up on whichever way that card is answered.
    if m.upNext <> invalid then return
    ' FOCUS AND STATE HAVE TO AGREE. m.btnFocus is what onKeyEvent branches on,
    ' so handing the remote to the episode list while it still says "a button
    ' is active" left every arrow press going to the button handler with the
    ' ring drawn on Play and the highlight sitting on an episode. Pre-existing;
    ' it bites whenever playback was started from the Play button rather than
    ' from the list. Set FIRST, so the repaint below takes the ring down.
    m.btnFocus = -1
    ' Coming back may have created a resume point, or finished the episode
    ' outright (the player writes the mark itself) — so the ticks and the
    ' Play button are both stale until this runs.
    refreshWatchState()
    m.episodeList.setFocus(true)
end sub

' ---- The D-pad chain, hand-wired, and its two exits into the lists ---------
'
' THE SHAPE. Index 0 is the primary and is alone on row 0; indices 1..N-1 are
' the secondaries on row 1, left to right. buildButtons guarantees that and
' nothing here depends on which buttons exist. -1 means focus is in the LISTS
' and the key sink no longer holds it.
'
' IT IS THE FILM PAGE'S CHAIN, because the buttons are now the film page's
' buttons. What this page adds is the two exits into the season and episode
' lists, and the back-ladder that climbs out of them.
'
' THE WALK, and every square is reachable in both directions:
'
'     from            up            down          left      right
'     0 primary       (stays)       1             0         0
'     1 (first sec)   0             synopsis      1         2
'     2..N-2          0             synopsis      i-1       i+1
'     N-1 (last sec)  0             synopsis      i-1       N-1
'     synopsis        button 1      season list   (stays)   (stays)
'     season list r0  synopsis      (list)        (stays)   episode list
'     season list r>0 (list)        (list)        (stays)   episode list
'     episode list    (list)        (list)        season    (stays)
'
' Down from the primary always lands on index 1; up from ANY secondary always
' lands on the primary. So from any square the primary is one, two or three
' presses away, and from the primary every secondary is down-then-left/right.
'
' >>> THE SYNOPSIS IS NOW THE ROW BETWEEN THE BUTTONS AND THE LISTS
' (2026-08-27), where it used to be the row above the primary. Mason moved the
' words - "put the decription under the buttons but above the seasons and
' episodes" - and the focus stop HAD to move with them: Roku decides
' directional focus purely by geometry, and a stop that is not where it looks
' is a bug nobody can explain. Down from any secondary reaches it, Up returns
' to the first secondary, Down carries on into the season list.
'
' Up from the PRIMARY now stays put. There is nothing focusable above it: the
' chips row and the ratings strip are Labels and Posters, which cannot take
' focus. That is the same behaviour the primary had before the synopsis was
' ever a stop.
'
' It is a stop ONLY while there is something to read (m.dpOn). A show whose
' details never arrived walks secondary -> season list directly, exactly as it
' did before this existed, and leaveListsUpward() skips it on the way back. OK
' on it opens the reading panel, and while that panel is up dpKey() swallows
' every key, so Back collapses the panel first and only closes the page once it
' is shut.
'
' THE LIST EXITS. Down out of any secondary lands on the synopsis, or on the
' SEASON list when there is none. Right out of the season list lands on the
' episode list; left out of the episode list goes back. Neither exit can arrive
' at a tile that does not exist yet: both lists are filled by
' fillSeasonList/fillEpisodeList before any of this is reachable, and when the
' show has no episodes at all the lists are empty, Down off the synopsis is
' refused outright, and the highlight stays where the member put it.
'
' BACK CLIMBS ONE LEVEL AT A TIME and ALWAYS reaches the exit:
'     episode list -> season list -> synopsis (or button 1) -> the page closes.
' Lists never swallow Back, so the ladder works even where Up is eaten by a
' list at its top edge. From ANY button AND from the synopsis, Back closes the
' page outright - it is checked before the arrow handling in both branches, so
' a 2-D handler cannot strand the member on the page with no way out. Worst
' case from anywhere on the page is three presses.
'
' UP OUT OF THE SEASON LIST goes to the synopsis, the block the lists sit
' directly under, and to button 1 when there is no synopsis. Only at the top
' row; below that the list keeps its own Up. leaveListsUpward() is the single
' copy of that decision, shared by Up and by Back.
'
' NOT SYMMETRIC ON PURPOSE, and the film page makes the same trade in the same
' words: down from button 3 and back up returns to button 1, not to 3.
' Remembering the column would be a shade nicer to use and it is a second
' behaviour to maintain on a chain the two pages now share. Deterministic beats
' clever.
'
' THE PARENTAL GATE IS UNTOUCHED: it hangs off playEpisode() and reads nothing
' from m.btnFocus, so the shape of the row cannot reach it.

' The first secondary, which is where the lists hand focus back. A row with a
' primary and nothing else falls back to the primary rather than to an index
' that is not there.
function firstSecondary() as integer
    if m.buttons.count() > 1 then return 1
    return 0
end function

' Leaving the season list upward - by Up at its top row, or by Back one rung up
' the ladder. ONE function because the two used to be two copies of the same
' three lines and the synopsis moving below the buttons on 2026-08-27 gave them
' a second case to get wrong.
'
' The synopsis is the block DIRECTLY ABOVE the lists now, so that is where this
' lands whenever there is something to read; the first secondary button is the
' next rung up, and the fallback when the show sent no synopsis at all. Either
' way the key sink takes real focus, so the lists stop eating arrow presses,
' and btnFocus stays >= 0 so onFocusIn agrees with it.
sub leaveListsUpward()
    if m.dpOn = true
        m.descFocus = true
    else
        m.descFocus = false
    end if
    m.btnFocus = firstSecondary()
    m.keySink.setFocus(true)
    redrawButtons()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    try
        return onKeyEventInner(key, press)
    catch e
        GuardFailed("series/onKeyEvent", e)
    end try

    ' TRUE, NOT FALSE, ON A CAUGHT FAULT - the channel page's choice, and NOT
    ' Home's or the Media Bar's. The difference is where the key would go next.
    ' This page is a SCENE CHILD, not a child of the shell: AppShell is its
    ' sibling, not its ancestor, so a key this function returns false for does
    ' not reach AppShell's Back handler at all. It goes to AppScene, which has
    ' no onKeyEvent (AppShell.brs:1070 says so in as many words), and from
    ' there to the firmware, which CLOSES THE CHANNEL. So returning false here
    ' would turn one caught fault into the member being thrown out of the app.
    '
    ' BUT SWALLOWING BACK ON ITS OWN WOULD STRAND THEM on the page, because
    ' the only way off it is setting `closed` - which is what the bottom rung
    ' of the Back ladder below does. So the catch does it too.
    '
    ' THE LADDER IS LOST, and that is the one thing the member would notice:
    ' Back normally climbs episodes -> seasons -> buttons -> close, and from
    ' here it closes the page in one press instead of three. One press too
    ' many beats no way out, and it only happens on a page that has already
    ' faulted.
    '
    ' A KEY-UP IS STILL RETURNED FALSE, exactly as the inner version's first
    ' line does, so a fault cannot start swallowing the release half of every
    ' press. In practice that line cannot fault, but the contract this function
    ' advertises should not change just because something below it broke.
    if not press then return false
    if key = "back" then m.top.closed = true
    return true
end function

function onKeyEventInner(key as string, press as boolean) as boolean
    if not press then return false

    ' THE READING PANEL IS ASKED FIRST and swallows everything while it is up,
    ' so Back collapses it and nothing behind it - buttons or lists - can move
    ' underneath the member.
    if dpKey(key) then return true

    ' ---- the synopsis, when the highlight is on it -------------------------
    ' It is a stop between the chips and the Play button, and it holds the key
    ' sink exactly as the buttons do, so the lists cannot eat arrow presses
    ' while it is active.
    if m.descFocus
        if key = "back"
            m.top.closed = true
        else if key = "OK"
            dpShow()
        else if key = "up"
            ' BACK UP TO THE BUTTON ROW the synopsis now sits under - the
            ' secondaries, which is the row directly above it on screen.
            ' firstSecondary() rather than a fixed 1, so a row that somehow had
            ' only a primary still lands somewhere real.
            m.descFocus = false
            m.btnFocus = firstSecondary()
            m.keySink.setFocus(true)
            redrawButtons()
        else if key = "down"
            ' ON INTO THE LISTS, and ONLY when there is something there to land
            ' on. Handing focus to an empty LabelList takes the highlight off
            ' this block and puts it nowhere, leaving the member with no visible
            ' focus and only Back to escape. A show with no seasons keeps the
            ' highlight here.
            if m.seasons.count() > 0
                m.descFocus = false
                m.btnFocus = -1
                redrawButtons()
                m.seasonList.setFocus(true)
            end if
        end if
        ' left / right stay put: there is nothing beside it.
        return true
    end if

    ' The buttons are custom focus stops above the lists. The key sink holds
    ' real focus while they are active so the lists cannot eat arrow presses.
    if m.btnFocus >= 0
        ' CHECKED FIRST and always closes the page, for the reason above.
        if key = "back"
            m.top.closed = true
            return true
        else if key = "OK"
            if m.btnFocus >= m.buttons.count() then return true
            b = m.buttons[m.btnFocus]
            if b.key = "play"
                ' Where scanWatchState says to pick the show up, if anywhere;
                ' otherwise the first episode of the selected season, which is
                ' what this button has always done. Either way playEpisode
                ' resumes on its own, so Resume needs nothing extra here.
                t = m.resumeTarget
                if t <> invalid
                    playEpisode(t.s, t.e)
                else
                    playEpisode(m.seasonIdx, 0)
                end if
            else if b.key = "shuffle"
                startShuffle()
            else if b.key = "markseries"
                askMarkSeries()
            else if b.key = "favorite"
                it = m.top.item
                fav = { kind: "series", id: ToStr(it.seriesId), name: ToStr(it.name), icon: ToStr(it.icon), ext: "" }
                if m.itemSrc <> invalid then fav.src = m.itemSrc
                ToggleFavoriteVod(fav)
            else if b.key = "addlist"
                openAddToList()
            end if
            redrawButtons()
            return true
        else if key = "down"
            ' Row 0 -> row 1 at its left end. Row 1 -> the synopsis if there is
            ' one to read (it is the next thing down the page now), otherwise
            ' straight on into the lists.
            if m.btnFocus = 0
                if m.buttons.count() > 1
                    m.btnFocus = 1
                    redrawButtons()
                end if
            else if m.dpOn = true
                ' The key sink already holds real focus and the synopsis is a
                ' custom stop, so nothing has to be handed over. btnFocus stays
                ' >= 0 so onFocusIn still routes to the key sink; redrawButtons
                ' paints index -1 while descFocus is set, so no button keeps
                ' the highlight.
                m.descFocus = true
                m.btnFocus = firstSecondary()
                redrawButtons()
            else if m.seasons.count() > 0
                ' Out into the lists - but ONLY when there is something there
                ' to land on. Handing focus to an empty LabelList takes the
                ' highlight off the buttons and puts it nowhere, which on a
                ' show whose details are still on the way would leave the
                ' member with no visible focus at all and only Back to escape.
                m.btnFocus = -1
                redrawButtons()
                m.seasonList.setFocus(true)
            end if
            return true
        else if key = "up"
            ' Any secondary -> the primary. The primary is the top stop on this
            ' page now: the synopsis moved BELOW the button row on 2026-08-27,
            ' and the chips and the ratings strip above it are not focusable.
            if m.btnFocus > 0
                m.btnFocus = 0
                redrawButtons()
            end if
            return true
        else if key = "left"
            ' Within row 1 only. Index 1 is the left end and stays put; the
            ' primary has nothing beside it and stays put.
            if m.btnFocus > 1
                m.btnFocus = m.btnFocus - 1
                redrawButtons()
            end if
            return true
        else if key = "right"
            if m.btnFocus >= 1 and m.btnFocus < m.buttons.count() - 1
                m.btnFocus = m.btnFocus + 1
                redrawButtons()
            end if
            return true
        end if
        return true
    end if

    ' Back climbs one level at a time: episodes -> seasons -> buttons ->
    ' close. Lists never swallow Back, so this ladder ALWAYS works even
    ' when Up is eaten by the list at its top edge.
    if key = "back"
        if m.episodeList.hasFocus()
            m.seasonList.setFocus(true)
            return true
        end if
        if m.seasonList.hasFocus()
            leaveListsUpward()
            return true
        end if
        m.top.closed = true
        return true
    else if key = "up"
        if m.seasonList.hasFocus() and m.seasonList.itemFocused <= 0
            leaveListsUpward()
            return true
        end if
    else if key = "right"
        if m.seasonList.hasFocus()
            m.episodeList.setFocus(true)
            return true
        end if
    else if key = "left"
        if m.episodeList.hasFocus()
            m.seasonList.setFocus(true)
            return true
        end if
    else if key = "options"
        ' The * (Options) button opens the episode menu — the same key, and
        ' the same Dialog, the channel menu uses (LiveTvScreen). Episodes
        ' only: a season is not a thing you can mark or play.
        if m.episodeList.hasFocus() then openEpisodeOptions()
        return true
    end if
    return false
end function

' ---- The per-episode "..." menu (GAP D3) ------------------------------------
'
' Android's showEpisodeMenu (lib/ui/widgets/episode_menu.dart): play, play
' from the beginning, mark watched or unwatched, and mark everything up to
' here in one go for somebody who watched the first season elsewhere.
'
' It is built fresh from THIS episode's state, so its buttons are renumbered
' every time they change. LiveTvScreen's channel menu warns about exactly
' this hazard and dodges it by never reordering a fixed set — a set that
' changes shape cannot, so the actions are kept in a parallel list and the
' pressed index is looked up in that rather than compared against a number.
sub openEpisodeOptions()
    idx = m.episodeList.itemFocused
    if idx < 0 or m.seasons.count() = 0 then return
    eps = m.seasons[m.seasonIdx].episodes
    if idx >= eps.count() then return
    e = eps[idx]
    st = "none"
    if e.doesExist("st") then st = ToStr(e.st)
    flat = 0
    if e.doesExist("flat") then flat = ToInt(e.flat)
    m.optEp = { s: m.seasonIdx, e: idx }

    labels = []
    keys = []
    ' Resume is only offered when there is something to resume, so the label
    ' never promises a position that does not exist.
    if st = "part" then labels.push("Resume") else labels.push("Play")
    keys.push("play")
    if st <> "none"
        labels.push("Play from Beginning")
        keys.push("begin")
    end if
    if st = "done"
        labels.push("Mark as Unwatched")
        keys.push("unmark")
    else
        labels.push("Mark as Watched")
        keys.push("mark")
    end if
    ' Only when there IS anything before it, counted across the whole show
    ' rather than this season — someone catching the app up on a season they
    ' watched elsewhere is the case this entry exists for.
    if flat > 0
        labels.push("Mark This and All Before as Watched")
        keys.push("markprev")
    end if
    labels.push("Cancel")
    keys.push("cancel")
    m.optKeys = keys

    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "S" + pad2(m.seasons[m.seasonIdx].num) + "E" + pad2(e.epNum) + "  " + ToStr(e.title)
    dialog.buttons = labels
    dialog.observeField("buttonSelected", "onEpisodeOptions")
    m.top.getScene().dialog = dialog
end sub

sub onEpisodeOptions()
    try
        onEpisodeOptionsInner()
    catch e
        GuardFailed("series/onEpisodeOptions", e)
        ' FOCUS BACK. This is the "..." menu; every one of its branches ends by
        ' putting the remote somewhere, so a fault part-way leaves the member
        ' with the menu gone and no focus anywhere on the page. That is the
        ' real recovery here.
        '
        ' The two fields cleared alongside it are belt-and-braces, NOT fixes
        ' for anything traced: m.optEp is overwritten by openEpisodeOptions
        ' every time the menu is opened, and m.pendingPlay is only ever set on
        ' a gate branch that returns cleanly. They are cleared because this
        ' handler is the one that can fault between "the member chose Play" and
        ' "playback started", and neither field costs anything to let go of.
        m.optEp = invalid
        m.pendingPlay = invalid
        restoreFocusAfterDialog()
    end try
end sub

sub onEpisodeOptionsInner()
    dialog = m.top.getScene().dialog
    choice = dialog.buttonSelected
    dialog.close = true
    act = "cancel"
    if choice >= 0 and choice < m.optKeys.count() then act = m.optKeys[choice]
    t = m.optEp
    if t = invalid
        m.episodeList.setFocus(true)
        return
    end if
    ' The two that play return without touching focus: playEpisode either
    ' opens the player, which takes it, or hands it to the PIN pad.
    if act = "play"
        playEpisode(t.s, t.e)
        return
    else if act = "begin"
        playEpisode(t.s, t.e, false, true)
        return
    else if act = "mark"
        markEpisodeSeen(t.s, t.e)
    else if act = "unmark"
        unmarkEpisodeSeen(t.s, t.e)
    else if act = "markprev"
        markThroughEpisode(t.s, t.e)
    end if
    ' AFTER the writes, not before — the repaint they cause would otherwise
    ' land after the focus request and take the remote off the row again.
    refreshWatchState()
    m.episodeList.setFocus(true)
end sub

sub markEpisodeSeen(si as integer, ei as integer)
    e = m.seasons[si].episodes[ei]
    ' The position is deliberately left alone, exactly as on Android: a mark
    ' outranks it everywhere that asks, and throwing it away would quietly
    ' drop the episode out of Continue Watching on every device the moment
    ' somebody ticked it by hand.
    MarkSeen(SeenKeyEpisode(ToStr(e.id), m.itemSrc), m.seriesRef)
    KLog("series", "marked S" + pad2(m.seasons[si].num) + "E" + pad2(e.epNum) + " as watched")
    ' And on their own Trakt and Simkl accounts. One episode, one request each.
    seriesTrackerMark(true, [seriesTrackerEp(si, ei)])
end sub

sub unmarkEpisodeSeen(si as integer, ei as integer)
    e = m.seasons[si].episodes[ei]
    ' One key, both stores — SeenKeyEpisode and ResumeKeyEpisode are the same
    ' string by design (Store.brs says so at the top of the seen section).
    key = SeenKeyEpisode(ToStr(e.id), m.itemSrc)
    UnmarkSeen(key)
    ' And forget the position, or the 95% rule calls it finished all over
    ' again and the tick is back before the list has finished repainting.
    ' Android does the same thing for the same reason.
    ClearResume(key)
    KLog("series", "marked S" + pad2(m.seasons[si].num) + "E" + pad2(e.epNum) + " as unwatched")
    ' And off their own Trakt and Simkl accounts.
    seriesTrackerMark(false, [seriesTrackerEp(si, ei)])
end sub

' This episode and everything before it in SHOW order.
sub markThroughEpisode(si as integer, ei as integer)
    ep = m.seasons[si].episodes[ei]
    if not ep.doesExist("flat") then return
    target = ToInt(ep.flat)
    n = 0
    ' Collected in the SAME walk, in show order, so the batch below costs no
    ' second pass over the show — and only when there is somebody to send it
    ' to, which for most members there is not.
    reach = []
    want = TrackerMarksOn()
    for s2 = 0 to m.seasons.count() - 1
        for e2 = 0 to m.seasons[s2].episodes.count() - 1
            row = m.seasons[s2].episodes[e2]
            if row.doesExist("flat") and ToInt(row.flat) <= target
                if MarkSeenRaw(SeenKeyEpisode(ToStr(row.id), m.itemSrc), m.seriesRef) then n = n + 1
                if want then reach.push(seriesTrackerEp(s2, e2))
            end if
        end for
    end for
    ' MarkSeenRaw + ONE TrimSeen is the store's own door for a batch, and it
    ' says why: TrimSeen walks the whole section, so trimming per row would
    ' do that walk once per episode instead of once per press.
    if n > 0 then TrimSeen()
    KLog("series", "marked " + n.toStr() + " episode(s) up to and including this one as watched")
    ' EVERY episode in the range, not just the ones that were new here — the
    ' member said "all of these are watched" and Android sends the same range
    ' (series_detail_screen.dart:1046-1060, `all.take(index + 1)`). ONE request
    ' per service carries the lot; a run of forty episodes must never be forty
    ' calls, because those limits belong to every Kwick Player in the world.
    seriesTrackerMark(true, reach)
end sub

' ---- Mark Series as Watched (GAP D5) ----------------------------------------
'
' Android's series-level button (series_detail_screen.dart:527) clears the
' whole show out of Continue Watching in one press. Here it does that AND
' writes the marks, because on this app the marks are what make the ticks
' appear — clearing positions alone would leave a show that looks completely
' untouched.
'
' It ASKS FIRST, which Android does not. Android undoes it with a snackbar;
' a TV has nowhere to put one, and this press throws away every saved
' position in the show. On a long show it can also crowd the finished-marks
' store, which is capped at 200 rows for the whole box and evicts the oldest
' to stay there — worth a sentence before, not a surprise after.
sub askMarkSeries()
    if m.seasons.count() = 0 or m.epCount = 0 then return
    it = m.top.item
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Mark Series as Watched"
    dialog.message = "Mark all " + m.epCount.toStr() + " episode(s) of " + ToStr(it.name) + " as watched? This also clears the show from Continue Watching."
    dialog.buttons = ["Mark All", "Cancel"]
    dialog.observeField("buttonSelected", "onMarkSeriesAnswer")
    m.top.getScene().dialog = dialog
end sub

sub onMarkSeriesAnswer()
    try
        dialog = m.top.getScene().dialog
        choice = dialog.buttonSelected
        dialog.close = true
        if choice = 0 then markSeriesSeen()
        restoreFocusAfterDialog()
    catch e
        GuardFailed("series/onMarkSeriesAnswer", e)
        ' FOCUS BACK. This is the "mark the whole show as watched?" answer. It
        ' ends by restoring focus anyway, so a fault in markSeriesSeen() -
        ' which walks every episode of every season and writes marks - leaves
        ' the dialog closed and the remote nowhere.
        '
        ' PART-MARKED IS NOT UNDONE, and the member can see it: the ticks for
        ' the episodes that were written stay written, and the rest do not
        ' appear. Unpicking a half-finished walk from an error path means
        ' guessing which writes landed, so the honest answer is to leave what
        ' happened and let them press it again - marking an already-marked
        ' episode is harmless.
        restoreFocusAfterDialog()
    end try
end sub

sub markSeriesSeen()
    n = 0
    ' Collected in the SAME walk, in show order, for the one request below —
    ' and only when there is somebody to send it to.
    whole = []
    want = TrackerMarksOn()
    for si = 0 to m.seasons.count() - 1
        for ei = 0 to m.seasons[si].episodes.count() - 1
            e = m.seasons[si].episodes[ei]
            key = SeenKeyEpisode(ToStr(e.id), m.itemSrc)
            if MarkSeenRaw(key, m.seriesRef) then n = n + 1
            ' The Continue Watching half of what the button promises. Safe on
            ' a key with no resume point — ClearResume checks before it
            ' deletes.
            ClearResume(key)
            if want then whole.push(seriesTrackerEp(si, ei))
        end for
    end for
    if n > 0 then TrimSeen()
    KLog("series", "marked the whole show as watched - " + n.toStr() + " new mark(s) over " + m.epCount.toStr() + " episode(s)")
    ' The whole show on the member's own accounts too, in ONE request each.
    '
    ' THIS ONE GOES BEYOND ANDROID and is worth knowing about: Android's
    ' series-level button only clears Continue Watching, so there is nothing
    ' there to copy. On this app the button WRITES the marks, which is what
    ' makes the ticks appear, so a member pressing it has said "I have watched
    ' this show" exactly as plainly as they do on one episode. Filing it is the
    ' consistent answer; leaving it out would tick every episode on the
    ' television and nothing at all on their Trakt.
    seriesTrackerMark(true, whole)
    refreshWatchState()
end sub

' ---- The same marks on the member's OWN Trakt and Simkl accounts (GAP D5) ----
'
' The second, independent errand on all four of this page's marks. The local
' marks above are unchanged and are still what make the ticks appear; this files
' the same thing on whichever tracking accounts the member has signed in to.
'
' EVERYTHING ABOUT IT LIVES IN TrackerMarks.brs — which services, which switch,
' what is sent, what is logged, and the cap on how many episodes one request
' carries. These two are only the series page saying what it has. They return
' immediately: the request goes out on AddOnTask's own thread and nothing on
' this page ever waits for it or is told when it fails.
'
' ONLY REACHED FROM A DELIBERATE PRESS — the episode menu and the Mark Series
' button. The app's own automatic mark at 95% is written in the player and never
' comes through here, and the player already sends its own scrobbles, so an
' episode is never filed twice by both halves. See the header of
' TrackerMarks.brs for the one case that does overlap.
'
' NO ID, NOTHING SENT, NOTHING SAID. m.subsTmdb is the SHOW's id, the same one
' the player is handed for scrobbling. A media-server show has none, and a show
' marked in the second before its details answer arrives has none yet either —
' in both cases nothing goes to either service and the member is told nothing,
' because an episode filed under a guessed show id lands on the wrong programme
' on their real account.

' One episode of this show, as { season, number } — the SHOW's season and
' episode numbers, never the episode's own catalogue id, which is a different
' number entirely and files the watch against the wrong programme.
function seriesTrackerEp(si as integer, ei as integer) as object
    return { season: ToInt(m.seasons[si].num), number: ToInt(m.seasons[si].episodes[ei].epNum) }
end function

sub seriesTrackerMark(watched as boolean, eps as object)
    TrackerMarkEpisodes(m.top.getScene(), watched, ToStr(m.subsTmdb), eps)
end sub

sub openAddToList()
    it = m.top.item
    m.addList = m.top.getScene().createChild("AddToListScreen")
    itemAA = { kind: "series", id: ToStr(it.seriesId), name: ToStr(it.name), icon: ToStr(it.icon), ext: "" }
    if m.itemSrc <> invalid then itemAA.src = m.itemSrc
    m.addList.item = itemAA
    m.addList.observeField("closed", "onAddListClosed")
    m.addList.setFocus(true)
end sub

sub onAddListClosed()
    try
        onAddListClosedInner()
    catch e
        GuardFailed("series/onAddListClosed", e)
        ' FOCUS BACK ON THIS PAGE. The list picker is taken off the scene
        ' first and the remote handed back last, so a fault in redrawButtons()
        ' leaves the picker gone and focus nowhere.
        restoreFocusAfterDialog()
    end try
end sub

sub onAddListClosedInner()
    if m.addList <> invalid
        m.top.getScene().removeChild(m.addList)
        m.addList = invalid
    end if
    redrawButtons()
    m.keySink.setFocus(true)
end sub

' ---- Parental gate -----------------------------------------------------------
'
' Same reasoning as the movie page: the Series category strip hides or gates a
' locked category, but this page is also reached from a favorite, from
' Continue Watching (which opens the SHOW), from a saved list and from the
' Media Bar's "More info" — none of which passed that strip. So the last word
' on whether a locked show plays belongs here, next to the play call.
'
' The rule, the PIN pad and the session unlock are the shared ones in
' GuideMeta.brs. A locked category asks here EVEN IN "hide" mode, for the
' reason the helper gives: hiding never applied on the way in.
'
' The adult rule (certification 6.3) rides along, because it is the same
' helper: an adult category with the Settings switch off answers "blocked",
' which no PIN opens. That is the one verdict that says no rather than asking.
'
' COST. ParentalGate() is about a dozen registry reads, taken ONCE in onItem —
' not per button, and NOT per episode row. A member with nothing locked AND
' adult categories already allowed takes parentalIdle()'s early exit and this
' block does nothing at all; everyone else pays one id->name cache read when
' get_series_info lands, and one hash lookup per press.

function parentalIdle() as boolean
    if m.pgate = invalid then return true
    if not m.pgate.adultOk then return false
    return m.pgate.locked.count() = 0
end function

' Which category is this show in? It rides on the get_series_info request this
' page ALREADY makes (info.category_id, with the payload's own copy as a
' fallback) — no extra request, and nothing per row. The id becomes a name
' through the id->name cache the browsing screens keep warm, with the same
' honest limitation ParentalBlockedCatIds documents: a cold cache resolves to
' nothing and the show is let through until something has been browsed.
'
' There is no "still loading" case to hold here the way the movie page has to:
' nothing on this screen can be played until this very answer has built the
' season and episode lists.
sub resolveCatFromInfo(res as dynamic)
    m.catName = ""
    ' Nothing to enforce: don't even read the cache.
    if parentalIdle() then return
    if res = invalid or res.ok <> true or m.provider = invalid then return
    cid = ToStr(GetField(GetField(res.data, "info"), "category_id"))
    if cid = "" then cid = ToStr(GetField(res.data, "category_id"))
    if cid = "" then return
    m.catName = catIdToName(loadCatNameCache("series", ToStr(m.provider.id)), cid)
end sub

' May this press start playback? "asked" leaves the PIN pad on screen and the
' press is replayed if the member gets it right.
function parentalOkToPlay(pending as object) as boolean
    if parentalIdle() then return true
    if m.catName = "" then return true
    v = ParentalGuardWith(m.pgate, m.top, m.catName, "onParentalPin", "onParentalPinCancel")
    if v = "allow" then return true
    if v = "asked"
        KLog("series", "detail: [" + m.catName + "] is locked - asking for the PIN")
        m.pendingPlay = pending
        return false
    end if
    ' "blocked": an adult category with the Settings switch off. No PIN gets
    ' in, so say so rather than leave the button looking broken.
    KLog("series", "detail: [" + m.catName + "] is an adult category and the Settings switch is off")
    m.pendingPlay = invalid
    note = CreateObject("roSGNode", "Dialog")
    note.title = "Not Available"
    note.message = "Adult categories are switched off. Turn on 'Show adult categories' under Settings > Parental controls to watch this."
    note.buttons = ["OK"]
    note.observeField("buttonSelected", "onParentalPinNote")
    m.top.getScene().dialog = note
    return false
end function

' Carry out the press that was unlocked. Cleared FIRST so a second refusal
' can't loop.
sub flushPendingPlay()
    p = m.pendingPlay
    if p = invalid then return
    m.pendingPlay = invalid
    if ToStr(p.kind) = "shuffle"
        startShuffle()
    else
        ' fromStart rides along with shuffled so a "Play from Beginning" that
        ' went to the PIN pad comes back as a play from the beginning, not as
        ' a resume — the two flags are the only thing that tells them apart.
        playEpisode(p.s, p.e, p.shuffled = true, p.fromStart = true)
    end if
end sub

' THESE TWO ARE RENDER-THREAD ENTRY POINTS TOO, and a grep of this file for
' observeField does not find them: the names are handed to ParentalGuardWith as
' strings (above), and GuideMeta.brs:369-370 is what observes "accepted" and
' "cancelled" on the PIN keyboard with them. They run in THIS component's
' namespace all the same, so they are guarded like everything else.
sub onParentalPin()
    try
        onParentalPinInner()
    catch e
        GuardFailed("series/onParentalPin", e)
        ' THE PIN PAD COMES DOWN AND THE HELD PLAY IS DROPPED. This is the
        ' handler for a CORRECT PIN, so a fault here is the member typing the
        ' right code and the television doing absolutely nothing - the FCF117
        ' complaint the channel page already carries a note about. Worse, it
        ' faults with the pad still on screen holding the remote.
        '
        ' ParentalClosePin() is safe to call from in here: it only sets close
        ' on m.pinDialog and never asks for the scene. The play is let go
        ' rather than retried, because a flush that faulted part-way may
        ' already have started something.
        ParentalClosePin()
        m.pendingPlay = invalid
        restoreFocusAfterDialog()
    end try
end sub

sub onParentalPinInner()
    if ParentalAcceptPin()
        ' Unlocked for the rest of the session — take a fresh snapshot (it now
        ' loads no locks at all) and play what was asked for.
        m.pgate = ParentalGate("series")
        flushPendingPlay()
    else
        ParentalWrongPinNote(m.top, "onParentalPinNote")
    end if
end sub

sub onParentalPinCancel()
    try
        onParentalPinCancelInner()
    catch e
        GuardFailed("series/onParentalPinCancel", e)
        ' The member backed out of the PIN pad. Drop the held play and take
        ' the remote back, which is all the inner version does anyway.
        m.pendingPlay = invalid
        restoreFocusAfterDialog()
    end try
end sub

sub onParentalPinCancelInner()
    ParentalClosePin()
    m.pendingPlay = invalid
    restoreFocusAfterDialog()
end sub

sub onParentalPinNote()
    try
        m.top.getScene().dialog.close = true
        m.pendingPlay = invalid
        restoreFocusAfterDialog()
    catch e
        GuardFailed("series/onParentalPinNote", e)
        ' THE HELD PLAY IS DROPPED FIRST, and that order matters. This handler
        ' is the "wrong PIN" note: the member failed the parental check, and
        ' m.pendingPlay is still holding the episode they asked for. Leave it
        ' set and the next thing that calls flushPendingPlay() - the next
        ' correct PIN, or the next details answer - plays the episode the gate
        ' just refused. So it is cleared here whatever else went wrong.
        m.pendingPlay = invalid
        restoreFocusAfterDialog()
    end try
end sub

' Back where the member was: the key sink while a button is active, the
' episode list otherwise — the same split onFocusIn makes.
sub restoreFocusAfterDialog()
    if m.btnFocus >= 0
        m.keySink.setFocus(true)
    else
        m.episodeList.setFocus(true)
    end if
end sub
