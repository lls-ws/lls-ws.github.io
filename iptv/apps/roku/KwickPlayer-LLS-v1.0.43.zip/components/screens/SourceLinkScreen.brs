' Add a source — the full-screen version, opened from Settings when a
' member wants to add another source later.
'
' It says "a source" and not "Xtream or M3U" because kwickplayer.tv now takes
' the member's own Jellyfin or Emby as well, and pairing is the ONLY way a
' store build can be given one: the screen that takes a typed server address
' is sideload-only, because Roku's Distribution Agreement 10.3(a) forbids a
' store build from letting anybody "enter web addresses".
'
' All this does is draw. The conversation with kwickplayer.tv/link — the
' claim, the QR, the polling, the fifteen-minute expiry and the re-claim,
' saving whatever arrives, and what to do when the service is unreachable —
' lives in LinkSession, because the store edition's first screen shows the
' same code on its right half and there must be exactly one of that machine
' anywhere in the app. This screen watches the session's fields and puts
' them where they go.
'
' Nothing here keeps running once the screen is gone: closeScreen() stops
' the session, which stops its timers and whatever request was in the air.

sub init()
    m.theme = KwickTheme()

    m.top.findNode("bg").color = m.theme.background
    ' This screen is a scene-level overlay, so its own backdrop covers
    ' AppScene's grid wash. See AddPageGrid() in Theme.brs — the mesh
    ' goes in at child 1, just above the backdrop declared first in the
    ' XML above, and under everything this screen draws.
    AddPageGrid(m.top)

    title = m.top.findNode("title")
    title.text = "Add a source"
    title.font = UiBoldFont(46)
    title.color = m.theme.textPrimary

    step1 = m.top.findNode("step1")
    step1.text = "In a web browser, go to:"
    step1.font = linkFont(28)
    step1.color = m.theme.textSecondary

    urlLabel = m.top.findNode("urlLabel")
    urlLabel.text = "kwickplayer.tv/link"
    urlLabel.font = UiBoldFont(44)
    urlLabel.color = m.theme.accentAlt

    m.step2 = m.top.findNode("step2")
    m.step2.text = "Then enter this code:"
    m.step2.font = linkFont(28)
    m.step2.color = m.theme.textSecondary

    m.codeBg = m.top.findNode("codeBg")
    m.codeBg.color = m.theme.surfaceElevated
    m.codeLabel = m.top.findNode("codeLabel")
    ' Stays at 104. The code is shown spaced out, so a six-character code is
    ' eleven glyphs = 686px at 104 mono, inside the 760px box. (The store
    ' edition's smaller copy of this on OnboardScreen had to drop two sizes;
    ' this one has the room.)
    m.codeLabel.font = UiBoldFont(104)
    m.codeLabel.color = m.theme.textPrimary

    m.expiryLabel = m.top.findNode("expiryLabel")
    m.expiryLabel.font = linkFont(24)
    m.expiryLabel.color = m.theme.textSecondary

    m.statusLabel = m.top.findNode("statusLabel")
    m.statusLabel.font = linkFont(28)

    m.qrCaption = m.top.findNode("qrCaption")
    m.qrCaption.text = "Scan this QR code with a phone camera"
    m.qrCaption.font = linkFont(24)
    m.qrCaption.color = m.theme.textSecondary
    ' Stays pure white whatever the palette does — it is the quiet zone a
    ' phone camera needs, not a surface.
    m.top.findNode("qrPlate").color = "0xFFFFFFFF"

    buildButtons()

    m.focus = 0

    ' The pairing conversation. Everything on screen below the title is one
    ' of its fields.
    m.session = m.top.findNode("session")
    m.session.observeField("codeText", "onSessionCode")
    m.session.observeField("qr", "onSessionQr")
    m.session.observeField("expiresText", "onSessionExpiry")
    m.session.observeField("statusText", "onSessionStatus")
    m.session.observeField("addedLines", "onSessionAdded")
    m.session.observeField("state", "onSessionState")
    ' No idleRetry here: this screen has a Try Again button, so a member who
    ' is looking at it decides when to have another go.
    m.session.active = true

    redraw()
end sub

function linkFont(sizePx as integer) as object
    return UiFont(sizePx)
end function

sub buildButtons()
    grp = m.top.findNode("buttons")
    m.buttons = []
    x = 0
    for i = 0 to 1
        wrap = grp.createChild("Group")
        wrap.translation = [x, 0]
        ring = wrap.createChild("Rectangle")
        ring.width = 348
        ring.height = 80
        ring.translation = [-4, -4]
        bg = wrap.createChild("Rectangle")
        bg.width = 340
        bg.height = 72
        lbl = wrap.createChild("Label")
        lbl.width = 340
        lbl.height = 72
        lbl.horizAlign = "center"
        lbl.vertAlign = "center"
        lbl.font = UiBoldFont(28)
        m.buttons.push({ wrap: wrap, ring: ring, bg: bg, lbl: lbl })
        x = x + 380
    end for
    m.buttonKinds = ["done"]
end sub

' ---- What the session says --------------------------------------------------

sub onSessionCode()
    m.codeLabel.text = ToStr(m.session.codeText)
    redraw()
end sub

sub onSessionQr()
    hasQr = DrawQrModules(m.top.findNode("qrGrid"), m.session.qr, 12)
    m.top.findNode("qrPlate").visible = hasQr
    m.qrCaption.visible = hasQr
end sub

sub onSessionExpiry()
    m.expiryLabel.text = ToStr(m.session.expiresText)
end sub

sub onSessionStatus()
    m.statusLabel.text = ToStr(m.session.statusText)
    paintStatus()
end sub

sub onSessionState()
    paintStatus()
    redraw()
end sub

' The colour says which of the three it is without reading a word: something
' has gone wrong, something has arrived, or we're still waiting.
sub paintStatus()
    if ToStr(m.session.state) = "failed"
        m.statusLabel.color = m.theme.errorColor
    else if m.session.addedCount > 0
        m.statusLabel.color = m.theme.textPrimary
    else
        m.statusLabel.color = m.theme.textSecondary
    end if
end sub

sub onSessionAdded()
    grp = m.top.findNode("addedGroup")
    while grp.getChildCount() > 0
        grp.removeChildIndex(0)
    end while
    added = m.session.addedLines
    if added = invalid then return
    first = 0
    if added.count() > 5 then first = added.count() - 5
    y = 0
    for i = first to added.count() - 1
        lbl = grp.createChild("Label")
        lbl.width = 1000
        lbl.font = linkFont(26)
        lbl.color = m.theme.accentAlt
        lbl.text = ToStr(added[i])
        lbl.translation = [0, y]
        y = y + 40
    end for
end sub

' ---- Drawing ----------------------------------------------------------------

sub redraw()
    hasCode = (ToStr(m.session.code) <> "")
    m.codeBg.visible = hasCode
    m.codeLabel.visible = hasCode
    m.step2.visible = hasCode
    m.expiryLabel.visible = hasCode

    if ToStr(m.session.state) = "failed"
        m.buttonKinds = ["retry", "done"]
        m.buttons[0].lbl.text = "Try Again"
        m.buttons[1].lbl.text = "Done"
        m.buttons[1].wrap.visible = true
    else
        m.buttonKinds = ["done"]
        m.buttons[0].lbl.text = "Done"
        m.buttons[1].wrap.visible = false
    end if
    if m.focus > m.buttonKinds.count() - 1 then m.focus = m.buttonKinds.count() - 1

    for i = 0 to m.buttons.count() - 1
        b = m.buttons[i]
        b.ring.color = m.theme.focusHighlight
        b.ring.visible = (b.wrap.visible and m.focus = i)
        if i = 0
            b.bg.color = m.theme.accent
            ' The palette accent is a LIGHT frost blue now, so white on it
            ' is 1.9:1 and unreadable from a sofa. Dark text on the light
            ' fill is 6:1.
            b.lbl.color = m.theme.background
        else
            b.bg.color = m.theme.surfaceElevated
            b.lbl.color = m.theme.textPrimary
        end if
    end for
end sub

' ---- Keys -------------------------------------------------------------------

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back"
        closeScreen()
        return true
    else if key = "left" or key = "right"
        if m.buttonKinds.count() > 1
            if key = "right" then m.focus = 1 else m.focus = 0
            redraw()
        end if
        return true
    else if key = "OK"
        if m.buttonKinds[m.focus] = "retry"
            m.session.retryNow = true
        else
            closeScreen()
        end if
        return true
    end if
    return false
end function

' Leaving takes everything with it: no timer left ticking, no request left
' in the air, and nothing still polling the service in the background.
sub closeScreen()
    m.session.active = false
    m.top.closed = true
end sub
