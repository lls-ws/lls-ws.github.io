' The first screen. Two layouts, one per edition — see OnboardScreen.xml.
'
' SIDELOAD ("Connect Your Provider"): focus order and copy mirror the
' Android screen — segment row -> (KwickTV members card is informational) ->
' fields -> Sign In / Add Source -> "Don't have an account? Get KwickTV".
' Members are running this today; it is untouched.
'
' STORE (the split screen): no tabs and nowhere to navigate to. Sign in with
' KwickTV on the left, the kwickplayer.tv/link code and its QR on the right,
' a USB playlist underneath. The pairing half is read-only — nothing in it
' takes focus — so the D-pad is a single column down the left: username,
' password, Sign In, USB.
'
' Everything below the layouts is shared: one keyboard, one sign-in, one
' playlist check, one way of finishing.

sub init()
    m.theme = KwickTheme()
    m.branding = KwickBranding()

    ' Which layout. The store edition is the one that can't take a typed web
    ' address (Distribution Agreement §10.3(a)), which is exactly why it
    ' needs the pairing code on the first screen.
    m.split = not AllowWebAddressEntry()

    ' Form state, shared by both layouts.
    m.segment = 0        ' the tab index — segmentKind() says what it means
    m.values = { name: "", server: "", username: "", password: "", m3uUrl: "", epgUrl: "" }
    m.busy = false

    ' Focus slots: 0..2 segments, 10+i fields, 90 submit, 91 sign-up link,
    ' 93 "load from USB" (split layout only)
    m.focus = 0
    m.fieldNodes = []
    m.kbDialog = invalid
    m.usbBrowser = invalid
    m.session = invalid
    m.pendingArrival = false
    m.arrivedCount = 0
    m.arrivedWasRestore = false

    ' DID THE MEMBER JUST CLEAR THIS TELEVISION? Read once and put straight
    ' back, HERE, before either layout is built and whatever this build is,
    ' so it covers exactly one arrival at this screen and cannot be left
    ' lying around for the next one.
    '
    ' Why it has to exist at all: a cleared box and a reinstalled box are the
    ' same box from the outside — no sources, cursor at zero, same device id
    ' — and the silent restore below is right for one and wrong for the
    ' other. The clean slate is the only thing that knows which happened, so
    ' it says so on its way past (clearEverySource in
    ' SettingsCategoryScreen.brs) and this is where it is heard.
    m.skipRestore = (m.global <> invalid and m.global.linkJustCleared = true)
    if m.skipRestore then m.global.linkJustCleared = false

    if m.split
        m.top.findNode("classicRoot").visible = false
        initSplit()
        return
    end if
    initClassic()
end sub

' ---- Sideload layout: Connect Your Provider ---------------------------------

sub initClassic()
    title = m.top.findNode("title")
    title.text = "Connect Your Provider"
    title.font = UiBoldFont(48)
    title.color = m.theme.textPrimary

    subtitle = m.top.findNode("subtitle")
    subtitle.text = "Sign in with KwickTV, or add any Xtream Codes or M3U provider."
    subtitle.font = UiFont(25)
    subtitle.color = m.theme.textSecondary

    ' --- Segment row: KwickTV first + default, same as Android ---
    m.segmentNames = ["KwickTV", "Xtream Codes", "M3U Playlist"]
    m.segments = []
    segGroup = m.top.findNode("segments")
    x = 0
    for i = 0 to m.segmentNames.count() - 1
        wrap = segGroup.createChild("Group")
        wrap.translation = [x, 0]
        ring = wrap.createChild("Rectangle")
        ring.width = 268
        ring.height = 68
        ring.translation = [-4, -4]
        bg = wrap.createChild("Rectangle")
        bg.width = 260
        bg.height = 60
        lbl = wrap.createChild("Label")
        lbl.width = 260
        lbl.height = 60
        lbl.horizAlign = "center"
        lbl.vertAlign = "center"
        ' Longest segment name is 12 chars = 173px at 24 mono, in a 260px
        ' button. No change needed.
        lbl.font = UiFont(24)
        lbl.text = m.segmentNames[i]
        m.segments.push({ ring: ring, bg: bg, lbl: lbl })
        x = x + 280
    end for

    ' --- KwickTV members card (accent tint, verified copy) ---
    ' THE CARD GREW, and only because of the type. Its second line is 68
    ' characters; in Roboto at 22 that was 748px and sat inside the 880px
    ' card, in JetBrains Mono at 22 it is 898px and hangs 100px out over the
    ' page. The line drops to 20 (816px) AND the card widens to 924, which
    ' is free here — it is a decorative panel with 320px of clear page on
    ' either side, and it stays centred on x=960 as it always was.
    wrapNode = m.top.findNode("memberCard")
    wrapNode.translation = [498, 300]
    card = m.top.findNode("cardBg")
    card.width = 924
    ' The palette accent at the same ~20% the Android tinted card uses.
    ' Derived rather than written out so it follows the palette.
    accentRgb = m.theme.accent
    card.color = accentRgb.left(8) + "33"
    cardIcon = m.top.findNode("cardIcon")
    cardIcon.font = IconFont(44)
    cardIcon.text = m.theme.iconStar
    cardIcon.color = m.theme.accent
    cardText = m.top.findNode("cardText")
    cardText.text = "KwickTV members: fastest way in."
    cardText.font = UiBoldFont(26)
    cardText.color = m.theme.textPrimary
    cardText2 = m.top.findNode("cardText2")
    cardText2.text = "Just your username and password — everything else is set up for you."
    cardText2.font = UiFont(20)
    cardText2.color = m.theme.textSecondary

    ' --- Submit + link + status ---
    m.submitBg = m.top.findNode("submitBg")
    m.submitRing = m.top.findNode("submitRing")
    m.submitLabel = m.top.findNode("submitLabel")
    m.submitLabel.font = UiBoldFont(28)

    m.linkLabel = m.top.findNode("linkLabel")
    ' "Don't have an account?  Get KwickTV" is 35 chars = 504px at 24 mono,
    ' inside the 620px box.
    m.linkLabel.font = UiFont(24)

    m.statusLabel = m.top.findNode("statusLabel")
    ' 620px wide, no wrap, so the longer error sentences are clipped. That
    ' was already true in Roboto (the longest is 62 chars = 744px there) and
    ' the mono switch makes it worse, not new. Not fixable by two points —
    ' see the report; it wants a wider or wrapping box, which is a layout
    ' decision rather than a type one.
    m.statusLabel.font = UiFont(24)
    m.statusLabel.color = m.theme.errorColor
    m.statusLabel.text = ""

    rebuildFields()
    redraw()
end sub

' What the segment under the cursor actually IS.
function segmentKind() as string
    if m.segment = 0 then return "kwicktv"
    if m.segment = 1 then return "xtream"
    return "m3u"
end function

' Field list per segment — matches the Android form exactly (KwickTV shows
' only username/password; Xtream adds name+server; M3U is name+urls).
function fieldDefs() as object
    kind = segmentKind()
    if kind = "kwicktv"
        return [
            { key: "username", label: "Username" },
            { key: "password", label: "Password", secure: true }
        ]
    else if kind = "xtream"
        return [
            { key: "name", label: "Source name" },
            { key: "server", label: "Server URL (http://host:port)" },
            { key: "username", label: "Username" },
            { key: "password", label: "Password", secure: true }
        ]
    end if
    ' The USB row is an action, not a value — Roku gives apps the filesystem
    ' but no file picker, so choosing a file opens our own browser and writes
    ' the path straight into m3uUrl above.
    return [
        { key: "name", label: "Source name" },
        { key: "m3uUrl", label: "Playlist URL (.m3u / .m3u8)" },
        { key: "browseUsb", label: "...or choose a playlist on a USB drive", browse: true },
        { key: "epgUrl", label: "EPG URL (optional)" }
    ]
end function

sub rebuildFields()
    fieldsGroup = m.top.findNode("fields")
    while fieldsGroup.getChildCount() > 0
        fieldsGroup.removeChildIndex(0)
    end while
    m.fieldNodes = []

    defs = fieldDefs()
    y = 0
    for each def in defs
        f = fieldsGroup.createChild("FormField")
        f.label = def.label
        f.value = m.values[def.key]
        if def.secure = true then f.secure = true
        f.translation = [0, y]
        m.fieldNodes.push({ node: f, def: def })
        y = y + 112
    end for

    ' The members card only shows on the KwickTV tab, like Android.
    ' The whole column is centered on screen (fields are 620 wide).
    m.top.findNode("memberCard").visible = (m.segment = 0)
    if m.segment = 0
        fieldsGroup.translation = [650, 430]
    else
        fieldsGroup.translation = [650, 320]
    end if

    baseY = fieldsGroup.translation[1] + y + 24
    m.top.findNode("submitWrap").translation = [650, baseY]
    m.linkLabel.translation = [650, baseY + 104]
    m.statusLabel.translation = [650, baseY + 160]

    if m.segment = 0
        m.submitLabel.text = "Sign In"
        m.linkLabel.text = "Don't have an account?  Get KwickTV"
        m.linkLabel.visible = ShowStorefront()
    else
        m.submitLabel.text = "Add Source"
        m.linkLabel.visible = false
    end if
end sub

sub selectSegment(idx as integer)
    if m.segment <> idx
        m.segment = idx
        m.statusLabel.text = ""
        rebuildFields()
    end if
    redraw()
end sub

' ---- Store layout: the split screen -----------------------------------------
' Left half signs in, right half pairs, USB underneath. The right half is
' read-only on purpose: a pairing code and a QR square are things to look
' at, and making them focusable would put a stop on the D-pad that does
' nothing when pressed.

sub initSplit()
    m.top.findNode("splitRoot").visible = true

    setLabel("sTitle", "Welcome to " + m.branding.appName, 42, m.theme.textPrimary)
    setLabel("sSub", "Sign in with KwickTV on the left, or add an Xtream or M3U source on the right.", 24, m.theme.textSecondary)

    ' ELEVATION RULE FOR THIS SCREEN, and the reason the fields were once
    ' invisible: FormField paints its own box with m.theme.surface and takes
    ' no colour from the caller. So nothing that CONTAINS a FormField may be
    ' surface as well, or the field's fill lands on an identical fill and
    ' all a member sees is the label and (when focused) a bare orange ring.
    ' The two panels are therefore the raised tone and everything set INTO
    ' them — the fields, the code box, the disabled Sign In button — is the
    ' recessed one. Anything added inside these panels later must be surface
    ' or darker, never surfaceElevated.
    m.top.findNode("sLeftBg").color = m.theme.surfaceElevated
    m.top.findNode("sRightBg").color = m.theme.surfaceElevated

    ' LEFT — the on-device sign-in Roku certification 2.2 asks for.
    setLabel("sLeftHead", "Sign in with KwickTV", 30, m.theme.textPrimary)
    ' Broken by hand at the full stop rather than left to the wrap: at this
    ' width the automatic break lands mid-sentence ("...Everything else / is
    ' set up for you."), and where it lands would move again the moment the
    ' copy, the font size or the panel width changed. Two sentences, two
    ' lines, and the label is numLines="2" so that is exactly what shows.
    setLabel("sLeftSub", "Your KwickTV username and password." + Chr(10) + "Everything else is set up for you.", 22, m.theme.textSecondary)

    m.submitRing = m.top.findNode("sSubmitRing")
    m.submitBg = m.top.findNode("sSubmitBg")
    m.submitLabel = m.top.findNode("sSubmitLabel")
    m.submitLabel.font = UiBoldFont(28)
    m.submitLabel.text = "Sign In"

    m.statusLabel = m.top.findNode("sStatus")
    m.statusLabel.font = splitFont(22)
    m.statusLabel.color = m.theme.errorColor
    m.statusLabel.text = ""

    ' RIGHT — the same words the full-screen Add a source uses, so a
    ' member who sees both screens is told the same thing twice.
    setLabel("sRightHead", "Add a source", 30, m.theme.textPrimary)
    setLabel("sStep1", "In a web browser, go to:", 22, m.theme.textSecondary)
    setLabel("sUrl", "kwickplayer.tv/link", 30, m.theme.accentAlt)
    setLabel("sStep2", "Then enter this code:", 22, m.theme.textSecondary)
    ' Recessed into the panel, same as the fields opposite it.
    m.top.findNode("sCodeBg").color = m.theme.surface
    m.codeLabel = m.top.findNode("sCode")
    ' 60 -> 54. The code is shown spaced out ("A B C D E F"), so a six-
    ' character code is eleven glyphs: 396px at 60 mono in a 375px box, i.e.
    ' clipped. 54 puts it at 356px. The box cannot grow — the QR plate
    ' starts 24px to its right.
    m.codeLabel.font = UiBoldFont(54)
    m.codeLabel.color = m.theme.textPrimary
    m.expiryLabel = m.top.findNode("sExpiry")
    ' 20 -> 18. "This code works for another 09:58" is 33 chars = 396px at
    ' 20 mono in the same 375px column; 18 puts it at 356px.
    m.expiryLabel.font = UiFont(18)
    m.expiryLabel.color = m.theme.textSecondary
    m.rightStatus = m.top.findNode("sRightStatus")
    m.rightStatus.font = splitFont(20)
    m.rightStatus.color = m.theme.textSecondary
    ' Stays pure white whatever the palette does — it is the quiet zone a
    ' phone camera needs, not a surface.
    m.top.findNode("sQrPlate").color = "0xFFFFFFFF"
    ' 20 -> 18. The caption is 37 chars = 444px at 20 mono in a 407px plate;
    ' 18 puts it at 400px. It has no wrap, so it would have clipped.
    setLabel("sQrCaption", "Scan this QR code with a phone camera", 18, m.theme.textSecondary)

    ' UNDERNEATH — the third way in, in the owner's own words.
    m.usbRing = m.top.findNode("sUsbRing")
    m.usbBg = m.top.findNode("sUsbBg")
    m.usbLabel = m.top.findNode("sUsbLabel")
    m.usbLabel.font = splitFont(24)
    m.usbLabel.text = "Or load a playlist from a USB drive"

    rebuildSplitFields()
    ' Straight onto the username: the first thing anybody does here.
    m.focus = 10
    redraw()

    ' Did this box already have sources when the screen opened? Only a box
    ' that had none gets taken straight in when its old ones come back —
    ' see onLinkArrived().
    m.hadProviders = (LoadProviders().count() > 0)

    ' Roku's Request For Information, ONCE per box. Certification RP 2.1 /
    ' 4.1 / 2.2 require an app with a sign-in to ask - through Roku's own
    ' dialog - whether it may pre-fill the member's Roku account email, and
    ' static analysis refused the first store package until it did. A KwickTV
    ' username is rarely an email, so most members will just type over it;
    ' the point is that they were asked. Never asked twice: the answer is
    ' remembered whether it was yes or no.
    ' NOT ON THE FIRST-RUN SCREEN, and that is the whole point. This is a Task,
    ' so Roku's dialog appears whenever the task gets round to it - a moving
    ' target. App Behavior Analysis drives THIS screen with a fixed key script
    ' on a fresh box, and a dialog that lands at an unpredictable moment throws
    ' every following keypress out by one: on 2026-09-03 the sign-in script
    ' completed, no account was saved, and all five middle tests then ran
    ' against the Welcome screen and failed.
    '
    ' A fresh box has no providers; adding a KwickTV account from Settings has
    ' some. Gating on that keeps the RFI call on a real sign-in path (which is
    ' what certification asks for) and keeps it off the one path a robot drives.
    if m.hadProviders and RegRead("rfi_asked") <> "1" and m.values.username = ""
        RegWrite("rfi_asked", "1")
        m.rfiTask = CreateObject("roSGNode", "RfiTask")   ' keep a ref so it isn't collected mid-flight
        m.rfiTask.observeField("result", "onRfiDone")
        m.rfiTask.control = "RUN"
    end if

    ' The pairing conversation, started AFTER everything above is drawn. The
    ' screen is already usable at this point and stays usable whatever the
    ' service does: a claim that never answers leaves one calm line in the
    ' right half and touches nothing else.
    m.session = m.top.findNode("session")
    m.session.observeField("codeText", "onLinkCode")
    m.session.observeField("qr", "onLinkQr")
    m.session.observeField("expiresText", "onLinkExpiry")
    m.session.observeField("statusCode", "onLinkStatus")
    m.session.observeField("state", "onLinkState")
    m.session.observeField("arrived", "onLinkArrived")
    ' No Try Again button on this screen — there is nothing on the right half
    ' to press — so the session retries by itself, slowly.
    m.session.idleRetry = true
    ' Straight after a clean slate, and on that one visit only: pair exactly
    ' as always — same code, same square, same everything works if the member
    ' uses it — but do not hand this television back the playlists it was
    ' just cleared of. Set BEFORE active, which is what starts the session.
    ' See the skip note in LinkSession.brs.
    m.session.skipRestore = m.skipRestore
    m.session.active = true
end sub

function splitFont(sizePx as integer) as object
    return UiFont(sizePx)
end function

' The split screen's three headings are the bold face; everything else on it
' is the regular one.
function isSplitHeading(id as string) as boolean
    return (id = "sTitle" or id = "sLeftHead" or id = "sRightHead" or id = "sUrl")
end function

sub setLabel(id as string, text as string, sizePx as integer, color as string)
    lbl = m.top.findNode(id)
    if isSplitHeading(id)
        lbl.font = UiBoldFont(sizePx)
    else
        lbl.font = UiFont(sizePx)
    end if
    lbl.color = color
    lbl.text = text
end sub

sub rebuildSplitFields()
    fieldsGroup = m.top.findNode("sFields")
    m.fieldNodes = []
    defs = [
        { key: "username", label: "Username" },
        { key: "password", label: "Password", secure: true }
    ]
    y = 0
    for each def in defs
        f = fieldsGroup.createChild("FormField")
        f.fieldWidth = 556
        f.label = def.label
        f.value = m.values[def.key]
        if def.secure = true then f.secure = true
        f.translation = [0, y]
        m.fieldNodes.push({ node: f, def: def })
        y = y + 112
    end for
end sub

sub redrawSplit()
    for i = 0 to m.fieldNodes.count() - 1
        m.fieldNodes[i].node.focused = (m.focus = 10 + i)
    end for

    m.submitRing.visible = (m.focus = 90)
    m.submitRing.color = m.theme.focusHighlight
    ' No spinner in this layout — the button itself says what is happening,
    ' right where the member just pressed.
    if m.busy
        ' Recessed, not raised — raised is the panel's own tone and the
        ' button would disappear into it for as long as the sign-in ran.
        m.submitBg.color = m.theme.surface
        m.submitLabel.text = "Signing in..."
        m.submitLabel.color = m.theme.textPrimary
    else
        m.submitBg.color = m.theme.accent
        m.submitLabel.text = "Sign In"
        ' The palette accent is a LIGHT frost blue now. White on it is
        ' 1.9:1 and unreadable from a sofa, so the button takes dark text
        ' on a light fill (6:1) instead of the old white-on-blue.
        m.submitLabel.color = m.theme.background
    end if

    m.usbRing.visible = (m.focus = 93)
    m.usbRing.color = m.theme.focusHighlight
    ' Raised, and correctly so: this row sits on the scene background out
    ' from under both panels, so it is not nested in anything.
    m.usbBg.color = m.theme.surfaceElevated
    m.usbLabel.color = m.theme.textPrimary
end sub

' ---- What the pairing session says (store layout) ---------------------------

sub onLinkCode()
    m.codeLabel.text = ToStr(m.session.codeText)
    redrawSplitLink()
end sub

sub onLinkQr()
    hasQr = DrawQrModules(m.top.findNode("sQrGrid"), m.session.qr, 11)
    m.top.findNode("sQrPlate").visible = hasQr
    m.top.findNode("sQrCaption").visible = hasQr
end sub

sub onLinkExpiry()
    m.expiryLabel.text = ToStr(m.session.expiresText)
end sub

sub onLinkState()
    redrawSplitLink()
end sub

' This screen writes its own copy rather than using the session's, because
' the full-screen version can afford whole sentences and this column is 375
' pixels wide. Short, calm, and never a code or a number a member can't do
' anything with.
sub onLinkStatus(event as object)
    what = ToStr(event.getData())
    if what = "claiming"
        m.rightStatus.color = m.theme.textSecondary
        m.rightStatus.text = "Getting your code..."
    else if what = "waiting"
        ' Anything that has landed gets counted out loud right here, the way
        ' the full-screen version lists them — the dialog that follows is
        ' the way onward, not the only place it is said.
        landed = m.session.addedCount
        if landed = 1
            m.rightStatus.color = m.theme.accentAlt
            m.rightStatus.text = "Your playlist has been added to " + m.branding.appName + "."
        else if landed > 1
            m.rightStatus.color = m.theme.accentAlt
            m.rightStatus.text = "Your " + landed.toStr() + " playlists have been added to " + m.branding.appName + "."
        else
            m.rightStatus.color = m.theme.textSecondary
            m.rightStatus.text = "Anything you add there turns up here on its own."
        end if
    else if what = "expired"
        m.rightStatus.color = m.theme.textSecondary
        m.rightStatus.text = "Getting you a new code..."
    else if what = "down"
        ' The one thing worth saying: the other half of the screen still
        ' works. Not an error colour — nothing the member did is wrong.
        m.rightStatus.color = m.theme.textSecondary
        m.rightStatus.text = "Can't reach kwickplayer.tv just now. You can still sign in on the left."
    end if
    ' "retrying" says nothing at all. A blip that fixes itself four seconds
    ' later is not worth a message, and the line it would replace is the one
    ' telling them what the code is for.
end sub

sub redrawSplitLink()
    hasCode = (ToStr(m.session.code) <> "")
    m.top.findNode("sCodeBg").visible = hasCode
    m.top.findNode("sCode").visible = hasCode
    m.top.findNode("sStep2").visible = hasCode
    m.top.findNode("sExpiry").visible = hasCode
    ' Sending somebody to an address we've just said we can't reach is worse
    ' than saying nothing, so when the service is down and there is no code,
    ' the address goes away and only the calm line is left.
    showAddr = hasCode or ToStr(m.session.state) <> "failed"
    m.top.findNode("sStep1").visible = showAddr
    m.top.findNode("sUrl").visible = showAddr
end sub

' A source landed. Two quite different things look identical from here, and
' the session tells them apart with "first":
'
'   first = true   this is the very first answer since the screen opened, so
'                  whatever came back is what this box ALREADY had. A box
'                  that has just been reinstalled looks exactly like a new
'                  one — the registry is wiped — but the link device id is
'                  worked out from something that survives an uninstall, so
'                  the service still knows this Roku. Nobody asked for this
'                  and nobody should have to acknowledge it: if they haven't
'                  started typing, take them straight in.
'
'   first = false  the member added one on the website a moment ago while
'                  looking at this screen. That is a thing they did, so it
'                  gets said out loud and they press Continue.
'
' ONE VISIT NEVER GETS THE FIRST KIND AT ALL: the one straight after the
' member cleared this television. There the session is told not to take those
' back (m.session.skipRestore above), so nothing lands, nothing is announced,
' and this is never called for them — a cleared TV stays cleared and the
' member chooses what happens next. The second kind still arrives normally on
' that visit, because adding a playlist on the website is something they did.
sub onLinkArrived(event as object)
    info = event.getData()
    if info = invalid then return
    landed = ToInt(GetField(info, "count"))
    if landed <= 0 then return

    wasRestore = (GetField(info, "first") = true)
    quiet = (not m.busy) and m.kbDialog = invalid and m.values.username = "" and m.values.password = ""
    if wasRestore and not m.hadProviders and quiet
        KLog("link", "restored " + landed.toStr() + " source(s) for this device")
        finishOnboarding()
        return
    end if

    if wasRestore then m.arrivedWasRestore = true
    m.arrivedCount = m.arrivedCount + landed
    ' Never two dialogs at once: if they're in the keyboard or a sign-in is
    ' in the air, this waits its turn (onKeyboardClosed / onKeyEvent).
    if m.busy or m.kbDialog <> invalid
        m.pendingArrival = true
        return
    end if
    showArrivedDialog()
end sub

sub showArrivedDialog()
    m.pendingArrival = false
    dialog = CreateObject("roSGNode", "Dialog")
    ' Sources that came back on their own are not something the member just
    ' did, so they don't get told "added" for something they didn't add.
    if m.arrivedWasRestore
        dialog.title = "Your sources are back"
    else
        dialog.title = "Source added"
    end if
    ' Named for the thing the member actually added on the website — a
    ' playlist — and for the app it landed in, rather than "your source is on
    ' this TV now", which said nothing they could picture. The same sentence
    ' is used on the full-screen Add a source screen (LinkSession's
    ' showWaitingStatus), so both pairing screens say the one thing.
    if m.arrivedCount = 1
        dialog.message = "Your playlist has been added to " + m.branding.appName + "."
    else
        dialog.message = "Your " + m.arrivedCount.toStr() + " playlists have been added to " + m.branding.appName + "."
    end if
    dialog.buttons = ["Continue"]
    ' House rule: the primary action starts focused.
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onArrivedDialog")
    m.top.getScene().dialog = dialog
end sub

sub onArrivedDialog()
    m.top.getScene().dialog.close = true
    finishOnboarding()
end sub

' ---- Focus movement --------------------------------------------------------

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if m.busy then return true

    ' A source arrived while the member was busy elsewhere — say so before
    ' anything else happens.
    if m.pendingArrival = true and m.kbDialog = invalid
        showArrivedDialog()
        return true
    end if

    ' When this screen was opened from Settings to add ANOTHER source,
    ' Back returns to the shell instead of exiting the app.
    '
    ' THIS TEST COMES FIRST AND MUST STAY FIRST. It is what stops the ladder
    ' below from ever being reached once a source exists: the moment anything
    ' is saved this screen has a real screen behind it, so it stops being a
    ' special case and Back simply leaves.
    if key = "back"
        if LoadProviders().count() > 0
            finishOnboarding()
            return true
        end if
        return onboardBack()
    end if

    if key = "down"
        moveDown()
        return true
    else if key = "up"
        moveUp()
        return true
    else if key = "left" or key = "right"
        if m.split
            ' Nothing in the right half is focusable — the code and the
            ' square are there to be read — so Left and Right have nowhere
            ' sensible to go, and doing nothing beats stranding focus on a
            ' label the member then has to escape from.
            return false
        end if
        if m.focus <= 2
            delta = 1
            if key = "left" then delta = -1
            idx = m.focus + delta
            if idx >= 0 and idx <= m.segments.count() - 1
                m.focus = idx
                selectSegment(idx)
            end if
            return true
        end if
        return false
    else if key = "OK"
        activate()
        return true
    end if
    return false
end function

' ---- Back on the FIRST-RUN screen, where nothing is saved yet --------------
' Roku certification 4.6: Back must return the member to the previous screen
' or state, and must never be the thing that closes the app. This screen used
' to `return false` here, which handed Back to the firmware and exited — the
' exact behaviour 4.6 forbids.
'
' It is not a one-line fix, because Back needs somewhere to GO. This screen
' has real state to unwind, and the hierarchy is not invented for this
' function: it is the one moveUp() below already uses, where the first field
' (focus 10) moves up to the segment row. So Back walks the same ladder,
' a whole step at a time instead of a row at a time:
'
'   1. anywhere in the form, on Sign In, or on the sign-up link
'                                      -> back to the segment row
'      (store layout: back to the first field, which is its top)
'   2. on the segment row, off the KwickTV tab
'                                      -> back to the KwickTV tab, where the
'                                         screen opened
'   3. on the segment row, on the KwickTV tab
'                                      -> nothing behind it. Swallow.
'
' >>> STEP 3 IS DELIBERATE. DO NOT TURN IT BACK INTO `return false`. <<<
' It looks like a dead end and it is not a mistake. With no providers saved
' there is genuinely no previous screen to return to — the shell cannot draw
' Home without a source — so this is the case certification 4.6 simply does
' not provide an exit for, and swallowing is the only answer that does not
' re-break it. The member is NOT trapped: the physical Home button on every
' Roku remote is handled by the firmware, never reaches this app, and always
' leaves it. What they lose is closing the app with Back, which is precisely
' what 4.6 says they should not be able to do.
'
' Always returns true: once this is reached, Back is ours and never the
' firmware's.
function onboardBack() as boolean
    if m.split
        ' No segment row over here — the fields are the top of the screen.
        if m.focus <> 10
            m.focus = 10
            redraw()
        end if
        return true
    end if

    if m.focus >= 10
        ' Step 1. Back to the segment row, on whichever tab is open.
        m.focus = m.segment
        redraw()
        return true
    end if

    if m.segment <> 0
        ' Step 2. Back to the tab the screen opened on. selectSegment()
        ' rebuilds the fields and redraws, so nothing else is needed.
        m.focus = 0
        selectSegment(0)
        return true
    end if

    ' Step 3. Swallow — see the note above.
    return true
end function

sub moveDown()
    if m.split
        if m.focus >= 10 and m.focus < 10 + m.fieldNodes.count() - 1
            m.focus = m.focus + 1
        else if m.focus = 10 + m.fieldNodes.count() - 1
            m.focus = 90
        else if m.focus = 90
            m.focus = 93
        end if
        redraw()
        return
    end if
    if m.focus <= 2
        m.focus = 10
    else if m.focus >= 10 and m.focus < 10 + m.fieldNodes.count() - 1
        m.focus = m.focus + 1
    else if m.focus = 10 + m.fieldNodes.count() - 1
        m.focus = 90
    else if m.focus = 90 and m.segment = 0 and ShowStorefront()
        ' Don't stop on the sign-up link when it isn't there — focus would
        ' land on an invisible row and Down would dead-end.
        m.focus = 91
    end if
    redraw()
end sub

sub moveUp()
    if m.split
        if m.focus = 93
            m.focus = 90
        else if m.focus = 90
            m.focus = 10 + m.fieldNodes.count() - 1
        else if m.focus > 10
            m.focus = m.focus - 1
        end if
        redraw()
        return
    end if
    if m.focus = 91
        m.focus = 90
    else if m.focus = 90
        m.focus = 10 + m.fieldNodes.count() - 1
    else if m.focus > 10
        m.focus = m.focus - 1
    else if m.focus = 10
        m.focus = m.segment
    end if
    redraw()
end sub

sub redraw()
    if m.split
        redrawSplit()
        return
    end if

    ' Segments
    for i = 0 to m.segments.count() - 1
        s = m.segments[i]
        s.ring.visible = (m.focus = i)
        s.ring.color = m.theme.focusHighlight
        if i = m.segment
            s.bg.color = m.theme.accent
            ' Dark on the light frost fill — see the note in redrawSplit().
            s.lbl.color = m.theme.background
        else
            s.bg.color = m.theme.surface
            s.lbl.color = m.theme.textSecondary
        end if
    end for

    ' Fields
    for i = 0 to m.fieldNodes.count() - 1
        m.fieldNodes[i].node.focused = (m.focus = 10 + i)
    end for

    ' Submit
    m.submitRing.visible = (m.focus = 90)
    m.submitRing.color = m.theme.focusHighlight
    if m.busy
        m.submitBg.color = m.theme.surfaceElevated
        m.submitLabel.color = m.theme.textPrimary
    else
        m.submitBg.color = m.theme.accent
        ' Dark on the light frost fill — see the note in redrawSplit().
        m.submitLabel.color = m.theme.background
    end if

    ' Link
    if m.focus = 91
        m.linkLabel.color = m.theme.focusHighlight
    else
        m.linkLabel.color = m.theme.accentAlt
    end if
end sub

sub activate()
    if m.split
        if m.focus >= 10 and m.focus < 90
            openKeyboard(m.focus - 10)
        else if m.focus = 90
            submitCredentials()
        else if m.focus = 93
            openUsbBrowser()
        end if
        return
    end if
    if m.focus <= 2
        selectSegment(m.focus)
    else if m.focus >= 10 and m.focus < 90
        openKeyboard(m.focus - 10)
    else if m.focus = 90
        submit()
    else if m.focus = 91
        showSignupDialog()
    end if
end sub

' ---- Finishing --------------------------------------------------------------
' One way out, and it always stops the pairing session first — AppScene
' throws this screen away the moment `done` is set, and a screen that is
' gone must not still be talking to the link service.

sub finishOnboarding()
    if m.session <> invalid then m.session.active = false
    m.top.done = true
end sub

' ---- Keyboard entry (click-to-edit) ----------------------------------------
' This is the sign-in form, so certification 4.12 applies here: "Apps must
' use Roku voice keyboards for email, PIN, and password entry." Every row on
' this screen goes through StandardKeyboardDialog, which is a voice keyboard
' with a microphone. One dialog for the whole form rather than a voice one
' for the password and the old one for everything else — a member typing a
' server URL should not get a different keyboard from the one they just used
' for their username.

' Which kind of thing is being typed. The voice keyboard uses this to pick a
' dictation style: "password" and "email" are spelled out letter by letter,
' which is the only way a spoken password can land right; the rest are heard
' as words. Roku's vocabulary is email / numeric / alphanumeric / generic /
' password and nothing else, so anything unrecognised has to fall to
' "generic".
function keyboardDomainFor(def as object) as string
    if def.secure = true then return "password"
    if def.key = "username" then return "alphanumeric"
    return "generic"
end function

sub openKeyboard(fieldIndex as integer)
    entry = m.fieldNodes[fieldIndex]
    ' The USB row isn't typed into — it opens the file browser.
    if entry.def.browse = true
        openUsbBrowser()
        return
    end if
    kb = CreateObject("roSGNode", "StandardKeyboardDialog")
    kb.title = entry.def.label
    kb.text = m.values[entry.def.key]
    kb.buttons = ["OK", "Cancel"]
    kb.keyboardDomain = keyboardDomainFor(entry.def)

    edit = kb.textEditBox
    ' Say it on the box as well as on the dialog. keyboardDomain is
    ' documented as something the keyboard "may" act on; the mic and the
    ' dictation style are not worth leaving to a "may".
    edit.voiceEnabled = true
    edit.voiceEntryType = kb.keyboardDomain
    ' Roku's boxes default to 15 characters, which would silently truncate
    ' every server URL on the screen.
    edit.maxTextLength = 255
    ' Passwords stay covered while they're typed, exactly as the row behind
    ' the dialog shows them.
    if entry.def.secure = true then edit.secureMode = true

    m.kbField = entry
    m.kbDialog = kb
    kb.observeField("buttonSelected", "onKeyboardButton")
    kb.observeField("wasClosed", "onKeyboardClosed")
    m.top.getScene().dialog = kb
end sub

sub onKeyboardButton()
    kb = m.kbDialog
    if kb = invalid then return
    if kb.buttonSelected = 0
        m.values[m.kbField.def.key] = kb.text.trim()
        m.kbField.node.value = m.values[m.kbField.def.key]
    end if
    kb.close = true
end sub

' Back closes the keyboard without going through a button, so the form has to
' take focus back here rather than in the OK branch — otherwise backing out
' of a keyboard leaves a screen that answers nothing.
sub onKeyboardClosed()
    m.kbDialog = invalid
    m.top.setFocus(true)
    redraw()
    if m.pendingArrival = true then showArrivedDialog()
end sub

' ---- Playlist from a USB drive ---------------------------------------------

sub openUsbBrowser()
    br = m.top.getScene().createChild("UsbBrowserScreen")
    br.observeField("closed", "onUsbBrowserClosed")
    br.setFocus(true)
    m.usbBrowser = br
end sub

sub onUsbBrowserClosed()
    if m.usbBrowser = invalid then return
    picked = ToStr(m.usbBrowser.chosen)
    m.top.getScene().removeChild(m.usbBrowser)
    m.usbBrowser = invalid
    m.top.setFocus(true)

    if m.split
        ' The split screen has no source-name row and no Add Source button:
        ' picking the file IS the whole thing, so it goes straight into the
        ' same check a typed playlist gets, named after the file.
        if picked = ""
            redraw()
            return
        end if
        m.values.m3uUrl = picked
        m.values.name = LocalPathLabel(picked)
        submitM3u()
        return
    end if

    if picked <> ""
        ' The path goes in the same field a URL would — everything
        ' downstream treats a playlist the same wherever it came from.
        m.values.m3uUrl = picked
        for each fn in m.fieldNodes
            if fn.def.key = "m3uUrl" then fn.node.value = picked
        end for
        ' Name the source after the file if they haven't named it yet, so
        ' they aren't forced to type anything at all.
        if m.values.name = ""
            m.values.name = LocalPathLabel(picked)
            for each fn in m.fieldNodes
                if fn.def.key = "name" then fn.node.value = m.values.name
            end for
        end if
    end if
    redraw()
end sub

' ---- Submit ----------------------------------------------------------------

sub submit()
    kind = segmentKind()
    if kind = "kwicktv" or kind = "xtream"
        submitCredentials()
        return
    end if
    submitM3u()
end sub

' KwickTV and Xtream: the same call, the same answer, different amounts of
' it typed in by hand. The split screen calls this one directly — it only
' ever signs in to KwickTV.
sub submitCredentials()
    m.statusLabel.text = ""
    server = m.branding.serverUrl
    name = "KwickTV"
    ptype = "kwicktv"
    if not m.split and segmentKind() = "xtream"
        ptype = "xtream"
        server = normalizeServer(m.values.server)
        name = m.values.name
        if name = "" then name = "Xtream Source"
        if server = ""
            showError("Enter the server URL.")
            return
        end if
    end if
    if m.values.username = "" or m.values.password = ""
        showError("Enter your username and password.")
        return
    end if
    setBusy(true, "Signing in...")
    m.pending = { ptype: ptype, name: name, server: server, username: m.values.username, password: m.values.password }
    m.task = CreateObject("roSGNode", "ApiTask")
    m.task.url = XtreamApiUrl(m.pending, "")
    ' Somebody is sitting here waiting on this one — worth the extra
    ' probe to be able to tell them what actually went wrong.
    m.task.diagnose = true
    m.task.observeField("result", "onAuthResult")
    m.task.control = "RUN"
end sub

sub submitM3u()
    m.statusLabel.text = ""
    name = m.values.name
    if name = "" then name = "M3U Source"
    if m.values.m3uUrl = ""
        if AllowWebAddressEntry()
            showError("Enter the playlist URL, or choose a file on a USB drive.")
        else
            showError("Choose a playlist file on a USB drive.")
        end if
        return
    end if
    setBusy(true, "Checking playlist...")
    m.pending = { ptype: "m3u", name: name, m3uUrl: m.values.m3uUrl, epgUrl: m.values.epgUrl }
    if IsLocalPath(m.values.m3uUrl)
        ' A file, not a web address — ApiTask only speaks HTTP, so the
        ' playlist parser (which reads both) does the checking.
        m.task = CreateObject("roSGNode", "M3uTask")
        m.task.url = m.values.m3uUrl
        m.task.observeField("result", "onLocalM3uResult")
    else
        m.task = CreateObject("roSGNode", "ApiTask")
        m.task.url = m.values.m3uUrl
        m.task.parseJson = false
        m.task.diagnose = true
        m.task.observeField("result", "onM3uResult")
    end if
    m.task.control = "RUN"
end sub

' M3uTask has already parsed it, so a channel count is proof enough.
sub onLocalM3uResult(event as object)
    res = event.getData()
    setBusy(false, "")
    if res = invalid
        showError("Something went wrong — try again.")
        return
    end if
    if res.ok <> true
        if ToStr(res.error) = "playlist file missing"
            showError("That file isn't there any more — is the drive still plugged in?")
        else
            showError("That doesn't look like an M3U playlist.")
        end if
        return
    end if
    if ToArray(res.channels).count() = 0
        showError("That playlist has no channels in it.")
        return
    end if
    finishAdd()
end sub

function normalizeServer(s as string) as string
    out = s.trim()
    if out = "" then return ""
    if LCase(Left(out, 4)) <> "http" then out = "http://" + out
    if Right(out, 1) = "/" then out = Left(out, Len(out) - 1)
    return out
end function

sub onAuthResult(event as object)
    res = event.getData()
    setBusy(false, "")
    if res = invalid
        showError("Something went wrong — try again.")
        return
    end if
    if res.ok <> true
        errText = ToStr(res.error)
        ' The kwick.cc panel answers HTTP 512 for wrong/expired/disabled
        ' logins — same message the Android app shows for it.
        if errText.instr(0, "512") > -1
            showError("Incorrect username/password, or the account is expired.")
        else
            showNetError(res, "Couldn't reach the server. " + errText)
        end if
        return
    end if
    userInfo = GetField(res.data, "user_info")
    if userInfo = invalid
        showError("The server didn't return account info.")
        return
    end if
    ' Same rule as the Android app (xtream_api_client.dart): a login is good
    ' when user_info.status is "active" — the auth flag isn't trustworthy.
    accountStatus = LCase(ToStr(GetField(userInfo, "status")))
    if accountStatus <> "active"
        if accountStatus = ""
            showError("Sign-in failed — check your username and password.")
        else
            showError("Account is not active (" + accountStatus + ").")
        end if
        return
    end if
    finishAdd()
end sub

sub onM3uResult(event as object)
    res = event.getData()
    setBusy(false, "")
    if res = invalid
        showError("Something went wrong — try again.")
        return
    end if
    if res.ok <> true
        showNetError(res, "Couldn't download the playlist. " + ToStr(res.error))
        return
    end if
    body = ToStr(res.data)
    if body.instr(0, "#EXTINF") < 0
        showError("That doesn't look like an M3U playlist.")
        return
    end if
    finishAdd()
end sub

sub finishAdd()
    p = m.pending
    provider = { id: "", ptype: p.ptype, name: p.name }
    if p.ptype = "m3u"
        provider.m3uUrl = p.m3uUrl
        provider.epgUrl = p.epgUrl
    else
        provider.server = p.server
        provider.username = p.username
        provider.password = p.password
    end if
    AddProvider(provider)
    ' The website's "On this TV" list never heard about a KwickTV login until
    ' the next pairing code happened to be minted, so a member who signed in
    ' here and went straight to kwickplayer.tv/link on their phone found the
    ' page empty. Said here instead — AFTER AddProvider, because the report
    ' reads the registry rather than being told what changed, and a line
    ' earlier it would find no KwickTV and report the opposite of the truth.
    '
    ' Only for the KwickTV login. This same finishAdd() also lands an Xtream
    ' login, an M3U address and a USB playlist, and none of those is the
    ' built-in source or changes anything about it — reporting there would
    ' mint a pairing code nobody asked for and say nothing new.
    '
    ' Fire and forget: sign-in finishes on the very next line whatever the
    ' service does, including nothing at all. See LinkReport.brs.
    if provider.ptype = "kwicktv" then ReportBuiltinToLinkService()
    finishOnboarding()
end sub

sub setBusy(b as boolean, text as string)
    m.busy = b
    if b
        m.statusLabel.color = m.theme.textSecondary
        m.statusLabel.text = text
    end if
    ' The split screen says it on the button instead — see redrawSplit().
    if not m.split
        spinner = m.top.findNode("spinner")
        if spinner.poster.uri = "" then spinner.poster.uri = "pkg:/images/spinner.png"
        spinner.visible = b
        if b
            spinner.control = "start"
        else
            spinner.control = "stop"
        end if
    end if
    redraw()
end sub

sub showError(msg as string)
    m.statusLabel.color = m.theme.errorColor
    m.statusLabel.text = msg
end sub

' A connection failure gets the full explanation in a dialog. The inline
' status line is one narrow row — enough for "check your password", nowhere
' near enough to say WHY the server couldn't be reached and what to do about
' it, which is the difference between a member fixing their router and a
' member deciding the app is broken. The one-line summary stays on screen
' after the dialog closes.
sub showNetError(res as object, fallback as string)
    diag = GetField(res, "diag")
    if diag = invalid
        showError(fallback)
        return
    end if
    KLog("net", "diagnosis: " + ToStr(GetField(diag, "title")))
    showError(ToStr(GetField(diag, "title")))
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = ToStr(GetField(diag, "title"))
    dialog.message = ToStr(GetField(diag, "message"))
    dialog.buttons = ["OK"]
    dialog.observeField("buttonSelected", "closeDiagDialog")
    m.top.getScene().dialog = dialog
end sub

sub closeDiagDialog()
    m.top.getScene().dialog.close = true
end sub

' Roku can't open a browser — show the signup address instead (same entry
' point, minimum compromise). Sideload only; the store edition has no
' storefront at all (certification 5.3).
sub showSignupDialog()
    if not ShowStorefront() then return
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Get KwickTV"
    dialog.message = "Sign up at:" + Chr(10) + m.branding.signupUrl
    dialog.buttons = ["Close"]
    dialog.observeField("buttonSelected", "closeSignupDialog")
    m.top.getScene().dialog = dialog
end sub

sub closeSignupDialog()
    m.top.getScene().dialog.close = true
end sub

' The member answered Roku's Request For Information. Only a "yes" with an
' email does anything, and only into a username box that is still empty -
' anything they have typed in the meantime is theirs.
sub onRfiDone()
    res = m.rfiTask.result
    m.rfiTask = invalid
    if res = invalid or res.ok <> true then return
    email = ToStr(GetField(res, "email"))
    if email = "" or m.values.username <> "" then return
    m.values.username = email
    for each fn in m.fieldNodes
        if fn.def.key = "username" then fn.node.value = email
    end for
    KLog("rfi", "sign-in form pre-filled from the member's Roku account")
    redraw()
end sub
