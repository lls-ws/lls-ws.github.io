' Movie detail: poster + title + meta + plot from get_vod_info, and a stack
' of action buttons. The stack adapts to resume state — Resume + Play from
' Beginning when there's a saved spot (Duffy's request), else just Play —
' always ending with Add/Remove Favorites. Play is autofocused like Android.
'
' Under the poster sits the information table (director, video, audio,
' bitrate, format) — see the "Information table" block below.
'
' THIS FILE LOGS UNDER THE TAG "movie" (2026-10-12). Every one of its ten log
' lines used to go out tagged "guide", so a grep of a member's log for guide
' activity came back full of film-page lines and a grep for the film page came
' back empty. This lane has been misled by a log reading three times now, once
' this week. The sibling show page owns "series" the same way; keep new lines
' in this file on "movie".

sub init()
    m.theme = KwickTheme()
    m.top.findNode("bg").color = m.theme.background
    ' This screen is an OVERLAY on the scene, not a page inside the shell —
    ' the backdrop above is what hides the sidebar and the screen behind it,
    ' so AppScene's grid wash cannot show through. Draw it here instead, over
    ' this screen's own background and under everything else it draws. See
    ' AddPageGrid() in Theme.brs for why the backdrop above cannot simply be
    ' deleted.
    AddPageGrid(m.top)

    ' ---- The shell theme's type, page-wide ---------------------------------
    ' JetBrains Mono via Theme.brs. TYPE AND COLOUR ONLY on this page: the
    ' button column's D-pad chain is hand-wired and every geometry number in
    ' it is load-bearing, so nothing below moves a pixel. Each label was
    ' measured against its own box at mono's flat 0.6em advance and every one
    ' of them clears it, so no size on this screen had to change.
    '
    ' The ONE thing that did have to change is mdValueLines() further down,
    ' which guesses how many lines an information-table value needs from a
    ' hard-coded pixels-per-character. That constant was tuned for
    ' Roboto-Medium and is wrong for mono — see the note there.
    ' ---- The hero -----------------------------------------------------------
    m.backdropArt = m.top.findNode("backdrop")
    ' The fallback panel behind the artwork, so a film with no picture at all
    ' is a flat surface rather than a hole. Android does the same
    ' (ColoredBox(color: colors.surface) in detail_hero.dart).
    m.top.findNode("heroDim").color = Left(m.theme.background, 8) + "40"
    m.top.findNode("heroFade").blendColor = m.theme.background
    m.top.findNode("heroSeal").color = m.theme.background

    m.title = m.top.findNode("title")
    ' 46, centred in 1824: 66 characters in JetBrains Mono's flat 0.6em, where
    ' the old left-aligned 1300px box held 28. The page's headline got much
    ' roomier when it moved to the middle of the screen, so nothing had to
    ' shrink to follow Android's centred title.
    m.title.font = UiBoldFont(46)
    m.title.color = m.theme.textPrimary

    ' ---- The title as its own lettering -------------------------------------
    ' The film's wordmark, drawn in place of the words above once it has
    ' actually loaded. `lg` rides in on the rating-badge answer, so there is no
    ' second request and no second cache; the whole of it lives in
    ' RatingBadges.brs, which this component already names. Everything below is
    ' this page's half of the arrangement - see the block in that file, and the
    ' geometry argument in the XML.
    m.tlLogo = m.top.findNode("titleLogo")
    m.tlLabel = m.title          ' the words, which are the fallback in every direction
    m.tlMaxW = 880               ' Android's 440dp maxWidth, doubled
    ' 260, Android's televisionLogoCap doubled, where this was 130. The hero
    ' grew by 120 to pay for it - see the block in the XML.
    m.tlMaxH = 260
    m.tlBottom = 308             ' the bottom edge the title text ends on, so nothing below moves
    m.tlCentre = 960             ' the page is one centred column
    m.tlOn = false               ' is the picture up, as opposed to merely asked for
    m.tlBad = {}                 ' urls this session has already watched fail
    m.tlLogo.observeField("loadStatus", "onTitleLogoLoad")

    m.plot = m.top.findNode("plot")
    ' 25, wrapped, in the 880px left-hand column below the hero: 58 characters
    ' a line over 160px of height, i.e. 4 lines, where it was 342px and about 8.
    ' The 120 it gave up is the wordmark's, and the Label clips at the height it
    ' is given either way - what changed is that the clipped text is now
    ' REACHABLE. See the description block further down and dpSetText in
    ' RatingBadges.brs. UNVERIFIED on the television.
    m.plot.font = UiFont(25)
    m.plot.color = m.theme.textPrimary
    m.plot.lineSpacing = 10

    ' ---- The synopsis as a focus stop ---------------------------------------
    ' The three nodes that make the plot block pressable, plus the shared panel
    ' behind them. Everything about the arrangement - why it is an overlay
    ' rather than a reflow, and why it costs no texture - is written out at the
    ' bottom of RatingBadges.brs.
    m.dpFrame = m.top.findNode("descFrame")
    m.dpCapPlate = m.top.findNode("descCapPlate")
    m.dpCap = m.top.findNode("descCap")
    ' 22, the smallest face on this page and still 13.2px a character in mono -
    ' "Press OK to read it all" is 23 characters, 304px, inside the 336px plate
    ' with 16 either side.
    m.dpCap.font = UiBoldFont(22)
    m.dpCap.text = dpCaptionText()
    ' The panel's three faces are all ones this screen already draws, so the
    ' panel adds no glyph atlas to texture memory: bold 28 is the button face,
    ' 25 is this plot's own, 23 is the cast line and the information table.
    m.dpHeadFont = UiBoldFont(28)
    m.dpBodyFont = UiFont(25)
    m.dpBodySize = 25
    m.dpHintFont = UiFont(23)
    ' Is the highlight on the synopsis rather than on a button? The two are
    ' mutually exclusive and both are repainted together - see redrawButtons.
    m.descFocus = false
    m.dpOn = false

    m.castLine = m.top.findNode("castLine")
    ' 23, centred, TWO lines reserved in 1824 — about 264 characters, where the
    ' old 1280px box held 184. Centred to match the rest of the hero column.
    m.castLine.font = UiFont(23)
    m.castLine.color = m.theme.textSecondary

    ' ---- Metadata chips (Android's MetaChip) --------------------------------
    ' detail_hero.dart MetaChip: 10dp/4dp padding, radius 6, the theme's
    ' surfaceElevated at 85% alpha, a 14px accent icon, 12.5sp text. Doubled
    ' for this screen, and the plate is images/card_fill.9.png rather than a
    ' Rectangle because Roku cannot round a Rectangle — radius 8 against
    ' Android's 6dp/12px, close enough that the file did not need re-cutting
    ' and it is ALREADY RESIDENT for every card in the app.
    m.chipsGrp = m.top.findNode("chips")
    m.chipFont = UiFont(25)
    m.chipIconFont = IconFont(28)
    ' 85% of the theme's own surfaceElevated, built from the token so a reskin
    ' carries it. Theme colours are "0xRRGGBBAA", so Left(...,8) is the RGB.
    m.chipFill = Left(m.theme.surfaceElevated, 8) + "D9"

    ' ---- Action buttons (Android's terminal DetailActionButton) -------------
    ' Nord Shell is a terminal skin, so the branch that governs is
    ' _buildTerminalButton in detail_hero.dart: a bordered box sitting on a
    ' HARD OFFSET SHADOW — not a blur, so Roku can draw it — that lifts toward
    ' the light when focused while the shadow grows.
    '
    '   fill      focus first, then primary, then quiet. Focused and primary
    '             both take the accent; everything else surfaceElevated.
    '   ink       dark on the accent, textPrimary on surfaceElevated, and the
    '             favourite colour on an unfocused favourited button.
    '   frame     2dp -> images/card_edge.9.png (stroke 3, radius 8), already
    '             resident. Android's is 2dp/4px; 3 is the app's own card
    '             stroke and sharing the file is what stops the two drifting.
    '   shadow    the SAME rounded plate as the fill, tinted the frame colour,
    '             offset 3dp -> 6px at rest and 5dp -> 10px on focus.
    '   lift      the button moves -2dp -> -4px up and left on focus while the
    '             shadow stays PUT, which is what makes it read as lifting off
    '             the page rather than sliding.
    '
    ' >>> THE FRAME COLOUR IS DERIVED, exactly as Android derives it
    ' (detailButtonEdge), and this is the reported bug it exists to fix: Nord
    ' Shell sets the theme's border TO its accent, so an accent-filled button
    ' has a frame and a shadow at 1.00:1 against itself — a flat slab with a
    ' stub of the same colour behind it and no edge anywhere. Android walks the
    ' fill toward its own ink in 5% steps until it clears 3:1 (WCAG 1.4.11,
    ' non-text contrast). Both answers are computed here rather than at bind
    ' time, because there are only two fills on this page:
    '
    '   surfaceElevated fill -> the theme border (frost) already reads:
    '                           4.31:1 against the fill, 6.24:1 against the
    '                           page. Android would keep it, so this does.
    '   accent fill          -> frost against frost is 1.00:1, so the walk
    '                           runs: 13 steps of the page colour blended into
    '                           the accent gives 0x4E6572, which is 3.06:1
    '                           against the fill. The page does not have to be
    '                           cleared as well because the accent is already
    '                           6.24:1 against it.
    ' <<<
    '
    ' >>> THE DRAWING MOVED, THE NUMBERS DID NOT (2026-08-27). Everything
    ' above is now carried out by hbLayout / hbMakeButton / hbPaint in
    ' source/utils/RatingBadges.brs, so the series page can draw the same
    ' buttons from the same copy instead of growing a second one. The move was
    ' mechanical - same nodes, same numbers, same order - and this page's
    ' buttons should still be looked at on the television alongside the new
    ' series page rather than assumed. The five m.hb* fields below are this
    ' screen's half of that arrangement.
    ' m.hbEdgeOnLight, not m.hbEdgeOnAccent: since 2026-08-27 a FOCUSED button
    ' fills with focusHighlight rather than the accent, so this one derived
    ' colour now sits on two different light fills. It clears WCAG 1.4.11's 3:1
    ' against both - 3.1:1 on the accent, 3.9:1 on the focus yellow - which is
    ' why there is still only one of it. See hbPaint in RatingBadges.brs.
    m.hbEdgeOnLight = "0x4E6572FF"
    m.hbEdgeOnSurface = m.theme.surfaceBorder
    ' 28, unchanged. The longest label is "Remove from Favorites" at 21
    ' characters = 353px in mono at 28; a secondary button is sized to its own
    ' text so nothing truncates, and the row's total width is checked in
    ' hbLayout().
    m.hbFont = UiBoldFont(28)
    ' Android: 19dp on the primary, 17dp on a secondary. Doubled.
    m.hbIconFontPri = IconFont(38)
    m.hbIconFont = IconFont(34)

    ' The information table reuses the cast line's size — it is the same
    ' rank of detail, and this screen already has enough type sizes. It is
    ' also the font the ratings strip measures its chips in (m.rbFont below),
    ' so changing it changes the badge widths; 23 is deliberately unchanged.
    m.infoFont = UiFont(23)

    m.spinner = m.top.findNode("spinner")
    m.spinner.poster.uri = "pkg:/images/spinner.png"

    ' ---- "Ends at 8:42 PM" --------------------------------------------------
    ' The chips WITHOUT the end-time one — year, genre, runtime, source —
    ' exactly as applyInfo worked them out. Held because the end-time chip is
    ' rebuilt once a minute and the other facts must not be re-derived to do it.
    m.chipDefs = []
    ' What the end-time chip says, or "" for no chip at all.
    m.endsText = ""
    ' Whole minutes left, last drawn. -1 = nothing drawn, which is not the same
    ' as 0 (a film with a minute to go), so the two cannot be confused.
    m.endsMins = -1
    m.endsTick = m.top.findNode("endsTick")
    m.endsTick.observeField("fire", "onEndsTick")

    m.provider = ActiveProvider()
    m.player = invalid
    m.ext = ""
    m.buttons = []       ' [{ key, node, ring, label }]
    m.btnFocus = 0
    m.duration = 0
    ' The Media Bar's landscape artwork for this film, once get_vod_info
    ' answers. See applyInfo.
    m.backdrop = ""

    ' ---- The ratings strip --------------------------------------------------
    ' The strip itself now lives in source/utils/RatingBadges.brs, because the
    ' series page grew one too and two copies of a merge rule and a cache key
    ' is how the two pages quietly drift apart. Everything below is this
    ' screen's half of the arrangement; the file's own header lists what each
    ' screen has to set and why.
    m.metaTask = invalid
    m.badges = []        ' [{ s, v }] — what the strip draws, in order
    m.hasCert = false    ' the panel gave us a certificate of its own
    m.rbId = ""          ' which film the strip on screen belongs to
    m.rbTag = ""         ' which film a lookup is out for, if one is
    m.rbWho = "movie detail"
    m.rbKind = "movie"
    ' The information table's font, which is the cast line's — the same rank of
    ' detail, and this screen already has enough type sizes. A new size would
    ' be a new glyph atlas in texture memory for the sake of five characters.
    m.rbFont = m.infoFont
    ' THE LANE THE STRIP CENTRES IN: the whole page, because the page is now
    ' ONE CENTRED COLUMN. The old note here said the strip could not centre on
    ' the page because x=960 was inside the right-hand column and a strip there
    ' would lie across the plot and the Play button — that was true of the
    ' two-column page and is not true of this one. It also said "Android
    ' centres its row too, because there the column IS the page"; that is now
    ' the case here as well, which is the whole point of the port.
    m.rbLane = 1920
    ' ONE row, where the poster needed two. rbRowY's length is the row cap, and
    ' at 1920 wide everything that used to wrap onto a second row fits on one —
    ' the hero's layout reserves exactly 34px for it.
    m.rbRowY = [0]
    ' No scrim: the strip sits inside the hero, where heroDim and heroFade have
    ' already taken the artwork down to the page colour underneath it. A second
    ' scrim would be a dark bar across the middle of the hero.
    m.rbScrim = false
    m.rbScrimH = 0
    ' A measuring instrument, not a feature. GAP I1 was sized LARGE with one
    ' unresolved question — memory headroom — and this is what answers it on
    ' real hardware. Same object Search and the Multi-View picker already use.
    m.memMon = CreateObject("roAppMemoryMonitor")

    ' Parental gate (see the block at the bottom of this file).
    m.pgate = invalid    ' the snapshot, taken once when the item arrives
    m.catName = ""       ' this film's category, once get_vod_info answers
    m.catDone = false
    m.pendingPlay = invalid
    m.pinDialog = invalid

    ' Is the film on screen one from the member's own Jellyfin or Emby, and
    ' which demuxer does it need? All four are rewritten on EVERY film in
    ' onItem; these are only so the fields exist before the first one arrives.
    m.isMs = false
    m.msFmt = ""
    ' The lettering the member's OWN server holds for this film, remembered for
    ' the life of the page so it can be put back if the metadata answer takes
    ' it down — see onMsMeta at the bottom of the media-server
    ' block.
    m.msLogo = ""
    ' Which film a one-off details fetch is out for, so a slow answer for the
    ' last film cannot paint over this one.
    m.msItemId = ""
    m.msItemTask = invalid

    ' The one-frame delay that lets this page have the last word on the
    ' lettering. It is pinned now (tlPinLogoUrl), so nothing can take it down.
    ' (The 0.1s re-assert timer that used to live here is gone: the logo is
    ' pinned now - tlPinLogoUrl - so there is no race left to paper over.)

    ' LAST, so the panel is the last child of this screen and therefore draws
    ' over everything above. Built ONCE, here, and never rebuilt: whatever a
    ' press reveals has to already exist in its final position, because Roku
    ' decides directional focus purely on geometry and a node that is not there
    ' yet sends the highlight somewhere else entirely.
    dpBuild()
end sub

' ---- Guarded handlers (v1.0.41) ---------------------------------------------
'
' Every entry point the render thread can call on this page now runs under
' try/catch and reports through GuardFailed (Util.brs), the same way Home, the
' Media Bar, the TV Guide and the channel page already do. A fault now leaves
' one line in the log - "crash averted in movie/<handler>", naming the file,
' the line and the function - and arms the next-launch crash report, instead of
' the app dying with no stack at all.
'
' WHY THIS PAGE, IN PLAIN WORDS. Log key 96C9BD, a TCL 43S451 on v1.0.41: the
' member had the app open for an hour and a half and opened four film pages in
' that time, and then the television stopped dead. Their log says only
' "EXIT_BRIGHTSCRIPT_CRASH" - no file, no line, no function - because not one
' handler on this page was guarded. The last thing written was Home finishing
' its rows, and then nothing at all for eighty-three minutes until the app
' died. So the app was sitting still, with nothing on screen moving, when it
' went. We cannot say what fired. That is the whole point of this block: 96C9BD
' CANNOT BE NAMED, and the next one on this page names itself.
'
' The shape that fits 96C9BD, and the reason the timer below gets its own
' treatment: AppShell.brs:431-445 records that a film page is a SCENE child,
' not a child of the screen that opened it, so a profile reload or a Multi-View
' hand-off can throw the opener away and leave this page attached to the scene
' for the life of the app - holding its 1920x768 backdrop (5.6 MB) and still
' running its once-a-minute timer, with nothing on screen to show for it.
'
' GuardFailed IS REACHABLE HERE because MovieDetailScreen.xml names
' pkg:/source/utils/Util.brs (MovieDetailScreen.xml:14). A component only sees
' the scripts its own XML names, and that line is what makes these calls legal.
'
' init() IS DELIBERATELY NOT GUARDED, here as on Home, VOD and the Media Bar.
' A fault in init leaves a page with half its fields missing, and a guard there
' would turn one honest crash into every handler below it faulting for the rest
' of the session. A crash in init is a crash that should be found and fixed.
'
' ONE ENTRY POINT ON THIS PAGE IS STILL UNGUARDED AND IT IS NOT IN THIS FILE:
' the title-logo observer set at :72 calls onTitleLogoLoad, which lives in
' RatingBadges.brs:745. This job was scoped to the two detail screens, so that
' one is left as it was and is still able to die without a word.
sub onItem()
    try
        onItemInner()
    catch e
        GuardFailed("movie/onItem", e)
        ' TAKE THE SPINNER DOWN. onItemInner is what turns it on, and only the
        ' two answer handlers below ever turn it off, so a fault in between
        ' leaves the member watching this page spin for as long as they are
        ' willing to wait. Down, they get a page missing some of its facts -
        ' which is honest about having nothing, and which Back still leaves.
        if m.spinner <> invalid
            m.spinner.visible = false
            m.spinner.control = "stop"
        end if
    end try
end sub

sub onItemInner()
    it = m.top.item
    if it = invalid then return
    ' CLEARED ON EVERY BIND, BOTH WAYS. Every opener makes a fresh node today,
    ' so these cannot currently be stale — but they are only filled in when the
    ' details answer arrives, and a node that was ever reused would carry the
    ' PREVIOUS film's catalogue id into this one. That id now decides which
    ' film gets ticked on the member's own Trakt and Simkl accounts, where a
    ' wrong one is theirs to go and unpick, so it is emptied here rather than
    ' relying on how the page happens to be opened.
    m.subsTmdb = ""
    m.subsYear = ""
    ' Baseline, before this page has built anything. Read the "opened" lines
    ' ACROSS several films — see the measurement note at the bottom.
    rbMemSample("opened")
    ' The item's own source (set by merged screens) wins over the active
    ' one — playback URL, favorites, and the resume key all follow it.
    m.itemSrc = invalid
    if type(it) = "roAssociativeArray" and it.doesExist("src") then m.itemSrc = ToStr(it.src)
    if m.itemSrc <> invalid
        p = ProviderForSrcToken(m.itemSrc)
        if p <> invalid then m.provider = p
    end if
    ' The poster, standing in for the backdrop until get_vod_info answers with
    ' a real one (applyInfo swaps it). Android does exactly this —
    ' `backdropUrl ?? posterUrl` in vod_detail_screen.dart:204-205 — and it
    ' looks exactly as soft there: a 2:3 cover cropped into a 1920 x 648 box.
    ' Parity, not an oversight.
    ' tmdbSized directly at w780, NOT DetailPosterUrl. That helper is w500 and
    ' is right for its three callers, all of which draw a poster at poster size
    ' — the series page's 240px art, the Media Bar's own fallback. This one is
    ' a poster being stretched across a 1920-wide hero, so w500 is a 3.8x
    ' upscale where w780 is 2.5x. w780 and not more because it is the largest
    ' size TMDB documents for a POSTER path; w1280 is a backdrop size, and a
    ' size token the CDN does not serve for this path is a 404, i.e. no picture
    ' at all rather than a soft one.
    '
    ' >>> AND IT ONLY BITES ON SOME URLS, which is worth knowing before anyone
    ' relies on it. tmdbSized rewrites the size ONLY when the url is a TMDB one
    ' carrying the "/w600_and_h900_bestv2/" marker — that is the form the
    ' panels quote. A TMDB url already in some other size, and any url the
    ' panel hosts itself, passes through untouched at whatever size its host
    ' chose. There is no bigger version to ask for in those cases, so the
    ' fallback is as sharp as it can be and no sharper. <<<
    '
    ' This is only ever a stopgap while get_vod_info is on the way, EXCEPT on a
    ' film the panel has no backdrop for at all, where it is what the member
    ' looks at. That second case is why it is worth the two lines.
    m.backdropArt.uri = tmdbSized(ToStr(it.icon), "w780")
    m.title.text = ToStr(it.name)
    m.ext = ToStr(it.ext)
    m.resumeKey = ResumeKeyMovie(ToStr(it.streamId), m.itemSrc)
    ' The parental snapshot: ONCE per screen open, never per button press.
    m.pgate = ParentalGate("movies")
    m.catName = ""
    m.catDone = false
    m.pendingPlay = invalid
    ' Same reasoning as everything else emptied here: the last film's backdrop
    ' is not this one's, and applyInfo does not run at all when the request
    ' fails. A Play pressed before the details land simply carries none, which
    ' the Media Bar already knows how to draw.
    m.backdrop = ""
    ' Last film's words are not this one's. These three are written in
    ' applyInfo, which does not run at all when the request fails — so
    ' without this, a film whose details never arrive keeps the PREVIOUS
    ' film's plot, meta line and cast underneath its own title.
    m.plot.text = ""
    ' THE PANEL AND ITS FURNITURE GO WITH THE WORDS, BOTH WAYS. This page is one
    ' node kept across films; a frame and a "Press OK to read it all" plate left
    ' behind on a film whose details never arrived would be a focus stop
    ' advertising an empty panel. dpSetText writes m.dpOn, dpPaintBlock draws
    ' the consequence, and the highlight is pulled back onto the buttons so it
    ' can never be sitting on a block that just stopped existing.
    dpSetText("", "")
    if m.descFocus
        m.descFocus = false
        if m.btnFocus < 0 then m.btnFocus = 0
    end if
    dpPaintBlock(false)
    m.castLine.text = ""
    ' The chips belong to the film whose details are in hand, so a new film
    ' clears them outright: applyInfo does not run at all when the request
    ' fails, and the previous film's year, runtime and "Ends at" under this
    ' film's title would be wrong facts rather than missing ones.
    m.chipDefs = []
    m.endsText = ""
    m.endsMins = -1
    m.duration = 0
    buildChips()
    m.endsTick.control = "start"
    ' Same reasoning for the technical fields below the poster: a request
    ' that fails must leave nothing stale on screen rather than the previous
    ' title's bitrate.
    clearInfoTable()
    ' Same reasoning as the table above: last film's scores are not this
    ' one's, and a lookup that fails must leave nothing stale on screen.
    ' rbReset also records WHICH film the strip is about, which is what makes a
    ' slow answer for the previous one land on the floor instead of on this
    ' page — see onTitleMeta in RatingBadges.brs.
    rbReset(ToStr(it.streamId))
    ' Cleared BOTH WAYS on every film, like everything above it: this page is
    ' one node handed a second film, and a demuxer left over from a member's
    ' Jellyfin would otherwise be handed to the next Xtream title. The logo
    ' address goes with them for the same reason — a leftover would put the
    ' PREVIOUS film's wordmark back up the moment this film's metadata landed.
    m.isMs = false
    m.msFmt = ""
    m.msLogo = ""
    m.msItemId = ""
    m.msDrawn = false
    buildButtons()

    ' ---- A film on the member's own Jellyfin or Emby ------------------------
    ' Everything this page shows for one of those is ALREADY IN HAND: the
    ' library read that filled the grid asked for Overview, ProductionYear,
    ' RunTimeTicks and Container in the same request, and MsMapItem carried
    ' them through on the row. So this branch costs the member's server ZERO
    ' requests and there is no spinner, because there is nothing to wait for.
    '
    ' That is deliberate and it matches the Flutter app, which has a test that
    ' fails if any request is made while a title is being opened or played.
    ' A request per Play press is the traffic shape that got this house's
    ' address banned by a provider (2026-08-14) — see
    ' Wiki/Roku/Roku - Anti-Share Bans.md.
    if MsIsMediaServer(m.provider)
        msApplyMovie(it)
        return
    end if

    ' Full details (plot, cast, year, rating, duration)
    m.spinner.visible = true
    m.spinner.control = "start"
    task = CreateObject("roSGNode", "ApiTask")
    task.url = XtreamApiUrl(m.provider, "get_vod_info") + "&vod_id=" + UrlEncode(ToStr(it.streamId))
    task.observeField("result", "onInfo")
    m.task = task
    task.control = "RUN"
end sub

' ---- The media-server film page, drawn from the row itself -------------------
'
' The Xtream half of this screen waits for get_vod_info and then fills in the
' plot, the chips, the cast, the technical table and the ratings strip. A
' Jellyfin or Emby film has no equivalent call worth making — the library read
' already asked for Overview, ProductionYear, RunTimeTicks, Container, Genres
' and OfficialRating, plus the Logo and Backdrop image tags, all in the same
' request, and MsMapItem carries every one of them through on the row. Asking
' again per film opened would be a request per item, which is the pattern this
' app refuses everywhere else.
'
' So a film from the member's own server now draws the same page an Xtream film
' does — the wide backdrop, the title's own lettering, the genre, the
' certificate and the scores — for ZERO extra requests, whenever it was opened
' from Movies & Series. The one door that does cost a request is the bare one
' below, and it costs exactly one.
'
' WHAT IS DELIBERATELY MISSING, so nobody hunts for a bug that is not there:
'   · no cast line and no director — the library read does not ask for People,
'     and adding it would make every library page heavier for a line most
'     members do not read. A later job, if it is wanted.
'   · the information table shows its Format row and nothing else. The other
'     four rows are the panel's MediaInfo — video codec, audio codec, bitrate —
'     and a library read reports none of them. That is a different request per
'     title (/PlaybackInfo), so it stays out.
' Every one of those leaves its space EMPTY rather than stale, because onItem
' above cleared all of them before this ran.
sub msApplyMovie(it as object)
    m.isMs = true
    ' Nothing is on the way YET — the branch at the bottom decides whether
    ' anything has to be, and turns the spinner back on if it does. Set BOTH
    ' ways rather than assumed off: certification 3.4 wants a spinner up while
    ' a member is waiting, and it wants it GONE when they are not.
    m.spinner.visible = false
    m.spinner.control = "stop"

    ' The container the catalogue reported, turned into the demuxer the Video
    ' node needs. This matters more here than anywhere else in the app: a
    ' media-server stream address carries no file extension, so the app's usual
    ' StreamFormatFor() would fall through to "mp4" and an mkv would fail with
    ' "malformed data" — the same wording as an undecodable codec, which would
    ' send the next person hunting the wrong fault. See MsStreamFormat().
    container = ""
    if type(it) = "roAssociativeArray"
        if it.doesExist("container") then container = ToStr(it.container)
        if container = "" and it.doesExist("ext") then container = ToStr(it.ext)
    end if
    m.msFmt = MsStreamFormat(container)
    ' The information table's Format row reads m.ext, and the raw container a
    ' server reports is ffmpeg's own list ("mov,mp4,m4a,3gp,3g2,mj2"), which is
    ' not a thing to print at a member. The tidied answer is what they read AND
    ' what playMovie plays with.
    m.ext = m.msFmt

    ' The parental gate. A media server has no category to look up, so this
    ' page is never waiting on one — say so, or parentalOkToPlay would hold
    ' every first press for an answer that is never coming.
    m.catName = ""
    m.catDone = true

    ' ---- Which door did this film come through? -----------------------------
    ' Opened from Movies & Series, it arrives with the whole library row on it
    ' and the page draws immediately, with nothing asked of anybody.
    '
    ' Opened from Continue Watching, Search or a favourite, it arrives with an
    ' id, a name and a poster and nothing else, because those doors store a
    ' place in a list and were never carrying a library row. `overview` is the
    ' tell — the KEY, not its contents, because a film can honestly have no
    ' synopsis and VodScreen sets all of these together or not at all.
    '
    ' ONE request for that second case, once, on page open. NEVER per tile and
    ' never per row — the note at the top of TitleMetaTask.brs and
    ' HomeScreen.brs says what the per-tile shape cost this house in August
    ' 2026.
    '
    ' AND ONE REQUEST IN THE FIRST CASE TOO, since 2026-09-12 - for the cast
    ' line and the information table, which the library read deliberately does
    ' not carry (People and MediaStreams are most of an item's bytes). It is
    ' the same one-request-per-page-open every Xtream film has always paid for
    ' get_vod_info, and the page is drawn from the row BEFORE it goes out, so
    ' nothing the member is looking at waits on it. Without it the film page
    ' had an empty band where the cast goes, which the owner spotted at once.
    if type(it) = "roAssociativeArray" and it.doesExist("overview") then msDrawMovie(it)
    msFetchMovie(ToStr(it.streamId))
end sub

' ---- Everything a media-server film puts on this page ------------------------
'
' ONE drawing sub and not two, because both maps that reach it carry the same
' plain field names: the row the grid handed over, and the answer to the single
' fetch below mapped through MsMapItem. It runs exactly ONCE per page open.
sub msDrawMovie(row as object)
    it = m.top.item
    if it = invalid then return

    ' The demuxer again, refined when THIS map named a container — the fetched
    ' answer carries one and a Continue Watching row may not have. msApplyMovie
    ' already worked one out from the item itself, so a Play pressed before a
    ' fetched answer landed is never left without one.
    container = ToStr(GetField(row, "container"))
    if container <> ""
        m.msFmt = MsStreamFormat(container)
        m.ext = m.msFmt
    end if

    ' ---- The chips, in the Xtream film page's own order ---------------------
    ' Year, genre, runtime with the clock icon, then the source with its colour
    ' dot: applyInfo's row exactly, so the two kinds of film read the same at
    ' ten feet. The score is NOT a chip here for the same reason it is not one
    ' there — it is a badge in the strip below, and the badge also says who
    ' gave the number.
    m.chipDefs = []
    yr = ToInt(GetField(row, "year"))
    if yr > 0 then m.chipDefs.push({ text: yr.toStr(), icon: "", dot: "" })
    ' One line, already cut to three genres by MsGenreLine, which is the same
    ' one chip of genre the Xtream page draws from info.genre.
    genre = ToStr(GetField(row, "genres"))
    if genre <> "" then m.chipDefs.push({ text: genre, icon: "", dot: "" })
    m.duration = ToInt(GetField(row, "runtime"))
    if m.duration > 0
        ' Chr(&hE425) is `timer`, the same codepoint the Xtream branch uses for
        ' its runtime chip. Icons here are ones ALREADY PROVEN in this package,
        ' never looked up in a chart. msRuntimeText is this page's own "1h 32m"
        ' and the seconds come from RunTimeTicks, so there is no second format.
        m.chipDefs.push({ text: msRuntimeText(m.duration), icon: Chr(&hE425), dot: "" })
    end if
    srcName = msSourceChipName(it)
    if srcName <> "" then m.chipDefs.push({ text: srcName, icon: "", dot: hcSrcDotColor() })
    buildChips()
    ' "Ends at 8:42 PM" needs the duration above and nothing else; it reads the
    ' resume point itself. Same reading, same contract, as the Xtream branch.
    refreshEndsAt()

    ' The synopsis, and the reading panel with it. Written BOTH ways: an empty
    ' Overview takes dpSetText's "off" branch, so no frame and no "Press OK to
    ' read it all" plate is left advertising an empty panel.
    m.plot.text = ToStr(GetField(row, "overview"))
    dpSetText(ToStr(it.name), m.plot.text)
    dpPaintBlock(m.descFocus)

    ' ---- The hero, step one of three ----------------------------------------
    ' Android's order is the member's own server first, the metadata match
    ' second, the portrait poster only if neither exists (`backdropUrl ??
    ' posterUrl`). This is step one; step two is in onMsMeta below; step three
    ' is the poster onItem already put up, which is simply left alone.
    '
    ' ASSIGNED DIRECTLY, NOT THROUGH BackdropUrl(). That function exists to put
    ' the host and the size back on TMDB's short stored form — a leading slash
    ' and a file name. What MsImageUrl builds is already a whole address on the
    ' member's own server, and it would pass through BackdropUrl untouched, so
    ' the call would be noise that reads as though a conversion were happening.
    '
    ' >>> AND THIS IS THE BIGGEST TEXTURE SAVING IN THE CHANGE. The hero node
    ' is loadDisplayMode="scaleToZoom" pinned at 1920 x 768, and zoom-to-cover
    ' has to decode enough picture to CROP from: a 2:3 poster forced into a
    ' 1920-wide box decodes 1920 x 2880, which is 22 MB against a budget of
    ' roughly 90 and five out-of-memory crash reports. That is what the stick
    ' logged as "Loaded texture (1920 x 2880) larger than the UI resolution".
    ' A real landscape backdrop is 16:9, so covering the same box decodes
    ' 1920 x 1080 — about 8.3 MB, a saving of roughly 14 MB every time a
    ' media-server film is opened. The pins do not change and neither does
    ' loadDisplayMode; feeding the node the right SHAPE of picture is the fix.
    m.backdrop = ToStr(GetField(row, "backdrop"))
    if m.backdrop <> ""
        m.backdropArt.uri = m.backdrop
        ' And onto the Continue Watching row, so the Media Bar on Home stops
        ' faking a landscape picture out of this film's portrait poster. Only
        ' the SERVER's own address is ever stored — never the TMDB one from
        ' step two — because the stored copy is mirrored across devices and a
        ' TMDB path written for a media title has not been thought through yet.
        ' AttachRecentBackdrop creates no row and reorders nothing; it writes
        ' only where the member already has one for this film.
        AttachRecentBackdrop("movie", ToStr(it.streamId), m.itemSrc, m.backdrop)
    end if

    ' ---- The title's own lettering ------------------------------------------
    ' tlApplyLogoUrl and not tlApplyLogo: the server's logo address is a whole
    ' url, and tlApplyLogo is the half that expands TMDB's short form first.
    ' Everything under the split is shared — the failed-url memory, the
    ' hidden-until-loaded rule, and falling back to the words.
    '
    ' Remembered in m.msLogo as well as applied, because the metadata answer
    ' can take it down again. See tlPinLogoUrl in RatingBadges.brs.
    m.msLogo = ToStr(GetField(row, "logo"))
    ' PINNED, not merely applied. The metadata answer lands a second later and
    ' used to put its own lettering over this one; two uris racing for one
    ' Poster is what blacklisted a perfectly good logo on the office stick.
    ' A pinned logo makes the service half stand down (tlApplyLogo). When the
    ' server has none, nothing is pinned and the service's lettering is
    ' welcome, exactly as before.
    if m.msLogo <> "" then tlPinLogoUrl(m.msLogo)
    m.msDrawn = true

    ' One row — Format — from m.ext above. invalid is safe: every reader in
    ' there answers empty on a missing map, so the director, video, audio and
    ' bitrate rows simply do not appear.
    buildInfoTable(invalid)

    ' ---- The ratings strip --------------------------------------------------
    ' The same two calls the Xtream branch makes, off MsInfoMap instead of the
    ' panel's info map. rbApplyProviderBadges costs nothing at all — the
    ' certificate and the server's own score are already in hand — and
    ' rbStartLookup is ONE request per page open, cached for a week, keyed on
    ' name and year, and refused outright on a box short of memory.
    '
    ' The certificate cannot end up on the strip twice: rbApplyProviderBadges
    ' sets m.hasCert when the server gave one, and onTitleMeta adds the
    ' service's only when it did not. That is the Xtream rule and this path
    ' simply obeys it rather than inventing a second one.
    info = MsInfoMap(row)
    ' THE TMDB ID, KEPT FOR THE SUBTITLE SEARCH. The relay takes an id or a
    ' name, and a name is genuinely ambiguous - one film's id once answered
    ' with ten Dexter episodes, which is why the relay insists on a type. The
    ' panel hands the id over in this very answer and nothing was keeping it,
    ' so every subtitle search was a name search. Media-server titles have no
    ' panel id (MsInfoMap deliberately sends none), so those still search by
    ' name, which is the honest fallback rather than a wrong id.
    m.subsTmdb = rbClean(GetField(info, "tmdb_id"))
    ' AND THE ONE THE SERVER ITSELF KNOWS. Jellyfin and Emby both carry the
    ' title's TMDB id in `ProviderIds`, and this screen now asks for that field
    ' (MsItemUrl). It is read straight off the row rather than through
    ' MsInfoMap on purpose — the note above that function explains why the
    ' ratings strip must not be handed an id it cannot vouch for — but
    ' everything that keys on an id wants it: the subtitle search, and the
    ' scrobbles and checkmarks that reach a member's Trakt and Simkl. Without
    ' this line a Jellyfin library, which is most of what this house watches,
    ' filed nothing to either service and searched subtitles by name only.
    if m.subsTmdb = "" then m.subsTmdb = MsTmdbId(row)
    m.subsYear = rbYearOf(info)
    rbApplyProviderBadges(info)
    rbStartLookup(info)
    msWatchMeta()
end sub

' ---- The one fetch, for a film that came through a bare door -----------------
'
' Continue Watching, Search and favourites all store an id and a name. They
' were never going to store a synopsis, a backdrop or a certificate, so a film
' opened from one of them has to ask for those once. ONE request, on page open,
' for ONE title — the same budget, at the same moment in the page's life, that
' the Xtream half spends on get_vod_info.
sub msFetchMovie(itemId as string)
    if itemId = "" then return
    ' No token means a 401. Draw nothing rather than spend a request being told
    ' so: the page already has the title, the poster and the buttons, and the
    ' Play press explains itself if the member gets that far.
    if MsNeedsSignIn(m.provider) then return
    ' Which film this answer is about. This page is ONE node handed a second
    ' film, so an answer that outlived its page must land on the floor.
    m.msItemId = itemId
    ' Certification 3.4 wants a spinner up while a member is waiting, and on
    ' this one path they are.
    m.spinner.visible = true
    m.spinner.control = "start"
    t = CreateObject("roSGNode", "MediaServerTask")
    t.url = MsItemUrl(m.provider, itemId)
    t.method = "GET"
    ' The identity header. This is the ONLY place the access token appears —
    ' never in the address, because an address is printed in the diagnostic log
    ' and written into watch history.
    t.headers = MsHeaders(m.provider)
    t.timeoutMs = 25000
    t.observeField("result", "onMsItem")
    ' Held in its own field rather than m.task: that one belongs to the Xtream
    ' ApiTask, and a task nothing holds a reference to can be collected while
    ' it is still in flight.
    m.msItemTask = t
    t.control = "RUN"
end sub

sub onMsItem(event as object)
    try
        onMsItemInner(event)
    catch e
        GuardFailed("movie/onMsItem", e)
        ' Same spinner insurance as onItem. The inner handler takes it down in
        ' its first act, so only a fault in getData() itself can reach here
        ' with the page still spinning - but that is the one case where the
        ' member would otherwise wait forever.
        if m.spinner <> invalid
            m.spinner.visible = false
            m.spinner.control = "stop"
        end if
    end try
end sub

sub onMsItemInner(event as object)
    res = event.getData()
    m.spinner.visible = false
    m.spinner.control = "stop"
    it = m.top.item
    if it = invalid then return
    ' A late answer for the PREVIOUS film. Dropped, not drawn.
    if ToStr(it.streamId) <> ToStr(m.msItemId) then return
    if res = invalid or res.ok <> true
        why = "the server did not answer"
        if res <> invalid and ToStr(res.error) <> "" then why = ToStr(res.error)
        KLog("movie", "movie detail:no details from the media server - " + why)
        return
    end if
    ' /Items answers with a LIST even when exactly one id was asked for.
    first = invalid
    for each e in ToArray(GetField(res.data, "Items"))
        first = e
        exit for
    end for
    if first = invalid then return
    row = MsMapItem(m.provider, first, "movie")
    if row = invalid then return
    ' A page drawn from its grid row already has everything but the cast and
    ' the table; drawing it all again would rebuild the chips under the
    ' member and ask the metadata service a second time. A page that came
    ' through a bare door has nothing yet and takes the lot.
    if m.msDrawn <> true then msDrawMovie(row)
    msApplyTech(row)
end sub

' Which source a title is on, for its chip. The caller's own label when it
' sent one; otherwise the provider's name, which every door into this page can
' answer because m.provider was resolved from the item's src in onItem. The
' owner's words on seeing the chip missing: "the sourcechip for VOD is missing
' from the details page" - Movies & Series never sent a label, and the chip
' was silently skipped on every title opened from the grid.
function msSourceChipName(it as dynamic) as string
    if type(it) = "roAssociativeArray" and it.doesExist("srcLabel")
        nm = ToStr(it.srcLabel)
        if nm <> "" then return nm
    end if
    if m.provider <> invalid then return ToStr(m.provider.name)
    return ""
end function

' The cast line and the information table, off the item answer's People and
' MediaStreams - the SAME two things applyInfo fills for an Xtream film, from
' the same-shaped map (MsTechInfo), drawn by the same code.
sub msApplyTech(row as object)
    tech = GetField(row, "tech")
    if tech = invalid then return
    cast = ToStr(GetField(tech, "cast"))
    if cast <> ""
        m.castLine.text = "Cast:  " + cast
    else
        m.castLine.text = ""
    end if
    buildInfoTable(tech)
end sub

' ---- The other half of the metadata answer -----------------------------------
'
' rbStartLookup above fires the SAME single cached lookup every Xtream title
' makes, and RatingBadges.brs draws the badges off it in onTitleMeta. Two
' things in that answer belong to this page rather than to the strip, and this
' is where they are picked up. It is a SECOND OBSERVER ON THE SAME TASK, not a
' second request: nothing extra is asked of anybody, and the shared file is
' untouched.
'
'   · `bd`, the TMDB backdrop — step two of the hero order above, used only
'     when the member's own server had none. Written to the NODE only, never
'     to m.backdrop, because m.backdrop is the copy that gets stored on the
'     Continue Watching row and mirrored to their other devices.
'   · the lettering, PUT BACK. onTitleMeta finishes by calling tlApplyLogo with
'     whatever the service sent, and on a title the service has no logo for
'     that call takes the member's OWN server's lettering back down and leaves
'     the words. The server's is the picture the member chose, so it wins.
sub msWatchMeta()
    ' m.rbTag is non-empty ONLY when rbStartLookup has just created a task — it
    ' refuses on a box short of memory and on a title with no name, and rbReset
    ' empties it on every new film. So this is the exact test for "there is a
    ' task of mine to listen to", and it can never attach to the last film's.
    if ToStr(m.rbTag) = "" then return
    if m.metaTask = invalid then return
    m.metaTask.observeField("result", "onMsMeta")
end sub

sub onMsMeta(event as object)
    try
        onMsMetaInner(event)
    catch e
        GuardFailed("movie/onMsMeta", e)
        ' LOGGED AND NOTHING ELSE. This answer only ever adds to the hero - a
        ' backdrop, a logo, the ratings strip. It owns no spinner and holds no
        ' focus, so a fault costs the member some artwork on a page that is
        ' otherwise complete and usable. There is nothing to put back.
    end try
end sub

sub onMsMetaInner(event as object)
    res = event.getData()
    if res = invalid or res.ok <> true then return
    if m.top.item = invalid then return
    ' The same two guards onTitleMeta uses, for the same reason: an answer that
    ' outlived its page has to land on the floor rather than on the film the
    ' member is looking at now.
    if ToStr(m.rbTag) = "" then return
    node = event.getRoSGNode()
    if node <> invalid and ToStr(node.tag) <> ToStr(m.rbTag) then return

    ' Step two of the hero order, and only when step one found nothing.
    if ToStr(m.backdrop) = ""
        ' BackdropUrl(), because THIS one really is TMDB's short form — a
        ' leading slash and a file name, exactly as the Xtream hero's is, and
        ' handing that to a Poster raw is what drew no hero at all on
        ' 2026-08-26. w1280 for the same reason as everywhere else on this
        ' page: it draws 1920 wide and w500 would be a 3.8x upscale.
        bd = ToStr(GetField(res.data, "bd")).trim()
        if bd <> "" then m.backdropArt.uri = BackdropUrl(bd, "w1280")
    end if
end sub

' WHY A TIMER AND NOT JUST A LINE IN onMsMeta. Both callbacks hang on the one
' `result` field, and Roku does not promise which of two observers on a field
' runs first. If ours ran first, RatingBadges.brs would then take the server's
' lettering down again and the whole re-assert would be pointless. A tick puts
' this on the frame AFTER whatever the shared file did, whichever order they
' fired in, so the outcome is the same either way. 0.1 seconds is invisible,
' and nothing here is a keypress, so certification 3.5's 250 ms is not in play.

' "1h 32m", "48m", "" for nothing. Local to this page on purpose: the player
' has its own clockDuration() and a component only gets the scripts its own XML
' names, so a helper borrowed from there would kill the render thread with
' "Function is not defined in component's namespace".
function msRuntimeText(secs as integer) as string
    if secs <= 0 then return ""
    mins = Int((secs + 30) / 60)
    if mins < 60 then return mins.toStr() + "m"
    hrs = Int(mins / 60)
    ' NOT named `rem`: REM is BrightScript's comment keyword and the gate
    ' rejects it, along with `pos`, `left`, `run`, `box` and `val`. That list
    ' has stopped this build three separate times.
    restMins = mins mod 60
    if restMins = 0 then return hrs.toStr() + "h"
    return hrs.toStr() + "h " + restMins.toStr() + "m"
end function

' Build the button stack for the current resume state.
' ---- The action grid (Android's DetailActionButton, terminal branch) --------
'
' ANDROID'S ARRANGEMENT, and it is what the owner asked for by name: the
' primary action alone on its own line, then the secondary actions WRAPPED in
' a row beneath it (detail_hero.dart build(): `actions.first`, then a Wrap over
' `actions.sublist(1)`). Roku has no Wrap, so the row is measured and centred
' here.
'
' >>> THIS REPLACED A LINEAR UP/DOWN STACK, AND THE D-PAD CHAIN HAD TO BE
' REWRITTEN WITH IT. The old chain walked m.btnFocus with up and down and
' nothing else, which cannot express a row. The new one is a hand-wired 2-D
' chain and it deliberately MIRRORS the one the sibling page already has -
' SeriesDetailScreen.brs onKeyEvent, which walks a 2x3 grid with explicit
' per-index left/right/up/down and stays put rather than jumping diagonally
' when there is nothing beside a button. Two different 2-D chains on two
' sibling pages is how the next person breaks one while fixing the other.
' See onKeyEvent() below for the walk and the reachability argument.
'
' THE PARENTAL GATE IS UNTOUCHED BY ANY OF THIS. It hangs off playMovie() ->
' parentalOkToPlay() on the OK press and reads nothing from m.btnFocus, so the
' shape of the grid cannot reach it.
sub buildButtons()
    col = m.top.findNode("buttonCol")
    while col.getChildCount() > 0
        col.removeChildIndex(0)
    end while
    m.buttons = []

    resume = LoadResume(m.resumeKey)
    specs = []
    ' Index 0 is ALWAYS the primary and is always alone on row 0. Everything
    ' after it is row 1, left to right. The chain below depends on that and on
    ' nothing else about the list.
    if resume <> invalid
        specs.push({ key: "resume", text: ResumeLeftText(resume.positionS, resume.durationS), icon: m.theme.iconPlay, primary: true, widest: "" })
        ' Icons are Material codepoints ALREADY PROVEN in this package, never
        ' looked up in a chart - a wrong codepoint draws the wrong picture and
        ' this repo has been burned by exactly that (the E1A8/E1B8 note in
        ' PlayerScreen.brs). E5D5 is `refresh`, the circular arrow, where
        ' Android uses `replay`; they are the same gesture and E5D5 is proven.
        specs.push({ key: "begin", text: "Play from Beginning", icon: Chr(&hE5D5), primary: false, widest: "Play from Beginning" })
    else
        specs.push({ key: "play", text: "Play", icon: m.theme.iconPlay, primary: true, widest: "" })
    end if
    ' Mark as Watched (GAP D5). It sits where Android puts it, ahead of
    ' Favorites, and its label says which way it will go. iconCheck (E5CA) for
    ' Android's check_circle_outline - proven here, and the tick is the part
    ' that carries at ten feet.
    ' `widest` is the WIDEST this label can ever get, not what it says now -
    ' see hbLayout. The three stateful buttons below are still empty strings
    ' when the row is measured, so the longer of each pair is named here.
    specs.push({ key: "markseen", text: "", icon: m.theme.iconCheck, primary: false, widest: "Mark as Unwatched" })
    ' THE HEART, not Android's star. Android's favourite glyph on this page is
    ' Icons.star, but the favourite mark in THIS app is a heart everywhere it
    ' appears - the poster cards, the player's own button, images/heart.png.
    ' Matching Android here would mean one title wearing a star on its detail
    ' page and a heart on the poster it was opened from. The app's own language
    ' wins over the reference on this one, deliberately.
    specs.push({ key: "favorite", text: "", icon: Chr(&hE87E), primary: false, widest: "Remove from Favorites" })
    specs.push({ key: "addlist", text: "Add to List", icon: Chr(&hE03B), primary: false, widest: "Add to List" })

    ' ---- Android's terminal button geometry, doubled ------------------------
    ' primaryButtonHeight 42 -> 84, secondaryButtonHeight 36 -> 72. The rest of
    ' the geometry - the spacing, the icon gaps, the shadow offset, the lift -
    ' lives in hbGap()/hbIconW()/hbIconGap*() in RatingBadges.brs, shared with
    ' the series page so the two cannot drift.
    priH = 84
    secH = 72
    priW = 720                ' inside Android's 200..440dp -> 400..880px clamp
    secY = priH + 28          ' gapAfterPrimary 14 -> 28

    ' Row 0 is the primary alone; row 1 is the secondaries, each sized to its
    ' own widest label and the row centred as a whole. The worst case today is
    ' "Play from Beginning" + "Mark as Unwatched" + "Remove from Favorites" +
    ' "In Lists", about 1500px against the 1824 the hero column has; hbLayout
    ' tightens the gap rather than running off the edge if a longer set ever
    ' arrives.
    m.buttons = hbLayout(col, specs, 0, priH, priW, secY, secH)

    if m.btnFocus >= m.buttons.count() or m.btnFocus < 0 then m.btnFocus = 0
    redrawButtons()
end sub

' THE WORDS, and only the words. The plate, the frame, the shadow, the ink and
' the lift are hbPaint's job now (RatingBadges.brs), shared with the series
' page. This still writes EVERY stateful label BOTH WAYS on every redraw - a
' label written only inside its "on" branch smears the previous state onto the
' next repaint.
sub redrawButtons()
    favored = false
    if m.top.item <> invalid
        favored = IsFavoriteVod("movie", ToStr(m.top.item.streamId), m.itemSrc)
    end if
    inList = false
    if m.top.item <> invalid
        inList = IsInAnyList("movie", ToStr(m.top.item.streamId), m.itemSrc)
    end if
    ' ONE registry read for the whole grid, taken here rather than inside the
    ' loop — this runs on every arrow press across the buttons.
    watched = IsSeen(movieSeenKey())
    for i = 0 to m.buttons.count() - 1
        b = m.buttons[i]

        ' ---- the words, and which of them ----------------------------------
        favInk = false
        if b.key = "markseen"
            if watched
                b.lbl.text = "Mark as Unwatched"
                b.ico.text = m.theme.iconCheck
            else
                b.lbl.text = "Mark as Watched"
                b.ico.text = m.theme.iconCheck
            end if
        else if b.key = "favorite"
            if favored
                b.lbl.text = "Remove from Favorites"
                b.ico.text = Chr(&hE87D)   ' favorite (filled heart)
                favInk = true
            else
                b.lbl.text = "Add to Favorites"
                b.ico.text = Chr(&hE87E)   ' favorite_border
            end if
        else if b.key = "addlist"
            if inList
                b.lbl.text = "In Lists"
                b.ico.text = Chr(&hE065)   ' playlist_add_check
            else
                b.lbl.text = "Add to List"
                b.ico.text = Chr(&hE03B)   ' playlist_add
            end if
        end if

        b.favInk = favInk
    end for
    ' The plate, the frame, the shadow, the ink and the lift, from the shared
    ' copy - see hbPaint in RatingBadges.brs. It reads the labels this loop has
    ' just written and knows nothing about what they say.
    '
    ' -1 WHEN THE SYNOPSIS HOLDS THE HIGHLIGHT, so no button is painted focused.
    ' The two stops are mutually exclusive and are repainted TOGETHER, on the
    ' same line, which is what makes it impossible to leave the yellow fill on a
    ' button the member has already walked off.
    idx = m.btnFocus
    if m.descFocus then idx = -1
    hbPaint(m.buttons, idx)
    dpPaintBlock(m.descFocus)
end sub

' The first secondary, which is where the synopsis hands focus back. A row with
' a primary and nothing else falls back to the primary rather than to an index
' that is not there. Same helper, same words, as the series page's.
function firstSecondary() as integer
    if m.buttons.count() > 1 then return 1
    return 0
end function

sub onInfo(event as object)
    try
        onInfoInner(event)
    catch e
        GuardFailed("movie/onInfo", e)
        ' SPINNER DOWN, same as onItem. This is the handler that builds most of
        ' the page, so it is the likeliest of the three to fault part-way; the
        ' member keeps whatever it managed to draw, and Back still works.
        '
        ' A PENDING PLAY IS DELIBERATELY NOT CARRIED OUT from here. The inner
        ' handler ends with flushPendingPlay(), and a fault above it means the
        ' category this film sits in was never resolved - so starting playback
        ' now would be starting it without the parental check that
        ' resolveCatFromInfo() exists to feed. The member's press is dropped
        ' instead, and pressing Play again re-asks properly.
        m.pendingPlay = invalid
        if m.spinner <> invalid
            m.spinner.visible = false
            m.spinner.control = "stop"
        end if
    end try
end sub

sub onInfoInner(event as object)
    res = event.getData()
    m.spinner.visible = false
    m.spinner.control = "stop"
    applyInfo(res)
    ' This page's own category rides on the SAME answer — read it, then carry
    ' out a Play that arrived while the details were still on the way.
    resolveCatFromInfo(res)
    flushPendingPlay()
end sub

sub applyInfo(res as dynamic)
    if res = invalid or res.ok <> true then return
    info = GetField(res.data, "info")
    if info = invalid then return

    ' ---- The metadata chips, Android's row ----------------------------------
    ' vod_detail_screen.dart:209-227 builds year, certification, rating, a
    ' runtime chip with a clock icon, and the source with its colour dot. The
    ' rating is NOT repeated here: it is a badge in the ratings strip below
    ' (GAP I1), and printing it twice is the same-words-twice problem the
    ' information table's own note calls out — the badge also says WHERE the
    ' number came from, which a bare chip never did.
    '
    ' Icons are Material codepoints ALREADY PROVEN in this package rather than
    ' looked up in a chart. A wrong codepoint draws the wrong picture and this
    ' repo has been burned by exactly that before (see the E1A8/E1B8 note in
    ' PlayerScreen.brs). Chr(&hE425) is `timer`, used by the player's sleep
    ' timer; Android's runtime chip uses `schedule`, whose codepoint is not
    ' proven here, and the two read the same at 28px across a room.
    m.chipDefs = []
    year = ToStr(GetField(info, "releasedate"))
    if Len(year) >= 4 then m.chipDefs.push({ text: Left(year, 4), icon: "", dot: "" })
    genre = ToStr(GetField(info, "genre"))
    if genre <> "" then m.chipDefs.push({ text: genre, icon: "", dot: "" })
    duration = ToStr(GetField(info, "duration"))
    if duration <> "" then m.chipDefs.push({ text: duration, icon: Chr(&hE425), dot: "" })
    ' The source, as one more short fact with its own colour as a DOT — the
    ' same dot the VOD chip row and every poster tag draw, and never a fill.
    ' Only when the caller actually named the source; a chip that cannot say
    ' which playlist a film is on is not worth a chip.
    srcName = msSourceChipName(m.top.item)
    if srcName <> "" then m.chipDefs.push({ text: srcName, icon: "", dot: hcSrcDotColor() })
    ' Drawn NOW, not left to refreshEndsAt() below: a film whose duration never
    ' arrives has no end-time chip, and refreshEndsAt returns early in that
    ' case, so waiting for it would leave the year and genre unbuilt on exactly
    ' the films that have the least to say.
    buildChips()

    ' ---- The Media Bar's backdrop ------------------------------------------
    ' NO NEW REQUEST. `backdrop_path` is already in this answer, right beside
    ' the plot and the cast this page has always read, and the phone has read
    ' it since day one (xtream_models.dart:412). This app never did, so the
    ' Media Bar has been faking a landscape picture out of a portrait poster.
    '
    ' Two things are done with it, and they cover the two ways a title gets
    ' into Continue Watching:
    '   * stamped onto the recents row NOW, if the member has one for this film
    '     already — which is what happens when they press More info on the
    '     Media Bar itself, so the panel's own button is what teaches it the
    '     picture. AttachRecentBackdrop creates nothing and reorders nothing,
    '     and writes nothing at all when the row already knew.
    '   * held for playMovie below, so a film played from this page is born
    '     with one instead of waiting for a second visit.
    '   * and, since this page became Android's hero, DRAWN AS THE HERO ITSELF.
    '     Until it arrives the hero wears the poster, which is Android's own
    '     fallback (`backdropUrl ?? posterUrl`) and looks equally soft there.
    '     Written only when there IS one: assigning "" would blank the poster
    '     standing in for it and leave the top of the page empty.
    m.backdrop = BackdropFromInfo(info)
    '     >>> BackdropUrl(), NOT the raw stored value. Fixed 2026-08-26 after a
    '     device build drew no hero at all and said why:
    '
    '         *** ERROR: Missing or invalid PHY: '/jjfLMwJa...Y.jpg'
    '
    '     BackdropFromInfo returns TMDB's SHORT STORED FORM — a leading slash
    '     and a file name, no host and no size — because that is the shape the
    '     registry holds (see NormalizeBackdrop, and the byte-budget note above
    '     it). Handing that to a Poster asks the box to load a path that is not
    '     a url. BackdropUrl() is the function that puts the host and the size
    '     back on, and MediaBar.brs:759 has always called it; this page was the
    '     one place that did not.
    '
    '     w1280, not the w500 default. This draws 1920 wide where the Media Bar
    '     draws 360, so w500 would be a 3.8x upscale — soft enough to look
    '     broken from a sofa, and quite possibly worse than the poster it
    '     replaces. w1280 is the size the panels themselves quote, and the
    '     extra bytes are affordable here because this is fetched once per page
    '     open rather than on every rotation.
    '
    '     THE DECODE CAP DOES NOT MOVE. loadWidth/loadHeight are pinned at
    '     1920 x 648 in the XML, so texture stays 1920 x 648 x 4 = 4,976,640
    '     bytes whatever size comes off the wire. The size above is a download
    '     and sharpness decision, not a memory one.
    if m.backdrop <> "" then m.backdropArt.uri = BackdropUrl(m.backdrop, "w1280")
    it = m.top.item
    if it <> invalid and m.backdrop <> ""
        AttachRecentBackdrop("movie", ToStr(it.streamId), m.itemSrc, m.backdrop)
    end if

    m.plot.text = ToStr(GetField(info, "plot"))
    ' The same words into the reading panel, and the film's own name as its
    ' heading so the member can see whose description they opened. Written on
    ' EVERY answer, both ways: dpSetText takes m.dpOn false on an empty
    ' synopsis, and dpPaintBlock then draws neither the frame nor the caption.
    heading = ""
    if m.top.item <> invalid then heading = ToStr(m.top.item.name)
    dpSetText(heading, m.plot.text)
    dpPaintBlock(m.descFocus)
    ' Written EVERY time, even when the panel sent no cast. It used to be
    ' written only when there was one, so opening a film with a cast and then
    ' one without left the first film's actors printed under the second film's
    ' plot. The plot and the meta line above have always been assigned
    ' unconditionally for the same reason; the cast line was simply missed.
    cast = ToStr(GetField(info, "cast"))
    if cast <> ""
        m.castLine.text = "Cast:  " + cast
    else
        m.castLine.text = ""
    end if

    m.duration = ToInt(GetField(info, "duration_secs"))
    ' The end-time reading needs the duration, so it is worked out here rather
    ' than up with the rest of the meta line.
    refreshEndsAt()
    movieData = GetField(res.data, "movie_data")
    if m.ext = "" then m.ext = ToStr(GetField(movieData, "container_extension"))

    ' LAST, because the Format row reads m.ext and the line above is what
    ' fills it in for a title that was opened without one.
    buildInfoTable(info)

    ' The badges the panel already paid for, drawn immediately — no request,
    ' nothing to wait for. The lookup that MIGHT add more to them goes out
    ' behind the drawn page.
    ' THE TMDB ID, KEPT FOR THE SUBTITLE SEARCH. The relay takes an id or a
    ' name, and a name is genuinely ambiguous - one film's id once answered
    ' with ten Dexter episodes, which is why the relay insists on a type. The
    ' panel hands the id over in this very answer and nothing was keeping it,
    ' so every subtitle search was a name search. Media-server titles have no
    ' panel id (MsInfoMap deliberately sends none), so those still search by
    ' name, which is the honest fallback rather than a wrong id.
    m.subsTmdb = rbClean(GetField(info, "tmdb_id"))
    m.subsYear = rbYearOf(info)
    rbApplyProviderBadges(info)
    rbStartLookup(info)
end sub

' ---- "Ends at 8:42 PM", on the details page ---------------------------------
'
' The wall-clock time this film would finish at if the member pressed the
' button the page is offering them, printed on the end of the meta line beside
' the runtime. Mason: "Alongside the existing runtime information, display:
' Ends at 8:42 PM".
'
' THE RULE IS A CROSS-PLATFORM CONTRACT, not a local choice. Android is
' building the same reading the same night with no reference implementation on
' either side, so the arithmetic is written down in
'
'     Wiki/Sync/Sync - End Time Contract (Android + Roku).md
'
' and its five points are marked (1)..(5) below. If any of this changes, change
' the note too or the phone and the television drift apart.
'
' >>> WHICH POSITION IS "position" ON A PAGE WHERE NOTHING IS PLAYING. The
' contract says remaining = duration - position, and a details page has no
' playback position. It uses THE RESUME POINT when there is one and zero when
' there is not, which is exactly what the page's own primary button would do:
' with a resume point that button says Resume, so the reading answers the
' question the button asks. A member sitting on "Play from Beginning" is
' therefore reading the Resume answer — that is a real limitation and it is
' left rather than papered over, because a reading that changed as the
' highlight moved down the stack would be worse. UNVERIFIED AGAINST ANDROID:
' Android's own details-page reading did not exist when this was written. <<<
'
' This is deliberately the ONLY place the reading appears on this page. The
' information table below already carries the runtime, and printing a second
' derived time in it is the same-words-twice problem that file's own note
' calls out.
sub onEndsTick()
    try
        refreshEndsAt()
    catch e
        GuardFailed("movie/onEndsTick", e)
        ' STOP THE TIMER after a caught fault. This is the one guard in this
        ' file that changes what the member sees, and it is the same call the
        ' Media Bar's rotation makes for the same reason.
        '
        ' THE REASON, PLAINLY: this timer repeats every 60 seconds for as long
        ' as the page is alive, and GuardFailed writes to the registry on every
        ' catch. A page that faults on every tick would spend the rest of the
        ' session writing to flash and would bury the one line that names the
        ' fault under an hour's worth of identical copies of it - which is the
        ' exact opposite of why these guards exist. The whole app only gets
        ' 16-32 KB of registry and a write past that fails silently, so this is
        ' not just noise, it is noise that can lose other settings.
        '
        ' AND IT IS THE 96C9BD SHAPE. A film page orphaned on the scene (see
        ' the block above, and AppShell.brs:431-445) keeps this timer running
        ' with nothing on screen, for as long as the app is open - eighty-three
        ' silent minutes, in that member's case. Stopping on the first fault is
        ' what keeps an orphan from logging forever.
        '
        ' WHAT THE MEMBER LOSES: the "Ends at 8:42 PM" chip stops keeping
        ' itself up to date and holds the last time it worked out. The rest of
        ' the page is untouched, and reopening the film starts the clock again.
        if m.endsTick <> invalid then m.endsTick.control = "stop"
    end try
end sub

sub refreshEndsAt()
    ' Nothing to show: the meta line goes back to year/genre/runtime alone
    ' rather than carrying a placeholder. The contract is explicit that an
    ' unknown duration means NO label, and plenty of provider VOD carries no
    ' duration at all — "Ends at --" is worse than nothing.
    ' Set BOTH ways: this runs once a minute on a page that can be handed a
    ' second film, and a stale reading is a wrong clock time rather than an
    ' obviously missing one.
    dur = m.duration
    if dur <= 0
        ' Already cleared: nothing to rebuild, and the timer fires every 60
        ' seconds whether or not anything moved.
        if m.endsMins = -1 then return
        m.endsMins = -1
        m.endsText = ""
        buildChips()
        return
    end if
    ' (2) RECOMPUTED FROM THE LIVE POSITION EVERY TIME. Never cached, never
    ' derived from where playback started. LoadResume is one registry read a
    ' minute on a page that is sitting still — not per bind and not per frame.
    posS = 0
    r = LoadResume(m.resumeKey)
    if r <> invalid
        posS = r.positionS
        ' The panel's duration_secs and the resume record's own duration can
        ' disagree; the resume record was measured by the player that actually
        ' opened the file, so it wins where it has one.
        if r.durationS > 0 then dur = r.durationS
    end if
    remain = dur - posS
    if remain < 0 then remain = 0

    ' (5) THE DEVICE'S OWN LOCAL CLOCK, not UTC and not a stream timestamp.
    ' roDateTime marks UTC; ToLocalTime shifts it to whatever the box is set
    ' to, including today's daylight-saving offset.
    dt = CreateObject("roDateTime")
    dt.Mark()
    dt.ToLocalTime()
    ' (1) NEAREST minute, not down. The +30 is the whole of that rule: 8:41:40
    ' has to read 8:42, and a platform that floors here disagrees with one that
    ' rounds on about half of all films. Worked in seconds since local midnight
    ' so `mod 1440` wraps a film that finishes after midnight and no epoch
    ' arithmetic is involved.
    ' (3) NOTHING FREEZES IT. "now" moves whether or not anything is playing,
    ' so a page left open for ten minutes reads ten minutes later. That is the
    ' contract's own rule for a paused film and it is the same rule here.
    daySecs = dt.GetHours() * 3600 + dt.GetMinutes() * 60 + dt.GetSeconds()
    endMins = Int((daySecs + remain + 30) / 60) mod 1440
    ' Only touch the Label when the minute has actually rolled. The timer fires
    ' every 60 seconds whether or not the answer moved, and a Label write is a
    ' relayout.
    if endMins = m.endsMins then return
    m.endsMins = endMins
    hh = Int(endMins / 60)
    mm = endMins mod 60
    mmTxt = mm.toStr()
    if mm < 10 then mmTxt = "0" + mmTxt

    ' (4) FOLLOW THE BOX'S OWN 12/24-HOUR SETTING. Neither is hard-coded.
    if mdClockIs24Hour()
        hhTxt = hh.toStr()
        if hh < 10 then hhTxt = "0" + hhTxt
        endsTxt = "Ends at " + hhTxt + ":" + mmTxt
    else
        ampm = " AM"
        h12 = hh
        if h12 >= 12
            ampm = " PM"
            h12 = h12 - 12
        end if
        if h12 = 0 then h12 = 12
        ' Mason's own example is 12-hour with a space: "Ends at 8:42 PM".
        endsTxt = "Ends at " + h12.toStr() + ":" + mmTxt + ampm
    end if
    ' One more chip on the end of the row, which is where the contract says it
    ' goes ("On the details page, alongside the runtime, as a chip"). NO ICON
    ' on purpose: the runtime chip beside it already wears the clock, and two
    ' clocks in a row say less than one clock and the word "Ends". An icon the
    ' member has to guess at is a support ticket.
    m.endsText = endsTxt
    buildChips()
end sub

' ---- The metadata chip row (Android's MetaChip, laid out by hand) -----------
'
' Roku has no Wrap widget, so the row is measured and centred here. ONE row:
' the facts are a year, a genre list, a runtime, an end time and a source name,
' and at UiFont(25) in JetBrains Mono's flat 0.6em that is nowhere near the
' 1824px the hero column has. If it ever were, the row would run off both
' edges rather than wrap — which is why the total is checked below and the
' gap tightens before that can happen.
'
' Torn down and rebuilt whole rather than updated in place. It runs on a page
' open and once a minute after that, it is at most six chips, and the
' alternative is per-chip geometry bookkeeping on a page that has no recycled
' cards to justify it.
sub buildChips()
    grp = m.chipsGrp
    while grp.getChildCount() > 0
        grp.removeChildIndex(0)
    end while

    defs = []
    for each d in m.chipDefs
        defs.push(d)
    end for
    ' The end-time chip, last, beside the runtime it belongs to. Absent
    ' entirely when the duration is unknown - the contract is explicit that
    ' there is no placeholder, and "Ends at --" is worse than no chip.
    if m.endsText <> "" then defs.push({ text: m.endsText, icon: "", dot: "" })
    if defs.count() = 0 then return

    ' The row itself - the measuring, the centring, the plate and the dot - is
    ' hcDrawChips in RatingBadges.brs, shared with the series page. This sub
    ' decides only WHICH chips this page shows.
    hcDrawChips(grp, defs)
end sub

' Is this box set to a 24-hour clock? roDeviceInfo.GetClockFormat answers "12h"
' or "24h" and has done since Roku OS 8.1 (2018). Anything else, a blank answer
' included, falls back to 12-hour, which is the format Mason asked for by name.
'
' PREFIXED md* ON PURPOSE. PlayerScreen.brs carries its own ClockIs24Hour() for
' the player's copy of this reading, and PlayerScreen.xml also includes
' Util.brs — so a shared helper under that name in Util.brs would be a
' duplicate definition and would stop the build. The two are worth folding
' together into one utility later, under ONE name, by whoever owns Util.brs.
' NOT VERIFIED ON HARDWARE.
function mdClockIs24Hour() as boolean
    di = CreateObject("roDeviceInfo")
    if di = invalid then return false
    return LCase(ToStr(di.GetClockFormat())) = "24h"
end function

sub playMovie(fromStart as boolean)
    it = m.top.item
    if it = invalid or m.provider = invalid then return
    ' Parental gate, ahead of everything else the press does — a refused play
    ' must not seed recommendations or touch Continue Watching either.
    if not parentalOkToPlay({ fromStart: fromStart }) then return
    ' A media server this app has not signed in to yet has no access token, so
    ' the stream would come back 401 and the member would read a decoder error
    ' about a file that is perfectly fine. Checked BEFORE the Kwick Picks seed
    ' and before Continue Watching, exactly like the parental refusal above: a
    ' press that cannot become playback must not leave a trace of a film the
    ' member never watched.
    if m.isMs and MsNeedsSignIn(m.provider)
        msCannotPlayNote("Kwick Player can't reach " + MsBrandLabel(m.provider) + " right now. Open Settings and sign in to your server again, then try this film once more.")
        return
    end if
    ' The address, and how to open it. Two shapes only: a panel's own url with
    ' the credentials baked into the path, or a media server's /Videos/{id}/
    ' stream with the token in a HEADER — never in the address, because an
    ' address ends up in watch history and in the diagnostic log, and a token
    ' in either of those is a token in a member's support email.
    hdrs = []
    if m.isMs
        url = MsStreamUrl(m.provider, ToStr(it.streamId))
        fmt = m.msFmt
        hdrs = MsHeaders(m.provider)
    else
        ' ONLY A PANEL CAN HAVE A STREAM ADDRESS BUILT HERE, and this is a
        ' POSITIVE test for the two kinds that can rather than a list of the kinds
        ' that cannot. A plain playlist has no server field at all, so Util.brs
        ' answers "" — but a member's own Jellyfin HAS a server, a username and a
        ' password, so the panel builder would hand back a real-looking address
        ' that is simply wrong, and the member would read a decoder error about
        ' something that is perfectly fine.
        '
        ' It is needed because m.provider is this film's OWN source only while
        ' its src token still resolves (onItem). When it does not, m.provider
        ' is left as whatever source happens to be active, which can be any
        ' kind at all.
        pt = ""
        if m.provider <> invalid then pt = LCase(ToStr(m.provider.ptype))
        if pt = "xtream" or pt = "kwicktv"
            url = XtreamVodUrl(m.provider, ToStr(it.streamId), m.ext)
        else
            url = ""
        end if
        fmt = StreamFormatFor(url, m.ext)
    end if
    ' LOG KEY FCF117 — Hisense 6Series-58, v1.0.39, 29 September 2026. What
    ' happened on the member's television, in plain words: they removed their
    ' source in Settings, a different one came back from the website on its own
    ' three seconds later, and the first thing they pressed was a leftover from
    ' the source they had just taken out. The app had nothing left to match it
    ' against, so it reached for the source that had just arrived — an
    ' ordinary playlist, which has no panel address to build a stream from —
    ' and the television froze with the spinner still turning and nothing on
    ' screen to say why. Util.brs now answers "" there instead of stopping the
    ' app; this is the half that tells the member something. Without it the
    ' press is simply dead: the player bails on an empty address before the
    ' Video node is ever handed anything to fail on, so no error and no retry
    ' ever happens, and the member is left watching a spinner turn forever.
    if url = ""
        KLog("movie", "movie detail:FCF117 refused play — no source on this box can open [" + ToStr(it.name) + "]")
        msCannotPlayNote("Kwick Player has no working source for this film. It was probably left behind by a source you removed. Check your sources under Settings, or pick another film.")
        return
    end if
    ' THE KWICK PICKS / CONTINUE WATCHING SEED WAS ABOVE THE ADDRESS, and has
    ' been moved down here. It sits BELOW the check for the same reason the
    ' parental refusal and the media-server sign-in refusal sit above
    ' everything: a press that cannot become playback must not leave Continue
    ' Watching showing a film the member never watched. LOG KEY FCF117.
    ' Seed for Kwick Picks recommendations.
    rec = { kind: "movie", id: ToStr(it.streamId), name: ToStr(it.name), icon: ToStr(it.icon), ext: m.ext }
    if m.itemSrc <> invalid then rec.src = m.itemSrc
    ' The landscape artwork for the Media Bar, off the get_vod_info answer this
    ' page already had (see applyInfo). Left off entirely when the details
    ' never arrived — PushRecentVod then keeps whatever the old row knew rather
    ' than blanking it.
    if m.backdrop <> "" then rec.bd = m.backdrop
    PushRecentVod(rec)
    startAt = 0
    if not fromStart
        resume = LoadResume(m.resumeKey)
        if resume <> invalid then startAt = resume.positionS
    end if
    m.player = m.top.getScene().createChild("PlayerScreen")
    m.player.titleText = ToStr(it.name)
    m.player.streamUrl = url
    m.player.streamFormat = fmt
    ' Empty for every panel and playlist source; the media-server identity
    ' header for a member's own server. The player appends these to the
    ' User-Agent it always sends rather than replacing it.
    m.player.streamHeaders = hdrs
    m.player.isLive = false
    m.player.resumeKey = m.resumeKey
    m.player.resumeFrom = startAt
    ' History metadata for KwickSync's hist push (Android shapes). The
    ' parent id is source-qualified like the media id.
    m.player.posterUrl = ToStr(it.icon)
    m.player.parentId = "movie:" + SrcQualifiedId(ToStr(it.streamId), m.itemSrc)
    ' What the subtitle search asks with. Empty is fine and means "search by
    ' name" - see the note where these are stashed.
    m.player.tmdbId = ToStr(m.subsTmdb)
    m.player.titleYear = ToStr(m.subsYear)
    m.player.observeField("closed", "onPlayerClosed")
    m.player.setFocus(true)
    m.player.start = true
end sub

' "Can't play this right now", in the shape this page already uses for the
' adult-category refusal below — one Dialog, one OK button, focus handed back
' to the page. Its own handler rather than the parental one's, because that
' one also clears m.pendingPlay and this refusal never sets it.
sub msCannotPlayNote(msg as string)
    KLog("movie", "movie detail:refused play - " + msg)
    note = CreateObject("roSGNode", "Dialog")
    note.title = "Can't Play This Right Now"
    note.message = msg
    note.buttons = ["OK"]
    note.observeField("buttonSelected", "onMsNoteClosed")
    m.top.getScene().dialog = note
end sub

sub onMsNoteClosed()
    try
        m.top.getScene().dialog.close = true
        m.top.setFocus(true)
    catch e
        GuardFailed("movie/onMsNoteClosed", e)
        ' FOCUS MUST END UP SOMEWHERE REAL. Dismissing the note is two
        ' statements - close it, then take the remote back - and a fault in the
        ' first leaves the member with a page that has no focus on it and a
        ' remote that does nothing.
        '
        ' THE DIALOG IS NOT CLOSED AGAIN FROM HERE, on purpose: that needs
        ' getScene(), and getScene() returning invalid on an orphaned page is
        ' the likeliest way the line above faults in the first place. A second
        ' go at it would fault INSIDE the catch, where nothing is listening,
        ' and that is a real crash instead of a caught one. Setting focus on
        ' m.top cannot fault, so that is all this does.
        m.top.setFocus(true)
    end try
end sub

sub onPlayerClosed()
    try
        onPlayerClosedInner()
    catch e
        GuardFailed("movie/onPlayerClosed", e)
        ' FOCUS MUST END UP SOMEWHERE REAL, the same call Home makes in the
        ' same handler. The inner version takes the player off the scene first
        ' and only then rebuilds the button stack and hands the remote back, so
        ' a fault in buildButtons() leaves the player gone and focus nowhere -
        ' the film page on screen with a remote that does nothing at all. This
        ' is not the focusedChild observer, so moving focus from here cannot
        ' recurse.
        m.top.setFocus(true)
    end try
end sub

sub onPlayerClosedInner()
    if m.player <> invalid
        m.top.getScene().removeChild(m.player)
        m.player = invalid
    end if
    ' Returning may have created/cleared a resume point — rebuild the stack.
    buildButtons()
    m.top.setFocus(true)
end sub

' ---- The D-pad chain, hand-wired over a 2-row grid --------------------------
'
' THE SHAPE. Index 0 is the primary and is alone on row 0; indices 1..N-1 are
' the secondaries on row 1, left to right. buildButtons() guarantees that and
' nothing else here depends on which buttons exist, so a film with a resume
' point (five buttons) and one without (four) walk identically.
'
' MIRRORS THE SIBLING PAGE ON PURPOSE. SeriesDetailScreen.brs onKeyEvent walks
' its own 2x3 grid with explicit per-index left/right/up/down and STAYS PUT
' rather than jumping diagonally where there is nothing beside a button ("Add
' to List has nothing beside it and stays put"). This follows that shape rather
' than inventing a second one - two different 2-D chains on two sibling pages
' is how the next person breaks one while fixing the other.
'
' THE WALK, and every square is reachable in both directions:
'
'     from        up      down       left      right
'     0 primary   0       1          0         0
'     1 (first)   0       synopsis   1         2
'     2..N-2      0       synopsis   i-1       i+1
'     N-1 (last)  0       synopsis   i-1       N-1
'     synopsis    1       synopsis   (stays)   (stays)
'
' Down from the primary always lands on index 1; up from ANY secondary always
' lands on the primary. So from any square the primary is one or two presses
' away, and from the primary every secondary is down-then-left/right. Nothing
' traps: the only presses that do nothing are the ones at an edge, which leave
' the highlight exactly where it was rather than moving it somewhere unexpected.
'
' THE SYNOPSIS IS THE THIRD ROW (2026-08-27), and it is geometrically where it
' looks: below the button rows, in the left-hand column under the fold. Down out
' of any secondary reaches it; Up out of it returns to index 1, the row it came
' down from. It is only a stop AT ALL when there is something to read - m.dpOn -
' so a film whose details never arrived has exactly the chain it always had.
'
' OK on it opens the reading panel; while that panel is up dpKey() swallows
' every key, so Back collapses the panel and only closes the page once it is
' shut. Left and right on the synopsis stay put: there is nothing beside it.
'
' NO REMEMBERED COLUMN. Down from the primary could return to whichever
' secondary was last used, and that would be a shade nicer to use, but the
' Series page does not do it and this is not the place to introduce a second
' behaviour. Deterministic beats clever on a chain two people have to maintain.
'
' BACK IS CHECKED FIRST and always closes the page. This is a scene overlay
' that closes by setting `closed`, and a 2-D handler that swallowed Back would
' strand the member on the page with no way out.
'
' THE PARENTAL GATE IS UNTOUCHED: it hangs off playMovie() -> parentalOkToPlay()
' on the OK press below and reads nothing from m.btnFocus, so the shape of the
' grid cannot reach it.
function onKeyEvent(key as string, press as boolean) as boolean
    try
        return onKeyEventInner(key, press)
    catch e
        GuardFailed("movie/onKeyEvent", e)
    end try

    ' TRUE, NOT FALSE, ON A CAUGHT FAULT - the channel page's choice, and NOT
    ' Home's or the Media Bar's. The difference is where the key would go next.
    ' This page is a SCENE CHILD, not a child of the shell: AppShell is its
    ' sibling, not its ancestor, so a key this function returns false for does
    ' not reach AppShell's Back handler at all. It goes to AppScene, which has
    ' no onKeyEvent (AppShell.brs:1070 says so in as many words), and from
    ' there to the firmware, which CLOSES THE CHANNEL. So returning false here
    ' would turn one caught fault into the member being thrown out of the app.
    '
    ' BUT SWALLOWING BACK ON ITS OWN WOULD STRAND THEM, which is the trap this
    ' file's own D-pad note warns about: "a 2-D handler that swallowed Back
    ' would strand the member on the page with no way out". The only way off
    ' this page is setting `closed`, which is what every Back branch below
    ' does. So the catch does it too.
    '
    ' That one line is also why this is better than the bare `return true` on
    ' ChannelDetailScreen.brs:2094 - worth lifting over there, but that file
    ' was not in this job.
    '
    ' A KEY-UP IS STILL RETURNED FALSE, exactly as the inner version's first
    ' line does, so a fault cannot start swallowing the release half of every
    ' press. In practice that line cannot fault, but the contract this function
    ' advertises should not change just because something below it broke.
    if not press then return false
    if key = "back" then m.top.closed = true
    return true
end function

function onKeyEventInner(key as string, press as boolean) as boolean
    if not press then return false

    ' THE READING PANEL IS ASKED FIRST and swallows everything while it is up,
    ' so Back collapses it and nothing behind it can move underneath the member.
    if dpKey(key) then return true

    ' ---- the synopsis, when the highlight is on it -------------------------
    if m.descFocus
        if key = "back"
            m.top.closed = true
        else if key = "OK"
            dpShow()
        else if key = "up"
            m.descFocus = false
            m.btnFocus = firstSecondary()
            redrawButtons()
        end if
        ' down / left / right stay put: there is nothing below or beside it.
        return true
    end if

    if key = "back"
        m.top.closed = true
        return true
    else if key = "down"
        ' Row 0 -> row 1 at its left end; row 1 -> the synopsis, when there is
        ' one. A secondary with no synopsis under it has nothing below it.
        if m.btnFocus = 0
            if m.buttons.count() > 1
                m.btnFocus = 1
                redrawButtons()
            end if
        else if m.dpOn = true
            m.descFocus = true
            redrawButtons()
        end if
        return true
    else if key = "up"
        ' Any secondary -> the primary. The primary has nothing above it.
        if m.btnFocus > 0
            m.btnFocus = 0
            redrawButtons()
        end if
        return true
    else if key = "left"
        ' Within row 1 only. Index 1 is the left end and stays put; the primary
        ' has nothing beside it and stays put.
        if m.btnFocus > 1
            m.btnFocus = m.btnFocus - 1
            redrawButtons()
        end if
        return true
    else if key = "right"
        if m.btnFocus >= 1 and m.btnFocus < m.buttons.count() - 1
            m.btnFocus = m.btnFocus + 1
            redrawButtons()
        end if
        return true
    else if key = "OK"
        b = m.buttons[m.btnFocus]
        if b.key = "resume"
            playMovie(false)
        else if b.key = "begin" or b.key = "play"
            playMovie(true)
        else if b.key = "favorite"
            it = m.top.item
            fav = { kind: "movie", id: ToStr(it.streamId), name: ToStr(it.name), icon: ToStr(it.icon), ext: m.ext }
            if m.itemSrc <> invalid then fav.src = m.itemSrc
            ToggleFavoriteVod(fav)
            redrawButtons()
        else if b.key = "markseen"
            toggleMovieSeen()
        else if b.key = "addlist"
            openAddToList()
        end if
        return true
    end if
    return false
end function

' ---- Mark as Watched (GAP D5) -----------------------------------------------
'
' Android's button on the film page (vod_detail_screen.dart:303). There it
' only clears the film out of Continue Watching, and it is only offered when
' there is a position to clear. Here it also writes the finished mark, which
' is the thing that survives having no position — the whole reason the mark
' store exists (Store.brs: "has no resume point" cannot be told apart from
' "never started it").
'
' Because the mark outlives the position, the button is always on the stack
' and says which way it will go. A stack that gained and lost a row depending
' on state would also renumber m.buttons under the member's thumb, and the
' up/down handler indexes straight into it.
'
' No confirmation: unlike the series page's version this touches exactly one
' title, and the very next press of the same button puts it back.
' The parent id the PHONE expects for a film: "movie:<src-qualified id>".
' Deliberately not derived from movieSeenKey() by string surgery - both are
' built from the same two pieces so a change in Store.brs cannot desynchronise
' them silently.
function moviePresenceParent() as string
    it = m.top.item
    if it = invalid then return ""
    id = ToStr(it.streamId)
    if id = "" then return ""
    return "movie:" + SrcQualifiedId(id, m.itemSrc)
end function

function movieSeenKey() as string
    it = m.top.item
    if it = invalid then return ""
    ' Character for character the resume key this screen already holds —
    ' Store.brs builds SeenKeyMovie and ResumeKeyMovie from the same pieces
    ' on purpose — but asked for by name, so a change there cannot quietly
    ' desynchronise the two here.
    return SeenKeyMovie(ToStr(it.streamId), m.itemSrc)
end function

sub toggleMovieSeen()
    key = movieSeenKey()
    if key = "" then return
    if IsSeen(key)
        UnmarkSeen(key)
        ' The position went when the mark was written, so there is nothing to
        ' clear on the way back — and the film returns to a plain "Play",
        ' which is honest: nothing knows where it got to any more.
        KLog("movie", "movie detail:marked as unwatched")
        ' And off their own Trakt and Simkl accounts, whichever they signed in
        ' to. See movieTrackerMark below: nothing here waits on it.
        movieTrackerMark(false)
    else
        ' A film's parent DOES merely name the film again — but the phone
        ' writes it anyway (`parentId: 'movie:$ref0'`,
        ' vod_detail_screen.dart:187) and its "mark unwatched" deletes BY
        ' parent (`unmarkParent`, watched_items_repository.dart:162). A mark
        ' sent up without one is therefore a mark the phone can never clear.
        ' So it is sent, redundant or not: agreeing with the other end beats
        ' being tidy. Same shape the phone uses, built from the same pieces
        ' the seen key is.
        MarkSeen(key, moviePresenceParent())
        ' The Continue Watching half of what the label promises.
        ClearResume(key)
        KLog("movie", "movie detail:marked as watched")
        ' And on their own Trakt and Simkl accounts, whichever they signed in
        ' to. See movieTrackerMark below: nothing here waits on it.
        movieTrackerMark(true)
    end if
    ' Rebuild rather than repaint: clearing the position turns a Resume +
    ' Play from Beginning pair back into a single Play, which is a different
    ' stack, not a different label.
    buildButtons()
    ' And put the remote back on the button that was just pressed. The stack
    ' is one row shorter than it was, so the INDEX it had is now somebody
    ' else's — leaving m.btnFocus alone would silently move the member onto
    ' Add to Favorites.
    for i = 0 to m.buttons.count() - 1
        if m.buttons[i].key = "markseen"
            m.btnFocus = i
            redrawButtons()
            return
        end if
    end for
end sub

' ---- The same tick on the member's OWN Trakt and Simkl accounts (GAP D5) -----
'
' The second, independent errand on the Mark as Watched button. The local mark
' above is unchanged and is still what makes the tick appear; this files the
' same thing on whichever tracking accounts the member has signed in to, and
' takes it off again when they untick.
'
' EVERYTHING ABOUT IT LIVES IN TrackerMarks.brs — which services, which switch,
' what is sent, what is logged. This is only the film page saying what it has.
' It returns immediately: the request goes out on AddOnTask's own thread and
' nothing on this page ever waits for it or is told when it fails.
'
' ONLY REACHED FROM THE BUTTON. The app's own automatic mark at 95% is written
' in the player and never comes through here, and the player already sends its
' own scrobbles — so a film is never filed twice by both halves. See the header
' of TrackerMarks.brs for the one case that does overlap.
'
' NO ID, NOTHING SENT, NOTHING SAID. m.subsTmdb is the id the panel gave with
' this film's details, the same one the subtitle search and the player use. A
' media-server title has none, and a film ticked in the second before the
' details answer arrives has none yet either — in both cases nothing goes to
' either service and the member is told nothing, because guessing from a name
' would mark the wrong film on their real account.
sub movieTrackerMark(watched as boolean)
    it = m.top.item
    if it = invalid then return
    TrackerMarkMovie(m.top.getScene(), watched, ToStr(m.subsTmdb), ToStr(it.name), ToStr(m.subsYear))
end sub

sub openAddToList()
    it = m.top.item
    m.addList = m.top.getScene().createChild("AddToListScreen")
    itemAA = { kind: "movie", id: ToStr(it.streamId), name: ToStr(it.name), icon: ToStr(it.icon), ext: m.ext }
    if m.itemSrc <> invalid then itemAA.src = m.itemSrc
    m.addList.item = itemAA
    m.addList.observeField("closed", "onAddListClosed")
    m.addList.setFocus(true)
end sub

sub onAddListClosed()
    try
        onAddListClosedInner()
    catch e
        GuardFailed("movie/onAddListClosed", e)
        ' FOCUS BACK ON THIS PAGE. The list picker is taken off the scene
        ' first and the remote handed back last, so a fault in redrawButtons()
        ' leaves the picker gone and focus nowhere.
        m.top.setFocus(true)
    end try
end sub

sub onAddListClosedInner()
    if m.addList <> invalid
        m.top.getScene().removeChild(m.addList)
        m.addList = invalid
    end if
    redrawButtons()
    m.top.setFocus(true)
end sub

' ---- Information table -------------------------------------------------------
'
' Android's MetadataInfoTable (vod_detail_screen.dart:393) — the little
' key/value block at the bottom of a film's page. Roku showed the plot and a
' cast line and nothing else, so "is this the 4K one or the 720p one" had no
' answer without starting playback.
'
' NO NEW REQUEST. Every field below is already in the get_vod_info answer
' this screen fetches in onItem; applyInfo was reading four of them out of
' the same `info` map and throwing the rest away. The table is built from
' that map, at the end of applyInfo, and nothing about WHEN applyInfo runs
' or what it may assume has changed.
'
' WHAT ANDROID SHOWS AND WE DON'T:
'   Genres  — we have it (info.genre), but the meta chip line at the top of
'             this screen already prints it, and the same words twice on one
'             page at ten feet reads as a bug. Left out on purpose.
'   Writers /
'   Studio  — not in get_vod_info at all. On Android those come from the
'             TMDB title-metadata lookup, which this app has no port of and
'             which would be the extra request we are avoiding.
'
' THE RAGGED CASE IS THE NORMAL CASE. Most Xtream panels fill these in
' inconsistently — plenty send director and nothing else, plenty send an
' empty list where the ffprobe map should be, and plenty write the literal
' string "null" or "N/A" into a field they have no value for. So every row
' is optional: a row that has no value is never created, the whole block
' (rule included) stays empty if none of them have one, and the rows that DO
' exist close up from the top with no gap where a missing one would have
' been. There is no fixed slot for anything.
'
' Focus is untouched: Labels and Rectangles cannot take focus, the group is
' not in the button stack, and onKeyEvent is not aware of it.

' Geometry. The group sits at [100, 712] (XML) — 32px under the poster,
' which ends at 680 — and runs to the bottom of the safe area, so 308px of
' room. 400 wide keeps it inside the poster column with a gutter before the
' plot at x=520.
' 800, where this was 400. The table used to live in the left column under a
' 360px poster; on Android's hero layout there is no poster and no left column,
' and the table sits in the RIGHT half of the space below the hero (x=1020,
' out to the 1820 title-safe edge). Twice the width means fewer values need a
' second line, which is what mdValueLines() below is guessing at.
function infoTableW() as integer
    return 800
end function

sub clearInfoTable()
    grp = m.top.findNode("infoTable")
    if grp = invalid then return
    while grp.getChildCount() > 0
        grp.removeChildIndex(0)
    end while
end sub

sub buildInfoTable(info as dynamic)
    clearInfoTable()
    grp = m.top.findNode("infoTable")
    if grp = invalid then return

    ' Gather first, draw second — the row count decides whether anything is
    ' drawn at all, including the rule.
    rows = []
    director = mdClean(GetField(info, "director"))
    if director <> "" then rows.push({ k: "Director", v: director })
    line = mdVideoLine(info)
    if line <> "" then rows.push({ k: "Video", v: line })
    line = mdAudioLine(info)
    if line <> "" then rows.push({ k: "Audio", v: line })
    line = mdBitrateLine(info)
    if line <> "" then rows.push({ k: "Bitrate", v: line })
    fmt = mdClean(m.ext)
    if fmt <> "" then rows.push({ k: "Format", v: UCase(fmt) })

    if rows.count() = 0
        ' Nothing drawn — not even the rule. A panel that sends none of this
        ' leaves the space under the poster exactly as empty as it was
        ' before this feature existed.
        KLog("movie", "movie detail:no information table - this panel sent none of the technical fields")
        return
    end if

    ' A hairline in the existing elevated-surface grey, so the block reads as
    ' its own thing under the poster instead of floating text. Drawn only
    ' when there is something to head.
    rule = grp.createChild("Rectangle")
    rule.width = infoTableW()
    rule.height = 2
    rule.color = m.theme.surfaceElevated
    rule.translation = [0, 0]

    ' Key column left, value column right, both in the cast line's size.
    ' Key in the secondary grey and value in the primary white is the same
    ' pairing the rest of the screen uses (meta/cast secondary, plot/title
    ' primary) — no new colour, no new size.
    keyW = 130
    valX = 138
    valW = infoTableW() - valX
    ' 222, where this was 342. The table's group now starts at y=780 - the hero
    ' grew by 120 to pay for the wordmark - and the right-hand column still runs
    ' to the 1018 title-safe edge, so the budget is 1018 - 780 less a little
    ' bottom air. Same arrangement as before, a fixed height budget the table
    ' stops cleanly inside, at the new geometry.
    '
    ' THE ROWS CLOSED UP TO PAY FOR IT. The head clearance is 16 where it was
    ' 22 and the gap between rows is 6 where it was 10, so the five fields this
    ' table can show cost 16 + 5 x 40 = 216 and still fit inside 222. What DOES
    ' now drop off the bottom is the fifth row on a film whose director credit
    ' wraps to two lines - 16 + 78 + 4 x 40 = 254. The loop below stops cleanly
    ' and logs how many of how many it drew, which is what that log line has
    ' always been for.
    limit = 222
    shown = 0
    y = 16
    for each r in rows
        h = 34 * mdValueLines(r.v, valW)
        ' Ran out of column. Stop cleanly rather than draw off the bottom of
        ' the screen; with the five rows above this cannot trigger unless two
        ' of them wrap, and a cut-off row would look far worse than a short
        ' table.
        if y + h > limit then exit for
        kl = grp.createChild("Label")
        kl.translation = [0, y]
        kl.width = keyW
        kl.height = 34
        kl.font = m.infoFont
        kl.color = m.theme.textSecondary
        kl.maxLines = 1
        kl.text = r.k
        vl = grp.createChild("Label")
        vl.translation = [valX, y]
        vl.width = valW
        vl.height = h
        vl.font = m.infoFont
        vl.color = m.theme.textPrimary
        vl.wrap = true
        vl.maxLines = 2
        vl.lineSpacing = 4
        vl.text = r.v
        y = y + h + 6
        shown = shown + 1
    end for
    KLog("movie", "movie detail:information table - " + shown.toStr() + " of " + rows.count().toStr() + " field(s) drawn")
end sub

' How tall a value is, in lines. There is no way to measure a Label before
' it renders, so this is an estimate, and the answer only has to be right
' enough to pick one line or two — the Label itself does the real wrapping
' and is capped at two lines either way. Only Director is ever long enough
' to matter.
'
' 14, WHERE THIS WAS 12, AND IT HAD TO CHANGE. The old constant was tuned to
' Roboto-Medium at 23, which averaged a little over 12px a character.
' JetBrains Mono at 23 is a flat 0.6em, i.e. 13.8px, so 12 would have
' UNDER-estimated every value: a long director credit that needs two lines
' would have been given one line of height, the row below would have been
' drawn on top of its second line, and nothing would have looked obviously
' broken — which is the worst kind of wrong. Rounded UP to 14 rather than to
' 13.8 on purpose: over-estimating costs at most one unnecessary two-line row
' and the `limit` check below stops the table cleanly, while under-estimating
' overlaps text.
'
' This is one of only two hard-coded pixels-per-character estimates left in
' the app; the other is the fallback in rbTextWidth (RatingBadges.brs), which
' is 15 and therefore still conservative for mono at 23 and 24.
function mdValueLines(v as string, w as integer) as integer
    if Len(v) * 14 > w then return 2
    return 1
end function

' A panel with nothing to say for a field very often fills it in anyway —
' with "null", "N/A", "0", "unknown" or a run of spaces. Every one of those
' has to read as ABSENT, or the table grows a row that says nothing, which
' is exactly the broken-looking gap this is supposed to avoid.
function mdClean(v as dynamic) as string
    s = ToStr(v).trim()
    if s = "" then return ""
    l = LCase(s)
    if l = "null" or l = "n/a" or l = "na" or l = "none" or l = "unknown" or l = "undefined" or l = "0" or l = "-" then return ""
    return s
end function

' info.video / info.audio are ffprobe maps, but a panel with nothing to
' report sends an empty LIST there instead, and a few send a list of streams.
' Take the map, or the first map in a list; anything else answers invalid and
' every field read off it comes back empty, which collapses the row.
function mdSubMap(info as dynamic, key as string) as dynamic
    v = GetField(info, key)
    if v = invalid then return invalid
    if type(v) = "roAssociativeArray" then return v
    if type(v) = "roArray"
        if v.count() > 0 and type(v[0]) = "roAssociativeArray" then return v[0]
    end if
    return invalid
end function

' ffprobe's codec names, turned into what a member recognises. Same table as
' Android's _codecName so the two apps say the same words about the same file.
function mdCodecName(codec as string) as string
    c = LCase(mdClean(codec))
    if c = "" then return ""
    if c = "h264" or c = "avc" then return "H.264"
    if c = "hevc" or c = "h265" then return "HEVC (H.265)"
    if c = "av1" then return "AV1"
    if c = "eac3" then return "EAC3"
    if c = "ac3" then return "AC3"
    if c = "aac" then return "AAC"
    if c = "mp3" then return "MP3"
    if c = "dts" then return "DTS"
    return UCase(c)
end function

' "1080p (H.264)". Either half may be missing — height alone gives "1080p",
' codec alone gives "H.264", neither gives nothing and the row is skipped.
function mdVideoLine(info as dynamic) as string
    v = mdSubMap(info, "video")
    if v = invalid then return ""
    res = ""
    h = ToInt(GetField(v, "height"))
    if h > 0 then res = h.toStr() + "p"
    codec = mdCodecName(ToStr(GetField(v, "codec_name")))
    ' "HEVC (H.265)" inside "1080p (...)" would nest brackets, so the video
    ' line takes the short head only. The audio row, where it stands alone,
    ' keeps the full name.
    p = Instr(1, codec, " (")
    if p > 0 then codec = Left(codec, p - 1)
    if res = "" then return codec
    if codec = "" then return res
    return res + " (" + codec + ")"
end function

' ---- The soundtrack's language, on the Audio row (JB-30, from Windows W-216)
'
' The Windows film page now leads this row with the language a member will
' actually HEAR - "English, Spanish · EAC3 5.1" - and this is the same row
' saying the same words. Every figure comes out of the get_vod_info answer this
' page ALREADY has: no second request, and nothing extra asked of the panel.
'
' A FILM WHOSE PANEL NAMES NO LANGUAGE MUST READ EXACTLY AS IT DID BEFORE.
' That is the part most likely to go wrong, so it is the rule every function
' below is written around: each one answers "" or an empty list when the panel
' said nothing, mdAudioLine then returns the same "EAC3 5.1" it has always
' returned, and there is no empty prefix, no stray separator and never the
' word "Unknown" on screen.
'
' WHAT WE NOW KNOW (2026-10-18, JB-31). Eleven films were opened on Mason's
' KwickTV Xtream panel and every one of them logged "no audio field" - that
' panel sends no technical block at all, so no Xtream film will ever show a
' language here, and there is no point running that experiment again.
' A member's own Jellyfin or Emby DOES name the language of every soundtrack,
' and MsTechInfo (MediaServer.brs) now carries it through in the shape these
' functions read. Media-server films are the whole audience for this row.
' It stays strictly additive: with no language in the answer, not one pixel
' of this row changes.

' A key read WITHOUT caring about its capitals.
'
' ParseJson hands back a CASE-SENSITIVE map, so GetField(tags, "language")
' finds nothing on a file whose tag is spelled LANGUAGE - which is what a
' number of Matroska muxers write. At least four live bugs in this codebase
' have come from exactly that mismatch, so the audio tags are read the careful
' way rather than the short way.
function mdCaseField(obj as dynamic, key as string) as dynamic
    if type(obj) <> "roAssociativeArray" then return invalid
    want = LCase(key)
    for each k in obj
        if LCase(k) = want then return obj[k]
    end for
    return invalid
end function

' Every audio stream the panel described, the file's DEFAULT one first.
'
' mdSubMap above keeps the first map and throws the rest away, which is the
' right answer for one codec and one channel count but cannot say "English,
' Spanish". This is the same field read as the list it sometimes is.
'
' The reorder is ffprobe's own disposition.default, the flag that says which
' soundtrack a player starts on. Where nothing is marked - and on the single
' map nearly every panel sends - the panel's own order is kept untouched,
' because then its first IS the one that plays.
function mdAudioStreams(info as dynamic) as object
    v = GetField(info, "audio")
    out = []
    if v = invalid then return out
    if type(v) = "roAssociativeArray"
        out.push(v)
        return out
    end if
    if type(v) <> "roArray" then return out
    for each s in v
        if type(s) = "roAssociativeArray" then out.push(s)
    end for
    best = -1
    for i = 0 to out.count() - 1
        if ToInt(mdCaseField(mdCaseField(out[i], "disposition"), "default")) = 1
            best = i
            exit for
        end if
    end for
    if best <= 0 then return out
    ordered = [out[best]]
    for i = 0 to out.count() - 1
        if i <> best then ordered.push(out[i])
    end for
    return ordered
end function

' One stream's language as a bare code ("eng"), or "" when it names none.
'
' ffprobe files it under tags.language; a hand-built panel may put it beside
' codec_name instead, so both are tried. A region is dropped ("pt-BR" is
' Portuguese, "zh_cn" is Chinese) because the region is not part of the
' language and is not what the row is naming.
'
' ISO 639's "there is no language here" codes answer "" on purpose. LangName
' turns "und" into the word "Unknown", and a row reading "Unknown · EAC3
' 5.1" would be worse than the row we already have.
function mdAudioLang(a as dynamic) as string
    code = ToStr(mdCaseField(mdCaseField(a, "tags"), "language")).trim()
    if code = "" then code = ToStr(mdCaseField(a, "language")).trim()
    if code = "" then return ""
    code = LCase(code)
    p = Instr(1, code, "-")
    if p > 0 then code = Left(code, p - 1)
    p = Instr(1, code, "_")
    if p > 0 then code = Left(code, p - 1)
    if code = "" then return ""
    if code = "und" or code = "unk" or code = "mis" or code = "mul" then return ""
    if code = "zxx" or code = "qaa" or code = "none" then return ""
    return code
end function

' The languages this film's soundtracks name, as words, the default first.
'
' LangName (Util.brs) is the app's ONE code-to-word table - the same one the
' player's own audio and subtitle menus read - so the film page and the player
' call the same soundtrack by the same name. A code it has no word for is
' shown as written, which is also what Windows does.
'
' THREE AT MOST, AND THAT IS A ROKU-ONLY LIMIT. This table has a fixed height
' budget (see `limit` in buildInfoTable): a value that wraps to two lines costs
' 40px, which is exactly the Format row at the bottom. Three of the longest
' names plus the sound format is 45 characters, inside the one-line width;
' four would wrap and silently push Format off the page. The default is first,
' so the three shown are the three that matter.
'
' A language is listed once. Two English tracks - the film and its commentary -
' are one language to a member reading this row.
function mdAudioLangs(info as dynamic) as object
    out = []
    for each a in mdAudioStreams(info)
        if out.count() >= 3 then exit for
        code = mdAudioLang(a)
        if code <> ""
            nm = LangName(code)
            seen = false
            for each had in out
                if had = nm then seen = true
            end for
            if not seen then out.push(nm)
        end if
    end for
    return out
end function

' "English, Spanish · EAC3 5.1", or plain "EAC3 5.1" where the panel names
' no language - which is the row exactly as it was before JB-30.
'
' The codec and the channel count still come from mdSubMap, i.e. the FIRST map
' the panel sent, untouched. They were deliberately not moved onto the
' default-first stream: on an answer with no languages in it that could change
' which codec is printed, and "no language means no change" is the one promise
' this job has to keep. Nearly every panel sends a single map, where the two
' are the same stream anyway.
'
' Either half alone is still a row. Language with no codec prints the language
' (Windows does the same); neither prints nothing and buildInfoTable drops the
' row, as it always has.
function mdAudioLine(info as dynamic) as string
    fmt = ""
    a = mdSubMap(info, "audio")
    if a <> invalid
        codec = mdCodecName(ToStr(GetField(a, "codec_name")))
        if codec <> ""
            ch = ToInt(GetField(a, "channels"))
            layout = ""
            if ch = 1 then layout = "1.0"
            if ch = 2 then layout = "2.0"
            if ch = 6 then layout = "5.1"
            if ch = 8 then layout = "7.1"
            if layout = "" and ch > 0 then layout = ch.toStr() + " ch"
            fmt = codec
            if layout <> "" then fmt = codec + " " + layout
        end if
    end if

    langs = mdAudioLangs(info)

    ' ---- THE PROBE, AND IT IS MEANT TO BE READ ----------------------------
    ' One line per film page opened, in the console and in Export Logs, saying
    ' what this source actually put in info.audio: the SHAPE (one map, a list,
    ' or nothing) and the raw codes found in it, before LangName touches them.
    ' A star after a code means that soundtrack is the one the file says to
    ' start on, and the codes are printed in the order the row will use them,
    ' so the star belongs on the FIRST code; no star anywhere means nothing
    ' was flagged and the source's own order was kept.
    ' Xtream panels are settled - they send nothing. This is now here to show
    ' that a member's Jellyfin or Emby does.
    ' It prints field names, never anything a member typed, and KLog scrubs
    ' secrets on the way through either way.
    ' TAKE IT OUT once the question is settled - it has no other job.
    rawAudio = GetField(info, "audio")
    shape = "no audio field"
    if type(rawAudio) = "roAssociativeArray" then shape = "one map"
    if type(rawAudio) = "roArray"
        howMany = rawAudio.count()
        shape = howMany.toStr() + " in a list"
    end if
    codes = ""
    for each s in mdAudioStreams(info)
        one = ToStr(mdCaseField(mdCaseField(s, "tags"), "language")).trim()
        if one = "" then one = ToStr(mdCaseField(s, "language")).trim()
        if one = "" then one = "(none)"
        ' The same test mdAudioStreams sorts on, so this reports the truth
        ' about whether the flag was understood rather than whether it arrived.
        if ToInt(mdCaseField(mdCaseField(s, "disposition"), "default")) = 1 then one = one + "*"
        if codes <> "" then codes = codes + ", "
        codes = codes + one
    end for
    if codes = "" then codes = "(no streams)"
    KLog("movie", "movie detail:audio field - " + shape + "; language tag(s): " + codes)

    if langs.count() = 0 then return fmt
    names = ""
    for each nm in langs
        if names <> "" then names = names + ", "
        names = names + nm
    end for
    if fmt = "" then return names
    return names + " " + Chr(&hB7) + " " + fmt
end function

' "4.4 Mbps". info.bitrate is kilobits per second — the same reading Android
' takes, so a title reports the same number on both apps. Integer arithmetic
' for the one decimal place: Str() on a float pads and rounds unpredictably.
function mdBitrateLine(info as dynamic) as string
    kbps = ToInt(GetField(info, "bitrate"))
    if kbps <= 0 then return ""
    if kbps < 1000 then return kbps.toStr() + " kbps"
    whole = Int(kbps / 1000)
    tenth = Int((kbps - whole * 1000) / 100)
    return whole.toStr() + "." + tenth.toStr() + " Mbps"
end function

' ---- Rating badges (GAP I1) --------------------------------------------------
'
' MOVED. The whole strip - the label -> artwork mapping, the merge, the cache
' key, the memory gate and the drawing - is in source/utils/RatingBadges.brs
' now, included by this component's XML and sharing this component's `m`
' exactly as it did when it lived here. It moved when the owner asked for the
' same strip on the series page: two copies of a merge rule and a cache key is
' how the two pages quietly drift apart, and the cache key in particular is the
' one thing that MUST match, since both pages file into the same file on disk.
'
' This screen's half of it is the block in init() - the lane, the rows, the
' font, the log name - plus these two calls, which have not moved:
'
'   rbApplyProviderBadges(info)   the certificate and the panel's own score,
'                                 drawn the instant the details land
'   rbStartLookup(info)           ONE request, behind an already-drawn page,
'                                 cached for a week, NEVER per tile
'
' Both are still called from the bottom of applyInfo, in that order, and the
' strip is still emptied in onItem before either can run.

' ---- Parental gate -----------------------------------------------------------
'
' The category strip on the Movies screen hides or gates a locked category,
' but this page is also reached from a favorite, from Continue Watching, from
' a saved list and from a deep link — none of which ever passed that strip. So
' the last word on whether a locked film plays belongs here, next to the play
' call, the same way GuideScreen keeps it next to its own.
'
' The rule, the PIN pad and the session unlock are the shared ones in
' GuideMeta.brs — this is not a second PIN system. A locked category asks here
' EVEN IN "hide" MODE (the helper's own note): hiding never applied on the way
' in, and a dead end with no way through would be worse than a prompt.
'
' The adult rule (certification 6.3) rides along, because it is the same
' helper: an adult category with the Settings switch off answers "blocked",
' which no PIN opens. That is the one verdict that says no rather than asking.
'
' COST. ParentalGate() is about a dozen registry reads; it is taken ONCE in
' onItem and then read as often as we like — never per button, never per tile.
' A member with nothing locked AND adult categories already allowed takes
' parentalIdle()'s early exit and this block does nothing at all; everyone
' else pays one id->name cache read when the details land, and one hash
' lookup per press.

' Nothing to enforce: adult categories already allowed and nothing locked (or
' the session is already unlocked, in which case ParentalGate loads no locks
' at all).
function parentalIdle() as boolean
    if m.pgate = invalid then return true
    if not m.pgate.adultOk then return false
    return m.pgate.locked.count() = 0
end function

' Which category is this film in? The answer rides on the get_vod_info request
' this page ALREADY makes (movie_data.category_id, with info's own copy as a
' fallback) — no extra request, and nothing per tile: the audit's finding that
' per-item requests killed the app is exactly why this is not a lookup of its
' own. The id becomes a name through the id->name cache the browsing screens
' keep warm, and carries the same honest limitation ParentalBlockedCatIds
' documents — a member who lands here first on a brand-new install has no
' cache yet, so the name comes back empty and the film is let through until
' something has been browsed.
sub resolveCatFromInfo(res as dynamic)
    m.catDone = true
    m.catName = ""
    ' Nothing to enforce: don't even read the cache.
    if parentalIdle() then return
    if res = invalid or res.ok <> true or m.provider = invalid then return
    cid = ToStr(GetField(GetField(res.data, "movie_data"), "category_id"))
    if cid = "" then cid = ToStr(GetField(GetField(res.data, "info"), "category_id"))
    if cid = "" then return
    m.catName = catIdToName(loadCatNameCache("movies", ToStr(m.provider.id)), cid)
end sub

' May this press start playback? "asked" leaves the PIN pad on screen and the
' press is replayed if the member gets it right.
function parentalOkToPlay(pending as object) as boolean
    if parentalIdle() then return true
    if not m.catDone
        ' Pressed before get_vod_info answered. With a category actually
        ' LOCKED, hold the press rather than let it through blind — otherwise
        ' beating the request to the button would be the way past the PIN.
        ' The page's spinner is already up, and every answer (including a
        ' failed one) releases it a moment later.
        '
        ' Nothing locked means the only rule left is the adult one, which is
        ' every member's default state — holding every first press on it would
        ' change what a member with no parental controls at all feels, for a
        ' case that is already dropped from every list they can browse. So
        ' that one is judged when the answer lands, and not before.
        if m.pgate.locked.count() = 0 then return true
        m.pendingPlay = pending
        KLog("movie", "movie detail:holding play until the category is known")
        return false
    end if
    if m.catName = "" then return true
    v = ParentalGuardWith(m.pgate, m.top, m.catName, "onParentalPin", "onParentalPinCancel")
    if v = "allow" then return true
    if v = "asked"
        KLog("movie", "movie detail:[" + m.catName + "] is locked - asking for the PIN")
        m.pendingPlay = pending
        return false
    end if
    ' "blocked": an adult category with the Settings switch off. No PIN gets
    ' in, so say so rather than leave the button looking broken.
    KLog("movie", "movie detail:[" + m.catName + "] is an adult category and the Settings switch is off")
    m.pendingPlay = invalid
    note = CreateObject("roSGNode", "Dialog")
    note.title = "Not Available"
    note.message = "Adult categories are switched off. Turn on 'Show adult categories' under Settings > Parental controls to watch this."
    note.buttons = ["OK"]
    note.observeField("buttonSelected", "onParentalPinNote")
    m.top.getScene().dialog = note
    return false
end function

' Carry out the press that was held (or unlocked). Cleared FIRST so a second
' refusal can't loop.
sub flushPendingPlay()
    p = m.pendingPlay
    if p = invalid then return
    m.pendingPlay = invalid
    playMovie(p.fromStart = true)
end sub

' THESE TWO ARE RENDER-THREAD ENTRY POINTS TOO, and a grep of this file for
' observeField does not find them: the names are handed to ParentalGuardWith as
' strings (above), and GuideMeta.brs:369-370 is what observes "accepted" and
' "cancelled" on the PIN keyboard with them. They run in THIS component's
' namespace all the same, so they are guarded like everything else.
sub onParentalPin()
    try
        onParentalPinInner()
    catch e
        GuardFailed("movie/onParentalPin", e)
        ' THE PIN PAD COMES DOWN AND THE HELD PLAY IS DROPPED. This is the
        ' handler for a CORRECT PIN, so a fault here is the member typing the
        ' right code and the television doing absolutely nothing - the FCF117
        ' complaint the channel page already carries a note about. Worse, it
        ' faults with the pad still on screen holding the remote.
        '
        ' ParentalClosePin() is safe to call from in here: it only sets close
        ' on m.pinDialog and never asks for the scene. The play is let go
        ' rather than retried, because a flush that faulted part-way may
        ' already have started something.
        ParentalClosePin()
        m.pendingPlay = invalid
        m.top.setFocus(true)
    end try
end sub

sub onParentalPinInner()
    if ParentalAcceptPin()
        ' Unlocked for the rest of the session — take a fresh snapshot (it
        ' now loads no locks at all) and play what was asked for.
        m.pgate = ParentalGate("movies")
        flushPendingPlay()
    else
        ParentalWrongPinNote(m.top, "onParentalPinNote")
    end if
end sub

sub onParentalPinCancel()
    try
        ParentalClosePin()
        m.pendingPlay = invalid
        m.top.setFocus(true)
    catch e
        GuardFailed("movie/onParentalPinCancel", e)
        ' The member backed out of the PIN pad. Drop the held play and take
        ' the remote back, which is all the inner three lines do anyway.
        m.pendingPlay = invalid
        m.top.setFocus(true)
    end try
end sub

sub onParentalPinNote()
    try
        m.top.getScene().dialog.close = true
        m.pendingPlay = invalid
        m.top.setFocus(true)
    catch e
        GuardFailed("movie/onParentalPinNote", e)
        ' THE HELD PLAY IS DROPPED FIRST, and that order matters. This handler
        ' is the "wrong PIN" note: the member failed the parental check, and
        ' m.pendingPlay is still holding the film they asked for. Leave it set
        ' and the next thing that calls flushPendingPlay() - the next correct
        ' PIN, or the next details answer - starts the film the gate just
        ' refused. So it is cleared here whatever else went wrong.
        '
        ' The dialog is not closed again from here, for the same reason as
        ' onMsNoteClosed: that needs getScene(), and a second go at it would
        ' fault inside the catch where nothing is listening.
        m.pendingPlay = invalid
        m.top.setFocus(true)
    end try
end sub
