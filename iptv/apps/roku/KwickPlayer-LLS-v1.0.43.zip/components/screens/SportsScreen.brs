' The Sports hub. All data arrives pre-built from SportsTask (events merged,
' badges resolved, art-first sort already decided) — this screen only
' filters, renders and navigates.

sub init()
    m.theme = KwickTheme()
    m.ctx = SportsCtx()

    m.header = m.top.findNode("header")
    m.header.text = "Sports"
    ' ---- The shell theme's type, page-wide ---------------------------------
    ' JetBrains Mono via Theme.brs. Every label on this page was measured at
    ' mono's flat 0.6em against its own box and all of them clear, so no size
    ' changed. The page's two MEASURED layouts — the sport chips and the day
    ' buttons — both go through textWidth() below, which over-reserves and is
    ' now more accurate than it was; see the note there.
    m.header.font = UiBoldFont(42)
    m.header.color = m.theme.textPrimary

    m.chipsGroup = m.top.findNode("chipsGroup")
    m.daysGroup = m.top.findNode("daysGroup")
    m.heroGroup = m.top.findNode("heroGroup")
    m.liveHeader = m.top.findNode("liveHeader")
    m.liveRow = m.top.findNode("liveRow")
    m.dayHeader = m.top.findNode("dayHeader")
    m.dayList = m.top.findNode("dayList")
    m.emptyLabel = m.top.findNode("emptyLabel")
    m.statusLabel = m.top.findNode("statusLabel")
    m.spinner = m.top.findNode("spinner")
    m.keySink = m.top.findNode("keySink")

    ' Search box — styled exactly like the one on the Search screen so the
    ' two read as the same control.
    m.searchBar = m.top.findNode("searchBar")
    m.barRing = m.top.findNode("barRing")
    m.barRing.color = m.theme.focusHighlight
    m.top.findNode("barBg").color = m.theme.surface
    barIcon = m.top.findNode("barIcon")
    barIcon.font = IconFont(30)
    barIcon.text = m.theme.iconSearch
    barIcon.color = m.theme.textSecondary
    m.barText = m.top.findNode("barText")
    ' 26 in a 568px box: 36 characters. The resting prompt "Search teams or
    ' leagues" is 23, and a typed query longer than 36 truncates — as it did
    ' before at about 44. UNVERIFIED.
    m.barText.font = UiFont(26)

    ' Section headings, and the status line, which is the longest string set
    ' in this size: "Finding games in your channels and guide..." is 42
    ' characters, i.e. 756px in a 1810px centred box.
    sec = UiBoldFont(30)
    for each id in ["liveHeader", "dayHeader"]
        n = m.top.findNode(id)
        n.font = sec
        n.color = m.theme.textPrimary
    end for
    m.liveHeader.text = "Live Now"
    ' The empty line wraps in a 1690px box, so it reflows rather than clips.
    m.emptyLabel.font = UiFont(25)
    m.emptyLabel.color = m.theme.textSecondary
    m.statusLabel.font = sec
    m.statusLabel.color = m.theme.textSecondary

    ' ---- Hero styling: the home treatment (2026-08-26) ----------------------
    ' Rounded nine-patch plate, an always-on frost frame, and the highlight
    ' colour on focus - the same three things every card in the app now wears,
    ' from the same two files. Both nodes are Posters, so the colour is a
    ' blendColor write rather than a Rectangle .color, and both are held
    ' because renderHeroFocus() writes them on every focus change.
    m.heroBg = m.top.findNode("heroBg")
    m.heroPlateRest = m.theme.surface
    ' surfaceLift, not surfaceElevated: Theme.brs says surfaceElevated "is only
    ' a hair off surface, which is invisible at ten feet". The hero is one card
    ' with nothing beside it to compare against, so its focus lift has to be
    ' the readable one.
    m.heroPlateLift = m.theme.surfaceLift
    m.heroBg.blendColor = m.heroPlateRest
    m.heroRing = m.top.findNode("heroRing")
    m.heroRingIdle = m.theme.cardIdleBorder
    m.heroRingFocus = m.theme.focusHighlight
    m.heroRing.blendColor = m.heroRingIdle
    ' The hero's secondary type. Its boxes are 1100-1240 wide, i.e. 76-86
    ' characters at 24 in mono — far more than a fixture line runs to.
    hm = UiFont(24)
    m.top.findNode("heroMeta").font = hm
    m.top.findNode("heroMeta").color = m.theme.textSecondary
    ' 40 in a 1240px box: 51 characters. "Manchester United vs Liverpool" is
    ' 29. Roboto fitted about 62, so a very long fixture name truncates
    ' sooner — UNVERIFIED, and the sub-line underneath repeats the teams.
    ht = UiBoldFont(40)
    m.top.findNode("heroTitle").font = ht
    m.top.findNode("heroTitle").color = m.theme.textPrimary
    m.top.findNode("heroSub").font = hm
    m.top.findNode("heroSub").color = m.theme.textSecondary
    hh = UiFont(21)
    m.top.findNode("heroHint").font = hh
    m.top.findNode("heroHint").color = m.theme.textSecondary
    m.top.findNode("heroVs").font = hm
    m.top.findNode("heroVs").color = m.theme.textSecondary
    m.top.findNode("heroVs").text = "vs"
    m.top.findNode("heroFallbackCircle").blendColor = m.theme.surfaceElevated
    m.top.findNode("heroFallbackLetters").font = sec
    m.top.findNode("heroFallbackLetters").color = m.theme.textSecondary

    m.events = []
    m.sports = []
    m.badges = {}
    m.tzOffsetS = 0
    m.sportSel = ""      ' "" = All
    m.daySel = "today"
    m.anyTimed = false
    m.filtered = []      ' events after the sport filter
    m.liveEvents = []
    m.dayEvents = []
    m.hero = invalid
    m.chipNodes = []
    m.dayNodes = []
    m.focusArea = "chips"
    m.chipFocus = 0
    m.dayFocus = 0
    m.overlay = invalid
    m.overlayEvent = invalid
    m.player = invalid

    m.query = ""         ' what the member typed or said, "" = not searching
    m.queryWords = []    ' the same thing, lowercased and split into words
    m.kbDialog = invalid ' the open keyboard dialog, or invalid
    m.kbEdit = invalid   ' its text box — what the microphone writes into
    m.kbApply = false    ' the query changed and takes effect as it closes
    m.kbHasClear = false ' this dialog was opened with a Clear button on it

    m.top.observeField("focusedChild", "onFocusIn")
    m.liveRow.observeField("rowItemSelected", "onLiveSelected")
    m.dayList.observeField("itemSelected", "onDaySelected")

    startLoad()
end sub

sub onFocusIn()
    if not m.top.hasFocus() then return
    if m.focusArea = "live"
        m.liveRow.setFocus(true)
    else if m.focusArea = "list"
        m.dayList.setFocus(true)
    else
        m.keySink.setFocus(true)
    end if
end sub

' ---- Data -------------------------------------------------------------------

sub startLoad()
    m.statusLabel.text = "Finding games in your channels and guide..."
    m.statusLabel.visible = true
    m.spinner.visible = true
    if m.spinner.uri = "" then m.spinner.uri = "pkg:/images/spinner.png"
    m.spinner.control = "start"
    ' Every M3U source needs its playlist in memory first — same dance as
    ' the TV Guide, once per playlist that isn't cached yet.
    m.m3uPending = 0
    m.m3uTasks = []
    slots = m.global.m3uByProv
    ' Media servers have no live channels to scan - see LiveProviders().
    for each p in LiveProviders()
        if ToStr(p.ptype) = "m3u" and not slots.doesExist(ToStr(p.id))
            m.m3uPending = m.m3uPending + 1
            task = CreateObject("roSGNode", "M3uTask")
            task.url = p.m3uUrl
            task.tag = ToStr(p.id)
            task.observeField("result", "onM3uReady")
            m.m3uTasks.push(task)     ' keep refs so none is collected mid-flight
            task.control = "RUN"
        end if
    end for
    if m.m3uPending = 0 then startSportsTask()
end sub

sub onM3uReady(event as object)
    res = event.getData()
    pid = ToStr(event.getRoSGNode().tag)
    if res <> invalid and GetField(res, "channels") <> invalid
        ' Through the per-source slots — never clobber other playlists.
        PublishM3uParse(pid, ToArray(res.channels), ToStr(GetField(res, "tvgUrl")))
    end if
    m.m3uPending = m.m3uPending - 1
    if m.m3uPending <= 0 then startSportsTask()
end sub

sub startSportsTask()
    m.task = CreateObject("roSGNode", "SportsTask")
    m.task.observeField("result", "onSportsData")
    m.task.control = "RUN"
end sub

sub onSportsData(event as object)
    res = event.getData()
    m.spinner.control = "stop"
    m.spinner.visible = false
    m.statusLabel.visible = false
    if res = invalid or res.ok <> true
        m.statusLabel.text = "Could not read your guide."
        m.statusLabel.visible = true
        return
    end if
    m.events = res.events
    m.sports = res.sports
    m.badges = res.badges
    m.tzOffsetS = res.tzOffsetS

    if m.events.count() = 0
        ' Nothing at all to search, so the box would only be a dead end.
        m.searchBar.visible = false
        m.statusLabel.visible = false
        m.emptyLabel.translation = [60, 400]
        m.emptyLabel.text = "No games found." + Chr(10) + Chr(10) + "This lists actual fixtures - two teams playing - found in your channel names and TV guide. Studio shows and highlights are deliberately left out."
        m.emptyLabel.visible = true
        return
    end if

    m.searchBar.visible = true
    renderSearchBar()
    buildChips()
    buildDays()
    renderAll()
end sub

' ---- Filters / derived lists ------------------------------------------------

sub renderAll()
    nowS = CreateObject("roDateTime").asSeconds()
    searching = (m.queryWords.count() > 0)

    ' Search, or the sport chip — never both. See searchScope() for why.
    m.filtered = []
    for each e in m.events
        if searching
            if eventMatchesQuery(e) then m.filtered.push(e)
        else if m.sportSel = "" or e.sport = m.sportSel
            m.filtered.push(e)
        end if
    end for

    ' Live + any-timed.
    m.liveEvents = []
    m.anyTimed = false
    for each e in m.filtered
        if e.startS > 0 then m.anyTimed = true
        if EventIsLiveAt(e, nowS) then m.liveEvents.push(e)
    end for

    ' Day buttons only make sense when the provider publishes times at all,
    ' and they are out of play during a search (searchScope() again).
    effDay = m.daySel
    if not m.anyTimed then effDay = "week"
    if searching then effDay = searchScope()
    m.daysGroup.visible = (m.anyTimed and not searching)
    ' Never leave the remote pointed at a row that just disappeared.
    if not m.daysGroup.visible and m.focusArea = "days" then m.focusArea = "chips"

    ' Day list (live games are shown separately AND lead this list).
    m.dayEvents = []
    localNow = nowS + m.tzOffsetS
    midnight = localNow - (localNow mod 86400)
    for each e in m.filtered
        if not EventIsLiveAt(e, nowS)
            keep = false
            if effDay = "today"
                if e.startS > 0
                    lc = e.startS + m.tzOffsetS
                    keep = (lc >= midnight and lc < midnight + 86400)
                end if
            else if effDay = "tomorrow"
                if e.startS > 0
                    lc = e.startS + m.tzOffsetS
                    keep = (lc >= midnight + 86400 and lc < midnight + 2 * 86400)
                end if
            else
                ' Undated fixtures live under "This week": claiming one is on
                ' today would be a guess, and a wrong one puts it above
                ' things that really are on.
                keep = (e.startS = 0 or (e.startS >= nowS and e.startS < nowS + 7 * 86400))
            end if
            if keep then m.dayEvents.push(e)
        end if
    end for

    ' Hero: the TOP of the already-art-first-sorted order, preferring a
    ' fixture with two named teams — a missing crest shows most on the big
    ' card.
    ordered = []
    for each e in m.liveEvents
        ordered.push(e)
    end for
    for each e in m.dayEvents
        ordered.push(e)
    end for
    m.hero = invalid
    for each e in ordered
        if e.homeTeam <> "" and e.awayTeam <> ""
            m.hero = e
            exit for
        end if
    end for
    if m.hero = invalid and ordered.count() > 0 then m.hero = ordered[0]

    renderChips()
    renderDays()
    renderHero(nowS)
    renderLiveRow()
    renderDayList(effDay)
end sub

' ---- Chips ------------------------------------------------------------------

sub buildChips()
    ' "All" plus only the sports the provider actually carries.
    m.chipDefs = ["All"]
    for each s in m.sports
        m.chipDefs.push(s)
    end for
    x = 0
    m.chipNodes = []
    for each label in m.chipDefs
        grp = m.chipsGroup.createChild("Group")
        grp.translation = [x, 0]
        lbl = grp.createChild("Label")
        lbl.font = UiBoldFont(27)
        lbl.text = label
        under = grp.createChild("Rectangle")
        under.height = 4
        under.color = m.theme.accent
        under.visible = false
        w = textWidth(label, 27)
        under.width = w
        under.translation = [0, 44]
        m.chipNodes.push({ label: lbl, under: under })
        x = x + w + 44
    end for
end sub

' Roku has no text measure on Labels before layout; a steady approximation
' keeps chips from overlapping (same trick the guide tabs use).
'
' 0.62 IS LEFT ALONE, and on JetBrains Mono it is finally honest. Mono's
' advance is a flat 0.600 em for every character in both weights, so this now
' over-reserves by a fixed 3% plus 10px — which is the safe direction, and it
' is a far tighter fit than it was on Roboto-Medium, where real text measured
' 0.483-0.549 em and this ran 13-28% wide.
'
' That matters for more than spacing: the sport chips use the SAME number for
' the width of the underline drawn under the selected chip, so the underline
' used to overhang its word noticeably and now sits close to it. Nothing here
' can clip — the estimate is an over-estimate in both fonts.
function textWidth(text as string, size as integer) as integer
    return Int(text.len() * size * 0.62) + 10
end function

sub renderChips()
    ' While a search is running the chips are not filtering anything, so
    ' none of them is drawn as picked — an underline under "Soccer" over a
    ' list of tennis matches would just look broken. Pressing one puts the
    ' chips back in charge and drops the search.
    searching = (m.queryWords.count() > 0)
    for i = 0 to m.chipNodes.count() - 1
        node = m.chipNodes[i]
        selected = (m.chipDefs[i] = "All" and m.sportSel = "") or (m.chipDefs[i] = m.sportSel)
        node.under.visible = (selected and not searching)
        if m.focusArea = "chips" and i = m.chipFocus
            node.label.color = m.theme.focusHighlight
        else if selected and not searching
            node.label.color = m.theme.textPrimary
        else
            node.label.color = m.theme.textSecondary
        end if
    end for
end sub

' ---- Day buttons ------------------------------------------------------------

sub buildDays()
    m.dayDefs = [{ id: "today", label: "Today" }, { id: "tomorrow", label: "Tomorrow" }, { id: "week", label: "This week" }]
    x = 0
    m.dayNodes = []
    for each d in m.dayDefs
        grp = m.daysGroup.createChild("Group")
        grp.translation = [x, 0]
        bg = grp.createChild("Rectangle")
        w = textWidth(d.label, 24) + 36
        bg.width = w
        bg.height = 46
        lbl = grp.createChild("Label")
        lbl.font = UiFont(24)
        lbl.text = d.label
        lbl.width = w
        lbl.height = 46
        lbl.horizAlign = "center"
        lbl.vertAlign = "center"
        m.dayNodes.push({ bg: bg, label: lbl })
        x = x + w + 18
    end for
end sub

sub renderDays()
    for i = 0 to m.dayNodes.count() - 1
        node = m.dayNodes[i]
        selected = (m.dayDefs[i].id = m.daySel)
        focused = (m.focusArea = "days" and i = m.dayFocus)
        ' INK PER FILL, every branch, every pass — these nodes are reused.
        ' On Nord Shell the accent is frost (0x88C0D0), light enough that the
        ' white this used to draw measured 2.0:1 and could not be read across
        ' a room; the page colour on frost is 6.2:1. The focused branch was
        ' already dark ink and is only moved onto the palette so a reskin
        ' carries it.
        if selected
            node.bg.color = m.theme.accent
            node.label.color = m.theme.background
        else
            node.bg.color = m.theme.surface
            node.label.color = m.theme.textSecondary
        end if
        if focused
            node.bg.color = m.theme.focusHighlight
            node.label.color = m.theme.background
        end if
    end for
end sub

' ---- Search -----------------------------------------------------------------
' Android parity (sports_screen.dart / searchEvents in sports_providers.dart),
' entered through Roku's own StandardKeyboardDialog the way SearchScreen and
' the sign-in form do it — that is the platform's voice keyboard, so holding
' the microphone on the remote and saying "Lakers Celtics" works, and Roku's
' "use your phone as a keyboard" affordance comes along for free. No new
' image is added; the whole dialog is the platform's.

' HOW A FIXTURE MATCHES — copied from Android's searchEvents(), not invented:
'   * the query is lowercased and split on spaces into words
'   * every word must appear SOMEWHERE in the fixture's
'     title + home team + away team + competition + sport, all lowercased
'   * the test is "contains", so part of a word counts: "liver" finds
'     Liverpool, and case never matters
'   * every word has to hit, so "lakers celtics" finds the one game rather
'     than every game either side plays
' The only deliberate difference is the minimum length. Android waits for two
' characters because it filters while you type, and one letter matches half
' the list on the way to typing more. On Roku the query arrives finished when
' the member presses Search, so a one-character search is something they meant
' and is honoured.
sub renderSearchBar()
    if m.query = ""
        m.barText.text = "Search teams or leagues"
        m.barText.color = m.theme.textSecondary
    else
        m.barText.text = m.query
        m.barText.color = m.theme.textPrimary
    end if
    m.barRing.visible = (m.focusArea = "search")
end sub

' WHAT A SEARCH COVERS: every sport, and the whole week.
'
' Every sport, because someone typing a team name is looking for that team,
' not for it inside whichever chip happens to be underlined — that is
' Android's call too.
'
' The whole week is where this goes further than Android. Android keeps the
' day buttons live during a search, which means a search under "Today" can
' never return a fixture whose time the provider does not publish, and this
' app deliberately parks every undated fixture under "This week". Searching
' for a team and being told nothing matches — when the game is right there
' one chip over — is the wrong answer. So a search widens to the full week
' and the day buttons step aside until it is cleared.
function searchScope() as string
    return "week"
end function

' The query as lowercase words, empties dropped.
function queryWords(q as string) as object
    out = []
    if q = "" then return out
    for each w in LCase(q).tokenize(" " + Chr(9))
        word = ToStr(w)
        if word <> "" then out.push(word)
    end for
    return out
end function

' Every word must appear somewhere in the fixture's own words.
function eventMatchesQuery(e as object) as boolean
    hay = LCase(ToStr(e.title) + " " + ToStr(e.homeTeam) + " " + ToStr(e.awayTeam) + " " + ToStr(e.league) + " " + ToStr(e.sport))
    for each w in m.queryWords
        if hay.instr(0, w) = -1 then return false
    end for
    return true
end function

' Speech comes back as a SENTENCE; typing does not. Roku's dictation
' punctuates what it heard, so "man united" can arrive as "Man United." and
' the trailing full stop would then match nothing. Only the ENDS are
' stripped — the middle is left exactly as spoken, and the fixtures are never
' touched. Same trick as SearchScreen.cleanQuery.
function cleanSpokenQuery(raw as string) as string
    q = raw.trim()
    junk = ".,!?;:"
    while q.len() > 0 and junk.instr(q.right(1)) > -1
        q = q.left(q.len() - 1)
    end while
    while q.len() > 0 and junk.instr(q.left(1)) > -1
        q = q.mid(1)
    end while
    return q.trim()
end function

sub openKeyboard()
    kb = CreateObject("roSGNode", "StandardKeyboardDialog")
    kb.title = "Search fixtures"
    ' Always a fresh, empty box. Set BEFORE the text box below is touched —
    ' the same order the sign-in form and SearchScreen use, and that one has
    ' to survive a real value being put in, so it is the order known to work.
    kb.text = ""
    ' A running search needs a way out that does not involve deleting
    ' letters one at a time on a TV remote.
    m.kbHasClear = (m.query <> "")
    if m.kbHasClear
        kb.buttons = ["Search", "Clear search", "Cancel"]
    else
        kb.buttons = ["Search", "Cancel"]
    end if
    ' Team and league names are ordinary words, not an address or a password
    ' spelled out letter by letter, so they are heard as words. Roku's
    ' vocabulary is email / numeric / alphanumeric / generic / password.
    kb.keyboardDomain = "generic"

    edit = kb.textEditBox
    ' Said on the box as well as on the dialog: keyboardDomain is documented
    ' as something the keyboard "may" act on, and the microphone is the point.
    edit.voiceEnabled = true
    edit.voiceEntryType = kb.keyboardDomain
    ' Roku's boxes default to 15 characters, which cuts a spoken pair of team
    ' names off mid-sentence.
    edit.maxTextLength = 255

    m.kbDialog = kb
    m.kbEdit = edit
    m.kbApply = false
    kb.observeField("buttonSelected", "onKeyboardButton")
    ' Back closes the dialog without going through a button at all, so focus
    ' has to come home from here rather than from the Search branch —
    ' otherwise backing out of the keyboard leaves a screen with the remote
    ' pointed at nothing. Same split as SearchScreen and the sign-in form.
    kb.observeField("wasClosed", "onKeyboardClosed")
    m.top.getScene().dialog = kb
end sub

' What the member left in the box, typed or spoken. The dialog's own `text`
' is the documented place to read it from; the box is consulted only when the
' dialog says nothing, because dictation lands in the box first.
function keyboardText() as string
    if m.kbDialog = invalid then return ""
    t = ToStr(m.kbDialog.text)
    if t = "" and m.kbEdit <> invalid then t = ToStr(m.kbEdit.text)
    return t
end function

sub onKeyboardButton()
    kb = m.kbDialog
    if kb = invalid then return
    idx = kb.buttonSelected
    if idx = 0
        q = cleanSpokenQuery(keyboardText())
        if q <> ""
            m.query = q
            m.kbApply = true
        else if m.query <> ""
            ' An empty box pressed as Search, with a search already running,
            ' means "show me everything again".
            m.query = ""
            m.kbApply = true
        else
            ' Nothing to search — an empty box, or speech Roku heard as
            ' nothing but punctuation. Treated exactly like Cancel.
            KLog("sports", "keyboard returned nothing - search unchanged")
        end if
    else if idx = 1 and m.kbHasClear
        m.query = ""
        m.kbApply = true
    end if
    ' Paint the bar BEFORE the dialog goes, so the frame that takes the
    ' keyboard away already shows what was asked for; the filtering itself
    ' runs once it is gone (onKeyboardClosed).
    if m.kbApply then renderSearchBar()
    kb.close = true
end sub

' Every way out of the dialog lands here: Search, Clear search, Cancel, Back.
sub onKeyboardClosed()
    m.kbDialog = invalid
    m.kbEdit = invalid
    m.kbHasClear = false
    apply = m.kbApply
    m.kbApply = false
    if apply then applySearch()
    restoreFocus()
end sub

sub applySearch()
    m.queryWords = queryWords(m.query)
    renderSearchBar()
    renderAll()
    if m.query = ""
        KLog("sports", "search cleared")
    else
        KLog("sports", "search " + Chr(34) + m.query + Chr(34) + " matched " + m.filtered.count().toStr() + " of " + m.events.count().toStr() + " fixture(s)")
    end if
end sub

' Drop the search without going near the keyboard — what picking a sport
' chip does.
sub clearSearch()
    if m.query = "" then return
    m.query = ""
    m.queryWords = []
    renderSearchBar()
    KLog("sports", "search cleared by picking a sport")
end sub

' ---- Hero -------------------------------------------------------------------

sub renderHero(nowS as integer)
    if m.hero = invalid
        m.heroGroup.visible = false
        return
    end if
    e = m.hero
    isLive = EventIsLiveAt(e, nowS)
    m.heroGroup.visible = true
    m.top.findNode("heroLivePill").visible = isLive
    meta = e.sport
    if e.league <> "" and LCase(e.league) <> LCase(e.sport) then meta = e.league
    if e.country <> "" then meta = e.country + "  " + meta
    mx = 28
    if isLive then mx = 126
    n = m.top.findNode("heroMeta")
    n.translation = [mx, 24]
    n.text = meta
    m.top.findNode("heroTitle").text = e.title
    bits = []
    if isLive then bits.push("Live Now") else bits.push(heroTime(e))
    bits.push(e.sport)
    bits.push(channelCountText(e))
    m.top.findNode("heroSub").text = bits.join("  -  ")
    hint = "Press OK to pick a channel"
    if isLive then hint = "Press OK to watch live"
    m.top.findNode("heroHint").text = hint

    ' Crest pair only when both resolved; else league art; else letters.
    hb = badgeUrl("team|" + e.homeTeam)
    ab = badgeUrl("team|" + e.awayTeam)
    lg = leagueBadgeUrl(e)
    pair = (e.homeTeam <> "" and hb <> "" and ab <> "")
    m.top.findNode("heroBadgeHome").visible = pair
    m.top.findNode("heroVs").visible = pair
    m.top.findNode("heroBadgeAway").visible = pair or (not pair and lg <> "")
    m.top.findNode("heroFallbackCircle").visible = (not pair and lg = "")
    m.top.findNode("heroFallbackLetters").visible = (not pair and lg = "")
    if pair
        m.top.findNode("heroBadgeHome").uri = hb
        m.top.findNode("heroBadgeAway").uri = ab
    else if lg <> ""
        m.top.findNode("heroBadgeAway").uri = lg
    else
        m.top.findNode("heroFallbackLetters").text = sportLetters(e.sport)
    end if
end sub

' ---- Live row / day list ----------------------------------------------------

sub renderLiveRow()
    hasLive = (m.liveEvents.count() > 0)
    m.liveHeader.visible = hasLive
    m.liveRow.visible = hasLive
    if hasLive
        content = CreateObject("roSGNode", "ContentNode")
        row = content.createChild("ContentNode")
        for each e in m.liveEvents
            node = row.createChild("ContentNode")
            node.addFields(eventContentFields(e, true))
            node.title = e.title
            node.description = "Live Now  -  " + channelCountText(e)
        end for
        m.liveRow.content = content
        ' Changing sport returns the row to the start — fresh content resets
        ' it, and the jump makes it explicit.
        m.liveRow.jumpToRowItem = [0, 0]
        m.liveHeader.translation = [60, 468]
        m.liveRow.translation = [60, 508]
        m.dayHeader.translation = [60, 682]
        m.dayList.translation = [60, 724]
        m.dayList.numRows = 3
    else
        m.dayHeader.translation = [60, 468]
        m.dayList.translation = [60, 510]
        m.dayList.numRows = 5
    end if
end sub

sub renderDayList(effDay as string)
    searching = (m.queryWords.count() > 0)
    label = "This week"
    if effDay = "today" then label = "Today"
    if effDay = "tomorrow" then label = "Tomorrow"
    ' During a search the day buttons are hidden, so the heading says what
    ' the list actually is instead of naming a day nobody chose.
    if searching then label = "Results for " + Chr(34) + m.query + Chr(34)
    m.dayHeader.text = label

    ' Live games lead the day list too, flagged, so a scroll never leaves
    ' you guessing what is on right now.
    rows = []
    for each e in m.liveEvents
        rows.push({ ev: e, live: true })
    end for
    for each e in m.dayEvents
        rows.push({ ev: e, live: false })
    end for

    content = CreateObject("roSGNode", "ContentNode")
    for each r in rows
        e = r.ev
        node = content.createChild("ContentNode")
        node.addFields(eventContentFields(e, r.live))
        node.title = e.title
        bits = []
        if r.live then bits.push("Live Now")
        ' Don't say "Golf - Golf": plenty of competitions are named after
        ' their sport, and repeating it reads like a bug.
        if e.league <> "" and LCase(e.league) <> LCase(e.sport) then bits.push(e.league)
        bits.push(e.sport)
        bits.push(channelCountText(e))
        node.description = bits.join("  -  ")
    end for
    m.rowEvents = rows
    m.dayList.content = content
    ' Changing sport returns the list to the start, not partway down the
    ' previous sport's fixtures.
    m.dayList.jumpToItem = 0

    isEmpty = (rows.count() = 0)
    m.emptyLabel.visible = isEmpty
    ' A heading over nothing reads as a bug; the message below says it all.
    m.dayHeader.visible = not (isEmpty and searching)
    if isEmpty
        if searching
            ' Sat up near the chips rather than down at the list, because
            ' with no hero and no Live Now row there is nothing above it.
            m.emptyLabel.translation = [60, 330]
            m.emptyLabel.text = "No fixtures match " + Chr(34) + m.query + Chr(34) + "." + Chr(10) + Chr(10) + "Try one team instead of two, or a league name. This only lists fixtures found in your channel names and TV guide, so a game nobody is showing will not appear."
        else
            m.emptyLabel.translation = m.dayList.translation
            m.emptyLabel.text = "Nothing listed with a start time for this day. Fixtures whose time your provider does not publish are under " + Chr(34) + "This week" + Chr(34) + "."
        end if
    end if
end sub

' Shared content fields for a row/card node.
function eventContentFields(e as object, isLive as boolean) as object
    hb = badgeUrl("team|" + e.homeTeam)
    ab = badgeUrl("team|" + e.awayTeam)
    pairHome = ""
    pairAway = ""
    if e.homeTeam <> "" and hb <> "" and ab <> ""
        pairHome = hb
        pairAway = ab
    end if
    lf = ""
    if isLive then lf = "1"
    ' The row's time column is narrow, so an undated fixture says "TBA"
    ' there rather than truncating "Time not listed" to "Time not li...".
    ' The hero and the channel picker have room for the full wording.
    rowTime = heroTime(e)
    if e.startS = 0 then rowTime = "TBA"
    return {
        liveFlag: lf,
        timeText: rowTime,
        flagCode: e.country,
        badgeHome: pairHome,
        badgeAway: pairAway,
        badgeSingle: leagueBadgeUrl(e),
        sportLetters: sportLetters(e.sport)
    }
end function

function badgeUrl(key as string) as string
    v = GetField(m.badges, key)
    if v = invalid then return ""
    return ToStr(v)
end function

' League artwork for events with no crest pair (a fight card, a race).
function leagueBadgeUrl(e as object) as string
    if e.homeTeam <> "" and e.awayTeam <> "" then return ""
    nm = e.league
    if nm = "" then nm = e.title
    return badgeUrl("league|" + nm)
end function

function sportLetters(sport as string) as string
    if sport = "Soccer" then return "SOC"
    if sport = "Football" then return "FB"
    if sport = "Basketball" then return "BKB"
    if sport = "Baseball" then return "BSB"
    if sport = "Hockey" then return "HKY"
    if sport = "Fights" then return "MMA"
    if sport = "Wrestling" then return "WWE"
    if sport = "Motorsport" then return "MOT"
    if sport = "Golf" then return "GLF"
    if sport = "Tennis" then return "TEN"
    if sport = "Cricket" then return "CRK"
    if sport = "Rugby" then return "RGB"
    if sport = "Racing" then return "RAC"
    return "SPT"
end function

function channelCountText(e as object) as string
    n = e.channels.count()
    if n = 1 then return "1 channel"
    return n.toStr() + " channels"
end function

' Local HH:MM from the EPG's UTC epoch, or the honest answer.
function heroTime(e as object) as string
    if e.startS = 0 then return "Time not listed"
    lc = e.startS + m.tzOffsetS
    hh = Int((lc mod 86400) / 3600)
    mm = Int((lc mod 3600) / 60)
    hs = hh.toStr()
    if hh < 10 then hs = "0" + hs
    ms = mm.toStr()
    if mm < 10 then ms = "0" + ms
    return hs + ":" + ms
end function

' ---- Selection / playback ---------------------------------------------------

sub onLiveSelected()
    sel = m.liveRow.rowItemSelected
    if sel = invalid or sel.count() < 2 then return
    idx = sel[1]
    if idx >= 0 and idx < m.liveEvents.count() then openChannels(m.liveEvents[idx])
end sub

sub onDaySelected()
    idx = m.dayList.itemSelected
    if m.rowEvents = invalid then return
    if idx >= 0 and idx < m.rowEvents.count() then openChannels(m.rowEvents[idx].ev)
end sub

sub openChannels(e as object)
    m.overlayEvent = e
    rows = []
    for i = 0 to e.channels.count() - 1
        lbl = StreamLabel(m.ctx, e.channels[i], i)
        rows.push({ title: lbl.title, subtitle: lbl.subtitle })
    end for
    m.overlay = m.top.getScene().createChild("EventChannelsScreen")
    m.overlay.eventTitle = e.title
    bits = []
    if e.league <> "" and LCase(e.league) <> LCase(e.sport) then bits.push(e.league)
    bits.push(e.sport)
    bits.push(heroTime(e))
    m.overlay.metaText = bits.join("  -  ")
    m.overlay.rows = rows
    m.overlay.observeField("picked", "onChannelPicked")
    m.overlay.observeField("closed", "onChannelsClosed")
    m.overlay.setFocus(true)
end sub

sub onChannelsClosed()
    removeOverlay()
    restoreFocus()
end sub

sub removeOverlay()
    if m.overlay <> invalid
        m.top.getScene().removeChild(m.overlay)
        m.overlay = invalid
    end if
end sub

sub onChannelPicked()
    if m.overlay = invalid or m.overlayEvent = invalid then return
    idx = m.overlay.picked
    e = m.overlayEvent
    removeOverlay()
    if idx < 0 or idx >= e.channels.count()
        restoreFocus()
        return
    end if
    c = e.channels[idx]
    ' An event can be carried by channels from different sources — play the
    ' picked one against ITS source's login.
    srcTok = ToStr(GetField(c, "src"))
    prov = ProviderForSrcToken(srcTok)
    ' The fallback to the active source is deliberate and stays, for the reason
    ' the comment above gives — but it is now gated on the kind.
    '
    ' ONLY A PANEL CAN HAVE A STREAM ADDRESS BUILT HERE, and this is a
    ' POSITIVE test for the two kinds that can rather than a list of the kinds
    ' that cannot. A plain playlist has no server field at all, so Util.brs
    ' answers "" — but a member's own Jellyfin HAS a server, a username and a
    ' password, so the panel builder would hand back a real-looking address
    ' that is simply wrong, and the member would read a decoder error about
    ' something that is perfectly fine.
    if prov = invalid then prov = ActiveProvider()
    ' The list of exclusions this replaces was `prov <> invalid`, on the old
    ' one-line fallback: any source at all was allowed to build a panel address.
    '
    ' THE `if url = ""` BELOW IS A PRE-CHECK OF THE PLAYLIST'S OWN ADDRESS, not
    ' a guard on the panel builder: a playlist channel carries its own url, and
    ' only one that has none falls through to the panel.
    url = LivePlayUrl(ToStr(c.url))
    if url = ""
        pt = ""
        if prov <> invalid then pt = LCase(ToStr(prov.ptype))
        if pt = "xtream" or pt = "kwicktv" then url = XtreamLiveUrl(prov, ToStr(c.streamId))
    end if
    ' LOG KEY FCF117 — Hisense 6Series-58, v1.0.39, 29 September 2026. What
    ' happened on the member's television, in plain words: they removed their
    ' source in Settings, a different one came back from the website on its own
    ' three seconds later, and the first thing they pressed was a leftover from
    ' the source they had just taken out. The app had nothing left to match it
    ' against, so it reached for the source that had just arrived — an
    ' ordinary playlist, which has no panel address to build a stream from —
    ' and the television froze with the spinner still turning and nothing on
    ' screen to say why. Util.brs now answers "" there instead of stopping the
    ' app; this is the half that tells the member something. Without it the
    ' press is simply dead: the player bails on an empty address before the
    ' Video node is ever handed anything to fail on, so no error and no retry
    ' ever happens, and the member is left watching a spinner turn forever.
    '
    ' THIS SCREEN ALREADY NOTICED AND SAID NOTHING. It called restoreFocus()
    ' and returned, so the member pressed OK on a sports event and the
    ' highlight simply moved back — no message, no sound, not even a line in
    ' the log. That is exactly the dead button PlayerScreen.brs warns about,
    ' and before the Util.brs change this same press would have stopped the
    ' app outright, so what was left is a silent failure where there used to be
    ' a loud one.
    if url = ""
        KLog("sports", "FCF117: refused play — no source on this box can open [" + ToStr(c.channelName) + "]")
        sptCannotPlayNote()
        return
    end if
    m.player = m.top.getScene().createChild("PlayerScreen")
    m.player.titleText = e.title
    m.player.streamUrl = url
    m.player.streamFormat = StreamFormatFor(url, "")
    m.player.isLive = true
    m.player.channel = { streamId: ToStr(c.streamId), name: ToStr(c.channelName), logo: ToStr(c.logo), url: ToStr(c.url), src: srcTok }
    m.player.observeField("closed", "onPlayerClosed")
    m.player.setFocus(true)
    m.player.start = true
end sub

sub onPlayerClosed()
    if m.player <> invalid
        m.top.getScene().removeChild(m.player)
        m.player = invalid
    end if
    restoreFocus()
end sub

' "Can't Play This Right Now", in the shape ChannelDetailScreen, the film page
' and the series page all already use — one Dialog, one OK button, focus handed
' back to where the member was standing. Written out again here rather than
' shared, because a component only ever sees the scripts its own XML names and
' those three live in their own screens' files.
'
' LOG KEY FCF117: before this, the member's press did nothing whatsoever. The
' guard in Util.brs stops the app dying, but on its own it turns a crash into a
' button that silently does nothing — the television just sits there with the
' spinner turning. This is the part that says something.
'
' THE WORDING names no cause it cannot be sure of. The commonest reason is a
' channel left behind by a removed source, but the same dead end is reached by
' a playlist row that carries no address, so it says "probably" and offers the
' one thing the member can actually do about it. Word for word the same
' sentence as the channel page, so the two never drift apart.
sub sptCannotPlayNote()
    note = CreateObject("roSGNode", "Dialog")
    note.title = "Can't Play This Right Now"
    note.message = "Kwick Player has no working source for this channel. It was probably left behind by a source you removed. Check your sources under Settings, or pick another channel."
    note.buttons = ["OK"]
    note.observeField("buttonSelected", "onSptCannotPlayNote")
    m.top.getScene().dialog = note
end sub

' restoreFocus(), the same hand-back the silent version did: the member goes
' back to the row they were standing on, not to the top of the screen.
sub onSptCannotPlayNote()
    m.top.getScene().dialog.close = true
    restoreFocus()
end sub

sub restoreFocus()
    if m.focusArea = "live" and m.liveRow.visible
        m.liveRow.setFocus(true)
    else if m.focusArea = "list"
        m.dayList.setFocus(true)
    else
        m.keySink.setFocus(true)
    end if
end sub

' ---- Remote navigation ------------------------------------------------------
' Areas top to bottom: search -> chips -> days -> hero -> live -> list. Every
' element focusable, focus always visible. The screen still opens on the
' chips: this is a browse screen first, and the search box is one press of Up
' away.
'
' BACK AND LEFT PART COMPANY ON THIS SCREEN (2026-08-26). LEFT climbs one area
' at a time and hands the remote to the sidebar when it runs out — a
' direction, unchanged. BACK leaves the screen: every Back branch below
' returns FALSE so the key bubbles to AppShell.onKeyEvent, which walks out to
' Home and raises the single exit confirmation certification 4.6 allows.
'
' >>> THE TRAP, WHICH BIT THREE SITES ACROSS THIS BUILD. <<< The per-area
' handlers (searchKey, chipsKey, ...) end in a bare `return true`, and
' onKeyEvent dispatches to them with `return searchKey(key)`. A Back branch
' that merely stopped raising backToNav and fell through would be reported as
' HANDLED and go nowhere — Back would be a dead button, with no crash and no
' error to find. Every Back branch therefore returns false EXPLICITLY. Do not
' remove those returns.

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if m.events.count() = 0
        if key = "back"
            ' Back does NOT raise backToNav any more (certification 4.6, and the
            ' owner's "i should be able to back button all the way to home"). It
            ' returns FALSE so the key bubbles to AppShell.onKeyEvent, which walks
            ' one screen out toward Home and raises the exit confirmation once it
            ' gets there. LEFT is unchanged and still parks on the rail - it is a
            ' direction, not an exit.
            '
            ' The false is returned EXPLICITLY rather than by falling out of the
            ' branch, because the fall-through at the end of this handler can be
            ' `return true`, which would eat it and leave Back doing nothing at
            ' all - a dead button with no error to find.
            return false
        else if key = "left"
            m.top.backToNav = true
            return true
        end if
        return false
    end if

    if m.focusArea = "search" then return searchKey(key)
    if m.focusArea = "chips" then return chipsKey(key)
    if m.focusArea = "days" then return daysKey(key)
    if m.focusArea = "hero" then return heroKey(key)
    if m.focusArea = "live" then return liveKey(key)
    if m.focusArea = "list" then return listKey(key)
    return false
end function

function searchKey(key as string) as boolean
    if key = "OK"
        openKeyboard()
        return true
    else if key = "down"
        m.focusArea = "chips"
        renderSearchBar()
        renderChips()
        return true
    else if key = "back"
        ' Back does NOT raise backToNav any more (certification 4.6, and the
        ' owner's "i should be able to back button all the way to home"). It
        ' returns FALSE so the key bubbles to AppShell.onKeyEvent, which walks
        ' one screen out toward Home and raises the exit confirmation once it
        ' gets there. LEFT is unchanged and still parks on the rail - it is a
        ' direction, not an exit.
        '
        ' The false is returned EXPLICITLY rather than by falling out of the
        ' branch, because the fall-through at the end of this handler can be
        ' `return true`, which would eat it and leave Back doing nothing at
        ' all - a dead button with no error to find.
        '
        ' THIS IS THE SITE THE SWALLOW WAS CALLED OUT ON: searchKey ends in a
        ' bare `return true` immediately below, and onKeyEvent dispatches here
        ' with `return searchKey(key)`, so a Back that fell through would be
        ' reported as handled and go nowhere.
        return false
    else if key = "left"
        ' Nothing sits to the left of the box on this screen, so Left hands
        ' the remote back to the sidebar — same as the Search screen's bar.
        m.top.backToNav = true
        return true
    end if
    return true
end function

function chipsKey(key as string) as boolean
    if key = "right"
        if m.chipFocus < m.chipNodes.count() - 1 then m.chipFocus = m.chipFocus + 1
        renderChips()
        return true
    else if key = "left"
        if m.chipFocus > 0
            m.chipFocus = m.chipFocus - 1
            renderChips()
            return true
        end if
        m.top.backToNav = true
        return true
    else if key = "OK"
        pick = ""
        if m.chipFocus > 0 then pick = m.chipDefs[m.chipFocus]
        ' Picking a sport is a browse action, so it takes the search off:
        ' the chips do not filter while a search is running, and leaving a
        ' query in the box that changes nothing would read as broken.
        hadQuery = (m.query <> "")
        if pick <> m.sportSel or hadQuery
            m.sportSel = pick
            clearSearch()
            ' Both the list and the Live Now row return to the start — a
            ' real bug on Android left you halfway along the old sport's
            ' cards, looking at nothing.
            renderAll()
        end if
        return true
    else if key = "up"
        m.focusArea = "search"
        renderChips()
        renderSearchBar()
        return true
    else if key = "down"
        if m.daysGroup.visible
            m.focusArea = "days"
        else if m.heroGroup.visible
            m.focusArea = "hero"
        else
            m.focusArea = "list"
            m.dayList.setFocus(true)
        end if
        renderChips()
        renderDays()
        renderHeroFocus()
        return true
    else if key = "back"
        ' Back does NOT raise backToNav any more (certification 4.6, and the
        ' owner's "i should be able to back button all the way to home"). It
        ' returns FALSE so the key bubbles to AppShell.onKeyEvent, which walks
        ' one screen out toward Home and raises the exit confirmation once it
        ' gets there. LEFT is unchanged and still parks on the rail - it is a
        ' direction, not an exit.
        '
        ' The false is returned EXPLICITLY rather than by falling out of the
        ' branch, because the fall-through at the end of this handler can be
        ' `return true`, which would eat it and leave Back doing nothing at
        ' all - a dead button with no error to find.
        '
        ' Same shape as searchKey above: chipsKey ends in a bare `return true`
        ' and onKeyEvent dispatches with `return chipsKey(key)`. This site was
        ' not on the flagged list but has the identical failure mode, so it is
        ' written the same way.
        return false
    end if
    return true
end function

function daysKey(key as string) as boolean
    if key = "right"
        if m.dayFocus < m.dayNodes.count() - 1 then m.dayFocus = m.dayFocus + 1
        renderDays()
        return true
    else if key = "left"
        if m.dayFocus > 0
            m.dayFocus = m.dayFocus - 1
            renderDays()
        end if
        return true
    else if key = "OK"
        pick = m.dayDefs[m.dayFocus].id
        if pick <> m.daySel
            m.daySel = pick
            renderAll()
        end if
        return true
    else if key = "up"
        m.focusArea = "chips"
        renderChips()
        renderDays()
        return true
    else if key = "down"
        if m.heroGroup.visible
            m.focusArea = "hero"
            renderDays()
            renderHeroFocus()
        else if m.liveRow.visible
            m.focusArea = "live"
            renderDays()
            m.liveRow.setFocus(true)
        else
            m.focusArea = "list"
            renderDays()
            m.dayList.setFocus(true)
        end if
        return true
    else if key = "back"
        m.focusArea = "chips"
        renderChips()
        renderDays()
        return true
    end if
    return true
end function

function heroKey(key as string) as boolean
    if key = "OK"
        if m.hero <> invalid then openChannels(m.hero)
        return true
    else if key = "up"
        if m.daysGroup.visible then m.focusArea = "days" else m.focusArea = "chips"
        renderHeroFocus()
        renderChips()
        renderDays()
        return true
    else if key = "down"
        renderHeroFocusOff()
        if m.liveRow.visible
            m.focusArea = "live"
            m.liveRow.setFocus(true)
        else
            m.focusArea = "list"
            m.dayList.setFocus(true)
        end if
        return true
    else if key = "back"
        m.focusArea = "chips"
        renderHeroFocus()
        renderChips()
        return true
    end if
    return true
end function

function liveKey(key as string) as boolean
    if key = "up"
        if m.heroGroup.visible
            m.focusArea = "hero"
        else if m.daysGroup.visible
            m.focusArea = "days"
        else
            m.focusArea = "chips"
        end if
        m.keySink.setFocus(true)
        renderChips()
        renderDays()
        renderHeroFocus()
        return true
    else if key = "down"
        m.focusArea = "list"
        m.dayList.setFocus(true)
        return true
    else if key = "back"
        m.focusArea = "chips"
        m.keySink.setFocus(true)
        renderChips()
        renderHeroFocus()
        return true
    end if
    return false
end function

function listKey(key as string) as boolean
    if key = "up" and m.dayList.itemFocused <= 0
        if m.liveRow.visible
            m.focusArea = "live"
            m.liveRow.setFocus(true)
        else if m.heroGroup.visible
            m.focusArea = "hero"
            m.keySink.setFocus(true)
            renderHeroFocus()
        else
            m.focusArea = "chips"
            m.keySink.setFocus(true)
            renderChips()
        end if
        return true
    else if key = "back"
        m.focusArea = "chips"
        m.keySink.setFocus(true)
        renderChips()
        renderHeroFocus()
        return true
    end if
    return false
end function

' The hero's frame is on at all times now; what focus changes is its COLOUR,
' plus the plate lifting underneath it. Both branches written every time.
sub renderHeroFocus()
    setHeroFocus(m.focusArea = "hero")
end sub

sub renderHeroFocusOff()
    setHeroFocus(false)
end sub

sub setHeroFocus(focused as boolean)
    if focused
        m.heroBg.blendColor = m.heroPlateLift
        m.heroRing.blendColor = m.heroRingFocus
    else
        m.heroBg.blendColor = m.heroPlateRest
        m.heroRing.blendColor = m.heroRingIdle
    end if
end sub
