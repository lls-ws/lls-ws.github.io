' Put the rows under Home's Media Bar in the member's own order.
'
' Mason, 2026-09-16: "on the home -> everything under the media bar we need to
' be able to re-order this how we want to." The phone has had this since the
' same day (home_row_order_screen.dart); this is the Roku half, and it is a
' port rather than a fresh design so the two screens behave the same way.
'
' HOW A ROW MOVES. Highlight it, press Left to move it up or Right to move it
' down. One press is one place. Every move is saved the moment it is made —
' there is no Save, no Cancel and nothing to confirm on the way out.
'
' THE ORDER LIVES IN THE REGISTRY, ONE KEY, AND NOTHING ELSE IS WRITTEN. See
' HomeRowOrderKey() in Store.brs for what it costs and why the default costs
' nothing at all.
'
' THE MEDIA BAR IS NOT IN THE LIST, deliberately, on both platforms: it is the
' panel these rows sit UNDER, not one of them. Its own switch is a row up in
' Settings > Home screen.

sub init()
    m.theme = KwickTheme()
    m.top.findNode("bg").color = m.theme.background
    ' Scene-level overlay, so its own backdrop covers AppScene's grid wash and
    ' the mesh goes back in above it. Same as ReorderFavoritesScreen.
    AddPageGrid(m.top)

    header = m.top.findNode("header")
    header.text = "Row order"
    header.font = UiBoldFont(42)
    header.color = m.theme.textPrimary

    subhead = m.top.findNode("subhead")
    subhead.font = UiFont(24)
    subhead.color = m.theme.textSecondary
    ' Android's own line, plus the sentence a Roku needs that a phone does not:
    ' Left is a move here, so it is not the way out.
    subhead.text = "Highlight a row, then press Left to move it up or Right to move it down. Press Back when you are done."

    m.list = m.top.findNode("list")
    ThemeLabelList(m.list, 22)
    m.list.observeField("itemSelected", "onSelected")

    m.rows = []
    m.top.observeField("focusedChild", "onFocusIn")
    load()
end sub

sub onFocusIn()
    if m.top.hasFocus() then m.list.setFocus(true)
end sub

sub load()
    ' HomeRowOrderIds() always answers with every row this build knows, in the
    ' member's order — a saved order that names a row this build no longer has
    ' simply ignores it, and a row missing from a saved order is slotted in
    ' beside its default neighbour rather than dumped on the end. Both cases
    ' are handled in Store.brs, not here.
    m.rows = []
    for each rid in HomeRowOrderIds()
        r = ToStr(rid)
        for each d in HomeRowDefs()
            if d.rid = r then m.rows.push(d)
        end for
    end for
    fillList()
end sub

sub fillList()
    content = CreateObject("roSGNode", "ContentNode")
    for i = 0 to m.rows.count() - 1
        d = m.rows[i]
        ' Numbered, like every other ordered list in this app: on ten rows that
        ' mostly begin with the same two words, "did that actually move?" is
        ' the only question a member has.
        rowText = (i + 1).toStr() + ".  " + d.label
        ' A row a SETTING is keeping off Home keeps its slot here, stays
        ' movable, and says why — Android greys it and writes the reason
        ' underneath; a Roku LabelList has one line and one colour per row, so
        ' the word "(hidden)" and the reason do that work in the line itself.
        ' A row that is merely EMPTY today is never marked: no favourites yet
        ' is not a reason, and that row appears the moment there is something
        ' to put in it.
        why = HomeRowHiddenReason(d.rid)
        if why <> ""
            rowText = rowText + " (hidden)   ·   " + why
        else if d.hint <> ""
            rowText = rowText + "   ·   " + d.hint
        end if
        item = content.createChild("ContentNode")
        item.title = rowText
    end for
    ' Reset last, below the rows, and NEVER where the remote lands first — it
    ' throws the member's order away and the first thing focused must not be
    ' the destructive thing. No number, so it reads as separate from the list.
    resetRow = content.createChild("ContentNode")
    resetRow.title = "Reset to default   ·   Put the rows back in the app's own order"
    m.list.content = content
end sub

' OK does nothing on a row, on purpose: a held OK from the Settings row that
' opened this screen repeats into whatever has focus, and "nothing" is the
' right thing for that repeat to do. The only item OK means anything on is
' Reset, which is last and is never what a repeat lands on.
sub onSelected()
    idx = m.list.itemSelected
    if idx <> m.rows.count() then return
    ' Straight to the app's own order, no confirmation and no undo — same as
    ' the phone. It stores the sentinel rather than a copy of today's default,
    ' so a later build's default is what a reset gives you, and it touches no
    ' switch: this screen orders rows, it does not turn them on and off.
    ResetHomeRowOrder()
    KLog("settings", "home row order: reset to default")
    load()
    m.list.jumpToItem = 0
    m.list.setFocus(true)
end sub

sub moveFocused(delta as integer)
    idx = m.list.itemFocused
    ' The Reset item is not a row and cannot be moved.
    if idx < 0 or idx >= m.rows.count() then return
    dest = idx + delta
    if dest < 0 or dest > m.rows.count() - 1 then return
    MoveHomeRowTo(idx, dest)
    KLog("settings", "home row order: " + m.rows[idx].rid + " " + idx.toStr() + " -> " + dest.toStr())
    load()
    ' Follow the row that moved, so a member can press Left twice without
    ' looking down at the remote to find their place again. jumpToItem, not
    ' animateToItem — this is restoring a position, not travelling to one.
    if dest >= 0 and dest < m.rows.count() then m.list.jumpToItem = dest
    m.list.setFocus(true)
end sub

' LEFT AND RIGHT ARE CLAIMED IN BOTH DIRECTIONS, including at the ends, so the
' highlight can never wander off the row a member is moving. BACK is the only
' way out of this screen — Left is a move here, unlike every other list in the
' app, which is what the line under the title is for.
function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back"
        m.top.closed = true
        return true
    end if
    if key = "left"
        moveFocused(-1)
        return true
    end if
    if key = "right"
        moveFocused(1)
        return true
    end if
    return false
end function
