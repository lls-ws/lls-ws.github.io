' Put favorites, or favorite lists, in the order the member wants them on
' Home. OK opens an action dialog; every change saves immediately and Home
' picks it up the next time it builds its rows.
'
' THE ORDER IS THE STORED LIST ITSELF — see the note above moveInArray in
' Store.brs. Nothing extra is written to the registry by this screen, which
' matters: the whole app shares 16-32 KB and a write past it fails silently.
'
' The rows are drawn from the SAME calls Home draws from (LoadFavoriteChannels,
' LoadFavoriteVod, LoadLists), in the same order, with nothing filtered out.
' That is deliberate — a screen for putting things in order has to show the
' member exactly the list they are trying to fix, including the rows from a
' second source, which is what Home shows them.

sub init()
    m.theme = KwickTheme()
    m.top.findNode("bg").color = m.theme.background
    ' This screen is a scene-level overlay, so its own backdrop covers
    ' AppScene's grid wash. See AddPageGrid() in Theme.brs — the mesh
    ' goes in at child 1, just above the backdrop declared first in the
    ' XML above, and under everything this screen draws.
    AddPageGrid(m.top)

    header = m.top.findNode("header")
    header.text = m.top.titleText
    header.font = UiBoldFont(42)
    header.color = m.theme.textPrimary

    m.subhead = m.top.findNode("subhead")
    sf = UiFont(24)
    m.subhead.font = sf
    m.subhead.color = m.theme.textSecondary

    m.empty = m.top.findNode("empty")
    m.empty.font = sf
    m.empty.color = m.theme.textSecondary

    m.list = m.top.findNode("list")
    ' 22pt, and the ROW was widened to 1400 to suit it rather than the type
    ' dropped to suit the row — see the note on the LabelList in the XML.
    ' 1400 at 22 mono is 106 characters; the longest row this screen builds
    ' is about 80 (an index, a film title, a source tag and "·  Movie"),
    ' so a title like "The Lord of the Rings: The Fellowship of the Ring"
    ' now reads in full where at 1000 it was cut mid-title. Do not drop
    ' this to 20 to reclaim width — the width is already there.
    ThemeLabelList(m.list, 22)
    m.list.observeField("itemSelected", "onSelected")

    m.scope = m.top.scope
    m.rows = []
    m.top.observeField("focusedChild", "onFocusIn")
    load()
end sub

sub onFocusIn()
    if m.top.hasFocus() and m.rows.count() > 0 then m.list.setFocus(true)
end sub

function isLists() as boolean
    return m.scope = "lists"
end function

' More than one source means a name on its own can be ambiguous — the same
' channel can be a favorite on two of them. Only paid for when it matters:
' with one source configured there is nothing to tell apart.
function srcTagFor(entry as dynamic) as string
    if m.multiSource <> true then return ""
    label = SourceLabelFor(ToStr(GetField(entry, "src")))
    if label = "" then return ""
    return "   [" + label + "]"
end function

sub load()
    m.multiSource = (SourceCount() > 1)
    m.rows = []
    if isLists()
        m.subhead.text = "Press OK to move a list up or down. This is the order their rows appear on Home."
        for each l in LoadLists()
            onOff = "   (Row off)"
            if l.homeRow = true then onOff = ""
            m.rows.push({ label: ToStr(l.name) + onOff })
        end for
    else if m.scope = "favvod"
        m.subhead.text = "Press OK to move a title up or down, or take it out of your favorites."
        for each f in LoadFavoriteVod()
            kind = "Movie"
            if ToStr(f.kind) = "series" then kind = "Series"
            m.rows.push({ label: ToStr(f.name) + srcTagFor(f) + "   ·  " + kind, entry: f })
        end for
    else
        m.subhead.text = "Press OK to move a channel up or down, or take it out of your favorites."
        for each c in LoadFavoriteChannels()
            nm = ToStr(c.name)
            ' Favorites that arrived over KwickSync before their source was
            ' loaded carry no name yet (EnrichFavoriteChannels fills them in
            ' when Live TV next runs). A blank row can still be moved, so it
            ' is labelled rather than hidden.
            if nm = "" then nm = "Channel " + ToStr(c.streamId)
            m.rows.push({ label: nm + srcTagFor(c), entry: c })
        end for
    end if
    fillList()
end sub

sub fillList()
    if m.rows.count() = 0
        ' Settings only offers this screen when there is something on it, so
        ' this is the case where the last row went away while it was open.
        m.list.visible = false
        m.empty.visible = true
        m.empty.text = "Nothing left to put in order."
        return
    end if
    m.list.visible = true
    m.empty.visible = false
    content = CreateObject("roSGNode", "ContentNode")
    for i = 0 to m.rows.count() - 1
        item = content.createChild("ContentNode")
        ' Numbered, because on a list of a dozen favorites "did that actually
        ' move?" is the only question a member has, and two rows that look
        ' alike answer it badly.
        item.title = (i + 1).toStr() + ".  " + m.rows[i].label
    end for
    m.list.content = content
end sub

sub onSelected()
    idx = m.list.itemSelected
    if idx < 0 or idx >= m.rows.count() then return
    m.actionIdx = idx
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = m.rows[idx].label
    ' Only the moves this row can actually make. A greyed-out button is not a
    ' thing a Roku dialog has, so an impossible one would simply do nothing.
    btns = []
    m.actions = []
    if idx > 0
        btns.push("Move to Top")
        m.actions.push("top")
        btns.push("Move Up")
        m.actions.push("up")
    end if
    if idx < m.rows.count() - 1
        btns.push("Move Down")
        m.actions.push("down")
    end if
    if not isLists()
        btns.push("Remove from Favorites")
        m.actions.push("remove")
    end if
    btns.push("Cancel")
    m.actions.push("cancel")
    dialog.buttons = btns
    ' House rule: a D-pad user can't click, so the primary action is focused.
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onAction")
    m.top.getScene().dialog = dialog
end sub

sub onAction()
    dialog = m.top.getScene().dialog
    choice = dialog.buttonSelected
    dialog.close = true
    if choice < 0 or choice >= m.actions.count()
        m.top.setFocus(true)
        return
    end if
    action = m.actions[choice]
    idx = m.actionIdx
    dest = idx
    if action = "top"
        dest = 0
    else if action = "up"
        dest = idx - 1
    else if action = "down"
        dest = idx + 1
    else if action = "remove"
        removeAt(idx)
        load()
        ' Land on the row that took its place, or the new last row. With
        ' nothing left the list is hidden, so focus goes to the screen itself
        ' — focusing a hidden node would leave Back with nothing listening.
        keep = idx
        if keep > m.rows.count() - 1 then keep = m.rows.count() - 1
        if m.rows.count() > 0
            if keep >= 0 then m.list.jumpToItem = keep
            m.list.setFocus(true)
        end if
        m.top.setFocus(true)
        return
    else
        m.top.setFocus(true)
        return
    end if

    if isLists()
        MoveListTo(idx, dest)
    else if m.scope = "favvod"
        MoveFavoriteVodTo(idx, dest)
    else
        MoveFavoriteChannelTo(idx, dest)
    end if
    KLog("settings", "reorder " + m.scope + ": " + idx.toStr() + " -> " + dest.toStr())
    load()
    ' Follow the row that moved, so a member can press Move Up twice without
    ' looking down at the remote to find their place again.
    if dest >= 0 and dest < m.rows.count() then m.list.jumpToItem = dest
    m.list.setFocus(true)
    m.top.setFocus(true)
end sub

' Taking a favorite off goes through the SAME toggle every heart in the app
' uses, so there is one place a favorite can be removed and one place the
' index and the sync push are kept honest.
'
' THE src FIELD IS SPELLED OUT, always, including when it is empty. A KwickTV
' favorite is stored with no src at all (ToggleFavoriteChannel only writes the
' field when the token isn't blank), and ItemSrcToken tells "the field is
' absent" apart from "the field is empty" on purpose: absent means "whatever
' source is active", which on a box whose active source is an Xtream playlist
' is the WRONG source — the toggle would find no matching row, decide it was
' an add, and put the channel back rather than take it off. Passing the token
' explicitly removes the guess.
sub removeAt(idx as integer)
    entry = m.rows[idx].entry
    if entry = invalid then return
    token = ToStr(GetField(entry, "src"))
    if m.scope = "favvod"
        ToggleFavoriteVod({
            kind: ToStr(entry.kind)
            id: ToStr(entry.id)
            name: ToStr(GetField(entry, "name"))
            icon: ToStr(GetField(entry, "icon"))
            ext: ToStr(GetField(entry, "ext"))
            src: token
        })
    else
        ToggleFavoriteChannel({
            streamId: ToStr(entry.streamId)
            name: ToStr(GetField(entry, "name"))
            logo: ToStr(GetField(entry, "logo"))
            url: ToStr(GetField(entry, "url"))
            src: token
        })
    end if
    KLog("settings", "removed a favorite from " + m.scope)
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back" or key = "left"
        m.top.closed = true
        return true
    end if
    return false
end function
