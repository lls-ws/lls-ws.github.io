' Add a Jellyfin or Emby server. See the XML for why it is an address and an
' API key rather than a username and password, and why the brand and the user
' are worked out rather than asked for.

sub init()
    m.theme = KwickTheme()
    m.top.findNode("bg").color = m.theme.background
    AddPageGrid(m.top)

    setText("title", "Add a media server", UiBoldFont(44), m.theme.textPrimary)
    setText("blurb", "Connect your own Jellyfin or Emby server. Type its address and sign in with the same username and password you use on that server. Your films and shows then sit in Movies & Series alongside your other sources.", UiFont(24), m.theme.textSecondary)
    setText("status", "", UiFont(24), m.theme.textSecondary)
    setText("hint", "Press Back to go back", UiFont(20), m.theme.textSecondary)

    m.values = { server: "", username: "", password: "" }
    ' secure: masked on screen and dictated letter by letter, which is what
    ' certification 4.12 asks of a password field.
    m.defs = [
        { key: "server", label: "Server address", hint: "https://jellyfin.example.com", secure: false },
        { key: "username", label: "Username", hint: "your account on that server", secure: false },
        { key: "password", label: "Password", hint: "", secure: true }
    ]
    m.focusIdx = 0
    m.busy = false
    m.rowNodes = []
    buildRows()
    m.top.setFocus(true)
end sub

sub setText(id as string, value as string, font as object, color as string)
    n = m.top.findNode(id)
    n.text = value
    n.font = font
    n.color = color
end sub

' ---- The form ----------------------------------------------------------------

sub buildRows()
    rows = m.top.findNode("rows")
    while rows.getChildCount() > 0
        rows.removeChildIndex(0)
    end while
    m.rowNodes = []
    y = 0
    for i = 0 to m.defs.count() - 1
        d = m.defs[i]
        ring = rows.createChild("Rectangle")
        ring.width = 1180 : ring.height = 84
        ring.translation = [0, y]
        ring.color = m.theme.focusHighlight
        ring.visible = false

        fieldBox = rows.createChild("Rectangle")
        fieldBox.width = 1172 : fieldBox.height = 76
        fieldBox.translation = [4, y + 4]
        fieldBox.color = m.theme.surfaceElevated

        lbl = rows.createChild("Label")
        lbl.text = d.label
        lbl.font = UiFont(24)
        lbl.color = m.theme.textSecondary
        lbl.translation = [28, y + 4]
        lbl.height = 76
        lbl.vertAlign = "center"
        lbl.width = 340

        valLbl = rows.createChild("Label")
        valLbl.font = UiFont(24)
        valLbl.color = m.theme.textPrimary
        valLbl.translation = [380, y + 4]
        valLbl.height = 76
        valLbl.width = 780
        valLbl.vertAlign = "center"

        m.rowNodes.push({ ring: ring, value: valLbl, def: d })
        y = y + 100
    end for

    ' Connect
    bring = rows.createChild("Rectangle")
    bring.width = 420 : bring.height = 84
    bring.translation = [0, y + 16]
    bring.color = m.theme.focusHighlight
    bring.visible = false
    bbox = rows.createChild("Rectangle")
    bbox.width = 412 : bbox.height = 76
    bbox.translation = [4, y + 20]
    bbox.color = m.theme.accent
    blbl = rows.createChild("Label")
    blbl.text = "Connect"
    blbl.font = UiBoldFont(26)
    blbl.color = m.theme.background
    blbl.translation = [4, y + 20]
    blbl.width = 412 : blbl.height = 76
    blbl.horizAlign = "center" : blbl.vertAlign = "center"
    m.connectRing = bring
    m.connectLabel = blbl

    redrawRows()
end sub

sub redrawRows()
    for i = 0 to m.rowNodes.count() - 1
        r = m.rowNodes[i]
        r.ring.visible = (i = m.focusIdx)
        v = ToStr(m.values[r.def.key])
        if v = ""
            r.value.text = r.def.hint
            r.value.color = m.theme.textSecondary
        else
            if r.def.secure = true
                r.value.text = maskSecret(v)
            else
                r.value.text = v
            end if
            r.value.color = m.theme.textPrimary
        end if
    end for
    m.connectRing.visible = (m.focusIdx = m.rowNodes.count())
end sub

' An API key is a credential: show that one is there and how it ends, never
' the whole of it. A member reading their key off a TV in a shared room should
' not be handing it to the room.
function maskSecret(v as string) as string
    if Len(v) <= 4 then return "****"
    out = ""
    for i = 1 to Len(v) - 4
        out = out + "*"
    end for
    return out + Right(v, 4)
end function

' ---- Typing ------------------------------------------------------------------

sub openKeyboard(idx as integer)
    if idx < 0 or idx >= m.rowNodes.count() then return
    d = m.rowNodes[idx].def
    kb = CreateObject("roSGNode", "StandardKeyboardDialog")
    kb.title = d.label
    kb.text = ToStr(m.values[d.key])
    kb.buttons = ["OK", "Cancel"]
    if d.secure = true
        kb.keyboardDomain = "password"
    else if d.key = "username"
        kb.keyboardDomain = "alphanumeric"
    else
        kb.keyboardDomain = "generic"
    end if
    edit = kb.textEditBox
    edit.voiceEnabled = true
    edit.voiceEntryType = kb.keyboardDomain
    if d.secure = true then edit.secureMode = true
    m.kbKey = d.key
    m.kb = kb
    kb.observeField("buttonSelected", "onKeyboardButton")
    kb.observeField("wasClosed", "onKeyboardClosed")
    m.top.getScene().dialog = kb
end sub

sub onKeyboardButton()
    if m.kb = invalid then return
    if m.kb.buttonSelected = 0
        m.values[m.kbKey] = StdKeyboardText(m.kb)
    end if
    m.kb.close = true
end sub

sub onKeyboardClosed()
    m.kb = invalid
    redrawRows()
    m.top.setFocus(true)
end sub

' ---- Connecting --------------------------------------------------------------
'
' Two steps, the second only taken because the first answered:
'   1. /System/Info/Public       — is this a media server, which one, its id
'   2. /Users/AuthenticateByName — sign in, and get back a token and a user id
'
' Step 1 needs no credentials, which is what lets a mistyped address be told
' apart from a mistyped password: the first fails "not a media server", the
' second fails "username or password was not accepted".
'
' THE PASSWORD IS NEVER STORED. Signing in trades it for a token, the token is
' what gets saved, and the member can revoke it from their own server's
' dashboard whenever they like — the same bargain the phone app makes.

sub startConnect()
    if m.busy then return
    server = normalizeBase(ToStr(m.values.server))
    user = ToStr(m.values.username).trim()
    if server = ""
        say("Type your server's address first.")
        return
    end if
    if user = ""
        say("Type your username on that server.")
        return
    end if
    m.values.server = server
    m.busy = true
    m.connectLabel.text = "Connecting..."
    say("Asking " + server + " what it is...")
    m.probeBase = server
    m.probeTriedEmbyPath = false
    probePublicInfo(server)
end sub

' Roku needs a scheme, and a member types the address off their own dashboard
' where it usually has one. Anything without a scheme is assumed http, which is
' what a home server on a LAN almost always is; a trailing slash and a trailing
' /web (what a browser shows while they are looking at the dashboard) are cut.
function normalizeBase(v as string) as string
    b = v.trim()
    if b = "" then return ""
    if Instr(1, LCase(b), "://") = 0 then b = "http://" + b
    at = Instr(1, LCase(b), "/web")
    if at > 8 then b = Left(b, at - 1)
    while Len(b) > 0 and Right(b, 1) = "/"
        b = Left(b, Len(b) - 1)
    end while
    return b
end function

sub probePublicInfo(base as string)
    t = CreateObject("roSGNode", "MediaServerTask")
    t.url = MsPublicInfoUrl(base)
    t.method = "GET"
    t.timeoutMs = 20000
    t.observeField("result", "onPublicInfo")
    m.probeTask = t
    t.control = "RUN"
end sub

sub onPublicInfo(event as object)
    res = event.getData()
    if res = invalid then return
    if res.ok <> true
        ' An Emby published under /emby answers nothing at the bare address.
        ' Try that ONE alternative before giving up, and remember whichever
        ' form answered — that is what gets stored and used forever after.
        if not m.probeTriedEmbyPath and Right(LCase(m.probeBase), 5) <> "/emby"
            m.probeTriedEmbyPath = true
            m.probeBase = m.probeBase + "/emby"
            say("Not there — trying " + m.probeBase + "...")
            probePublicInfo(m.probeBase)
            return
        end if
        finishBusy()
        say(ToStr(res.error))
        return
    end if

    d = res.data
    m.serverName = ToStr(GetField(d, "ServerName"))
    m.serverId = ToStr(GetField(d, "Id"))
    product = ToStr(GetField(d, "ProductName"))
    version = ToStr(GetField(d, "Version"))
    ' Jellyfin names itself here; Emby sends no ProductName at all.
    if Instr(1, LCase(product), "jellyfin") > 0
        m.brand = "jellyfin"
    else
        m.brand = "emby"
    end if
    if m.serverId = ""
        finishBusy()
        say("That address answered, but it did not say which server it is. Check it is the server's own address.")
        return
    end if
    label = "Jellyfin"
    if m.brand = "emby" then label = "Emby"
    nm = m.serverName
    if nm = "" then nm = m.probeBase
    say("Found " + label + " " + version + " — " + nm + ". Signing in...")
    signIn()
end sub

' POST /Users/AuthenticateByName {"Username":..,"Pw":..}. The field is Pw, not
' Password - both servers ignore "Password" and answer 401, which reads to a
' member as a wrong password when it is really a wrong field name.
sub signIn()
    stub = { ptype: m.brand, server: m.probeBase, token: "", userId: "", serverId: m.serverId }
    body = FormatJson({ Username: ToStr(m.values.username).trim(), Pw: ToStr(m.values.password) })
    t = CreateObject("roSGNode", "MediaServerTask")
    t.url = MsAuthUrl(m.probeBase)
    t.method = "POST"
    t.bodyJson = body
    t.headers = MsHeaders(stub)
    t.timeoutMs = 25000
    t.observeField("result", "onSignIn")
    m.authTask = t
    t.control = "RUN"
end sub

sub onSignIn(event as object)
    res = event.getData()
    if res = invalid then return
    finishBusy()
    if res.ok <> true
        say(ToStr(res.error))
        return
    end if
    d = res.data
    token = ToStr(GetField(d, "AccessToken"))
    u = GetField(d, "User")
    uid = ""
    uname = ""
    if u <> invalid
        uid = ToStr(GetField(u, "Id"))
        uname = ToStr(GetField(u, "Name"))
    end if
    if token = "" or uid = ""
        say("The server accepted the sign-in but returned no session. Try again, or check the account is allowed to sign in.")
        return
    end if
    if uname = "" then uname = ToStr(m.values.username).trim()
    saveServer(token, uid, uname)
end sub

sub saveServer(token as string, userId as string, userName as string)
    label = "Jellyfin"
    if m.brand = "emby" then label = "Emby"
    nm = m.serverName
    if nm = "" then nm = label
    ' The sign-in is kept alongside the token, exactly as a source paired on
    ' kwickplayer.tv keeps it and exactly as an Xtream source has always kept
    ' its password. A media server's token does not last forever, and without
    ' the sign-in behind it an expired token is a dead source the member can
    ' only fix by deleting it and typing everything again. With it, the
    ' app's own sign-in sweep (MediaServerSignIn) heals it on the next
    ' launch without anybody being told anything.
    p = {
        ptype: m.brand,
        name: nm,
        server: m.probeBase,
        username: ToStr(m.values.username).trim(),
        password: ToStr(m.values.password),
        token: token,
        userId: userId,
        userName: userName,
        serverId: m.serverId
    }
    AddProvider(p)
    KLog("mediaserver", "added " + label + " '" + nm + "' as " + userName + " (" + MsSrcToken(p) + ")")
    m.top.added = true
    closeScreen()
end sub

sub finishBusy()
    m.busy = false
    m.connectLabel.text = "Connect"
end sub

sub say(msg as string)
    m.top.findNode("status").text = msg
end sub

sub closeScreen()
    m.top.closed = true
end sub

' ---- Remote ------------------------------------------------------------------

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    last = m.rowNodes.count()          ' the Connect button's index
    if key = "up"
        if m.focusIdx > 0
            m.focusIdx = m.focusIdx - 1
            redrawRows()
        end if
        return true
    else if key = "down"
        if m.focusIdx < last
            m.focusIdx = m.focusIdx + 1
            redrawRows()
        end if
        return true
    else if key = "OK"
        if m.focusIdx = last
            startConnect()
        else
            openKeyboard(m.focusIdx)
        end if
        return true
    else if key = "back"
        closeScreen()
        return true
    end if
    return false
end function
