' Scrollable subtitle picker: the caller passes display labels (row 0 = Off);
' picking fires chosen (0-based row) + picked, Back cancels with closed only.

sub init()
    m.theme = KwickTheme()
    m.top.findNode("panel").color = m.theme.surface

    m.title = m.top.findNode("title")
    ' Held at 34. The player is the only caller and its longest title is
    ' "Closed Captions" — 15 characters, 306px of JetBrains Mono in a 680px
    ' box, so the shell type costs this label nothing.
    m.title.font = UiBoldFont(34)
    m.title.color = m.theme.textPrimary
    m.title.text = m.top.titleText

    m.note = m.top.findNode("note")
    ' 25 -> 22, and NOT because the sentence runs out of characters — the
    ' longest note is 114 and even mono 25 holds 181 over four lines. It is
    ' the LINE HEIGHT: mono's box is taller than Roboto's, so four lines at
    ' 25 grow past the 120px onNoteText below assumes and land on the list
    ' at y=360. At 22 four lines are ~116px and the gap is honest again.
    m.note.font = UiFont(22)
    m.note.color = m.theme.textSecondary

    m.panel = m.top.findNode("panel")
    ' Where the list starts, kept in step with onNoteText so sizePanel() can
    ' work out the height without reading it back off the node.
    m.listTop = 240

    m.list = m.top.findNode("list")
    ' No wrap assignment: MarkupList has no such field and setting it logs a
    ' device warning on every open. vertFocusAnimationStyle="floatingFocus"
    ' in the XML is what actually stops wraparound.
    m.list.observeField("itemSelected", "onSelected")
    m.top.observeField("labels", "onLabels")
    m.top.observeField("titleText", "onTitleText")
    m.top.observeField("noteText", "onNoteText")
    m.top.observeField("focusedChild", "onFocusIn")
end sub

sub onTitleText()
    m.title.text = m.top.titleText
end sub

' A note pushes the list down rather than overlapping it. Four wrapped lines
' at 22px of JetBrains Mono is ~116px, so the list starts at 360 and loses two
' rows. The 360 is unchanged from the Roboto build; only the type shrank.
sub onNoteText()
    t = m.top.noteText
    m.note.text = t
    m.note.visible = (t <> "")
    if t <> ""
        m.list.translation = [620, 360]
        m.list.numRows = 8
        m.listTop = 360
    else
        m.list.translation = [620, 240]
        m.list.numRows = 10
        m.listTop = 240
    end if
end sub

' ---- The panel is sized to what is actually in it ---------------------------
'
' The 760x820 in the XML is the TALLEST this can need — ten rows of subtitle
' tracks under a note — and it used to be the only size there was. A two-row
' list got the same 820px box, so "Closed Captions: Off / On" drew two rows at
' the top of a panel with 600px of empty slate under them, and so did the
' player's "Carry on where you left off?".
'
' Rows beyond numRows scroll, so the height follows whichever is smaller.
sub sizePanel()
    rows = m.top.labels.count()
    if rows > m.list.numRows then rows = m.list.numRows
    if rows < 1 then rows = 1
    ' (top of list - top of panel) + the rows themselves + a bottom margin
    ' that matches the 40px between the panel top and the title.
    h = (m.listTop - 130) + rows * 66 + 40
    if h > 820 then h = 820
    m.panel.height = h
end sub

sub onLabels()
    marks = m.top.marks
    content = CreateObject("roSGNode", "ContentNode")
    i = 0
    for each l in m.top.labels
        item = content.createChild("ContentNode")
        item.title = l
        if marks <> invalid and i < marks.count() then item.description = marks[i] else item.description = ""
        i = i + 1
    end for
    m.list.content = content
    m.list.jumpToItem = m.top.startIndex
    ' Last, because it needs the row count that was just set.
    sizePanel()
end sub

sub onFocusIn()
    if m.top.hasFocus() then m.list.setFocus(true)
end sub

sub onSelected()
    m.top.chosen = m.list.itemSelected
    m.top.picked = true
    m.top.closed = true
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back"
        ' Back from partway down jumps to the top; Back at the top exits.
        if m.list.itemFocused > 0
            m.list.jumpToItem = 0
            return true
        end if
        m.top.closed = true
        return true
    end if
    return false
end function
