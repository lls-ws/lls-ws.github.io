' Settings — the landing grid.
'
' This used to be one flat list of every setting in the app, forty-odd rows
' deep, divided only by a section name that changed as you scrolled. Sign
' out lived thirty-five presses below Sources. It is now nine category
' tiles, three across and three down, and each tile opens a
' SettingsCategoryScreen carrying only that category's rows — so the
' deepest anything sits is two presses, and the whole of Settings is
' readable in one glance from the sofa.
'
' The tiles themselves are built by hand in a Group rather than put in a
' MarkupGrid, the same way the profile picker builds its avatar row. Nine
' fixed tiles never scroll, so there is nothing for a grid component to
' virtualise, and doing the arrow keys here means Left on the first column
' is guaranteed to fall through to the sidebar instead of being swallowed
' by a list's own edge handling.
'
' Every tile exists in BOTH editions, in the same place. The store and
' sideload builds differ only in the rows INSIDE Sources and Account &
' help, so the grid a member learns never moves under them.

sub init()
    m.theme = KwickTheme()
    m.branding = KwickBranding()

    header = m.top.findNode("header")
    header.text = "Settings"
    header.font = UiBoldFont(46)
    header.color = m.theme.textPrimary

    m.version = m.top.findNode("version")
    m.version.font = UiFont(24)
    m.version.color = m.theme.textSecondary
    m.version.text = m.branding.fullAppName + " for Roku  ·  v" + appVersion()

    ' The account line stays on the landing screen, where it has always
    ' been. It is the single most-asked question in support ("when does
    ' mine run out?"), it is status rather than a setting — there is
    ' nothing to press — and a member should not have to guess which tile
    ' it hides behind. Keeping it here also means the answer is on screen
    ' the moment Settings opens, exactly as before.
    m.accountInfo = m.top.findNode("accountInfo")
    ' 27 -> 25 for the JetBrains Mono sweep. This label has no width and
    ' auto-sizes, so it cannot truncate — it OVERFLOWS instead, and its
    ' longest form ("<source name> — Active  ·  renews/expires 12 Jan 2027
    ' ·  max connections 2") is about 70 characters. At 27 mono that is
    ' 1134px from x=192, which a source name of any length pushes past the
    ' title-safe right edge at 1726. Two points buys back ~80px.
    m.accountInfo.font = UiFont(25)
    m.accountInfo.color = m.theme.textSecondary

    m.tilesGroup = m.top.findNode("tiles")
    m.cat = invalid
    m.catId = ""
    m.focusIdx = 0
    buildGrid()
    loadAccountInfo()
end sub

' ---- The tiles --------------------------------------------------------------
'
' Grouping notes, because the old section headers were not a good starting
' point — they grew one at a time and several were arbitrary:
'
'   Sources          the sources themselves plus every way of adding one,
'                    and the per-source custom guide, which is set once per
'                    source and belongs beside the source it belongs to.
'   Profiles         one row in the old list, so it gets no screen at all —
'                    the tile IS the button, and its subtitle names whoever
'                    is watching.
'   Playback         start-muted lived alone under PLAYBACK and the three
'                    caption rows lived alone under their own header. They
'                    are all "how a video plays", so they are one screen.
'   Home screen      the three home-row switches, plus the member's own
'                    lists — the only thing a list does on this screen is
'                    turn its home row on and off, so this is where they go.
'   Categories       hide/reorder for Live TV, Movies and Series were split
'                    across two headers for no reason other than the order
'                    they were written in. Same job, one screen, with
'                    channel sort order alongside the Live TV one.
'   Parental         unchanged in content; the tile carries the state.
'   KwickSync        unchanged in content; the tile carries the status, so
'                    "when did this last sync" needs no presses at all.
'   Reset            the old DATA section, named for what it does.
'   Account & help   logs, the community links, and the clean slate that
'                    signs out and clears this television.
'
' Tile geometry: 486 x 214 faces, 32 apart across and 34 down, first face at
' local (88, 256). The focus frame stands 6px proud of the face on every
' side, and it is the frame that is fitted to the title-safe box rather than
' the face: the outer bounds of the nine frames come to exactly 192..1726
' across and 250..972 down in absolute screen pixels, which is the FHD
' title-safe rectangle to the pixel. (This Group is the shell's content
' pane, already shifted right by the 110px sidebar, so local 88 is absolute
' 198 and the frame's left edge lands on 192.)
'
' WHY THERE IS NO TENTH TILE, asked twice now and answered the same way both
' times. Nine is what fits: a fourth ROW needs 248 more pixels and there are
' 108 left under the bottom edge, and shrinking the tiles to make one is not
' available either — a tile's own contents are 196px of the 214 it has. A
' fourth COLUMN is arithmetically possible and is the only way: 359px tiles
' instead of 486, which costs the title font (17 characters of "Parental
' controls" at 34 mono is 347px and would no longer fit) and moves all nine
' tiles a member has already learned. That is a look for Mason to approve, not
' a decision to take while adding a feature — so the background effect went
' inside Home & appearance, and the add-ons (JB-7) have gone inside Playback,
' each on the tile whose subject they belong to.
function tileDefs() as object
    return [
        { id: "sources", title: "Sources", subtext: sourcesTileText(), icon: m.theme.iconPlaylist },
        { id: "profiles", title: "Profiles", subtext: ToStr(ActiveProfile().name), icon: m.theme.iconPeople },
        ' "and add-ons" is on this tile because the add-ons live on the
        ' Playback screen — see the note under the geometry above, and the
        ' ADD-ONS section in SettingsCategoryScreen.buildPlaybackRows. 38
        ' characters wraps to two lines inside the 442px box at 24 mono
        ' ("Sound, captions, subtitles" / "and add-ons"), which is the two
        ' lines this label has.
        { id: "playback", title: "Playback", subtext: "Sound, captions, subtitles and add-ons", icon: m.theme.iconPlay },
        { id: "home", title: "Home screen", subtext: "Rows on Home, and the background effect", icon: m.theme.iconHome },
        { id: "categories", title: "Categories", subtext: "Hide, reorder and sort", icon: m.theme.iconCategory },
        { id: "parental", title: "Parental controls", subtext: parentalTileText(), icon: m.theme.iconLock },
        { id: "sync", title: "KwickSync", subtext: syncTileText(), icon: m.theme.iconSync },
        { id: "reset", title: "Reset", subtext: "Clear history and hidden channels", icon: m.theme.iconRestore },
        { id: "account", title: "Account & help", subtext: accountTileText(), icon: m.theme.iconAccount }
    ]
end function

function sourcesTileText() as string
    n = LoadProviders().count()
    if n = 1 then return "1 source connected"
    return n.toStr() + " sources connected"
end function

' The big thing behind this tile is the clean slate — sign out AND clear every
' playlist — and that is a DIFFERENT job from the KwickTV row's own Sign out
' over in Sources. A tile that just said "sign out" would send a member here
' for the small one and hand them the big one, so it carries the row's own
' words instead of a shorter paraphrase: two ways of saying it is two things
' to tell apart, and there is nothing to gain by inventing a second. On a TV
' running playlists alone there is nothing to sign out of, so that half drops
' off and the clearing stays. (The subtitle wraps to two lines at 442px, which
' the longer of these needs and has.) The grid is rebuilt every time a category
' closes, so this tile follows the screen behind it the moment anything
' changes.
function accountTileText() as string
    if LoadProviders().count() = 0 then return "Get help from the team"
    if KwickTvProvider() <> invalid then return "Get help, or sign out and clear this TV"
    return "Get help, or clear this TV"
end function

function parentalTileText() as string
    if HasParentalPin() then return "PIN is set"
    return "No PIN yet"
end function

' The status a member actually opens KwickSync to read, printed on the tile
' so most of the time they never have to open it.
function syncTileText() as string
    if not SyncEligible() then return "Sign in with KwickTV to use it"
    if not SyncEnabled() then return "Off for this device"
    last = SyncLastAt()
    if last = 0 then return "On — not synced yet"
    return "On — synced " + agoText(last)
end function

sub buildGrid()
    while m.tilesGroup.getChildCount() > 0
        m.tilesGroup.removeChildIndex(0)
    end while

    m.tileDefs = tileDefs()

    iconFont = IconFont(54)
    ' Widest tile title is "Parental controls" — 17 chars, 347px at 34 mono,
    ' inside the 450px name box. Widest subtitle is "Get help, or sign out
    ' and clear this TV" — 39 chars, which still word-wraps to two lines
    ' inside the 442px box at 24 mono (longest line 25 chars = 360px). Both
    ' hold; no size change needed here.
    titleFont = UiBoldFont(34)
    subFont = UiFont(24)

    m.cells = []
    for i = 0 to m.tileDefs.count() - 1
        d = m.tileDefs[i]
        col = i mod 3
        row = Int(i / 3)
        x = 88 + col * 518
        y = 256 + row * 248

        ' Drawn first and six pixels proud on every side, so the face laid
        ' over it leaves a frame rather than a glow — the same trick the
        ' setting rows and the profile tiles use.
        ring = m.tilesGroup.createChild("Rectangle")
        ring.width = 498
        ring.height = 226
        ring.translation = [x - 6, y - 6]
        ring.color = m.theme.focusHighlight
        ring.visible = false

        face = m.tilesGroup.createChild("Rectangle")
        face.width = 486
        face.height = 214
        face.translation = [x, y]
        face.color = m.theme.surface

        glyph = face.createChild("Label")
        glyph.width = 486
        glyph.height = 58
        glyph.translation = [0, 24]
        glyph.horizAlign = "center"
        glyph.vertAlign = "center"
        glyph.font = iconFont
        glyph.color = m.theme.accentAlt
        glyph.text = d.icon

        name = face.createChild("Label")
        name.width = 450
        name.height = 40
        name.translation = [18, 90]
        name.horizAlign = "center"
        name.vertAlign = "center"
        name.font = titleFont
        name.color = m.theme.textPrimary
        name.text = d.title

        state = face.createChild("Label")
        state.width = 442
        state.height = 62
        state.translation = [22, 134]
        state.horizAlign = "center"
        state.wrap = true
        state.maxLines = 2
        state.font = subFont
        state.color = m.theme.textSecondary
        state.text = d.subtext

        m.cells.push({ ring: ring, face: face, glyph: glyph, state: state })
    end for

    if m.focusIdx >= m.cells.count() then m.focusIdx = 0
    applyFocus()
end sub

sub applyFocus()
    for i = 0 to m.cells.count() - 1
        c = m.cells[i]
        on = (i = m.focusIdx)
        c.ring.visible = on
        if on
            c.face.color = m.theme.surfaceElevated
            c.glyph.color = m.theme.focusHighlight
            c.state.color = m.theme.textPrimary
        else
            c.face.color = m.theme.surface
            c.glyph.color = m.theme.accentAlt
            c.state.color = m.theme.textSecondary
        end if
    end for
end sub

' ---- Opening a category -----------------------------------------------------

sub openTile(idx as integer)
    if idx < 0 or idx >= m.tileDefs.count() then return
    id = m.tileDefs[idx].id

    ' Profiles was a single row, and a screen holding one row is a wasted
    ' press — so the tile does the thing the row did.
    if id = "profiles"
        m.top.getScene().switchProfile = true
        return
    end if

    ' The only category that can be empty. It used to be a row that read
    ' "Cross-device sync — sign in with KwickTV to enable" and did nothing
    ' when you pressed it; now the tile says so, and pressing it explains
    ' properly instead of opening a screen with nothing on it.
    if id = "sync" and not SyncEligible()
        showSyncLocked()
        return
    end if

    openCategory(id)
end sub

sub openCategory(id as string)
    m.catId = id
    m.cat = m.top.getScene().createChild("SettingsCategoryScreen")
    m.cat.observeField("closed", "onCategoryClosed")
    m.cat.observeField("signedOut", "onCategorySignedOut")
    m.cat.category = id
    m.cat.setFocus(true)
end sub

sub onCategoryClosed()
    ' The account line under the header is drawn from the active source, and
    ' those are the two screens that can change which source that is —
    ' Sources adds and removes them, and Account & help clears the lot.
    ' Anywhere else the line is still true and the probe behind it would be a
    ' network round trip for nothing.
    sourceMayHaveChanged = (m.catId = "sources" or m.catId = "account")
    if m.cat <> invalid
        m.top.getScene().removeChild(m.cat)
        m.cat = invalid
    end if
    m.catId = ""
    ' Tile subtitles carry live state — the profile name, the sync clock,
    ' whether a PIN exists, how many sources there are — so the grid is
    ' rebuilt on the way back rather than left showing what was true when
    ' Settings opened. The focused tile is remembered, so Back lands the
    ' member exactly where they left.
    buildGrid()
    if sourceMayHaveChanged then loadAccountInfo()
    m.top.setFocus(true)
end sub

sub onCategorySignedOut()
    if m.cat = invalid then return
    if m.cat.signedOut <> true then return
    m.top.getScene().removeChild(m.cat)
    m.cat = invalid
    m.catId = ""
    m.top.signedOut = true
end sub

sub showSyncLocked()
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "KwickSync"
    dialog.message = "KwickSync keeps your profiles, favorites and watch history the same on every device you use." + Chr(10) + Chr(10) + "Sign in with KwickTV to turn it on."
    dialog.buttons = ["OK"]
    ' House rule: a D-pad user can't click, so the primary action is focused.
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onSyncLockedClosed")
    m.top.getScene().dialog = dialog
end sub

sub onSyncLockedClosed()
    m.top.getScene().dialog.close = true
    m.top.setFocus(true)
end sub

' ---- Account info -----------------------------------------------------------

sub loadAccountInfo()
    p = ActiveProvider()
    if p = invalid then return
    if p.ptype = "m3u"
        m.accountInfo.text = ToStr(p.name) + " — M3U playlist"
        return
    end if
    m.accountInfo.text = ToStr(p.name) + " — checking account..."
    m.task = CreateObject("roSGNode", "ApiTask")
    m.task.url = XtreamApiUrl(p, "")
    m.task.observeField("result", "onAccountInfo")
    m.task.control = "RUN"
end sub

sub onAccountInfo(event as object)
    res = event.getData()
    p = ActiveProvider()
    if p = invalid or res = invalid then return
    if res.ok <> true
        m.accountInfo.text = ToStr(p.name) + " — couldn't reach the server"
        return
    end if
    ui = GetField(res.data, "user_info")
    status = ToStr(GetField(ui, "status"))
    expRaw = ToInt(GetField(ui, "exp_date"))
    expText = ""
    if expRaw > 0
        dt = CreateObject("roDateTime")
        dt.fromSeconds(expRaw)
        expText = "  ·  renews/expires " + dt.asDateString("short-month-no-weekday")
    end if
    maxConn = ToStr(GetField(ui, "max_connections"))
    connText = ""
    if maxConn <> "" then connText = "  ·  max connections " + maxConn
    m.accountInfo.text = ToStr(p.name) + " — " + status + expText + connText
end sub

' ---- Bits the tiles need ----------------------------------------------------

' Version straight from the manifest, so the line never goes stale.
function appVersion() as string
    ai = CreateObject("roAppInfo")
    return ai.getValue("major_version") + "." + ai.getValue("minor_version") + "." + ai.getValue("build_version")
end function

function agoText(secs as integer) as string
    now = CreateObject("roDateTime").asSeconds()
    d = now - secs
    if d < 45 then return "just now"
    if d < 3600
        mins = Int(d / 60)
        if mins <= 1 then return "1 min ago"
        return mins.toStr() + " min ago"
    end if
    if d < 86400
        h = Int(d / 3600)
        if h = 1 then return "1 hour ago"
        return h.toStr() + " hours ago"
    end if
    dd = Int(d / 86400)
    if dd = 1 then return "1 day ago"
    return dd.toStr() + " days ago"
end function

' ---- Input ------------------------------------------------------------------
' Three columns, three rows, no wrapping in either direction.
'
' BACK AND LEFT ARE NOT THE SAME KEY HERE ANY MORE, and that is the point of
' the split below. Left on the first column is the way out to the sidebar,
' which is what Left has always done and still does — it is a direction, not
' an exit, so it raises backToNav and focus moves to the rail with Settings
' still on screen. Back now goes one further and reaches HOME in a single
' press, which is what the owner asked for ("if I'm in Settings I should be
' able to back button all the way to home").
'
' Back does that by returning FALSE — deliberately, and it is the only key on
' this screen that does. The press bubbles to AppShell's own Back handler
' (AppShell.brs, `if key = "back"`), which switches to Home and puts focus on
' the rail. That handler is the last stop inside the shell and every branch of
' it returns true, so bubbling cannot reach the firmware and cannot close the
' app — certification 4.6 is safe. Do not "tidy" this into `return true`:
' that would eat the press and leave Back doing nothing at all on this screen,
' with no crash and no log line to show for it.

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if m.cat <> invalid then return false

    if key = "back"
        ' Nothing to tear down on the way out: the category overlay is
        ' guarded above, and the account-info task is fire-and-forget and is
        ' not stopped on the Left path either, so the two stay symmetric.
        return false
    else if key = "left"
        if (m.focusIdx mod 3) > 0
            m.focusIdx = m.focusIdx - 1
            applyFocus()
            return true
        end if
        m.top.backToNav = true
        return true
    else if key = "right"
        if (m.focusIdx mod 3) < 2 and m.focusIdx + 1 < m.cells.count()
            m.focusIdx = m.focusIdx + 1
            applyFocus()
        end if
        return true
    else if key = "up"
        if m.focusIdx - 3 >= 0
            m.focusIdx = m.focusIdx - 3
            applyFocus()
        end if
        return true
    else if key = "down"
        if m.focusIdx + 3 < m.cells.count()
            m.focusIdx = m.focusIdx + 3
            applyFocus()
        end if
        return true
    else if key = "OK"
        openTile(m.focusIdx)
        return true
    end if
    return false
end function
