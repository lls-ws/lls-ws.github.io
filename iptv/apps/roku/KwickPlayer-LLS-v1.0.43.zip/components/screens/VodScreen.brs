' VOD home — Movies | Series tabs + category strip + poster grid.
' Focus flow: mode tabs -> category strip -> grid.
'
' BACK AND LEFT ARE NOT THE SAME KEY HERE ANY MORE (2026-08-26). Left walks
' back out toward the sidebar, one area at a time, and raises backToNav when
' it runs out of screen — a direction, exactly as before. Back walks out of
' the SCREEN: it returns false so the key bubbles to AppShell.onKeyEvent,
' which moves to Home and, once there, raises the one exit confirmation
' certification 4.6 permits. Do not "tidy" those `return false` branches back
' into the Left ones; see the note at each of them.

sub init()
    m.theme = KwickTheme()

    ' ---- The shell theme's type, page-wide --------------------------------
    ' JetBrains Mono via Theme.brs's UiFont/UiBoldFont everywhere in this
    ' file. Mono's flat 0.6em advance is ~20% wider than Roboto-Medium's
    ' average, and the two places on this page where that could have bitten
    ' both MEASURE their own text rather than assuming an advance: addPill()
    ' sizes each chip from boundingRect, and buildCatStrip() packs category
    ' names until they stop fitting. So nothing here truncates — the visible
    ' effect is that a few FEWER categories fit across the strip before it
    ' scrolls, which is a scroll and not a loss. The chip row is the one that
    ' needed a change; see buildModeTabs().
    header = m.top.findNode("header")
    header.text = "VOD"
    header.font = UiBoldFont(42)
    header.color = m.theme.textPrimary

    m.emptyLabel = m.top.findNode("emptyLabel")
    m.emptyLabel.font = UiFont(26)
    m.emptyLabel.color = m.theme.textSecondary

    ' The "this page is short" line in the header band. Quieter than the
    ' header and the same weight as the empty text, because it is a note and
    ' not an error: the titles that DID load are still worth looking at.
    '
    ' TEXT COLOUR RAISED TO textPrimary (2026-10-02, log key B6DA8F). It was
    ' textSecondary - a mid grey - and at 18px on a 70in set across a living
    ' room that is not a message, it is a smudge. The size cannot go up (the
    ' 520px box holds 48 mono characters a line at 18px and the wording needs
    ' them), so the contrast does instead. It is still the smallest thing on
    ' the page, so it still reads as a note rather than an error.
    m.memNote = m.top.findNode("memNote")
    m.memNote.font = UiFont(18)
    m.memNote.color = m.theme.textPrimary
    m.memNote.text = ""
    m.memNote.visible = false

    ' The "Try again" button under an empty page. Hidden here and shown only
    ' by xtShowRetry, which is called on EVERY paint and sets it both ways -
    ' see the note on that sub.
    m.retryGroup = m.top.findNode("emptyAction")
    m.retryRing = m.top.findNode("retryRing")
    m.retryPill = m.top.findNode("retryPill")
    m.retryLabel = m.top.findNode("retryLabel")
    ' 27 bold is exactly what the Movies | Series pills are set in, because
    ' this is the same kind of control and has to read as one.
    m.retryLabel.font = UiBoldFont(27)
    m.retryGroup.visible = false
    redrawRetry()

    m.spinner = m.top.findNode("spinner")
    m.spinner.poster.uri = "pkg:/images/spinner.png"

    m.grid = m.top.findNode("grid")
    m.grid.observeField("itemSelected", "onItemSelected")

    m.rowsView = m.top.findNode("rowsView")
    m.rowsView.observeField("rowItemSelected", "onRowItemSelected")
    m.rowsView.rowLabelFont = UiBoldFont(26)
    m.rowsView.rowLabelColor = m.theme.textPrimary

    m.keySink = m.top.findNode("keySink")
    m.top.observeField("focusedChild", "onScreenFocus")

    ' Every Xtream-type source contributes to one merged catalog (Android
    ' model; M3U playlists carry no VOD). A source chip row filters to one
    ' source, like Android's VOD source chips; "All" is the default.
    ' XTREAM SOURCES ONLY, and it has to be spelled that way rather than
    ' "not M3U". This list feeds loadCategories/loadItems, which build
    ' player_api.php addresses — so a Jellyfin or an Emby landing here does not
    ' merely show nothing: it sends get_vod_categories to a media server, which
    ' answers 404, on a 90-second deadline, once per source. That is what froze
    ' this screen the first time a media server was added (Mason, 2026-09-12).
    ' Media servers reach the grid through their own path below, never this one.
    m.vodSources = []
    for each p in LoadProviders()
        if ToStr(p.ptype) <> "m3u" and not MsIsMediaServer(p)
            m.vodSources.push({ prov: p, provId: ToStr(p.id), token: SrcTokenFor(p), label: ToStr(p.name) })
        end if
    end for
    ' ---- The member's own Jellyfin / Emby servers ---------------------------
    '
    ' Kept in their OWN list, never folded into m.vodSources, and that
    ' separation is the whole safety rule of this screen: every address
    ' m.vodSources builds is a player_api.php one, and a media server sent a
    ' player_api.php request does not fail politely — it sits on a 90-second
    ' deadline and freezes the page (Mason, 2026-09-12). Media servers get
    ' their own fetch functions further down, all prefixed ms*, and nothing
    ' in this list ever reaches them.
    '
    ' A server that has not been signed in to yet is left out completely
    ' rather than shown as a chip with nothing behind it: without a token
    ' there is not one thing we can ask it for. AppScene starts the sign-in
    ' at launch, so it puts itself on the row on the next visit to this page.
    m.mediaSources = MediaServerProviders()
    m.msSources = []
    for each p in m.mediaSources
        if not MsNeedsSignIn(p)
            nm = ToStr(p.name)
            if nm = "" then nm = MsBrandLabel(p)
            m.msSources.push({ prov: p, provId: ToStr(p.id), token: SrcTokenFor(p), label: nm })
        end if
    end for
    ' ONE chip row across both kinds of source. To the member "my Jellyfin"
    ' is simply another place their films come from, and it filters exactly
    ' the way another IPTV login does — so the count that decides whether
    ' there is anything to filter has to include them.
    m.multi = (m.vodSources.count() + m.msSources.count() > 1)
    ' Source filter: "" = All, else a provider id. Remembered per profile.
    m.srcFilter = RegRead("pref_vod_source" + ProfileScopeSuffix())
    if m.srcFilter <> "" and anySourceById(m.srcFilter) = invalid then m.srcFilter = ""

    m.mode = "movies"           ' "movies" | "series"
    m.catsByKey = {}            ' mode|filter -> merged cats incl. Home + All
    m.catAggByMode = {}         ' mode -> {provId: [{catId, name}]}
    m.catFetch = invalid        ' in-progress per-source category fan-out
    m.contentByKey = {}         ' mode|filter|catId -> prebuilt ContentNode
    m.inflight = {}
    ' ---- The catalogue load, one source at a time (2026-09-15) -------------
    ' What is still to be asked for on each view, and whether the box ran out
    ' of room part way through. See loadItems / xtStartNext for the whole
    ' story; the short version is that all the sources used to be pulled into
    ' one answer at one moment and that moment is what killed the app.
    m.xtQueue = {}              ' content key -> { sources: [...], ... } still to run
    m.xtCapped = {}             ' content key -> this box ran short mid-load
    ' ---- WHAT THE PROVIDER ITSELF SENT, per view (2026-10-15) --------------
    ' Added for the fault the Windows lane hit (W-214) and Mason hit on his
    ' own account: a panel that answers the film list with a valid but EMPTY
    ' list, where every other day it holds about 44,000 films.
    '
    ' Three counts per view, summed across its sources as each one answers:
    ' how many were asked, how many answered at all, and how many films were
    ' in those answers BEFORE this page dropped, bucketed or capped a single
    ' one. VodContentTask reports them; xtProviderSentNothing is the only
    ' thing that reads them. Without this the screen cannot tell a provider
    ' that sent nothing from a member who has hidden all their categories,
    ' and it has been telling the second one the first one's story.
    m.xtTally = {}              ' content key -> { asked, answered, raw, whole }
    ' Made ONCE and on the render thread on purpose. The same object read
    ' from inside a Task reports the task's own thread and is wrong by a wide
    ' margin - SportsTask.brs:562 says so in as many words - and this screen
    ' is the render thread, so the number it reads here is the honest one.
    m.memMon = CreateObject("roAppMemoryMonitor")
    m.catIdx = 0                ' 0 = Home landing
    m.catFocus = 0
    m.catScroll = 0             ' first visible strip entry
    ' Year browsing (Android's Year tab). "Year" is an entry in the SAME
    ' category strip, and picking it unfolds the years inline after it —
    ' one control, one row, and nothing added to the mode/source chip row,
    ' which is already one chip away from running off the right edge.
    m.stripCats = []            ' what the strip actually shows (cats [+ years])
    m.yearOpen = false          ' years unfolded into the strip?
    m.yearPick = ""             ' the year showing, "" = newest
    m.yearBackId = ""           ' category to return to when Year folds up
    ' "retry" is the Try again button on an empty page, and it only exists
    ' while that button is on screen. xtShowRetry puts focus back on the
    ' category strip whenever the button goes away, because the button is a
    ' drawn pill and nothing in the firmware would move the highlight off it.
    m.focusArea = "modes"       ' "modes" | "cats" | "content" | "retry"
    m.modeFocus = 0
    m.detail = invalid
    m.pinDialog = invalid
    m.pendingSelectId = invalid
    m.failedSrc = {}            ' source name -> couldn't be reached
    m.deadSrc = {}              ' provider id -> don't ask it for items either

    ' ---- Media-server state, all of it kept apart from the Xtream state ----
    m.msViews = {}              ' provider id -> its video libraries, once
    m.msGenres = {}             ' provider id -> its FILM genres, once
    m.msWideByKey = {}          ' mode|filter -> the libraries All and Year sweep
    m.msPending = 0             ' media requests still out (queued or on the wire)
    m.msTaskInfo = {}           ' task tag -> what that request was for
    m.msSeq = 0                 ' tag counter, so a tag is never ambiguous
    m.msQueue = []              ' item requests waiting for a free slot
    m.msActive = 0              ' item requests actually on the wire right now
    m.msHeld = {}               ' content key -> rows that beat their grid here
    m.restoreCatId = ""         ' strip entry to land back on after a re-merge

    refreshResumeVodIndex(m.mode = "series")
    buildModeTabs()
    loadCategories()
end sub

' ---- Resume progress index ---------------------------------------------------
'
' How far the profile is into every film and show it has a position for:
' "<src>:<kind>:<id>" -> 1..99, parked on m.global so a recycling poster
' costs one associative-array hit and nothing else. The keys come from
' FavVodKeyFor, which is the SAME string VodContentTask already stamped on
' each node as favKey for the heart — so the poster needs no new field and
' the grid content, which is built off-thread by a task, is untouched.
'
' WHY A MAP AND NOT A FIELD PER TILE. The All grid is a whole catalog:
' walking every node on the render thread to stamp a percentage on it is
' thousands of writes between the member's press and the screen moving, and
' certification 3.5 gives us 250ms. One map read per bind costs nothing.
'
' WHY IT IS BUILT IN ONE PASS. Both per-tile alternatives are already banned
' here: LoadResume() per poster is a registry read per poster per scroll —
' "a visible stutter on a stick" (Store.brs, RefreshFavVodIndex, which
' builds exactly this shape of map for exactly this reason) — and asking a
' provider where you are in something, per tile, is the loop that got this
' house's address banned on 2026-08-14. Nothing below touches the network.
'
' THIS IS A DELIBERATE COPY of the same function in HomeScreen.brs. It wants
' to live in Store.brs next to RefreshFavVodIndex(); that file was being
' rewritten by another lane while this landed and could not be touched.
' Move it there and delete both copies.
sub refreshResumeVodIndex(withSeries = true as boolean)
    if m.global = invalid then return
    if not m.global.hasField("resumeVodIndex") then m.global.addFields({ resumeVodIndex: {} })
    idx = {}
    profileId = ActiveProfileId()
    prefix = ""
    if profileId <> "default" and profileId <> "" then prefix = profileId + "|"

    ' FILMS. A film's position IS the resume section, so read the section
    ' once rather than asking it per title. (SaveResume throws a film's
    ' point away past 95%, so anything still in here is genuinely partway.)
    sec = CreateObject("roRegistrySection", "kwick_resume")
    for each k in sec.getKeyList()
        ks = ToStr(k)
        ' Same profile test MediaBarEpisodeIndex uses: the default profile's
        ' keys carry no prefix at all, so "has no pipe" is what marks them.
        mine = false
        if prefix = ""
            mine = (Instr(1, ks, "|") = 0)
        else
            mine = (Len(ks) >= Len(prefix) and ks.left(Len(prefix)) = prefix)
        end if
        if mine
            bare = Mid(ks, Len(prefix) + 1)
            if bare.left(6) = "movie:"
                parts = sec.read(ks).split("|")
                if parts.count() >= 2
                    pct = MediaBarPercent(ToInt(parts[0]), ToInt(parts[1]))
                    if pct > 0
                        q = SplitSrcQualifiedId(Mid(bare, 7))
                        idx[FavVodKeyFor("movie", q.id, q.src)] = pct
                    end if
                end if
            end if
        end if
    end for

    ' SHOWS. A series has no position of its own — the bar stands for the
    ' episode you are up to, and the only thing that knows which episode
    ' that is is MediaBarEpisodeIndex(): the player's own kwick_hist rows
    ' plus the rows KwickSync pulled from the phone. It reads nothing off
    ' the network either, but it does parse JSON per row, so the Movies tab
    ' skips it outright — nothing on screen there can be a show.
    if withSeries
        eps = MediaBarEpisodeIndex()
        for each ref in eps
            row = eps[ref]
            pct = MediaBarPercent(ToInt(row.pos), ToInt(row.dur))
            if pct > 0
                q = SplitSrcQualifiedId(ToStr(ref))
                idx[FavVodKeyFor("series", q.id, q.src)] = pct
            end if
        end for
    end if

    m.global.resumeVodIndex = idx
end sub

function providerInSources(provId as string) as dynamic
    for each s in m.vodSources
        if s.provId = provId then return s
    end for
    return invalid
end function

' The same lookup over the media-server list. Deliberately a second function
' rather than a flag on the first: every caller of providerInSources goes on
' to build an Xtream address, and one that quietly started returning a
' Jellyfin is the freeze this screen already had once.
function msSourceById(provId as string) as dynamic
    for each s in m.msSources
        if s.provId = provId then return s
    end for
    return invalid
end function

' Is this provider id a source this screen shows at all? Only the remembered
' chip needs to ask, and it does not care which kind it is.
function anySourceById(provId as string) as dynamic
    one = providerInSources(provId)
    if one <> invalid then return one
    return msSourceById(provId)
end function

' The XTREAM sources the current chip shows: all of them, or just the picked
' one.
'
' EMPTY when the chip names a media server, and that is load-bearing. The old
' fall-through returned every Xtream source for any id it did not recognise,
' which was fine while the only unrecognised ids were stale ones — with a
' media-server chip on the row it would have fired the whole Xtream catalogue
' at every other source the moment the member filtered to their Jellyfin.
function currentSources() as object
    if m.srcFilter = "" then return m.vodSources
    one = providerInSources(m.srcFilter)
    if one <> invalid then return [one]
    if msSourceById(m.srcFilter) <> invalid then return []
    return m.vodSources
end function

' The media servers the current chip shows — the mirror of currentSources(),
' and empty whenever the chip names an Xtream source.
function currentMediaSources() as object
    if m.srcFilter = "" then return m.msSources
    one = msSourceById(m.srcFilter)
    if one <> invalid then return [one]
    return []
end function

function catsKey() as string
    return m.mode + "|" + m.srcFilter
end function

' ---- Focus routing -----------------------------------------------------------

' The content pane is the rows view on Home, the poster grid otherwise.
function contentPane() as object
    if m.rowsView.visible then return m.rowsView
    return m.grid
end function

' Focus handed to the screen as a whole (from the sidebar) goes to the
' right holder: the content pane when browsing, the key sink otherwise.
' ---- Guarded handlers (v1.0.41) ---------------------------------------------
'
' Every entry point the render thread can call on this screen now runs under
' try/catch and reports through GuardFailed (Util.brs), the same way the TV
' Guide and the channel page already do: one log line naming the file, the
' line and the function, plus an armed next-launch crash report, instead of
' the app dying with no stack at all.
'
' WHY THIS SCREEN, IN PLAIN WORDS. Log key AFE7F5, an HKPRO 43-inch set on
' v1.0.40: the app stopped dead and the last thing in the member's log was the
' shell's own "opened VodScreen" line. So the member pressed Movies & Series,
' the page opened, and somewhere in the seconds while it was filling itself in
' the app died. Nothing in this file was guarded, so the report could not name
' a function or a line. It can now - and everything that fills this page in
' arrives through one of the handlers below, so whatever it was will be named.
'
' GuardFailed IS REACHABLE HERE because VodScreen.xml names
' pkg:/source/utils/Util.brs (VodScreen.xml:11). A component only sees the
' scripts its own XML names, and that line is what makes these calls legal.
'
' init() IS DELIBERATELY NOT GUARDED - a fault there leaves a screen with half
' its fields missing, and guarding it would turn one honest crash into every
' handler below faulting for the rest of the session.
'
' WHAT A GUARD HERE DOES NOT FIX, and it is worth being plain about it: a
' fault inside onCategories or onContentDone still leaves the page half built
' - a spinner that never stops, or a strip with nothing in it. The guard does
' not repair that and is not pretending to. What it buys is that the member
' keeps the rest of the app and can press Back, and that the next log says
' which line to go and look at.
sub onScreenFocus()
    try
        onScreenFocusInner()
    catch e
        GuardFailed("vod/onScreenFocus", e)
        ' LOGGED AND NOTHING ELSE, on purpose. This is the focusedChild
        ' observer, so moving focus from in here fires it again - a handler
        ' that faults every time would then recurse until the stack gave out,
        ' which is a worse crash than the one being guarded. Leaving it alone
        ' is safe: focus stays on this screen's own node, so onKeyEvent still
        ' fires and Back and Left still get the member out.
    end try
end sub

sub onScreenFocusInner()
    if not m.top.hasFocus() then return
    if m.focusArea = "content"
        contentPane().setFocus(true)
    else
        m.keySink.setFocus(true)
    end if
end sub

' ---- Mode tabs (Movies | Series) — centered pill buttons, mobile style --------

' Movies | Series pills, plus — with several sources — the source chips
' (All | <source> | <source>) on the right, Android's VOD source filter.
' The dot colour for one source chip: the member's synced choice if there is
' one, this app's own hash otherwise. Mirrors PosterCard/ChannelCard so a
' source looks the same on its chip as it does on every tile.
function chipDotColor(token as dynamic) as string
    tok = ToStr(token)
    if m.global <> invalid and m.global.hasField("srcColorIdx")
        idx = m.global.srcColorIdx
        if idx <> invalid
            k = "t" + tok
            if idx.doesExist(k) then return idx[k].mark
        end if
    end if
    return SrcColorsFor(tok).mark
end function

' Where a row of pills starts so that the row is CENTRED. Both rows call this
' and nothing else computes a start position, which is the point: the tabs and
' the chips cannot end up centred a few pixels apart.
'
' 1810 rather than 1920 because AppShell puts every screen at x=110 to clear the
' sidebar rail (AppShell.xml), so the middle of what the member sees is the
' middle of the 1810 content area. This is the same box the Movies | Series
' pills were already centred in.
'
' The floor is the page's own left margin: a row too wide to centre starts at 60
' and runs right, which is what it did before, rather than starting off-screen.
function modeRowStart(rowW as integer) as integer
    x = Int((1810 - rowW) / 2)
    if x < 60 then x = 60
    return x
end function

' The width a pill needs for its own text. THE ONE COPY: it is used both to
' measure a row before it can be centred and to build each pill in it, and a
' second copy of this arithmetic is how a row gets measured at one width and
' drawn at another.
'
' 44 is the horizontal padding, 26 the room a colour dot reserves, and 72 the
' floor - pill.9.png holds 62px of fixed corner on each axis, so anything drawn
' narrower than 63 would squash the very caps that file exists to protect.
function pillWidthFor(text as string, fsize as integer, dotColor as string) as integer
    probe = CreateObject("roSGNode", "Label")
    probe.font = UiBoldFont(fsize)
    probe.text = text
    dotPad = 0
    if dotColor <> "" then dotPad = 26
    w = Int(probe.boundingRect().width) + 44 + dotPad
    if w < 72 then w = 72
    return w
end function

' A source chip's label, cut to fit. Held here rather than inside the build loop
' because the row is MEASURED before it is placed and both passes have to agree
' on the words, character for character.
'
' 12 characters is the mono tax on the one row of this page that could run off
' the edge. Roboto-Medium measured 0.483-0.549 em on real text, so 14 characters
' at 22 ran 149-169px; JetBrains Mono is a flat 0.600 em, so 12 characters at 22
' is 158px - inside that range, and the row therefore ends no further right than
' it did. Going the other way (keeping 14 and dropping the point size) was the
' alternative and was not taken: 20px of mono is small for a label somebody has
' to read from a sofa.
function chipLabelFor(label as dynamic) as string
    s = ToStr(label)
    if Len(s) > 12 then return Left(s, 11) + "…"
    return s
end function

sub buildModeTabs()
    tabs = m.top.findNode("modeTabs")
    while tabs.getChildCount() > 0
        tabs.removeChildIndex(0)
    end while
    chips = m.top.findNode("srcChips")
    while chips.getChildCount() > 0
        chips.removeChildIndex(0)
    end while
    m.modeNodes = []
    m.chipDefs = []

    ' ---- Row 1: Movies | Series, centred ------------------------------------
    ' Always centred now, where this used to jump to x=60 the moment a second
    ' source existed so the chips had somewhere to go. The chips have their own
    ' row underneath since 2026-08-27, so the tabs never have to make way.
    pillW = 240
    pillH = 64
    gap = 24
    x = modeRowStart(pillW * 2 + gap)
    for each name in ["Movies", "Series"]
        x = addPill(tabs, name, x, pillW, pillH, 27)
        x = x + gap
    end for
    if m.multi
        ' Each source chip carries a coloured DOT — the same colour that
        ' source's corner tag gets on every poster and channel card (see
        ' SrcPalette in Theme.brs). The chip is its own legend: the dot sits
        ' right beside the source's name, so the member learns the pairing
        ' once here and can then read the cards by colour alone.
        '
        ' A dot rather than a tinted chip fill, because the fill is already
        ' spoken for: the selected chip is filled with the app accent and
        ' the rest sit on flat surface grey, and that is the one thing on
        ' this row that must never get ambiguous. Colouring the fills would
        ' put selection and source in a shouting match, and "All" has no
        ' source colour to give anyway. The dot leaves selection untouched
        ' and still carries at ten feet.
        m.chipDefs.push({ filter: "", label: "All", dot: "" })
        for each s in m.vodSources
            ' Same precedence the card tags use (PosterCard.srcDotColor): the
            ' member's own colour, painted on the phone and carried over
            ' KwickSync, wins over this app's local hash. Read from the
            ' session map rather than storage - it is rebuilt once per sync
            ' cycle, and the chip row is drawn far too often to pay for a
            ' registry read here.
            m.chipDefs.push({ filter: s.provId, label: s.label, dot: chipDotColor(s.token) })
        end for
        ' The member's own servers sit on the same row, after the IPTV ones,
        ' and get their dot from the SAME call — a media server's source token
        ' ("jf:<id>" / "emby:<id>") goes through SrcColorsFor and the synced
        ' colour map exactly like an Xtream one, so the dot on the chip is
        ' already the dot on its posters with nothing added here.
        for each s in m.msSources
            m.chipDefs.push({ filter: s.provId, label: s.label, dot: chipDotColor(s.token) })
        end for
        ' ---- Row 2: the source chips, centred by the same arithmetic --------
        ' MEASURED FIRST, THEN PLACED, because centring needs the row's total
        ' before the first chip can be given an x. Two passes over a handful of
        ' chips, and exactly the shape hbLayout and hcDrawChips use on the
        ' detail pages for the same reason.
        chipGap = 16
        labels = []
        widths = []
        total = 0
        for each cd in m.chipDefs
            lbl = chipLabelFor(cd.label)
            labels.push(lbl)
            w = pillWidthFor(lbl, 22, ToStr(cd.dot))
            widths.push(w)
            total = total + w
        end for
        total = total + chipGap * (m.chipDefs.count() - 1)
        cx = modeRowStart(total)
        for i = 0 to m.chipDefs.count() - 1
            ' 64 TALL, where these were 52 (2026-08-26). Two reasons and the
            ' first one is a bug fix. images/pill.9.png has a fixed height of
            ' 62px of corner, so anything shorter than 63 would squash the
            ' caps it exists to protect — see PILL_RADIUS in
            ' tools/make_card_art.py. The second is that 64 is what the
            ' Movies|Series tabs above them are, so both rows are one height.
            '
            ' The width is passed IN now rather than left as 0 for addPill to
            ' work out, because the row was already measured a few lines above
            ' and measuring it twice is how the two answers drift.
            addPill(chips, labels[i], cx, widths[i], 64, 22, ToStr(m.chipDefs[i].dot))
            cx = cx + widths[i] + chipGap
        end for
    end if
    ' A source list that changed under a remembered index would put the ring on
    ' a pill that is not there. Cheap, and this is the only place the count can
    ' change.
    if m.modeFocus >= m.modeNodes.count() then m.modeFocus = 0
    if m.modeFocus < 0 then m.modeFocus = 0
    redrawModeTabs()
end sub

' One pill (ring + fill + label) appended to m.modeNodes; returns its right edge.
'
' `grp` is whichever ROW the pill belongs to - modeTabs for Movies | Series,
' srcChips for a source chip. m.modeNodes stays ONE flat list across both rows,
' tabs first and chips after, because redrawModeTabs and selectMode both index
' into it by "0 and 1 are the tabs, 2 onward are chips" and moving the chips to
' their own group must not renumber anything.
' dotColor, when given, adds a source-colour dot inside the pill's left end
' and reserves room for it, so the label still centres in what's left.
'
' >>> WHY THE ART IS A NINE-PATCH NOW, and what it fixes (2026-08-26).
' The owner reported the "All" chip looking as if "the top and bottom of the
' pill are sliced off". images/pill.png was a plain 240 x 64 bitmap of a
' stadium and a plain bitmap is SCALED, non-uniformly, to whatever box it is
' given. The Movies|Series tabs are drawn at exactly 240 x 64 so they were
' always right; a source chip is sized to its own text, and "All" is the
' narrowest pill on the row by a distance — three characters, and the only
' chip with no colour dot to reserve room for. At about 84px wide its 32px
' caps were squeezed to 11px across while staying 26px tall, which leaves
' three quarters of the top and bottom edges as a dead flat line.
'
' It was NOT the switch to JetBrains Mono. Mono is wider than Roboto at the
' same size, so the font change made every chip a little wider and the
' distortion very slightly BETTER, not worse.
'
' images/pill.9.png (tools/make_card_art.py) never scales its caps, so the
' shape is now correct at every width. It also costs less: 68 x 68 x 4 =
' 18,496 bytes of texture against the old bitmap's 61,440, both shared by
' every pill on the row. <<<
function addPill(grp as object, text as string, x as integer, w as integer, h as integer, fsize as integer, dotColor = "" as string) as integer
    lbl = CreateObject("roSGNode", "Label")
    lbl.text = text
    lbl.font = UiBoldFont(fsize)
    dotPad = 0
    if dotColor <> "" then dotPad = 26
    pw = w
    ' The measurement and the floor are pillWidthFor's now, so a row that was
    ' measured before it could be centred and the pills that row is built from
    ' cannot disagree about a single pixel. Width 0 still means "fit the text",
    ' for any caller that has nothing to centre.
    if pw = 0 then pw = pillWidthFor(text, fsize, dotColor)
    if pw < 72 then pw = 72
    y = Int((64 - h) / 2)
    ring = grp.createChild("Poster")
    ring.uri = "pkg:/images/pill.9.png"
    ring.width = pw + 12
    ring.height = h + 12
    ring.translation = [x - 6, y - 6]
    pill = grp.createChild("Poster")
    pill.uri = "pkg:/images/pill.9.png"
    pill.width = pw
    pill.height = h
    pill.translation = [x, y]
    if dotColor <> ""
        ' The dot rides on its own dark disc, the same trick the poster
        ' favourite heart uses. It isn't decoration: the SELECTED chip is
        ' filled with the app accent, and KwickTV's source colour IS the app
        ' accent, so without the disc that one dot would vanish the moment
        ' its own chip was picked and read as a rendering fault. The disc
        ' also stops the mid-tone dots washing out on the accent fill.
        ' Both reuse images/circle.png — no new art, nothing added to the
        ' 4 MB certification budget.
        disc = grp.createChild("Poster")
        disc.uri = "pkg:/images/circle.png"
        disc.width = 24
        disc.height = 24
        disc.translation = [x + 12, y + Int((h - 24) / 2)]
        disc.blendColor = "0x000000B8"
        dot = grp.createChild("Poster")
        dot.uri = "pkg:/images/circle.png"
        dot.width = 14
        dot.height = 14
        dot.translation = [x + 17, y + Int((h - 14) / 2)]
        dot.blendColor = dotColor
    end if
    lbl.width = pw - dotPad
    lbl.height = h
    lbl.horizAlign = "center"
    lbl.vertAlign = "center"
    lbl.translation = [x + dotPad, y]
    grp.appendChild(lbl)
    m.modeNodes.push({ ring: ring, pill: pill, lbl: lbl })
    return x + pw
end function

sub redrawModeTabs()
    activeIdx = 0
    if m.mode = "series" then activeIdx = 1
    for i = 0 to m.modeNodes.count() - 1
        t = m.modeNodes[i]
        t.ring.blendColor = m.theme.focusHighlight
        t.ring.visible = (m.focusArea = "modes" and i = m.modeFocus)
        on = false
        if i <= 1
            on = (i = activeIdx)
        else if i - 2 < m.chipDefs.count()
            ' Chips: the one matching the saved filter lights up.
            on = (ToStr(m.chipDefs[i - 2].filter) = m.srcFilter)
        end if
        if on
            t.pill.blendColor = m.theme.accent
            ' The PAGE colour, not white. This label sits on a pill filled
            ' with the theme accent, and on Nord Shell the accent is frost
            ' (0x88C0D0) — a LIGHT colour. White on it is under 2:1, which
            ' is not readable across a room; nord0 on it is about 6:1. The
            ' old accent was a mid blue where white worked, so this is
            ' fallout from the Nord port rather than a preference, and it is
            ' the SELECTED tab, i.e. the one label on this row that most has
            ' to be readable.
            t.lbl.color = m.theme.background
        else
            t.pill.blendColor = m.theme.surfaceElevated
            t.lbl.color = m.theme.textSecondary
        end if
    end for
end sub

' ---- Categories ---------------------------------------------------------------

function catAction() as string
    if m.mode = "movies" then return "get_vod_categories"
    return "get_series_categories"
end function

function itemsAction() as string
    if m.mode = "movies" then return "get_vod_streams"
    return "get_series"
end function

sub loadCategories()
    ' M3U-only box: no VOD catalog at all. The test counts BOTH lists now —
    ' a box whose only source is a Jellyfin has no Xtream sources and used to
    ' fall out here with a blank page, which is precisely the member this
    ' whole path exists for.
    if m.vodSources.count() + m.msSources.count() = 0 then return
    ' A different mode or source is a different catalog, so a different set
    ' of years: fold the Year list away rather than leave last catalog's
    ' years sitting in the strip.
    m.yearOpen = false
    m.yearPick = ""
    rebuildStripCats()
    if m.catsByKey.doesExist(catsKey())
        m.catIdx = 0
        m.catFocus = 0
        m.catScroll = 0
        buildCatStrip()
        loadItems()
        return
    end if
    ' Category ids from every shown source, merged by NAME once all answer.
    ' Already-fetched sources (mode revisits, chip changes) come from the
    ' per-mode aggregate for free.
    if not m.catAggByMode.doesExist(m.mode) then m.catAggByMode[m.mode] = {}
    agg = m.catAggByMode[m.mode]
    ' What the member's own servers have to offer, asked for ONCE per screen
    ' open and reused by every chip and both tabs: the libraries (which of
    ' them belong on Movies and which on Series is decided from the
    ' CollectionType they already sent back) and, on the Movies tab, the film
    ' genres. Two small GETs per server for a whole visit, and revisiting a
    ' tab costs nothing at all.
    '
    ' DELIBERATELY NOT COUNTED IN m.catFetch.pending. That counter gates the
    ' merge, and a media server is very often a box on the member's own
    ' network that is simply switched off — holding the whole category strip
    ' behind its 20-second timeout would make one sleeping server the reason
    ' their IPTV films will not list. It folds in when it answers instead.
    msLoadCatalog()
    m.catFetch = { mode: m.mode, pending: 0 }
    for each s in currentSources()
        if not agg.doesExist(s.provId)
            m.catFetch.pending = m.catFetch.pending + 1
            task = CreateObject("roSGNode", "ApiTask")
            task.tag = m.mode + "|" + s.provId
            task.url = XtreamApiUrl(s.prov, catAction())
            task.observeField("result", "onCategories")
            m.inflight["cats_" + s.provId + "_" + m.mode] = task
            task.control = "RUN"
        end if
    end for
    if m.catFetch.pending > 0
        setBusy(true)
    else
        mergeVodCategories(m.mode)
    end if
end sub

sub onCategories(event as object)
    try
        onCategoriesInner(event)
    catch e
        GuardFailed("vod/onCategories", e)
        ' Nothing is unwound. The real handler's bookkeeping - m.inflight, the
        ' per-source aggregate, m.catFetch.pending - is what decides when the
        ' categories merge, and a catch that guessed at it would merge a
        ' half-collected list and show the member a strip that is missing
        ' their sources. A page that stays on its spinner is wrong in a way
        ' they can see and back out of; a page that quietly drops half their
        ' categories is not.
    end try
end sub

sub onCategoriesInner(event as object)
    res = event.getData()
    tag = ToStr(event.getRoSGNode().tag)
    sep = Instr(1, tag, "|")
    if sep = 0 then return
    forMode = Left(tag, sep - 1)
    pid = Mid(tag, sep + 1)
    m.inflight.delete("cats_" + pid + "_" + forMode)
    raw = []
    cacheCats = []
    if res <> invalid and res.ok = true
        for each c in ToArray(res.data)
            cid = ToStr(GetField(c, "category_id"))
            nm = ToStr(GetField(c, "category_name"))
            raw.push({ catId: cid, name: nm })
            cacheCats.push({ id: cid, name: nm })
        end for
        ' ---- The category-name cache, and the shrink that must not land ----
        '
        ' This table is not decoration and it is not this screen's own: the
        ' PARENTAL GATE reads it. MovieDetailScreen and SeriesDetailScreen both
        ' translate a title's category id through loadCatNameCache("movies" /
        ' "series", ...) to decide whether a title is behind a lock. A provider
        ' that answers once with a collapsed list - a bad minute, a partial
        ' answer, a panel mid-migration - would overwrite the table and take the
        ' NAMES the locks match on with it. That is a child-safety path, not a
        ' cosmetic one.
        '
        ' Nia's helper, not a second test of our own: IsDestructiveChannelShrink
        ' carries Android's numbers (a floor of 50 stored, a ratio of 4) in ONE
        ' place, and two shrink rules in one app is how they drift. Opal guarded
        ' LiveTvScreen and GuideScreen the same way the same day; this was the
        ' third and last site, and the only one behind a gate.
        '
        ' REFUSED SILENTLY, with a log line and no dialog. This is a screen
        ' opening rather than a member pressing a button - there is nothing to
        ' ask them, the cache is a translation table and not their own list, and
        ' a modal on an ordinary launch after one bad provider minute is worse
        ' than the thing it would be warning about.
        '
        ' ONLY THE REGISTRY WRITE IS GUARDED, NOT THE DRAW - deliberately, and
        ' the same call Opal made. The strip below still shows the list as
        ' served, because painting a stale lineup would tell the member they can
        ' watch things that may be gone, and this cache holds {id: name} without
        ' the ordering the strip needs anyway.
        stored = CachedCategoryCount(forMode, pid)
        if IsDestructiveChannelShrink(stored, cacheCats.count())
            KLog("guide", "vod: refusing to overwrite the " + forMode + " category names for this source - " + stored.toStr() + " known, only " + cacheCats.count().toStr() + " offered. The parental gate reads this table.")
        else
            SaveCatNameCacheFor(forMode, pid, cacheCats)
        end if
    end if
    if not m.catAggByMode.doesExist(forMode) then m.catAggByMode[forMode] = {}
    m.catAggByMode[forMode][pid] = raw    ' a failed source contributes nothing
    ' "Didn't answer" and "answered, and has nothing" are different things:
    ' a provider genuinely carrying no movies must not be reported as
    ' unreachable, and must not be skipped for its item list either.
    if res = invalid or res.ok <> true
        s = providerInSources(pid)
        if s <> invalid then m.failedSrc[s.label] = true
        if not m.deadSrc.doesExist(pid) then m.deadSrc[pid] = true
    end if
    if m.catFetch = invalid or m.catFetch.mode <> forMode then return
    m.catFetch.pending = m.catFetch.pending - 1
    if m.catFetch.pending <= 0 then mergeVodCategories(forMode)
end sub

' Merge the shown sources' categories by name (Android rule), apply the
' user's name-keyed prefs, and lead with Home + All.
sub mergeVodCategories(forMode as string)
    msRefreshBusy()
    ' A media server's libraries can land for a tab whose Xtream half was
    ' never asked for (a box with no Xtream source at all, or a tab not
    ' visited yet), and this used to be reached only from a path that had
    ' just created the bucket.
    if not m.catAggByMode.doesExist(forMode) then m.catAggByMode[forMode] = {}
    agg = m.catAggByMode[forMode]
    merged = []
    byName = {}
    for each s in currentSources()
        if agg.doesExist(s.provId)
            for each c in agg[s.provId]
                nm = ToStr(c.name)
                if nm <> ""
                    if not byName.doesExist(nm)
                        entry = { id: nm, name: nm, srcCats: [], msCats: [] }
                        byName[nm] = entry
                        merged.push(entry)
                    end if
                    byName[nm].srcCats.push({ provId: s.provId, catId: ToStr(c.catId) })
                end if
            end for
        end if
    end for
    ' WHAT A MEDIA SERVER PUTS IN THE STRIP — genres on Movies, libraries on
    ' Series — is msStripEntriesFor's decision and not this loop's. Either
    ' way the names merge into the very same list, so a Jellyfin entry called
    ' "Comedy" and an IPTV category called "Comedy" are one strip entry
    ' holding both lots of films, which is the rule several Xtream sources
    ' already follow.
    '
    ' Merging here rather than keeping a separate media strip is also what
    ' buys the parental rules for free: FilterAdultCats and ApplyCatPrefs
    ' below run over this one list, so an Adult entry is dropped
    ' (certification 6.3) and one the member hid or locked behaves exactly
    ' like a hidden or locked IPTV category, with no second copy of those
    ' rules written out for media servers.
    for each s in currentMediaSources()
        for each v in msStripEntriesFor(s.provId, forMode)
            nm = ToStr(v.name)
            if nm <> ""
                if not byName.doesExist(nm)
                    entry = { id: nm, name: nm, srcCats: [], msCats: [] }
                    byName[nm] = entry
                    merged.push(entry)
                end if
                byName[nm].msCats.push({ provId: s.provId, libId: ToStr(v.libId), genre: ToStr(v.genre) })
            end if
        end for
    end for
    ' Adult categories come out first and unconditionally (certification
    ' 6.3) — see the Adult block in GuideMeta.brs.
    real = ApplyCatPrefs(forMode, FilterAdultCats(merged), false)
    ' All and Year sweep whole LIBRARIES even on the Movies tab, where the
    ' strip is genres — see msBuildWideCats. Stored beside the strip and
    ' thrown away with it, so the two can never fall out of step.
    m.msWideByKey[forMode + "|" + m.srcFilter] = msBuildWideCats(forMode, real)
    ' Home (row-per-category landing) + All + Year lead the strip, then the
    ' rest. Year sits in the strip and NOT with the Movies/Series pills for
    ' two reasons: the chip row's right edge is already nearly spent (four
    ' sources fit, five overflow), and Android puts it in the category strip
    ' too — it is a way of slicing the library, exactly like a category.
    cats = [{ id: "__home", name: "Home" }, { id: "", name: "All" }, { id: "__year", name: "Year" }]
    for each c in real
        cats.push(c)
    end for
    m.catsByKey[forMode + "|" + m.srcFilter] = cats
    if forMode = m.mode
        ' ---- A QUIET RE-MERGE, when a media server's libraries turn up late
        '
        ' The strip is rebuilt underneath the member, so it has to put them
        ' back exactly where they were: on the entry they were reading, by
        ' ID and never by index, because new entries shift every index after
        ' them. Nothing below it is touched either — the grid's content is
        ' only reloaded if what should be showing is not what is showing,
        ' since re-assigning it would throw them back to the top row.
        if m.restoreCatId <> ""
            wantId = m.restoreCatId
            m.restoreCatId = ""
            beforeKey = currentContentKey()
            rebuildStripCats()
            stripped = currentCats()
            found = 0
            for i = 0 to stripped.count() - 1
                if ToStr(stripped[i].id) = wantId
                    found = i
                    exit for
                end if
            end for
            m.catIdx = found
            if m.focusArea <> "cats" then m.catFocus = found
            ensureCatVisible()
            buildCatStrip()
            ' RELOADED ALSO WHEN THE VIEW IS THE SAME ONE BUT WAS NEVER
            ' ACTUALLY ASKED FOR. Home, All and Year are built FROM the strip,
            ' so on a box whose only source is a media server the very first
            ' Home is drawn before that server has said what it holds: there
            ' was nothing to ask for, so nothing was asked, and nothing was
            ' cached either. The strip arriving is the moment there is
            ' something to ask for, and without this the landing page sits
            ' empty for the rest of the visit. It cannot ask twice: any view
            ' that HAS been asked for has a cache entry by the same line that
            ' started the request.
            if currentContentKey() <> beforeKey
                loadItems()
            else if not m.contentByKey.doesExist(currentContentKey())
                loadItems()
            end if
            return
        end if
        rebuildStripCats()
        m.catIdx = 0
        m.catFocus = 0
        m.catScroll = 0
        ' Just unlocked a category? Jump straight to it and sit on the strip.
        justUnlocked = false
        if m.pendingSelectId <> invalid
            for i = 0 to cats.count() - 1
                if cats[i].id = m.pendingSelectId
                    m.catIdx = i
                    m.catFocus = i
                    justUnlocked = true
                    exit for
                end if
            end for
            m.pendingSelectId = invalid
        end if
        ensureCatVisible()
        buildCatStrip()
        loadItems()
        if justUnlocked
            m.focusArea = "cats"
            redrawCatStrip()
            m.keySink.setFocus(true)
        end if
    end if
end sub

' The strip's entries. Everything on this screen — m.catIdx, m.catFocus, the
' key handler — indexes into THIS list, not the stored category list, so the
' unfolded years have to be spliced in once, here, and never guessed at.
function currentCats() as object
    if m.stripCats = invalid then return []
    return m.stripCats
end function

' Rebuild the strip entries from the stored categories, unfolding the years
' after the Year entry when Year is open. Years come from the year tree the
' task built (its children are one row per year, newest first) — so they
' exist only once that has landed, and until then Year is just an entry that
' shows a spinner.
sub rebuildStripCats()
    base = []
    if m.catsByKey.doesExist(catsKey()) then base = m.catsByKey[catsKey()]
    if not m.yearOpen
        m.stripCats = base
        return
    end if
    root = invalid
    if m.contentByKey.doesExist(yearKey()) then root = m.contentByKey[yearKey()]
    out = []
    for each c in base
        out.push(c)
        if ToStr(c.id) = "__year" and root <> invalid
            for j = 0 to root.getChildCount() - 1
                y = ToStr(root.getChild(j).title)
                out.push({ id: "__y" + y, name: y, year: y, row: j })
            end for
        end if
    end for
    m.stripCats = out
end sub

' The year tree is cached per mode|source, like every other view's content —
' one entry, whatever year is showing.
function yearKey() as string
    return catsKey() + "|__year"
end function

' Every year entry's id starts "__y", and so does "__year" itself — which is
' deliberate: "the Year view" and "the Year view showing 1998" want the same
' content and the same cache entry.
function isYearId(id as string) as boolean
    return (Left(id, 3) = "__y")
end function

' The newest year in the strip, or the Year entry itself while the tree is
' still being built.
function firstYearId() as string
    for each c in currentCats()
        cid = ToStr(c.id)
        if cid <> "__year" and isYearId(cid) then return cid
    end for
    return "__year"
end function

' The row of the year tree a strip entry stands for. Nothing is copied or
' rebuilt: the row node the task already built IS the grid's content, so
' switching years is one field assignment and well inside the 250 ms
' certification 3.5 allows for a remote press.
' MATCHED BY THE YEAR ITSELF FIRST, and only then by the remembered row
' number. The row number was enough while the tree was built once by one task
' and never touched again; a media server's titles are folded in afterwards
' and can INSERT a year the IPTV catalogue did not have, which shifts every
' row below it and would leave a remembered index pointing at the year next
' door. The title is the thing that cannot drift.
function yearRowFor(root as object, cat as object) as object
    if root = invalid then return invalid
    if root.getChildCount() = 0 then return root
    want = ""
    if cat <> invalid then want = ToStr(GetField(cat, "year"))
    if want <> ""
        for j = 0 to root.getChildCount() - 1
            if ToStr(root.getChild(j).title) = want then return root.getChild(j)
        end for
    end if
    r = 0
    if cat <> invalid and cat.row <> invalid then r = ToInt(cat.row)
    if r < 0 or r >= root.getChildCount() then r = 0
    return root.getChild(r)
end function

' Select a strip entry BY ID. Folding the years in or out shifts every index
' after Year, so anything that changes the strip has to re-find its target
' by id or it lands on whatever moved into that slot.
sub selectCatById(id as string)
    cats = currentCats()
    idx = 0
    for i = 0 to cats.count() - 1
        if ToStr(cats[i].id) = id
            idx = i
            exit for
        end if
    end for
    m.catIdx = idx
    m.catFocus = idx
    ensureCatVisible()
    buildCatStrip()
    loadItems()
end sub

' Windowed category strip: packs as many names as FIT from the scroll
' position (no fixed slot count — a hard cap hid categories), scrolling as
' focus moves.
sub buildCatStrip()
    strip = m.top.findNode("catStrip")
    while strip.getChildCount() > 0
        strip.removeChildIndex(0)
    end while
    m.catNodes = []
    cats = currentCats()
    if cats.count() = 0 then return

    x = 0
    for i = m.catScroll to cats.count() - 1
        lbl = strip.createChild("Label")
        nm = cats[i].name
        if cats[i].locked = true then nm = nm + " (Locked)"
        lbl.text = nm
        lbl.font = UiFont(24)
        lbl.translation = [x, 0]
        ' Measure the real rendered width — estimating from character count
        ' made the underlines the wrong length.
        w = Int(lbl.boundingRect().width)
        if x + w > 1690
            strip.removeChild(lbl)
            exit for
        end if
        underline = strip.createChild("Rectangle")
        underline.height = 3
        underline.width = w
        underline.translation = [x, 36]
        m.catNodes.push({ lbl: lbl, underline: underline, index: i, id: ToStr(cats[i].id) })
        x = x + w + 44
    end for
    redrawCatStrip()
end sub

sub redrawCatStrip()
    for each t in m.catNodes
        if m.focusArea = "cats" and t.index = m.catFocus
            t.lbl.color = m.theme.focusHighlight
        else if t.index = m.catIdx
            t.lbl.color = m.theme.textPrimary
        else if m.yearOpen and t.id = "__year"
            ' The underline is on the YEAR that's showing, so Year itself
            ' has to say "you are inside me" some other way. Accent text —
            ' the same accent the underline uses, no new art.
            t.lbl.color = m.theme.accent
        else
            t.lbl.color = m.theme.textSecondary
        end if
        t.underline.visible = (t.index = m.catIdx)
        t.underline.color = m.theme.accent
    end for
end sub

' ---- Items --------------------------------------------------------------------

sub loadItems()
    cats = currentCats()
    m.emptyLabel.visible = false
    if cats.count() = 0 then return
    cat = cats[m.catIdx]
    isYear = isYearId(ToStr(cat.id))
    key = catsKey() + "|" + cat.id
    ' EVERY year shares one cache entry and one fetch. This is the whole
    ' point of the design: the tree is built once per mode|source and each
    ' year after that is a row already sitting in it, so browsing years
    ' never touches the network.
    if isYear then key = yearKey()
    if m.contentByKey.doesExist(key)
        if isYear
            showContent(key, yearRowFor(m.contentByKey[key], cat))
        else
            showContent(key, m.contentByKey[key])
        end if
        return
    end if
    if m.inflight.doesExist("items_" + key) then return
    ' A view whose sources are still queued has no task on the wire in the
    ' instant between one source answering and the next being asked, so the
    ' line above is not enough on its own any more.
    if m.xtQueue.doesExist(key) then return

    ' A source that just failed its category list is not going to answer a
    ' much bigger catalog request either — asking anyway spent another 90
    ' seconds per source before the screen could say anything. Only ask the
    ' ones that actually answered.
    live = []
    agg = m.catAggByMode[m.mode]
    for each s in currentSources()
        if not m.deadSrc.doesExist(s.provId) then live.push(s)
    end for
    ' Which of the member's own libraries this strip entry stands for. A
    ' media server that never answered contributes no libraries, so it
    ' contributes no targets either — a switched-off server therefore costs
    ' exactly ONE request for the whole visit, not one per view opened.
    msTargets = msTargetsFor(cat)
    if live.count() = 0 and msTargets.count() = 0
        showContent(key, CreateObject("roSGNode", "ContentNode"))
        msRefreshBusy()
        return
    end if

    ' Home, All and Year pull the WHOLE catalogue of every shown source with no
    ' category filter. On a Westinghouse 70in (key B6DA8F, v1.0.33) opening this
    ' screen alone took the app from 5% to 95% of its limit in seven seconds -
    ' the biggest single allocation in any crash log. That box lived; a smaller
    ' one would not. So on a device that is ALREADY reporting low memory, land on
    ' the first real category (one folder, one request) instead of the whole
    ' catalogue. Coarse device-wide level only - a box with room sees no change.
    if isYear or cat.id = "__home" or cat.id = ""
        lvl = LCase(ToStr(CreateObject("roDeviceInfo").GetGeneralMemoryLevel()))
        if lvl = "low" or lvl = "critical"
            for each c in cats
                cid = ToStr(c.id)
                if cid <> "__home" and cid <> "" and not isYearId(cid)
                    KLog("vod", "this device is already short of memory - opening one category instead of the whole catalogue")
                    selectCatById(cid)
                    return
                end if
            end for
        end if
    end if

    ' ---- The member's own servers, started FIRST ---------------------------
    ' Ahead of the Xtream task on purpose: the two fetches are completely
    ' independent, and whichever answers first paints. A server on the same
    ' network usually beats a panel across the internet, and there is no
    ' reason to make it queue behind one.
    viewKind = "flat"
    if cat.id = "__home"
        viewKind = "rows"
    else if isYear
        viewKind = "years"
    end if
    msStartFetch(key, viewKind, msTargets)

    if live.count() = 0
        ' A media-only view: there is no Xtream task to build the tree, so
        ' the empty tree is built and cached HERE and the libraries fold
        ' into it as they answer. Cached rather than thrown away each time,
        ' because the fold has to have somewhere to land.
        root = CreateObject("roSGNode", "ContentNode")
        m.contentByKey[key] = root
        msDrainHeld(key, viewKind)
        ' Painted BEFORE the spinner is judged: what decides whether the
        ' spinner stays up is whether there is anything in the pane, and
        ' until this line the pane still holds the last view's titles.
        showContent(key, msViewNode(key, cat))
        msRefreshBusy()
        return
    end if

    setBusy(true)

    ' ======================================================================
    ' ONE SOURCE'S CATALOGUE AT A TIME, AND ONLY AS MUCH OF IT AS THE PAGE
    ' CAN SHOW (2026-09-15)
    '
    ' WHAT HAPPENED ON THE MEMBER'S BOX. Log key 5BB222, a Hisense 6Series-50
    ' (G000X) on v1.0.36 with an Xtream provider carrying 39,357 live channels
    ' and a VOD catalogue to match. They opened the app's Home page at 16% of
    ' the memory the television allows this app, then Live TV at 16%, then
    ' Movies & Series at 16% — a perfectly healthy box on the way in, nothing
    ' leaking — and FOURTEEN SECONDS LATER the television raised its 80%
    ' memory alarm with the app sitting at 70% and killed it. It happened
    ' again the same evening from 8%. Four kills in two hours. Opening this
    ' one screen cost that member 55-70% of their television in a single go.
    '
    ' The v1.0.34 guard a few lines above cannot catch this: it only fires on
    ' a box that is ALREADY short on the way in, and this box had plenty of
    ' room right up to the moment the catalogue landed.
    '
    ' WHAT THIS DOES ABOUT IT — three things, and NOT ONE MORE REQUEST than
    ' before. Every source is still asked for exactly what it was asked for.
    '
    '   1. The sources are asked ONE AT A TIME instead of all at once. Every
    '      source's whole catalogue used to be pulled into one answer and
    '      held together before a single title reached the screen. Now each
    '      one answers, is folded into the page, and is LET GO OF before the
    '      next is asked. Search learned this exact rule in v1.0.35 and its
    '      note says why better than this one could (SearchScreen.brs,
    '      startNextFetch): "the kill comes from the raw answers landing".
    '
    '   2. Between sources this screen reads how full the app is and, if it
    '      is past the ceiling, stops. The member gets the sources that fit
    '      and a line on screen saying the page is short, instead of a dead
    '      app. See xtStartNext / xtMemoryCeiling.
    '
    '   3. What is KEPT is capped. Home rows hold fifteen titles a category
    '      and the All grid holds five hundred a source — the same two numbers
    '      the member's own Jellyfin and Emby libraries have always been held
    '      to on this page (msPageLimit). The rest is thrown away with the
    '      source that brought it, not kept for the life of the screen.
    '
    ' WHAT IS NOT FIXED HERE, honestly: the cost of ONE source's raw answer
    ' being parsed inside VodContentTask is unchanged, because that is that
    ' file's business and not this one's. On a member with a single enormous
    ' provider — which is exactly member 5BB222 — that single parse may still
    ' be most of the spike. This change bounds everything after it.
    ' ======================================================================

    ' The job description every one of this view's per-source fetches shares.
    ' A plain map rather than a task node, because there is no longer ONE
    ' task: there is one per source, made and thrown away in turn.
    plan = { sources: [], viewKind: viewKind, whole: false, kind: "movie", mode: "grid", catsJson: "", dropCatsJson: "[]", timeoutMs: 90000, showTags: (m.multi and m.srcFilter = "") }
    if m.mode = "series" then plan.kind = "series"
    srcs = []
    if isYear or cat.id = "__home" or cat.id = ""
        ' Home rows / All / Year: the full catalog of every shown source, and
        ' therefore the only three views the memory ceiling applies to.
        plan.whole = true
        for each s in live
            srcs.push({ url: XtreamApiUrl(s.prov, itemsAction()), src: s.token, label: ShortSrcLabel(s.label), cats: srcCatMap(s.provId) })
        end for
        ' These views ask for the whole catalog with no category filter, so
        ' the categories the strip dropped have to be named again here or
        ' their titles walk straight back in (certification 6.3). Year needs
        ' this most of all: years cut clean across categories.
        plan.dropCatsJson = FormatJson(adultCatNames())
        if cat.id = "__home"
            plan.mode = "rows"
            ' Real categories only — skip Home, All, Year and any unfolded
            ' year, by id rather than by index, so adding another leading
            ' entry can never silently put "Year" in the row list again.
            names = []
            for each c in cats
                cid = ToStr(c.id)
                if cid <> "__home" and cid <> "" and not isYearId(cid)
                    names.push({ name: c.name })
                end if
            end for
            plan.catsJson = FormatJson(names)
        else if isYear
            plan.mode = "years"
        end if
    else
        ' One merged folder: only the sources that carry this category name,
        ' each fetching by its own category id.
        for each sc in ToArray(cat.srcCats)
            s = providerInSources(ToStr(sc.provId))
            if s <> invalid
                srcs.push({ url: XtreamApiUrl(s.prov, itemsAction()) + "&category_id=" + UrlEncode(ToStr(sc.catId)), src: s.token, label: ShortSrcLabel(s.label) })
            end if
        end for
        plan.timeoutMs = 30000
    end if
    plan.sources = srcs
    m.xtQueue[key] = plan
    m.xtCapped.delete(key)
    ' A fresh count for a fresh load, so a Try again starts from zero rather
    ' than adding this answer to the empty one it is replacing. `whole` is
    ' carried because the "your provider sent nothing" message only applies to
    ' the three views that ask for the WHOLE catalogue - one category coming
    ' back empty is an empty category and the provider is answering fine.
    m.xtTally[key] = { asked: 0, answered: 0, raw: 0, whole: (plan.whole = true) }

    ' THE TREE EXISTS FROM THIS MOMENT, EMPTY, and every source folds into it
    ' as it answers. It used to be created by the task and handed over whole
    ' at the end, which is no longer possible when there are several answers
    ' — and it has a second benefit: a media server that beats the panel now
    ' has somewhere to put its titles instead of being parked to one side.
    m.contentByKey[key] = CreateObject("roSGNode", "ContentNode")
    msDrainHeld(key, viewKind)
    ' Bound to the pane NOW, empty, so that everything folded in afterwards
    ' simply appears in place. Painted before the spinner is judged, for the
    ' reason the media-only branch above gives: what decides whether the
    ' spinner stays up is whether there is anything in the pane.
    showContent(key, msViewNode(key, cat))
    xtStartNext(key)
end sub

' ---- The per-source catalogue queue -------------------------------------------

' Ask the next source on this view's list, or finish the view if there is
' nothing left to ask or no room left to hold it.
sub xtStartNext(key as string)
    plan = m.xtQueue[key]
    if plan = invalid then return
    ' One catalogue on the wire at a time. This is the whole point: two
    ' answers in the air is two raw catalogues in memory at once.
    if m.inflight.doesExist("items_" + key) then return
    if plan.sources.count() = 0
        xtFinished(key)
        return
    end if
    ' THE CHECK THAT GOES BETWEEN SOURCES. Only on the three views that pull
    ' a whole catalogue — a single category is one folder and is not what
    ' fills a television up.
    if plan.whole and xtMemoryCeiling()
        m.xtCapped[key] = true
        KLog("vod", "memory ceiling reached between catalogues - " + plan.sources.count().toStr() + " source(s) not loaded, results will be partial")
        plan.sources = []
        xtFinished(key)
        return
    end if
    src = plan.sources.shift()
    ' Remembered so the "holds N titles, showing the first 500" line can name
    ' the source the member recognises rather than a number. Safe to keep one
    ' of: there is only ever one of these on the wire at a time per view.
    plan.lastLabel = ToStr(src.label)
    task = CreateObject("roSGNode", "VodContentTask")
    task.tag = key
    task.kind = ToStr(plan.kind)
    task.mode = ToStr(plan.mode)
    task.showTags = (plan.showTags = true)
    task.catsJson = ToStr(plan.catsJson)
    task.dropCatsJson = ToStr(plan.dropCatsJson)
    task.timeoutMs = ToInt(plan.timeoutMs)
    ' ONE source, where this used to be the whole list.
    task.sourcesJson = FormatJson([src])
    task.observeField("done", "onContentDone")
    m.inflight["items_" + key] = task
    task.control = "RUN"
end sub

' Is this app close enough to its memory limit that holding another whole
' catalogue risks the television killing it?
'
' A STRAIGHT COPY OF SearchScreen.atMemoryCeiling, on purpose and with its
' reasoning intact: 70% of this app's own limit leaves headroom for what
' comes after the catalogue (the posters, the detail page the member opens
' next), and the coarse device-wide level is checked FIRST because a 512MB
' box was once killed at only ~55% of its own limit while the television was
' already reporting "low". Two numbers, both of which work the same on a 2017
' Roku TV and a Streaming Stick 4K, where any fixed count of titles would be
' wrong on one or the other.
'
' READ HERE AND NOWHERE ELSE, because here is the render thread. The same
' reading taken inside a Task reports that task's thread and is wrong
' (SportsTask.brs:562). m.global.appMemPct is the last number some other part
' of the app published from the render thread, so it is taken as a FLOOR: if
' something else already saw the app fuller than we do, believe it.
function xtMemoryCeiling() as boolean
    lvl = LCase(ToStr(CreateObject("roDeviceInfo").GetGeneralMemoryLevel()))
    if lvl = "low" or lvl = "critical" then return true
    if m.memMon = invalid then return false
    used = m.memMon.GetMemoryLimitPercent()
    if used = invalid then return false
    pct = ToInt(used)
    if m.global <> invalid
        if m.global.hasField("appMemPct")
            other = ToInt(m.global.appMemPct)
            if other > pct then pct = other
        end if
    end if
    return pct >= 70
end function

' HAS THE APP'S OWN MEMORY ALARM GONE OFF?
'
' The SAME flag the catalogue build reads on its own thread
' (VodContentTask.vodMemPressure): raised in main.brs the moment either the
' television or the app says it is short of memory, and cleared in one place
' only - Store.PublishM3uParse, when a playlist is parsed again and the
' render thread's honest reading is back under 70%. A member whose sources
' are all Xtream panels never re-parses a playlist, so for them the flag does
' not come down at all once it has gone up.
'
' WHY THIS IS READ HERE. The build task reports done = { ok: true } whether it
' built the whole catalogue or gave up before the first title, so "ok" cannot
' tell an empty category apart from a page the television refused to fill.
' This flag can, because it is the exact thing the task stopped on - it is
' tested before the first title and every hundred titles after that.
'
' WHAT HAPPENED ON THE MEMBER'S TELEVISION (log key B6DA8F, a Westinghouse
' 70in, 1 October 2026). In plain words: the television told the app it was
' running out of room, the app did the right thing and stopped loading their
' films part way, and then said absolutely nothing about it - the page simply
' sat there empty under a full list of categories. They went straight to
' Settings and deleted their source.
function xtMemAlarmUp() as boolean
    if m.global = invalid or not m.global.hasField("memPressure") then return false
    return (m.global.memPressure = true)
end function

' Every source this view was going to ask has been asked (or has been
' abandoned because there was no room). This is where the single task's
' completion handler used to end.
sub xtFinished(key as string)
    m.xtQueue.delete(key)
    msRefreshBusy()
    xtShowMemNote(key)
    ' The year tree finishing is the moment the strip learns which years the
    ' library actually has: unfold them and land on the newest one (or the
    ' year the member was last on, if they went away and came back).
    if key = yearKey()
        if not m.yearOpen then return
        rebuildStripCats()
        want = "__year"
        if m.yearPick <> "" then want = "__y" + m.yearPick
        found = false
        for each c in currentCats()
            if ToStr(c.id) = want
                found = true
                exit for
            end if
        end for
        if not found then want = firstYearId()
        selectCatById(want)
        return
    end if
    msRepaint(key)
end sub

' ONE SOURCE'S FRESHLY BUILT TREE, MOVED INTO THE TREE THIS VIEW KEEPS.
'
' Moved, not copied: each title is one ContentNode and it is re-parented, so
' folding a source in costs nothing beyond the walk. Whatever is left in the
' source's tree afterwards is what this page is not allowed to show, and it
' is thrown away with the task (see onContentDone) instead of sitting in
' memory for the rest of the visit.
'
' THE TWO CAPS ARE NOT NEW NUMBERS. Fifteen a row and five hundred a source
' are exactly what the member's own Jellyfin and Emby libraries have been
' held to on this page since they were added (msPageLimit, msFoldRows) — so
' an IPTV provider and a media server now cost the same page the same amount,
' which is the thing that was wrong. Five hundred posters is eighty-four rows
' of the six-wide grid, far past where anyone scrolls, and the member can
' still reach anything else through Search or through the category itself.
sub xtFoldTree(root as object, tree as object, viewKind as string, label as string)
    if root = invalid or tree = invalid then return
    ' ---- THE FIRST SOURCE COSTS ALMOST NOTHING ----------------------------
    ' Nothing has been folded in yet, so there is nothing to merge WITH: the
    ' task's rows are already in the strip's display order (Home) or newest
    ' first (Year), and it already capped them at fifteen and three hundred.
    ' They move across whole — one re-parent per ROW instead of one per title,
    ' and no name matching at all.
    '
    ' This matters because the merge below runs on the RENDER THREAD, and
    ' certification 3.5 gives us 250ms to answer a remote press. A provider
    ' with two hundred categories would otherwise cost a name scan per row on
    ' top of a move per title, for the one source that never needed either.
    ' Every source after the first takes the slow, correct path.
    if (viewKind = "rows" or viewKind = "years") and root.getChildCount() = 0
        while tree.getChildCount() > 0
            xtMoveChild(tree, root)
        end while
        return
    end if
    if viewKind = "rows"
        for j = 0 to tree.getChildCount() - 1
            srcRow = tree.getChild(j)
            ' A ROW WITH NOTHING IN IT MUST NEVER BE CREATED (2026-10-02).
            ' msRowFor makes the row whether or not anything follows it, so
            ' handing it an empty one puts a category name on the page with
            ' no posters under it - a row advertising titles it will never
            ' show, which is the complaint behind log key B6DA8F. The task
            ' drops its own empty rows already; this is the same rule on the
            ' merge side, where a later source can arrive with a row the
            ' television's memory alarm emptied before it was built.
            if srcRow.getChildCount() = 0 then continue for
            rowNode = msRowFor(root, ToStr(srcRow.title))
            if rowNode <> invalid
                while srcRow.getChildCount() > 0 and rowNode.getChildCount() < 15
                    xtMoveChild(srcRow, rowNode)
                end while
            end if
        end for
    else if viewKind = "years"
        for j = 0 to tree.getChildCount() - 1
            srcRow = tree.getChild(j)
            ' Same rule as the rows branch above: msYearRowFor creates the
            ' year whether or not a title follows, and an empty year is a
            ' heading promising films that are not there.
            if srcRow.getChildCount() = 0 then continue for
            rowNode = msYearRowFor(root, ToStr(srcRow.title))
            ' The same three hundred a year the Xtream year build and the
            ' media-server year fold both already use.
            while srcRow.getChildCount() > 0 and rowNode.getChildCount() < 300
                xtMoveChild(srcRow, rowNode)
            end while
        end for
    else
        ' The flat grid — the All view, and a single category.
        onSource = tree.getChildCount()
        lim = msPageLimit("flat")
        kept = 0
        while tree.getChildCount() > 0 and kept < lim
            xtMoveChild(tree, root)
            kept = kept + 1
        end while
        ' Named in the log exactly the way a member's own library already
        ' reads, so the two paths can be read off one log side by side.
        if onSource > lim
            KLog("vod", "'" + label + "' holds " + onSource.toStr() + " titles; showing the first " + lim.toStr() + ".")
        end if
    end if
end sub

' Re-parent the first child of one node onto another. Removed from its old
' parent first rather than relying on appendChild to do it — the tree it came
' from is about to be emptied and we must not be guessing about who still
' holds a reference to what.
sub xtMoveChild(src as object, dst as object)
    node = src.getChild(0)
    if node = invalid then return
    src.removeChild(node)
    dst.appendChild(node)
end sub

' The one line on screen that says this page is short of the member's real
' library because the television ran out of room.
'
' SET BOTH WAYS, EVERY TIME. This label is on a screen that switches between
' Movies and Series, between sources and between categories without being
' rebuilt, so a note left visible from a view that ran short would sit over a
' view that did not and tell the member a lie about it.
sub xtShowMemNote(key as string)
    capped = m.xtCapped.doesExist(key)
    if capped
        ' TWO LINES, 48 CHARACTERS EACH AT MOST. This page is set in JetBrains
        ' Mono - a flat 0.6em advance - so at 18px the 520px label holds 48
        ' characters and the label is capped at two lines, because a third
        ' would land on the source chips' focus ring (VodScreen.xml).
        '
        ' WHY THERE IS A SECOND LINE AT ALL (2026-10-02, log key B6DA8F). The
        ' first line is the old wording with "memory" swapped for "room" - a
        ' word anyone understands. On its own it told the member what had gone
        ' wrong and nothing whatever about what to do, and that member went and
        ' deleted their source. The second line is not new advice: it is the
        ' same remedy the empty page offers in showContent below, said short
        ' enough to fit.
        m.memNote.text = "Short of room - some titles aren't listed." + Chr(10) + "Reopening the app usually helps."
    else
        m.memNote.text = ""
    end if
    m.memNote.visible = capped
end sub

' ---- "YOUR PROVIDER SENT BACK AN EMPTY FILM LIST" -----------------------------
'
' DID THE MEMBER'S PROVIDER HAND BACK A FILM LIST WITH NOTHING IN IT?
'
' Added 2026-10-15 off the Windows lane's W-214. Mason hit it on his own
' account: the panel answered get_vod_streams with an empty list in under a
' second, where every other day the same account holds about 44,000 films.
'
' This is the one question that separates the blank pages that look identical
' from a sofa, and getting it wrong in either direction is worse than saying
' nothing at all. It says yes to ONE case and no to every other:
'
'   YES   a source answered, politely, and its list was empty.
'
'   NO, nobody answered (answered = 0). "Couldn't be reached" is not "sent
'       nothing", and this screen already has words for it.
'   NO, we stopped building to save room (xtCapped). That is OUR doing, it
'       already has its own message, and confusing the two would be the worst
'       outcome of this change - the member on log key B6DA8F had 37 films
'       waiting and was told the page was empty.
'   NO, films DID arrive and this page dropped them. That is what a member who
'       has hidden or locked every one of their film categories looks like:
'       `raw` is in the thousands and the page is still blank. Telling them
'       their provider is broken would send them to delete a source that is
'       working perfectly.
'   NO on a single category. An empty folder is an empty folder; the provider
'       is answering fine, so only the three whole-catalogue views (Home, All,
'       Year) can reach this.
'   NO while anything is still being asked for, including one of the member's
'       own servers - a page that has not finished loading is not an empty one.
function xtProviderSentNothing(key as string) as boolean
    tally = m.xtTally[key]
    if tally = invalid then return false
    ' doesExist FIRST, the shape onContentDoneInner already uses on the task's
    ' payload: a missing field reads as invalid, and `invalid = true` is a
    ' Type Mismatch that kills the render thread. Every tally this screen
    ' writes carries all four fields, and this is what keeps that true of the
    ' next person's as well.
    if not tally.doesExist("whole") then return false
    if tally.whole <> true then return false
    if m.xtQueue.doesExist(key) then return false
    if m.inflight.doesExist("items_" + key) then return false
    if m.msPending > 0 then return false
    if m.xtCapped.doesExist(key) then return false
    if ToInt(tally.answered) <= 0 then return false
    return (ToInt(tally.raw) = 0)
end function

' The "Try again" button, shown or hidden.
'
' SET BOTH WAYS, EVERY PAINT, exactly as xtShowMemNote is and for the same
' reason: this screen switches between Movies and Series, between sources and
' between categories without ever being rebuilt, so a button left over from a
' view that had nothing would sit on top of a view that has plenty.
'
' AND IT TAKES THE HIGHLIGHT WITH IT. This button is a drawn pill rather than
' a real focusable node, so nothing in the firmware moves focus off it when it
' disappears. Leaving m.focusArea on "retry" would leave the member pressing OK
' on a button that is no longer there. The focus move only happens when focus
' was actually ON the button - it must never reach in and grab focus off the
' poster grid during an ordinary repaint.
sub xtShowRetry(key as string, shown as boolean)
    m.retryGroup.visible = shown
    if shown
        redrawRetry()
        return
    end if
    if m.focusArea = "retry"
        m.focusArea = "cats"
        redrawCatStrip()
        m.keySink.setFocus(true)
    end if
end sub

' The button's two states, in the same language as the pills at the top of
' this page: the PLATE changes colour and the ink flips with it, plus a ring.
' A one-step lift in grey is invisible across a living room.
'
' Unfocused ink is textPrimary and not textSecondary - this is the only
' control on an otherwise empty page, and it has to read as a button rather
' than as more of the paragraph above it. Same choice MediaBar.paintButton
' makes for its unfocused plates.
'
' ToStr around m.focusArea because init calls this before m.focusArea has been
' assigned, and comparing an unset field straight to a string is a type
' mismatch waiting for whoever moves these lines around next.
sub redrawRetry()
    focusedHere = (ToStr(m.focusArea) = "retry")
    m.retryRing.visible = focusedHere
    m.retryRing.blendColor = m.theme.focusHighlight
    if focusedHere
        m.retryPill.blendColor = m.theme.accent
        ' The PAGE colour on the accent fill, not white - the accent is Nord
        ' frost, a LIGHT colour, and white on it is under 2:1. Same ruling as
        ' redrawModeTabs a few hundred lines up.
        m.retryLabel.color = m.theme.background
    else
        m.retryPill.blendColor = m.theme.surfaceElevated
        m.retryLabel.color = m.theme.textPrimary
    end if
end sub

' THE MEMBER PRESSED TRY AGAIN.
'
' ONE REQUEST, ON A PRESS, AND NOTHING ELSE IN THIS APP CAN REACH IT. There is
' no timer behind this, no retry loop, and nothing in the background: a panel
' answering empty under load must not be hammered, and the only thing that can
' ask it again is a member deciding to. A second press costs one more request,
' the same as the first.
'
' All it does is forget this view's answer. Everything after that is the
' ordinary load this page already does, with the ordinary one-source-at-a-time
' memory discipline, so nothing new is held and nothing new is asked for.
'
' WHAT IT DOES NOT DO. It does not re-ask a source whose CATEGORY list failed
' (m.deadSrc): that source did not answer a small request, so a much bigger one
' is not going to work either, and asking anyway is the pattern that got this
' house's provider access banned. And it does not touch any view but this one.
sub doVodRetry()
    key = currentContentKey()
    if key = "" then return
    ' Already asking? Then there is nothing for this press to do, and starting
    ' a second catalogue on the wire is the exact thing this screen's memory
    ' work exists to prevent.
    if m.xtQueue.doesExist(key) or m.inflight.doesExist("items_" + key) then return
    KLog("vod", "you pressed Try again - asking your sources for the film list once more")
    m.contentByKey.delete(key)
    m.xtTally.delete(key)
    m.xtCapped.delete(key)
    ' Focus off the button FIRST, so hiding it has nothing to rescue, and back
    ' on the category strip - which is where the member was a press ago and
    ' where the spinner is about to appear underneath.
    m.focusArea = "cats"
    xtShowRetry(key, false)
    redrawRetry()
    redrawCatStrip()
    m.keySink.setFocus(true)
    loadItems()
end sub

' Every Adult-classified category name across the shown sources, for the
' All/Home fetch to drop by name. Empty when the member has allowed them —
' see the Adult block in GuideMeta.brs.
function adultCatNames() as object
    out = []
    if AdultCatsAllowed() then return out
    agg = m.catAggByMode[m.mode]
    if agg = invalid then return out
    seen = {}
    for each pid in agg
        for each c in agg[pid]
            nm = ToStr(c.name)
            if nm <> "" and not seen.doesExist(nm) and IsAdultCatName(nm)
                seen[nm] = true
                out.push(nm)
            end if
        end for
    end for
    return out
end function

' One source's category id->name pairs for the rows-mode bucketing.
function srcCatMap(provId as string) as object
    out = []
    agg = m.catAggByMode[m.mode]
    if agg <> invalid and agg.doesExist(provId)
        for each c in agg[provId]
            out.push({ id: ToStr(c.catId), name: ToStr(c.name) })
        end for
    end if
    return out
end function

' ONE SOURCE'S CATALOGUE HAS LANDED.
'
' It is folded into the page, the rest of it is thrown away, and only THEN is
' the next source asked for. That order is the whole fix (see the long note
' in loadItems and log key 5BB222): two raw catalogues must never be in this
' television at the same moment.
sub onContentDone(event as object)
    try
        onContentDoneInner(event)
    catch e
        GuardFailed("vod/onContentDone", e)
        ' AFE7F5's surface, and the one guard on this screen that has real
        ' work to do in the catch.
        '
        ' LET GO OF THE CATALOGUE THE TASK IS STILL HOLDING. On a provider
        ' panel that tree is tens of thousands of nodes and it is the largest
        ' thing this screen ever has in hand - the real handler hands the task
        ' a fresh empty tree for exactly that reason, and a fault before it
        ' got that far would otherwise leave the whole catalogue held for the
        ' rest of the session on a screen that already has five out-of-memory
        ' crash reports behind it.
        '
        ' Nested, so a failure in the clean-up cannot itself become the
        ' uncaught fault this guard exists to prevent.
        try
            t = event.getRoSGNode()
            if t <> invalid
                t.unobserveField("done")
                t.content = CreateObject("roSGNode", "ContentNode")
            end if
        catch e2
            GuardFailed("vod/onContentDone/release", e2)
        end try
    end try
end sub

sub onContentDoneInner(event as object)
    task = event.getRoSGNode()
    res = event.getData()
    key = ToStr(task.tag)
    m.inflight.delete("items_" + key)
    plan = m.xtQueue[key]
    viewKind = msViewKindFor(key)
    label = ""
    if plan <> invalid
        viewKind = ToStr(plan.viewKind)
        label = ToStr(plan.lastLabel)
    end if
    if res <> invalid and res.ok = true
        ' A media server that answered while the IPTV catalogue was still
        ' coming has its titles parked to one side only if there was no tree
        ' to put them in. There always is one now, but the drain is kept for
        ' anything held from an earlier visit to the same view.
        msDrainHeld(key, viewKind)
        xtFoldTree(m.contentByKey[key], task.content, viewKind, label)
    end if
    ' ---- WHAT THE PROVIDER ITSELF SENT (2026-10-15) ----------------------
    ' Added up here, before anything on this page has had a chance to decide
    ' what it is willing to show. The fold above may well have kept nothing -
    ' that is this page's doing and is a different story from the provider
    ' having nothing to send, which is the whole point of keeping the two
    ' numbers apart.
    '
    ' doesExist on every field, the shape onContentDone already uses below
    ' and for the same reason: a payload written by anything other than
    ' VodContentTask reads as invalid, and ToInt(invalid) is 0 but an
    ' unguarded field read on an older payload is not worth the risk on the
    ' render thread.
    tally = m.xtTally[key]
    if tally <> invalid and res <> invalid
        if res.doesExist("asked") then tally.asked = ToInt(tally.asked) + ToInt(res.asked)
        if res.doesExist("answered") then tally.answered = ToInt(tally.answered) + ToInt(res.answered)
        if res.doesExist("raw") then tally.raw = ToInt(tally.raw) + ToInt(res.raw)
    end if
    ' ---- DID THE TELEVISION CUT THIS PAGE SHORT? (2026-10-02, B6DA8F) ----
    ' Until now the only place that could mark a view short was the ceiling
    ' check between whole-catalogue fetches (xtStartNext), and on the member's
    ' television that check never fired once - every stop came from inside the
    ' build task, where the screen could not see it. So the page knew nothing,
    ' showed nothing, and told that member "Nothing in this category yet."
    ' about a library holding 37 and 50 films.
    '
    ' TWO THINGS COUNT AS SHORT, AND NOTHING ELSE DOES. Either the build
    ' itself stopped early (the task says so outright now - VodContentTask
    ' reports `trimmed`), or sources were dropped off this view's queue
    ' below. A page that happens to be loaded while the alarm is up but lost
    ' nothing is NOT short, and must not be told it is: the member would be
    ' hunting for films that are all already on the screen in front of them.
    cutShort = false
    if res <> invalid
        ' doesExist FIRST (the shape at MediaBar.brs:1598). A payload without
        ' the field reads as invalid, and `invalid = true` is a Type Mismatch
        ' that kills the render thread - so this must not rest on
        ' VodContentTask.brs being the only writer of `done` forever.
        if res.doesExist("trimmed") and res.trimmed = true then cutShort = true
    end if
    ' ---- AND STOP ASKING -------------------------------------------------
    ' The alarm went off six times in thirty-one seconds on that television.
    ' They were not six discoveries. The flag does not clear by itself (it is
    ' cleared in one place only, when a playlist is re-parsed, which a member
    ' on provider panels alone may never do), so those were ONE alarm re-read
    ' by six separate builds - and every one of those builds first pulled a
    ' whole catalogue down off the member's provider and parsed it, only to
    ' throw every title away. That download and parse is among the largest
    ' things this app ever holds, so the retries were making the shortage
    ' worse, not recovering from it. One wasted catalogue is the price of
    ' finding out; the rest are free to skip, and the member gets their words
    ' on screen seconds sooner.
    '
    ' Scoped to the view being loaded right now, on purpose. Because the flag
    ' is sticky, refusing to START a view while it is up would lock Movies &
    ' Series shut for the rest of the session even after the television
    ' recovered. A box that is short on the way IN is handled elsewhere, by
    ' the live device reading in loadItems.
    if xtMemAlarmUp() and plan <> invalid
        if plan.sources.count() > 0
            KLog("vod", "the memory alarm is still up - not asking the remaining " + plan.sources.count().toStr() + " source(s), they would stop the same way")
            plan.sources = []
            cutShort = true
        end if
    end if
    if cutShort then m.xtCapped[key] = true
    ' ---- LET GO OF WHAT WE DID NOT KEEP, HERE, BEFORE ASKING FOR MORE -----
    ' Everything still hanging off this task's tree is a title this page is
    ' not allowed to show. On the member's provider that is tens of thousands
    ' of them. Emptied explicitly rather than left for the task node to take
    ' with it, because the very next line asks for another whole catalogue
    ' and the two must not overlap.
    '
    ' Done by handing the task a fresh empty tree rather than by walking the
    ' old one and removing children: one assignment, and the tree it replaces
    ' has no references left the instant it happens. Walking tens of thousands
    ' of nodes to delete them would be exactly the render-thread stall this
    ' whole change exists to avoid.
    task.content = CreateObject("roSGNode", "ContentNode")
    task.unobserveField("done")
    msRefreshBusy()
    msRepaint(key)
    if plan = invalid
        xtShowMemNote(key)
        return
    end if
    xtStartNext(key)
end sub

sub showContent(key as string, content as object)
    isHome = (key.instr(0, "|__home") > -1)
    m.rowsView.visible = isHome
    m.grid.visible = not isHome
    if isHome
        m.rowsView.content = content
    else
        m.grid.content = content
    end if
    isEmpty = (content = invalid or content.getChildCount() = 0)
    ' STILL COMING IS NOT NOTHING. A member whose only source is their own
    ' server sees an empty pane for as long as that server takes to answer,
    ' and "Nothing in this category yet." under a turning spinner is the app
    ' telling them their library is empty when it has not finished asking.
    ' The spinner speaks for this moment; the words wait their turn.
    if isEmpty and m.msPending > 0 then isEmpty = false
    ' THE SAME RULE FOR THE PANEL CATALOGUE, which now arrives one source at a
    ' time rather than all in one answer. The pane is deliberately bound empty
    ' the instant a view is opened so the titles can appear in place as they
    ' land, which means "nothing in it" is the NORMAL state for the first few
    ' seconds of every view. Without this line every member would be told
    ' their library was empty every time they changed category.
    if isEmpty and m.xtQueue.doesExist(key) then isEmpty = false
    m.emptyLabel.visible = isEmpty
    ' Set both ways on every paint, whatever else this function decides.
    xtShowMemNote(key)
    ' "Nothing here" and "your provider didn't answer" look the same on
    ' screen unless one of them says so — a member whose panel is down was
    ' being told their library was empty.
    names = []
    for each n in m.failedSrc
        names.push(n)
    end for
    ' Does this page get the Try again button? Only the one branch below sets
    ' it, and it is declared out here so the answer exists on every path - the
    ' button is hidden on every other page by the single call at the end.
    sentNothing = false
    if names.count() = 0
        m.emptyLabel.text = "Nothing in this category yet."
        ' An empty YEAR view means the library has no release years to read,
        ' not that a category is empty — say the true thing (Android's
        ' wording).
        if key = yearKey() then m.emptyLabel.text = "No release years in this library yet."
        ' An empty page on a box that ran out of room is not an empty
        ' library, and saying "nothing here" to that member is simply wrong.
        if m.xtCapped.doesExist(key) then m.emptyLabel.text = "This Roku ran short of memory before your movies and series finished loading, so none of them could be listed." + Chr(10) + Chr(10) + "Closing the app and opening it again usually gives it enough room."
        ' ---- THE PROVIDER'S OWN LIST CAME BACK EMPTY (2026-10-15) --------
        ' Checked LAST so it wins over the two generic lines above, and
        ' deliberately NOT over the memory one: a page this Roku cut short is
        ' our doing and not the provider's, and those two must never be
        ' confused. xtProviderSentNothing refuses on xtCapped for the same
        ' reason; the test is repeated here so moving either line cannot
        ' quietly swap the messages over.
        '
        ' Mason's wording, word for word, and it says the one thing a member
        ' most needs to know - that the rest of their app is fine - so they
        ' do not go into Settings and delete a source that is working.
        '
        ' THE MOVIES TAB ONLY, and that is the wording's doing rather than a
        ' limit of the test above. The sentence names films and promises the
        ' member their series are fine, which would be a straight lie on the
        ' Series tab - that tab asks for a different list (get_series) and an
        ' empty answer there is a different sentence nobody has written yet.
        ' Series therefore keeps exactly the words it had. Raised with Mason.
        if m.mode = "movies" and not m.xtCapped.doesExist(key) and xtProviderSentNothing(key)
            sentNothing = true
            m.emptyLabel.text = "Your provider sent back an empty film list. Your channels and series are fine. This usually clears on its own - try again in a moment, or ask your provider."
        end if
    else if names.count() = 1
        m.emptyLabel.text = "Couldn't reach " + names[0] + "." + Chr(10) + Chr(10) + "Its movies and series can't be listed right now. Everything else in the app still works."
    else
        m.emptyLabel.text = "Couldn't reach " + names.count().toStr() + " of your sources." + Chr(10) + Chr(10) + "Their movies and series can't be listed right now."
    end if
    ' Set both ways on every paint, whatever else this function decided.
    xtShowRetry(key, isEmpty and sentNothing)
end sub

' ---- Detail / playback ---------------------------------------------------------

sub onItemSelected()
    try
        onItemSelectedInner()
    catch e
        GuardFailed("vod/onItemSelected", e)
    end try
end sub

sub onItemSelectedInner()
    idx = m.grid.itemSelected
    if m.grid.content = invalid or idx < 0 or idx >= m.grid.content.getChildCount() then return
    openDetail(m.grid.content.getChild(idx))
end sub

sub onRowItemSelected()
    try
        onRowItemSelectedInner()
    catch e
        GuardFailed("vod/onRowItemSelected", e)
    end try
end sub

sub onRowItemSelectedInner()
    sel = m.rowsView.rowItemSelected
    if sel = invalid or sel.count() < 2 or m.rowsView.content = invalid then return
    rowNode = m.rowsView.content.getChild(sel[0])
    if rowNode = invalid or sel[1] >= rowNode.getChildCount() then return
    openDetail(rowNode.getChild(sel[1]))
end sub

' Detail item comes straight off the ContentNode (id / title / poster /
' container hint) — no parallel arrays to fall out of sync.
sub openDetail(node as object)
    if node = invalid then return
    ' The item's SOURCE rides along — the detail screen plays, favorites
    ' and resumes against that source, not whatever is "active".
    srcTok = ""
    if node.hasField("srcTok") then srcTok = ToStr(node.srcTok)
    scene = m.top.getScene()
    if m.mode = "series"
        m.detail = scene.createChild("SeriesDetailScreen")
        item = { kind: "series", seriesId: node.id, name: node.title, icon: node.hdPosterUrl, src: srcTok }
        msCarryDetail(node, item)
        m.detail.item = item
    else
        m.detail = scene.createChild("MovieDetailScreen")
        item = { kind: "movie", streamId: node.id, name: node.title, icon: node.hdPosterUrl, ext: node.description, src: srcTok }
        msCarryDetail(node, item)
        m.detail.item = item
    end if
    m.detail.observeField("closed", "onDetailClosed")
    m.detail.setFocus(true)
end sub

' THE MEDIA-SERVER EXTRAS, HANDED ON UNDER THE NAMES THE DETAIL PAGES READ.
'
' A media-server tile already carries the whole of its own description because
' the library read paid for it (see msAppendRow). This is the moment it stops
' being tile data and becomes page data, so the prefixed names are dropped and
' the plain ones the detail screens read take over.
'
' An Xtream tile has none of these fields, so it is passed through untouched
' and its map keeps exactly the shape it has always had — the detail screen
' goes on fetching that title's information from the panel the way it always
' has. That is what the hasField test is for, and why every field is either
' added or not added as one group.
sub msCarryDetail(node as object, item as object)
    if not node.hasField("msOverview") then return
    item.overview = ToStr(node.msOverview)
    item.year = ToInt(node.msYear)
    item.runtime = ToInt(node.msRuntime)
    item.logo = ToStr(node.msLogo)
    item.backdrop = ToStr(node.msBackdrop)
    item.rating = ToStr(node.msRating)
    item.cert = ToStr(node.msCert)
    item.genres = ToStr(node.msGenres)
end sub

sub onDetailClosed()
    try
        onDetailClosedInner()
    catch e
        GuardFailed("vod/onDetailClosed", e)
        ' FOCUS MUST END UP SOMEWHERE REAL. The real handler takes the detail
        ' page off the scene first and hands focus back last, so a fault in
        ' between leaves the page gone and focus nowhere - the grid on screen
        ' with a remote that does nothing.
        '
        ' The key sink and not the grid, and m.focusArea moved to match: the
        ' area this handler says is active and the node that actually holds
        ' focus have to agree, or the arrow keys are handled for the grid
        ' while the grid has no focus - the "highlighted but not really" bug
        ' the key sink exists to prevent. The member lands on the category
        ' strip instead of back in the grid, which is a real change, but only
        ' ever on a caught fault.
        m.focusArea = "cats"
        m.keySink.setFocus(true)
    end try
end sub

sub onDetailClosedInner()
    if m.detail <> invalid
        m.top.getScene().removeChild(m.detail)
        m.detail = invalid
    end if
    ' They may have just watched some of whatever they opened. Rebuild the
    ' index and the posters repaint themselves where they stand — the grid's
    ' content is deliberately NOT re-assigned, which would throw away the
    ' scroll position they came back to (the same reason the hearts are done
    ' this way).
    refreshResumeVodIndex(m.mode = "series")
    contentPane().setFocus(true)
end sub

sub setBusy(b as boolean)
    m.spinner.visible = b
    if b
        m.spinner.control = "start"
    else
        m.spinner.control = "stop"
    end if
end sub

' ---- Keys -----------------------------------------------------------------------

sub selectMode(idx as integer)
    if idx <= 1
        newMode = "movies"
        if idx = 1 then newMode = "series"
        if newMode <> m.mode
            m.mode = newMode
            ' Series carry the expensive half of the index, so it is only
            ' built on the tab that can show one.
            refreshResumeVodIndex(m.mode = "series")
            redrawModeTabs()
            loadCategories()
        end if
    else if idx - 2 < m.chipDefs.count()
        ' A source chip: filter the whole catalog to that source (or All)
        ' and remember the choice, like Android's prefs.vodSource.
        pick = ToStr(m.chipDefs[idx - 2].filter)
        if pick <> m.srcFilter
            m.srcFilter = pick
            RegWrite("pref_vod_source" + ProfileScopeSuffix(), pick)
            redrawModeTabs()
            loadCategories()
        end if
    end if
end sub

sub selectCat(idx as integer)
    cats = currentCats()
    if idx < 0 or idx >= cats.count() then return
    if cats[idx].locked = true and not ParentalUnlocked()
        m.pinTargetCatId = cats[idx].id
        promptVodPin()
        return
    end if
    id = ToStr(cats[idx].id)

    if id = "__year"
        if m.yearOpen
            ' Year again folds the years away and puts back whatever was
            ' showing before — the short way out of a hundred year entries
            ' without walking right past all of them.
            m.yearOpen = false
            rebuildStripCats()
            selectCatById(m.yearBackId)
            return
        end if
        ' Remember where we came from, unless we came from a year.
        m.yearBackId = ""
        if m.catIdx >= 0 and m.catIdx < cats.count()
            back = ToStr(cats[m.catIdx].id)
            if not isYearId(back) then m.yearBackId = back
        end if
        m.yearOpen = true
        m.yearPick = ""
        ' The Year view is a different set of posters from the one that was
        ' on screen, so the resume bars need the same rebuild the Movies /
        ' Series switch does — once, on the way in. NOT per year: this
        ' sweeps the registry, and doing it on every year press would spend
        ' the 250 ms certification 3.5 allows on a keypress that only has to
        ' swap one already-built row into the grid.
        refreshResumeVodIndex(m.mode = "series")
        rebuildStripCats()
        selectCatById(firstYearId())
        return
    end if

    if isYearId(id)
        m.yearPick = ToStr(cats[idx].year)
        if idx <> m.catIdx
            m.catIdx = idx
            redrawCatStrip()
            loadItems()
        end if
        return
    end if

    ' An ordinary category, Home or All: fold the years away first, then
    ' find the target again — folding moves every index after Year.
    if m.yearOpen
        m.yearOpen = false
        rebuildStripCats()
        selectCatById(id)
        return
    end if
    if idx <> m.catIdx
        m.catIdx = idx
        redrawCatStrip()
        loadItems()
    end if
end sub

' PIN gate for a locked VOD category. On success, unlock for the session,
' re-fetch this mode's categories (locks clear) and open the target.
sub promptVodPin()
    kb = CreateObject("roSGNode", "PinDialog")
    kb.title = "Enter PIN"
    kb.observeField("accepted", "onVodPin")
    kb.observeField("cancelled", "onVodPinCancel")
    m.pinDialog = kb
    ' The scene's dialog slot, not a child — see PinDialog.
    m.top.getScene().dialog = kb
end sub

sub removeVodPin()
    if m.pinDialog <> invalid
        m.pinDialog.close = true
        m.pinDialog = invalid
    end if
end sub

sub onVodPin()
    try
        onVodPinInner()
    catch e
        GuardFailed("vod/onVodPin", e)
        ' THIS GUARD CANNOT OPEN A LOCKED CATEGORY, and that has to be
        ' checkable by eye because this is the parental gate. The unlock
        ' happens on one line, immediately after CheckParentalPin has already
        ' returned true; a fault anywhere before that leaves the session
        ' locked, a fault in CheckParentalPin itself lands here with nothing
        ' unlocked, and a fault after it means the member typed the right PIN.
        ' There is no path through this catch that grants access.
        '
        ' The dialog is taken down and focus put back, or the member is left
        ' looking at a PIN box that no longer answers.
        removeVodPin()
        m.keySink.setFocus(true)
    end try
end sub

sub onVodPinInner()
    entered = m.pinDialog.value
    removeVodPin()
    if CheckParentalPin(entered)
        SetParentalUnlocked(true)
        m.pendingSelectId = m.pinTargetCatId
        m.catsByKey.delete(catsKey())   ' force re-merge so locks recompute
        loadCategories()
    else
        note = CreateObject("roSGNode", "Dialog")
        note.title = "Incorrect PIN"
        note.buttons = ["OK"]
        note.observeField("buttonSelected", "onVodPinNote")
        m.top.getScene().dialog = note
    end if
end sub

sub onVodPinCancel()
    try
        onVodPinCancelInner()
    catch e
        GuardFailed("vod/onVodPinCancel", e)
        m.keySink.setFocus(true)
    end try
end sub

sub onVodPinCancelInner()
    removeVodPin()
    m.keySink.setFocus(true)
end sub

sub onVodPinNote()
    try
        onVodPinNoteInner()
    catch e
        GuardFailed("vod/onVodPinNote", e)
        ' The first statement of the real handler reaches into the scene's
        ' dialog slot to close it, so this is the likeliest of the three PIN
        ' callbacks to fault - and if it does, focus is still on a dialog that
        ' is going away. Put it back on the screen.
        m.keySink.setFocus(true)
    end try
end sub

sub onVodPinNoteInner()
    m.top.getScene().dialog.close = true
    m.keySink.setFocus(true)
end sub

' ---- The mode area is TWO ROWS now, so its walk is 2-D --------------------
'
' m.modeNodes is one flat list: 0 and 1 are the Movies | Series tabs, 2 onward
' are the source chips on the row beneath them. Left and right move WITHIN a
' row and never wrap between them - a D-pad that walked off the end of Series
' and reappeared under "All" is the kind of jump nobody can predict from a sofa.
'
' CROSSING A ROW LANDS ON THAT ROW'S SELECTED PILL, both directions: down from
' the tabs lands on the chip the catalogue is actually filtered to, up from the
' chips lands on the tab that is actually lit. It is one rule, it is a pure
' function of state, and it puts the highlight where the member's eye already
' is. (The detail pages land on a row's LEFT END instead; there the rows have no
' "selected" member to land on, so there is nothing to be consistent with.)
'
' Left at the start of either row still walks out to the sidebar, exactly as it
' did when there was one row.

' Which row an index is on. -1 is not possible here: the mode area always has at
' least the two tabs.
function inChipRow(idx as integer) as boolean
    return (idx >= 2)
end function

' The lit mode tab, which is where the chip row hands focus back.
function activeTabIdx() as integer
    if m.mode = "series" then return 1
    return 0
end function

' The lit source chip, which is where the tab row hands focus down. -1 when
' there is no chip row at all (a single-source box), and the caller then falls
' straight through to the category strip.
function activeChipIdx() as integer
    if not m.multi then return -1
    if m.modeNodes.count() <= 2 then return -1
    for i = 0 to m.chipDefs.count() - 1
        if ToStr(m.chipDefs[i].filter) = m.srcFilter then return i + 2
    end for
    return 2
end function

' Down out of the mode area, into the category strip. Held in one place because
' three branches reach it.
sub enterCatStrip()
    if currentCats().count() = 0 then return
    m.focusArea = "cats"
    m.catFocus = m.catIdx
    ensureCatVisible()
    redrawModeTabs()
    buildCatStrip()
end sub

' Up (or Back) out of the category strip, into the mode area. It lands on the
' row DIRECTLY ABOVE the strip - the chips when there are any, the tabs
' otherwise - because that is where the geometry says up goes.
sub enterModesFromBelow()
    m.focusArea = "modes"
    chip = activeChipIdx()
    if chip >= 0 then m.modeFocus = chip
    redrawModeTabs()
    redrawCatStrip()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    try
        return onKeyEventInner(key, press)
    catch e
        GuardFailed("vod/onKeyEvent", e)
    end try
    ' FALSE, NOT TRUE, ON A CAUGHT FAULT - the TV Guide's choice, not the
    ' channel page's, and on this screen the reason is written into the file
    ' already (see the note at the top, and the "back" branch in the modes
    ' area). Back only works here BECAUSE it is handed upward: AppShell is
    ' what walks the member one screen out toward Home. Returning true would
    ' swallow it and leave them sealed on a faulting page with a dead Back
    ' button and no error to find.
    return false
end function

function onKeyEventInner(key as string, press as boolean) as boolean
    if not press then return false

    if m.focusArea = "modes"
        if key = "right"
            lastIdx = 1
            if inChipRow(m.modeFocus) then lastIdx = m.modeNodes.count() - 1
            if m.modeFocus < lastIdx
                m.modeFocus = m.modeFocus + 1
                redrawModeTabs()
            end if
            return true
        else if key = "left"
            firstIdx = 0
            if inChipRow(m.modeFocus) then firstIdx = 2
            if m.modeFocus > firstIdx
                m.modeFocus = m.modeFocus - 1
                redrawModeTabs()
                return true
            end if
            m.top.backToNav = true
            return true
        else if key = "OK"
            selectMode(m.modeFocus)
            return true
        else if key = "up"
            ' Chips -> tabs. The tabs are the top of the page and keep the old
            ' behaviour of letting the key bubble.
            if inChipRow(m.modeFocus)
                m.modeFocus = activeTabIdx()
                redrawModeTabs()
                return true
            end if
            return false
        else if key = "down"
            ' Tabs -> chips, chips -> the category strip. On a single-source
            ' box there is no chip row and the tabs go straight to the strip,
            ' which is exactly what this page did before it had two rows.
            if not inChipRow(m.modeFocus)
                chip = activeChipIdx()
                if chip >= 0
                    m.modeFocus = chip
                    redrawModeTabs()
                    return true
                end if
            end if
            enterCatStrip()
            return true
        else if key = "back"
            ' Back does NOT raise backToNav any more (certification 4.6, and the
            ' owner's "i should be able to back button all the way to home"). It
            ' returns FALSE so the key bubbles to AppShell.onKeyEvent, which walks
            ' one screen out toward Home and raises the exit confirmation once it
            ' gets there. LEFT is unchanged and still parks on the rail - it is a
            ' direction, not an exit.
            '
            ' The false is returned EXPLICITLY rather than by falling out of the
            ' branch, because the fall-through at the end of this handler can be
            ' `return true`, which would eat it and leave Back doing nothing at
            ' all - a dead button with no error to find.
            return false
        end if
        return false
    end if

    if m.focusArea = "cats"
        cats = currentCats()
        if key = "right"
            if m.catFocus < cats.count() - 1
                m.catFocus = m.catFocus + 1
                ensureCatVisible()
                buildCatStrip()
            end if
            return true
        else if key = "left"
            if m.catFocus > 0
                m.catFocus = m.catFocus - 1
                ensureCatVisible()
                buildCatStrip()
                return true
            end if
            m.top.backToNav = true
            return true
        else if key = "OK"
            selectCat(m.catFocus)
            return true
        else if key = "up"
            enterModesFromBelow()
            return true
        else if key = "down"
            pane = contentPane()
            if pane.content <> invalid and pane.content.getChildCount() > 0
                m.focusArea = "content"
                redrawCatStrip()
                pane.setFocus(true)
            else if m.retryGroup.visible
                ' The empty page's one control. Gated on the button actually
                ' being on screen, so Down past an ordinary empty category
                ' still does nothing at all, exactly as it did before.
                m.focusArea = "retry"
                redrawCatStrip()
                redrawRetry()
                m.keySink.setFocus(true)
            end if
            return true
        else if key = "back"
            enterModesFromBelow()
            return true
        end if
        return false
    end if

    ' ---- The Try again button on an empty page ---------------------------
    ' A drawn pill rather than a focusable node - the same idiom as the pills
    ' at the top of this page - so keySink is holding real focus and every key
    ' this button answers has to be spelled out here.
    if m.focusArea = "retry"
        if key = "OK"
            doVodRetry()
            return true
        else if key = "up" or key = "back"
            m.focusArea = "cats"
            redrawCatStrip()
            redrawRetry()
            m.keySink.setFocus(true)
            return true
        else if key = "left"
            ' Left walks out toward the sidebar, the same direction it means
            ' everywhere else on this screen.
            m.top.backToNav = true
            return true
        else if key = "right" or key = "down"
            ' One button, with nothing either side of it and nothing below.
            ' The key is eaten rather than passed on, so the highlight cannot
            ' wander off a page that has nothing else on it to land on.
            return true
        end if
        return false
    end if

    ' Content pane (grid or rows) has native focus; handle exits.
    if key = "up"
        atTop = false
        if m.rowsView.visible
            focusedRow = m.rowsView.rowItemFocused
            atTop = (focusedRow <> invalid and focusedRow.count() > 0 and focusedRow[0] = 0)
        else
            ' Read the column count off the grid rather than spelling it
            ' out - it moved from 6 to 7 when the poster card became a real
            ' 2:3 poster, and a hard-coded number here silently strands the
            ' top row against the category strip.
            atTop = (m.grid.itemFocused < m.grid.numColumns)
        end if
        if atTop
            m.focusArea = "cats"
            m.keySink.setFocus(true)
            redrawCatStrip()
            return true
        end if
        return false
    else if key = "back"
        m.focusArea = "cats"
        m.keySink.setFocus(true)
        redrawCatStrip()
        return true
    else if key = "left"
        atLeft = false
        if m.rowsView.visible
            focusedRow = m.rowsView.rowItemFocused
            atLeft = (focusedRow <> invalid and focusedRow.count() > 1 and focusedRow[1] = 0)
        else
            atLeft = (m.grid.itemFocused mod m.grid.numColumns = 0)
        end if
        if atLeft
            m.top.backToNav = true
            return true
        end if
        return false
    end if
    return false
end function

' Keep the focused category inside the packed strip window (widths vary,
' so hold a small margin of earlier entries for context).
sub ensureCatVisible()
    if m.catFocus < m.catScroll
        m.catScroll = m.catFocus
        return
    end if
    lastBuilt = m.catScroll
    if m.catNodes <> invalid and m.catNodes.count() > 0
        lastBuilt = m.catNodes[m.catNodes.count() - 1].index
    end if
    if m.catFocus > lastBuilt
        m.catScroll = m.catFocus - 2
        if m.catScroll < 0 then m.catScroll = 0
    end if
end sub

' ==== THE MEMBER'S OWN SERVERS ================================================
'
' Everything below talks to a Jellyfin or an Emby and NOTHING above it does.
' That line is the safety rule of this screen, not a filing preference: an
' Xtream address and a media-server address have not one thing in common, and
' the day a media server was allowed into m.vodSources this page fired
' get_vod_categories at a Jellyfin and hung for ninety seconds per source
' (Mason, 2026-09-12, "i went and clicked VOD and the app froze"). Every
' function here is prefixed ms, every one of them is reached only from a
' currentMediaSources() list, and none of them can be handed an Xtream source.
'
' HOW IT FITS THE PAGE, in one paragraph. A server's LIBRARIES are its
' categories and merge by name into the same strip as the IPTV ones; a
' library's films and shows are mapped by MsMapItem into the very same
' ContentNode the Xtream task builds, field for field, so the poster tile, the
' favourite heart, the resume bar and the source dot need no idea any of this
' exists. The two halves are fetched independently and fold together whenever
' each arrives, so a server that is asleep costs the IPTV catalogue nothing.
'
' WHAT IT COSTS THE NETWORK. One request for the libraries per visit to this
' screen, shared by both tabs and every chip, and then one request per library
' per view opened, cached. Nothing here is per tile, per row or per scroll.

' ---- Libraries and genres ------------------------------------------------------

' WHY FILMS ARE BROWSED BY GENRE AND SHOWS BY LIBRARY (Mason, 2026-09-12:
' "it should show all the genreas for movies, and liobrarys for series").
'
' His shows live in libraries that already read as categories — Anime,
' Classic TV, Docu-Series, Kids TV, Reality TV, TV Shows — and browsing those
' by name is exactly how he thinks about them. His films live in ONE library
' called "Movies" holding 4,599 of them, so a strip built from libraries
' offered him a single button in front of the lot: no browsing at all, and a
' Home landing that was one row scrolling sideways rather than a page
' scrolling down. The genres are the shelves that library actually has — 22
' on his Jellyfin, 19 on his Emby.
'
' The two lists never mix in the strip. On the Movies tab the library names
' are not merged at all, or "Movies" would sit in the middle of his genres
' reading like one of them.
'
' BOTH ARE STILL READ ON THE MOVIES TAB, because the strip is not the only
' thing that needs an answer: All and Year sweep the catalogue, and a sweep
' built from genres would ask 22 times for 500 titles each and hand back the
' same film once per genre it is filed under. Those two views keep sweeping
' libraries. So a server costs two small GETs for the whole visit — one list
' of libraries, one list of genres — and nothing per row, per tile or per
' scroll.
sub msLoadCatalog()
    msLoadLibraries()
    if m.mode = "movies" then msLoadGenres()
end sub

' The film genres of every shown server, once each.
sub msLoadGenres()
    for each s in currentMediaSources()
        pid = s.provId
        if m.msGenres.doesExist(pid) then continue for
        if m.inflight.doesExist("msgenres_" + pid) then continue for
        task = CreateObject("roSGNode", "MediaServerTask")
        task.tag = pid
        task.url = MsGenresUrl(s.prov, "Movie")
        task.headers = MsHeaders(s.prov)
        task.timeoutMs = 20000
        task.observeField("result", "onMediaGenres")
        m.inflight["msgenres_" + pid] = task
        m.msPending = m.msPending + 1
        task.control = "RUN"
    end for
end sub

sub onMediaGenres(event as object)
    try
        onMediaGenresInner(event)
    catch e
        GuardFailed("vod/onMediaGenres", e)
    end try
end sub

sub onMediaGenresInner(event as object)
    pid = ToStr(event.getRoSGNode().tag)
    m.inflight.delete("msgenres_" + pid)
    if m.msPending > 0 then m.msPending = m.msPending - 1
    res = event.getData()
    ok = false
    if res <> invalid
        if res.ok = true then ok = true
    end if
    kept = []
    if ok
        seen = {}
        for each g in ToArray(GetField(res.data, "Items"))
            nm = ToStr(GetField(g, "Name"))
            nm = nm.trim()
            ' THE NAME IS THE WHOLE OF WHAT IS KEPT, and the id that comes
            ' back beside it is deliberately thrown away: measured on both of
            ' the owner's servers, `genres=Action` answers 1,287 films and
            ' `genreIds=` answers nothing at all (MsGenreItemsUrl). A name is
            ' also the same string on every server he owns, where an id is
            ' not, so two servers' "Action" merge into one strip entry.
            if nm <> "" and not seen.doesExist(nm)
                seen[nm] = true
                kept.push({ name: nm })
            end if
        end for
    else
        s = msSourceById(pid)
        if s <> invalid then m.failedSrc[s.label] = true
        KLog("vod", "media server did not list its film genres: " + msErrText(res))
    end if
    ' Written either way, for the same reason the library list is: an empty
    ' list is the honest record of "we asked", and it is what keeps a
    ' sleeping server to one request for the whole visit.
    m.msGenres[pid] = kept
    msCatalogLanded(pid)
    msRefreshBusy()
end sub

sub msLoadLibraries()
    for each s in currentMediaSources()
        pid = s.provId
        if m.msViews.doesExist(pid) then continue for
        if m.inflight.doesExist("msviews_" + pid) then continue for
        task = CreateObject("roSGNode", "MediaServerTask")
        task.tag = pid
        task.url = MsViewsUrl(s.prov)
        task.headers = MsHeaders(s.prov)
        ' 20 seconds rather than the node's 30. A server on the member's own
        ' network answers this in well under a second; the long wait is only
        ' ever a box that is switched off, and every second of it is a
        ' spinner on a page that may have nothing else to show yet.
        task.timeoutMs = 20000
        task.observeField("result", "onMediaViews")
        m.inflight["msviews_" + pid] = task
        m.msPending = m.msPending + 1
        task.control = "RUN"
    end for
end sub

sub onMediaViews(event as object)
    try
        onMediaViewsInner(event)
    catch e
        GuardFailed("vod/onMediaViews", e)
    end try
end sub

sub onMediaViewsInner(event as object)
    pid = ToStr(event.getRoSGNode().tag)
    m.inflight.delete("msviews_" + pid)
    if m.msPending > 0 then m.msPending = m.msPending - 1
    res = event.getData()
    ok = false
    if res <> invalid
        if res.ok = true then ok = true
    end if
    kept = []
    if ok
        for each v in ToArray(GetField(res.data, "Items"))
            ctype = ToStr(GetField(v, "CollectionType"))
            ' Music, photos, books, box sets and the Playlists entry every
            ' Emby carries are not films — MsLibraryHoldsVideo is the one
            ' place that judgement is made, and this screen does not repeat it.
            if MsLibraryHoldsVideo(ctype)
                kept.push({ id: ToStr(GetField(v, "Id")), name: ToStr(GetField(v, "Name")), ctype: ctype })
            end if
        end for
    else
        s = msSourceById(pid)
        if s <> invalid then m.failedSrc[s.label] = true
        KLog("vod", "media server did not list its libraries: " + msErrText(res))
    end if
    ' WRITTEN EITHER WAY, answered or not. An empty list is the honest record
    ' of "we asked, and there is nothing to show", and writing it is what
    ' keeps a sleeping server to one request for the whole visit instead of
    ' one for every tab and chip the member tries afterwards.
    m.msViews[pid] = kept
    msCatalogLanded(pid)
    msRefreshBusy()
end sub

' The libraries of one server that belong on the tab being built.
'
' A library with no type at all is MIXED and is read on BOTH tabs: the server
' is asked for Movie items on one and Series items on the other, so the same
' folder legitimately appears in both strips holding different things.
function msLibrariesFor(pid as string, forMode as string) as object
    out = []
    if not m.msViews.doesExist(pid) then return out
    wantShows = (forMode = "series")
    for each v in m.msViews[pid]
        ctype = ToStr(v.ctype)
        keep = false
        if MsLibraryIsMixed(ctype)
            keep = true
        else if wantShows
            keep = MsLibraryIsShows(ctype)
        else
            keep = not MsLibraryIsShows(ctype)
        end if
        if keep then out.push(v)
    end for
    return out
end function

' The genres of one server: names only, in the order the server sorted them.
function msGenresFor(pid as string) as object
    if not m.msGenres.doesExist(pid) then return []
    return m.msGenres[pid]
end function

' WHAT ONE SERVER PUTS IN THE CATEGORY STRIP on the tab being built. The one
' place that judgement is made — genres on Movies, libraries on Series, and
' the reasoning is in the block above msLoadCatalog.
'
' Each entry carries BOTH a libId and a genre, exactly one of them filled, so
' every later step — the merge, msPushTargets, msStartFetch — reads one shape
' and never has to ask which tab it is on.
function msStripEntriesFor(pid as string, forMode as string) as object
    out = []
    if forMode = "movies"
        for each g in msGenresFor(pid)
            out.push({ name: ToStr(g.name), libId: "", genre: ToStr(g.name) })
        end for
        return out
    end if
    for each v in msLibrariesFor(pid, forMode)
        out.push({ name: ToStr(v.name), libId: ToStr(v.id), genre: "" })
    end for
    return out
end function

' The libraries All and Year sweep, merged and filtered by the SAME rules the
' strip is — so an Adult library is still dropped (certification 6.3) and one
' the member hid or locked still contributes nothing, which is the whole
' reason msTargetsFor was written to read a merged list and never the server.
'
' On Series this IS the strip, returned untouched: the strip is already the
' libraries, and building the same list twice is how two lists drift apart.
' On Movies the strip is genres, so the libraries are merged here instead —
' out of sight, feeding nothing the member can see or press.
function msBuildWideCats(forMode as string, stripCats as object) as object
    if forMode <> "movies" then return stripCats
    merged = []
    byName = {}
    for each s in currentMediaSources()
        for each v in msLibrariesFor(s.provId, forMode)
            nm = ToStr(v.name)
            if nm <> ""
                if not byName.doesExist(nm)
                    entry = { id: nm, name: nm, srcCats: [], msCats: [] }
                    byName[nm] = entry
                    merged.push(entry)
                end if
                byName[nm].msCats.push({ provId: s.provId, libId: ToStr(v.id), genre: "" })
            end if
        end for
    end for
    return ApplyCatPrefs(forMode, FilterAdultCats(merged), false)
end function

' A server's libraries or genres have arrived, so the category strip is now
' wrong.
sub msCatalogLanded(pid as string)
    ' Thrown away wholesale rather than picked over. Rebuilding a merged list
    ' is pure arithmetic over answers already in hand — m.catAggByMode still
    ' holds every Xtream reply — so this repeats not one request.
    m.catsByKey = {}
    ' The wide-view list is built by the same merge and dies with it, or All
    ' and Year would go on sweeping the libraries of a strip that no longer
    ' exists.
    m.msWideByKey = {}
    if msSourceById(pid) = invalid then return
    onScreen = false
    for each s in currentMediaSources()
        if s.provId = pid then onScreen = true
    end for
    ' Filtered to a different chip: nothing on screen changes, and the strip
    ' this server belongs on is rebuilt from scratch when it is next asked for.
    if not onScreen then return
    cat = currentCatEntry()
    if cat <> invalid then m.restoreCatId = ToStr(cat.id)
    mergeVodCategories(m.mode)
end sub

' ---- Which libraries a strip entry stands for --------------------------------

' The answer always comes out of the MERGED category list and never straight
' off the server, and that is deliberate. The merge is where an Adult library
' was dropped (certification 6.3) and where a library the member hid or locked
' was taken out — asking the server directly would walk every one of them back
' in through the All, Home and Year views, which is the exact fault the Xtream
' side spends dropCatsJson to avoid.
function msTargetsFor(cat as object) as object
    out = []
    if m.msSources.count() = 0 then return out
    cid = ToStr(cat.id)
    if cid = "__home"
        ' The Home landing is a row PER STRIP ENTRY, so its targets are the
        ' strip: on Movies that is one small fifteen-title read per genre and
        ' a page that scrolls down, which is what it is for.
        base = []
        if m.catsByKey.doesExist(catsKey()) then base = m.catsByKey[catsKey()]
        for each c in base
            msPushTargets(out, c)
        end for
    else if cid = "" or isYearId(cid)
        ' All and Year are the whole catalogue, so they sweep LIBRARIES on
        ' both tabs — see msBuildWideCats. Sweeping genres instead would ask
        ' 22 times for 500 titles and hand the same film back once per genre
        ' it is filed under, which is both a duplicate grid and roughly ten
        ' thousand tiles of texture on a budget of about 90 MB.
        wide = []
        if m.msWideByKey.doesExist(catsKey()) then wide = m.msWideByKey[catsKey()]
        for each c in wide
            msPushTargets(out, c)
        end for
    else
        msPushTargets(out, cat)
    end if
    return out
end function

' WHETHER A GENRE SWEEP OF THIS SERVER HAS TO BE CONFINED TO LIBRARIES, and
' this is the ONE place that decision is made (certification 6.3).
'
' A genre is server-wide: /Genres?genres=Action reaches into every library
' there is, so on a box where a library is being kept out — dropped as Adult,
' or hidden or locked by the member — a plain genre sweep walks its films
' straight back in under an ordinary shelf name. That is the exact fault the
' Xtream side spends dropCatsJson to avoid.
'
' THE TEST IS "DID ANYTHING GET DROPPED", and it is asked per server:
'   - every film library the server REPORTED (msLibrariesFor), against
'   - every one that SURVIVED FilterAdultCats + ApplyCatPrefs.
'
' The survivors are read back out of the list msBuildWideCats already built
' for All and Year rather than filtered a second time here, so the two can
' never come to different conclusions about what is hidden.
'
' invalid means "nothing was dropped, sweep the whole server" — one request
' per genre, which is what the ordinary member with a single Movies library
' pays and what Mason's box pays. An array means "sweep these libraries and
' no others", one request per genre PER LIBRARY, paid only by a box that
' actually has something to hide. The four-at-a-time queue is what keeps that
' worst case tolerable.
'
' A missing wide list also returns invalid. Not knowing is not the same as
' knowing something was dropped, and the strip has not been merged yet at
' that point, so there is nothing to confine the sweep to anyway.
function msGenreScopeFor(pid as string) as object
    if not m.msWideByKey.doesExist(catsKey()) then return invalid
    reported = msLibrariesFor(pid, "movies")
    survived = []
    for each c in m.msWideByKey[catsKey()]
        for each mc in ToArray(GetField(c, "msCats"))
            if ToStr(mc.provId) = pid
                keepId = ToStr(mc.libId)
                if keepId <> "" then survived.push(keepId)
            end if
        end for
    end for
    if survived.count() >= reported.count() then return invalid
    return survived
end function

sub msPushTargets(out as object, c as object)
    cid = ToStr(c.id)
    ' Home, All and Year are not libraries; skipped by ID rather than by
    ' position so another leading entry can never quietly become a target.
    if cid = "__home" then return
    if cid = "" then return
    if isYearId(cid) then return
    for each mc in ToArray(GetField(c, "msCats"))
        s = msSourceById(ToStr(mc.provId))
        if s <> invalid
            ' provId rides along so a server that turns out to be switched
            ' off can have its remaining queued reads dropped in one go
            ' rather than each waiting out its own twenty seconds.
            askGenre = ToStr(GetField(mc, "genre"))
            if askGenre = ""
                out.push({ prov: s.prov, provId: s.provId, label: s.label, libId: ToStr(mc.libId), genre: "", catName: ToStr(c.name) })
            else
                ' ONE STRIP BUTTON EITHER WAY. Expanding a genre across
                ' libraries is a fetch decision and nothing else — the member
                ' still sees one entry reading "Action", and the answers merge
                ' into its one row or grid exactly as several sources merge
                ' into one "All".
                scope = msGenreScopeFor(s.provId)
                if scope = invalid
                    out.push({ prov: s.prov, provId: s.provId, label: s.label, libId: "", genre: askGenre, catName: ToStr(c.name) })
                else
                    for each keepId in scope
                        out.push({ prov: s.prov, provId: s.provId, label: s.label, libId: keepId, genre: askGenre, catName: ToStr(c.name) })
                    end for
                end if
            end if
        end if
    end for
end sub

' ---- Items -------------------------------------------------------------------

' How many titles one library is asked for in one go.
'
' The Home landing shows fifteen a row and no more — the same cap the Xtream
' rows build uses — so fifteen is all that is asked for, and a member with
' twenty-two genres pays twenty-two SMALL requests for that page rather than
' twenty-two large ones. That is 330 titles for the whole landing, which is
' the point: the row cap, not the request count, is what keeps a genre-built
' Home off the memory budget.
'
' Everything else takes 500, and it is a CAP AND NOT A PAGE: nothing here ever
' asks for a second page, because a request per scroll is the traffic shape
' this house is banned for. 500 titles is forty-odd grid rows deep inside one
' library, further than anyone scrolls, and a bigger library is browsed by
' picking a library or a year rather than by walking All to its end. It is a
' memory ceiling as well — the tiles recycle, so what a big number actually
' costs is the catalogue itself sitting in RAM against a budget of about 90 MB
' with five out-of-memory reports behind it.
function msPageLimit(viewKind as string) as integer
    if viewKind = "rows" then return 15
    return 500
end function

' HOW MANY OF THESE READS RUN AT ONCE. Four.
'
' Every one is a MediaServerTask, and a Task node is a THREAD — the Home
' landing used to want one per library, which was six on the owner's box.
' With films browsed by genre it wants one per genre, which is twenty-two,
' and twenty-two threads asked for at the same instant is not a fan-out this
' app has ever attempted. A task that cannot be started does not complain: it
' simply never runs, and the row it was fetching stays empty for ever.
'
' So they are queued instead, four on the wire and the rest waiting, each
' finished read starting the next. Four is chosen because these go to a box
' on the member's own network at a few hundred milliseconds a read — the
' whole twenty-two drain in about two seconds — and because a sleeping server
' costs four dead sockets rather than twenty-two. It is not a request budget:
' the count of requests is unchanged, only how many are in the air.
function msMaxInFlight() as integer
    return 4
end function

sub msStartFetch(key as string, viewKind as string, targets as object)
    if targets.count() = 0 then return
    lim = msPageLimit(viewKind)
    ' The server's own vocabulary on the wire, the app's own in the rows —
    ' MsMapItem takes "movie"/"series" so that everything downstream reads
    ' the same word it reads on an Xtream title.
    kindWord = "Movie"
    mapKind = "movie"
    if m.mode = "series"
        kindWord = "Series"
        mapKind = "series"
    end if
    for each t in targets
        ' A genre is asked for by NAME, a library by id, and this test is the
        ' one place the tab's browsing rule reaches the wire.
        '
        ' A genre target carries a libId ONLY when msGenreScopeFor decided
        ' this server has something to keep out; then the sweep is confined to
        ' that one library and the genre is asked for once per surviving
        ' library. On the ordinary box the libId is empty and MsGenreItemsUrl
        ' sweeps the whole server in one request, exactly as before.
        askUrl = MsItemsUrl(t.prov, ToStr(t.libId), kindWord, 0, lim)
        flatCap = 0
        if ToStr(t.genre) <> ""
            askUrl = MsGenreItemsUrl(t.prov, ToStr(t.genre), kindWord, 0, lim, ToStr(t.libId))
            ' A GENRE SPLIT ACROSS LIBRARIES IS STILL ONE SHELF, so its grid
            ' holds the same 500 one library would have answered with — three
            ' surviving libraries must not make the member's Action grid three
            ' times as tall, or three times as much texture. The cap rides on
            ' the mapped rows (see msFoldInto) rather than on the request,
            ' because which library answers first is not ours to predict.
            ' Zero means no cap, which is every other target on this page:
            ' All is meant to be one 500 per library.
            if ToStr(t.libId) <> "" then flatCap = lim
        end if
        ' Counted as pending the moment it is QUEUED, not when it reaches the
        ' wire — m.msPending is what tells the spinner and the empty label
        ' that an answer is still coming, and a read waiting for a slot is
        ' every bit as much still coming as one already out.
        job = {
            key: key,
            viewKind: viewKind,
            prov: t.prov,
            provId: ToStr(t.provId),
            label: t.label,
            catName: t.catName,
            mapKind: mapKind,
            askUrl: askUrl,
            flatCap: flatCap
        }
        m.msQueue.push(job)
        m.msPending = m.msPending + 1
    end for
    msPumpQueue()
end sub

' Start queued reads until the four slots are full. Called on the way in and
' again every time one finishes.
sub msPumpQueue()
    while m.msActive < msMaxInFlight() and m.msQueue.count() > 0
        job = m.msQueue.shift()
        m.msSeq = m.msSeq + 1
        tag = "ms" + m.msSeq.toStr()
        ' The tag is a counter and the request's details are held here beside
        ' it, rather than packed into the tag string: a library or genre name
        ' can hold any character at all, so any separator picked to pack one
        ' would be a character some member's shelf is named after.
        m.msTaskInfo[tag] = job
        task = CreateObject("roSGNode", "MediaServerTask")
        task.tag = tag
        task.url = job.askUrl
        task.headers = MsHeaders(job.prov)
        task.timeoutMs = 20000
        task.observeField("result", "onMediaItems")
        m.inflight["msitems_" + tag] = task
        m.msActive = m.msActive + 1
        task.control = "RUN"
    end while
end sub

' A server did not answer at all, so the reads still queued for it are
' dropped rather than each waiting out its own twenty seconds. Only a real
' failure gets here — a shelf that answers with nothing in it is an answer.
sub msDropQueued(provId as string)
    if provId = "" then return
    keepJobs = []
    for each job in m.msQueue
        if ToStr(job.provId) = provId
            if m.msPending > 0 then m.msPending = m.msPending - 1
        else
            keepJobs.push(job)
        end if
    end for
    m.msQueue = keepJobs
end sub

sub onMediaItems(event as object)
    try
        onMediaItemsInner(event)
    catch e
        GuardFailed("vod/onMediaItems", e)
        ' KEEP THE QUEUE MOVING. This handler frees a slot at the top and
        ' refills it at the bottom on every path out, because a queue that
        ' stops moving is a page that never finishes filling in - so a fault
        ' in the middle has to refill it too, or the member's remaining
        ' libraries silently never load. Nested so the clean-up cannot itself
        ' become the uncaught fault.
        try
            msPumpQueue()
            msRefreshBusy()
        catch e2
            GuardFailed("vod/onMediaItems/pump", e2)
        end try
    end try
end sub

sub onMediaItemsInner(event as object)
    tag = ToStr(event.getRoSGNode().tag)
    info = m.msTaskInfo[tag]
    m.msTaskInfo.delete(tag)
    m.inflight.delete("msitems_" + tag)
    if m.msPending > 0 then m.msPending = m.msPending - 1
    ' The slot is freed here and refilled at the very bottom, on EVERY path
    ' out of this handler: a queue that stops moving is a page that never
    ' finishes filling in.
    if m.msActive > 0 then m.msActive = m.msActive - 1
    if info = invalid
        msPumpQueue()
        return
    end if
    res = event.getData()
    ok = false
    if res <> invalid
        if res.ok = true then ok = true
    end if
    rows = []
    if ok
        for each it in ToArray(GetField(res.data, "Items"))
            row = MsMapItem(info.prov, it, ToStr(info.mapKind))
            if row <> invalid
                row["catName"] = ToStr(info.catName)
                row["srcLabel"] = ToStr(info.label)
                ' Carried on the row rather than applied here: these rows can
                ' be PARKED (msHeld) and folded in long after this handler has
                ' gone, and a cap that only existed in this scope would be
                ' lost on the way. Read and dropped by msFoldInto; never
                ' written to the tile.
                row["flatCap"] = ToInt(info.flatCap)
                rows.push(row)
            end if
        end for
        onServer = ToInt(GetField(res.data, "TotalRecordCount"))
        lim = msPageLimit(ToStr(info.viewKind))
        if onServer > lim
            KLog("vod", "'" + ToStr(info.catName) + "' holds " + onServer.toStr() + " titles; showing the first " + lim.toStr() + ".")
        end if
    else
        ' SILENT ON SCREEN. A server that did not answer is named only by the
        ' ordinary empty state, and only when there is nothing else to look
        ' at — the member never sees a status code.
        m.failedSrc[ToStr(info.label)] = true
        KLog("vod", "media shelf '" + ToStr(info.catName) + "' did not list: " + msErrText(res))
        msDropQueued(ToStr(info.provId))
    end if
    if rows.count() > 0 then msFoldIn(info, rows)
    msRepaint(ToStr(info.key))
    msPumpQueue()
    msRefreshBusy()
end sub

function msErrText(res as dynamic) as string
    if res = invalid then return "no answer at all"
    return ToStr(res.error)
end function

' ---- Folding the titles into whatever the screen is showing -------------------

sub msFoldIn(info as object, rows as object)
    key = ToStr(info.key)
    if not m.contentByKey.doesExist(key)
        ' The server beat the IPTV catalogue here and there is no tree to put
        ' these in yet. Parked, and drained the moment one is built.
        held = m.msHeld[key]
        if held = invalid then held = []
        for each r in rows
            held.push(r)
        end for
        m.msHeld[key] = held
        return
    end if
    msFoldInto(key, ToStr(info.viewKind), rows)
end sub

sub msDrainHeld(key as string, viewKind as string)
    if not m.msHeld.doesExist(key) then return
    rows = m.msHeld[key]
    m.msHeld.delete(key)
    msFoldInto(key, viewKind, rows)
end sub

sub msFoldInto(key as string, viewKind as string, rows as object)
    if not m.contentByKey.doesExist(key) then return
    root = m.contentByKey[key]
    if root = invalid then return
    if viewKind = "rows"
        msFoldRows(root, rows)
    else if viewKind = "years"
        msFoldYears(root, rows)
        if key = yearKey() then msResyncYearStrip()
    else
        ' The flat grid. Home caps itself at fifteen a row and the Year tree
        ' at three hundred a year; this is the third cap and the only one that
        ' is per-request, because it exists for exactly one case — a genre
        ' whose sweep had to be split across several libraries. Everything
        ' else arrives with flatCap 0 and appends as it always has, so All
        ' still holds one full 500 per library.
        for each r in rows
            flatCap = ToInt(GetField(r, "flatCap"))
            if flatCap > 0 and root.getChildCount() >= flatCap then exit for
            msAppendRow(root, r)
        end for
    end if
end sub

' The view a cached content key belongs to, read back off the key itself —
' the same two tests showContent and loadItems make.
function msViewKindFor(key as string) as string
    if key = yearKey() then return "years"
    if key.instr(0, "|__home") > -1 then return "rows"
    return "flat"
end function

' ONE MAPPED TITLE, BUILT AS THE SAME ContentNode THE XTREAM PATH BUILDS.
'
' Field for field against VodContentTask.appendItem, and that is the point of
' the whole exercise: the poster tile, the favourite heart, the resume bar,
' the source dot and the detail screen all read these names, and not one of
' them should ever have to learn that a media server exists. Anything renamed
' here silently loses the member a heart or a progress bar on their own films.
sub msAppendRow(parent as object, r as object)
    node = parent.createChild("ContentNode")
    node.title = ToStr(r.name)
    node.id = ToStr(r.id)
    node.hdPosterUrl = PosterUrl(ToStr(r.icon))
    ' description carries the CONTAINER, exactly as it carries an Xtream
    ' film's container_extension. It is what tells the player which demuxer to
    ' use, and it matters more here than there: a media-server stream address
    ' has no file extension to read one off (see MsStreamFormat).
    node.description = ToStr(r.container)
    token = ToStr(r.src)
    ' The favourite/resume key, precomputed so a recycling poster costs one
    ' associative-array hit. Must match FavVodKeyFor byte for byte:
    ' "<kind>:<id>", prefixed "<src>:" when the source is not the KwickTV
    ' login — and a media server's token is never blank, by design, so these
    ' are always prefixed.
    favKey = ""
    if node.id <> ""
        favKey = ToStr(r.kind) + ":" + node.id
        if token <> "" then favKey = token + ":" + favKey
    end if
    ' The corner tag, on the same terms the Xtream tiles get it: only on the
    ' All view of a box with more than one source, where there is actually
    ' something to tell apart.
    srcTag = ""
    if m.multi and m.srcFilter = "" then srcTag = ShortSrcLabel(ToStr(r.srcLabel))
    ' EVERYTHING THE DETAIL PAGE NEEDS, CARRIED ON THE TILE.
    '
    ' The library read already paid for the synopsis, the year, the runtime,
    ' the lettering, the wide artwork, the score, the certificate and the
    ' genres, so the detail page must never ask the server for them a second
    ' time. Carried here they cost one field write per tile and nothing on the
    ' wire. Not carrying them is why a member's own films opened with no
    ' description, no backdrop and no ratings while every IPTV film had all
    ' three.
    '
    ' The "ms" prefix is deliberate: these names belong to the media-server
    ' path alone and cannot collide with anything the Xtream tiles set or the
    ' poster card reads. Empty string and zero are REAL answers here, not gaps
    ' — most titles in most libraries have no logo — and the detail page
    ' already knows to fall back to words when one is missing.
    node.addFields({ favKey: favKey, srcTok: token, srcLabel: srcTag, cardRound: true, msOverview: ToStr(r.overview), msYear: ToInt(r.year), msRuntime: ToInt(r.runtime), msLogo: ToStr(r.logo), msBackdrop: ToStr(r.backdrop), msRating: ToStr(r.rating), msCert: ToStr(r.cert), msGenres: ToStr(r.genres) })
end sub

' ---- Home rows ---------------------------------------------------------------

sub msFoldRows(root as object, rows as object)
    for each r in rows
        rowNode = msRowFor(root, ToStr(r.catName))
        if rowNode <> invalid
            ' The same fifteen-a-row cap the Xtream rows build uses, so a
            ' merged row cannot end up twice as long as its neighbours.
            if rowNode.getChildCount() < 15 then msAppendRow(rowNode, r)
        end if
    end for
end sub

' The Home row a library's titles belong in, created if it is not there yet
' and slotted into the SAME order the category strip is in. A row appended
' blindly at the end would leave the strip and the landing page disagreeing
' about the order of the member's own libraries — and on a box whose only
' source is a media server, those libraries are the whole of both lists.
function msRowFor(root as object, catName as string) as object
    if catName = "" then return invalid
    for j = 0 to root.getChildCount() - 1
        if ToStr(root.getChild(j).title) = catName then return root.getChild(j)
    end for
    ordinal = msCatOrdinal(catName)
    at = root.getChildCount()
    for j = 0 to root.getChildCount() - 1
        if msCatOrdinal(ToStr(root.getChild(j).title)) > ordinal
            at = j
            exit for
        end if
    end for
    rowNode = CreateObject("roSGNode", "ContentNode")
    rowNode.title = catName
    root.insertChild(rowNode, at)
    return rowNode
end function

' Where a category name sits in the merged strip. Anything not in the strip
' sorts to the end rather than to the front, so a row nobody can explain
' cannot push the member's real libraries down the page.
function msCatOrdinal(catName as string) as integer
    base = []
    if m.catsByKey.doesExist(catsKey()) then base = m.catsByKey[catsKey()]
    for i = 0 to base.count() - 1
        if ToStr(base[i].name) = catName then return i
    end for
    return 9999
end function

' ---- The Year view -----------------------------------------------------------

sub msFoldYears(root as object, rows as object)
    maxYear = CreateObject("roDateTime").GetYear() + 1
    for each r in rows
        y = ToInt(r.year)
        ' The server states the release year outright, so there is no title
        ' to read one out of the way CatalogYear has to for an IPTV panel.
        ' Next year is allowed (announced titles legitimately appear early);
        ' a title with no year at all is simply not in the Year view, which
        ' is what the Xtream side does too.
        if y >= 1900 and y <= maxYear
            rowNode = msYearRowFor(root, y.toStr())
            ' The same 300-a-year cap the Xtream year tree uses, for the same
            ' reason: a busy year in a big library is thousands of titles.
            if rowNode.getChildCount() < 300 then msAppendRow(rowNode, r)
        end if
    end for
end sub

' The row for one year, created and slotted in newest-first if this is the
' first title from it. Rows are already in descending order, so the first row
' whose year is smaller is where this one goes.
function msYearRowFor(root as object, y as string) as object
    at = root.getChildCount()
    for j = 0 to root.getChildCount() - 1
        t = ToStr(root.getChild(j).title)
        if t = y then return root.getChild(j)
        if t < y
            at = j
            exit for
        end if
    end for
    rowNode = CreateObject("roSGNode", "ContentNode")
    rowNode.title = y
    root.insertChild(rowNode, at)
    return rowNode
end function

' The year strip after new years have appeared in the tree.
'
' The entry the member is sitting on is re-found BY ID: inserting 1998 shifts
' every entry below it, and an index remembered across that lands on the year
' next door. Nothing here re-assigns the grid's content — msRepaint decides
' that, and only when the grid has nothing in it.
sub msResyncYearStrip()
    if not m.yearOpen then return
    cat = currentCatEntry()
    curId = ""
    if cat <> invalid then curId = ToStr(cat.id)
    rebuildStripCats()
    cats = currentCats()
    idx = 0
    for i = 0 to cats.count() - 1
        if ToStr(cats[i].id) = curId
            idx = i
            exit for
        end if
    end for
    m.catIdx = idx
    ' The highlight only follows when it is NOT in the strip. A member whose
    ' finger is on the strip keeps the entry they walked to; moving it under
    ' them because a server answered is the one thing focus must never do.
    if m.focusArea <> "cats" then m.catFocus = idx
    ensureCatVisible()
    buildCatStrip()
end sub

' ---- Painting ----------------------------------------------------------------

' The strip entry the member is on, and the content key it stands for. Held
' here because three of the functions above need to know whether what they
' just changed is what is actually on screen.
function currentCatEntry() as dynamic
    cats = currentCats()
    if m.catIdx < 0 or m.catIdx >= cats.count() then return invalid
    return cats[m.catIdx]
end function

function currentContentKey() as string
    cat = currentCatEntry()
    if cat = invalid then return ""
    if isYearId(ToStr(cat.id)) then return yearKey()
    return catsKey() + "|" + cat.id
end function

' What the grid should be showing for a key: the whole tree, or one year's
' row out of it.
' `cat` is dynamic and stands in as an empty entry when there is none: a
' typed `as object` parameter handed invalid is a runtime type mismatch, and
' the one caller that can have no strip entry is the media-only page in the
' second before its libraries land.
function msViewNode(key as string, cat as dynamic) as object
    root = invalid
    if m.contentByKey.doesExist(key) then root = m.contentByKey[key]
    if root = invalid then return CreateObject("roSGNode", "ContentNode")
    entry = cat
    if entry = invalid then entry = {}
    if key = yearKey() then return yearRowFor(root, entry)
    return root
end function

sub msRepaint(key as string)
    if key = "" then return
    if currentContentKey() <> key then return
    pane = contentPane()
    wasEmpty = true
    if pane.content <> invalid
        if pane.content.getChildCount() > 0 then wasEmpty = false
    end if
    if wasEmpty
        ' Nothing to lose: there is no scroll position and the highlight
        ' cannot be down here, because it takes a non-empty pane to get into.
        showContent(key, msViewNode(key, currentCatEntry()))
        return
    end if
    ' There IS something on screen, so the content node is left alone. The new
    ' tiles were appended straight onto the node the pane is already bound to,
    ' which puts them on screen without moving anything; re-assigning it would
    ' throw a member who has scrolled back to the top row.
    m.emptyLabel.visible = false
    ' The Try again button goes with the words it belongs to. This is the one
    ' path that paints an empty page into a full one without going through
    ' showContent, so the button has to be taken down here by hand - a member
    ' whose own server has just filled the page must not be left sitting on a
    ' button under a grid of films.
    xtShowRetry(key, false)
end sub

' The spinner, over both halves of the page at once.
sub msRefreshBusy()
    busy = false
    if m.catFetch <> invalid
        if m.catFetch.pending > 0 then busy = true
    end if
    for each k in m.inflight
        if Left(ToStr(k), 6) = "items_" then busy = true
    end for
    ' A view with sources still queued is a load still running, even in the
    ' instant between one source answering and the next being asked — without
    ' this the spinner blinks off and on again once per source.
    if m.xtQueue.count() > 0 then busy = true
    ' A media server still out only holds the spinner while there is nothing
    ' to look at. Once tiles are up, a server that is slow or switched off
    ' must not leave a spinner turning over a screen that already works.
    if not busy
        if m.msPending > 0
            pane = contentPane()
            if pane.content = invalid
                busy = true
            else if pane.content.getChildCount() = 0
                busy = true
            end if
        end if
    end if
    setBusy(busy)
end sub
