sub init()
    m.theme = KwickTheme()
    m.top.findNode("scrim").color = "0x000000C0"
    panel = m.top.findNode("panel")
    panel.color = m.theme.surface

    m.title = m.top.findNode("title")
    m.title.font = UiBoldFont(36)
    m.title.color = m.theme.textPrimary
    m.title.text = "Choose a playlist"

    m.crumb = m.top.findNode("crumb")
    cf = UiFont(24)
    m.crumb.font = cf
    m.crumb.color = m.theme.textSecondary

    m.emptyLabel = m.top.findNode("emptyLabel")
    m.emptyLabel.font = cf
    m.emptyLabel.color = m.theme.textSecondary

    m.hint = m.top.findNode("hint")
    m.hint.font = cf
    m.hint.color = m.theme.textSecondary
    m.hint.text = "Back goes up a folder"

    m.spinner = m.top.findNode("spinner")
    m.spinner.poster.uri = "pkg:/images/spinner.png"

    m.list = m.top.findNode("list")
    m.list.observeField("itemSelected", "onSelected")

    ' "" is the drive list; anything else is a folder inside a drive.
    m.path = ""
    m.entries = []
    load("")
end sub

sub load(path as string)
    m.path = path
    setBusy(true)
    m.list.visible = false
    m.emptyLabel.visible = false
    if path = ""
        m.crumb.text = "USB drives"
        m.hint.text = "Press Back to go back"
    else
        m.crumb.text = path
        m.hint.text = "Press Back to go up a folder"
    end if
    task = CreateObject("roSGNode", "UsbListTask")
    task.path = path
    task.observeField("result", "onListed")
    m.task = task
    task.control = "RUN"
end sub

sub onListed(event as object)
    res = event.getData()
    setBusy(false)
    m.entries = []
    if res <> invalid and res.ok = true then m.entries = ToArray(res.entries)

    if res <> invalid and res.ok <> true
        ' The usual cause is the drive being pulled out mid-browse.
        showEmpty("That folder isn't there any more. The drive may have been unplugged.")
        return
    end if

    if m.entries.count() = 0
        if m.path = ""
            ' Not an error, and on most Rokus it's the only possible answer:
            ' the sticks and the Express line have no USB port at all.
            showEmpty("No USB drive found." + Chr(10) + Chr(10) + "Plug a drive with your playlist on it into the Roku's USB port and open this again." + Chr(10) + Chr(10) + "Not every Roku has one — the sticks and the Express models don't, so on those you'll need to use a playlist address instead.")
        else
            showEmpty("Nothing here." + Chr(10) + Chr(10) + "This folder has no .m3u or .m3u8 playlists in it, and no folders to look in.")
        end if
        return
    end if

    content = CreateObject("roSGNode", "ContentNode")
    for each e in m.entries
        node = content.createChild("ContentNode")
        node.title = ToStr(e.name)
        if e.isDir = true then node.description = "Folder" else node.description = "Playlist"
    end for
    m.list.content = content
    m.list.jumpToItem = 0
    m.list.visible = true
    m.emptyLabel.visible = false
    m.list.setFocus(true)
end sub

sub showEmpty(text as string)
    m.emptyLabel.text = text
    m.emptyLabel.visible = true
    m.list.visible = false
    ' Nothing to focus in the list, so the screen keeps focus and Back works.
    m.top.setFocus(true)
end sub

sub onSelected()
    idx = m.list.itemSelected
    if idx < 0 or idx >= m.entries.count() then return
    e = m.entries[idx]
    if e.isDir = true
        load(ToStr(e.path))
    else
        m.top.chosen = ToStr(e.path)
        m.top.closed = true
    end if
end sub

sub setBusy(b as boolean)
    m.spinner.visible = b
    if b then m.spinner.control = "start" else m.spinner.control = "stop"
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back"
        if m.path = ""
            m.top.chosen = ""
            m.top.closed = true
            return true
        end if
        load(parentOf(m.path))
        return true
    end if
    return false
end function

' "ext1:/movies/uk/" -> "ext1:/movies/", and "ext1:/" -> "" (the drive list).
function parentOf(path as string) as string
    p = path
    if p.right(1) = "/" then p = p.left(p.len() - 1)
    slash = -1
    for i = 0 to p.len() - 1
        if p.mid(i, 1) = "/" then slash = i
    end for
    if slash < 0 then return ""
    ' Only the volume left ("ext1:") means we're back at the drive list.
    head = p.left(slash)
    if head.right(1) = ":" then return ""
    return head + "/"
end function
