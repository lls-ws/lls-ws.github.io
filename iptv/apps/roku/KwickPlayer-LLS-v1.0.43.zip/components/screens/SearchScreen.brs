' Search across Channels, Movies, and Series. The catalog is fetched once
' (three background requests) and cached; a query filters it by name. The
' query is entered through Roku's own standard keyboard dialog — the same
' one the sign-in form uses — so remote focus is reliable AND the member can
' hold the microphone button and simply say what they want.

sub init()
    m.theme = KwickTheme()

    ' ---- The shell theme's type, page-wide --------------------------------
    ' JetBrains Mono via Theme.brs's UiFont/UiBoldFont everywhere in this
    ' file. Mono's flat 0.6em advance is ~20% wider than Roboto-Medium's
    ' average; every label below was re-checked against its own box and the
    ' one that had to move is the search bar's own text, for the reason
    ' written there.
    header = m.top.findNode("header")
    header.text = "Search"
    header.font = UiBoldFont(42)
    header.color = m.theme.textPrimary

    m.barRing = m.top.findNode("barRing")
    m.barBg = m.top.findNode("barBg")
    m.barBg.color = m.theme.surface
    m.barRing.color = m.theme.focusHighlight
    barIcon = m.top.findNode("barIcon")
    barIcon.font = IconFont(34)
    barIcon.text = m.theme.iconSearch
    barIcon.color = m.theme.textSecondary
    m.barText = m.top.findNode("barText")
    ' 26, where this was 28. The bar's text box is 980 wide and does not
    ' wrap, and its RESTING text is the longest thing it ever holds:
    ' "Search channels, movies & series" is 32 characters, which in mono at
    ' 28 is 538px — comfortable — but a member's own query can be much
    ' longer, and at 28 mono only 58 characters fit against Roboto's 70.
    ' At 26 it is 15.6px a character and 62 fit. Nothing on this screen
    ' clips today that did not clip before; the prompt itself has 440px of
    ' slack either way.
    m.barText.font = UiFont(26)

    m.hintLabel = m.top.findNode("hintLabel")
    ' Unchanged at 26. The hint box is 1790 wide, wraps, and allows four
    ' lines: even at mono's 15.6px a character that is 114 per line and 458
    ' in total, which is far more than any message this screen writes.
    m.hintLabel.font = UiFont(26)
    m.hintLabel.color = m.theme.textSecondary

    m.spinner = m.top.findNode("spinner")
    m.spinner.poster.uri = "pkg:/images/spinner.png"

    m.results = m.top.findNode("results")
    m.results.observeField("rowItemSelected", "onResultSelected")
    m.results.rowLabelFont = UiBoldFont(26)
    m.results.rowLabelColor = m.theme.textPrimary

    m.keySink = m.top.findNode("keySink")
    ' Search sweeps EVERY source's catalogs (Android model): channels from
    ' Xtream and M3U sources alike, movies/series from each Xtream source.
    m.sources = LoadProviders()
    m.multi = (m.sources.count() > 1)
    m.query = ""
    m.focusArea = "bar"           ' "bar" | "results"
    m.kbDialog = invalid          ' the open keyboard dialog, or invalid
    m.kbEdit = invalid            ' its text box — what the microphone writes into
    m.pendingSearch = false       ' a query is waiting for the dialog to close
    m.rerunPending = false        ' a source landed while the keyboard was open
    m.channels = invalid
    m.movies = invalid
    m.series = invalid
    m.loaded = false
    m.resultRows = []             ' [{kind, items}]
    m.inflight = {}
    ' Parental rules. Search used to hold RAW catalogue rows and enforce
    ' nothing but the adult rule, so a PIN-locked film could be found by
    ' searching for it and played straight from the results with no PIN
    ' asked for — the locks were only ever enforced on the Live TV, VOD and
    ' Home screens. Now the shared gate decides, the same one the guide uses
    ' (see the parental-gate block in GuideMeta.brs).
    '
    ' Results are FILTERED, not gated: a flat result grid has nowhere
    ' sensible to put a PIN pad, and the title showing up at all is half the
    ' leak. That is the same call Kwick Picks and the Multi-View picker
    ' already make — left out entirely rather than shown and then refused.
    ' Hence strict = true everywhere below.
    '
    ' Read ONCE, at catalogue load — not per query and certainly not per
    ' row. Search is rebuilt from scratch every time it is opened (the shell
    ' destroys the screen on every navigation), so the gate is never stale by
    ' more than one visit.
    m.gate = ParentalGate("live")
    m.pidByToken = {}             ' source token -> provider id
    m.failedSrc = {}              ' source name -> couldn't be reached
    ' source name -> at least one of its catalogues was too big to hold. Kept
    ' apart from m.failedSrc because it is a different sentence to the member
    ' (the provider answered fine; this Roku could not take the answer) and
    ' apart from m.capped because it must NOT stop the remaining requests.
    m.tooBigSrc = {}
    ' Search is the only screen that holds every source's whole catalogue at
    ' once, so it is the one that runs small Rokus out of memory. Trimming
    ' the rows (v1.0.24) was not enough on its own: a Philips Roku TV still
    ' died with EXIT_OUT_OF_MEMORY on v1.0.26 with Search as the last screen
    ' opened (key B922E9), and it had crashed the same way the session
    ' before. So there is now a ceiling as well as a diet.
    '
    ' roAppMemoryMonitor reports how much of THIS app's limit is already
    ' used, which is the only number that means anything across the range of
    ' Roku hardware — a fixed row count that is safe on a Streaming Stick 4K
    ' is fatal on a 2017 TV.
    m.memMon = CreateObject("roAppMemoryMonitor")
    m.rowsHeld = 0
    m.capped = false

    m.top.observeField("focusedChild", "onFocusIn")
    redrawBar()
    ' No hint until there's something to say — the screen is empty until a
    ' search runs anyway. The catalog loads quietly in the background.
    m.hintLabel.text = ""
    fetchCatalog()
end sub

sub onFocusIn()
    if not m.top.hasFocus() then return
    ' Bar active -> the key sink holds real focus; results active -> the grid.
    if m.focusArea = "results" and m.results.visible
        m.results.setFocus(true)
    else
        m.keySink.setFocus(true)
    end if
end sub

' ---- Catalog fetch (once) ----------------------------------------------------

sub fetchCatalog()
    m.channels = []
    m.movies = []
    m.series = []
    m.fetchQueue = []
    ' THE FETCH ITSELF CAN BE FATAL. atMemoryCeiling() stops Search holding
    ' more rows, but it is checked as rows ARRIVE - by then three whole
    ' catalogues per source have already landed in memory. A Roku Streaming
    ' Stick 3800X (key 16A582, v1.0.32) opened Search at 11%, the fetch took it
    ' to 63%, the ceiling fired at 0 rows, and the box was killed anyway. So on
    ' a device that is ALREADY reporting low memory before anything is asked
    ' for, don't ask: playlist channels are in memory already and still search;
    ' the panel catalogues are skipped and the member is told. Coarse
    ' device-wide level only - silent on any box with room.
    m.memStarved = false
    lvl = LCase(ToStr(CreateObject("roDeviceInfo").GetGeneralMemoryLevel()))
    if lvl = "low" or lvl = "critical"
        m.memStarved = true
        KLog("search", "this device is already short of memory - not loading the panel catalogues; playlist channels only")
    end if
    started = 0
    for each p in m.sources
        token = SrcTokenFor(p)
        label = ToStr(p.name)
        m.pidByToken[token] = ToStr(p.id)
        if ToStr(p.ptype) = "m3u"
            ' M3U channels come from the session cache (or a fresh parse).
            slots = m.global.m3uByProv
            pid = ToStr(p.id)
            if slots.doesExist(pid)
                for each c in slots[pid].channels
                    ' Pushed by REFERENCE, and deliberately not trimmed: the
                    ' session cache holds these rows for the whole app
                    ' anyway, so a trimmed copy would only add memory.
                    ' An M3U row carries its own group name, so the adult and
                    ' lock tests are EXACT here — no id->name cache to
                    ' consult and no cold-start hole.
                    takeM3uChannel(pid, c)
                end for
            else
                started = started + 1
                task = CreateObject("roSGNode", "M3uTask")
                task.url = p.m3uUrl
                task.tag = pid
                task.observeField("result", "onM3uList")
                m.inflight["m3u_" + pid] = task
                task.control = "RUN"
            end if
        else if m.memStarved <> true
            ' Queued, not started - see startNextFetch.
            for each kind in ["live", "movies", "series"]
                started = started + 1
                m.fetchQueue.push({ kind: kind, prov: p, token: token, label: label })
            end for
        end if
    end for
    startNextFetch()
    if started = 0 then m.loaded = true
end sub

' ONE CATALOGUE IN FLIGHT AT A TIME. Search used to fire live, movies and
' series for every source all at once, so three whole raw catalogues per source
' sat in memory together before the first row ever reached atMemoryCeiling().
' The ceiling counts rows as they are KEPT; the kill comes from the raw answers
' landing. A Westinghouse 70in with an 8,000-channel panel (key 441514,
' v1.0.33) opened Search at 6% of its limit - a perfectly healthy box - and was
' killed inside twenty seconds, which the low-memory pre-check cannot catch
' because nothing was low yet. Same rule the guide chain already lives by:
' the next request is only made after the previous one has answered and been
' let go of, and the honest render-thread reading is taken in between. Live
' first (what people search for most), then movies, then series, source by
' source. If the box is tight after any one of them, the rest are skipped and
' the member gets partial results instead of a dead app.
sub startNextFetch()
    if m.fetchQueue.count() = 0 then return
    ' A panel catalogue already in flight? Let it answer first. (An M3U parse
    ' in flight is fine - that is a different, already-budgeted thing.)
    for each k in m.inflight
        if k.Left(4) <> "m3u_" then return
    end for
    if not m.capped and atMemoryCeiling()
        m.capped = true
        KLog("search", "memory ceiling reached between catalogues at " + m.rowsHeld.toStr() + " rows - results will be partial")
    end if
    if m.capped
        KLog("search", "skipping " + m.fetchQueue.count().toStr() + " remaining catalogue request(s) - no room to hold them")
        m.fetchQueue = []
        return
    end if
    job = m.fetchQueue.shift()
    kind = ToStr(job.kind)
    action = "get_live_streams"
    if kind = "movies" then action = "get_vod_streams"
    if kind = "series" then action = "get_series"
    task = CreateObject("roSGNode", "ApiTask")
    task.tag = kind + "|" + ToStr(job.token) + "|" + ToStr(job.label)
    task.url = XtreamApiUrl(job.prov, action)
    task.timeoutMs = 90000
    ' THE SIZE LIMIT ON THIS ONE ANSWER, worked out HERE and handed to the
    ' task. It has to be worked out here: this is the render thread, where
    ' roAppMemoryMonitor tells the truth about the whole app. Inside the task
    ' it would report only the task's own few percent. Re-read for every
    ' request, because the free room shrinks as each catalogue lands.
    ' See catalogueCapBytes for the arithmetic.
    task.maxBytes = catalogueCapBytes()
    task.observeField("result", "onList")
    m.inflight[kind + "_" + ToStr(job.prov.id)] = task
    task.control = "RUN"
end sub

' One playlist row, kept or dropped. Its group name is right there, so the
' adult / hidden / locked tests are exact; the hidden-channel set is loaded
' once per source inside the gate, never per row.
sub takeM3uChannel(pid as string, c as object)
    if not ParentalAllowsCat(m.gate, ToStr(GetField(c, "group")), true) then return
    if ParentalChannelHidden(m.gate, pid, ToStr(GetField(c, "streamId"))) then return
    m.channels.push(c)          ' already tagged by M3uTask
end sub

sub onList(event as object)
    res = event.getData()
    who = event.getRoSGNode()
    tag = ToStr(who.tag)
    ' The ceiling THIS request actually ran under, read back off the task
    ' rather than recomputed — by now the free memory has moved and a fresh
    ' reading would not be the number that decided anything.
    capBytesUsed = ToInt(who.maxBytes)
    parts = tag.split("|")
    if parts.count() < 3 then return
    kind = ToStr(parts[0])
    token = ToStr(parts[1])
    label = ToStr(parts[2])
    keyGuess = ""
    for each k in m.inflight
        if m.inflight[k].tag = tag then keyGuess = k
    end for
    if keyGuess <> "" then m.inflight.delete(keyGuess)
    ' Every category id this source has that the member must not see in this
    ' section: adult (cert 6.3), hidden, or PIN-locked. Built ONCE per
    ' source+scope and remembered on the gate — reading the locks per row
    ' across tens of thousands of catalogue rows is exactly the per-row
    ' registry read the audit called a visible stutter on a stick.
    ' The scope names are the same words as the kinds, which is why this can
    ' pass `kind` straight through: "live" | "movies" | "series".
    pid = ToStr(m.pidByToken[token])
    blockedIds = ParentalBlockedCatIds(m.gate, kind, pid, true)
    keptHere = 0
    if res <> invalid and res.ok = true
        ' Keep a TRIMMED copy, not the panel's row. Search holds every item
        ' from every source at once, so what it keeps per row is the whole
        ' screen's memory budget — and the raw rows carry a dozen fields
        ' nothing here ever reads (plot, cast, director, genre, added,
        ' category_id, tv_archive, rating, direct_source...). A series plot
        ' alone runs to hundreds of bytes, times tens of thousands of rows,
        ' times every source.
        '
        ' A member on a Roku Premiere crashed twice with
        ' EXIT_CHANNEL_MEM_LIMIT_FG on 2026-08-13 and 08-14, Search on
        ' screen both times (key FE748C).
        for each s in ToArray(res.data)
            ' Checked every 500 rows, not every row: GetMemoryLimitPercent is
            ' a syscall and a catalogue can run to tens of thousands.
            if m.rowsHeld mod 500 = 0
                if not m.capped and atMemoryCeiling()
                    m.capped = true
                    KLog("search", "memory ceiling reached at " + m.rowsHeld.toStr() + " rows - results will be partial")
                end if
            end if
            if m.capped then exit for
            ' Dropped before it is trimmed, so a blocked row is never held —
            ' it costs no memory and can never reach a result.
            if blockedIds.doesExist(ToStr(GetField(s, "category_id"))) then continue for
            ' A channel the member hid in Settings shouldn't come back in a
            ' search either — the Live TV screen has filtered these out of
            ' its grid since ApplyChannelPrefs, and Search never did.
            if kind = "live"
                if ParentalChannelHidden(m.gate, pid, ToStr(GetField(s, "stream_id"))) then continue for
            end if
            row = trimForSearch(s, kind, token, label)
            if row <> invalid
                m.rowsHeld = m.rowsHeld + 1
                keptHere = keptHere + 1
                if kind = "live" then m.channels.push(row)
                if kind = "movies" then m.movies.push(row)
                if kind = "series" then m.series.push(row)
            end if
        end for
        ' What this catalogue actually cost, on the record. Nobody could say
        ' how big any of these answers were when the memory kills came in, and
        ' the whole cap below is sized against a number we have been guessing
        ' at. One line per catalogue answers it for good — and it is the line
        ' that says whether the cap has room on a healthy box or is about to
        ' start refusing catalogues that were always fine.
        KLog("search", "'" + label + "' " + kind + " catalogue: " + mbWord(ToInt(GetField(res, "bytes"))) + ", kept " + keptHere.toStr() + " row(s) (limit " + mbWord(capBytesUsed) + ")")
    else if res <> invalid and ToStr(GetField(res, "error")) = "too large"
        ' The provider answered perfectly well; this Roku could not take the
        ' answer. ApiTask refused it by size before parsing it, so none of it
        ' ever reached the app's memory — which is the entire point, and the
        ' difference between this line appearing and the app being killed.
        '
        ' DELIBERATELY NOT m.capped. That flag means "stop asking for
        ' anything else", and one oversized catalogue says nothing about the
        ' next one: a source's live list can be enormous while its films are
        ' small, and a second source may be small throughout. The queue carries
        ' on and the member gets everything that does fit.
        m.tooBigSrc[label] = true
        KLog("search", "'" + label + "' " + kind + " catalogue is " + mbWord(ToInt(GetField(res, "bytes"))) + " - too large for this device, skipped (limit " + mbWord(capBytesUsed) + ")")
    else
        m.failedSrc[label] = true
    end if
    ' The next catalogue only goes out now that this one has answered and its
    ' raw rows are gone; if it starts one, inflight is non-empty and
    ' finishListIfDone correctly waits.
    startNextFetch()
    finishListIfDone()
end sub

' HOW A PANEL ROW IS TESTED, and what it cannot do. Search never loads a
' category list of its own — it asks each panel for whole catalogues — so a
' row arrives carrying a numeric category_id and no name. The names come
' from the id->name cache that LiveTvScreen / VodScreen / GuideScreen write
' whenever they fetch a source's categories, which ParentalBlockedCatIds
' reads for us.
'
' THE LIMITATION, stated plainly: a member who opens Search FIRST on a
' brand-new install has no cache yet, so on that one visit nothing is
' matched and locked or adult titles CAN appear in results. From the next
' launch, once anything has been browsed, it filters. This is not new — the
' adult filter has always worked this way, and the Multi-View picker says
' the same — but the locks now inherit it too, so it is worth knowing.
' Search has no category list of its own to fall back on, and fetching three
' more lists per source here is what put small Rokus over the memory limit
' in the first place.
'
' Playlist (M3U) rows have no such hole: they carry their own group name.
' Channel NAMES are deliberately never tested: "Adult Swim" is an ordinary
' channel.

' Is this app close enough to its memory limit that holding more catalogue
' risks the whole channel being killed? roAppMemoryMonitor measures usage
' against THIS device's limit, so one number works from a 2017 Roku TV to a
' Streaming Stick 4K, where any fixed row count would be wrong on one or the
' other.
'
' 70% leaves headroom for what comes AFTER the catalogue: the result grid,
' its posters, and whatever screen the member opens next. An OOM kill is not
' a Search problem when it happens, it is a dead app.
'
' The row backstop only catches a device whose monitor is unavailable or
' stuck reporting low usage. It is deliberately far above any real
' catalogue: the memory monitor is the control that should decide, and a
' fixed count cannot be right for both a 2017 TV and a Streaming Stick 4K.
' Measured on the office stick, this account alone holds more than 60,000
' rows across its sources and never passed 70% — an earlier 60,000 backstop
' capped that healthy device for no reason.
' ---- The size limit put on ONE catalogue answer ------------------------------
'
' WHY IT EXISTS. The one-at-a-time fetch above guards the SECOND catalogue and
' every one after it: atMemoryCeiling() is read between answers, here on the
' render thread, where the reading is honest. It cannot guard the FIRST one.
' Two members on v1.0.36 opened Search on a healthy box — an AOC 43S5195 at 5%
' of the app's limit (key 9BB92E) and a TCL 43S433 at 4% (key E1DFE0) — and
' were killed with EXIT_CHANNEL_MEM_LIMIT_FG seconds later with nothing else
' logged. Both were on a provider with tens of thousands of channels, and
' get_live_streams for one of those is a single JSON document that ApiTask
' downloaded and parsed in one go. That one answer was fatal before any check
' on this thread could run. So the answer is now refused BEFORE it is parsed,
' by size, and ApiTask does the refusing (its maxBytes field).
'
' THE ARITHMETIC, written out so the next person can argue with it.
'
'   free       100 minus GetMemoryLimitPercent(), read HERE. From a Task that
'              call reports only that thread — measured on the office stick, a
'              parse task read 14-17% while the app was really at 47-56% — so
'              the number is worked out on this thread and handed over.
'
'   1 point    is worth AT LEAST 1,048,576 bytes. This app's limit is somewhere
'              between about 100 MB and 190 MB depending on the box, and 100 MB
'              is the low end, so costing a percentage point at one megabyte
'              under-spends on a roomy box rather than over-spends on a small
'              one. Roku will not tell us the real figure and both of its
'              attempts were checked. CORRECTED 2026-10-13: the first half of
'              what stood here was wrong. GetChannelMemoryLimit() does NOT
'              return nothing — it returns an roAssociativeArray of three
'              Integers, and the old code ran it through ToStr(), which
'              answers "" for a non-scalar. Every empty "limitKB=" line in the
'              archive was our own bug, not the box. It is read properly now
'              in AppScene.logMemoryCeiling(). The second half still stands:
'              GetChannelAvailableMemory() swings by a hundred megabytes
'              between readings seconds apart and cannot carry arithmetic.
'              NOTE before anyone sizes this cap off the real ceiling: on the
'              office stick GetMemoryLimitPercent() read 4% while
'              GetChannelAvailableMemory() reported 258948 KB free of a
'              501760 KB foreground ceiling — 48% used. The percentage is not
'              a percentage of any of the three figures, so the two cannot be
'              mixed in one sum until a member log says which is which.
'
'   half       of what is free is the most one answer may cost. The other half
'              pays for the result grid and its posters, the catalogues still
'              queued behind this one, and whatever screen the member opens
'              next. An OOM kill is not a Search problem when it lands, it is a
'              dead app.
'
'   6x         is what the parse costs. This week's measurements put parsed
'              JSON at roughly 4-6x its byte size as BrightScript associative
'              arrays; 6 is the pessimistic end. The downloaded text is held
'              beside the parse until ParseJson returns, and that overlap is
'              the slack inside "half".
'
'   bytes per free point = 1,048,576 x 0.5 / 6 = 87,381, rounded DOWN to 87,000.
'
' WHAT IT COMES TO. Search never asks for a catalogue at all above 70% (the
' check in startNextFetch), so free is always at least 30 and the cap is never
' below 2.6 MB. On the office Streaming Stick 4K, which opens Search at 3% of
' its limit, free is 97 and the cap is 8.4 MB.
'
' >>> UNVERIFIED, AND IT IS THE RISK IN THIS CHANGE. Nobody has measured how
'     many bytes the KwickTV catalogue actually is, so nobody can say from a
'     desk that 8.4 MB clears it. The inference is that it does: the whole
'     Search load on the office stick moves the app from 3% to 27% for all
'     three catalogues of the account together, so no single raw answer is
'     costing anything like eight megabytes. That is inference, not a reading.
'     The accepted size of every catalogue is now logged next to the limit that
'     was in force, so the first run on the stick says outright whether this
'     bites. If it does, the fix is to raise the 87,000 — and the lesson from
'     the playlist ration and the 70% guide gate is that refusing something on
'     a healthy box is worse than not guarding it at all. <<<
function catalogueCapBytes() as integer
    ' No honest reading available. Assume a small box that is already half
    ' full rather than a roomy one that is empty.
    if m.memMon = invalid then return 4000000
    used = m.memMon.GetMemoryLimitPercent()
    if used = invalid then return 4000000
    freePct = 100 - ToInt(used)
    if freePct < 1 then freePct = 1
    if freePct > 100 then freePct = 100
    ' 350,000 PER FREE PERCENTAGE POINT, MEASURED - NOT THE 87,000 FIRST CUT.
    ' The first cut assumed parsed JSON costs 6x its bytes and refused the
    ' office stick's own catalogues on a healthy box (2026-09-16: "live
    ' catalogue is 10 MB - too large, skipped (limit 7 MB)", movies 15 MB
    ' likewise). The stick's real numbers: all three KwickTV catalogues, 31 MB
    ' of JSON together, move the app from 3% to 27% (v1.0.35 sweep), i.e. one
    ' raw megabyte costs about 0.8 of a percentage point - parsed cost is
    ' roughly 1x, not 6x. Half of the free room at that cost is 1,048,576 x
    ' 0.5 / 1.5 = 350,000 per point, keeping the pessimistic 1.5 for the
    ' smaller boxes. At the stick's 95 free points that is 33 MB, which
    ' admits every catalogue it has today; at the 30 free points the 70%
    ' ceiling guarantees, 10 MB - still enough for an ordinary provider, and
    ' the AOC (key 9BB92E) that died at 5% had no bound at all.
    return freePct * 350000
end function

' A byte count as whole megabytes, for the log. Never "0 MB" — anything under
' a megabyte is spelled out in bytes instead, so a line can't read as if
' nothing was there.
function mbWord(n as integer) as string
    if n <= 0 then return "size unknown"
    if n < 1048576 then return n.toStr() + " bytes"
    return Int(n / 1048576).toStr() + " MB"
end function

function atMemoryCeiling() as boolean
    if m.rowsHeld >= 150000 then return true
    ' The device-wide level, checked BEFORE the own-limit percent. GetMemoryLimit
    ' Percent is the app against its own ceiling; a 512MB box (Streaming Stick
    ' 3800X, key 16A582) was killed with CHANNEL_MEM_LIMIT at only ~55% of that
    ' while the OS was already reporting "low" device-wide. This is the same
    ' coarse signal guideMemoryTight() rides. It stays silent on a box with room
    ' - the office Streaming Stick 4K reads "normal" and loads the full catalogue
    ' as before - so it can only ever cut a search short on a box the OS is about
    ' to kill, never on a healthy one (the trap the 70% own-limit gate must not
    ' repeat: this adds a coarser arm, it does NOT lower the 70%).
    lvl = LCase(ToStr(CreateObject("roDeviceInfo").GetGeneralMemoryLevel()))
    if lvl = "low" or lvl = "critical" then return true
    if m.memMon = invalid then return false
    used = m.memMon.GetMemoryLimitPercent()
    if used = invalid then return false
    return ToInt(used) >= 70
end function

' Only the fields matchFor() and buildResults() actually read. Rows with no
' name can never match anything, so they are dropped outright rather than
' held for the life of the screen. Returns invalid for those.
'
' Used for the panel (Xtream) lists only. M3U rows are already retained by
' the shared session cache, so those stay references — see onM3uList.
function trimForSearch(s as object, kind as string, token as string, label as string) as object
    name = ToStr(GetField(s, "name"))
    if name = "" then return invalid
    row = {}
    row["name"] = name
    row["src"] = token
    row["srclabel"] = label
    if kind = "series"
        row["series_id"] = ToStr(GetField(s, "series_id"))
        row["cover"] = ToStr(GetField(s, "cover"))
        return row
    end if
    ' Channels arrive in two shapes: panel rows (stream_id / stream_icon)
    ' and M3U rows (streamId / logo / url). Normalise to the panel names so
    ' matchFor() finds them either way.
    id = ToStr(GetField(s, "stream_id"))
    if id = "" then id = ToStr(GetField(s, "streamId"))
    row["stream_id"] = id
    icon = ToStr(GetField(s, "stream_icon"))
    if icon = "" then icon = ToStr(GetField(s, "logo"))
    row["stream_icon"] = icon
    if kind = "movies" then row["container_extension"] = ToStr(GetField(s, "container_extension"))
    if kind = "live" then row["url"] = ToStr(GetField(s, "url"))
    return row
end function

sub onM3uList(event as object)
    res = event.getData()
    pid = ToStr(event.getRoSGNode().tag)
    m.inflight.delete("m3u_" + pid)
    if res <> invalid and res.ok = true
        chans = ToArray(res.channels)
        ' PublishM3uParse keeps these rows for the session, so pushing them
        ' by reference costs nothing — trimming would mean a second copy.
        PublishM3uParse(pid, chans, ToStr(GetField(res, "tvgUrl")))
        for each c in chans
            takeM3uChannel(pid, c)
        end for
    end if
    finishListIfDone()
end sub

' Every answer widens what a search can find, so a search already on
' screen is re-run as each source lands. NOT while the member is moving
' through the results though — swapping the rows out from under them would
' throw the cursor back to the first tile.
'
' >>> THIS GUARD IS WHY SEARCH NEEDS NO FOCUS CAPTURE/RESTORE. <<< Home
' carries one because Home's rows ARE rebuilt under the member; Search simply
' does not rebuild while focusArea = "results", so there is no highlight to
' put back. If that ever changes, the capture/restore has to come with it.
sub finishListIfDone()
    if m.inflight.count() = 0 then m.loaded = true
    if m.query = "" then return
    if m.focusArea = "results" and m.results.visible then return
    ' Nor while the keyboard is open. Rebuilding the grid ends in
    ' setFocus() on the RowList, which would pull focus out from underneath a
    ' modal dialog — and with the voice keyboard that means yanking the box
    ' away mid-sentence. Nothing is lost: the re-run happens as the dialog
    ' closes instead (onKeyboardClosed).
    if m.kbDialog <> invalid
        m.rerunPending = true
        return
    end if
    runSearch()
end sub

' ---- Keyboard entry (typed or spoken) ----------------------------------------
' Roku's StandardKeyboardDialog, exactly as the sign-in form uses it (see
' OnboardScreen.openKeyboard, which certification 4.12 put there). It is the
' platform's own voice keyboard: it brings the microphone with it, so the
' member can hold the mic button on the remote and just say the title, and it
' carries Roku's "use your phone as a keyboard" affordance for free. Nothing
' new is drawn and no image is added — the whole thing is the platform's.
'
' 4.12 does not compel this one (searching is not an email, a PIN or a
' password), so this is a parity/quality change rather than a cert fix: the
' Android app has no voice search at all.

sub openKeyboard()
    kb = CreateObject("roSGNode", "StandardKeyboardDialog")
    kb.title = "Search"
    ' Always a fresh, empty search box. Set BEFORE the text box below is
    ' touched — the same order the sign-in form uses, and that one has to
    ' survive putting a real value in, so it is the order known to work.
    kb.text = ""
    kb.buttons = ["Search", "Cancel"]
    ' What is being said, so the keyboard can pick a dictation style. A title
    ' is ordinary words, not an address or a password spelled out letter by
    ' letter, so it is heard as words. Roku's vocabulary is
    ' email / numeric / alphanumeric / generic / password and nothing else.
    kb.keyboardDomain = "generic"

    edit = kb.textEditBox
    ' Said on the box as well as on the dialog. keyboardDomain is documented
    ' as something the keyboard "may" act on, and the microphone is the whole
    ' point of this screen's dialog — not worth leaving to a "may".
    edit.voiceEnabled = true
    edit.voiceEntryType = kb.keyboardDomain
    ' Roku's boxes default to 15 characters, which would cut a spoken title
    ' off mid-sentence.
    edit.maxTextLength = 255

    m.kbDialog = kb
    m.kbEdit = edit
    m.pendingSearch = false
    kb.observeField("buttonSelected", "onKeyboardButton")
    ' Back closes the dialog without going through a button at all, so focus
    ' has to come home from here rather than from the Search branch —
    ' otherwise backing out of the keyboard leaves a screen that answers
    ' nothing. Same split as the sign-in form.
    kb.observeField("wasClosed", "onKeyboardClosed")
    m.top.getScene().dialog = kb
end sub

' What the member left in the box, typed or spoken. The dialog's own `text`
' is the documented place to read it from and is what the sign-in form reads;
' the box is consulted only when the dialog says nothing, because dictation
' lands in the box first. It can only ever widen what is read — if both are
' empty this still returns "", which is a cancel.
function keyboardText() as string
    if m.kbDialog = invalid then return ""
    t = ToStr(m.kbDialog.text)
    if t = "" and m.kbEdit <> invalid then t = ToStr(m.kbEdit.text)
    return t
end function

' Speech comes back as a SENTENCE, typing does not. Roku's dictation
' punctuates what it heard, so "star wars" can arrive as "Star Wars." and a
' plain substring test against the catalogue name "Star Wars" would then find
' nothing at all. Capitalisation needs no help — runSearch lowercases the
' query and filterList lowercases every name it tests — but the stray full
' stop does, so the ENDS of the query are stripped.
'
' Only the ends, and only the query: the middle is left exactly as spoken
' ("S.W.A.T." still matches, because the test is "contains"), and the
' catalogue rows are never touched. Normalising tens of thousands of names
' per query is the sort of per-row work that put small Rokus over the memory
' limit here in the first place.
function cleanQuery(raw as string) as string
    q = raw.trim()
    junk = ".,!?;:"
    while q.len() > 0 and junk.instr(q.right(1)) > -1
        q = q.left(q.len() - 1)
    end while
    while q.len() > 0 and junk.instr(q.left(1)) > -1
        q = q.mid(1)
    end while
    return q.trim()
end function

sub onKeyboardButton()
    kb = m.kbDialog
    if kb = invalid then return
    if kb.buttonSelected = 0
        raw = keyboardText()
        q = cleanQuery(raw)
        if q <> ""
            if q <> raw.trim() then KLog("search", "trimmed speech punctuation from query")
            m.query = q
            m.pendingSearch = true
            ' Set the bar and the hint BEFORE the dialog closes, so the frame
            ' that takes the keyboard away already has them painted; the
            ' filter itself runs once it is gone (onKeyboardClosed).
            redrawBar()
            setHint("Loading search results...")
        else
            ' Nothing to search — an empty box, or speech Roku heard as
            ' nothing but punctuation. Treated exactly like Cancel: the query
            ' is left alone, no search runs, and focus goes back where it was.
            KLog("search", "keyboard returned nothing - query unchanged")
        end if
    end if
    kb.close = true
end sub

' Every way out of the dialog lands here: Search, Cancel, and Back.
sub onKeyboardClosed()
    m.kbDialog = invalid
    m.kbEdit = invalid
    runNow = m.pendingSearch
    m.pendingSearch = false
    if runNow
        runSearch()
    else if m.rerunPending and m.query <> ""
        ' A source answered while the keyboard was up, so the search already
        ' on screen is widened now instead — the re-run finishListIfDone held
        ' back.
        runSearch()
    end if
    m.rerunPending = false
    if m.focusArea = "results" and m.results.visible
        m.results.setFocus(true)
    else
        m.keySink.setFocus(true)
    end if
end sub

' ---- Query -------------------------------------------------------------------

sub redrawBar()
    if m.query = ""
        m.barText.text = "Search channels, movies & series"
        m.barText.color = m.theme.textSecondary
    else
        m.barText.text = m.query
        m.barText.color = m.theme.textPrimary
    end if
    m.barRing.visible = (m.focusArea = "bar")
end sub

sub runSearch()
    if m.query = "" then return
    ' Only hold the screen back when there is genuinely nothing to search
    ' yet; otherwise show what the sources that answered can offer.
    if not m.loaded and m.channels.count() = 0 and m.movies.count() = 0 and m.series.count() = 0
        setHint("Loading search results...")
        return
    end if
    q = LCase(m.query)
    m.resultRows = []
    ' Anything already in hand is searchable NOW — a provider that has gone
    ' down used to keep results off the screen for its full 90-second
    ' timeout while the other sources' channels sat in memory unused.
    chans = filterList(m.channels, q, "channel")
    if chans.count() > 0 then m.resultRows.push({ kind: "channel", label: "Channels", items: chans })
    movs = filterList(m.movies, q, "movie")
    if movs.count() > 0 then m.resultRows.push({ kind: "movie", label: "Movies", items: movs })
    sers = filterList(m.series, q, "series")
    if sers.count() > 0 then m.resultRows.push({ kind: "series", label: "Series", items: sers })

    if m.resultRows.count() = 0
        m.results.visible = false
        msg = Chr(34) + m.query + Chr(34) + " — no matches."
        note = partialNote()
        if note <> "" then msg = msg + Chr(10) + Chr(10) + note
        setHint(msg)
        return
    end if
    buildResults()
end sub

' Filter one raw list by name (case-insensitive contains), capped at 40.
function filterList(raw as dynamic, q as string, kind as string) as object
    out = []
    if raw = invalid then return out
    for each s in raw
        name = ToStr(GetField(s, "name"))
        if name <> "" and LCase(name).instr(0, q) > -1
            ' Every result knows its source: routes playback/detail, and
            ' VOD tiles show the label when several sources are in play
            ' (live results stay unlabeled — Android parity).
            item = { kind: kind, name: name, src: ToStr(GetField(s, "src")), srcLabel: ToStr(GetField(s, "srclabel")) }
            if kind = "series"
                item.id = ToStr(GetField(s, "series_id"))
                item.icon = ToStr(GetField(s, "cover"))
            else if kind = "movie"
                item.id = ToStr(GetField(s, "stream_id"))
                item.icon = ToStr(GetField(s, "stream_icon"))
                item.ext = ToStr(GetField(s, "container_extension"))
            else
                ' Channels come in two shapes: panel rows (stream_id /
                ' stream_icon) and M3U rows (streamId / logo / url).
                item.id = ToStr(GetField(s, "stream_id"))
                if item.id = "" then item.id = ToStr(GetField(s, "streamId"))
                item.icon = ToStr(GetField(s, "stream_icon"))
                if item.icon = "" then item.icon = ToStr(GetField(s, "logo"))
                item.url = ToStr(GetField(s, "url"))
            end if
            out.push(item)
            if out.count() >= 40 then exit for
        end if
    end for
    return out
end function

sub buildResults()
    content = CreateObject("roSGNode", "ContentNode")
    for each row in m.resultRows
        rowNode = content.createChild("ContentNode")
        rowNode.title = row.label + "  (" + row.items.count().toStr() + ")"
        for each it in row.items
            node = rowNode.createChild("ContentNode")
            node.title = it.name
            node.hdPosterUrl = PosterUrl(ToStr(it.icon))
            ' favKey is per the ITEM's source; empty for channels, so a
            ' channel result never draws the heart. VOD results carry the
            ' source label when several sources are in play.
            tag = ""
            if m.multi and ToStr(it.kind) <> "channel" then tag = ShortSrcLabel(ToStr(it.srcLabel))
            ' srcTok rides along so the card can colour its source plate.
            ' It must be the STABLE token, never the display name - a renamed
            ' source has to keep its colour, and the same source has to look
            ' the same here as it does on the VOD chips.
            ' artFit: how PosterCard should fit this item's artwork. The
            ' card is a 2:3 poster and crops film covers to fill it, which
            ' is right for a poster and wrong for a channel - a station
            ' logo is landscape, and cropping one to portrait leaves a
            ' sliver of its middle. Channels ask for the whole logo, sat on
            ' the card's surface plate, which is exactly how Live TV draws
            ' them and the part of this app the member says already looks
            ' right. Written on EVERY node, not only on channels, because
            ' the card is recycled and reads it back both ways.
            fit = "cover"
            if ToStr(it.kind) = "channel" then fit = "fit"
            node.addFields({ favKey: FavVodKeyFor(ToStr(it.kind), ToStr(it.id), ToStr(it.src)), srcLabel: tag, srcTok: ToStr(it.src), artFit: fit })
        end for
    end for
    m.results.content = content
    m.results.visible = true
    ' Say it even when there ARE results. Results that look complete but
    ' silently aren't are worse than none: the member searches a film they
    ' own, sees a few unrelated hits, and concludes the app can't find it.
    ' A note shown WITH results can't float over them — the grid runs to the
    ' bottom of the screen, so there is no free space down there. Put it
    ' directly under the search bar and start the rows lower instead, which
    ' also reads better: the caveat comes before what it qualifies.
    note = partialNote()
    m.hintLabel.text = note
    if note <> ""
        m.hintLabel.translation = [60, 214]
        m.results.translation = [60, 300]
    else
        m.hintLabel.translation = [60, 260]
        m.results.translation = [60, 220]
    end if
    m.focusArea = "results"
    redrawBar()
    m.results.setFocus(true)
end sub

' Why these results may be short: a source that didn't answer, or a
' catalogue this Roku ran out of room to hold. Empty when neither applies.
function partialNote() as string
    note = unreachableNote()
    ' AT MOST ONE "no room" sentence, and this is why. There are now two ways
    ' the results can be short for memory — the app filled up part way through
    ' (m.capped) and a single catalogue was too big to take at all
    ' (m.tooBigSrc) — and to the member they are the same news twice. They also
    ' cost a line each: buildResults leaves 86px between the note and the top
    ' of the rows, which is two lines at font 26, and the unreachable note
    ' above may already have taken one of them. So the broader message wins
    ' and the narrower one is left to the log.
    roomMsg = ""
    if m.capped
        roomMsg = "This Roku ran short of memory before the whole catalogue was loaded, so not everything could be searched."
    else
        bigNames = []
        for each n in m.tooBigSrc
            bigNames.push(n)
        end for
        if bigNames.count() = 1
            roomMsg = bigNames[0] + " is too big for this Roku to search all of, so some of it isn't included."
        else if bigNames.count() > 1
            roomMsg = bigNames.count().toStr() + " of your sources are too big for this Roku to search all of, so some of them aren't included."
        end if
    end if
    if roomMsg <> ""
        if note = "" then note = roomMsg else note = note + Chr(10) + roomMsg
    end if
    return note
end function

' "no matches" and "your provider is down" look identical on screen
' unless one of them says so.
function unreachableNote() as string
    names = []
    for each n in m.failedSrc
        names.push(n)
    end for
    if names.count() = 0 then return ""
    if m.inflight.count() > 0 then return "Still checking your other sources..."
    if names.count() = 1 then return "Couldn't reach " + names[0] + ", so its channels and titles aren't included."
    return "Couldn't reach " + names.count().toStr() + " of your sources, so their channels and titles aren't included."
end function

sub setHint(text as string)
    m.hintLabel.text = text
    m.hintLabel.translation = [60, 260]
    m.results.visible = false
end sub

' ---- Result selection --------------------------------------------------------

sub onResultSelected()
    sel = m.results.rowItemSelected
    if sel = invalid or sel.count() < 2 then return
    row = m.resultRows[sel[0]]
    it = row.items[sel[1]]
    scene = m.top.getScene()
    ' Everything routes by the result's OWN source.
    srcTok = ToStr(GetField(it, "src"))
    if it.kind = "channel"
        ' THE `if url = ""` ON THE LINE AFTER NEXT IS A PRE-CHECK OF THE
        ' PLAYLIST'S OWN ADDRESS, not a guard on the panel builder: an M3U
        ' result carries its own url, and only a result that has none falls
        ' through to the panel. The guard on the BUILDER's answer is the
        ' second one, further down.
        url = LivePlayUrl(ToStr(GetField(it, "url")))    ' M3U results carry theirs
        if url = ""
            p = ProviderForSrcToken(srcTok)
            ' The fallback to the active source stays — a result whose own
            ' source has been removed should still try what is there rather
            ' than dead-end — but it is now gated on the kind.
            '
            ' ONLY A PANEL CAN HAVE A STREAM ADDRESS BUILT HERE, and this is a
            ' POSITIVE test for the two kinds that can rather than a list of the kinds
            ' that cannot. A plain playlist has no server field at all, so Util.brs
            ' answers "" — but a member's own Jellyfin HAS a server, a username and a
            ' password, so the panel builder would hand back a real-looking address
            ' that is simply wrong, and the member would read a decoder error about
            ' something that is perfectly fine.
            if p = invalid then p = ActiveProvider()
            pt = ""
            if p <> invalid then pt = LCase(ToStr(p.ptype))
            if pt = "xtream" or pt = "kwicktv" then url = XtreamLiveUrl(p, it.id)
        end if
        ' LOG KEY FCF117 — Hisense 6Series-58, v1.0.39, 29 September 2026. What
        ' happened on the member's television, in plain words: they removed their
        ' source in Settings, a different one came back from the website on its own
        ' three seconds later, and the first thing they pressed was a leftover from
        ' the source they had just taken out. The app had nothing left to match it
        ' against, so it reached for the source that had just arrived — an
        ' ordinary playlist, which has no panel address to build a stream from —
        ' and the television froze with the spinner still turning and nothing on
        ' screen to say why. Util.brs now answers "" there instead of stopping the
        ' app; this is the half that tells the member something. Without it the
        ' press is simply dead: the player bails on an empty address before the
        ' Video node is ever handed anything to fail on, so no error and no retry
        ' ever happens, and the member is left watching a spinner turn forever.
        '
        ' Checked BEFORE PushRecentChannel: a press that cannot become
        ' playback must not leave a trace of a channel the member never
        ' watched.
        if url = ""
            KLog("search", "FCF117: refused play — no source on this box can open [" + ToStr(it.name) + "]")
            srchCannotPlayNote()
            return
        end if
        ch = { streamId: it.id, name: it.name, logo: it.icon, url: ToStr(GetField(it, "url")), src: srcTok }
        PushRecentChannel(ch)
        m.player = scene.createChild("PlayerScreen")
        m.player.titleText = it.name
        m.player.channel = ch
        m.player.streamUrl = url
        m.player.streamFormat = StreamFormatFor(url, "")
        m.player.isLive = true
        m.player.observeField("closed", "onPlayerClosed")
        m.player.setFocus(true)
        m.player.start = true
    else if it.kind = "movie"
        m.detail = scene.createChild("MovieDetailScreen")
        m.detail.item = { kind: "movie", streamId: it.id, name: it.name, icon: it.icon, ext: it.ext, src: srcTok }
        m.detail.observeField("closed", "onDetailClosed")
        m.detail.setFocus(true)
    else
        m.detail = scene.createChild("SeriesDetailScreen")
        m.detail.item = { kind: "series", seriesId: it.id, name: it.name, icon: it.icon, src: srcTok }
        m.detail.observeField("closed", "onDetailClosed")
        m.detail.setFocus(true)
    end if
end sub

sub onPlayerClosed()
    if m.player <> invalid
        m.top.getScene().removeChild(m.player)
        m.player = invalid
    end if
    m.results.setFocus(true)
end sub

sub onDetailClosed()
    if m.detail <> invalid
        m.top.getScene().removeChild(m.detail)
        m.detail = invalid
    end if
    m.results.setFocus(true)
end sub

' "Can't Play This Right Now", in the shape ChannelDetailScreen, the film page
' and the series page all already use — one Dialog, one OK button, focus handed
' back to where the member was standing. Written out again here rather than
' shared, because a component only ever sees the scripts its own XML names and
' those three live in their own screens' files.
'
' LOG KEY FCF117: before this, the member's press did nothing whatsoever. The
' guard in Util.brs stops the app dying, but on its own it turns a crash into a
' button that silently does nothing — the television just sits there with the
' spinner turning. This is the part that says something.
'
' THE WORDING names no cause it cannot be sure of. The commonest reason is a
' channel left behind by a removed source, but the same dead end is reached by
' a playlist row that carries no address, so it says "probably" and offers the
' one thing the member can actually do about it. Word for word the same
' sentence as the channel page, so the two never drift apart.
sub srchCannotPlayNote()
    note = CreateObject("roSGNode", "Dialog")
    note.title = "Can't Play This Right Now"
    note.message = "Kwick Player has no working source for this channel. It was probably left behind by a source you removed. Check your sources under Settings, or pick another channel."
    note.buttons = ["OK"]
    note.observeField("buttonSelected", "onSrchCannotPlayNote")
    m.top.getScene().dialog = note
end sub

' Focus goes back to the RESULTS ROW, not to the screen: the member was
' standing on a result when they pressed OK, and that is where they must still
' be standing when the note clears. m.focusArea is set with it — this screen
' reads that field to decide where Up and Down go, and a note that left it
' saying something else would send the next press somewhere the member did not
' ask for.
sub onSrchCannotPlayNote()
    m.top.getScene().dialog.close = true
    m.focusArea = "results"
    m.results.setFocus(true)
end sub

' ---- Keys --------------------------------------------------------------------

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false

    if m.focusArea = "bar"
        if key = "OK"
            openKeyboard()
            return true
        else if key = "down"
            if m.results.visible
                m.focusArea = "results"
                redrawBar()
                m.results.setFocus(true)
            end if
            return true
        else if key = "back"
            ' Back does NOT raise backToNav any more (certification 4.6, and the
            ' owner's "i should be able to back button all the way to home"). It
            ' returns FALSE so the key bubbles to AppShell.onKeyEvent, which walks
            ' one screen out toward Home and raises the exit confirmation once it
            ' gets there. LEFT is unchanged and still parks on the rail - it is a
            ' direction, not an exit.
            '
            ' The false is returned EXPLICITLY rather than by falling out of the
            ' branch, because the fall-through at the end of this handler can be
            ' `return true`, which would eat it and leave Back doing nothing at
            ' all - a dead button with no error to find.
            return false
        else if key = "left"
            m.top.backToNav = true
            return true
        end if
        return false
    end if

    ' Results focused.
    if key = "up"
        focusedRow = m.results.rowItemFocused
        if focusedRow <> invalid and focusedRow.count() > 0 and focusedRow[0] = 0
            m.focusArea = "bar"
            m.keySink.setFocus(true)
            redrawBar()
            return true
        end if
        return false
    else if key = "back"
        m.focusArea = "bar"
        m.keySink.setFocus(true)
        redrawBar()
        return true
    else if key = "left"
        focusedRow = m.results.rowItemFocused
        if focusedRow <> invalid and focusedRow.count() > 1 and focusedRow[1] = 0
            m.top.backToNav = true
            return true
        end if
        return false
    end if
    return false
end function
