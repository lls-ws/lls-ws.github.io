' Add to List overlay. Rows: each list (ticked if the item is in it), then
' "+ Create new list" (opens the keyboard). OK toggles membership instantly.

sub init()
    m.theme = KwickTheme()
    m.top.findNode("panel").color = m.theme.surfaceElevated

    m.title = m.top.findNode("title")
    ' "Add to List" is 11 chars = 224px at 34 mono, in a 680px box.
    m.title.font = UiBoldFont(34)
    m.title.color = m.theme.textPrimary
    m.title.text = "Add to List"

    m.itemName = m.top.findNode("itemName")
    ' 24 -> 22. This is the movie, series or channel title the member is
    ' filing, so it is the longest string on the overlay, and the box is
    ' 680 wide with no wrap: mono at 24 is 14.4px a character and fits 47,
    ' at 22 it is 13.2px and fits 51. Roboto at 24 fitted about 57. Long
    ' film titles WILL still cut sooner than they did — the panel has only
    ' 20px of slack either side, so there is no widening to be had here.
    m.itemName.font = UiFont(22)
    m.itemName.color = m.theme.textSecondary

    m.list = m.top.findNode("list")
    ' No m.list.wrap here: ArrayGrid has no such field and assigning one
    ' only logs a device warning. vertFocusAnimationStyle="floatingFocus" in
    ' the XML is what actually stops the wraparound.
    m.list.observeField("itemSelected", "onSelected")

    m.top.observeField("focusedChild", "onFocusIn")
    m.top.observeField("item", "onItem")
end sub

sub onFocusIn()
    if m.top.hasFocus() then m.list.setFocus(true)
end sub

sub onItem()
    if m.top.item = invalid then return
    m.itemName.text = ToStr(m.top.item.name)
    refresh()
end sub

sub refresh()
    m.lists = LoadLists()
    m.rows = []
    content = CreateObject("roSGNode", "ContentNode")
    for each l in m.lists
        node = content.createChild("ContentNode")
        node.title = ToStr(l.name)
        inIt = IsInList(l.id, ToStr(m.top.item.kind), ToStr(m.top.item.id))
        if inIt then node.description = "Added" else node.description = ""
        m.rows.push({ kind: "list", id: l.id })
    end for
    newNode = content.createChild("ContentNode")
    newNode.title = "+ Create new list"
    newNode.description = ""
    m.rows.push({ kind: "new" })
    m.list.content = content
end sub

sub onSelected()
    idx = m.list.itemSelected
    if idx < 0 or idx >= m.rows.count() then return
    r = m.rows[idx]
    if r.kind = "new"
        openKeyboard()
    else
        ToggleItemInList(r.id, m.top.item)
        refresh()
        m.list.jumpToItem = idx
    end if
end sub

sub openKeyboard()
    kb = CreateObject("roSGNode", "StandardKeyboardDialog")
    kb.title = "New list name"
    kb.text = ""
    kb.buttons = ["Create", "Cancel"]
    kb.keyboardDomain = "generic"
    edit = kb.textEditBox
    edit.voiceEnabled = true
    edit.voiceEntryType = kb.keyboardDomain
    edit.maxTextLength = 255
    kb.observeField("buttonSelected", "onKeyboardDone")
    m.top.getScene().dialog = kb
end sub

sub onKeyboardDone()
    kb = m.top.getScene().dialog
    name = StdKeyboardText(kb)
    if kb.buttonSelected = 0 and name <> ""
        newId = CreateList(name)
        ToggleItemInList(newId, m.top.item)  ' add the item to the new list
    end if
    kb.close = true
    refresh()
    m.list.setFocus(true)
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back"
        ' Back from partway down jumps to the top; Back at the top exits.
        if m.list.itemFocused > 0
            m.list.jumpToItem = 0
            return true
        end if
        m.top.closed = true
        return true
    end if
    return false
end function
