' Home — the Media Bar across the top, then dynamically stacked rows of
' whatever has content: Continue Watching, Recently Watched Channels,
' Favorite Channels, Favorite Movies & Series, each Favorite List with its Home
' row enabled, then the member's Trakt and Simkl watchlists. Channels play;
' movies/series open their detail page.
'
' Two settings fold pairs of those rows together — Recently Watched into one
' row, Favorites into one row — under the phone's own switches, so a member
' who folds them on either device finds them folded on both. See the two
' blocks marked GAP G9 and GAP G10 in refresh().
'
' THE MEDIA BAR IS BUILT FROM WHAT THIS BOX ALREADY HOLDS AND NOTHING ELSE.
' The phone's panel looks a title's backdrop, logo, certificate and genres
' up as it draws each one; here that would be one request per tile on every
' Home rebuild, and that exact loop is what got this house's address banned
' by the provider on 2026-08-14, with the provider refusing to whitelist it
' (see the comments at the top of the Android home_screen.dart and
' continue_watching_spotlight.dart). So the panel shows the poster this app
' already saved with the title, the title's own name, and the progress it
' already knows. Nothing here asks a panel anything.
'
' The one request in this file happens on a PRESS, never on a render: when
' the member picks Resume on a show, its episode listing is fetched once to
' find the file extension and, on a finished episode, the one after it.
' That is the same single request opening the show's page already makes.

sub init()
    m.theme = KwickTheme()

    ' ---- The shell theme's type, page-wide --------------------------------
    ' Every Font built in this file is now JetBrains Mono via Theme.brs's
    ' UiFont/UiBoldFont. Mono's advance is a flat 0.6em where Roboto-Medium
    ' averaged about 0.5em, so each label below was re-checked against its own
    ' box; the one that had to move is profileName, and the reason is written
    ' there. The header and the empty line are auto-width Labels with nothing
    ' beside them, so they cannot clip.
    header = m.top.findNode("header")
    header.text = "Home"
    header.font = UiBoldFont(42)
    header.color = m.theme.textPrimary

    ' Profile button (H7) — see the section further down.
    m.keySink = m.top.findNode("keySink")
    m.profileRing = m.top.findNode("profileRing")
    m.profileFace = m.top.findNode("profileFace")
    m.profileInitial = m.top.findNode("profileInitial")
    m.profileAvatar = m.top.findNode("profileAvatar")
    m.profileName = m.top.findNode("profileName")
    m.profileRing.color = m.theme.focusHighlight
    m.profileInitial.font = UiBoldFont(34)
    ' The initial's COLOUR is not set here any more — it depends on which of
    ' the six avatar colours is behind it, so it moved into
    ' renderProfileButton() beside the square it has to sit on. Three of those
    ' six are light enough that white on them was under 2:1; see ProfileInkAt()
    ' in Theme.brs for the measurements and the rule.
    ' 22, where this was 24. The name sits in a 250px box, right-aligned,
    ' maxLines 1, so it truncates rather than wraps: mono at 24 is 14.4px a
    ' character and fits 17, at 22 it is 13.2px and fits 18. Roboto at 24
    ' fitted about 20. A member with a long profile name loses a couple of
    ' characters off the front of the right-aligned box — UNVERIFIED on the
    ' television, and the avatar beside it carries the same identity anyway.
    m.profileName.font = UiBoldFont(22)
    m.profileName.maxLines = 1
    ' False until a profile is actually known — see renderProfileButton().
    m.hasProfileButton = false

    m.emptyLabel = m.top.findNode("emptyLabel")
    m.emptyLabel.font = UiFont(26)
    m.emptyLabel.color = m.theme.textSecondary

    m.rowsContainer = m.top.findNode("rowsContainer")
    ' ---- Row headings, as shell prompts ------------------------------------
    ' JetBrains Mono, and TWO fonts because a prompt is two weights: the
    ' arrow and the path are the loud half, the command is the quiet one.
    ' Both built once here and shared by every row - a Font node per row per
    ' rebuild would be pure waste on a page that rebuilds whenever a sync
    ' lands. See ShellPrompt() in Theme.brs for the format and the map.
    '
    ' 26 rather than the 28 this was: mono's flat 0.6em advance makes the
    ' whole line ~20% longer than Roboto did, and the longest heading here
    ' ("❯ ~/recent/channels ls", 22 characters) is 343px at 26 against a
    ' 1690px row, so there is room either way - 26 is chosen so a very long
    ' member-named list ("❯ ~/lists/<slug> cat") still sits clear of the
    ' right-hand margin.
    m.titleFont = UiBoldFont(26)
    m.titleCmdFont = UiFont(26)

    m.scroller = m.top.findNode("scroller")
    m.barHost = m.top.findNode("barHost")
    m.bar = invalid           ' the MediaBar node, once there's anything in it
    m.barEntries = []
    m.barCountLogged = -1
    m.rowsTop = 130           ' 470 while the Media Bar is up

    m.provider = ActiveProvider()
    m.player = invalid
    m.detail = invalid
    m.enrichStarted = false
    m.rowDefs = []       ' [{ title, items:[normalized], rid }]
    m.rowGrids = []      ' row nodes (RowList or MarkupGrid), aligned with rowDefs
    ' Index-aligned with m.rowGrids and describing the nodes that are UP
    ' RIGHT NOW, which is not the same thing as m.rowDefs: refresh() replaces
    ' rowDefs before buildRows() pulls the old nodes down, so the teardown
    ' needs its own record of what it is tearing down. See captureRowFocus().
    m.rowTitles = []     ' the row title each live node was built from
    m.rowIsList = []     ' true = RowList (posters), false = MarkupGrid (channels)
    ' Where each row's TITLE line sits and how tall the whole row is (title
    ' line + cards). Rows are no longer all the same height — see the block
    ' above buildRows() — so the two places that used to multiply by a fixed
    ' 310 read these instead. Built once per buildRows(), never on a keypress.
    m.rowTops = []
    m.rowHeights = []
    m.rowShapeLogged = ""
    m.rowIndex = 0
    ' ---- WHERE THE MEMBER WAS STANDING, kept across a rebuild ---------------
    '
    ' >>> THIS IS THE FIX FOR "sometimes it snaps back to the first option in
    '     the row". <<<
    '
    ' buildRows() throws every row node away and makes new ones, and a brand
    ' new ArrayGrid always starts on item 0. m.rowIndex was already carried
    ' across that (onReloadFromSync, onFocusIn, onPicksResult all restore it)
    ' but the COLUMN never was — it was not held anywhere in this file. So the
    ' row survived a rebuild and the position inside the row did not.
    '
    ' Rebuilds happen on the 90-second sync heartbeat (AppShell.brs:62 ->
    ' onSyncTick -> onBgSyncResult -> reloadFromSync), when the enrich task
    ' answers, when Kwick Picks answers, and every time a detail screen or the
    ' player closes. One landing between the arrow press and the OK press is
    ' exactly the intermittent report.
    '
    ' Keyed by ROW TITLE, not by row index, because a rebuild can legitimately
    ' change how many rows there are and what order they come in: a sync can
    ' add or drop a Favorite List, Kwick Picks appends a row late, and the two
    ' merge switches fold two rows into one. A title follows its row wherever
    ' it moves.
    m.rowCols = {}       ' row title -> the column the member last stood on
    m.focusRowTitle = "" ' the row title focus was on when we last tore down
    ' "profile" | "bar" | "rows". Home opens on the panel when there is one,
    ' the way the phone autofocuses it as the first thing in the column —
    ' the profile button sits above it and is never the opening stop.
    m.focusZone = "bar"
    m.resumeTask = invalid
    m.pendingResume = invalid
    m.resumeProv = invalid
    ' The finished marks for this page build — see seenMarks(). invalid means
    ' "not read yet"; refresh() puts it back to invalid every time so a mark
    ' written while the member was off watching something is picked up.
    m.seenCache = invalid

    m.top.observeField("focusedChild", "onFocusIn")
    m.top.observeField("reloadFromSync", "onReloadFromSync")
    refresh()
end sub

' A background sync applied remote changes — rebuild the rows so new
' favorites/lists show up. Keep the current row focused if we had focus.
' ---- Guarded handlers (v1.0.41) ---------------------------------------------
'
' Every entry point the render thread can call on this screen now runs under
' try/catch and reports through GuardFailed (Util.brs), the same way the TV
' Guide and the channel page already do: one log line naming the file, the
' line and the function, plus an armed next-launch crash report, instead of
' the app dying with no stack at all.
'
' WHY HOME, IN PLAIN WORDS. Two members' televisions died on this screen on
' v1.0.40 and neither report could say where, because nothing in this file was
' guarded:
'
'   EB3CEB  an ATVIO 40-inch set. The app stopped dead while Home was on
'           screen, just after the Media Bar had failed to download a title's
'           artwork for the third time in forty seconds. That panel's own
'           handlers are guarded now too (MediaBar.brs).
'   373E65  a Pioneer PN70. The app died during startup, between the line the
'           shell prints when it comes up and the line Roku's launch beacon
'           prints when Home has finished drawing. See the note below.
'
' 373E65 IS PROBABLY NOT IN THIS FILE, and that is worth writing down so
' nobody chases it here. By the time the shell prints its "up" line, this
' screen's init() and refresh() have already finished - the shell creates the
' screen first and prints afterwards. Nothing in this file runs again until
' the next log line, because the only things that could (a focus change, a
' task answering) are delivered after the launch call chain returns, and
' refresh() sets focus on nothing. So the fault sits in the small run of
' synchronous code between those two lines, which belongs to AppShell and
' AppScene, not here. The guards below cover this screen either way; the
' remaining window is for whoever owns those two files.
'
' GuardFailed IS REACHABLE HERE because HomeScreen.xml names
' pkg:/source/utils/Util.brs (HomeScreen.xml:23). A component only sees the
' scripts its own XML names, and that line is what makes these calls legal.
'
' init() IS DELIBERATELY NOT GUARDED - a fault there leaves a screen with half
' its fields missing, and guarding it would turn one honest crash into every
' handler below faulting for the rest of the session.
sub onReloadFromSync()
    try
        onReloadFromSyncInner()
    catch e
        GuardFailed("home/onReloadFromSync", e)
    end try
end sub

sub onReloadFromSyncInner()
    ' A sync can bring in NEW art-less favorites — allow another enrich pass.
    m.enrichStarted = false
    refreshKeepingHomeFocus()
end sub

' EVERY rebuild of Home's rows must go through here, because refresh() destroys
' whatever grid had focus and does NOT hand it back. Capture where focus was,
' rebuild, then restore it. onEnrichDone used to call refresh() directly with no
' restore, which was the v1.0.32 "highlight disappears after a few seconds"
' report: the enrich task back-fills art-less favorites a few seconds into a
' session, refresh() tore the focused grid down, and focus was left on a
' destroyed node — the member could hear key sounds but nothing responded until
' Home. Route the sync rebuild through the same path so the two can never drift.
sub refreshKeepingHomeFocus()
    ' The Media Bar is re-used rather than rebuilt (see buildMediaBar), so a
    ' rebuild landing while somebody is standing in it neither steals focus nor
    ' snaps it back to the first title.
    barHadFocus = (m.bar <> invalid and m.bar.isInFocusChain())
    profileHadFocus = (m.focusZone = "profile" and m.keySink.hasFocus())
    hadFocus = false
    for each g in m.rowGrids
        if g.hasFocus() then hadFocus = true
    end for
    refresh()
    if profileHadFocus
        ' The button and its focus holder both live in the XML and survive
        ' the rebuild, so ordinarily there is nothing to do and the member
        ' does not feel the sync at all. The only case that needs a hand is
        ' the profile going away underneath them (deleted on another device
        ' while it was the active one) — renderProfileButton has already
        ' moved the zone off "profile", so put focus somewhere real.
        if m.hasProfileButton
            applyProfileFocus(true)
            return
        end if
        m.focusZone = "rows"
        m.top.setFocus(true)
        onFocusIn()
        return
    end if
    if barHadFocus
        if m.bar <> invalid
            m.focusZone = "bar"
            m.bar.setFocus(true)
            return
        end if
        ' The panel went away under them (the last thing in it finished, or
        ' the switch came across turned off). Don't leave focus nowhere.
        m.focusZone = "rows"
        if m.rowGrids.count() > 0
            m.rowIndex = 0
            m.rowGrids[0].setFocus(true)
            scrollToRow(0)
        end if
        return
    end if
    if hadFocus and m.rowGrids.count() > 0
        if m.rowIndex >= m.rowGrids.count() then m.rowIndex = m.rowGrids.count() - 1
        m.rowGrids[m.rowIndex].setFocus(true)
        scrollToRow(m.rowIndex)
    end if
end sub

sub onFocusIn()
    try
        onFocusInInner()
    catch e
        GuardFailed("home/onFocusIn", e)
        ' LOGGED AND NOTHING ELSE, on purpose. This is the focusedChild
        ' observer, so moving focus from in here fires it again - a handler
        ' that faults every time would then recurse until the stack gave out,
        ' which is a worse crash than the one being guarded. Leaving it alone
        ' is safe: every route into here either already holds focus on this
        ' screen's own node or is handing it over from somewhere that does, so
        ' onKeyEvent still fires and Back and Left still get the member out.
    end try
end sub

sub onFocusInInner()
    if not m.top.isInFocusChain()
        ' Focus has left Home altogether — the rail, a detail page, the
        ' picker overlay. Drop the profile button's ring so the screen isn't
        ' left showing a focus ring for a screen nobody is on; the row cards
        ' fade their own the same way.
        applyProfileFocus(false)
        return
    end if
    if not m.top.hasFocus() then return
    ' Focus has come back to Home from somewhere else — the rail, a detail
    ' page, a cancelled "Who's watching?". The profile may have been renamed
    ' or given a new avatar while they were away (both live in the picker's
    ' editor), so re-read the button. One registry read on a key press a
    ' member makes a few times a minute, and it saves a full rebuild.
    renderProfileButton()
    if m.focusZone = "profile" and m.hasProfileButton
        m.scroller.translation = [0, 0]
        m.keySink.setFocus(true)
        applyProfileFocus(true)
        return
    end if
    if m.focusZone = "bar" and m.bar <> invalid
        m.scroller.translation = [0, 0]
        m.bar.setFocus(true)
        return
    end if
    if m.rowGrids.count() > 0
        m.focusZone = "rows"
        if m.rowIndex >= m.rowGrids.count() then m.rowIndex = 0
        m.rowGrids[m.rowIndex].setFocus(true)
        scrollToRow(m.rowIndex)
    else if m.bar <> invalid
        m.focusZone = "bar"
        m.scroller.translation = [0, 0]
        m.bar.setFocus(true)
    end if
end sub

' Keep the focused row on screen — the Media Bar and the rows slide up and
' down together, so rows beyond the first screenful (e.g. Kwick Picks) are
' reachable and the panel scrolls away instead of sitting over them.
'
' It used to work the row's box out with `m.rowsTop + i * 310`, which was only
' ever right while every row was the same 206-tall tile. A poster row is 348
' tall, so the box is now LOOKED UP rather than multiplied — m.rowTops and
' m.rowHeights are laid down by buildRows() and are the single answer to
' "where is row i". Two array reads on an arrow press; nothing is measured,
' nothing is rebuilt (certification 3.5, 250ms).
sub scrollToRow(i as integer)
    if i < 0 or i >= m.rowTops.count() then return
    rowTop = m.rowTops[i]
    rowBottom = rowTop + m.rowHeights[i]
    off = m.scroller.translation[1]
    topV = rowTop + off
    bottomV = rowBottom + off
    if bottomV > 1060
        off = off - (bottomV - 1060)
    else if topV < 130
        off = off + (130 - topV)
    end if
    if off > 0 then off = 0
    m.scroller.translation = [m.scroller.translation[0], off]
end sub

' Normalize any saved item into { kind, id, name, icon, ext, url, src } —
' src rides along so opening/playing routes to the item's own source.
function normChannel(c as object) as object
    return { kind: "channel", id: ToStr(c.streamId), name: ToStr(c.name), icon: ToStr(c.logo), ext: "", url: ToStr(c.url), src: ToStr(GetField(c, "src")) }
end function

function normVod(v as object) as object
    return { kind: ToStr(v.kind), id: ToStr(v.id), name: ToStr(v.name), icon: ToStr(v.icon), ext: ToStr(v.ext), url: "", src: ToStr(GetField(v, "src")) }
end function

' ---- "Your Trakt watchlist" / "Your Simkl watchlist" -------------------------
'
' The row is READ, never fetched. AddOnSyncTask pulls the member's list on its
' own thread, matches it against their own catalogue and leaves the answer on
' cachefs:; all this does is read that file. So:
'
'   * NOTHING on this screen ever asks Trakt, Simkl or a provider anything.
'     Home rebuilds on the 90-second sync heartbeat, on every detail close and
'     on every player close — a fetch here would be a request per rebuild,
'     which is the exact pattern that got this house's provider access banned
'     in August 2026.
'   * WHILE A PULL IS IN FLIGHT THE TILES ALREADY DRAWN STAY. The task replaces
'     the file in one write at the very end, so a rebuild landing mid-pull
'     reads the last good answer. The row is never blanked and refilled a
'     second later.
'   * A FAILED PULL CHANGES NOTHING, because it writes nothing.
'
' EVERY TILE IS A FILM OR A SHOW, never a channel, so rowIsPosters() is always
' true for these rows and every poster is drawn by PosterCard — which pins its
' decode to the 232 x 348 it actually draws (322,944 bytes a card, whatever the
' provider sent). There is no uncapped decode on this path. What the two rows
' add to the page is the live cards, not the 60 entries: a RowList recycles, so
' it holds about 7 cards and at most about 9.
'
'     2:3 cover    232 x 348 x 4 = 322,944 bytes    7 cards -> 2.2 MB a row
'     16:9 cover   619 x 348 x 4 = 861,648 bytes    7 cards -> 6.0 MB a row
'
' So both rows together cost about 4.3 MB of texture on an ordinary page of 2:3
' covers, and about 12 MB in the worst case where every cover a provider sent
' is landscape and the recycling pool is full — against a budget of roughly
' 90 MB, on a page that already carries the Media Bar and up to four other
' rows. That is the number to watch if a third watchlist service is ever added.
'
' THE FILE IS READ BY ITS EXACT SPELLINGS. ParseJson hands back a CASE-
' SENSITIVE map, so `it` must be read as `it` — four live bugs in this codebase
' have come from a field written one way and read another.
function watchlistRow(svc as string) as object
    out = []
    ' Cheapest possible no: a member with no add-ons never touches the disk.
    if not WatchlistRowOn(svc) then return out
    if not AddOnSignedIn(svc) then return out
    path = "cachefs:/kwickwl_" + svc + ".json"
    ' >>> NEITHER Exists() NOR THE DIRECTORY LISTING IS ASKED. JUST READ. <<<
    '
    ' This started out asking Exists() first and falling back to
    ' GetDirectoryListing("cachefs:/") when it said no, on the strength of the
    ' 2026-09-17 measurement in
    ' [[Roku - Outside Subtitle Files Never Appear (Measured)]] — where the two
    ' disagreed about a file that then read back 97,610 bytes.
    '
    ' THE NEXT DAY ON THE SAME STICK, BOTH OF THEM SAID NO about a watchlist
    ' cache the sync had just written: the pull logged "2 titles · 2 in your
    ' playlists" three runs in a row and Home drew no row at all, because
    ' neither gate ever let it get as far as the read. The measurement was
    ' worse than the note recorded — it is not that Exists() is unreliable and
    ' the listing saves you, it is that NOTHING that merely asks ABOUT a
    ' cachefs: file can be believed on this firmware.
    '
    ' So the read is the only test. ReadAsciiFile answers "" for a file that
    ' is not there, which is the same answer as a file that is empty, and both
    ' mean "no row" — so nothing downstream has to care which it was. Wrapped
    ' because a read of a missing path is allowed to be noisy, and this runs on
    ' every one of Home's rebuilds.
    raw = ""
    try
        raw = ToStr(ReadAsciiFile(path))
    catch e
        raw = ""
    end try
    if raw = "" then return out
    p = ParseJson(raw)
    if p = invalid then return out
    for each r in ToArray(GetField(p, "it"))
        kind = ToStr(GetField(r, "k"))
        id = ToStr(GetField(r, "i"))
        if kind = "" or id = "" then continue for
        ' OUR title, OUR poster, OUR id and OUR source — so open() routes this
        ' to the ordinary movie or series page and nothing downstream knows or
        ' cares that it came from Trakt.
        out.push({ kind: kind, id: id, name: ToStr(GetField(r, "n")), icon: ToStr(GetField(r, "p")), ext: ToStr(GetField(r, "e")), url: "", src: ToStr(GetField(r, "s")) })
    end for
    return out
end function

' ---- Row order (GAP: "import the row order for homescreen", 2026-09-18) -----
' Home's rows are built in the order this file happens to be written in; the
' member's order is applied afterwards, over the finished list. That keeps
' every row's construction exactly as it was and puts the ordering in three
' small functions instead of through the whole of refresh().

' Put one finished row under its Android row id. Several rows can share an id
' — one per favourite list under "favoriteLists" — and they come out in the
' order they went in.
sub stashRow(stash as object, rid as string, def as object)
    def.rid = rid
    if not stash.doesExist(rid) then stash[rid] = []
    stash[rid].push(def)
end sub

' The stash laid out in the member's order.
'
' HomeRowOrderIds() always answers with EVERY row this build knows, in the
' member's order, with anything their saved order does not mention slotted in
' beside its default neighbour — so a row that exists and is missing from a
' stored order cannot be lost here. The sweep at the end is belt and braces
' for exactly that: an id the order does not carry at all still gets drawn,
' on the end, rather than silently disappearing off Home.
function orderedRowDefs(stash as object) as object
    outDefs = []
    done = {}
    for each rid in HomeRowOrderIds()
        r = ToStr(rid)
        if stash.doesExist(r)
            done[r] = true
            for each d in stash[r]
                outDefs.push(d)
            end for
        end if
    end for
    for each rid in stash
        r = ToStr(rid)
        if not done.doesExist(r)
            for each d in stash[r]
                ' The def's own rid, not the map key: an roAssociativeArray in
                ' its default mode hands its keys back lowercased, and a log
                ' line naming 'recentmerged' would send whoever reads it
                ' hunting for a row id that does not exist.
                KLog("home", "row order does not mention '" + ToStr(GetField(d, "rid")) + "' - drawn on the end")
                outDefs.push(d)
            end for
        end if
    end for
    return outDefs
end function

' Put one late row into an already-built list at its ordered place: in front
' of the first row that ranks AFTER it, or on the end if there is none.
' Rebuilt rather than shuffled — BrightScript arrays have no insert-at.
function insertRowDefInOrder(defs as object, def as object) as object
    rank = {}
    order = HomeRowOrderIds()
    for i = 0 to order.count() - 1
        rank[ToStr(order[i])] = i
    end for
    ' An id the order does not carry sorts last, which is where it used to go
    ' anyway.
    mine = 9999
    if rank.doesExist(def.rid) then mine = rank[def.rid]
    at = defs.count()
    for i = 0 to defs.count() - 1
        other = 9999
        rid = ToStr(GetField(defs[i], "rid"))
        if rank.doesExist(rid) then other = rank[rid]
        if other > mine
            at = i
            exit for
        end if
    end for
    outDefs = []
    for i = 0 to defs.count()
        if i = at then outDefs.push(def)
        if i < defs.count() then outDefs.push(defs[i])
    end for
    return outDefs
end function

sub refresh()
    ' Who is watching, drawn top right. Cheap, and it has to be here rather
    ' than in init(): Home is rebuilt after every background sync and after
    ' a profile switch, and a renamed profile or a new avatar arriving from
    ' another device must show up without the member reopening anything.
    renderProfileButton()

    ' Last build's finished marks are not this build's — the member may have
    ' just come back from finishing something. One walk per build, at most,
    ' and only if a show on the page actually asks (see seenMarks()).
    m.seenCache = invalid

    m.rowDefs = []

    ' ---- The member's own row order (2026-09-18) ----------------------------
    ' Home used to build its rows in the order this sub happens to be written
    ' in, and there was no way to change it; the phone has let a member drag
    ' them about for a while (Settings > Home screen > Row order). Every row
    ' built below is now put in a STASH under its Android row id instead of
    ' pushed straight on, and orderedRowDefs() lays them out in the member's
    ' order at the end. Nothing about how a row is BUILT has changed.
    '
    ' One id can stand for several drawn rows — "favoriteLists" is one entry
    ' in the order and one row per list on Home, exactly as on the phone, and
    ' the lists keep their own order among themselves (Settings > "Put your
    ' lists in order").
    stash = {}

    ' Home mixes every source's favorites and recents in the same rows —
    ' the Android model. Each item carries its src, so opening one routes
    ' to its own source no matter what else is configured.
    if GetPrefBool("pref_show_recents", true)
        ' Continue Watching leads Home, as it does on the phone ("the
        ' Continue Watching panel at the top of Home"). The list it reads has
        ' existed all along but was only ever used to seed Kwick Picks, so
        ' movies and series watched anywhere — including on this Roku — had
        ' nowhere to appear. Episodes are held as their SERIES, which is what
        ' the detail screens store locally and what the phone sends as the
        ' row's parent.
        cw = []
        for each v in LoadRecentVod()
            cw.push(normVod(v))
        end for
        chans = []
        for each c in LoadRecentChannels()
            chans.push(normChannel(c))
        end for

        ' ---- One row or two (GAP G9) ---------------------------------------
        ' Settings > Home screen can fold the two Recently Watched rows into
        ' one, exactly as the phone does (MergeRecentsRow in Store.brs, which
        ' shares the phone's own key name so folding them on either device
        ' folds them on both). Until today the switch existed and Home
        ' ignored it; this is the half that was missing.
        '
        ' NAMING. The phone calls the merged pair "Recently Watched" and its
        ' VOD half "Recently Watched VOD" (home_screen.dart:643/662). This
        ' screen has always called that half "Continue Watching" and keeps
        ' doing so while it stands alone — it is the row the Media Bar is
        ' built from and the name members here already know. Merged, the row
        ' is no longer only what you are partway through, so it takes the
        ' phone's name for the merged pair.
        '
        ' ORDER INSIDE THE MERGED ROW. Films and shows lead, channels follow.
        ' The phone interleaves its two halves by watchedAt; this box cannot,
        ' and guessing would be worse than a stable order — a recent here
        ' carries only a DAY number (PushRecentVod/PushRecentChannel write
        ' `d`, TodayDayNumber), rows saved before that field arrived carry
        ' nothing at all, and sorting a whole row on a value half of it does
        ' not have would shuffle a member's recents about on every rebuild.
        ' Each half is already newest-first within itself, which is the part
        ' that matters.
        if MergeRecentsRow()
            merged = []
            for each it in cw
                merged.push(it)
            end for
            for each it in chans
                merged.push(it)
            end for
            ' cw:true marks the row seedContinueEpisodes may deep-link from —
            ' see GAP H12 below. The channels in it simply aren't shows and
            ' are skipped there.
            if merged.count() > 0 then stashRow(stash, "recentMerged", { title: "Recently Watched", items: merged, cw: true })
        else
            if cw.count() > 0 then stashRow(stash, "recentVod", { title: "Continue Watching", items: cw, cw: true })
            if chans.count() > 0 then stashRow(stash, "recentChannels", { title: "Recently Watched Channels", items: chans })
        end if
    end if

    if GetPrefBool("pref_show_favorites", true)
        favItems = []
        for each c in LoadFavoriteChannels()
            favItems.push(normChannel(c))
        end for
        vodItems = []
        for each v in LoadFavoriteVod()
            vodItems.push(normVod(v))
        end for
        ' ---- One row or two (GAP G10) --------------------------------------
        ' The same switch again for favorites (MergeFavoritesRow). Channels
        ' first, then movies and shows: that is the phone's own order inside
        ' its merged row, which walks the ordered favorite channels and then
        ' the VOD favorites (home_screen.dart:702-714). The unmerged case is
        ' untouched — the two rows it has always drawn, in the order it has
        ' always drawn them.
        if MergeFavoritesRow()
            merged = []
            for each it in favItems
                merged.push(it)
            end for
            for each it in vodItems
                merged.push(it)
            end for
            if merged.count() > 0 then stashRow(stash, "favoritesMerged", { title: "Favorites", items: merged })
        else
            if favItems.count() > 0 then stashRow(stash, "favoriteChannels", { title: "Favorite Channels", items: favItems })
            ' allFav: every item in this row is already a favourite, so a heart
            ' on each poster says nothing the row title has not. The card
            ' honours it through hideFav below. ChannelCard has never drawn
            ' one for exactly this reason - "the Home rows ARE your favorites".
            ' ONE ROW WHERE THE PHONE HAS TWO. Android orders "Favorite Movies"
            ' and "Favorite Series" separately; this box has always drawn a
            ' single combined row off LoadFavoriteVod(). It takes the
            ' favoriteMovies slot, and favoriteSeries is carried through the
            ' saved order untouched — see SaveHomeRowOrder in Store.brs.
            if vodItems.count() > 0 then stashRow(stash, "favoriteMovies", { title: "Favorite Movies & Series", items: vodItems, allFav: true })
        end if
    end if

    ' Favorite Lists with a Home row on.
    for each l in LoadLists()
        if l.homeRow = true
            items = []
            for each it in ToArray(l.items)
                if ToStr(it.kind) = "channel"
                    items.push({ kind: "channel", id: ToStr(it.id), name: ToStr(it.name), icon: ToStr(it.icon), ext: "", url: "", src: ToStr(GetField(it, "src")) })
                else
                    items.push({ kind: ToStr(it.kind), id: ToStr(it.id), name: ToStr(it.name), icon: ToStr(it.icon), ext: ToStr(it.ext), url: "", src: ToStr(GetField(it, "src")) })
                end if
            end for
            if items.count() > 0 then stashRow(stash, "favoriteLists", { title: ToStr(l.name), items: items })
        end if
    end for

    ' The member's Trakt and Simkl watchlists, after their own lists and before
    ' Kwick Picks (which appends itself when its task answers). See the block
    ' above watchlistRow().
    for each wl in [{ id: "trakt", title: "Your Trakt watchlist", rid: "traktWatchlist" }, { id: "simkl", title: "Your Simkl watchlist", rid: "simklWatchlist" }]
        wlItems = watchlistRow(wl.id)
        ' AN EMPTY ROW IS NO ROW AT ALL — a heading over nothing is worse than
        ' nothing, and it is what a member sees for the first three hours after
        ' signing in, before the first pull has landed.
        if wlItems.count() > 0 then stashRow(stash, wl.rid, { title: wl.title, items: wlItems })
        ' SAID OUT LOUD WHEN THERE IS NOTHING TO DRAW, and only then. An empty
        ' row is invisible by design, so without this line "the pull matched
        ' two titles" and "Home shows no row" are the same picture from the
        ' sofa and there is nothing to tell them apart. On the office stick
        ' 2026-09-18 the sync logged "2 titles · 2 in your playlists" three
        ' times over while Home drew neither row, and this is the line that
        ' says which half is wrong. Once per build per service, only on the
        ' empty path, so a working box never prints it.
        ' ONLY WHEN A SYNC HAS ACTUALLY RUN. Signed in with the switch on and
        ' nothing cached is the ORDINARY state for the first few hours after
        ' signing in, and saying so on every one of Home's rebuilds would be
        ' noise in every member's log. A row that is empty AFTER a pull has
        ' finished is the broken one, and that is the only one worth a line.
        if wlItems.count() = 0 and WatchlistRowOn(wl.id) and AddOnSignedIn(wl.id) and LastSyncAt(wl.id) > 0
            KLog("home", wl.title + ": a sync has run but the cache gave no tiles")
        end if
    end for

    ' Everything built above, laid out in the member's own order. Kwick Picks
    ' is NOT here — its task has not answered yet; onPicksResult puts it in at
    ' its ordered place when it does.
    m.rowDefs = orderedRowDefs(stash)

    ' How far into each title the profile is, for the bars on the row tiles.
    ' Worked out ONCE for the whole page, before any tile is built — see
    ' refreshResumeVodIndex(). Only bother with the episode half when there
    ' is actually a show on the page to put a bar on.
    hasSeries = false
    for each d in m.rowDefs
        for each it in d.items
            if it.kind = "series" then hasSeries = true
        end for
    end for
    ' Which episode each show is up to — ONE walk of the watch-history
    ' stores for the WHOLE page, built here and handed to everything that
    ' needs it: the progress bars on the tiles, the Continue Watching deep
    ' links (GAP H12) and, through MediaBarEntries, the panel. Three readers,
    ' one build, no request. Skipped outright when there is no show on the
    ' page to ask about.
    epIndex = invalid
    if hasSeries then epIndex = MediaBarEpisodeIndex()
    seedContinueEpisodes(epIndex)
    refreshResumeVodIndex(hasSeries, epIndex)

    buildMediaBar()
    buildRows()
    startPicks()
    startEnrich()
end sub

' ---- Resume progress index ---------------------------------------------------
'
' How far the profile is into every film and show it has a position for:
' "<src>:<kind>:<id>" -> 1..99, parked on m.global so a recycling tile costs
' one associative-array hit and nothing else. The keys are built by
' FavVodKeyFor, so they are the SAME strings the favorite hearts use and a
' title half-watched on one source can never light a bar on the
' same-numbered title of another.
'
' WHY IT IS BUILT IN ONE PASS. Both of the obvious per-tile alternatives are
' already banned in this codebase. LoadResume() per tile is a registry read
' per tile per scroll — "a visible stutter on a stick" (Store.brs,
' RefreshFavVodIndex, which exists for exactly this reason and builds
' exactly this shape of map). And asking a provider where you are in
' something, per tile, is the loop that got this house's address banned on
' 2026-08-14 (home_screen.dart:71-74). Nothing below touches the network:
' every number comes out of registry sections this app already wrote.
'
' THIS IS A DELIBERATE COPY of the same function in VodScreen.brs. It wants
' to live in Store.brs next to RefreshFavVodIndex(); that file was being
' rewritten by another lane while this landed and could not be touched.
' Move it there and delete both copies.
sub refreshResumeVodIndex(withSeries = true as boolean, epIndex = invalid as dynamic)
    if m.global = invalid then return
    if not m.global.hasField("resumeVodIndex") then m.global.addFields({ resumeVodIndex: {} })
    idx = {}
    profileId = ActiveProfileId()
    prefix = ""
    if profileId <> "default" and profileId <> "" then prefix = profileId + "|"

    ' FILMS. A film's position IS the resume section, so read the section
    ' once rather than asking it per title. (SaveResume throws a film's
    ' point away past 95%, so anything still in here is genuinely partway.)
    sec = CreateObject("roRegistrySection", "kwick_resume")
    for each k in sec.getKeyList()
        ks = ToStr(k)
        ' Same profile test MediaBarEpisodeIndex uses: the default profile's
        ' keys carry no prefix at all, so "has no pipe" is what marks them.
        mine = false
        if prefix = ""
            mine = (Instr(1, ks, "|") = 0)
        else
            mine = (Len(ks) >= Len(prefix) and ks.left(Len(prefix)) = prefix)
        end if
        if mine
            bare = Mid(ks, Len(prefix) + 1)
            if bare.left(6) = "movie:"
                parts = sec.read(ks).split("|")
                if parts.count() >= 2
                    pct = MediaBarPercent(ToInt(parts[0]), ToInt(parts[1]))
                    if pct > 0
                        q = SplitSrcQualifiedId(Mid(bare, 7))
                        idx[FavVodKeyFor("movie", q.id, q.src)] = pct
                    end if
                end if
            end if
        end if
    end for

    ' SHOWS. A series has no position of its own — the bar stands for the
    ' episode you are up to, and the only thing that knows which episode
    ' that is is MediaBarEpisodeIndex(): the player's own kwick_hist rows
    ' plus the rows KwickSync pulled from the phone. It reads nothing off
    ' the network either, but it does parse JSON per row, so it is skipped
    ' outright when there is no show on screen to draw a bar on.
    if withSeries
        ' Handed in by refresh(), which builds it once for the whole page.
        ' The fallback is for any other caller (and for VodScreen's copy of
        ' this function, which passes nothing); it must never fire on a Home
        ' build, because that would be a SECOND walk of the same stores.
        eps = epIndex
        if eps = invalid then eps = MediaBarEpisodeIndex()
        for each ref in eps
            row = eps[ref]
            pct = MediaBarPercent(ToInt(row.pos), ToInt(row.dur))
            if pct > 0
                q = SplitSrcQualifiedId(ToStr(ref))
                idx[FavVodKeyFor("series", q.id, q.src)] = pct
            end if
        end for
    end if

    m.global.resumeVodIndex = idx
end sub

' ---- "Which episode is next", and everywhere it has to agree ----------------
'
' Three places on this screen name an episode: the Media Bar's Resume button
' ("Play next episode"), a Continue Watching tile opening the show's page, and
' — one screen along — the series page's own Play button. Until today they
' could disagree, because Home worked "finished" out from the POSITION alone
' (MediaBarEntries: pos >= 95% of dur) while the series page had a store of
' real finished marks to read. A show finished on the phone, whose mark synced
' across but whose position did not, was "not finished" here and "finished"
' there: the panel offered the episode again, the series page offered the one
' after it.
'
' So all three now answer out of the SAME two facts, in the same order, and it
' is the series page's order because that is where the rule is written down
' (SeriesDetailScreen.scanWatchState, itself a port of Android's
' watch_state.dart):
'
'   1. a stored finished mark wins outright;
'   2. failing that, past 95% of the duration counts as finished — kept as a
'      second answer for the reason the series page keeps it, that positions
'      written before marks existed carry no mark;
'   3. anything else is not finished.
'
' Note (2) is "past 95%", strictly greater, which is what scanWatchState and
' SaveResume both use. MediaBarEntries said ">=", so an episode sitting on
' exactly 95% used to be finished on Home and part-watched on the series page.
' Home now says the same thing the other two do.
'
' ONE REGISTRY WALK PER HOME BUILD, and never per tile. LoadSeenSet is built
' at most once per refresh() and cached on m.seenCache; a tile costs one
' associative-array hit. Asking a panel per tile is the loop that got this
' house's address banned on 2026-08-14 (home_screen.dart:71-74), and reading
' the registry per tile is the documented stutter refreshResumeVodIndex exists
' to avoid. Neither happens here.

' The finished marks for the active profile, built on first use and thrown
' away at the start of every refresh() so a mark written by the player during
' this Home session is picked up on the way back out of it.
function seenMarks() as object
    if m.seenCache = invalid then m.seenCache = LoadSeenSet(ActiveProfileId())
    return m.seenCache
end function

' The finished-mark key for an episode named the way the watch-history index
' names one — source-qualified, "<src>~<id>". Store.brs builds its keys from a
' BARE id plus a source token, so the two are taken apart and handed over in
' that shape rather than the string being glued together here: one way to name
' a mark, and no second spelling of the prefix to drift out of step.
function seenKeyForEpisodeRef(epRef as string) as string
    if epRef = "" then return ""
    q = SplitSrcQualifiedId(epRef)
    return SeenKeyEpisode(q.id, q.src)
end function

' Rule (1)+(2)+(3) above, for the episode a Home tile or panel entry stands
' for. epRef is source-qualified; posS/dur are that episode's saved position.
function episodeIsFinished(epRef as string, posS as integer, dur as integer) as boolean
    if epRef = "" then return false
    key = seenKeyForEpisodeRef(epRef)
    if key <> "" and seenMarks().doesExist(key) then return true
    return (dur > 0 and posS > Int(dur * 0.95))
end function

' ---- GAP H12: a Continue Watching tile opens on the RIGHT episode -----------
'
' Pressing a show in Continue Watching used to drop the member on the series
' page with nothing said about which episode they were on, so the page opened
' on the first episode of the first season — three seasons away from where
' they actually were. The panel above it already carried the episode ("More
' info" hands it over as item.episodeId); the row did not.
'
' It does now, and it uses the rule above to decide WHICH:
'
'   part-watched  -> deep-link to it. The series page seeds its Play button
'                    and both lists onto that episode (focusSeedEpisode).
'   finished      -> deep-link to NOTHING, deliberately. Home cannot know
'                    what comes after an episode without an episode list, and
'                    fetching one per tile is the banned loop. The series page
'                    CAN — scanWatchState answers "the one after the last
'                    finished" out of the marks store — so Home says nothing
'                    and lets the page answer. Two places, one answer, because
'                    it is literally the same code deciding.
'   unknown       -> nothing, as before.
'
' The Media Bar's Resume button is the one place that does resolve the next
' episode itself, because it PLAYS rather than opens and has nowhere to defer
' to. It spends one request on the press to do it (resumeOrNext), which is the
' same single request opening the show's page already makes.
sub seedContinueEpisodes(epIndex as dynamic)
    if epIndex = invalid then return
    for each d in m.rowDefs
        if d.doesExist("cw") and d.cw = true
            for each it in d.items
                if it.kind = "series"
                    ' Same lookup MediaBarEntries does, so the row and the
                    ' panel are reading the same row of the same map.
                    ep = epIndex[SrcQualifiedId(it.id, it.src)]
                    if ep <> invalid
                        epRef = ToStr(ep.epId)
                        if epRef <> "" and not episodeIsFinished(epRef, ToInt(ep.pos), ToInt(ep.dur))
                            ' Bare id: the series page matches it against the
                            ' ids in get_series_info, which are not qualified.
                            ' open() passes it through untouched.
                            it.episodeId = SplitSrcQualifiedId(epRef).id
                            it.episodeLabel = ToStr(ep.sub)
                        end if
                    end if
                end if
            end for
        end if
    end for
end sub

' ---- Profile button (H7) ----------------------------------------------------
' The phone carries the active profile's avatar in Home's app bar and a press
' opens the profile list (home_screen.dart:405). Here it is the same thing:
' the avatar top right, the profile's name beside it, and OK raises the SAME
' "Who's watching?" the app raises at launch — AppScene's picker overlay,
' floated over the shell. THIS SCREEN BUILDS NO PICKER OF ITS OWN; it sets one
' field on the scene and AppScene does the rest (see the H7 section there).
'
' DRAWN FROM WHAT IS ALREADY ON THE BOX. The colour, the initial and the pack
' avatar are exactly the three things ProfilePickerScreen already builds a
' tile out of, and the avatar pack is already in the bundle. Nothing is
' downloaded, nothing is looked up, and no image asset was added — the whole
' package has to stay under 4 MB (certification 3.7).
'
' >>> IT IS NOT ALWAYS THERE, AND THAT IS THE POINT <<<
' Home can be rendered before this device knows the account's profiles at all:
' the locker took longer than five seconds and AppScene opened Home pointing
' at NO profile rather than fabricating one. Read the note at
' AppScene.brs:364 before touching the next line. So this asks ProfileById,
' which answers invalid, and NEVER ActiveProfile(), which calls
' EnsureDefaultProfile() and would create the blank "Default" that whole note
' exists to prevent — a blank Default gets pushed up and overwrites the
' member's real profile name, colour, avatar and PIN on every device they
' own. No profile, no button. The moment the real ones land, Home is rebuilt
' (reloadProfile -> refresh) and it appears.
sub renderProfileButton()
    p = ProfileById(ActiveProfileId())
    m.hasProfileButton = (p <> invalid)
    if not m.hasProfileButton
        m.profileRing.visible = false
        m.profileFace.visible = false
        m.profileInitial.visible = false
        m.profileAvatar.visible = false
        m.profileName.visible = false
        ' Never leave the focus zone pointing at something that isn't there.
        if m.focusZone = "profile" then m.focusZone = "rows"
        return
    end if
    m.profileFace.visible = true
    m.profileInitial.visible = true
    m.profileName.visible = true
    ' The square AND the ink that goes on it, together, every time. Written as
    ' a pair on purpose: this node is re-used across every rebuild, so setting
    ' the colour without the ink would leave the previous profile's ink on the
    ' new profile's square — and on this palette that is the difference
    ' between a readable letter and a 1.7:1 smudge.
    m.profileFace.color = ProfileColorAt(ToInt(p.color))
    m.profileInitial.color = ProfileInkAt(ToInt(p.color))
    nm = ToStr(p.name)
    if nm = "" then m.profileInitial.text = "?" else m.profileInitial.text = UCase(nm.left(1))
    m.profileName.text = nm
    ' Set BOTH ways every time. These nodes live in the XML and are re-used
    ' across every rebuild, so a profile with no avatar has to actively clear
    ' the last profile's picture rather than simply not setting one.
    avUri = AvatarUri(ToStr(p.avatar))
    m.profileAvatar.uri = avUri
    m.profileAvatar.visible = (avUri <> "")
    ' Rebuilt while the member is standing on it (a background sync landing)
    ' must not lose the ring — the zone is the truth, not the node.
    applyProfileFocus(m.focusZone = "profile")
end sub

sub applyProfileFocus(on as boolean)
    if m.profileRing = invalid then return
    if not m.hasProfileButton
        m.profileRing.visible = false
        return
    end if
    m.profileRing.visible = on
    if on
        m.profileName.color = m.theme.textPrimary
    else
        m.profileName.color = m.theme.textSecondary
    end if
end sub

' Hand the press to AppScene, which owns "Who's watching?". One field, no
' picker built here, nothing to keep in step.
sub openProfilePicker()
    if not m.hasProfileButton then return
    KLog("home", "profile button - asking for Who's watching?")
    m.top.getScene().switchProfileOverlay = true
end sub

' Down out of the profile button: into the panel when there is one, else the
' first row, else there is nowhere to go and it stays where it is.
sub focusBelowProfile()
    if m.bar <> invalid
        applyProfileFocus(false)
        m.focusZone = "bar"
        m.scroller.translation = [0, 0]
        m.bar.setFocus(true)
        return
    end if
    if m.rowGrids.count() > 0
        applyProfileFocus(false)
        m.focusZone = "rows"
        if m.rowIndex >= m.rowGrids.count() then m.rowIndex = 0
        m.rowGrids[m.rowIndex].setFocus(true)
        scrollToRow(m.rowIndex)
        return
    end if
end sub

' ---- Media Bar --------------------------------------------------------------
' The rotating Continue Watching panel across the top of Home — the Roku
' port of Android's ContinueWatchingSpotlight.
'
' It has its OWN switch and is deliberately not tied to "Show Recently
' Watched": wanting the rows without the big rotating panel, or the other
' way round, is a reasonable thing to want, and that is the phone's rule.
'
' Built once and then RE-USED. Home rebuilds itself after every background
' sync, and throwing the panel away each time would take focus off whatever
' button the member was on and drop them back on the first title mid-press.
' It is only ever removed when there is genuinely nothing left to continue,
' in which case the section simply isn't there at all.
sub buildMediaBar()
    m.barEntries = []
    if MediaBarEnabled() then m.barEntries = MediaBarEntries()
    applySeenToBarEntries()
    applyLastWatchedToBarEntries()

    if m.barEntries.count() = 0
        if m.bar <> invalid
            m.barHost.removeChild(m.bar)
            m.bar = invalid
        end if
        if m.focusZone = "bar" then m.focusZone = "rows"
        m.rowsTop = 130
        if m.barCountLogged <> 0
            m.barCountLogged = 0
            KLog("home", "media bar has nothing to show - drawing nothing")
        end if
        return
    end if

    if m.bar = invalid
        m.bar = m.barHost.createChild("MediaBar")
        m.bar.observeField("action", "onMediaBarAction")
    end if
    m.bar.rotateSeconds = MediaBarSeconds()
    m.bar.entries = m.barEntries
    m.rowsTop = 470
    if m.barCountLogged <> m.barEntries.count()
        m.barCountLogged = m.barEntries.count()
        KLog("home", "media bar showing " + m.barEntries.count().toStr() + " title(s), every " + MediaBarSeconds().toStr() + "s")
    end if
end sub

' ---- The panel's "finished" is the same "finished" as everywhere else -------
'
' MediaBarEntries hands each entry back with finished worked out from the
' POSITION alone, which is all it could do: the panel's builder lives in
' Store.brs and pre-dates the finished-marks store landing beside it. Here the
' marks are read — once, for the whole page — and every entry's flag is
' settled by the shared rule (episodeIsFinished, above).
'
' TWO THINGS READ THIS FLAG and both change with it, which is the point:
'   * the panel's own button label, "Play next episode" instead of "Resume"
'     (MediaBar.brs:385) — so the button stops offering an episode back that
'     the member finished on their phone last night;
'   * resumeOrNext below, which is what the press actually does.
' The Continue Watching tile beside it and the series page behind it are on
' the same rule, so all four name one episode.
'
' A film is left alone. It has no episode and no mark to find: this app throws
' a film's resume point away the moment it passes 95%, so "still in the panel"
' already means "not finished" (see MediaBarEntries).
sub applySeenToBarEntries()
    for each e in m.barEntries
        if ToStr(e.kind) = "series"
            e.finished = episodeIsFinished(ToStr(GetField(e, "epId")), ToInt(e.pos), ToInt(e.dur))
        end if
    end for
end sub

' ---- "You were watching it yesterday" --------------------------------------
'
' The panel's subtext line (describeEntry in MediaBar.brs) says when the
' member last had a title on, and it can only say it if somebody hands it the
' day. PushRecentVod stamps every recents row with `d`, the day number it was
' watched (Store.brs:3524), but MediaBarEntries builds its rows field by field
' and does not carry it across — and Store.brs is not ours to change.
'
' So it is copied on here, where the panel is already being filled in. This
' costs ONE registry read of a list this screen was going to read anyway; it
' is not a request and it cannot become one. A row with no `d` (written before
' the stamp existed) simply gets no sentence.
sub applyLastWatchedToBarEntries()
    if m.barEntries.count() = 0 then return
    days = {}
    for each r in LoadRecentVod()
        d = GetField(r, "d")
        if d <> invalid
            ' The same three parts entryKey() in MediaBar.brs joins, so a
            ' title matches on kind AND source AND id and never on id alone —
            ' two sources can hand out the same stream id.
            days[ToStr(r.kind) + "|" + ToStr(GetField(r, "src")) + "|" + ToStr(r.id)] = ToInt(d)
        end if
    end for
    for each e in m.barEntries
        d = days[ToStr(e.kind) + "|" + ToStr(GetField(e, "src")) + "|" + ToStr(e.id)]
        if d <> invalid then e.d = d
    end for
end sub

' Resume / More info came back from the panel.
sub onMediaBarAction(event as object)
    try
        onMediaBarActionInner(event)
    catch e
        GuardFailed("home/onMediaBarAction", e)
    end try
end sub

sub onMediaBarActionInner(event as object)
    act = event.getData()
    if act = invalid then return
    idx = ToInt(GetField(act, "index"))
    if idx < 0 or idx >= m.barEntries.count() then return
    e = m.barEntries[idx]
    what = ToStr(GetField(act, "what"))
    if what = "info"
        openFromBar(e)
    else if what = "resume"
        resumeOrNext(e)
    end if
end sub

' The detail page for whatever the panel is showing, with the episode the
' tile stood for carried along.
'
' The episode goes over EVEN WHEN IT IS FINISHED, unlike the Continue Watching
' tile, and that is not an inconsistency. The panel is naming that episode on
' screen at the moment of the press, so the page it opens has to be able to
' find its way from there; the page then applies the shared rule and lands on
' whatever comes next (SeriesDetailScreen.focusSeedEpisode, GAP H12). A tile
' names nothing, so it hands over nothing and the page answers from scratch.
' Both arrive at the same episode.
sub openFromBar(e as object)
    it = { kind: ToStr(e.kind), id: ToStr(e.id), name: ToStr(e.name), icon: ToStr(e.icon), ext: ToStr(e.ext), url: "" }
    it.src = ToStr(GetField(e, "src"))
    if ToStr(GetField(e, "epId")) <> ""
        it.episodeId = SplitSrcQualifiedId(ToStr(e.epId)).id
        it.episodeLabel = ToStr(GetField(e, "sub"))
    end if
    m.focusZone = "bar"
    open(it)
end sub

' Resume — but on a FINISHED episode of a show, play the next one instead.
' A port of Android's resumeOrNext: once you have finished the episode a
' tile is built from, the useful thing to offer is the one after it, which
' is what every other app does and what members expect.
'
' "Finished" is e.finished, and since applySeenToBarEntries above that is the
' finished-marks answer rather than the position-only guess this was written
' with — see the block at the top of that sub. Nothing in here changed for it;
' the flag it has always read simply tells the truth now, and tells the same
' truth the Continue Watching tile and the series page tell.
'
' The episode listing is fetched HERE, on the press. That is one request per
' press, exactly like opening the show's own page — not one per tile on
' every render, which is the thing that must never happen again.
'
' >>> WHY THIS ONE RESOLVES THE NEXT EPISODE ITSELF AND THE TILE DOES NOT <<<
' This PLAYS. There is no screen further along to defer the question to, so it
' spends the one press-time request to answer it. A Continue Watching tile
' OPENS the series page, which already has the whole episode list in hand and
' answers out of the same marks store, so that path defers instead of asking
' (seedContinueEpisodes). Two routes, one answer, one request between them.
sub resumeOrNext(e as object)
    src = ToStr(GetField(e, "src"))
    prov = ProviderForSrcToken(src)
    ' ONLY A PANEL CAN HAVE ITS STREAM ADDRESS BUILT HERE, and this is a
    ' positive test rather than a list of exclusions because the old one was
    ' the list `<> "m3u"` — which let a Jellyfin or an Emby through into
    ' XtreamVodUrl, where the member's Xtream username is invalid on a media
    ' server and UrlEncode halted the whole app.
    '
    ' CRASHED THE OFFICE STICK, 2026-09-19: pressing Resume on the Media Bar
    ' for "#SKYKING" — a film on the house Jellyfin, and the first thing on
    ' Home — stopped the app dead. `Type Mismatch. Unable to cast "Invalid"
    ' to "String" ... UrlEncode ... XtreamVodUrl ... playMovieFromBar ...
    ' resumeOrNext`. The screen froze where it was; nothing on the television
    ' said anything. A member's own server is most of what this house
    ' watches, so this was one press away on every launch.
    '
    ' Everything that is not a panel goes to its own detail page, which knows
    ' how to open it: a media server builds its address from a session, an
    ' M3U from its own row, and a USB file is already a path.
    pt = ""
    if prov <> invalid then pt = LCase(ToStr(prov.ptype))
    if prov = invalid or (pt <> "xtream" and pt <> "kwicktv")
        openFromBar(e)
        return
    end if
    if ToStr(e.kind) <> "series"
        playMovieFromBar(e, prov)
        return
    end if
    ' A show nothing has ever told us an episode for — there is no position
    ' to pick up and no episode to be "next" after, so hand the member the
    ' show itself rather than guessing which one they meant.
    if ToStr(GetField(e, "epId")) = ""
        openFromBar(e)
        return
    end if
    if m.resumeTask <> invalid then return   ' one press at a time
    m.pendingResume = e
    m.resumeProv = prov
    m.resumeTask = CreateObject("roSGNode", "ApiTask")
    m.resumeTask.url = XtreamApiUrl(prov, "get_series_info") + "&series_id=" + UrlEncode(ToStr(e.id))
    m.resumeTask.observeField("result", "onResumeSeriesInfo")
    KLog("home", "media bar resume - fetching episode list for " + ToStr(e.name))
    m.resumeTask.control = "RUN"
end sub

sub onResumeSeriesInfo(event as object)
    try
        onResumeSeriesInfoInner(event)
    catch e
        GuardFailed("home/onResumeSeriesInfo", e)
        ' DO NOT LEAVE RESUME WEDGED. resumeOrNext refuses a second press
        ' while m.resumeTask is set ("one press at a time"), so a fault before
        ' the real handler cleared it would mean Resume on the Media Bar did
        ' nothing at all for the rest of the session, with nothing on the
        ' television to say why. Cleared here so the next press is allowed.
        m.resumeTask = invalid
        m.pendingResume = invalid
    end try
end sub

sub onResumeSeriesInfoInner(event as object)
    res = event.getData()
    m.resumeTask = invalid
    e = m.pendingResume
    m.pendingResume = invalid
    if e = invalid then return
    if res = invalid or res.ok <> true
        KLog("home", "media bar resume - no episode list came back, opening the show instead")
        openFromBar(e)
        return
    end if
    eps = flattenEpisodes(GetField(res.data, "episodes"))
    if eps.count() = 0
        openFromBar(e)
        return
    end if
    wantId = SplitSrcQualifiedId(ToStr(e.epId)).id
    at = -1
    for i = 0 to eps.count() - 1
        if eps[i].id = wantId then at = i
    end for
    if at < 0
        ' The episode is no longer in this panel's listing, and anything we
        ' played instead would be the wrong one.
        openFromBar(e)
        return
    end if
    pick = eps[at]
    startAt = ToInt(e.pos)
    ' doesExist FIRST (the shape at MediaBar.brs:1598). A row without the
    ' field reads as invalid, and `invalid = true` is a Type Mismatch - which
    ' here means the member presses Resume on the Media Bar and gets nothing,
    ' with only a caught-fault line in the log to say why.
    ' applySeenToBarEntries stamps it on every series entry today; this no
    ' longer depends on it. Same site as MediaBar.brs:1709 and :1766.
    if e.doesExist("finished") and e.finished = true
        if at + 1 >= eps.count()
            openFromBar(e)   ' that was the last episode — the show is done
            return
        end if
        ' A fresh episode, not a resume: there is no position to pick up.
        pick = eps[at + 1]
        startAt = 0
    end if
    playEpisodeFromBar(e, pick, startAt)
end sub

' { "1": [ {id, episode_num, container_extension}, ... ] } -> one flat list
' in season then episode order, which is what "the next one" means.
function flattenEpisodes(epsBySeason as dynamic) as object
    out = []
    if epsBySeason = invalid or type(epsBySeason) <> "roAssociativeArray" then return out
    nums = []
    for each k in epsBySeason
        nums.push(ToInt(k))
    end for
    nums.sort()
    for each n in nums
        for each ep in ToArray(epsBySeason[n.toStr()])
            out.push({
                id: ToStr(GetField(ep, "id"))
                ext: ToStr(GetField(ep, "container_extension"))
                season: n
                epNum: ToInt(GetField(ep, "episode_num"))
            })
        end for
    end for
    return out
end function

sub playEpisodeFromBar(e as object, ep as object, startAt as integer)
    if m.resumeProv = invalid then return
    src = ToStr(GetField(e, "src"))
    url = XtreamSeriesEpisodeUrl(m.resumeProv, ep.id, ep.ext)
    code = "S" + pad2(ep.season) + "E" + pad2(ep.epNum)
    ' Recents hold the SERIES, exactly as the series page does.
    rec = { kind: "series", id: ToStr(e.id), name: ToStr(e.name), icon: ToStr(e.icon), ext: "" }
    rec.src = src
    PushRecentVod(rec)
    m.player = m.top.getScene().createChild("PlayerScreen")
    m.player.titleText = ToStr(e.name) + " - " + code
    m.player.streamUrl = url
    m.player.streamFormat = StreamFormatFor(url, ep.ext)
    m.player.isLive = false
    m.player.resumeKey = ResumeKeyEpisode(ToStr(ep.id), src)
    m.player.resumeFrom = startAt
    ' History metadata for KwickSync's hist push — the same shapes the
    ' series page writes, so a title continued from here looks identical on
    ' the phone to one played from its own page.
    m.player.histTitle = ToStr(e.name)
    m.player.subText = code
    m.player.posterUrl = ToStr(e.icon)
    m.player.parentId = "series:" + SrcQualifiedId(ToStr(e.id), src)
    m.player.observeField("closed", "onPlayerClosed")
    m.player.setFocus(true)
    m.player.start = true
    KLog("home", "media bar playing " + ToStr(e.name) + " " + code + " from " + startAt.toStr() + "s")
end sub

sub playMovieFromBar(e as object, prov as object)
    src = ToStr(GetField(e, "src"))
    ext = ToStr(e.ext)
    url = XtreamVodUrl(prov, ToStr(e.id), ext)
    rec = { kind: "movie", id: ToStr(e.id), name: ToStr(e.name), icon: ToStr(e.icon), ext: ext }
    rec.src = src
    PushRecentVod(rec)
    m.player = m.top.getScene().createChild("PlayerScreen")
    m.player.titleText = ToStr(e.name)
    m.player.streamUrl = url
    m.player.streamFormat = StreamFormatFor(url, ext)
    m.player.isLive = false
    m.player.resumeKey = ResumeKeyMovie(ToStr(e.id), src)
    m.player.resumeFrom = ToInt(e.pos)
    m.player.histTitle = ToStr(e.name)
    m.player.posterUrl = ToStr(e.icon)
    m.player.parentId = "movie:" + SrcQualifiedId(ToStr(e.id), src)
    m.player.observeField("closed", "onPlayerClosed")
    m.player.setFocus(true)
    m.player.start = true
    KLog("home", "media bar playing " + ToStr(e.name) + " from " + ToInt(e.pos).toStr() + "s")
end sub

' Two-digit season/episode numbers, Android style ("S01E03").
function pad2(n as integer) as string
    if n < 10 then return "0" + n.toStr()
    return n.toStr()
end function

' Synced-in favorites can arrive without art (phone channel payloads carry
' no logo; some VOD rows lost posters before the sync wire fix). Look the
' blanks up in the panel catalog once per Home visit and rebuild.
sub startEnrich()
    if m.enrichStarted = true then return
    ' A ROW FROM A MEDIA SERVER NEVER COUNTS, and this is the trigger rather
    ' than the task, which matters. EnrichTask heals art and names off an
    ' Xtream panel and now skips media servers outright — so a media
    ' favourite with no picture is a row it can never fix, and left in this
    ' test it would ask for a whole-catalogue pull against the member's IPTV
    ' panel every single time Home was built, forever. A media favourite
    ' arriving from the phone carries no title on the wire on purpose, so
    ' this is the ordinary case and not a rare one.
    needs = false
    for each c in LoadFavoriteChannels()
        if not IsMediaSrcToken(ItemSrcToken(c))
            if ToStr(c.name) = "" or ToStr(c.logo) = "" then needs = true
        end if
    end for
    for each v in LoadFavoriteVod()
        if not IsMediaSrcToken(ItemSrcToken(v))
            if ToStr(v.icon) = "" then needs = true
        end if
    end for
    if not needs then return
    m.enrichStarted = true
    task = CreateObject("roSGNode", "EnrichTask")
    task.observeField("done", "onEnrichDone")
    m.enrichTask = task
    task.control = "RUN"
end sub

sub onEnrichDone(event as object)
    try
        onEnrichDoneInner(event)
    catch e
        GuardFailed("home/onEnrichDone", e)
    end try
end sub

sub onEnrichDoneInner(event as object)
    res = event.getData()
    ' refreshKeepingHomeFocus(), NOT refresh(): the rebuild destroys the focused
    ' grid, and this fires a few seconds into a session. Calling bare refresh()
    ' here left focus on a dead node - the "highlight vanishes, keys do nothing,
    ' must hit Home" report on v1.0.32.
    if res <> invalid and res.changed = true then refreshKeepingHomeFocus()
end sub

' ---- Kwick Picks (Because you watched) --------------------------------------
' Seeds from the newest recently-watched movie/series and recommends other
' unwatched titles from its category. Runs off-thread; the row is appended
' when the task answers.
sub startPicks()
    if not GetPrefBool("pref_show_picks", true) then return
    ' Seed from the newest movie/series watched on ANY source, then ask
    ' THAT source's catalog for recommendations — its ids only mean
    ' anything on its own panel.
    recents = LoadRecentVod()
    if recents.count() = 0 then return
    seed = recents[0]
    m.seedSrc = ToStr(GetField(seed, "src"))
    seedProv = ProviderForSrcToken(m.seedSrc)
    if seedProv = invalid or ToStr(seedProv.ptype) = "m3u" then return

    scope = "movies"
    action = "get_vod_streams"
    if ToStr(seed.kind) = "series"
        scope = "series"
        action = "get_series"
    end if

    ' Exclusions must be same-source AND same-kind — a watched id from
    ' another source could accidentally exclude an unrelated title here.
    watched = []
    for each r in recents
        if ToStr(r.kind) = ToStr(seed.kind) and ToStr(GetField(r, "src")) = m.seedSrc then watched.push(ToStr(r.id))
    end for

    ' Hidden/locked category prefs are NAMES now; the picks task filters by
    ' this panel's category ids, so translate through its name cache.
    hiddenNames = LoadHiddenCats(scope)
    if not ParentalUnlocked()
        for each l in LoadLockedCats(scope)
            hiddenNames.push(l)
        end for
    end if
    cache = loadCatNameCache(scope, ToStr(seedProv.id))
    ' Adult categories are never a source of picks unless the member has
    ' allowed them (certification 6.3) — see the Adult block in GuideMeta.brs.
    ' The names come off this source's own cache, which is the only list of
    ' its categories this screen has.
    if not AdultCatsAllowed()
        for each cid in cache
            nm = ToStr(cache[cid])
            if IsAdultCatName(nm) then hiddenNames.push(nm)
        end for
    end if
    hidden = []
    for each nm in hiddenNames
        cid = catNameToId(cache, ToStr(nm))
        if cid <> "" then hidden.push(cid)
    end for

    m.picksTask = CreateObject("roSGNode", "KwickPicksTask")
    m.picksTask.url = XtreamApiUrl(seedProv, action)
    m.picksTask.kind = ToStr(seed.kind)
    m.picksTask.seedId = ToStr(seed.id)
    m.picksTask.watchedJson = FormatJson(watched)
    m.picksTask.hiddenCatsJson = FormatJson(hidden)
    m.picksTask.observeField("result", "onPicksResult")
    m.picksTask.control = "RUN"
end sub

sub onPicksResult(event as object)
    try
        onPicksResultInner(event)
    catch e
        GuardFailed("home/onPicksResult", e)
        ' Focus deliberately not touched. If the fault landed after
        ' buildRows(), the row nodes have been replaced and whatever had focus
        ' is gone - but putting focus back from in here means guessing which
        ' row, and guessing wrong moves the highlight under the member's
        ' thumb. A press of Back or Left still leaves the screen, and the next
        ' time focus arrives onFocusIn puts it somewhere real.
    end try
end sub

sub onPicksResultInner(event as object)
    res = event.getData()
    if res = invalid or res.ok <> true then return
    items = ToArray(res.items)
    if items.count() = 0 then return
    ' Don't duplicate the row if a later refresh already added it.
    for each d in m.rowDefs
        if d.title = "Kwick Picks" then return
    end for
    picks = []
    for each it in items
        picks.push({ kind: ToStr(it.kind), id: ToStr(it.id), name: ToStr(it.name), icon: ToStr(it.icon), ext: ToStr(it.ext), url: "", src: ToStr(m.seedSrc) })
    end for
    ' Preserve content focus across the rebuild if a row currently has it.
    hadFocus = false
    for each g in m.rowGrids
        if g.hasFocus() then hadFocus = true
    end for
    ' KWICK PICKS IS THE ONE ROW NOT BUILT WITH THE OTHERS. Its task answers
    ' after refresh() and buildRows() have already run, so pushing it on the
    ' end put it last on Home whatever the member's order said. It now goes in
    ' at its ordered place — in front of the first row that ranks after it.
    m.rowDefs = insertRowDefInOrder(m.rowDefs, { title: "Kwick Picks", items: picks, rid: "kwickPicks" })
    buildRows()
    if hadFocus and m.rowGrids.count() > 0
        if m.rowIndex >= m.rowGrids.count() then m.rowIndex = 0
        m.rowGrids[m.rowIndex].setFocus(true)
        scrollToRow(m.rowIndex)
    end if
end sub

' ---- Posters for films, tiles for channels (2026-08-25) ---------------------
'
' THE OWNER'S WORDS: "lets change the tiles on the home page that use posters
' to actually show posters the way android does", and, twice, "tv channels
' look fine though."
'
' Home used to draw EVERY row with ChannelCard — a 284x206 landscape tile with
' the artwork letterboxed inside it. That is right for a channel, whose logo
' is landscape, and wrong for a film, whose cover is 2:3 portrait: the poster
' was squeezed into a wide grey box with dead space either side. Rows of films
' and shows are now drawn with PosterCard, the same card the VOD grid was
' rebuilt onto earlier today — artwork edge to edge at 2:3, title left-aligned
' underneath. Channel rows are untouched, down to the pixel.
'
' >>> HOW A ROW DECIDES: rowIsPosters() below, from the ITEMS, never the name.
'
' >>> WHAT IT COSTS IN TEXTURE MEMORY, which is the reason this is not just a
'     look-and-feel change. A film cover drawn in a channel tile is held at
'     whatever resolution the provider chose to send: a 1000x1500 cover is
'     6,000,000 bytes against a budget of roughly 90MB, and this app has five
'     out-of-memory crash reports. A Home page of three VOD rows was asking for
'     about 86MB of covers on its own. PosterCard pins the decode to the 232x348
'     it actually draws (322,944 bytes, whatever the source), so the same three
'     rows come to about 5.5MB — the same fix, and the same arithmetic, as the
'     VOD grid. (ChannelCard now pins loadHeight=140, and the TV Guide's own
'     channel logo pins loadHeight=76 as of v1.0.33 — the last uncapped decode.)
'     Channel rows keep the uncapped decode they have always had; a station
'     logo is small, and ChannelCard is not this lane's file to change.
'
' >>> AND WHAT THE ROW ADDS (corrected 2026-08-26). A poster row draws SEVEN
'     cards — six whole and the peek at the seventh, which is a fully decoded
'     card however little of it is on screen. Per card the ceiling is
'     unchanged, because PosterCard still pins its own decode:
'
'         2:3 cover   232 x 348 x 4 =   322,944 bytes   (0.31 MB)
'         16:9 cover  619 x 348 x 4 =   861,648 bytes   (0.82 MB), worst case
'
'         per poster row   6 cards -> 1.85 MB      7 cards -> 2.16 MB
'         four such rows           -> 7.4  MB              -> 8.6  MB
'         same, all 16:9 covers    -> 19.7 MB              -> 23.0 MB
'
'     So the widest realistic Home page — Continue Watching, Favorite Movies &
'     Series, a VOD Favorite List and Kwick Picks — goes up by about 1.2 MB
'     over the old six-across page, against a budget of roughly 90 MB. Every
'     row on the page counts, not just the two that are on screen: Home builds
'     all of its rows at once. An ArrayGrid keeps a small recycling pool
'     beyond what it draws, so read those figures as a floor of about 7 live
'     cards per row and a ceiling nearer 9 (2.9 MB a row at worst).
'
'     Correcting the viewport from 1800 to 1690 GIVES 0.31 MB A ROW BACK — one
'     fewer card is live per row — so this page is about 1.2 MB lighter than
'     the version that ran off the right-hand edge.
'
'     THE ROUNDED CORNERS COST 7,056 BYTES FOR THE WHOLE APP, not per card.
'     images/card_round.9.png is a 42 x 42 nine-patch (tools/make_card_art.py)
'     at 42 x 42 x 4 = 7,056 bytes of texture, decoded ONCE however many
'     posters point at it and stretched to card size for free. The focus ring
'     adds nothing at all: it is images/card_edge.9.png, the channel tile's own
'     edge, already resident. That is 0.008% of the budget, and it is the whole
'     reason the corners are a nine-patch overlay rather than a MaskGroup —
'     see PosterCard.xml, where the MaskGroup arithmetic is written out.
'
' ---- Row geometry -----------------------------------------------------------
'
' Rows are no longer all one height, so the layout is laid down here as two
' arrays (m.rowTops, m.rowHeights) and everything else looks the answer up.
'
'   channel row : 50 (title line) + 206 (tile)   = 256  -> pitch 310  UNCHANGED
'   poster row  : 50 (title line) + 348 (poster) = 398  -> pitch 452
'                  (348, not 384: the card lost its caption line when the
'                   title moved INSIDE the artwork, shown only on focus)
'
' The 54px gap between rows is the gap Home has always had (310 - 256), so a
' page of nothing but channel rows lays out exactly where it laid out before.
'
' Nothing collides with the Media Bar (y=112..442) or the page dots (450..460):
' the first row still starts at m.rowsTop, which buildMediaBar() sets to 470
' when the panel is up and 130 when it is not, and only the FIRST row's top is
' pinned there.
'
' What fits on a 1080 screen, with the visible band running 130..1060:
'   panel up   — one poster row (470..904) with the next row's title and the
'                top of its cards showing underneath, or two channel rows as
'                before (470..726, 780..1036).
'   panel down — two poster rows (130..564, 618..1052), or three channel rows.
'
' ---- HOW WIDE A POSTER ROW IS (corrected 2026-08-26, second pass) -----------
'
' THE OWNER'S WORDS: "it only shows me 6 titles but when i have more then 6
' titles in that row you cant tell at all. 8 titles would be nice instead,
' with a half faded image on the right".
'
' >>> THE SCREEN IS NOT 1920 WIDE IN HERE. THAT IS THE WHOLE CORRECTION. <<<
'
' HomeScreen is not the screen. It is dropped into AppShell's content Group,
' and that Group sits at translation [110, 0] (AppShell.xml:24) so the sidebar
' rail has the left-hand 110px to itself. EVERY x written in this file is
' therefore 110px further right on the actual television than it reads here.
'
'   usable width in here   1920 - 110 = 1810
'   left margin            x = 60      (170 absolute)
'   right margin to match  ends at 1750 (1860 absolute)  -> 1690 of viewport
'
' 1690 is not a new number invented here: it is what MediaBar.xml already
' uses for the panel's own width, in the same coordinate space, from the same
' x=60 (barHost is at [60, 112]), and its edgeRight comment says in as many
' words that "1690 is where every row underneath ends too". The profile
' button in HomeScreen.xml lands its right edge on 1750 for the same reason.
'
' The FIRST pass of this row set the viewport to 1800 and wrote that it "ends
' at 1860, the same 60px margin on the right". That arithmetic was done as if
' this file owned a 1920-wide screen. 60 + 1800 = 1860 in HERE is 1970 on the
' television, so the row ran 50px off the right-hand edge, had no right margin
' at all, and showed about 14px of its last card instead of 64. Confirmed on
' a device screenshot before this pass: the first poster's left edge measured
' at absolute x=170, and 170 + 7 x 248 = 1906, i.e. 14px short of the edge.
'
' WHAT ACTUALLY FITS IN 1690, at the card and gutter this lane does not own
' (PosterCard is 232 wide; the gutter is 16, SportsScreen's own row gutter):
'
'   pitch      248            (232 card + 16 gutter)
'   card k     starts at k x 248
'   6 whole    232 + 5x248 = 1472   ends at 1532 in here, 1642 absolute
'   7th card   starts 6x248 = 1488  (1598 in here) and the viewport stops at
'              1690, so 202px of it is drawn — 87% of a poster
'
' >>> SO IT IS SIX WHOLE POSTERS AND 202px OF A SEVENTH. Seven titles on
'     screen, not eight, and the seventh is nearly whole. <<<
'
' SEVEN WHOLE CARDS CANNOT BE HAD AT ANY SENSIBLE GUTTER. Seven of them need
' 1624px before a single gap is added, which leaves 66px to share over six
' gaps — an 11px gutter, cards all but touching, and then not one pixel left
' over to hint that the row keeps going. That is worse than what is here.
'
' >>> A 202px PEEK IS A JUDGEMENT CALL AND IT IS THE OWNER'S, NOT THIS
'     FILE'S. <<< 87% of a card does not read as "there is more over here";
'     it reads as a whole card that something has sliced the end off, and the
'     rounded corners added in this same pass make that worse, because the
'     cut card is the one card in the row with two square corners. The peek
'     is set by the GUTTER, which is not this lane's to change:
'
'       gutter 16 (today)  6 whole + 202px  (87% — a sliced card)
'       gutter 24          6 whole + 154px  (66%)
'       gutter 30          6 whole + 118px  (51% — literally the "half
'                                            image" that was asked for)
'       gutter 40          6 whole +  58px  (25% — a quarter, which is the
'                                            proportion the first pass aimed
'                                            at when it thought it had 1800)
'
' Nothing above changes the number of WHOLE cards; it only changes how much
' of the seventh is showing. Left at 16 until it is ruled on.
'
' ---- AND YES, 1860 IS PAST TITLE-SAFE. CHECKED 2026-08-27. LEAVE IT. -------
'
' This row has now been flagged twice as running past Roku's 5% title-safe
' margin. It does, by 36px, and it is BENIGN. Writing the whole subtraction
' down so it is not flagged a third time:
'
'   title-safe (Roku's 5%)         96 .. 1824 absolute
'   the same box in THIS file      -14 .. 1714 local   (subtract the 110)
'   this row                        60 .. 1750 local
'                                  170 .. 1860 absolute
'   overshoot                       36px
'
' >>> THE TRAP IS THE 110, IN BOTH DIRECTIONS. <<< The first pass compared a
' LOCAL number to an ABSOLUTE title-safe edge and made the row too wide; it
' would be just as wrong to compare 1750 to 1824, decide there are 74px
' spare, and make it wider again.
'
' WHAT IS IN THE 36px: only the part-card. The seventh card is drawn
' 1708..1860 absolute and is ALREADY clipped to 202px by the viewport - it
' exists to say "this row keeps going" and is meant to be cut. 116px of it is
' inside title-safe on the worst-overscanning set, which is nearer the "half
' faded image" that was asked for than what a set with no overscan shows. No
' whole card is lost. No text is cropped: the title draws only on the FOCUSED
' card, and floatingFocus slides the row rather than letting focus sit on the
' clipped edge card, so neither the title nor PosterCard's orange ring ever
' reaches out there.
'
' WHAT IT WOULD COST TO "FIX": pulling the viewport to 1654 (ending on 1824)
' does NOT cost a whole card - it is still six whole, with the peek going
' 202px -> 166px. The real cost is alignment. 1690 is the Media Bar panel's
' width in this same coordinate space (MediaBar.xml:6), and the bar sits
' directly above these rows; narrowing the rows alone would leave every row
' ending 36px short of the bar above it, which is visible. The bar's own last
' 90px is fade_right.png, a gradient to transparent, so the bar has nothing
' readable out there either.
'
' Benefit zero, cost a visible misalignment. Not changed.
'
' A poster row does not line up with a channel row on the right (1750 against
' 1576) and is not meant to: a channel row STOPS at its last tile and is
' complete, a poster row RUNS OFF the page and has to look like it does.
' Channel rows stay 5 across at 284 x 206, exactly as they were.

' ---- Does this row draw posters, or landscape tiles? ------------------------
'
' >>> THE RULE: a row draws posters when EVERY item in it is a film or a show.
'     One channel anywhere in the row and the whole row keeps tiles. <<<
'
' Decided from the ITEMS — it.kind, which normChannel() stamps as "channel"
' and normVod() carries through as "movie"/"series" — and never from the row's
' TITLE. Titles cannot be trusted here: a Favorite List is named by the member
' and can be called anything at all, and the two merged rows (GAP G9/G10) are
' called "Recently Watched" and "Favorites" whatever they happen to hold.
'
' WHY "EVERY", NOT "ANY". A MarkupGrid has ONE itemComponentName, so a row
' holding both kinds has to pick a single card and something loses. The
' owner's ruling is that channels look right as they are and must not change
' ("tv channels look fine though"), so the loser in a mixed row is the film —
' which is exactly what a mixed row looks like today, i.e. no regression —
' rather than the channel. PosterCard *can* be told to fit a landscape logo
' whole instead of cropping it (its artFit field, which Search uses for its
' channel row), but that still leaves a wide logo floating in a tall portrait
' plate, which is a change to how channels look, and that is the one thing
' this job is not allowed to do.
'
' It falls out of the rule that:
'   * Recently Watched Channels, Favorite Channels     -> tiles, untouched
'   * Continue Watching, Favorite Movies & Series,
'     Kwick Picks, an all-VOD Favorite List            -> posters
'   * a Favorite List holding channels AND films       -> tiles
'   * either merged row, while it has a channel in it  -> tiles
'
' The last two are the arguable ones. The merged rows agree with the phone,
' which draws both halves of its own merged rows as small square tiles and
' never mixes two shapes inside one row (home_screen.dart:650-672 and
' :712-724). The mixed Favorite List is where this differs from the phone,
' which draws every Favorite List row as posters regardless of what is in it
' (:761) — it can afford to, because its list is a Flutter ListView that
' builds each item its own way and has no single "item component" to choose.
function rowIsPosters(def as object) as boolean
    if def.items.count() = 0 then return false
    for each it in def.items
        if ToStr(it.kind) = "channel" then return false
    end for
    return true
end function

' ---- Read the member's place off the rows that are about to be destroyed ----
'
' Called from the TOP of buildRows(), before a single node comes down. Every
' live row is asked where its highlight is sitting and the answer is filed
' under that row's title; whichever row actually holds focus is remembered
' separately so the rebuild can find it again even if the row has moved up or
' down the page.
'
' WHY IT IS READ HERE AND NOT TRACKED ON EVERY KEY PRESS. The obvious
' alternative is to observe itemFocused/rowItemFocused on each row and write
' the column down as the member moves. That is work on every single arrow
' press (certification 3.5, 250ms) for no gain, AND it is racy: a freshly
' created grid reports item 0 through that same observer, and SceneGraph
' delivers observer callbacks on the message loop rather than inline, so the
' spurious 0 arrives AFTER the rebuild has finished and overwrites the very
' value it was supposed to protect. Reading the nodes at teardown is exact,
' costs nothing until a rebuild, and needs no guard flag.
sub captureRowFocus()
    if m.rowGrids.count() = 0 then return
    ' The row the member is on, even when nothing on Home holds real focus —
    ' which is the normal case here, because onDetailClosed() and
    ' onPlayerClosed() call refresh() while focus is still off this screen.
    if m.focusZone = "rows" and m.rowIndex >= 0 and m.rowIndex < m.rowTitles.count()
        m.focusRowTitle = m.rowTitles[m.rowIndex]
    end if
    for i = 0 to m.rowGrids.count() - 1
        g = m.rowGrids[i]
        if g <> invalid and i < m.rowTitles.count()
            col = 0
            if m.rowIsList[i] = true
                ' RowList answers with [row, column]; there is only ever one
                ' row in a Home RowList, so the column is all we want.
                f = g.rowItemFocused
                if f <> invalid and f.count() >= 2 then col = f[1]
            else
                col = g.itemFocused
            end if
            if col < 0 then col = 0
            m.rowCols[m.rowTitles[i]] = col
            if g.hasFocus() then m.focusRowTitle = m.rowTitles[i]
        end if
    end for
end sub

sub buildRows()
    ' MUST be first — it reads the nodes the next three lines destroy.
    captureRowFocus()
    while m.rowsContainer.getChildCount() > 0
        m.rowsContainer.removeChildIndex(0)
    end while
    m.scroller.translation = [0, 0]
    m.rowsContainer.translation = [0, 0]
    m.rowGrids = []
    m.rowTitles = []
    m.rowIsList = []
    m.rowTops = []
    m.rowHeights = []

    if m.rowDefs.count() = 0
        ' The empty line only belongs here when the whole page is empty —
        ' with the Media Bar up there is plainly something on screen.
        m.emptyLabel.visible = (m.bar = invalid)
        m.emptyLabel.text = "Watch a few channels and your recents, favorites, and lists will show up here."
        return
    end if
    m.emptyLabel.visible = false

    y = m.rowsTop
    shape = ""
    for i = 0 to m.rowDefs.count() - 1
        def = m.rowDefs[i]
        posters = rowIsPosters(def)
        ' ---- The heading, as a shell prompt --------------------------------
        ' "❯ ~/favorites/movies ls" instead of "Favorite Movies", which is
        ' what the Android app's terminal skins do with a row title
        ' (lib/ui/screens/home_screen.dart:809 -> TerminalPromptTitle). The
        ' path is spelled out in words, so nothing here is a glyph the member
        ' has to decode; the "❯" is decoration in front of it, and it was
        ' read out of JetBrains Mono's character map before being used -
        ' Roboto does not have U+276F and would draw a box.
        '
        ' A LayoutGroup, because Roku's Label has no rich text and the two
        ' halves are different colours and weights. Horizontal, no spacing -
        ' the gap is a space carried inside the strings, so the two Labels
        ' butt together the way one line of terminal output would.
        '
        ' Nothing in this file walks m.rowsContainer's children by index
        ' (they are cleared wholesale at the top of this sub and the grids
        ' are tracked in m.rowGrids), so swapping one Label for a group of
        ' two is contained. m.rowTops is measured from `y` arithmetic, not
        ' from this node, and the 50px allowed for a heading has not moved.
        pr = ShellPrompt(def.title)
        title = m.rowsContainer.createChild("LayoutGroup")
        title.layoutDirection = "horiz"
        title.vertAlignment = "center"
        title.itemSpacings = [0.0]
        title.translation = [60, y]
        promptPath = title.createChild("Label")
        promptPath.text = pr.arrow + pr.path
        promptPath.font = m.titleFont
        promptPath.color = m.theme.accent
        promptCmd = title.createChild("Label")
        promptCmd.text = pr.cmd
        promptCmd.font = m.titleCmdFont
        promptCmd.color = m.theme.textSecondary

        ' Set once per row, read on every item below. A row flagged allFav is
        ' entirely favourites, so its posters draw no heart.
        hideHearts = (GetField(def, "allFav") = true)

        if posters
            shape = shape + "P"
            ' >>> A CAROUSEL, NOT A GRID (2026-08-26). See the "Row geometry"
            '     note above for the arithmetic; the short version is that a
            '     MarkupGrid can only ever draw WHOLE columns, so it can never
            '     show the half card at the edge that says "this row keeps
            '     going". RowList clips its row to an arbitrary width and is
            '     the node built for this — VodScreen and SearchScreen have
            '     used one for their poster rows all along.
            grid = m.rowsContainer.createChild("RowList")
            grid.itemComponentName = "PosterCard"
            ' The ROW's box: 1690 wide from x=60, so it ends at 1750 HERE and
            ' at 1860 on the television — the same 60px margin on the right
            ' that the page has on the left. 348 tall is the card, unchanged.
            '
            ' 1690, NOT the 1800 this shipped with. Everything in this file is
            ' drawn 110px right of where it reads, because AppShell puts the
            ' content Group at [110, 0]; 60 + 1800 was 1970 on a 1920 screen
            ' and the row ran off the edge. The full working is in the "HOW
            ' WIDE A POSTER ROW IS" block above, including how many cards this
            ' actually fits (six whole and 202px of a seventh) and what the
            ' gutter would have to be to change that.
            '
            ' 1860 absolute IS 36px past the 1824 title-safe edge, deliberately
            ' - only the already-clipped part-card is out there, and narrowing
            ' this would misalign every row with the Media Bar above it. The
            ' full working, and the 110px subtraction that makes this look like
            ' a bug when it is not, are in the "AND YES, 1860 IS PAST
            ' TITLE-SAFE" section of that same block. Do not re-flag it.
            grid.itemSize = [1690, 348]
            grid.rowItemSize = [[232, 348]]
            ' 16px gutter — the same one SportsScreen.xml:56 uses for its own
            ' row. It is the only slack in the row (the card is 232 and is not
            ' this lane's file to shrink) and it is what sets how much of the
            ' seventh card peeks past the edge: 298 - 6 x gutter, so 202px at
            ' 16 and 118px (half a poster) at 30. See the block above; that
            ' call is the owner's.
            grid.rowItemSpacing = [[16, 0]]
            ' Home draws its own title Labels (they are what m.rowTops is
            ' measured from), so the RowList must not draw a second one.
            grid.showRowLabel = [false]
            ' >>> floatingFocus ON BOTH AXES, DELIBERATELY. <<<
            ' Roku's default for an ArrayGrid is "fixedFocusWrap", and this
            ' codebase has been bitten by it twice already — see the comments
            ' in MultiViewPicker.xml:60-63 and SubtitlePickerScreen.xml:31-32.
            ' Two things go wrong here with the default:
            '   * HORIZONTALLY it wraps, so Right on the last poster in the
            '     row jumps the highlight back to the FIRST poster. That is
            '     the second half of the owner's "snaps back to the first
            '     option in the row" report and it is not a race at all.
            '   * VERTICALLY a one-row list can wrap onto itself and SWALLOW
            '     Down, which would break Home's own row-to-row navigation in
            '     onKeyEvent below.
            ' floatingFocus does neither: the highlight moves through the
            ' visible cards and the row only slides once it reaches the edge,
            ' which is also the "push left like a carousel" the owner asked
            ' for.
            ' There is deliberately no "wrap" field set here: ArrayGrid has
            ' none, and assigning one only logs a device warning — measured,
            ' see the same note in MultiViewPicker.xml. floatingFocus alone
            ' is what stops the wrap.
            grid.rowFocusAnimationStyle = "floatingFocus"
            grid.vertFocusAnimationStyle = "floatingFocus"
            ' >>> THE RING IS DRAWN BY THE CARD, NOT BY THE LIST. Settled on
            '     the television 2026-08-26 after both ways were tried. <<<
            '
            ' Home's posters have 8px corners now (the owner: "lets just round
            ' the corners of the posters liek we did the tiles"), and the
            ' list's native ring cannot serve them. THREE reasons, all of them
            ' properties of the native path rather than of any bitmap:
            '
            '   * IT CANNOT BE TINTED. focusBitmapUri is the whole interface -
            '     there is no blendColor beside it. images/focus_ring.9.png
            '     gets away with that by having the orange BAKED INTO its
            '     pixels (255,158,69). Everything tools/make_card_art.py writes
            '     is white-with-alpha and coloured at draw time, so handed to
            '     the native path it renders WHITE. That is exactly what the
            '     television showed.
            '   * IT OUTSETS. >>> THIS ANSWERS THE QUESTION THIS FILE AND
            '     PosterCard.xml HAVE BOTH CARRIED FOR WEEKS. <<< Roku draws
            '     the native focus bitmap OUTSIDE the item's box, not on it -
            '     the owner saw "a space inbetween the indicator and the
            '     image". No more guessing in either file, and it confirms the
            '     channel rows below were right to turn it off for a card whose
            '     ring has to sit on the tile.
            '   * ITS CORNER DOES NOT MATCH. focus_ring.9.png's arc is about
            '     6px and a nine-patch corner never stretches, so it stays a
            '     near-square frame at any card size.
            '
            ' PosterCard therefore draws the ring itself, from
            ' images/card_edge.9.png - ChannelCard's OWN focus edge, the same
            ' file, so 8px corners and a 3px stroke tinted to
            ' m.theme.focusHighlight. The owner asked for parity with the tiles
            ' ("the same as the tiles, have the same thickness as tiles, and
            ' hug the image") and sharing the file is what guarantees it. Being
            ' a child of the card, it is inside the card's box by construction,
            ' so it hugs the artwork with no gap.
            '
            ' This needs PosterCard's `live` gate to work inside a RowList,
            ' which it did not until the same day - see PosterCard.brs
            ' onFocus(). No focusBitmapUri is set here at all: with
            ' drawFocusFeedback false it would do nothing, and leaving one
            ' would only invite someone to switch it back on.
            grid.drawFocusFeedback = false
            cardH = 348
            isList = true
        else
            ' Channel rows are UNCHANGED — same MarkupGrid, same 284x206
            ' tile, same 24px gutter, same five across ending at 1576.
            '
            ' They do not become carousels in this pass and the reason is not
            ' taste: ChannelCard's interface (ChannelCard.xml:52-58) declares
            ' gridHasFocus but NOT rowListHasFocus, and a RowList sets the
            ' latter. Dropped into a RowList the card would read its default
            ' gridHasFocus of true forever and keep drawing its focus ring
            ' after focus had left Home altogether. ChannelCard is read-only
            ' to this lane — see the report.
            shape = shape + "C"
            grid = m.rowsContainer.createChild("MarkupGrid")
            grid.itemComponentName = "ChannelCard"
            grid.itemSize = [284, 206]
            grid.itemSpacing = [24, 30]
            grid.numColumns = 5
            ' Same anti-wrap ruling as the poster rows above: Right on the
            ' last channel must not throw the highlight back to the first,
            ' and Down must reach the next row rather than being eaten.
            ' No "wrap" field here either — see the poster branch above.
            grid.horizFocusAnimationStyle = "floatingFocus"
            grid.vertFocusAnimationStyle = "floatingFocus"
            ' ChannelCard draws its own inset ring — grid items are clipped
            ' to their exact size and an outset native ring would lose its
            ' top and left edges on a 284-wide tile.
            grid.drawFocusFeedback = false
            cardH = 206
            isList = false
        end if
        grid.numRows = 1
        grid.translation = [60, y + 50]
        if isList
            grid.observeField("rowItemSelected", "onRowItemSelected")
        else
            grid.observeField("itemSelected", "onItemSelected")
        end if

        content = CreateObject("roSGNode", "ContentNode")
        ' A RowList's content is one level deeper than a grid's: root -> row
        ' -> items. A MarkupGrid hangs its items straight off the root.
        holder = content
        if isList then holder = content.createChild("ContentNode")
        for each it in def.items
            node = holder.createChild("ContentNode")
            node.title = it.name
            node.hdPosterUrl = PosterUrl(ToStr(it.icon))
            ' The tile's own key into the resume index, worked out here
            ' rather than on the card: the card is recycled and would redo
            ' it on every scroll, and building it needs the item's source,
            ' which only this side holds. Channels get "" back from
            ' FavVodKeyFor and so never draw a bar — a channel has no
            ' position to be partway through.
            '
            ' PosterCard reads this SAME field for both its resume bar and
            ' its favourite heart, so a poster row would gain a heart on
            ' anything already favourited. `hideFav` turns the heart off
            ' WITHOUT touching the bar - which is why it had to be a separate
            ' field rather than simply withholding favKey.
            '
            ' cardRound turns on PosterCard's 8px corners AND its own focus
            ' ring, together, as one switch — they are one look and half of it
            ' is broken (see the drawFocusFeedback block above). It rides on
            ' the ITEM for the same reason hideFav and artFit do: a
            ' RowList/MarkupGrid does not expose its item components, so a
            ' screen has no way to set a field on the card itself.
            '
            ' Set BOTH ways, every item, never left off: `posters` is false on
            ' a channel row and ChannelCard simply ignores a field it does not
            ' read, exactly as it already ignores hideFav.
            node.addFields({ favKey: FavVodKeyFor(it.kind, it.id, it.src), hideFav: hideHearts, cardRound: posters })
        end for
        grid.content = content
        m.rowGrids.push(grid)
        m.rowTitles.push(def.title)
        m.rowIsList.push(isList)

        ' >>> PUT THE MEMBER BACK WHERE THEY WERE. <<<
        ' The other half of the fix captureRowFocus() set up. Done HERE,
        ' immediately after the content lands and before anything gets focus,
        ' so the row is already drawn at the right place — there is no visible
        ' snap and no second layout pass. jumpToItem, not animateToItem: this
        ' is restoring a position, not travelling to one, and an animation on
        ' a rebuild is exactly the flicker this is meant to remove.
        col = 0
        if m.rowCols.doesExist(def.title) then col = m.rowCols[def.title]
        ' The row may have got shorter while they were away — a favourite
        ' removed on the phone, a list trimmed.
        if col > def.items.count() - 1 then col = def.items.count() - 1
        if col < 0 then col = 0
        if col > 0
            if isList
                grid.jumpToRowItem = [0, col]
            else
                grid.jumpToItem = col
            end if
        end if

        ' Where this row sits, for scrollToRow(). The row is its title line
        ' plus its cards; the 54 is the gap Home has always had between rows.
        m.rowTops.push(y)
        m.rowHeights.push(50 + cardH)
        y = y + 50 + cardH + 54
    end for

    ' >>> AND PUT THEM BACK ON THE RIGHT ROW. <<<
    ' m.rowIndex was already carried across a rebuild, but only as a NUMBER,
    ' which is wrong the moment a sync adds or drops a row above the one they
    ' were on — they would come back on whatever row had slid into that slot.
    ' The remembered title is authoritative; the number is only the fallback.
    if m.focusRowTitle <> ""
        for i = 0 to m.rowDefs.count() - 1
            if m.rowDefs[i].title = m.focusRowTitle then m.rowIndex = i
        end for
    end if
    if m.rowIndex >= m.rowGrids.count() then m.rowIndex = m.rowGrids.count() - 1
    if m.rowIndex < 0 then m.rowIndex = 0

    ' One line per change of shape, not per rebuild — refresh() runs after
    ' every sync, every player close and every detail close, and the log is
    ' read by hand.
    if m.rowShapeLogged <> shape
        m.rowShapeLogged = shape
        KLog("home", "rows " + shape + " (P=poster, C=channel tile), page is " + y.toStr() + "px tall")
    end if
end sub

' Channel rows (MarkupGrid) report a plain item index.
sub onItemSelected(event as object)
    try
        onItemSelectedInner(event)
    catch e
        GuardFailed("home/onItemSelected", e)
    end try
end sub

sub onItemSelectedInner(event as object)
    grid = event.getRoSGNode()
    rowIdx = rowIndexOf(grid)
    if rowIdx < 0 then return
    selectFromRow(rowIdx, grid.itemSelected)
end sub

' Poster rows (RowList) report [row, column]. There is only ever one row in a
' Home RowList, so the column is the item.
sub onRowItemSelected(event as object)
    try
        onRowItemSelectedInner(event)
    catch e
        GuardFailed("home/onRowItemSelected", e)
    end try
end sub

sub onRowItemSelectedInner(event as object)
    node = event.getRoSGNode()
    rowIdx = rowIndexOf(node)
    if rowIdx < 0 then return
    sel = node.rowItemSelected
    if sel = invalid or sel.count() < 2 then return
    selectFromRow(rowIdx, sel[1])
end sub

function rowIndexOf(node as object) as integer
    for i = 0 to m.rowGrids.count() - 1
        if m.rowGrids[i].isSameNode(node) then return i
    end for
    return -1
end function

sub selectFromRow(rowIdx as integer, itemIdx as integer)
    if rowIdx < 0 or rowIdx >= m.rowDefs.count() then return
    def = m.rowDefs[rowIdx]
    if itemIdx < 0 or itemIdx >= def.items.count() then return
    it = def.items[itemIdx]
    m.rowIndex = rowIdx
    m.focusZone = "rows"
    ' Write the place down HERE as well as at teardown. Opening a title is the
    ' one moment we know for certain where the member was standing, and the
    ' rebuild that runs when they back out of the detail screen happens while
    ' focus is off this screen entirely — belt and braces on the one path the
    ' member takes every single time.
    m.focusRowTitle = def.title
    m.rowCols[def.title] = itemIdx
    open(it)
end sub

sub open(it as object)
    scene = m.top.getScene()
    srcTok = ToStr(GetField(it, "src"))
    if it.kind = "channel"
        ' Channel hub first, like Android — Watch Live plays from there.
        m.detail = scene.createChild("ChannelDetailScreen")
        m.detail.channel = { streamId: it.id, name: it.name, logo: it.icon, url: it.url, src: srcTok }
        m.detail.observeField("closed", "onDetailClosed")
        m.detail.setFocus(true)
    else if it.kind = "series"
        m.detail = scene.createChild("SeriesDetailScreen")
        payload = { kind: "series", seriesId: it.id, name: it.name, icon: it.icon, src: srcTok }
        ' Which episode the Media Bar tile stood for, carried along with the
        ' show. Additive: the series page ignores keys it does not read, so
        ' this costs nothing until that page is taught to open on it.
        if type(it) = "roAssociativeArray" and it.doesExist("episodeId")
            payload.episodeId = ToStr(it.episodeId)
            payload.episodeLabel = ToStr(GetField(it, "episodeLabel"))
        end if
        m.detail.item = payload
        m.detail.observeField("closed", "onDetailClosed")
        m.detail.setFocus(true)
    else
        m.detail = scene.createChild("MovieDetailScreen")
        m.detail.item = { kind: "movie", streamId: it.id, name: it.name, icon: it.icon, ext: it.ext, src: srcTok }
        m.detail.observeField("closed", "onDetailClosed")
        m.detail.setFocus(true)
    end if
end sub

sub onPlayerClosed()
    try
        onPlayerClosedInner()
    catch e
        GuardFailed("home/onPlayerClosed", e)
        ' FOCUS MUST END UP SOMEWHERE REAL. The real handler takes the player
        ' off the scene first and only then rebuilds and hands focus back, so
        ' a fault in the middle leaves the player gone and focus nowhere -
        ' Home on screen with a remote that does nothing. This is not the
        ' focusedChild observer, so moving focus from here cannot recurse.
        m.top.setFocus(true)
    end try
end sub

sub onPlayerClosedInner()
    if m.player <> invalid
        m.top.getScene().removeChild(m.player)
        m.player = invalid
    end if
    refresh()
    m.top.setFocus(true)
    onFocusIn()
end sub

sub onDetailClosed()
    try
        onDetailClosedInner()
    catch e
        GuardFailed("home/onDetailClosed", e)
        ' Same as onPlayerClosed: the detail page has already been removed by
        ' the time anything below it can fault, so focus has to be put back or
        ' the member is left on a Home screen that answers nothing.
        m.top.setFocus(true)
    end try
end sub

sub onDetailClosedInner()
    if m.detail <> invalid
        m.top.getScene().removeChild(m.detail)
        m.detail = invalid
    end if
    refresh()
    m.top.setFocus(true)
    onFocusIn()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    try
        return onKeyEventInner(key, press)
    catch e
        GuardFailed("home/onKeyEvent", e)
    end try
    ' FALSE, NOT TRUE, ON A CAUGHT FAULT - the TV Guide's choice, not the
    ' channel page's. The key bubbles up to AppShell, so Back still walks out
    ' toward the exit confirmation and Left still reaches the sidebar. Return
    ' true and a Home screen that has started faulting swallows the member's
    ' only way off it; AppShell acts on nothing else, so every other key is a
    ' no-op either way.
    return false
end function

function onKeyEventInner(key as string, press as boolean) as boolean
    if not press then return false
    if key = "options"
        ' >>> THE WAY INTO THE PROFILE BUTTON FROM ANYWHERE ON HOME <<<
        ' * is a Roku idiom and a second route in. It is no longer the only
        ' one: the Media Bar hands Up back rather than swallowing it (see the
        ' "up" branch of MediaBar.onKeyEvent), so Up out of the panel reaches
        ' the Up branch below and lands on the profile button. This stays
        ' because it works from every focus zone including the rows, where
        ' Up means "the row above" and cannot mean anything else. MarkupGrid
        ' ignores * as well, so it works from there too.
        if m.hasProfileButton
            openProfilePicker()
            return true
        end if
        return false
    else if key = "back" or key = "left"
        ' Leaving the screen — don't leave a focus ring behind on a screen
        ' nobody is standing on.
        applyProfileFocus(false)
        m.top.backToNav = true
        return true
    else if key = "OK"
        if m.focusZone = "profile" and m.hasProfileButton
            openProfilePicker()
            return true
        end if
    else if key = "down"
        if m.focusZone = "profile"
            focusBelowProfile()
            return true
        end if
        ' Out of the Media Bar and into the rows underneath it. The panel
        ' passes Down up to here rather than handling it itself.
        if m.focusZone = "bar" and m.bar <> invalid
            if m.rowGrids.count() > 0
                m.focusZone = "rows"
                if m.rowIndex >= m.rowGrids.count() then m.rowIndex = 0
                m.rowGrids[m.rowIndex].setFocus(true)
                scrollToRow(m.rowIndex)
            end if
            return true
        end if
        if m.rowIndex < m.rowGrids.count() - 1
            m.rowIndex = m.rowIndex + 1
            m.rowGrids[m.rowIndex].setFocus(true)
            scrollToRow(m.rowIndex)
            return true
        end if
    else if key = "up"
        ' The profile button is the top of the page — nothing above it.
        if m.focusZone = "profile" then return true
        ' Up out of the Media Bar. The panel passes Up to here rather than
        ' handling it itself, exactly as it passes Down, so the profile
        ' button in the header is reachable on the D-pad from inside the
        ' panel and not only through the * shortcut.
        if m.focusZone = "bar" and m.hasProfileButton
            applyProfileFocus(true)
            m.focusZone = "profile"
            m.scroller.translation = [0, 0]
            m.keySink.setFocus(true)
            return true
        end if
        if m.focusZone = "rows" and m.rowIndex = 0 and m.bar = invalid and m.hasProfileButton
            applyProfileFocus(true)
            m.focusZone = "profile"
            m.scroller.translation = [0, 0]
            m.keySink.setFocus(true)
            return true
        end if
        ' Top row, and there is a panel above it.
        if m.focusZone = "rows" and m.rowIndex = 0 and m.bar <> invalid
            m.focusZone = "bar"
            m.scroller.translation = [0, 0]
            m.bar.setFocus(true)
            return true
        end if
        if m.rowIndex > 0
            m.rowIndex = m.rowIndex - 1
            m.rowGrids[m.rowIndex].setFocus(true)
            scrollToRow(m.rowIndex)
            return true
        end if
    end if
    return false
end function
