' Live TV — categories from get_live_categories (Xtream) or group-titles
' (M3U), channels per category, OK plays. Focus flow: category list <->
' channel grid, Back/Left returns toward the sidebar.

sub init()
    m.theme = KwickTheme()

    header = m.top.findNode("header")
    header.text = "Live TV"
    header.font = UiBoldFont(42)
    header.color = m.theme.textPrimary

    m.catList = m.top.findNode("catList")
    m.catList.observeField("itemFocused", "onCategoryFocused")
    m.catList.observeField("itemSelected", "onCategorySelected")

    m.grid = m.top.findNode("channelGrid")
    m.grid.observeField("itemSelected", "onChannelSelected")
    ' Watched ONLY to restart the dwell timer — see "What's on now for an
    ' Xtream channel" further down. Moving the cursor never fetches anything;
    ' stopping on a tile is what does.
    m.grid.observeField("itemFocused", "onChannelFocused")

    m.emptyLabel = m.top.findNode("emptyLabel")
    ' 26 -> 22, the biggest drop on this screen and the one with a reason. This
    ' label is only 1160px wide (the grid pane, not the whole screen) and the
    ' "no channel in this category matches" hint is ~187 characters BEFORE the
    ' member's own search text is quoted into it. At mono 26 three wrapped lines
    ' hold about 200 characters, so a typed query of any length would have run
    ' the sentence off the end; at 22 they hold about 237, which is what Roboto
    ' 26 gave.
    m.emptyLabel.font = UiFont(22)
    m.emptyLabel.color = m.theme.textSecondary

    ' Every configured source contributes to ONE merged lineup (Android
    ' model): same-named categories collapse into a single folder, channels
    ' inside carry their source, playback routes by it.
    ' LiveProviders(), not LoadProviders(): a Jellyfin/Emby holds no channels,
    ' and every non-M3U source here falls into the Xtream branch below.
    m.sources = LiveProviders()
    m.multi = (m.sources.count() > 1)
    m.srcLabels = {}            ' src token -> short source name (badges)
    ' src token -> the provider record itself. ProviderForSrcToken() re-reads
    ' the registry on every call, and this screen needs the answer whenever a
    ' caption is asked for; the whole list is already in m.sources, so the
    ' lookup is built once here instead. (Same rule as ChannelCard's note on
    ' registry reads while a grid is live.)
    ' "t" prefixes the token for the same reason ChannelCard's colour memo
    ' does: the KwickTV login's token is the empty string, and that makes a
    ' poor key.
    m.provBySrc = {}
    for each p in m.sources
        m.provBySrc["t" + SrcTokenFor(p)] = p
    end for
    m.categories = []           ' merged [{id(name), name, srcCats:[...]}]
    m.catAgg = {}               ' provId -> that source's category descriptors
    m.catPending = 0
    m.channelsByCat = {}        ' category NAME -> merged channel list
    ' The SAME folders, after the hidden/sort/reorder prefs have been applied
    ' to them. Worked out once per folder instead of once per arrow press —
    ' see the note at the top of fillGridInner. Trimmed beside m.channelsByCat.
    m.shownByCat = {}
    m.currentCatId = invalid    ' the folder on screen, once one is open
    m.xmltvWatch = false        ' watching a guide fetch somebody else began
    m.nowLogged = false         ' the one-line "captions are on" log
    m.inflight = {}

    ' ---- The guide chain (see the long note above startXmltv) --------------
    ' The member's own guides, in their own order, then each Xtream panel's
    ' own xmltv.php. Read ONE AT A TIME and merged first-writer-wins, then
    ' published to the globals in a single go. Same bookkeeping, same names
    ' and same rules as GuideScreen's chain, so whichever screen the member
    ' opens first leaves the globals in the same shape.
    m.gChain = []
    m.gChainIdx = 0
    m.gChainRunning = false
    m.gChainOk = 0
    m.gMergedById = {}
    m.gMergedAliases = {}
    m.gMergedProgrammes = 0
    m.gWantedJson = "[]"
    m.xmltvTask = invalid
    ' Which M3U sources have answered (parsed or failed). The chain waits for
    ' these before it decides there is no playlist guide to read — see
    ' liveGuideMayStart.
    m.m3uAnswered = {}

    ' ---- Captions for Xtream channels (see the long note lower down) -------
    m.nowTitles = []            ' guide-file caption per visible channel
    ' Index-aligned with m.nowTitles: does the loaded guide NAME this channel
    ' at all? A channel the guide covers is never asked about one at a time,
    ' even when the guide has no programme running on it this minute — the
    ' batched guide came from the same panel the single-channel call would go
    ' to, so asking again is asking the same source the same question. This
    ' is the same rule GuideScreen.applyXmltvToChannels follows.
    m.nowCovered = []
    m.epgTimer = invalid        ' the dwell timer; built on first use
    m.epgPending = {}           ' key -> true while its request is in flight
    m.epgInflight = 0
    m.epgCatCount = 0           ' asked so far in the folder on screen
    m.epgCatLogged = false
    m.epgSessLogged = false
    m.epgStartLogged = false
    ' Session-wide, because this screen is destroyed and rebuilt every time
    ' the member leaves Live TV and comes back (AppShell swaps the child).
    ' A per-screen cache would ask the panel for the same channel again on
    ' every visit, which is exactly the pattern this is meant to avoid.
    if m.global <> invalid
        if not m.global.hasField("liveNowById") then m.global.addFields({ liveNowById: {} })
        ' When each cached caption stops being true. Kept in its own map so
        ' the one the CARDS read stays a plain key->text lookup with no clock
        ' read in it — the cards run on every recycled tile, this does not.
        if not m.global.hasField("liveNowUntil") then m.global.addFields({ liveNowUntil: {} })
        if not m.global.hasField("liveEpgCount") then m.global.addFields({ liveEpgCount: 0 })
    end if
    m.load = invalid            ' the in-progress per-category fan-out
    m.loadGen = 0
    m.painted = false           ' progressive load (see mergeCategories)
    m.userMoved = false
    m.paintTimer = invalid

    ' ---- Building the channel grid a page at a time (see paintGridChunk) ---
    m.gridGen = 0               ' bumped by every repaint; stale passes die
    m.gridFillGen = -1          ' the generation the fill timer belongs to
    m.gridTimer = invalid       ' built on first use, like the two above
    m.gridShown = invalid       ' the folder the running fill is drawing
    m.gridTitles = invalid      ' its captions, index-aligned with gridShown
    m.gridContent = invalid     ' the content node the tiles are added to
    m.gridBuilt = 0             ' how many tiles of it exist so far
    m.gridLineup = []           ' the player's zap list, grown with the tiles
    m.player = invalid
    m.mvPicker = invalid        ' the Multi-View picker, while it is open
    m.mvScreen = invalid        ' the Multi-View grid, while it is open

    ' ---- Channel search (see the long note above setupFilterBar) -----------
    m.query = ""                ' what the member typed or said, as typed
    m.queryLc = ""              ' lowercased ONCE, never per channel
    m.kbDialog = invalid        ' the open keyboard dialog, or invalid
    m.kbEdit = invalid          ' its text box — what the microphone writes into
    m.kbHasClear = false        ' is "Show all" one of its buttons this time?
    m.pendingSet = false        ' a new query is waiting for the dialog to close
    m.pendingQuery = ""
    ' The chip is not a focusable node — it is drawn by this screen and the
    ' focus lives on m.top while it is "selected", the same arrangement the
    ' TV Guide uses for every one of its areas. onFocusIn has to know about
    ' that or it would hand focus straight back to the category list.
    m.filterFocus = false
    m.filterFrom = "cats"       ' which pane Down returns to

    ' ---- This screen going away (log key 0D722F) ---------------------------
    ' Which shell built this screen. AppShell numbers its shells on the global
    ' node (shellSerialNext) and a profile switch or a sign-out builds a new
    ' one, so a screen whose number no longer matches the current shell belongs
    ' to a profile nobody is on. Read HERE, in init, because it is the only
    ' moment it is certainly ours. invalid while the field does not exist, and
    ' then simply not tested. The whole story is in the note under onFocusIn.
    m.shellNo = invalid
    if m.global <> invalid and m.global.hasField("shellSerial") then m.shellNo = ToInt(m.global.shellSerial)

    m.top.observeField("focusedChild", "onFocusIn")
    ' Arriving on Live TV means the last screen's lineup is no longer what the
    ' member is looking at. Clear it here, before anything can be fetched, so a
    ' box with no sources at all — where loadCategories returns without ever
    ' reaching fillGrid — still leaves the player with nothing to step through
    ' rather than the TV Guide's last tab. See publishLiveLineup.
    publishLiveLineup([])
    setupFilterBar()
    loadCategories()
end sub

sub onFocusIn()
    try
        onFocusInInner()
    catch e
        GuardFailed("livetv/onFocusIn", e)
    end try
end sub

sub onFocusInInner()
    if liveScreenIsGone() then return
    ' While the search chip is the focused thing, focus is SUPPOSED to be on
    ' this Group — that is how onKeyEvent gets the presses. Without this
    ' guard, focusing the chip would bounce straight back to the categories.
    if m.filterFocus = true then return
    if m.top.hasFocus() then m.catList.setFocus(true)
end sub

' ---- THIS SCREEN IS GONE BUT ITS WORK IS NOT --------------------------------
'
' >>> READ THIS BEFORE ADDING ANY KIND OF "the screen is closing" NOTICE. <<<
'
' The first attempt at this fix had AppShell raise a tearDown field on the
' outgoing screen and a flag in here that every gate read. On the office stick
' that notice reached a Live TV screen that was alive and on display: the flag
' went up, every gate closed at once, the guide parsed and was never published,
' and every row of the TV Guide read "No guide data available". One wrong write
' to one field silently cost the member their whole guide.
'
' The notice is gone, and with it the field, the flag, and the two lines it
' needed in AppShell. Nothing tells this screen it has been removed. Instead
' every handler ASKS THE TREE at the moment it matters - see liveScreenIsGone()
' - which is a question a live screen cannot get wrong. The notice turned out
' to buy nothing the tree does not already answer, and it was the only part of
' the design that could fail towards "no guide" instead of towards "logged
' caught fault".

'
' LOG KEY 0D722F - Hisense 50R6, v1.0.40, 2026-10-05, and it killed the
' television. IN PLAIN WORDS: the member opened Live TV, the app started
' reading their guide (20 MB, and it took over two minutes to read on that
' set), and eight seconds later they walked off to Settings and switched
' profile. Two minutes after that the guide finished reading and the app tried
' to put the result onto a Live TV screen that had already been thrown away.
' The app closed itself and the member was dropped back to the Roku home
' screen.
'
' WHY IT COULD HAPPEN AT ALL. SceneGraph gives a screen no destructor, and
' AppShell replaces one with m.content.removeChild (AppShell.brs:466) with no
' notice to the screen either way. So this screen never learned it had gone,
' and four things it had set going outlived it: the XmltvTask it created and
' observed, the observer it planted on m.global (which is never collected), and
' two orphan Timer nodes. Every one of them points back in here.
' tearDownShell's own comment at AppShell.brs:228 names exactly this hazard for
' AppShell's own observers; the screens' own were never covered by it.
'
' THE MECHANISM. AppShell now raises a tearDown field on the outgoing screen,
' carrying the reason, exactly the way AppScene already raises AppShell's own
' tearDown (AppScene.brs:678). It is the only hook that can be certain: there
' is no other moment at which this component is still alive and knows it is
' leaving.
'
' AND THE GUIDE CHAIN IS DELIBERATELY NOT KILLED when the member navigates
' away. Walking from Live TV to Settings while a guide downloads is the common
' case, not the rare one, and that read is one request per launch whose answer
' every screen shares. Throwing it away would cost the member the guide and
' then cost them a second download of it, which is the last thing RK-018 needs.
' So the DATA half of the chain runs to the end and publishes; only the half
' that touches this screen's own nodes is switched off, by the gates.
'
' A PROFILE SWITCH IS THE ONE EXCEPTION, and it is handled where it can be
' proven rather than where it is announced: liveShellChanged() stops the chain
' starting its next download (runNextLiveGuide) and refuses the publish
' (finishLiveGuideChain), so the old profile's listings can never reach the new
' profile's globals. The cost of having no notice is that one download already
' in flight runs to completion and is then discarded - the same cost the build
' before this fix had, on a path the member reaches by switching profile
' mid-guide-read.

' Let the guide task go.
'
' THE OBSERVER IS THE POINT, not the memory the task itself holds. m.xmltvTask
' is an orphan node - created in runNextLiveGuide, never added to the scene,
' held by nothing but this reference - and a plain observeField on it is a hard
' reference from that node back into this screen. Exactly the shape, and
' exactly the treatment, of PlayerScreen.releaseDiagTask: observeFieldScoped is
' not the answer here the way it is for a recycled card, because this node is
' ours to destroy, so destroying it is.
'
' The "stop" is usually a no-op - the answer has landed and the task has ended.
' On the teardown path it may still be downloading, and a 20 MB request whose
' reply nobody will read is not one worth leaving open at the member's panel.
' Killing it mid-download leaves a part-written file on cachefs, which is
' already handled: XmltvTask.sweepOldGuides deletes any kwick_xmltv_* file
' older than twice its own download deadline on the next run.
'
' Safe to call from anywhere, including from inside the observer it is
' removing: by then the event has already been delivered.
sub releaseLiveGuideTask()
    if m.xmltvTask = invalid then return
    m.xmltvTask.unobserveField("result")
    m.xmltvTask.control = "stop"
    m.xmltvTask = invalid
end sub

' Is this screen still part of the app the member can see?
'
' >>> THIS ASKS THE TREE. IT DOES NOT TRUST A FLAG, AND THAT IS THE WHOLE
' POINT OF THE SECOND VERSION OF IT. <<<
'
' The first version returned true as soon as a flag set from outside this screen
' was raised, and that was a shipping blocker found on the office stick: the
' notice reached a Live TV screen that was alive and on display, the flag went
' up, all twenty-odd gates below closed at once, the guide parsed and was then
' never published, and every row of the TV Guide read "No guide data available".
' One wrong write to one field silently cost every member their listings. A flag
' that can be set wrongly must never be what twenty-three call sites hang off,
' so the flag, the field and the notice that raised it are all gone.
'
' So the question is asked of the thing that cannot be wrong: a screen the
' member is looking at is IN THE TREE. It has a parent and it has a scene. A
' screen that has been removed has neither. There is no way for a live screen
' to fail this test, whoever writes what to which field.
'
' BOTH NODE TESTS, because neither is verified on a device and they fail the
' same safe way. getParent() and getScene() both answer invalid for a
' parentless node per the documentation, and neither has been measured here.
' Taking either as proof of "gone" means:
'   * a FALSE POSITIVE is impossible - an attached node has both, so a live
'     screen is never gated off and the guide can never be lost this way;
'   * a FALSE NEGATIVE, if both turn out to answer non-invalid for a removed
'     node, costs only that the 0D722F callback reaches a dead screen again -
'     where the GuardFailed wrappers now catch it, name the line and leave the
'     member their app instead of killing the television.
' That is the right way round: the worst case is a logged caught fault, not a
' silently empty guide.
'
' NOTHING OUTSIDE THIS FUNCTION DECIDES THE ANSWER. There is no flag to set and
' no notice to send - if a future change wants to tell a screen it is closing,
' read the warning at the head of the teardown section first.
function liveScreenIsGone() as boolean
    if liveShellChanged() then return true
    if m.top.getParent() = invalid then return true
    if m.top.getScene() = invalid then return true
    return false
end function

' Has the app rebuilt its shell since this screen was made?
'
' A profile switch and a sign-out both do, and it is the one case where work
' still in flight must not only stop drawing but must not be PUBLISHED either:
' the listings belong to the profile that left. Kept separate from
' liveScreenIsGone() above because the two questions have different answers -
' a screen the member merely navigated away from is gone, but its guide is
' still the right guide.
function liveShellChanged() as boolean
    if m.shellNo = invalid then return false
    if m.global = invalid or not m.global.hasField("shellSerial") then return false
    return ToInt(m.global.shellSerial) <> m.shellNo
end function

' ---- Data ------------------------------------------------------------------

sub loadCategories()
    if m.sources.count() = 0 then return
    setBusy(true)
    m.catAgg = {}
    m.catPending = 0
    for each p in m.sources
        pid = ToStr(p.id)
        m.srcLabels[SrcTokenFor(p)] = ToStr(p.name)
        if ToStr(p.ptype) = "m3u"
            slots = m.global.m3uByProv
            if slots.doesExist(pid)
                ' Already parsed this session — its groups come for free.
                m.m3uAnswered[pid] = true
                m.catAgg[pid] = m3uGroupCats(slots[pid].channels)
            else
                m.catPending = m.catPending + 1
                task = CreateObject("roSGNode", "M3uTask")
                task.url = p.m3uUrl
                task.tag = pid
                task.observeField("result", "onM3uParsed")
                m.inflight["m3u_" + pid] = task
                task.control = "RUN"
            end if
        else
            m.catPending = m.catPending + 1
            task = CreateObject("roSGNode", "ApiTask")
            task.tag = pid
            task.url = XtreamApiUrl(p, "get_live_categories")
            ' See the note in GuideScreen: this answer gates the screen and
            ' several sources fetch at once, so it gets room to land.
            task.timeoutMs = 60000
            task.observeField("result", "onCategories")
            m.inflight["cats_" + pid] = task
            task.control = "RUN"
        end if
    end for
    if m.catPending = 0
        mergeCategories()
    else
        ' Same rule as the TV Guide: don't hold the category list hostage to
        ' the slowest source. Draw what has answered after a short grace
        ' period; late arrivals top it up unless the member has started
        ' browsing, in which case their place on screen wins.
        m.paintTimer = CreateObject("roSGNode", "Timer")
        m.paintTimer.duration = 6
        m.paintTimer.repeat = false
        m.paintTimer.observeField("fire", "onCatPaintTimer")
        m.paintTimer.control = "start"
    end if
end sub

sub onCatPaintTimer()
    try
        onCatPaintTimerInner()
    catch e
        GuardFailed("livetv/onCatPaintTimer", e)
    end try
end sub

sub onCatPaintTimerInner()
    if liveScreenIsGone() then return
    if m.painted = true then return
    got = 0
    for each pid in m.catAgg
        if m.catAgg[pid].count() > 0 then got = got + 1
    end for
    if got = 0 then return
    KLog("livetv", "drawing with " + got.toStr() + " of " + m.sources.count().toStr() + " source(s); the rest are still answering")
    mergeCategories()
end sub

' One M3U source's groups as category descriptors, playlist order.
function m3uGroupCats(channels as object) as object
    seen = {}
    out = []
    for each ch in channels
        g = ToStr(ch.group)
        if g = "" then g = "Uncategorized"
        if not seen.doesExist(g)
            seen[g] = true
            out.push({ catId: g, name: g })
        end if
    end for
    return out
end function

sub onCategories(event as object)
    try
        onCategoriesInner(event)
    catch e
        GuardFailed("livetv/onCategories", e)
    end try
end sub

sub onCategoriesInner(event as object)
    res = event.getData()
    pid = event.getRoSGNode().tag
    m.inflight.delete("cats_" + pid)
    raw = []
    cacheCats = []
    if res <> invalid and res.ok = true
        for each c in ToArray(res.data)
            cid = ToStr(GetField(c, "category_id"))
            nm = ToStr(GetField(c, "category_name"))
            raw.push({ catId: cid, name: nm })
            cacheCats.push({ id: cid, name: nm })
        end for
        ' Keep this source's id->name cache warm (legacy-pref translation +
        ' Kwick Picks both read it).
        '
        ' >>> GUARDED, AND SILENTLY. <<<
        ' Settings' Refresh row refuses a collapsed category list — a panel
        ' having a bad minute and answering with eleven where the member has
        ' hundreds — because that table is what parental locks and the
        ' hide/reorder lists translate through. THIS write is the same write,
        ' and without the same test the refusal lasts until the member opens
        ' Live TV, which is the next thing they do.
        '
        ' Same helper, not a second copy of the rule: two shrink tests in one
        ' app is how the phone and the television start giving one member two
        ' answers about one provider.
        '
        ' NO DIALOG HERE, and that is the difference from the Settings copy.
        ' There a member has deliberately pressed Refresh and a question is
        ' fair. Here a screen is opening — the member asked for nothing, so a
        ' modal on an ordinary launch after a bad provider minute would be
        ' worse than the thing it warns about. There is also nothing to ask:
        ' the cache is a translation table, not the member's own list, so
        ' keeping the good copy is right every time.
        '
        ' ONLY THE REGISTRY WRITE IS REFUSED — m.catAgg below still takes the
        ' list as served. The screen must show what the provider is actually
        ' offering right now; if a package really was cut, drawing a stale
        ' lineup would be a lie, and the cache holds {id: name} with none of
        ' the ordering or source refs the grid needs anyway. A stale table is
        ' harmless in the meantime: it is additive, the ids still in use still
        ' resolve, and dead ids are never looked up.
        offered = cacheCats.count()
        stored = CachedCategoryCount("live", pid)
        if IsDestructiveChannelShrink(stored, offered)
            KLog("livetv", "source " + ToStr(pid) + " offered " + offered.toStr() + " categories where " + stored.toStr() + " are cached - keeping the cached names, nothing overwritten")
        else
            SaveCatNameCacheFor("live", pid, cacheCats)
        end if
    end if
    m.catAgg[pid] = raw          ' a failed source contributes nothing, not a blank screen
    m.catPending = m.catPending - 1
    ' Everything above is bookkeeping and the registry name cache, which is
    ' worth keeping whoever is still watching. mergeCategories draws, so it is
    ' not for a screen that has gone.
    if liveScreenIsGone() then return
    if m.catPending <= 0 then mergeCategories()
end sub

sub onM3uParsed(event as object)
    try
        onM3uParsedInner(event)
    catch e
        GuardFailed("livetv/onM3uParsed", e)
    end try
end sub

sub onM3uParsedInner(event as object)
    res = event.getData()
    pid = event.getRoSGNode().tag
    m.inflight.delete("m3u_" + pid)
    ' Answered, whichever way it went. The guide chain waits on this and not
    ' on success: a playlist that could not be fetched has no url-tvg to
    ' contribute, and waiting for one that will never come would mean no
    ' guide at all.
    m.m3uAnswered[ToStr(pid)] = true
    if res <> invalid and res.ok = true
        chans = ToArray(res.channels)
        PublishM3uParse(pid, chans, ToStr(GetField(res, "tvgUrl")))
        m.catAgg[pid] = m3uGroupCats(chans)
    else
        m.catAgg[pid] = []
    end if
    ' PublishM3uParse above runs either way, and that is deliberate: it fills
    ' the session cache every screen reads, so a playlist that answered after
    ' the member walked off still saves the next screen a second download.
    ' Everything from here on draws, or claims the guide handshake.
    if liveScreenIsGone() then return
    m.catPending = m.catPending - 1
    ' Tried here as well as from mergeCategories. A playlist's url-tvg is only
    ' knowable once its parse lands, and mergeCategories bows out early once
    ' the member has started browsing — so without this a household whose
    ' playlist answered late could go the whole session with no guide.
    startXmltv()
    if m.catPending <= 0 then mergeCategories()
end sub

' The Android merge rule: same-named categories from different sources
' become ONE folder (exact name match); order is "whichever source listed
' it first", walking sources in the order they were added.
sub mergeCategories()
    setBusy(false)
    if m.paintTimer <> invalid then m.paintTimer.control = "stop"
    if m.painted = true and m.userMoved = true
        KLog("livetv", "a late source answered, but you're browsing - leaving the list as it is")
        return
    end if
    m.painted = true
    merged = []
    byName = {}
    for each p in m.sources
        pid = ToStr(p.id)
        if m.catAgg.doesExist(pid)
            for each c in m.catAgg[pid]
                nm = ToStr(c.name)
                if nm <> ""
                    if not byName.doesExist(nm)
                        entry = { id: nm, name: nm, srcCats: [] }
                        byName[nm] = entry
                        merged.push(entry)
                    end if
                    byName[nm].srcCats.push({ provId: pid, ptype: ToStr(p.ptype), catId: ToStr(c.catId), src: SrcTokenFor(p) })
                end if
            end for
        end if
    end for
    ' User prefs (hide/reorder/locks) apply to the merged list by name.
    ' Adult categories come out first and unconditionally (certification
    ' 6.3) — see the Adult block in GuideMeta.brs.
    m.categories = ApplyCatPrefs("live", FilterAdultCats(merged), false)
    startXmltv()
    fillCategoryList()
end sub

' ---- The shared guide, read once per launch ---------------------------------
'
' THIS USED TO READ ONE GUIDE AND ONE ONLY, and that was a bug the moment the
' TV Guide learned to read several. A source can be pointed at a LIST of
' guides in an order the member sets (Store.brs: ProviderCustomEpgGuides), and
' GuideScreen reads that whole list one after another and merges them
' first-writer-wins. This screen read ProviderCustomEpgUrl — the FIRST address
' only — and it shares the same one-fetch-per-launch handshake, so whichever
' screen got there first decided what everybody got. Open Live TV before the
' TV Guide and the member's second, third and fourth guides were never read at
' all, all session, on every screen. Same handshake, same globals, two
' different answers depending on the order somebody happened to press buttons.
'
' So this screen now builds THE SAME CHAIN, in the same order, out of the same
' Store call, merges it by the same rule, and publishes it with the same three
' writes in the same order. Whoever wins the race, the member's guides are all
' read and the result is the same.
'
' AND IT ADDS ONE THING GUIDESCREEN DOES NOT: each Xtream panel's OWN guide, at
' xmltv.php, appended at the END of the chain. That is the batched "what's on
' now" for a panel household — one request for every channel at once, instead
' of the one-channel-at-a-time dwell further down this file, which existed only
' because XmltvTask used to pull a guide into a single string before it could
' measure it and a panel guide is routinely over 100 MB. XmltvTask streams to
' cachefs now, refuses an oversized guide on a HEAD pre-check and cancels
' mid-download past its cap, so the thing that made this unsafe is gone.
'
' Appending it LAST is what keeps the two screens honest. The merge is
' first-writer-wins, so the panel guide can only ever FILL GAPS the member's
' own guides left — it can never take a channel off one of them, and it can
' never change what the member's guides contributed. If the TV Guide wins the
' race the globals hold the member's guides alone; if this screen wins they
' hold the same thing plus panel channels nobody else claimed. Neither is
' wrong and neither can surprise the other: every reader treats an unnamed
' channel as "fall back to the panel", which is exactly what the extra
' coverage saves them doing.
' A guide read is claimed by whichever screen gets there first, and the
' loser waits on the flag. But SceneGraph gives a screen no destructor: leave
' Live TV or the TV Guide part-way through a chain of guides and the screen
' that owned the read is torn down with the flag still saying "loading", and
' every other screen waits on a field that will never change again. Blank
' captions and an empty guide for the rest of the session.
'
' So a claim is stamped, and a stale claim can be taken over. The bar is
' deliberately high: one guide is allowed 300 s by XmltvTask's own deadline
' and a chain can hold three, so nothing under that is evidence of anything.
' Taking over costs one duplicate download in the worst case; NOT taking over
' costs the guide for the whole session.
function xmltvClaimIsStale() as boolean
    if m.global = invalid or not m.global.hasField("xmltvClaimedAt") then return false
    at = m.global.xmltvClaimedAt
    if at = invalid or at <= 0 then return false
    return (CreateObject("roDateTime").asSeconds() - at) > 960
end function

sub stampXmltvClaim()
    if m.global <> invalid and m.global.hasField("xmltvClaimedAt")
        m.global.xmltvClaimedAt = CreateObject("roDateTime").asSeconds()
    end if
end sub

' Did the app give the guide back to Roku to stay alive?
'
' The twin of GuideScreen.guideWasShed, duplicated for the same reason the
' claim helpers above it are: component scripts do not share statics and
' neither screen owns a file the other includes.
'
' THIS SCREEN IS WHY THE WHOLE JOB EXISTS. Member key D62C10 (Roku Express
' 3910X, v1.0.39, 2026-09-23) opened Live TV at 13:45:57 holding 4% of what
' their box allows, took twenty-three memory alarms over the next six
' minutes, and was killed at 13:52:21. AppScene now drops the parsed guide
' when one of those alarms arrives and leaves xmltvState alone; without this
' the flag would never be answered, and the "what's on now" caption under
' every tile would stay blank for the rest of the session -- which is worse
' for the member than the crash it is trying to avoid.
'
' Tested on the flag and not on an empty map: a guide can parse perfectly and
' match none of the member's channels, which leaves an empty map reading
' "ready" too, and re-reading on that would be a download per screen open.
function liveGuideWasShed() as boolean
    if m.global = invalid or not m.global.hasField("xmltvShed") then return false
    if m.global.xmltvShed <> true then return false
    return LCase(ToStr(m.global.xmltvState)) <> "loading"
end function

sub startXmltv()
    ' Did the member ask for a refresh in Settings? THE FLAG IS CLAIMED HERE
    ' and not in Settings, on purpose: until a guide screen opens there is
    ' nothing to re-read, so the guide the member already has stays live and
    ' readable everywhere the whole time they are still in the settings list.
    ' The blank-caption gap is then only ever as long as the chain below
    ' actually takes. GuideRefreshTake clears the flag, so whichever of the
    ' two guide screens opens first does the work and the other behaves
    ' normally.
    if GuideRefreshTake()
        KLog("livetv", "reading the guide again - you asked for a refresh")
        m.global.xmltvState = ""
    end if
    ' The app let the guide go on a Roku memory alarm -- see liveGuideWasShed
    ' above. It goes HERE, above the early return, because after a shed the
    ' state still reads "ready" and that return is what would otherwise send
    ' this screen away with nothing. Clearing the state puts the recovery
    ' through the ordinary path below -- liveGuideMayStart, the chain, the
    ' claim stamp, the memory gate before each download -- so a shed session
    ' reads its guide exactly the way a fresh launch does.
    if liveGuideWasShed()
        KLog("livetv", "the guide was let go of to keep the app alive - reading it again")
        m.global.xmltvShed = false
        m.global.xmltvState = ""
    end if
    if m.global.xmltvState = "ready" or m.global.xmltvState = "failed" then return
    if m.global.xmltvState = "loading" and xmltvClaimIsStale() and not m.gChainRunning
        KLog("livetv", "the guide read that was in progress went away - taking it over")
        m.global.xmltvState = ""
    end if
    if m.global.xmltvState = "loading"
        ' Somebody else is already reading it — the TV Guide, or a channel
        ' page. Wait for THAT one rather than starting a second, and repaint
        ' the tiles when it lands so this screen isn't the only one that
        ' never learns the guide arrived. (mergeCategories and onM3uParsed
        ' both call this more than once as late sources answer, hence the
        ' flag: a second observeField on the same field would fire the
        ' callback twice.)
        '
        ' If the somebody is US, the chain calls onLiveGuideLanded itself when
        ' it finishes; a second way in would only repaint the tiles twice.
        if m.gChainRunning then return
        if m.xmltvWatch <> true
            m.xmltvWatch = true
            m.global.observeField("xmltvState", "onXmltvStateChanged")
        end if
        return
    end if
    if not liveGuideMayStart() then return
    chain = buildLiveGuideChain()
    if chain.count() = 0 then return

    ' ONE task at a time and one state transition, claimed before anything is
    ' created. Every screen that reads this global does the same check-then-set
    ' on the render thread, which is the only thread any of them run on, so the
    ' first one here owns the fetch and the rest wait.
    m.global.xmltvState = "loading"
    stampXmltvClaim()
    m.gChain = chain
    m.gChainIdx = 0
    m.gChainOk = 0
    m.gMergedById = {}
    m.gMergedAliases = {}
    m.gMergedProgrammes = 0
    m.gChainRunning = true

    ' The tvg-ids the member's playlists actually use. Built once and reused
    ' for every MEMBER guide in the chain — it describes the member's channels,
    ' not the file — exactly as GuideScreen does it, so the member's guides
    ' parse to the same thing whichever screen read them. An Xtream-only
    ' household has no playlist to enumerate, so this goes out empty, which
    ' XmltvTask reads as "keep everything".
    wanted = []
    seen = {}
    for each ch in m.global.m3uChannels
        tid = ToStr(GetField(ch, "tvgId"))
        if tid <> "" and not seen.doesExist(tid)
            seen[tid] = true
            wanted.push(tid)
        end if
    end for
    m.gWantedJson = FormatJson(wanted)

    KLog("livetv", "reading " + chain.count().toStr() + " guide(s), one at a time")
    runNextLiveGuide()
end sub

' Is it too early to decide what the chain is?
'
' Only ever true for one reason: a playlist that has not come back yet. The
' playlist's url-tvg is the fallback guide address and it is not knowable until
' the parse lands, so starting the chain before then would claim the
' one-per-launch handshake and then read a guide the member never had. That is
' the same "first screen in wins" trap this whole rewrite is about, just with
' the timing instead of the ordering.
'
' The wait is as narrow as it can be. It only applies when the fallback is the
' only thing that could be missed — no guides of the member's own, and no
' url-tvg claimed by an earlier playlist yet. A household with either of those
' already knows its whole chain and starts immediately, and an Xtream-only
' household has no playlist to wait on at all.
function liveGuideMayStart() as boolean
    for each p in m.sources
        if ProviderCustomEpgGuides(p).count() > 0 then return true
    end for
    if ToStr(m.global.m3uTvgUrl) <> "" then return true
    for each p in m.sources
        if ToStr(p.ptype) = "m3u"
            if not m.m3uAnswered.doesExist(ToStr(p.id)) then return false
        end if
    end for
    return true
end function

' The reading order.
'
'   [{ url, wantedJson, names, panel }]
'
' The member's own guides first, in their order, flattened across sources and
' de-duplicated by address — the SAME list GuideScreen builds, from the same
' Store call, walking the same LoadProviders() order, so the two screens agree
' on it entry for entry. With none set it is the playlist's url-tvg on its own,
' which is what this screen has always read.
'
' Then each Xtream panel's own xmltv.php, last, one per source.
function buildLiveGuideChain() as object
    chain = []
    byUrl = {}
    for each p in m.sources
        for each g in ProviderCustomEpgGuides(p)
            u = ToStr(GetField(g, "u")).trim()
            if u <> ""
                lk = LCase(u)
                if byUrl.doesExist(lk)
                    byUrl[lk].names = byUrl[lk].names + ", " + ToStr(p.name)
                else
                    e = { url: u, wantedJson: "", names: ToStr(p.name), panel: false }
                    byUrl[lk] = e
                    chain.push(e)
                end if
            end if
        end for
    end for
    if chain.count() = 0
        tvg = ToStr(m.global.m3uTvgUrl)
        if tvg <> ""
            e = { url: tvg, wantedJson: "", names: "your playlist", panel: false }
            byUrl[LCase(tvg)] = e
            chain.push(e)
        end if
    end if

    ' The panels' own guides, after everything of the member's.
    for each p in m.sources
        u = xtreamGuideUrl(p)
        if u <> ""
            lk = LCase(u)
            ' A member who pasted their panel's own xmltv.php into Settings has
            ' it in the chain already. Left exactly where they put it — moving
            ' it would change the order they chose, and it is the same file
            ' either way.
            if not byUrl.doesExist(lk)
                ' "[]" — KEEP EVERYTHING, and it has to be. The wanted list is
                ' built from the member's PLAYLIST tvg-ids; a panel's guide is
                ' full of the panel's own ids, so filtering it by a playlist's
                ' would throw away every channel it came for. A panel-only
                ' household sends an empty list anyway, and this is the mixed
                ' household where the two would otherwise disagree.
                e = { url: u, wantedJson: "[]", names: ToStr(p.name) + "'s own guide", panel: true }
                byUrl[lk] = e
                chain.push(e)
            end if
        end if
    end for
    return chain
end function

' A panel's batched guide address, or "" for a source that hasn't got one.
'
' Same server root and same credentials XtreamApiUrl builds from
' (source/utils/Util.brs:197-201), spelled out here rather than added as a
' helper there because Util.brs is shared with every other screen and this is
' the only caller.
function xtreamGuideUrl(p as dynamic) as string
    if p = invalid then return ""
    if ToStr(GetField(p, "ptype")) = "m3u" then return ""
    server = ToStr(GetField(p, "server")).trim()
    user = ToStr(GetField(p, "username"))
    pass = ToStr(GetField(p, "password"))
    if server = "" or user = "" or pass = "" then return ""
    return server + "/xmltv.php?username=" + UrlEncode(user) + "&password=" + UrlEncode(pass)
end function

' The most programmes the merged guide is allowed to hold.
'
' The SAME number GuideScreen.GuideMaxMergedProgrammes() uses, and for the same
' reason: XmltvTask caps ONE guide at 12,000 because that is about what a cheap
' 720p set can carry alongside the app, and merging three of them is three
' times that with no warning before the box is killed outright. Once the merge
' is this full the guides still waiting are not downloaded at all — which is
' exactly why the panels' guides sit at the END of the chain. The member's own
' choices get the room first.
function LiveGuideMaxMergedProgrammes() as integer
    return 16000
end function

' ONE XmltvTask ALIVE AT A TIME, EVER. Never a task per guide: each one is a
' download plus a parse, and two at once on a small box is how the app gets
' killed. The next is only created after the previous has answered and been
' let go of.
sub runNextLiveGuide()
    ' Same test, one step earlier: no point downloading guide 2 of 3 for a
    ' profile nobody is on any more. finishLiveGuideChain's own check below
    ' tidies up the handshake.
    if liveShellChanged()
        finishLiveGuideChain("the profile changed")
        return
    end if
    if m.gChainIdx >= m.gChain.count()
        finishLiveGuideChain("all " + m.gChain.count().toStr() + " read")
        return
    end if
    ' Checked before each download except the first — the first is the
    ' member's top choice and is always attempted, so this can never turn into
    ' "no guide at all" on a box that was already tight.
    if m.gChainIdx > 0
        if m.gMergedProgrammes >= LiveGuideMaxMergedProgrammes()
            finishLiveGuideChain("full at " + m.gMergedProgrammes.toStr() + " programmes - the guides further down the list were not read")
            return
        end if
        if liveGuideMemoryTight()
            finishLiveGuideChain("stopping early - this device is running short of memory")
            return
        end if
    end if
    e = m.gChain[m.gChainIdx]
    n = m.gChainIdx + 1
    KLog("livetv", "guide " + n.toStr() + " of " + m.gChain.count().toStr() + " (" + ToStr(e.names) + ")")
    task = CreateObject("roSGNode", "XmltvTask")
    task.url = ToStr(e.url)
    wj = ToStr(e.wantedJson)
    if wj = "" then wj = m.gWantedJson
    task.wantedJson = wj
    task.observeField("result", "onLiveGuideXmltv")
    m.xmltvTask = task
    task.control = "RUN"
end sub

' Is the box short of memory right now? XmltvTask has its own copy of this (it
' runs on a different thread and can't call in here); the chain needs the same
' answer before it starts the NEXT download.
' MEASURED, not just asked. The coarse level is all this used to read, and
' "low" arrives far too late to stop a guide chain: on the office stick - the
' ROOMIEST box we own - the app went from 4% to 32% of its limit on the first
' guide alone, and from 46% to 77% while a chain ran behind a Live TV screen.
' The device still called that "normal" the whole way.
'
' Six members on cheap boxes (Roku Express 3960X, Streaming Stick 3840X, SEMP)
' were killed with EXIT_CHANNEL_MEM_LIMIT_FG on v1.0.30 holding as little as
' 353 channels and 5% of the device - so it was never the size of their
' line-up, it was what the guide chain piled on top.
'
' THIS RUNS ON THE RENDER THREAD, where roAppMemoryMonitor reports the whole
' app honestly. (From a Task it reports only that thread - 14-17% while the app
' was really at 47-56% - which is why XmltvTask still has to use the coarse
' reading and this no longer does.)
'
' 88%, NOT 70%. The first cut used 70 and it was wrong in the other direction:
' this app legitimately sits at 61-70% on a healthy box with a couple of
' playlists and Sports loaded, so a 70% gate refused the guide on hardware
' that was perfectly fine - the owner's own Roku came back with "could not read
' your guide". Refusing a guide is refusing the feature; it is only the right
' answer when the alternative is Roku killing the app, which is what 88 means.
function liveGuideMemoryTight() as boolean
    lvl = LCase(ToStr(CreateObject("roDeviceInfo").GetGeneralMemoryLevel()))
    if lvl = "low" or lvl = "critical" then return true
    mon = CreateObject("roAppMemoryMonitor")
    if mon = invalid then return false
    used = mon.GetMemoryLimitPercent()
    if used = invalid then return false
    return ToInt(used) >= 88
end function

' One guide has answered — or given up. Either way the chain moves on: a guide
' that can't be read costs the member the channels only that guide knew about,
' not the whole guide.
'
' HOW A PANEL THAT DOESN'T SERVE xmltv.php IS DETECTED: it lands here, as a
' failure, like any other unreadable guide. There is nothing to probe for and
' nothing to configure. A panel that has no such endpoint answers 404 or 500
' and XmltvTask reports "guide unreachable"; a panel that serves a login page
' or an error page instead answers 200 with no <programme> in it anywhere and
' XmltvTask reports "guide XML didn't parse"; a panel that answers with nothing
' at all is a zero-byte file, which is "guide unreachable" again. All three are
' ok:false, all three are logged by name, and all three leave that source's
' channels exactly where they were before this feature existed — uncovered, and
' filled in by the one-at-a-time dwell below as the member browses.
sub onLiveGuideXmltv(event as object)
    try
        onLiveGuideXmltvInner(event)
    catch e
        GuardFailed("livetv/onLiveGuideXmltv", e)
        ' AND HAND THE HANDSHAKE BACK. Stopping the chain is not enough on its
        ' own: this screen owns the one-read-per-launch claim, so a fault here
        ' used to leave xmltvState on "loading" with nobody left to finish it,
        ' and every screen in the app then waited out the 960 s stale-claim
        ' timer with blank captions. Released, so the next guide screen reads it
        ' straight away. A caught fault should cost the member one retry, not
        ' the session's listings.
        m.gChainRunning = false
        releaseLiveGuideTask()
        if m.global <> invalid and ToStr(m.global.xmltvState) = "loading"
            m.global.xmltvState = ""
            if m.global.hasField("xmltvClaimedAt") then m.global.xmltvClaimedAt = 0
        end if
    end try
end sub

' NO liveScreenIsGone() GATE, AND THAT IS A DECISION, NOT AN OMISSION. This
' handler and mergeLiveGuide below touch no nodes at all - they read the task's
' answer, merge it into plain maps and hand the result to the globals. On a
' screen the member has walked away from that is exactly what should still
' happen: the guide read is one request per launch and its answer is shared.
' The gate sits one step further on, in onLiveGuideLanded, which is where the
' drawing starts. The faulting statement in log key 0D722F was somewhere in
' this stretch and the crash report could not say where; the wrapper above is
' what will name it if it ever happens again.
sub onLiveGuideXmltvInner(event as object)
    res = event.getData()
    e = invalid
    if m.gChainIdx >= 0 and m.gChainIdx < m.gChain.count() then e = m.gChain[m.gChainIdx]
    ' Let go of the finished task BEFORE the next is made, so the box is never
    ' holding two guides' worth at once. One helper now, shared with the
    ' teardown path, so there is one place that knows how to let a task go.
    releaseLiveGuideTask()
    nm = "a guide"
    if e <> invalid then nm = ToStr(e.names)
    if res <> invalid and res.ok = true
        mergeLiveGuide(res, nm)
        m.gChainOk = m.gChainOk + 1
    else
        why = ToStr(GetField(res, "error"))
        if why = "" then why = "no answer"
        if e <> invalid and e.panel = true
            KLog("livetv", nm + " isn't there (" + why + ") - those channels fill in one at a time as you browse")
        else
            KLog("livetv", "couldn't read the guide from " + nm + " (" + why + ") - carrying on with the rest")
        end if
    end if
    m.gChainIdx = m.gChainIdx + 1
    runNextLiveGuide()
end sub

' FIRST WRITER WINS — the same rule, spelled the same way, as
' GuideScreen.mergeGuideIntoChain. A channel already named by an earlier guide
' is left exactly as that guide left it; only channels nobody has claimed yet
' are taken from this one. That is what makes the order in Settings mean
' something, it is what keeps the merge cheap (it never rewrites, only fills
' gaps), and it is what lets the panels' guides ride on the end of the chain
' without being able to change a thing the member's own guides said.
sub mergeLiveGuide(res as object, nm as string)
    byId = GetField(res, "byId")
    if byId = invalid then byId = {}
    added = 0
    passed = 0
    for each k in byId
        if m.gMergedById.doesExist(k)
            passed = passed + 1
        else
            list = byId[k]
            m.gMergedById[k] = list
            m.gMergedProgrammes = m.gMergedProgrammes + list.count()
            added = added + 1
        end if
    end for
    ' Callsign/name aliases follow the same rule, or a later guide could
    ' quietly re-point a name an earlier guide had already claimed.
    al = GetField(res, "aliases")
    if al <> invalid
        for each a in al
            if not m.gMergedAliases.doesExist(a) then m.gMergedAliases[a] = al[a]
        end for
    end if
    msg = nm + ": " + added.toStr() + " channel(s) taken, " + passed.toStr() + " already covered by an earlier guide"
    if GetField(res, "capped") = true
        ' Worth saying out loud: a capped guide stops naming channels part way
        ' through the file, and the ones past that point stay uncovered. They
        ' are not lost — the dwell below still fills them in one at a time,
        ' because coverage is decided per channel and not per guide.
        msg = msg + " (that guide was too big to read in full, so the rest of its channels fill in as you browse)"
    end if
    KLog("livetv", msg)
end sub

' The chain is done. THIS is the only place this screen publishes the shared
' guide, and it publishes it the way GuideScreen.finishGuideChain does, in the
' same order, with the same three writes:
'
'   xmltvById   assigned once, whole
'   xmltvAliases assigned once, and only when there are any
'   xmltvState  flipped once, last
'
' The order is load-bearing and it is why the aliases go before the flag:
' ChannelDetailScreen takes a COPY of one channel's listings the moment the
' state turns "ready", and MultiViewScreen, PlayerScreen, SportsTask and the
' nowPlayingTitles pass below all gate on the same word. Anything still being
' built when the flag flips would be read half-finished.
'
' THE ALIASES ARE NEW HERE and their absence was a real hole. This screen used
' to write xmltvById and the flag but never the alias map, so a guide read from
' Live TV left every reader with the alias map AppScene created — empty — and
' the callsign fallback in nowPlayingTitles, GuideScreen.xmltvKeyFor and
' ChannelDetailScreen silently matched nothing. The same guide read from the TV
' Guide filled it in. Same file, same session, two different answers depending
' on which screen was opened first.
sub finishLiveGuideChain(why as string)
    m.gChainRunning = false
    ' >>> THE PROFILE CHANGED WHILE THIS WAS STILL READING. <<<
    ' Reached when the member left Live TV for another screen FIRST and only
    ' then switched profile: the shell's teardown names whatever screen was on
    ' at that moment, so the "shell" notice never arrives here and the chain
    ' this screen started is still running. Publishing now would put the old
    ' profile's listings into the globals the new one reads AND leave the flag
    ' saying "ready", so the profile the member just switched to would never
    ' read its own guide for the rest of the session. So it is dropped, and the
    ' one-read-per-launch handshake is put back so the new profile does read
    ' its own. Checked HERE and not in the caller because this sub is the only
    ' place this screen writes the shared guide.
    if liveShellChanged()
        releaseLiveGuideTask()
        m.gChain = []
        m.gMergedById = {}
        m.gMergedAliases = {}
        if m.global <> invalid and ToStr(m.global.xmltvState) = "loading"
            m.global.xmltvState = ""
            if m.global.hasField("xmltvClaimedAt") then m.global.xmltvClaimedAt = 0
        end if
        KLog("livetv", "the guide finished reading after the profile changed - not used, the new profile reads its own")
        return
    end if
    ' SAID HERE BECAUSE HERE IT CAN BE PROVEN. liveScreenIsGone() asks the tree,
    ' so this line only ever appears when the member really did walk away
    ' mid-read - and it appears immediately above the "guide ready" line, which
    ' is what says the walking away cost them nothing.
    if liveScreenIsGone()
        KLog("livetv", "you left Live TV while the guide was still being read - finished it anyway, so it is ready wherever you went")
    end if
    if m.gChainOk > 0
        m.global.xmltvById = m.gMergedById
        if m.gMergedAliases.count() > 0 then m.global.xmltvAliases = m.gMergedAliases
        m.global.xmltvState = "ready"
        KLog("livetv", "guide ready: " + m.gMergedById.count().toStr() + " channels, " + m.gMergedProgrammes.toStr() + " programmes from " + m.gChainOk.toStr() + " guide(s) - " + why)
    else if m.global.xmltvById.count() > 0
        ' A REFRESH THAT FAILED MUST NOT COST THE MEMBER THE GUIDE THEY HAD.
        '
        ' This is the guide's version of the hazard Android's
        ' refresh_guard_dialog exists for: a refresh that comes back with
        ' less than the member started with. Here it can only be ALL or
        ' nothing — a guide never supplies channels, only captions, so a
        ' merely smaller guide costs some captions and is not worth asking
        ' about. A chain where every guide failed is different: publish
        ' "failed" and a working guide is replaced by nothing for the rest of
        ' the session, and the member did that to themselves by pressing
        ' Refresh.
        '
        ' xmltvById is only ever overwritten on the success arm above, so at
        ' this point it still holds whatever was published last. A non-empty
        ' map here means exactly one thing — a re-read of a guide that had
        ' already succeeded, which is a refresh — because on a first read
        ' AppScene's empty map is what is sitting there. Keep it, and say
        ' "ready" so every reader carries on with the listings it already had.
        ' No dialog: there is no judgement call for the member to make.
        m.global.xmltvState = "ready"
        KLog("livetv", "the guide couldn't be read again - keeping the " + m.global.xmltvById.count().toStr() + " channels you already had (" + why + ")")
    else
        ' Every guide in the chain failed, and there was nothing to fall back
        ' on. Same word this screen has always used, so everything waiting on
        ' it behaves as it always has: the panel's own per-channel guide
        ' answers instead.
        m.global.xmltvState = "failed"
        KLog("livetv", "no guide could be read - " + why)
    end if
    ' The global holds its own copy now, so the render thread's stops costing
    ' anything.
    m.gMergedById = {}
    m.gMergedAliases = {}
    onLiveGuideLanded()
end sub

' The guide another screen started has finished one way or the other.
sub onXmltvStateChanged()
    try
        onXmltvStateChangedInner()
    catch e
        GuardFailed("livetv/onXmltvStateChanged", e)
    end try
end sub

sub onXmltvStateChangedInner()
    ' THE ONLY PLACE THIS REGISTRATION CAN BE REMOVED WITH PROOF. m.global is
    ' never collected, so a plain observeField on it from a screen that gets
    ' thrown away is the RK-006 retention shape - but it must not be removed on
    ' a guess, because a live screen waiting here is a screen whose captions
    ' depend on it. By the time this fires the tree can answer, so it is removed
    ' here and nowhere else.
    if liveScreenIsGone()
        m.global.unobserveField("xmltvState")
        m.xmltvWatch = false
        return
    end if
    ' THE READ WENT AWAY WITHOUT FINISHING. "" is the handshake being handed
    ' back, and there is now one way for that to happen after a chain has
    ' started: a guide read abandoned because the profile changed under it
    ' (finishLiveGuideChain). Without this branch the screen that was waiting
    ' sits here with no listings until the member leaves Live TV and comes
    ' back, so it takes the claim and reads instead. Unobserved first, so the
    ' "loading" startXmltv is about to write cannot come straight back in here.
    if ToStr(m.global.xmltvState) = ""
        m.global.unobserveField("xmltvState")
        m.xmltvWatch = false
        startXmltv()
        return
    end if
    if m.global.xmltvState = "loading" then return
    m.global.unobserveField("xmltvState")
    m.xmltvWatch = false
    onLiveGuideLanded()
end sub

' The shared guide has settled, whoever read it. Get the captions onto the
' tiles that are already on screen.
'
' WHAT THE MEMBER SAW WHILE IT WAS DOWNLOADING: the folder, drawn immediately,
' with no captions under the tiles and no spinner, no placeholder and no
' "Loading…" — the same silence the one-at-a-time path keeps while one of its
' requests is in flight, and for the same reason: a caption band that appears
' with a placeholder and then disappears reads as a fault. Nothing on this
' screen waits for the guide; it fills in when it arrives.
sub onLiveGuideLanded()
    ' >>> THE GATE FOR LOG KEY 0D722F. <<<
    ' Everything below this line reaches for this screen's own nodes - the
    ' grid, its content, the empty label - and this is the first thing after the
    ' guide lands that does. A guide that finishes after its screen has gone
    ' still publishes, because that is the point of letting it finish; it just
    ' has nothing left to draw on.
    if liveScreenIsGone() then return
    ' Standing in the grid is the case that needs the second route.
    ' refillNowPlaying deliberately refuses to repaint while the grid holds
    ' focus, because re-assigning the grid's content throws the member back to
    ' the first channel in the folder — so with a guide that lands while they
    ' are browsing, the tiles in front of them would stay blank until they left
    ' the folder and came back. Publishing into the session map the cards
    ' already watch gets the captions onto those exact tiles, in place, with
    ' nothing moving.
    if m.grid.hasFocus()
        publishNowFromGuide()
    end if
    refillNowPlaying()
end sub

' How many of the open folder's captions are pushed into the session map when
' the guide lands mid-browse.
'
' Bounded because that map is the same one the one-at-a-time path fills, it is
' held for the whole session, and a folder on this screen is not capped the way
' the TV Guide's 150-per-tab is — "All" on a big panel is several thousand
' channels and none of them are on screen. Four hundred is more than a member
' can have scrolled past by the time a guide download finishes, and anything
' past it gets its caption the ordinary way, off the content node, the next
' time the folder is painted.
function LiveGuidePublishMax() as integer
    return 400
end function

' Put the open folder's "what's on now" into the map the cards watch.
'
' NO REQUESTS, none of the budgets, and nothing here can reach the network —
' every title comes out of the guide that just landed. It doubles as the reason
' the dwell never asks about these channels again: requestNowFor treats an
' entry in liveNowById as "already answered", so a channel the guide covered is
' settled by the same test that stops a channel being asked about twice.
'
' Only channels the guide actually NAMES get an entry. A channel it never
' mentioned is left absent, not blank, so the dwell can still ask the panel
' about it one at a time — which is the whole fallback.
sub publishNowFromGuide()
    if m.global = invalid then return
    if m.currentChannels = invalid then return
    if m.global.xmltvState <> "ready" then return
    ' Recomputed rather than reused: this is also what refreshes m.nowTitles
    ' and m.nowCovered for the folder on screen, which is what the dwell reads.
    titles = nowPlayingTitles(m.currentChannels)
    m.nowTitles = titles
    covered = m.nowCovered
    now = CreateObject("roDateTime").asSeconds()
    ' Both maps rebuilt whole and assigned once — the same rule mapWith()
    ' follows and for the same reason. Assigning liveNowById is what wakes the
    ' cards, so it goes last and the tiles repaint exactly once.
    ' Both globals read ONCE into locals. A node field read hands back a fresh
    ' copy of the whole map every time it is touched, so reading it inside the
    ' loop would copy the map once per key.
    wasU = m.global.liveNowUntil
    wasT = m.global.liveNowById
    keepU = {}
    keepT = {}
    for each k in wasU
        keepU[k] = wasU[k]
    end for
    for each k in wasT
        keepT[k] = wasT[k]
    end for
    n = 0
    added = 0
    for i = 0 to m.currentChannels.count() - 1
        if n >= LiveGuidePublishMax() then exit for
        if i >= covered.count() then exit for
        if covered[i] = true
            ' nowKeyFor, NOT epgKeyFor. The old call published nothing at all
            ' for an M3U channel, so a playlist household that was standing in
            ' the grid when the guide landed kept blank captions until the
            ' folder was repainted — see nowKeyFor for the whole story. Still
            ' blank for a channel with nothing to identify it by.
            key = nowKeyFor(m.currentChannels[i])
            if key <> "" and not keepT.doesExist(key)
                keepT[key] = titles[i]
                ' Half an hour, the same expiry a blank answer from the panel
                ' gets. This is only a DISPLAY cache for tiles that are already
                ' drawn — the guide itself is still in memory, so once it runs
                ' out pruneExpiredNow drops it and the next paint reads the
                ' real thing again. It is deliberately not the programme's own
                ' end time: a tile that is repainted takes its caption off the
                ' content node instead, which is worked out fresh every time.
                keepU[key] = now + 1800
                added = added + 1
            end if
            n = n + 1
        end if
    end for
    if added = 0 then return
    m.global.liveNowUntil = keepU
    m.global.liveNowById = keepT
    KLog("livetv", "what's on now: the guide landed while you were browsing - filled in " + added.toStr() + " caption(s) without moving you")
end sub

sub fillCategoryList()
    content = CreateObject("roSGNode", "ContentNode")
    for each c in m.categories
        item = content.createChild("ContentNode")
        name = c.name
        if c.locked = true then name = name + "   (Locked)"
        item.title = name
    end for
    m.catList.content = content
    if m.categories.count() > 0
        loadChannels(0)
    end if
end sub

sub onCategoryFocused()
    try
        onCategoryFocusedInner()
    catch e
        GuardFailed("livetv/onCategoryFocused", e)
    end try
end sub

sub onCategoryFocusedInner()
    if liveScreenIsGone() then return
    ' Browsing with Up/Down loads the category under the cursor, like the
    ' Android list which fills the right pane as you move.
    loadChannels(m.catList.itemFocused)
end sub

sub onCategorySelected()
    try
        onCategorySelectedInner()
    catch e
        GuardFailed("livetv/onCategorySelected", e)
    end try
end sub

sub onCategorySelectedInner()
    if liveScreenIsGone() then return
    idx = m.catList.itemSelected
    if idx >= 0 and idx < m.categories.count()
        cat = m.categories[idx]
        if cat.locked = true and not ParentalUnlocked()
            promptCategoryPin()
            return
        end if
    end if
    m.grid.setFocus(true)
end sub

' PIN gate for a locked category (PIN mode). A correct PIN unlocks every
' locked category for the rest of the session and re-fetches so they open.
sub promptCategoryPin()
    kb = CreateObject("roSGNode", "PinDialog")
    kb.title = "Enter PIN"
    kb.observeField("accepted", "onCategoryPin")
    kb.observeField("cancelled", "onCategoryPinCancel")
    m.pinDialog = kb
    ' Handed to the scene rather than added as a child: the voice pin pad is
    ' a standard dialog, and only the scene's own dialog slot makes it modal,
    ' focused and closable with Back.
    m.top.getScene().dialog = kb
end sub

sub removePinDialog()
    if m.pinDialog <> invalid
        m.pinDialog.close = true
        m.pinDialog = invalid
    end if
end sub

sub onCategoryPin()
    try
        onCategoryPinInner()
    catch e
        GuardFailed("livetv/onCategoryPin", e)
    end try
end sub

' The PIN pad, the two notes and the search keyboard are all parented to the
' SCENE, not to this screen, so they outlive it. They cannot realistically be
' open at teardown - a modal dialog holds the focus, so the member cannot reach
' the sidebar or the profile picker while one is up - but every one of them
' dereferences m.top.getScene().dialog, which is the shape that kills a
' detached screen, so they are gated anyway.
sub onCategoryPinInner()
    if liveScreenIsGone() then return
    entered = m.pinDialog.value
    removePinDialog()
    if CheckParentalPin(entered)
        SetParentalUnlocked(true)
        loadCategories()  ' re-fetch: locks clear now that we're unlocked
        m.catList.setFocus(true)
    else
        note = CreateObject("roSGNode", "Dialog")
        note.title = "Incorrect PIN"
        note.buttons = ["OK"]
        note.observeField("buttonSelected", "onPinNoteClosed")
        m.top.getScene().dialog = note
    end if
end sub

sub onCategoryPinCancel()
    try
        onCategoryPinCancelInner()
    catch e
        GuardFailed("livetv/onCategoryPinCancel", e)
    end try
end sub

sub onCategoryPinCancelInner()
    if liveScreenIsGone() then return
    removePinDialog()
    m.catList.setFocus(true)
end sub

sub onPinNoteClosed()
    try
        onPinNoteClosedInner()
    catch e
        GuardFailed("livetv/onPinNoteClosed", e)
    end try
end sub

sub onPinNoteClosedInner()
    if liveScreenIsGone() then return
    m.top.getScene().dialog.close = true
    m.catList.setFocus(true)
end sub

' ---- "Can't play this right now" --------------------------------------------
'
' The refusal MovieDetailScreen (:1384) and SeriesDetailScreen (:1116) already
' use when no source can open what was asked for: one Dialog, one OK button,
' focus handed back — to the GRID here, because that is where the press came
' from. Written out again rather than shared, because a component only ever
' sees the scripts its own XML names.
'
' The title and the message are WORD FOR WORD the ones ChannelDetailScreen
' puts up (cannotPlayNote there), the same way the * menu's favourite label is
' word for word the channel page's button — the two screens must never give
' the same channel two different answers.
'
' LOG KEY FCF117: before this the press did nothing whatsoever, and on a
' television that reads as the app having frozen.
sub cannotPlayNote(chName as string)
    KLog("livetv", "refused play - no source on this box can open [" + chName + "]")
    note = CreateObject("roSGNode", "Dialog")
    note.title = "Can't Play This Right Now"
    note.message = "Kwick Player has no working source for this channel. It was probably left behind by a source you removed. Check your sources under Settings, or pick another channel."
    note.buttons = ["OK"]
    note.observeField("buttonSelected", "onCannotPlayNoteClosed")
    m.top.getScene().dialog = note
end sub

sub onCannotPlayNoteClosed()
    try
        onCannotPlayNoteClosedInner()
    catch e
        GuardFailed("livetv/onCannotPlayNoteClosed", e)
    end try
end sub

sub onCannotPlayNoteClosedInner()
    if liveScreenIsGone() then return
    m.top.getScene().dialog.close = true
    m.grid.setFocus(true)
end sub

' A category's channels come from every source that carries the name: M3U
' parts filter the session cache instantly, Xtream parts fetch per source.
' Parts assemble in source order once the last one answers; a generation
' counter throws away answers for a category the user has already left.
sub loadChannels(catIndex as integer)
    if catIndex < 0 or catIndex >= m.categories.count() then return
    cat = m.categories[catIndex]
    ' A different folder: stop any dwell that was counting down for the old
    ' one and start its caption budget over. Arrowing down the category list
    ' comes through here on every press, hence the guard — the budget must
    ' not reset just because the same folder was re-opened.
    ' ToStr on both sides: m.currentCatId is invalid until the first folder is
    ' opened, and comparing a string against invalid is a type mismatch.
    if ToStr(cat.id) <> ToStr(m.currentCatId)
        cancelEpgDwell()
        resetCatEpgBudget()
    end if
    m.currentCatId = cat.id

    ' Locked category (PIN mode): don't fetch until unlocked.
    if cat.locked = true and not ParentalUnlocked()
        ' STOP THE PAGE-AT-A-TIME FILL FIRST. This branch replaces the grid's
        ' content without going through fillGrid, so a fill still running for
        ' the folder the member just left would carry on adding that folder's
        ' tiles onto a node nobody is looking at — and, worse, keep publishing
        ' its channels as the player's zap list behind a locked folder.
        releaseGridFill()
        m.grid.content = CreateObject("roSGNode", "ContentNode")
        m.currentChannels = []
        ' Nothing is on screen, so nothing is zappable. Published EMPTY rather
        ' than left alone: the previous folder's lineup standing here would let
        ' channel-up walk out of a locked folder into channels the member is
        ' being refused, which is the hole B1b closed on the detail screens.
        publishLiveLineup([])
        m.emptyLabel.visible = true
        m.emptyLabel.text = "Locked. Press OK and enter your PIN to view."
        return
    end if

    if m.channelsByCat.doesExist(cat.id)
        fillGrid(m.channelsByCat[cat.id])
        return
    end if

    m.loadGen = m.loadGen + 1
    m.load = { gen: m.loadGen, catName: cat.id, order: [], parts: {}, need: 0 }
    slots = m.global.m3uByProv
    for each sc in ToArray(cat.srcCats)
        pid = ToStr(sc.provId)
        m.load.order.push(pid)
        if ToStr(sc.ptype) = "m3u"
            part = []
            if slots.doesExist(pid)
                for each ch in slots[pid].channels
                    g = ToStr(ch.group)
                    if g = "" then g = "Uncategorized"
                    if g = ToStr(sc.catId) then part.push(ch)
                end for
            end if
            m.load.parts[pid] = part
        else
            m.load.need = m.load.need + 1
            prov = providerById(pid)
            if prov <> invalid
                task = CreateObject("roSGNode", "ApiTask")
                task.tag = m.loadGen.toStr() + "|" + pid
                task.url = XtreamApiUrl(prov, "get_live_streams") + "&category_id=" + UrlEncode(ToStr(sc.catId))
                task.observeField("result", "onChannels")
                ' Keyed by generation AND provider — a stale answer from the
                ' previous category must never evict the live category's
                ' still-running task from the reference map.
                m.inflight["ch_" + m.loadGen.toStr() + "_" + pid] = task
                task.control = "RUN"
            else
                m.load.need = m.load.need - 1
            end if
        end if
    end for
    if m.load.need > 0
        setBusy(true)
    else
        assembleChannels()
    end if
end sub

function providerById(pid as string) as dynamic
    for each p in m.sources
        if ToStr(p.id) = pid then return p
    end for
    return invalid
end function

sub onChannels(event as object)
    try
        onChannelsInner(event)
    catch e
        GuardFailed("livetv/onChannels", e)
    end try
end sub

sub onChannelsInner(event as object)
    res = event.getData()
    tag = ToStr(event.getRoSGNode().tag)
    sep = Instr(1, tag, "|")
    if sep = 0 then return
    gen = ToInt(Left(tag, sep - 1))
    pid = Mid(tag, sep + 1)
    m.inflight.delete("ch_" + gen.toStr() + "_" + pid)
    if m.load = invalid or gen <> m.load.gen then return   ' stale answer
    ' A folder nobody is looking at is nobody's to assemble. The same early
    ' exit as a stale generation, for the same reason.
    if liveScreenIsGone() then return
    prov = providerById(pid)
    token = ""
    if prov <> invalid then token = SrcTokenFor(prov)
    chans = []
    if res <> invalid and res.ok = true
        ' THE SAME GUARD THE CATALOGUE BUILD GOT IN v1.0.38, WHICH THIS PATH
        ' NEVER HAD. Log duty 2026-09-18: seven crash logs, every one of them
        ' EXIT_CHANNEL_MEM_LIMIT_FG, and five ended on or just after the line
        ' "opened LiveTvScreen" — a Roku Express 3960X (key 3E82F0) twenty
        ' seconds after opening it, a Roku Premiere+ 4630X (C95C89) two
        ' minutes after, four times over in half an hour. The app went from 2%
        ' to between 39% and 57% in that window with nothing else logged.
        ' This loop was the only unbounded thing in it: every row a panel
        ' answers with, built into an associative array, with no ceiling and
        ' no memory check — while VodContentTask, Search and the playlist
        ' parser had all been given one.
        kept = 0
        for each s in ToArray(res.data)
            ' Checked every hundred rows rather than every row: reading a
            ' global field is not free and a hundred rows is small enough that
            ' nothing runs away between checks.
            if kept mod 100 = 0 and liveMemPressure() then exit for
            kept = kept + 1
            chans.push({
                streamId: ToStr(GetField(s, "stream_id"))
                name: ToStr(GetField(s, "name"))
                logo: ToStr(GetField(s, "stream_icon"))
                url: ""
                src: token
                provId: pid
                ' The panel's own guide id for this channel — the SAME field
                ' the TV Guide keeps (GuideScreen: epg_channel_id -> tvgId)
                ' and the same one M3uTask reads out of tvg-id. It is what
                ' joins a tile to its listings, and it was simply being
                ' thrown away here: the answer already carries it, so
                ' keeping it costs nothing and no extra request.
                tvgId: ToStr(GetField(s, "epg_channel_id"))
            })
        end for
        ' Said out loud, because a folder that comes back short is something a
        ' member can see and nobody could otherwise explain.
        offered = ToArray(res.data).count()
        if offered > kept then KLog("livetv", "this folder holds " + offered.toStr() + " channels; stopped at " + kept.toStr() + " because the box is short of memory")
    end if
    m.load.parts[pid] = chans
    m.load.need = m.load.need - 1
    if m.load.need <= 0 then assembleChannels()
end sub

sub assembleChannels()
    setBusy(false)
    if m.load = invalid then return
    merged = []
    for each pid in m.load.order
        if m.load.parts.doesExist(pid)
            for each ch in m.load.parts[pid]
                merged.push(ch)
            end for
        end if
    end for
    m.channelsByCat[m.load.catName] = merged
    ' Fresh channels for this folder, so the prefs-applied copy of it is no
    ' longer about the same list. Dropped here rather than rebuilt, because
    ' fillGrid below rebuilds and re-caches it in the same breath.
    m.shownByCat.delete(ToStr(m.load.catName))
    ' AND LET THE OLD FOLDERS GO. This map kept every category the member had
    ' ever opened, for the life of the screen, with nothing ever removed — so
    ' walking down a provider's folder list quietly added each one's channels
    ' to the pile. On the packages these members are on that is tens of
    ' thousands of rows a folder, and it is the other half of why v1.0.37 kept
    ' dying on Live TV (log duty 2026-09-18, keys 3E82F0 and C95C89: 2% on
    ' opening the screen, 39% and 57% a folder or two later, then killed).
    ' Four is the most any member can be looking at — the one on screen and
    ' the ones they might step back to — and a folder dropped here costs one
    ' request to fetch again, which is the same request opening it the first
    ' time cost.
    trimChannelCache(m.load.catName)
    ' Fill in name/logo for favorites that arrived via sync without metadata.
    EnrichFavoriteChannels(merged)
    if m.load.catName = m.currentCatId then fillGrid(merged)
    m.load = invalid
end sub

' Has the box said it is short of memory? The same flag the catalogue build
' and the playlist parser read, and from v1.0.39 it is raised by the BOX's own
' alarm as well as this app's own — which matters here more than anywhere,
' because the small streaming players that die on this screen never send the
' app-level one at all (main.brs carries the counts).
function liveMemPressure() as boolean
    if m.global = invalid or not m.global.hasField("memPressure") then return false
    if m.global.memPressure = true
        KLog("livetv", "stopping the channel list - the box has said it is short of memory")
        return true
    end if
    return false
end function

' Keep the folder on screen and the last few behind it; drop the rest.
'
' ONE WALK, NO ORDER KEPT. An associative array has no order, so rather than
' carry a second list of which folder was opened when — another thing to keep
' in step and another thing to get wrong — this keeps the one named and drops
' whatever else is over the count. A member stepping back and forth between
' two folders never loses either; one walking down a long list loses the ones
' they have left behind, which is the point.
sub trimChannelCache(keep as string)
    if m.channelsByCat = invalid then return
    max = 4
    n = 0
    for each k in m.channelsByCat
        n = n + 1
    end for
    if n <= max then return
    dropped = 0
    for each k in m.channelsByCat
        if n - dropped <= max then exit for
        name = ToStr(k)
        if name = keep or name = ToStr(m.currentCatId) then continue for
        m.channelsByCat.delete(name)
        ' Kept in step with the raw folders, or this map would be the new
        ' thing that grows for ever while the one it mirrors is trimmed.
        m.shownByCat.delete(name)
        dropped = dropped + 1
    end for
    if dropped > 0 then KLog("livetv", "let go of " + dropped.toStr() + " folder(s) of channels this TV was still holding")
end sub

' ---- The lineup the player zaps through (A2) ---------------------------------
'
' WHAT THIS IS. One field, m.global.liveLineup, holding the live channels
' EXACTLY as the member is looking at them: this folder, after the hidden and
' reorder prefs, after their search, in the order the tiles are drawn. It is
' what lets PlayerScreen answer channel up / channel down, which it could not
' do before — the Xtream lineup lived only inside this screen, and a player
' asking the panel for one mid-stream is the request shape that got this
' house's access banned on 2026-08-14.
'
' NOT ONE NEW REQUEST, AND NEVER. This hands over a list this screen is already
' holding, at the moment it changes. Nothing here asks the provider anything,
' and if completing this lineup ever seems to need a fetch, the answer is that
' the feature costs more than it is worth.
'
' THE SHAPE IS THE PLAYER'S OWN, not a new one. These five keys are exactly
' what onChannelSelected already builds and hands to PlayerScreen.channel, and
' exactly what GuideScreen.openChannelPage hands the channel page. So the
' player re-derives a stream address from an entry the same way
' onChannelSelected does — LivePlayUrl on the channel's own url, else
' XtreamLiveUrl through ProviderForSrcToken — and needs nothing from this
' screen it has not already been given.
'
' NARROWED, NOT THE ROW ITSELF, and narrowing is the CHEAPER of the two. A raw
' row also carries provId, tvgId and group, none of which the player has any
' use for, and every one of those rides across the m.global field boundary on
' each publish. It also keeps the rows unshared, which matters: M3U channels
' are held BY REFERENCE out of the session cache, and PushRecentChannel
' MUTATES whatever it is handed (it stamps src and d onto it), so publishing
' the real row would let the player scribble on every other screen's copy of
' that channel.
'
' NO EXTRA PASS OVER THE FOLDER. The entries are built inside fillGrid's
' existing loop, which already walks `shown` once to build the tiles. The
' publish itself is ONE assignment of a FINISHED array — a half-filled lineup
' must never be visible, the same rule the guide globals follow.
'
' WRITTEN BOTH WAYS, ALWAYS. Every path that leaves the grid empty — a locked
' folder, a search that matched nothing, arriving here with no sources at all —
' publishes an EMPTY lineup rather than leaving the last one standing. A stale
' lineup would step the member onto a channel that is not on their screen.
'
' >>> FOR WHOEVER BUILDS THE BUTTONS <<<
'   · Match by IDENTITY (src + streamId), never by index. The guide publishes
'     the same field and leaves its PIN-locked rows OUT, so a published index
'     is not a row index there.
'   · The player is also opened from screens that publish NOTHING — Home's
'     recents, Search, the channel page — and those leave whatever was
'     published last standing. So find the channel the player was actually
'     handed inside this array BEFORE offering up/down, and offer no buttons
'     when it is not there. That is one pass over at most a few hundred
'     entries, once, when the player opens: no request, no clock, no registry.
sub publishLiveLineup(entries as object)
    if m.global = invalid then return
    ' Belt and braces, the same guard the liveNowById globals use above: the
    ' field is declared in AppScene, and a screen must not die on the render
    ' thread if it ever is not.
    if not m.global.hasField("liveLineup") then m.global.addFields({ liveLineup: [] })
    m.global.liveLineup = entries
end sub

' ---- THE GRID IS BUILT A PAGE AT A TIME (2026-10-29) ------------------------
'
' WHAT WENT WRONG, AND IT IS THE FIRST HARD EVIDENCE THIS LANE HAS HAD. The
' v1.0.42 crash reports came back with the same caught fault from two members
' on two different televisions:
'
'     CAUGHT livetv/onCategoryFocused: Execution timeout
'       @ pkg:/components/screens/LiveTvScreen.brs:1768 fillgrid
'
' - 466B77, a Philips 55PQL7676F6, and
' - 644F4F, a Roku Express 4K, which jumped from 8% to 58% the moment a second
'   source finished loading.
'
' An Execution timeout is NOT the app running out of heap. It is the drawing
' thread being held too long in one go, and that is why boxes have been dying
' at 1-6% reported memory with no alarm raised: the thing filling up is
' SceneGraph nodes and picture memory, which the percentage this app reports
' cannot see at all. Steering by that number was always going to miss this.
'
' The hold was this function. It built ONE SceneGraph node per channel, for
' every channel in the folder, in a single uninterrupted loop, with no ceiling
' anywhere in the path. Members on these packages carry line-ups of 25,884 and
' 69,291 channels; one big folder out of that is more than enough to hold the
' thread past the box's limit, and Roku then stops the function where it
' stands.
'
' WHAT THE MEMBER SAW WHEN IT DID. Nothing good, and nothing that said so. The
' fault came out of the tile loop, which sits BEFORE the line that hands the
' grid its new content — so the grid kept the PREVIOUS folder's channels,
' sitting under the new folder's name, with the player's zap list still
' pointing at them. Press OK and you played a channel out of a folder you had
' already left. On the very first folder of a visit there is no previous
' content, so the right-hand side was simply blank with no message on it.
'
' WHAT IT DOES NOW. The same work, paced. The first 150 tiles are built and
' handed over exactly as before, so a folder of 150 channels or fewer behaves
' the way it always has, down to the line. Anything past that is added 100 at
' a time on a tenth-of-a-second timer, onto the content node the grid is
' already holding — so no channel is lost, the member's place on screen never
' moves (tiles are added at the END, never in front of the cursor), and the
' drawing thread gets handed back between every page.
'
' WHY NOT JUST CAP THE FOLDER. Because a cap that quietly hides half a folder
' is a worse bug than the one being fixed. The TV Guide's 150-per-tab cap is
' about how many channels it will FETCH; this folder is already in memory and
' costs nothing more to show.
'
' WHY NOT STOP ON THE MEMORY PERCENTAGE. That is the number that could not see
' this fault in the first place. What is bounded here is the WORK done in one
' turn of the drawing thread, which is the thing that was actually over.
'
' TWO PRESSES OF DOWN IN QUICK SUCCESSION. onCategoryFocused fires on every
' press, so this function is re-entered constantly and can easily be re-entered
' while a fill is still running. m.gridGen is bumped on every repaint and the
' timer is stopped; a fill checks the generation it was armed under before it
' touches anything, so an older pass cannot add its folder's tiles to the new
' folder's grid. There is one timer node, so there can only ever be one fill
' pending.
'
' SEVERAL SOURCES DO NOT MULTIPLY THIS, THEY ADD TO IT. Same-named folders from
' different sources collapse into one folder (mergeCategories) and their
' channels are concatenated (assembleChannels), so two sources make a folder
' roughly twice as long, not squared. 644F4F's jump on the second source is
' that, plus that source's own category list and playlist cache.
sub fillGrid(chans as object)
    try
        fillGridInner(chans)
    catch e
        ' Caught HERE rather than left to whichever handler called us, purely
        ' so the member is not left looking at the wrong folder's channels —
        ' see "WHAT THE MEMBER SAW" above. The fault is still named and still
        ' uploaded; GuardFailed does that before anything is cleared.
        GuardFailed("livetv/fillGrid", e)
        clearGridAfterFailure()
    end try
end sub

sub fillGridInner(chans as object)
    ' Apply hidden-channel filter + sort order (Settings).
    '
    ' HELD PER FOLDER FOR THE LIFE OF THIS SCREEN. This used to run on every
    ' single repaint, and onCategoryFocused repaints on every press of Up or
    ' Down, so walking down a provider's folder list re-did the whole job once
    ' per press. It is not a cheap job: it reads the hidden list out of the
    ' registry and then, for a member who has chosen A-Z or Z-A in Settings,
    ' finishes with an insertion sort — the one MultiViewPicker already refuses
    ' to call for exactly this reason ("its insertion sort over a few thousand
    ' catalogue rows would stall the render thread"). Now it is done once per
    ' folder per visit, which is the other half of keeping this handler short.
    '
    ' WHAT MAKES THAT SAFE. The only thing that can change a channel pref while
    ' this screen is alive is hiding a channel from the * menu, and that drops
    ' this folder's entry before it repaints. Everything else that changes
    ' prefs — Settings, Manage Channels, Reorder — is a different screen, and
    ' AppShell throws this screen away and builds a new one when the member
    ' comes back. A folder whose channels are re-fetched drops its entry too.
    ck = ToStr(m.currentCatId)
    if ck <> "" and m.shownByCat.doesExist(ck)
        shown = m.shownByCat[ck]
    else
        shown = ApplyChannelPrefs(chans)
        if ck <> "" then m.shownByCat[ck] = shown
    end if
    ' THEN, and only then, the member's own search. Order matters and is the
    ' way round it is on purpose: the Settings prefs decide what exists in
    ' this folder and in what order, and the search narrows that VIEW. Doing
    ' it the other way would let a hidden channel be typed back into
    ' existence, and would sort a list the prefs had already sorted.
    '
    ' Applied HERE and nowhere else, so every path that repaints the grid —
    ' a category answering, arrowing down the folder list, hiding a channel,
    ' the guide file landing late, the search itself — goes through one rule.
    ' m.currentChannels and m.nowTitles are both built from `shown` below, so
    ' they stay index-aligned with the tiles by construction and every place
    ' that reads "the channel under the cursor" (playback, the * menu, the
    ' caption dwell) keeps pointing at the right one.
    shown = filterChannelsByName(shown)
    ' What is on RIGHT NOW under every tile in this folder, worked out for
    ' the WHOLE folder in one pass before a single tile is built.
    nowTitles = nowPlayingTitles(shown)
    ' Kept so the dwell can tell in one array hit whether the focused tile
    ' already has its caption from the guide file, without redoing the match.
    m.nowTitles = nowTitles
    ' Throw out any looked-up caption whose programme has since finished, so
    ' a folder opened an hour into a session doesn't show what WAS on. One
    ' pass over at most a couple of hundred entries, once per folder.
    pruneExpiredNow()

    ' Any fill still running belongs to the folder the member has just left.
    ' Bumping the generation is what kills it — see the note above fillGrid.
    m.gridGen = m.gridGen + 1
    if m.gridTimer <> invalid then m.gridTimer.control = "stop"
    m.gridShown = shown
    m.gridTitles = nowTitles
    m.gridBuilt = 0
    ' A NEW array every time, never the published one emptied and refilled.
    ' Whatever was handed to publishLiveLineup must never change underneath
    ' the player afterwards.
    m.gridLineup = []
    m.gridContent = CreateObject("roSGNode", "ContentNode")

    ' The first page, built and handed over in one go exactly as the whole
    ' folder used to be. A folder of 150 channels or fewer is finished here and
    ' never arms the timer at all, so nothing about it changes.
    paintGridChunk(LiveGridFirstPage())
    m.grid.content = m.gridContent
    m.currentChannels = shown
    ' One write, complete, and after m.currentChannels so the two can never
    ' disagree about what is on screen. An empty folder or a search that
    ' matched nothing publishes an empty array here, not the last folder's.
    '
    ' A BIG FOLDER PUBLISHES TWICE, AND BOTH WRITES ARE WHOLE. This one covers
    ' the channels that are on screen now; the fill publishes again, once, when
    ' the last page is built and the list covers the whole folder. Neither
    ' write is ever a half-filled array, which is the rule this field has
    ' always followed — the player simply has fewer channels to step through
    ' for the second or two the fill takes.
    publishLiveLineup(gridLineupCopy())
    m.emptyLabel.visible = (shown.count() = 0)
    ' "Nothing matched what you typed" and "this folder is empty" are two
    ' different things, and letting one line mean both is the confusion
    ' GuideScreen.showBucketEmptyState exists to avoid. Say which it is, and
    ' say plainly WHERE the search looked.
    if shown.count() = 0 and m.query <> ""
        m.emptyLabel.text = Chr(34) + m.query + Chr(34) + " — no channel in this category matches. The search looks at the category you are in, so try another one on the left, or press Up and choose Show all."
    else
        m.emptyLabel.text = "No channels in this category."
    end if
    armGridFill()
end sub

' How many tiles go up before the member is shown anything, and how many are
' added per turn after that.
'
' 150 IS THE HOUSE NUMBER, not a new one — it is what the TV Guide holds per
' tab. The grid shows sixteen tiles at a time, so it is nine screens of
' scrolling in hand before the fill has to keep up, and the fill adds a
' hundred every tenth of a second, which no one can scroll past.
function LiveGridFirstPage() as integer
    return 150
end function

function LiveGridPage() as integer
    return 100
end function

' Add up to howMany more tiles to the content node the grid is holding.
'
' EVERY FIELD IS SET BOTH WAYS ON EVERY TILE, tag or no tag, caption or no
' caption — these cards are recycled, and a field left unset keeps the last
' channel's value on the next one.
'
' GetField on the way in. The two channel shapes this screen holds (M3U-parsed
' and Xtream-parsed) do not carry all the same keys, and a missing one read
' straight out is a type mismatch rather than a blank — which is why the
' player's copy below has always read them this way.
sub paintGridChunk(howMany as integer)
    shown = m.gridShown
    content = m.gridContent
    if shown = invalid or content = invalid then return
    nowTitles = m.gridTitles
    if nowTitles = invalid then nowTitles = []
    i = m.gridBuilt
    upTo = i + howMany
    if upTo > shown.count() then upTo = shown.count()
    while i < upTo
        ch = shown[i]
        item = content.createChild("ContentNode")
        item.title = ToStr(GetField(ch, "name"))
        item.hdPosterUrl = ToStr(GetField(ch, "logo"))
        ' With several sources, say whose channel each one is — the same
        ' source tag Android puts on channel cards in a merged folder. It
        ' rides as its own field so the card can draw it on the artwork
        ' instead of stealing room from the channel name.
        ' srcTok rides along so the card can COLOUR the tag by source without
        ' looking anything up mid-scroll. It is always set, tag or no tag —
        ' the card decides whether to draw.
        tag = ""
        if m.multi then tag = ShortSrcLabel(ToStr(m.srcLabels[ToStr(GetField(ch, "src"))]))
        ' nowTitle rides on the node the same way srcLabel does, so the card
        ' draws it without looking anything up mid-scroll.
        ' epgKey is the card's way of asking "did a caption for THIS channel
        ' land after the grid was built?" — one associative-array hit against
        ' the session map, no lookup and no request.
        ' nowKeyFor, NOT epgKeyFor — the DISPLAY key, which every channel has,
        ' including the M3U ones that must never be asked about. See nowKeyFor.
        caption = ""
        if i < nowTitles.count() then caption = ToStr(nowTitles[i])
        item.addFields({ srcLabel: tag, srcTok: ToStr(GetField(ch, "src")), nowTitle: caption, epgKey: nowKeyFor(ch) })
        m.gridLineup.push({
            streamId: ToStr(GetField(ch, "streamId"))
            name: ToStr(GetField(ch, "name"))
            logo: ToStr(GetField(ch, "logo"))
            url: ToStr(GetField(ch, "url"))
            src: ToStr(GetField(ch, "src"))
        })
        i = i + 1
    end while
    m.gridBuilt = i
end sub

' A copy of the zap list as it stands, so the array handed to the player can
' never be the one the fill is still pushing onto.
function gridLineupCopy() as object
    out = []
    for each e in m.gridLineup
        out.push(e)
    end for
    return out
end function

' Set the next page going, or finish and tidy up.
sub armGridFill()
    if m.gridShown = invalid
        releaseGridFill()
        return
    end if
    if m.gridBuilt >= m.gridShown.count()
        ' Finished. ONLY A FOLDER THAT ACTUALLY NEEDED A SECOND PAGE does
        ' anything here: a folder of 150 or fewer was complete the moment
        ' fillGridInner handed it over, and it must stay exactly as it is
        ' today. A second identical write of a global field on every repaint
        ' would also mean one per keystroke of the search box.
        if m.gridShown.count() > LiveGridFirstPage()
            settleGridContent()
            ' The zap list now covers the whole folder. One write, whole.
            publishLiveLineup(gridLineupCopy())
        end if
        releaseGridFill()
        return
    end if
    if m.gridTimer = invalid
        ' Built the same way the category paint timer and the caption dwell
        ' are: once, on first use, with its callback attached once.
        m.gridTimer = CreateObject("roSGNode", "Timer")
        m.gridTimer.duration = 0.1
        m.gridTimer.repeat = false
        m.gridTimer.observeField("fire", "onGridFill")
    end if
    ' Stamped so a fire that was already on its way when the member moved to
    ' another folder is thrown away instead of adding the old folder's tiles.
    m.gridFillGen = m.gridGen
    m.gridTimer.control = "stop"
    m.gridTimer.control = "start"
end sub

' ---- THE BELT: hand the finished folder to the grid once, at the end -------
'
' WHY THIS EXISTS AT ALL. The fill above adds its pages by appending children
' to the content node the grid is ALREADY holding. Every Roku sample for
' loading a long list a page at a time does it that way and it is meant to
' work — but the office stick has been off for twelve days and nobody in this
' house has watched it work on a television. If it quietly does not, a member
' with a 2,000-channel folder reaches tile 150 and the other 1,850 are simply
' unreachable, which is a WORSE outcome than the timeout being fixed: the
' timeout at least eventually drew everything. So the folder is handed over
' once more when the fill is done.
'
' >>> WHY IT IS NOT JUST "m.grid.content = m.gridContent" <<<
'
' Because that is very probably a no-op, and a no-op is not a belt. SceneGraph
' does not notify on a field set to the value it already holds unless the field
' was declared alwaysNotify, and by this point m.grid.content IS m.gridContent
' — the same node object. Assigning it to itself would cost nothing and change
' nothing, in the good case AND in the bad one.
'
' So an empty ContentNode goes in first, which makes the value genuinely
' change, and then the finished node. An EMPTY NODE rather than invalid on
' purpose: this file already hands the grid an empty ContentNode in two places
' (a locked folder, and clearGridAfterFailure), so it is a value this grid is
' known to take.
'
' Both assignments happen in the same turn of the render thread, before
' anything is composited, so there should be nothing to see. NOT VERIFIED ON A
' TELEVISION — if a flicker shows up on the stick, this is the line that makes
' it.
'
' PUTTING THE MEMBER BACK. Re-assigning content sends an ArrayGrid back to the
' top, which on a folder somebody is reading would be its own bug. jumpToItem
' immediately after the content lands is the house answer to exactly this and
' it is already shipping in two places — HomeScreen rebuilds every row this way
' ("there is no visible snap and no second layout pass") and ManageChannelsScreen
' rebuilds its channel column this way on every keystroke. jumpToItem, not
' animateToItem: this is restoring a position, not travelling to one.
'
' Nothing is done when they never left the first tile, which is the ordinary
' case — the fill takes a second or two and it starts the moment they arrow
' onto the folder.
'
' ONCE, AND ONLY FOR A FOLDER THAT NEEDED IT. Per page would reset the scroll
' over and over and cost more than the bug. The caller only reaches this on the
' last page of a folder longer than the first page.
sub settleGridContent()
    if m.gridContent = invalid or m.gridShown = invalid or m.grid = invalid then return
    ' The same stamp the fill itself checks. Only reachable from the timer
    ' path, which has already tested it, but the guarantee is worth having
    ' here rather than borrowed from the caller: a folder the member has left
    ' must never have its tiles pushed onto the grid they are looking at now.
    if m.gridFillGen <> m.gridGen then return
    keepAt = m.grid.itemFocused
    hadFocus = m.grid.hasFocus()
    m.grid.content = CreateObject("roSGNode", "ContentNode")
    m.grid.content = m.gridContent
    if keepAt < 0 then keepAt = 0
    if keepAt > m.gridBuilt - 1 then keepAt = m.gridBuilt - 1
    if keepAt > 0 then m.grid.jumpToItem = keepAt
    ' Belt and braces on the belt: clearing the content for an instant must not
    ' cost the member the highlight they were holding.
    if hadFocus then m.grid.setFocus(true)
    ' ONE LINE, ONCE PER FOLDER, and it is the line the next log sweep gets
    ' read for. It says how big the folder was, how many tiles were actually
    ' built onto the node, and where the member was put back. A "holds" number
    ' that does not match the folder size would mean something emptied the node
    ' underneath us, which is a fault nobody would otherwise ever see.
    '
    ' WHAT IT CANNOT TELL US, and this is worth being straight about: there is
    ' no cheap way to ask the grid how many tiles IT took. getChildCount() here
    ' counts our own node's children, which are all present either way, so it
    ' answers the question "did we build them", not "did the grid notice".
    ' Only a television answers the second one.
    KLog("livetv", "this folder holds " + m.gridShown.count().toStr() + " channels; drew the first " + LiveGridFirstPage().toStr() + " straight away, filled the rest in behind them, then handed the finished list of " + m.gridContent.getChildCount().toStr() + " to the grid (back on tile " + keepAt.toStr() + ")")
end sub

' Stop the fill and let go of what it was holding. The content node itself is
' NOT thrown away — the grid owns it now; this only drops this screen's second
' reference to it.
sub releaseGridFill()
    if m.gridTimer <> invalid then m.gridTimer.control = "stop"
    m.gridShown = invalid
    m.gridTitles = invalid
    m.gridContent = invalid
    m.gridBuilt = 0
end sub

sub onGridFill()
    try
        onGridFillInner()
    catch e
        GuardFailed("livetv/onGridFill", e)
        releaseGridFill()
    end try
end sub

sub onGridFillInner()
    ' FIRST, ahead of everything else, the same rule the caption dwell follows:
    ' this is an orphan Timer and a torn-down screen must not be drawn into.
    if liveScreenIsGone()
        releaseGridFill()
        return
    end if
    ' An older folder's fill. Dropped, not continued — its tiles would land on
    ' the folder the member is looking at now.
    if m.gridFillGen <> m.gridGen then return
    if m.gridShown = invalid or m.gridContent = invalid then return
    paintGridChunk(LiveGridPage())
    armGridFill()
end sub

' The grid could not be built at all. Leave nothing standing that belongs to a
' folder the member is no longer on — see "WHAT THE MEMBER SAW" above fillGrid.
sub clearGridAfterFailure()
    releaseGridFill()
    m.currentChannels = []
    m.nowTitles = []
    m.nowCovered = []
    if m.grid <> invalid then m.grid.content = CreateObject("roSGNode", "ContentNode")
    publishLiveLineup([])
    if m.emptyLabel <> invalid
        m.emptyLabel.visible = true
        m.emptyLabel.text = "This category was too big for this television to draw. Pick a smaller one on the left, or press Up and search for the channel you want."
    end if
end sub

' The search itself: a case-insensitive "contains" over names, the same test
' the TV Guide's filter and the Search screen both make. No request, no
' registry read, no clock read — a folder-sized loop over an array that is
' already in hand, which is what keeps it inside the 250 ms certification 3.5
' gives a remote press.
function filterChannelsByName(chans as object) as object
    q = m.queryLc
    if q = "" then return chans
    out = []
    for each ch in chans
        nm = ToStr(GetField(ch, "name"))
        if nm = "" then continue for
        ' The query was lowercased once, in applyChannelFilter.
        if LCase(nm).instr(0, q) < 0 then continue for
        out.push(ch)
    end for
    return out
end function

' ---- What's on now, for a whole folder at a time -----------------------------
'
' Returns one programme title per channel, index-aligned with `shown`.
'
' THE RULE THIS OBEYS. Android does not ask per tile either: it collects
' every EPG id in the folder, joins them into one key and makes ONE batched
' query for the lot (channel_group_screen.dart:44-51 builds the id set,
' _nowPlayingProvider at :272-288 runs the single nowAndNextForAll and keeps
' the first programme that has already started and has not yet ended). This
' is that, in Roku terms: the equivalent local store here is the session's
' parsed XMLTV, which the app fetches ONCE per launch (startXmltv above,
' shared with the TV Guide and the channel pages through m.global), so the
' whole folder is answered out of memory with no request of any kind. A
' per-tile get_short_epg would be the 2026-08-14 ban all over again, and
' there is no Xtream call that answers a folder in one go — the batched
' feed IS the XMLTV file we already have.
'
' Cost is a folder-sized loop of associative-array hits, paid once when the
' folder is opened, and NOT paid per card while the grid recycles. Repeats
' inside a folder are memoised, because a provider often lists the same
' station several times (HD/SD/backup) against one guide id.
' It also writes m.nowCovered, index-aligned with what it returns: true where
' the loaded guide NAMES this channel at all, whether or not it has anything
' running on it this minute. The captions and the coverage come out of the same
' two lookups, so working them out separately would be paying for the match
' twice — and the dwell below needs the coverage, not the caption: a channel
' the guide covers must not be asked about one at a time even when its caption
' is blank, because the guide and the single-channel call are the same panel
' answering the same question.
function nowPlayingTitles(shown as object) as object
    out = []
    covered = []
    m.nowCovered = covered
    if m.global.xmltvState <> "ready"
        for each ch in shown
            out.push("")
            covered.push(false)
        end for
        return out
    end if
    ' Read the shared maps ONCE into locals: every `m.global.x` is a field
    ' read, and there are hundreds of channels in a big folder.
    byId = m.global.xmltvById
    aliases = m.global.xmltvAliases
    ' The callsign fallback picks apart the channel's NAME character by
    ' character, so it is only worth attempting when a guide that carries
    ' aliases has actually been loaded (only the TV Guide's fetch fills this
    ' in). Without the check, a folder of several hundred channels pays for
    ' several hundred name scans on every arrow press down the category
    ' list, and this folder is rebuilt on every one of them —
    ' certification 3.5 gives the remote 250ms to answer.
    hasAliases = (aliases <> invalid and aliases.count() > 0)
    now = CreateObject("roDateTime").asSeconds()
    memo = {}
    for each ch in shown
        title = ""
        ' The guide's own id first, then the callsign fallback — the same
        ' two-step GuideScreen.xmltvKeyFor makes, because an uploaded guide
        ' often numbers its channels nothing like the provider does.
        tid = ToStr(GetField(ch, "tvgId"))
        if tid = "" or not byId.doesExist(tid)
            tid = ""
            if hasAliases
                tid = EpgAliasLookup(aliases, ToStr(GetField(ch, "name")))
                if tid <> "" and not byId.doesExist(tid) then tid = ""
            end if
        end if
        if tid <> ""
            if memo.doesExist(tid)
                title = memo[tid]
            else
                for each p in byId[tid]
                    ' Started, and not finished — the same test Android
                    ' makes and the same one Multi-View's Now: line makes.
                    if p.startS <= now and p.stopS > now
                        title = ToStr(p.title)
                        exit for
                    end if
                end for
                memo[tid] = title
            end if
        end if
        out.push(title)
        ' tid is non-blank only when it survived the doesExist() tests above,
        ' so this is "the guide named this channel" and not "the channel had
        ' an id".
        covered.push(tid <> "")
    end for
    ' One line, once per screen, so a member's log says whether the captions
    ' are coming from a guide at all — and never one line per channel.
    if not m.nowLogged
        m.nowLogged = true
        got = 0
        for each t in out
            if t <> "" then got = got + 1
        end for
        KLog("livetv", "what's on now: matched " + got.toStr() + " of " + out.count().toStr() + " channels to the loaded guide")
    end if
    return out
end function

' The guide landed after this folder was already on screen. Repaint the
' tiles so the captions appear — but only while the member is not standing
' in the grid. Re-assigning the grid's content resets its scroll position,
' and snapping somebody back to the first channel because a background fetch
' finished is worse than a folder that stays caption-less until they move.
sub refillNowPlaying()
    if m.global.xmltvState <> "ready" then return
    if m.grid.hasFocus() then return
    if m.currentCatId = invalid then return
    if m.channelsByCat.doesExist(m.currentCatId) then fillGrid(m.channelsByCat[m.currentCatId])
end sub

' ---- What's on now for an XTREAM channel: THE FALLBACK -----------------------
'
' READ THE CHAIN NOTE ABOVE startXmltv FIRST. The batched guide is the main
' road now: each Xtream panel's own xmltv.php goes on the end of the guide
' chain, is read once per launch like any other guide, and answers every
' channel it names at once with no per-channel request at all. What follows is
' what happens for the channels that guide could NOT answer.
'
' THE PROBLEM IT SOLVES. Not every panel serves xmltv.php. Some answer 404,
' some hand back a login or error page instead of a guide, some answer with
' nothing at all, and some serve one so large it trips XmltvTask's 24 MB cap or
' so long it fills the 12,000-programme ceiling part way down the file. In
' every one of those cases the source's channels are exactly where they were
' before the batch existed: uncovered, with a blank caption under every tile.
' That is what this fills in.
'
' HOW THE TWO AVOID DOING THE SAME WORK. One test, made per channel and not per
' guide: did the loaded guide NAME this channel? nowPlayingTitles writes that
' into m.nowCovered as it works out the captions, off the same two lookups, so
' it costs nothing extra — and onEpgDwell refuses to ask about a covered
' channel even when its caption is blank, because a blank caption on a covered
' channel means the panel already told us nothing is on. A channel the guide
' never mentioned is the only kind that reaches the code below. Per channel
' rather than per source is what makes a partly-read guide behave sensibly: the
' channels it got to are answered from memory and the ones past the cap fill in
' here, on the same budgets, as the member browses.
'
' The second half of the same test is publishNowFromGuide, which drops the
' covered channels' captions into the session map requestNowFor already treats
' as "asked and answered" — so a covered channel is settled twice over, once by
' the coverage flag and once by the ledger.
'
' WHAT THIS IS NOT. It is NOT "fetch the EPG for each tile as it renders".
' That is the loop that got this house's address banned on 2026-08-14 (see
' Util.brs above StreamErrorKind, and HomeScreen's opening note). A Live TV
' grid recycles tiles dozens per second while somebody holds the arrow down;
' anything hung off rendering would fire hundreds of requests in seconds.
' NOTHING here is triggered by a tile being drawn. There is no queue that
' keeps running in the background and no prefetch loop.
'
' WHAT IT IS. One request, for ONE channel, when a person has STOPPED on it.
' The trigger is a dwell: every key press restarts a 600 ms timer, and only
' when that timer actually fires — cursor at rest, grid holding focus, no
' player open — is a single get_short_epg sent for the channel under the
' cursor. Scrolling costs nothing at all, because the timer never reaches
' the end of its count while keys are arriving. Holding the arrow down
' across four hundred channels costs exactly zero requests.
'
' THE RATE THIS CAN REACH, which is the whole point:
'   · at most ONE request per 600 ms, and only if a human stops that often;
'   · at most EPGMAXINFLIGHT() (3) unanswered at any moment — a settle that
'     would exceed that is dropped, not queued, because a queued request
'     fires later and is no longer tied to where the member is looking;
'   · at most EPGMAXPERCAT() (40) per folder viewed;
'   · at most EPGMAXPERSESSION() (200) per launch of the app, across every
'     folder and every visit to this screen.
' For comparison, the TV Guide sends up to 150 of the same request six at a
' time, back to back, on a single visit (GuideScreen.pumpCatQueue). This is
' materially gentler than a screen that already ships.
'
' WHY ONLY THE FOCUSED TILE, and not its neighbours as well. In a four-column
' grid, "the focused row" or "focus plus left and right" triples the cost of
' the commonest movement there is — arrowing straight down a column to get
' through a folder. Fifteen rows costs 15 requests this way and 45 the other,
' and two thirds of those 45 are for tiles the member never looked at. The
' caption people actually read is the one under the tile they are on, and
' every one that lands is kept, so a folder fills in as it is browsed.
'
' WHY THIS IS STILL HERE now the panel's own xmltv.php is fetched. It used to
' say the batched guide was the better answer and was not available: XmltvTask
' pulled a whole document into one string before it could measure it, and a
' panel guide well over a hundred megabytes is precisely what killed this app
' with EXIT_CHANNEL_MEM_LIMIT_FG. That is fixed — XmltvTask streams to cachefs,
' refuses an oversized guide on a HEAD pre-check and cancels mid-download past
' the cap — and the batch is wired in above. This stays because "the panel
' serves a batched guide" is not something an app can assume: see the list of
' ways a panel says no in the note at the top of this section. Deleting this
' would take the captions away from every household with such a panel.
'
' NONE OF ITS BUDGETS MOVED. Same 600 ms dwell, same 3 in flight, same 40 per
' folder, same 200 per launch. The batch does not buy the fallback more room;
' it means the fallback is asked for less.
'
' WHAT THE MEMBER SEES WHILE ONE IS IN FLIGHT: nothing. No caption, no
' spinner, no "Loading…" — a caption band that appears with a placeholder and
' then vanishes because the panel had no listing reads as a fault. It stays
' blank and the real one drops in when it lands.

function EPGDWELLSECONDS() as float
    return 0.6
end function

function EPGMAXINFLIGHT() as integer
    return 3
end function

function EPGMAXPERCAT() as integer
    return 40
end function

function EPGMAXPERSESSION() as integer
    return 200
end function

' The session key for a channel's listings — the same shape the TV Guide
' uses (source token + stream id), so the two never disagree about what
' identifies a channel. Blank means "there is nothing to ask": no stream id,
' an unknown source, or an M3U source, which has no panel behind it.
function epgKeyFor(ch as object) as string
    sid = ToStr(GetField(ch, "streamId"))
    if sid = "" then return ""
    tok = ToStr(GetField(ch, "src"))
    p = m.provBySrc["t" + tok]
    if p = invalid then return ""
    if ToStr(p.ptype) = "m3u" then return ""
    return tok + "|" + sid
end function

' THE DISPLAY KEY. epgKeyFor above is the REQUEST key and answers "" for
' anything this screen must never ask a panel about — an M3U channel, a
' channel with no stream id, a source that has gone away. That is exactly
' right for requestNowFor and exactly wrong for the caption, and until now
' they were the same function.
'
' WHAT THAT COST, and it is the owner's complaint of 2026-08-26 ("the black
' bar ... shouldnt be a hover thing, that should show by default"). The
' caption on a tile comes from one of two places: the nowTitle written onto
' the content node when the folder was painted, or the session map the cards
' watch. A playlist household gets its captions from the FIRST of those, free,
' with no request of any kind — but only if the guide was already parsed when
' the folder was painted. Open Live TV before the guide download finishes,
' step into the grid, and the guide landing could not reach those tiles:
' publishNowFromGuide keyed the map with epgKeyFor, which is blank for every
' M3U channel, so it published nothing for them; and refillNowPlaying refuses
' to repaint a grid the member is standing in, because re-assigning content
' throws them back to the first channel in the folder. The tiles stayed blank
' for the rest of that folder, and moving to another folder — which repaints —
' is what made it look like a focus effect.
'
' So the two keys are separated. This one exists for every channel that can be
' identified at all, requestNowFor still uses epgKeyFor and so still cannot
' reach an M3U channel, and the "m|" prefix cannot collide with an Xtream key
' (which is "<srcToken>|<streamId>", and a source token is never "m").
'
' NO REQUEST, NO BUDGET, NO NEW STATE. Same map, same 400-entry publish cap,
' same expiry. It only lets titles the app already has in memory reach tiles
' that are already on screen.
function nowKeyFor(ch as object) as string
    k = epgKeyFor(ch)
    if k <> "" then return k
    ' Keyed on the GUIDE's own id, not the stream id, because that is what an
    ' M3U channel is matched to a listing by. A playlist channel with no
    ' tvg-id has nothing to look a caption up with and gets no key.
    id = ToStr(GetField(ch, "tvgId"))
    if id = "" then return ""
    return "m|" + ToStr(GetField(ch, "src")) + "|" + id
end function

' Every key press comes through onKeyEvent and lands here, so the countdown
' restarts on each one. That is the whole throttle: the timer only ever
' reaches the end of its count once the remote has gone quiet.
sub armEpgDwell()
    if m.global = invalid then return
    if m.epgTimer = invalid
        ' Built the same way the category paint timer above is.
        m.epgTimer = CreateObject("roSGNode", "Timer")
        m.epgTimer.duration = EPGDWELLSECONDS()
        m.epgTimer.repeat = false
        m.epgTimer.observeField("fire", "onEpgDwell")
    end if
    m.epgTimer.control = "stop"
    m.epgTimer.control = "start"
end sub

sub cancelEpgDwell()
    if m.epgTimer <> invalid then m.epgTimer.control = "stop"
end sub

sub resetCatEpgBudget()
    if m.epgCatCount > 0
        KLog("livetv", "what's on now: asked the panel about " + m.epgCatCount.toStr() + " channel(s) in that folder")
    end if
    m.epgCatCount = 0
    m.epgCatLogged = false
end sub

' The cursor moved. Nothing is fetched here — this only restarts the count.
sub onChannelFocused()
    try
        onChannelFocusedInner()
    catch e
        GuardFailed("livetv/onChannelFocused", e)
    end try
end sub

sub onChannelFocusedInner()
    if liveScreenIsGone() then return
    armEpgDwell()
end sub

' The remote has been quiet for the dwell. If the member is still standing on
' a tile, ask about THAT channel and nothing else.
sub onEpgDwell()
    try
        onEpgDwellInner()
    catch e
        GuardFailed("livetv/onEpgDwell", e)
    end try
end sub

sub onEpgDwellInner()
    ' FIRST, ahead of every other test. This is an orphan Timer with a 600 ms
    ' fuse: it is the fastest way a dead screen gets called back into, and a
    ' request started from here would be a request for a tile nobody is looking
    ' at - which is the pattern the whole budget exists to prevent.
    if liveScreenIsGone() then return
    if m.player <> invalid then return          ' a stream is opening; stay off the wire
    if m.mvScreen <> invalid or m.mvPicker <> invalid then return
    ' The search keyboard is up. The focus test below already covers it — a
    ' modal dialog takes focus off the grid — but this is said out loud
    ' because "a lookup must never race a dialog the member is dictating
    ' into" is a rule, not a side effect of where focus happens to be.
    if m.kbDialog <> invalid then return
    if not m.grid.hasFocus() then return        ' browsing folders, not channels
    if m.currentChannels = invalid then return
    idx = m.grid.itemFocused
    if idx < 0 or idx >= m.currentChannels.count() then return
    ' Already captioned from the guide file — an M3U/XMLTV household never
    ' reaches the network from this screen at all.
    if idx < m.nowTitles.count()
        if ToStr(m.nowTitles[idx]) <> "" then return
    end if
    ' Covered by the guide but with nothing running on it this minute. Still
    ' nothing to ask for: the batched guide came from the same panel a
    ' get_short_epg would go to, so the answer is already in hand and it is
    ' "nothing". Without this the blank caption on a covered channel would be
    ' the ONE case where the batched guide and the one-at-a-time path both did
    ' the same work — which is exactly the duplication the batch exists to
    ' remove, and it would spend the folder budget doing it.
    if idx < m.nowCovered.count()
        if m.nowCovered[idx] = true then return
    end if
    requestNowFor(m.currentChannels[idx])
end sub

' Drop cached captions that have run out. Returns nothing; only re-assigns
' the map the cards watch if something actually went, so a folder change
' doesn't repaint every tile for no reason.
'
' A channel whose caption expires becomes askable again — that is the ONLY
' way the same channel is ever requested twice in a launch, it needs the
' member to stop on it a second time, and it still comes out of the same two
' budgets as everything else.
sub pruneExpiredNow()
    if m.global = invalid then return
    was = m.global.liveNowUntil
    if was.count() = 0 then return
    now = CreateObject("roDateTime").asSeconds()
    dead = false
    for each k in was
        if ToInt(was[k]) <= now
            dead = true
            exit for
        end if
    end for
    if not dead then return
    old = m.global.liveNowById
    keepU = {}
    keepT = {}
    for each k in was
        if ToInt(was[k]) > now
            keepU[k] = was[k]
            if old.doesExist(k) then keepT[k] = old[k]
        end if
    end for
    m.global.liveNowUntil = keepU
    m.global.liveNowById = keepT
end sub

' A fresh copy of a session map with one key set.
'
' BUILT FRESH, NOT MUTATED. Reading a global assocarray field and writing
' back the very same object is the classic SceneGraph trap: the cards watching
' it may never be told anything changed, and the caption then sits invisible
' until something else repaints the grid. Every other index in this app that
' the cards watch is rebuilt whole for the same reason (HomeScreen's
' refreshResumeVodIndex builds `idx = {}` from scratch and assigns that).
' These maps hold at most EPGMAXPERSESSION() short entries, so a copy costs
' nothing worth counting and happens only when an answer lands.
function mapWith(src as object, key as string, value as dynamic) as object
    out = {}
    for each k in src
        out[k] = src[k]
    end for
    out[key] = value
    return out
end function

sub requestNowFor(ch as object)
    key = epgKeyFor(ch)
    if key = "" then return
    ' Asked once, answer or no answer: a blank entry is still an answer and
    ' must stop the channel being asked about again. Same idea as
    ' GuideScreen's m.epgCache/m.epgPending pair, one for settled and one for
    ' in flight — with an expiry on top, because unlike the guide's grid this
    ' caption claims to be about right now. pruneExpiredNow clears the entry
    ' first if its programme has ended.
    pruneExpiredNow()
    if m.global.liveNowById.doesExist(key) then return
    if m.epgPending.doesExist(key) then return
    if m.epgInflight >= EPGMAXINFLIGHT() then return

    if m.global.liveEpgCount >= EPGMAXPERSESSION()
        if not m.epgSessLogged
            m.epgSessLogged = true
            KLog("livetv", "what's on now: reached this session's limit of " + EPGMAXPERSESSION().toStr() + " lookups - the captions already loaded stay, no more will be fetched until you reopen the app")
        end if
        return
    end if
    if m.epgCatCount >= EPGMAXPERCAT()
        if not m.epgCatLogged
            m.epgCatLogged = true
            KLog("livetv", "what's on now: reached the limit of " + EPGMAXPERCAT().toStr() + " lookups for this folder - open another folder to carry on")
        end if
        return
    end if

    sep = Instr(1, key, "|")
    tok = Left(key, sep - 1)
    sid = Mid(key, sep + 1)
    prov = m.provBySrc["t" + tok]
    if prov = invalid then return

    m.epgPending[key] = true
    m.epgInflight = m.epgInflight + 1
    m.epgCatCount = m.epgCatCount + 1
    m.global.liveEpgCount = m.global.liveEpgCount + 1

    if not m.epgStartLogged
        m.epgStartLogged = true
        KLog("livetv", "no guide file for these channels - filling in what's on now one channel at a time, as you stop on each")
    end if

    task = CreateObject("roSGNode", "ApiTask")
    task.tag = key
    ' limit=4, not the guide's 30. All that is wanted is the programme
    ' covering this minute; four covers a panel that starts its list at the
    ' one that just ended. Fewer listings is less to download and less to
    ' parse on a box that is already tight for memory.
    task.url = XtreamApiUrl(prov, "get_short_epg") + "&stream_id=" + UrlEncode(sid) + "&limit=4"
    ' Shorter than the 25s default. A caption is a nicety; a task thread held
    ' open for half a minute waiting for one is not worth having, and Roku
    ' kills an app that runs too many at once.
    task.timeoutMs = 15000
    task.observeField("result", "onNowEpg")
    m.inflight["nowepg_" + key] = task
    task.control = "RUN"
end sub

sub onNowEpg(event as object)
    try
        onNowEpgInner(event)
    catch e
        GuardFailed("livetv/onNowEpg", e)
    end try
end sub

' NO GATE, same reasoning as onLiveGuideXmltv: nothing in here touches a node.
' The answer goes into the session caption map the CARDS watch, so a reply that
' lands after the member walked off is still worth keeping - it is the one
' thing that stops that channel being asked about a second time.
sub onNowEpgInner(event as object)
    res = event.getData()
    key = ToStr(event.getRoSGNode().tag)
    m.inflight.delete("nowepg_" + key)
    m.epgPending.delete(key)
    m.epgInflight = m.epgInflight - 1
    if m.epgInflight < 0 then m.epgInflight = 0

    ' Resolved to a single title HERE, on the render thread, once — never on
    ' the card. The card gets one associative-array hit and no clock read, the
    ' same deal resumePct() gets, because it runs on every recycled tile.
    title = ""
    now = CreateObject("roDateTime").asSeconds()
    ' A panel that said nothing useful is remembered for half an hour rather
    ' than for ever: some panels fill their guide in late, and a channel that
    ' answered blank at launch should get one more chance later in a long
    ' session without being re-asked on every dwell in between.
    goodUntil = now + 1800
    if res <> invalid and res.ok = true
        for each e in ToArray(GetField(res.data, "epg_listings"))
            startS = ToInt(GetField(e, "start_timestamp"))
            stopS = ToInt(GetField(e, "stop_timestamp"))
            ' Started, and not finished — the same test the XMLTV path above
            ' makes, and the same one Multi-View's Now: line makes.
            if startS <= now and stopS > now
                title = B64Decode(ToStr(GetField(e, "title")))
                ' Good until the programme ends, and no longer: this caption
                ' says "now", so it has to stop saying it when that stops
                ' being true.
                goodUntil = stopS
                exit for
            end if
        end for
    end if

    ' Written back as a whole map on purpose. Re-assigning m.grid.content
    ' would repaint the captions but would also throw the member back to the
    ' first channel in the folder (see refillNowPlaying), so instead the cards
    ' watch this one session map and redraw their own band — the same
    ' arrangement the resume bars use for resumeVodIndex.
    '
    ' The expiry map goes first because nothing observes it; assigning the
    ' caption map is what wakes the cards, so it is assigned last and the
    ' tiles repaint exactly once.
    m.global.liveNowUntil = mapWith(m.global.liveNowUntil, key, goodUntil)
    m.global.liveNowById = mapWith(m.global.liveNowById, key, title)
end sub

' ---- Playback --------------------------------------------------------------

sub onChannelSelected()
    try
        onChannelSelectedInner()
    catch e
        GuardFailed("livetv/onChannelSelected", e)
    end try
end sub

sub onChannelSelectedInner()
    if liveScreenIsGone() then return
    idx = m.grid.itemSelected
    if idx < 0 or idx >= m.currentChannels.count() then return
    ch = m.currentChannels[idx]

    ' A stream is about to be opened. Nothing else of ours goes near the
    ' provider while that happens — a lookup racing the connection is the
    ' shape of thing a max-connections-1 account gets banned for.
    cancelEpgDwell()

    ' Playback routes by the CHANNEL's source, not whatever is active —
    ' an Xtream channel plays with its own source's credentials.
    '
    ' >>> ONLY A PANEL CAN BUILD AN ADDRESS OUT OF A STREAM ID <<<
    '
    ' A channel that carries its own address (a playlist row) plays from that.
    ' A panel channel carries none — it is a stream id — so the address has to
    ' be built from a source. The test below is POSITIVE, naming the two kinds
    ' that can build one, which is the shape HomeScreen.resumeOrNext uses
    ' (:1149); the old `<> "m3u"` style test is what let a media server reach
    ' a panel-only builder on the Home page and halted the app there.
    '
    ' It matters because of the two fallbacks right above it. An src token
    ' whose source has been removed resolves to invalid, and ActiveProvider()
    ' then hands back whatever source happens to be first — any kind at all.
    ' ProviderForSrcToken("") does the same on a box with no KwickTV login.
    '
    ' LOG KEY FCF117 — Hisense 6Series-58, v1.0.39, 29 September 2026. In
    ' plain words: the member removed their source in Settings, a different
    ' one came back from the website on its own three seconds later, and the
    ' first channel they pressed Play on was a leftover from the source they
    ' had just taken out. The app fell back to the source that had just
    ' arrived — an ordinary playlist, with no panel address to build a stream
    ' from — and the television froze with the spinner still turning and
    ' nothing on screen to say why. That crash landed on the channel page, but
    ' this is the identical six lines and reaches the same dead end: a
    ' playlist row that carries no address of its own gets here too.
    url = LivePlayUrl(ToStr(ch.url))
    srcTok = ToStr(GetField(ch, "src"))
    if url = ""
        p = ProviderForSrcToken(srcTok)
        if p = invalid then p = ActiveProvider()
        pt = ""
        if p <> invalid then pt = LCase(ToStr(p.ptype))
        if pt = "xtream" or pt = "kwicktv"
            url = XtreamLiveUrl(p, ch.streamId)
        end if
    end if
    ' Checked before PushRecentChannel: a press that cannot become playback
    ' must not leave a trace of a channel the member never watched. This used
    ' to be a bare `return`, which is a button that does nothing at all.
    if url = ""
        cannotPlayNote(ToStr(ch.name))
        return
    end if

    chAA = { streamId: ToStr(ch.streamId), name: ToStr(ch.name), logo: ToStr(ch.logo), url: ToStr(ch.url), src: srcTok }
    PushRecentChannel(chAA)

    ' Attach to the SCENE, not this screen — the sidebar draws above the
    ' content layer, so a player inside it can never be truly fullscreen.
    m.player = m.top.getScene().createChild("PlayerScreen")
    m.player.titleText = ch.name
    m.player.channel = chAA
    m.player.streamUrl = url
    m.player.streamFormat = StreamFormatFor(url, "")
    m.player.isLive = true
    m.player.observeField("closed", "onPlayerClosed")
    m.player.setFocus(true)
    m.player.start = true ' all fields set — safe to play
end sub

sub onPlayerClosed()
    try
        onPlayerClosedInner()
    catch e
        GuardFailed("livetv/onPlayerClosed", e)
    end try
end sub

' The player is parented to the SCENE, so it outlives this screen and AppShell
' deliberately leaves a live one alone (AppShell.brs:445). That makes this one
' of the few callbacks that really can arrive on a detached screen. The player
' is NOT closed on the teardown path - it is not this screen's to kill - but
' its callback must not reach back in here.
sub onPlayerClosedInner()
    if liveScreenIsGone() then return
    if m.player <> invalid
        m.top.getScene().removeChild(m.player)
        m.player = invalid
    end if
    m.grid.setFocus(true)
end sub

sub setBusy(b as boolean)
    spinner = m.top.findNode("spinner")
    if spinner.poster.uri = "" then spinner.poster.uri = "pkg:/images/spinner.png"
    spinner.visible = b
    if b
        spinner.control = "start"
    else
        spinner.control = "stop"
    end if
end sub

' ---- Channel search ----------------------------------------------------------
'
' WHAT IT IS. The Roku half of Android's channel search
' (channel_list_screen.dart:149, results at :242): a chip on the header line
' that narrows the grid to channels whose name contains what you typed. It is
' deliberately the SAME chip, in the same place, with the same keyboard and
' the same wording as the TV Guide's channel filter, so the two screens feel
' like one feature rather than two.
'
' WHERE IT LOOKS. At the channels of the CATEGORY you are standing in, as
' already loaded — not at the provider's whole catalogue. That is the same
' bargain the guide's filter strikes, and it is what makes the next paragraph
' true. Pick a different category on the left and the search follows you into
' it; the empty-state line says so when nothing matches.
'
' WHAT IT DELIBERATELY DOES NOT DO — this is the whole of it:
'   · It starts NO request, of any kind. Not a category fetch, not a channel
'     fetch, not a get_short_epg. Certification 3.5 gives a remote press
'     250 ms, and there is nothing here but one pass over an array this
'     screen already holds.
'   · It does not touch the caption budgets. The dwell timer, the 3-in-flight
'     ceiling, the 40-per-folder count and the 200-per-launch count are all
'     driven from loadChannels (folder change) and onEpgDwell (cursor at
'     rest); searching re-runs fillGrid for the SAME folder, which resets
'     none of them and asks for nothing. Captions that already landed stay
'     — they live in the session map the cards read, not in the grid.
'   · It cannot reach a locked or an adult category. Adult categories were
'     dropped in mergeCategories before the list existed, and a locked
'     category never has its channels fetched at all (loadChannels returns
'     early with the "Locked" line), so there is nothing in m.channelsByCat
'     for a typed name to match. The strictness GuideScreen had to write by
'     hand is a property of this screen's load order.
'
' THE * BUTTON IS NOT THE WAY IN, unlike on the guide: on this screen * has
' always opened the channel menu, and taking it away would be worse than
' having two habits. Up from the category list — or up from the top row of
' the grid — lands on the chip, and OK opens the keyboard.

sub setupFilterBar()
    m.filterRing = m.top.findNode("filterRing")
    m.filterRing.color = m.theme.focusHighlight
    bg = m.top.findNode("filterBg")
    bg.color = m.theme.surface
    icon = m.top.findNode("filterIcon")
    icon.font = IconFont(30)
    icon.text = m.theme.iconSearch
    icon.color = m.theme.textSecondary
    m.filterText = m.top.findNode("filterText")
    ' 24 -> 22, matching the TV Guide's chip character for character — the two
    ' are deliberately the same control in the same place (see the note above).
    m.filterText.font = UiFont(22)
    redrawFilterBar()
end sub

sub redrawFilterBar()
    if m.query = ""
        m.filterText.text = "Search channels"
        m.filterText.color = m.theme.textSecondary
    else
        m.filterText.text = m.query
        m.filterText.color = m.theme.textPrimary
    end if
    m.filterRing.visible = m.filterFocus
end sub

' Move onto the chip from `fromPane` ("cats" or "grid"), remembering where
' Down should put the member back.
sub focusFilterBar(fromPane as string)
    m.filterFrom = fromPane
    m.filterFocus = true
    ' Any caption countdown belongs to the tile they just left. Stop it rather
    ' than let it fire against a grid that no longer holds focus.
    cancelEpgDwell()
    m.top.setFocus(true)
    redrawFilterBar()
end sub

sub leaveFilterBar()
    m.filterFocus = false
    redrawFilterBar()
    if m.filterFrom = "grid"
        m.grid.setFocus(true)
    else
        m.catList.setFocus(true)
    end if
end sub

' Roku's StandardKeyboardDialog, set up exactly as SearchScreen.openKeyboard
' and GuideScreen.openFilterKeyboard set it up — including the `wasClosed`
' observer, WITHOUT which Back closes the dialog through no button at all and
' leaves this screen with focus nowhere, answering no key. Voice comes with
' the dialog: hold the microphone and say the channel's name. Nothing is drawn
' and no image is added — the whole thing is the platform's.
sub openFilterKeyboard()
    kb = CreateObject("roSGNode", "StandardKeyboardDialog")
    kb.title = "Search channels"
    ' Always a fresh, empty box, set BEFORE the text box below is touched —
    ' the order the sign-in form uses and the one known to work.
    kb.text = ""
    ' "Show all" only when there is something to clear; an always-present
    ' button that does nothing is a D-pad stop for nothing.
    ' onFilterKeyboardButton reads the index off m.kbHasClear rather than
    ' assuming it.
    m.kbHasClear = (m.query <> "")
    if m.kbHasClear
        kb.buttons = ["Search", "Show all", "Cancel"]
    else
        kb.buttons = ["Search", "Cancel"]
    end if
    ' A channel name is ordinary words, not an address spelled out letter by
    ' letter. Roku's vocabulary is email / numeric / alphanumeric / generic /
    ' password and nothing else.
    kb.keyboardDomain = "generic"
    edit = kb.textEditBox
    ' Said on the box as well as on the dialog: keyboardDomain is documented as
    ' something the keyboard "may" act on, and the microphone is the point.
    edit.voiceEnabled = true
    edit.voiceEntryType = kb.keyboardDomain
    edit.maxTextLength = 128        ' Roku defaults to 15 — a spoken name is longer
    m.kbDialog = kb
    m.kbEdit = edit
    m.pendingSet = false
    m.pendingQuery = ""
    kb.observeField("buttonSelected", "onFilterKeyboardButton")
    kb.observeField("wasClosed", "onFilterKeyboardClosed")
    m.top.getScene().dialog = kb
end sub

' What was left in the box, typed or spoken. The dialog's own `text` is the
' documented place to read it from; the box is consulted only when the dialog
' says nothing, because dictation lands in the box first.
function filterKeyboardText() as string
    if m.kbDialog = invalid then return ""
    t = ToStr(m.kbDialog.text)
    if t = "" and m.kbEdit <> invalid then t = ToStr(m.kbEdit.text)
    return t
end function

' Dictation punctuates what it heard, so "history" can arrive as "History."
' and a plain "contains" test against the channel name would then match
' nothing. Only the ENDS are stripped and only on the query — the middle is
' left as spoken, and no channel name is ever normalised (that would be
' per-channel work over the whole folder).
function cleanFilterQuery(raw as string) as string
    q = raw.trim()
    junk = ".,!?;:"
    while q.len() > 0 and junk.instr(q.right(1)) > -1
        q = q.left(q.len() - 1)
    end while
    while q.len() > 0 and junk.instr(q.left(1)) > -1
        q = q.mid(1)
    end while
    return q.trim()
end function

sub onFilterKeyboardButton()
    try
        onFilterKeyboardButtonInner()
    catch e
        GuardFailed("livetv/onFilterKeyboardButton", e)
    end try
end sub

sub onFilterKeyboardButtonInner()
    if liveScreenIsGone() then return
    kb = m.kbDialog
    if kb = invalid then return
    b = kb.buttonSelected
    clearIdx = -1
    if m.kbHasClear then clearIdx = 1
    if b = 0
        ' An empty box — or speech Roku heard as nothing but punctuation —
        ' means "show everything again", not a search for "".
        m.pendingQuery = cleanFilterQuery(filterKeyboardText())
        m.pendingSet = true
    else if b = clearIdx
        m.pendingQuery = ""
        m.pendingSet = true
    end if
    ' Cancel (and Back, which never reaches here) leave the query alone.
    kb.close = true
end sub

' Every way out of the dialog lands here: Search, Show all, Cancel and Back.
sub onFilterKeyboardClosed()
    try
        onFilterKeyboardClosedInner()
    catch e
        GuardFailed("livetv/onFilterKeyboardClosed", e)
    end try
end sub

sub onFilterKeyboardClosedInner()
    if liveScreenIsGone() then return
    m.kbDialog = invalid
    m.kbEdit = invalid
    apply = m.pendingSet
    q = ToStr(m.pendingQuery)
    m.pendingSet = false
    m.pendingQuery = ""
    ' The dialog took the focus. Take it back to the chip — the member is
    ' still standing on it — or this screen answers no key at all.
    m.filterFocus = true
    m.top.setFocus(true)
    redrawFilterBar()
    if not apply then return
    if q = m.query then return          ' nothing actually changed
    applyChannelFilter(q)
end sub

' Re-derive the grid from what is already in hand. No request, no registry
' read, no re-fetch: m.channelsByCat is untouched, so this is exactly the work
' one arriving category answer already does.
sub applyChannelFilter(q as string)
    m.query = q
    m.queryLc = LCase(q)
    redrawFilterBar()
    ' A locked category has no channels loaded and is showing its own line —
    ' leave it saying that rather than repaint it into a search result.
    if m.currentCatId <> invalid and m.channelsByCat.doesExist(m.currentCatId)
        fillGrid(m.channelsByCat[m.currentCatId])
    end if
    if m.query = ""
        KLog("livetv", "channel search cleared")
    else
        n = 0
        if m.currentChannels <> invalid then n = m.currentChannels.count()
        KLog("livetv", "channel search " + Chr(34) + m.query + Chr(34) + " matched " + n.toStr() + " channel(s) in this category")
    end if
end sub

' ---- Keys ------------------------------------------------------------------

' THIS FILE HAD ZERO GUARDED HANDLERS UNTIL NOW, which is why log key 0D722F
' carries no line number: a BrightScript fault on the render thread kills the
' app, and the report that goes up on the next launch holds only the last log
' lines. That is the same gap that left the TV Guide's crash unexplained for
' four months until GuideScreen was wrapped, and it is why the chain in 0D722F
' could be traced to a stretch of lines but not to a statement.
'
' FALSE, NOT TRUE, ON A CAUGHT FAULT - and on this screen it matters more than
' it does on the guide. Two branches below return false ON PURPOSE so the key
' bubbles up to AppShell: Back from the category list (certification 4.6, one
' press to Home) and Back off the search chip, whose own comment says the false
' has to be inside the branch or Back does nothing at all. Returning true here
' would swallow both - the member's only way off a screen that has started
' faulting - and AppShell acts on nothing else, so every other key is a no-op
' either way. This is deliberately not what ChannelDetailScreen does, which
' returns true at ChannelDetailScreen.brs:2094 because Back is handled on that
' screen itself rather than bubbled.
'
' NOT GATED on liveScreenIsGone(). A detached screen holds no focus, so no
' press can reach it, and certification 3.5 gives this function 250 ms to
' answer - it is not the place to spend a tree walk on every press.
function onKeyEvent(key as string, press as boolean) as boolean
    try
        return onKeyEventInner(key, press)
    catch e
        GuardFailed("livetv/onKeyEvent", e)
    end try
    return false
end function

function onKeyEventInner(key as string, press as boolean) as boolean
    if not press then return false
    m.userMoved = true
    ' EVERY key press restarts the caption dwell — including the ones handled
    ' below and the ones passed on to the grid, which is why it sits here
    ' rather than in the arrow branches. While keys keep arriving the timer
    ' keeps going back to the start and nothing is ever fetched; see the long
    ' note above EPGDWELLSECONDS().
    armEpgDwell()

    ' The search chip. It is not a focusable node, so while it is "selected"
    ' the focus sits on this Group and every press arrives here — which means
    ' this block has to answer them all, including the ones that do nothing.
    ' Handled BEFORE the panes below, because neither list has focus now and
    ' those branches all ask which one does.
    if m.filterFocus = true
        if key = "OK"
            openFilterKeyboard()
        else if key = "down"
            leaveFilterBar()
        else if key = "back"
            ' Back is an EXIT: it bubbles to AppShell, which takes the member
            ' to Home in one press (AppShell.onKeyEvent, cert 4.6).
            '
            ' TWO THINGS ABOUT THIS BRANCH, both of which fail SILENTLY.
            '  1. `return false` MUST be here, inside the branch. This block
            '     ends in a bare `return true` a few lines down — a false put
            '     anywhere below is eaten, and the symptom is Back doing
            '     nothing at all on this view. No crash, no log line.
            '  2. The chip cleanup below has to run on BOTH paths. It is
            '     duplicated into each branch rather than hoisted, because
            '     hoisting it above the `if` would run it on OK and Down too.
            m.filterFocus = false
            redrawFilterBar()
            return false
        else if key = "left"
            ' Left is a DIRECTION: the chip is the top-left of the screen as
            ' far as the member is concerned, so Left from it goes to the
            ' sidebar, exactly as it always has.
            m.filterFocus = false
            redrawFilterBar()
            m.top.backToNav = true
        end if
        ' Up and Right have nothing to go to; swallowed rather than passed on
        ' so nothing below reacts to a press meant for the chip.
        return true
    end if

    if key = "back" or key = "left"
        ' From the grid, BOTH keys mean the same thing and still do: step back
        ' to the category list. That is a move within the screen, not an exit,
        ' so it is consumed either way.
        if m.grid.hasFocus()
            m.catList.setFocus(true)
            return true
        else if m.catList.hasFocus()
            ' From the category list the two part company. Left is a
            ' DIRECTION and walks to the sidebar; Back is an EXIT and bubbles
            ' to AppShell, which goes to Home in one press.
            if key = "back" then return false
            m.top.backToNav = true
            return true
        end if
    else if key = "right"
        if m.catList.hasFocus()
            m.grid.setFocus(true)
            return true
        end if
    else if key = "up"
        ' Only ever reached when the list or the grid did NOT consume Up —
        ' i.e. the cursor was already on the first row. That is the way onto
        ' the search chip from either pane.
        if m.catList.hasFocus()
            focusFilterBar("cats")
            return true
        else if m.grid.hasFocus()
            focusFilterBar("grid")
            return true
        end if
    else if key = "options"
        ' The * (Options) button opens a channel menu: Add to List / Hide /
        ' Watch Together / Favorites.
        if m.grid.hasFocus() then openChannelOptions()
        return true
    end if
    return false
end function

sub openChannelOptions()
    idx = m.grid.itemFocused
    if m.currentChannels = invalid or idx < 0 or idx >= m.currentChannels.count() then return
    m.optTarget = m.currentChannels[idx]
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = ToStr(m.optTarget.name)
    ' The label says which way the toggle goes, exactly as the channel page's
    ' own button does (ChannelDetailScreen.buildButtons) — the two must never
    ' disagree about whether a channel is already a favourite, so they ask the
    ' same helper the same question with the same token.
    favLabel = "Add to Favorites"
    if IsFavoriteChannel(ToStr(m.optTarget.streamId), optTargetSrc()) then favLabel = "Remove from Favorites"
    ' EVERY NEW ENTRY GOES IN BEFORE "Cancel" AND AFTER THE EXISTING ONES.
    ' These indexes are positional and onChannelOptions dispatches on the
    ' number, so 0/1/2 must keep meaning Add to List / Hide / Watch Together
    ' forever. Cancel is the only one that may move, because nothing handles
    ' it: it falls off the end of the if-chain below and simply returns focus
    ' to the grid, which is what Cancel should do at any index. (Same rule the
    ' "Watch Together" note left behind when it was added the same way.)
    dialog.buttons = ["Add to List", "Hide Channel", "Watch Together", favLabel, "Cancel"]
    dialog.observeField("buttonSelected", "onChannelOptions")
    m.top.getScene().dialog = dialog
end sub

' The source token of the channel the * menu is open on, in the exact shape
' Store's ItemSrcToken expects: its OWN src when the record carries one, and
' `invalid` — meaning "the active source" — when it does not. The doesExist
' test is the point: KwickTV's token IS the empty string, which a plain read
' cannot tell apart from a missing field, and getting that wrong would file
' the favourite under the wrong source.
function optTargetSrc() as dynamic
    if type(m.optTarget) <> "roAssociativeArray" then return invalid
    if not m.optTarget.doesExist("src") then return invalid
    return ToStr(m.optTarget.src)
end function

sub onChannelOptions()
    try
        onChannelOptionsInner()
    catch e
        GuardFailed("livetv/onChannelOptions", e)
    end try
end sub

sub onChannelOptionsInner()
    if liveScreenIsGone() then return
    dialog = m.top.getScene().dialog
    choice = dialog.buttonSelected
    dialog.close = true
    if choice = 0
        ch = m.optTarget
        m.addList = m.top.getScene().createChild("AddToListScreen")
        m.addList.item = { kind: "channel", id: ToStr(ch.streamId), name: ToStr(ch.name), icon: ToStr(ch.logo), ext: "", src: ToStr(GetField(ch, "src")) }
        m.addList.observeField("closed", "onAddListClosed")
        m.addList.setFocus(true)
        return
    else if choice = 1
        ToggleChannelHidden(ToStr(m.optTarget.streamId), ToStr(GetField(m.optTarget, "provId")))
        ' The ONE thing that can change a channel pref while this screen is
        ' alive. The prefs-applied copy of this folder is now wrong by exactly
        ' the channel that was just hidden, so it goes before the repaint —
        ' without this line the tile would stay on screen until the member
        ' left Live TV and came back.
        m.shownByCat.delete(ToStr(m.currentCatId))
        if m.channelsByCat.doesExist(m.currentCatId)
            fillGrid(m.channelsByCat[m.currentCatId])
        end if
    else if choice = 2
        openMultiView(m.optTarget)
        return
    else if choice = 3
        ' The SAME store helper and the SAME record shape the channel page
        ' writes (ChannelDetailScreen: streamId / name / logo / url, plus src
        ' only when the channel carries one). A favourite added from here has
        ' to be indistinguishable from one added there, or the Home row, the
        ' player's heart and the sync payload disagree with each other.
        ch = m.optTarget
        fav = { streamId: ToStr(ch.streamId), name: ToStr(ch.name), logo: ToStr(ch.logo), url: ToStr(ch.url) }
        tok = optTargetSrc()
        if tok <> invalid then fav.src = tok
        ToggleFavoriteChannel(fav)
        ' Nothing on the tile changes — ChannelCard carries no favourite mark
        ' on purpose (see its own note), so there is no grid to repaint and no
        ' scroll position to lose. The next time the menu is opened on this
        ' channel the label reads the other way round, which is the feedback.
    end if
    m.grid.setFocus(true)
end sub

' ---- Multi-View -------------------------------------------------------------
'
' One of the two entry points into Multi-View, and the "before I start, put
' these two up together" one: you are browsing, deciding what to watch, and
' the channel under the cursor is handed to the picker as the first pane so
' nobody has to find it twice.
'
' Nothing is playing here, so — unlike Android's player entry points — there is
' no stream to tear down first and this can simply open over the top.

sub openMultiView(ch as object)
    seed = MvLiveSlot(ch)
    m.mvPicker = m.top.getScene().createChild("MultiViewPicker")
    if seed <> invalid then m.mvPicker.seedJson = FormatJson(seed)
    m.mvPicker.observeField("closed", "onMvPickerClosed")
    m.mvPicker.setFocus(true)
    m.mvPicker.start = true
end sub

sub onMvPickerClosed()
    try
        onMvPickerClosedInner()
    catch e
        GuardFailed("livetv/onMvPickerClosed", e)
    end try
end sub

sub onMvPickerClosedInner()
    if liveScreenIsGone() then return
    res = ""
    if m.mvPicker <> invalid
        res = m.mvPicker.result
        m.top.getScene().removeChild(m.mvPicker)
        m.mvPicker = invalid
    end if
    if res = ""
        m.grid.setFocus(true)
        return
    end if
    ' Attached to the SCENE, like the player: the sidebar draws above the
    ' content layer, so a grid of panes inside this screen could never be
    ' fullscreen.
    m.mvScreen = m.top.getScene().createChild("MultiViewScreen")
    m.mvScreen.slotsJson = res
    m.mvScreen.observeField("closed", "onMultiViewClosed")
    m.mvScreen.setFocus(true)
    m.mvScreen.start = true
end sub

sub onMultiViewClosed()
    try
        onMultiViewClosedInner()
    catch e
        GuardFailed("livetv/onMultiViewClosed", e)
    end try
end sub

sub onMultiViewClosedInner()
    if liveScreenIsGone() then return
    if m.mvScreen <> invalid
        m.top.getScene().removeChild(m.mvScreen)
        m.mvScreen = invalid
    end if
    m.grid.setFocus(true)
end sub

sub onAddListClosed()
    try
        onAddListClosedInner()
    catch e
        GuardFailed("livetv/onAddListClosed", e)
    end try
end sub

sub onAddListClosedInner()
    if liveScreenIsGone() then return
    if m.addList <> invalid
        m.top.getScene().removeChild(m.addList)
        m.addList = invalid
    end if
    m.grid.setFocus(true)
end sub
