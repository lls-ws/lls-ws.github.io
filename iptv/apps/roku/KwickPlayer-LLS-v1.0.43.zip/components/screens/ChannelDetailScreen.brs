' Channel detail hub (Android channel_detail_screen port). Shows the logo,
' the channel name and its metadata chips, what's on now (live progress bar +
' synopsis), what's up next, a Watch Live / Watch Together / Favorite /
' Add-to-List action block, and the next 24 hours of guide data with day
' separators, a synopsis line and a NOW badge.
' OK on a guide row pops the programme's details (with Watch on the current
' one). A 30s ticker keeps the progress bar and now/next honest.
'
' FOCUS. The page has two panes and no SG focus of its own: focus lives on
' this Group and every key comes through onKeyEvent, exactly as before. m.pane
' says which one is listening — 0 the actions, 1 the listings (up/down/OK,
' plus the skip keys for a page at a time). LEFT and BACK come back from the
' listings.
'
' THE ACTIONS ARE A GRID NOW, not a column, because Android's are.
' Android puts ONE wide primary Watch button on its own line and wraps the
' secondary actions into rows beneath it (a Wrap with runSpacing). This page
' does the same, so the keys had to follow:
'
'   up / down     move between action rows, keeping the nearest column
'   left / right  move along an action row
'   right         at the END of a row, crosses into the listings — which is
'                 the press that used to cross from anywhere in the column,
'                 and is still the only way in
'
' A single-button row (the primary) therefore behaves exactly as the old
' column did: down goes to the secondaries, right goes to the listings.

sub init()
    m.theme = KwickTheme()
    m.top.findNode("bg").color = m.theme.background
    ' This page is an overlay on top of the still-present shell and paints its
    ' own full-screen backdrop, so AppScene's grid wash cannot show through.
    ' Draw it here instead, over this screen's own background and under
    ' everything else it draws. See AddPageGrid() in Theme.brs for why the
    ' backdrop above cannot simply be deleted. (`bg` is child 0 in the XML,
    ' which is the one assumption AddPageGrid makes, and nothing on this
    ' screen reaches a child by index — every lookup here is findNode.)
    AddPageGrid(m.top)

    ' The logo plate: Android's `colors.surface` container, rounded. It is a
    ' nine-patch and not a Rectangle because a Rectangle cannot be rounded on
    ' Roku at all — see the shapes note in the XML.
    m.top.findNode("logoCard").blendColor = m.theme.surface
    m.top.findNode("logoEdge").blendColor = m.theme.cardIdleBorder
    m.logo = m.top.findNode("logo")
    m.logoFallback = m.top.findNode("logoFallback")
    m.logoFallback.font = IconFont(84)
    m.logoFallback.color = m.theme.textSecondary
    m.logoFallback.text = m.theme.iconLiveTv
    ' Android's errorWidget: a logo the provider serves but the box cannot
    ' fetch or decode falls back to the same glyph as no logo at all, rather
    ' than leaving an empty plate. Two boolean writes on one observer — it
    ' asks nothing of the network, it only listens to a fetch already made.
    m.logo.observeField("loadStatus", "onLogoLoad")

    ' TYPE. JetBrains Mono is a flat 0.6em advance where Roboto-Medium
    ' averaged about 0.5em, so every string wants ~20% more room and every
    ' size on this page was cut for it once. The two-column layout gives most
    ' of that room back — the left column is 800px where the old boxes were
    ' 480-780 — so the sizes that were cut are put back where the new box
    ' holds at least as many characters as the old one did. Each one says
    ' what it now holds.

    m.name = m.top.findNode("name")
    ' 38 -> 44, back to where it started. 548px wrapped to two lines at 44 is
    ' ~20 characters a line, against ~21 at 38 in the old 480px box: the same
    ' line, in Android's headlineSmall proportion to everything around it.
    m.name.font = UiBoldFont(44)
    m.name.color = m.theme.textPrimary

    ' Metadata chips (Android's MetaChip row: group name, and the source when
    ' the member has more than one).
    m.chipRow = m.top.findNode("chipRow")
    m.chipFont = UiFont(22)
    m.chipIconFont = IconFont(22)

    m.nowCard = m.top.findNode("nowCard")
    m.nowCard.blendColor = m.theme.surfaceAccent
    m.nowEdge = m.top.findNode("nowEdge")
    m.nowEdge.blendColor = m.theme.cardIdleBorder

    m.nowTitle = m.top.findNode("nowTitle")
    ' Held at 26, deliberately. 744px on one line is ~47 characters, which is
    ' what the old 780px box held; going up to 30 would drop it to 41 and
    ' Android's now-title is a body-weight line, not a headline.
    m.nowTitle.font = UiBoldFont(26)
    m.nowTitle.color = m.theme.textPrimary

    m.progressTrack = m.top.findNode("progressTrack")
    ' Was 0x3A3D42FF, the old KwickTV Dark track grey. Nord's role for "a
    ' surface raised off the page" is surfaceElevated, and the filled part is
    ' the accent, so the pair still reads as track-and-fill. It sits on the
    ' on-now plate now, so the track is a step DOWN from that plate rather
    ' than up from the page — surfaceElevated is darker than surfaceAccent,
    ' which is what a groove wants.
    m.progressTrack.color = m.theme.surfaceElevated
    m.progressFill = m.top.findNode("progressFill")
    m.progressFill.color = m.theme.accent
    ' The two circles that cap each bar (see the note in the XML). A Poster
    ' takes blendColor where a Rectangle takes color, so the pair is written
    ' with two different property names for one colour — the caps and the bar
    ' they cap MUST come from the same theme entry or the bar gains a seam.
    m.trackCapL = m.top.findNode("trackCapL")
    m.trackCapR = m.top.findNode("trackCapR")
    m.trackCapL.blendColor = m.theme.surfaceElevated
    m.trackCapR.blendColor = m.theme.surfaceElevated
    m.fillCapL = m.top.findNode("fillCapL")
    m.fillCapR = m.top.findNode("fillCapR")
    m.fillCapL.blendColor = m.theme.accent
    m.fillCapR.blendColor = m.theme.accent

    m.timeLine = m.top.findNode("timeLine")
    ' 21 -> 22, back to where it started: the time range is 19 characters and
    ' the box under the bar is 744px, not the 260px sliver it used to have.
    ' LEFT aligned now, under the bar, which is where Android puts it.
    m.timeLine.font = UiFont(22)
    m.timeLine.color = m.theme.textSecondary
    m.timeLine.horizAlign = "left"

    m.desc = m.top.findNode("desc")
    ' 21 -> 22. Three wrapped lines in 744px is ~169 characters of synopsis,
    ' one more than the 780px box held at 21. Three lines at 22 with
    ' lineSpacing 8 need about 103px, which is why the box in the XML is 110
    ' and not the 100 the block would otherwise have wanted.
    m.desc.font = UiFont(22)
    m.desc.color = m.theme.textSecondary
    m.desc.lineSpacing = 8

    m.upNext = m.top.findNode("upNext")
    ' 20 -> 21. "Up next: <title> at 10:30 PM" on one 800px line: ~63
    ' characters against ~65 at 20 in the old 780px box.
    '
    ' ANDROID SETS THIS ITALIC AND ROKU CANNOT. The bundle carries JetBrains
    ' Mono Regular and Bold and no oblique face, and Roku has no synthetic
    ' slant — so the line is separated from the synopsis above it by colour
    ' and size only.
    m.upNext.font = UiFont(21)
    m.upNext.color = m.theme.textSecondary

    ' ---- The day's listings -------------------------------------------------
    m.guideRows = m.top.findNode("guideRows")

    ' 22, unchanged: the programme title in a row is a 534px box with
    ' maxLines 1, and 22 holds ~40 characters there — what the old 540px box
    ' held.
    m.rowFont = UiBoldFont(22)
    ' 20, unchanged: the time column is eight characters in 130px and fits
    ' either way, but a 22pt clock beside a 22pt title would be as loud as
    ' the programme name.
    m.rowTimeFont = UiFont(20)
    ' NEW — the synopsis line under each programme (Android's ListTile
    ' subtitle). 18 in a 534px box is ~49 characters.
    m.rowSubFont = UiFont(18)
    ' 21 -> 22 — a day separator is a short word ("Tomorrow", "Sat, Aug 30").
    m.sepFont = UiFont(22)
    ' Unchanged at 18 — "NOW", three characters, centred in 84px.
    m.badgeFont = UiBoldFont(18)

    m.guideHead = m.top.findNode("guideHead")
    ' 22 -> 26. It is a section heading over an 800px column (Android's
    ' titleMedium), not a row label.
    m.guideHead.font = UiBoldFont(26)
    m.guideHead.color = m.theme.textPrimary
    m.guideHead.text = "Guide"
    m.guideHead.visible = false

    m.guideHint = m.top.findNode("guideHint")
    m.guideHint.font = m.rowTimeFont
    m.guideHint.color = m.theme.textSecondary
    m.guideHint.horizAlign = "right"

    m.guideMore = m.top.findNode("guideMore")
    m.guideMore.font = m.rowTimeFont
    m.guideMore.color = m.theme.textSecondary

    m.entries = []        ' the render list: {kind:"day"|"pgm", ...}
    m.truncated = 0       ' programmes inside the window that the cap dropped
    m.cursor = -1         ' index into m.entries, always a "pgm"
    m.cursorKey = 0       ' its start time, so the 30s rebuild can find it again
    m.viewTop = 0         ' first entry drawn in the slot pool
    m.pane = 0            ' 0 = actions, 1 = listings
    m.rowPool = []
    m.lastRowLog = -1
    m.pgmWatch = false
    ' One detached Label, reused, for every text measurement this page makes
    ' (the secondary buttons and the chips are sized to their own words, the
    ' way Android's Wrap and MetaChip are). Never added to the tree.
    m.measure = CreateObject("roSGNode", "Label")
    buildRowPool()

    m.noGuide = m.top.findNode("noGuide")
    ' Unchanged at 25. Its longest line is the parental one, 49 characters,
    ' which is 735px of an 800px box.
    m.noGuide.font = UiFont(25)
    m.noGuide.color = m.theme.textSecondary
    m.noGuide.text = "No guide data for this channel"

    m.spinner = m.top.findNode("spinner")
    m.spinner.poster.uri = "pkg:/images/spinner.png"

    ' ---- Action button type and ink, from MovieDetailScreen ----------------
    ' 28 for the one primary action, 24 for the secondaries — Android's own
    ' split (a 15.5pt primary over 13.5pt secondaries in the terminal skin).
    ' At 24 the longest secondary, "Remove from Favorites", measures 302px of
    ' words inside a 406px button, and the widest possible pair on one row is
    ' 748px of the 800px column.
    '
    ' THE FILM PAGE USES 28 FOR BOTH and that is the ONE number of this
    ' treatment that is not copied. Its buttons have all 1920 to spread across
    ' and do not wrap; these live in an 800px column beside the listings. At
    ' 28 the three secondaries come to 1085px of button and would have to go
    ' one per row, four rows deep, which runs off the bottom of the screen.
    ' Everything else about how a button is DRAWN — plate, frame, shadow, lift,
    ' fill precedence, ink, icon size, padding, the gap — is Bram's, verbatim.
    m.btnFont = UiBoldFont(28)
    m.btnFontSmall = UiBoldFont(24)
    ' Android: 19dp on the primary, 17dp on a secondary. Doubled, and the same
    ' two sizes the film page uses.
    m.btnIconFontPri = IconFont(38)
    m.btnIconFont = IconFont(34)
    m.btnRows = []        ' [[button index, ...], ...] — the wrapped rows

    ' >>> THE FRAME COLOUR IS DERIVED, and this is the bug it exists to fix.
    ' Nord Shell sets the theme's border TO its accent, so an accent-filled
    ' button has a frame and a shadow at 1.00:1 against itself — a flat slab
    ' with a stub of the same colour behind it and no edge anywhere on it.
    ' Android (detailButtonEdge, detail_hero.dart) walks the fill toward its
    ' own ink until it clears 3:1, WCAG 1.4.11 non-text contrast.
    '
    ' Both answers are taken STRAIGHT OUT OF MovieDetailScreen.brs rather than
    ' re-derived here. There is one theme on this app and therefore one right
    ' pair of numbers, and two files each computing it is how two pages that
    ' are supposed to be identical start drifting. If Theme.brs ever gains
    ' these as tokens, both files should read them and both these lines go.
    '
    '   surfaceElevated fill -> the theme border (frost) already reads at
    '                           4.31:1 against the fill and 6.24:1 against the
    '                           page, so it is kept.
    '   a LIGHT fill         -> frost on frost is 1.00:1, so the page colour is
    '                           blended into the accent until it clears:
    '                           0x4E6572, 3.06:1 against the accent.
    '
    ' ONE EDGE COLOUR NOW SERVES BOTH LIGHT FILLS, which is why it is no
    ' longer called btnEdgeOnAccent. Since 2026-08-27 the focused fill is nord
    ' yellow and the primary's resting fill is still frost, and 0x4E6572
    ' measures 4.06:1 against the yellow and 3.06:1 against the frost — both
    ' clear 3:1, so the frame and the shadow do not have to change when the
    ' fill under them does. Keeping one colour is also what keeps the two
    ' states reading as the same button in two states rather than as two
    ' different controls.
    ' <<<
    m.btnEdgeOnLight = "0x4E6572FF"
    m.btnEdgeOnSurface = m.theme.surfaceBorder

    m.provider = ActiveProvider()
    m.player = invalid
    m.addList = invalid
    m.mvPicker = invalid     ' the Multi-View picker, while it is open
    m.mvScreen = invalid     ' the Multi-View grid, while it is open
    m.listings = []      ' [{title, desc, startS, stopS}] upcoming window, sorted
    m.buttons = []
    m.btnFocus = 0

    ' The channel's own row in the parsed playlist, found ONCE per channel by
    ' resolveChannelMeta and read by both the group chip and the parental
    ' gate. Empty on an Xtream source, which carries no group at all.
    m.chGroup = ""
    m.chMatched = false

    ' Parental gate (see the block at the bottom of this file).
    m.pgate = invalid    ' the snapshot, taken once when the channel arrives
    m.catName = ""       ' this channel's category, when it can be known
    m.catDone = false
    m.pendingPlay = invalid
    m.pinDialog = invalid

    ' Ticker: refresh the now-playing block every 30s (progress + rollover).
    m.ticker = CreateObject("roSGNode", "Timer")
    m.ticker.duration = 30
    m.ticker.repeat = true
    m.ticker.observeField("fire", "onTick")
    m.ticker.control = "start"

    m.top.observeField("focusedChild", "onFocusIn")
end sub

' Both ways, every time — a channel whose logo fails must not inherit the last
' one's picture, and one that succeeds must not keep the fallback glyph.
sub onLogoLoad()
    st = ToStr(m.logo.loadStatus)
    if st = "failed"
        m.logo.visible = false
        m.logoFallback.visible = true
    else if st = "ready"
        m.logo.visible = true
        m.logoFallback.visible = false
    end if
end sub

sub onFocusIn()
    try
        onFocusInInner()
    catch e
        GuardFailed("channel/onFocusIn", e)
    end try
end sub

sub onFocusInInner()
    ' Focus always lives on this Group. Which PANE is listening is m.pane —
    ' see the note at the top of the file — and no child ever takes SG focus,
    ' so coming back from the player, a dialog or Multi-View lands here and
    ' the pane the member left is still the one that answers.
end sub

sub onChannel()
    ch = m.top.channel
    if ch = invalid then return
    ' The channel's own source (merged screens set it) wins over the
    ' active one for the play URL, EPG calls, and favorite matching.
    m.itemSrc = invalid
    if type(ch) = "roAssociativeArray" and ch.doesExist("src") then m.itemSrc = ToStr(ch.src)
    if m.itemSrc <> invalid
        p = ProviderForSrcToken(m.itemSrc)
        if p <> invalid then m.provider = p
    end if
    ' BOTH WAYS, EVERY TIME. This page is created once per open today, but a
    ' channel arriving over the top of another one (the Guide hands one in
    ' without tearing the page down) must not leave the last channel's logo
    ' or its fallback glyph on screen.
    logoUri = ToStr(ch.logo)
    m.logo.uri = logoUri
    m.logo.visible = (logoUri <> "")
    m.logoFallback.visible = (logoUri = "")
    m.name.text = ToStr(ch.name)
    ' The parental snapshot: ONCE per screen open, never per button press.
    m.pgate = ParentalGate("live")
    m.pendingPlay = invalid
    ' A fresh channel means a fresh day of listings: drop the old ones before
    ' the new guide lands so nothing from the last channel is on screen (or
    ' under the cursor) while it loads.
    m.listings = []
    m.entries = []
    m.truncated = 0
    m.cursor = -1
    m.cursorKey = 0
    m.viewTop = 0
    m.pane = 0
    m.lastRowLog = -1
    resolveCatName()
    buildChips()
    buildButtons()
    loadEpg()
    ' After loadEpg, not before: it puts the spinner up on the paths that go
    ' to the network, and that is what stops "No guide data for this channel"
    ' flashing on screen for the second before the guide arrives.
    buildDayGuide()
end sub

' ---- Metadata chips ---------------------------------------------------------
'
' Android's MetaChip row under the channel name: the channel's group, and the
' source it came from when the member has more than one configured
' (channel_detail_screen.dart :314-327). Neither was on this page at all.
'
' NOTHING HERE ASKS THE NETWORK. The group name comes out of the parsed
' playlist that is already in m.global (see resolveChannelMeta), and the
' source name is a registry-backed lookup the app makes on every screen.
' An Xtream channel has no group to show — the reason is written out over
' resolveCatName — so it gets the source chip alone, or no chips at all.
'
' Shape is Android's: a rounded rectangle, NOT the stadium pill the VOD tabs
' wear. images/card_fill.9.png is the 8px corner (Android's is 6) and its
' caps are 10px tall, so a 44px chip cannot squash them the way the old
' fixed-height pill bitmap did.
sub buildChips()
    chips = m.chipRow
    while chips.getChildCount() > 0
        chips.removeChildIndex(0)
    end while

    defs = []
    ' The group is held back with the listings when the category is locked.
    ' Not because a category name is contraband on its own, but because this
    ' page's whole answer to a locked channel is to say nothing about it and
    ' point at the PIN.
    if m.chGroup <> "" and not listingsSuppressed()
        defs.push({ text: m.chGroup, icon: "" })
    end if
    if SourceCount() > 1
        tok = ""
        if m.itemSrc <> invalid then tok = m.itemSrc else tok = ActiveSrcToken()
        srcName = SourceLabelFor(tok)
        ' Material "dns", the icon Android puts on this chip. Verified
        ' present in fonts/MaterialIcons-Regular.ttf before it was used.
        if srcName <> "" then defs.push({ text: srcName, icon: Chr(&hE875) })
    end if

    ' The row runs from x=372 to the column edge at 920, so 548px, and the
    ' text in a chip is whatever the member's playlist called the group. Both
    ' are trimmed to a length that cannot overrun that: 18 characters plus
    ' the chip's own 32px of padding is 269px, and 14 plus an icon is 251px.
    x = 0
    for each cd in defs
        txt = ToStr(cd.text)
        cap = 18
        if cd.icon <> "" then cap = 14
        if Len(txt) > cap then txt = Left(txt, cap - 1) + "…"
        iconPad = 0
        if cd.icon <> "" then iconPad = 34
        w = cdTextWidth(txt, m.chipFont) + 32 + iconPad
        plate = chips.createChild("Poster")
        plate.uri = "pkg:/images/card_fill.9.png"
        plate.width = w
        plate.height = 44
        plate.translation = [x, 0]
        ' Android's chip is surfaceElevated at 85%; on Roku the page behind it
        ' is the flat background, so the alpha buys nothing and costs the
        ' 7.4:1 textPrimary sits at. Opaque.
        plate.blendColor = m.theme.surfaceElevated
        if cd.icon <> ""
            ic = chips.createChild("Label")
            ic.font = m.chipIconFont
            ic.text = cd.icon
            ic.color = m.theme.accent
            ic.width = 26
            ic.height = 44
            ic.horizAlign = "center"
            ic.vertAlign = "center"
            ic.translation = [x + 14, 0]
        end if
        lbl = chips.createChild("Label")
        lbl.font = m.chipFont
        lbl.color = m.theme.textPrimary
        lbl.text = txt
        lbl.height = 44
        lbl.vertAlign = "center"
        lbl.translation = [x + 16 + iconPad, 0]
        x = x + w + 12
    end for
end sub

' ---- Actions (Watch Live / Watch Together / Favorite / Add to List) ----------
'
' ANDROID'S HIERARCHY, NOT A COLUMN OF FOUR EQUALS. Android draws one wide
' primary Watch button and wraps the rest into rows of smaller buttons sized
' to their own labels (channel_detail_screen.dart :399-484). This page used to
' draw four identical 440x72 slabs stacked vertically, which said all four
' actions were the same size of decision.
'
' WHY THEY WRAP RATHER THAN SHRINK. JetBrains Mono is a flat 0.6em, so
' "Remove from Favorites" is 302px of words at 24pt and the three secondaries
' come to 894px of button — 94px more than the column. Android's Wrap already
' answers that (runSpacing 10), so the row wraps here too rather than the type
' coming down again.
'
' THE ART IS THE FILM PAGE'S, NOT THE MEDIA BAR'S (2026-08-27).
'
' These buttons used to wear btn_fill / btn_edge / btn_focus at a 12px corner —
' a rounded plate with a proud focus RING and a yellow focus fill, the Media
' Bar's language. That was a defensible reading on its own and it is wrong in
' the app: the owner opened this page straight after a film's page and read the
' difference as this page never having been rebuilt at all. "the buttons look
' different then the VOD so i got confused. id liek the buttons to match."
'
' So a button here is now drawn EXACTLY as makeActionButton/redrawButtons draw
' one in MovieDetailScreen.brs, which is Android's terminal DetailActionButton
' (_buildTerminalButton, detail_hero.dart):
'
'   plate     images/card_fill.9.png, 8px corner
'   frame     images/card_edge.9.png, 3px stroke, colour DERIVED from the fill
'   shadow    the SAME plate again, tinted the frame colour, offset +6,+6 and
'             NEVER MOVED. Android grows its offset 3dp -> 5dp on focus while
'             translating the button -2,-2; doubled that is a shadow that sits
'             still while the button lifts -4,-4 off it, so the gap goes 6 ->
'             10 and the effect reads as depth rather than as sliding.
'   fill      focus, then primary, then quiet — Android's precedence exactly.
'             Focus takes nord yellow; the primary at rest takes the accent.
'   ink       the page colour on either light fill (8.29:1 on the yellow,
'             6.24:1 on the accent); textPrimary on surfaceElevated (7.49:1).
'
' THE YELLOW IS BACK, AND IT WAS THE RIGHT CALL (2026-08-27). The first pass
' at this page copied the film page exactly, which meant focus and the primary
' BOTH took the accent and only the lift and the widened shadow separated
' them. The hand-off flagged that as the one thing to check from the sofa, and
' it did not carry: "when play, resume or watch now is hovered you cant really
' tell, we should use the orange for hover/highlight". So the focused fill is
' focusHighlight — nord yellow, nord13, what every other focus cue in this app
' already uses — and the same change went onto the film and series pages in
' the same pass, so the three still match. The lift and the shadow stay; they
' are now the second cue rather than the only one.
'
' The ink follows the fill and is written on every arm. Nord yellow is a LIGHT
' colour, so a focused label is `background` (the page colour) at 8.29:1, not
' textPrimary — white on that yellow is about 1.9:1 and unreadable across a
' room. The frame and the shadow do not change with the fill: one derived
' colour clears 3:1 against both (see m.btnEdgeOnLight in init).
'
' COST: nothing. card_fill.9.png and card_edge.9.png are 42 x 42 x 4 = 7,056
' bytes each, decoded ONCE for the whole app however many nodes point at them,
' and both are already resident for the logo plate, the on-now card, the chips
' and every listing row on this same screen. The shadow is a third Poster
' pointing at a file already in memory.

' The primary is 84 tall, a secondary 72 — Android's 42/36 doubled, the film
' page's own pair.
function BTNPRIH() as integer
    return 84
end function

function BTNSECH() as integer
    return 72
end function

function BTNCOLW() as integer
    return 800
end function

sub buildButtons()
    col = m.top.findNode("buttonCol")
    while col.getChildCount() > 0
        col.removeChildIndex(0)
    end while
    m.buttons = []
    m.btnRows = []

    ch = m.top.channel
    isFav = IsFavoriteChannel(ToStr(ch.streamId), m.itemSrc)
    favLabel = "Add to Favorites"
    ' Material "star_border" / "star", Android's own pair for this button.
    favIcon = Chr(&hE83A)
    if isFav
        favLabel = "Remove from Favorites"
        favIcon = Chr(&hE838)
    end if
    listLabel = "Add to List"
    ' Material "playlist_add" / "playlist_add_check", Android's pair.
    listIcon = Chr(&hE03B)
    if IsInAnyList("channel", ToStr(ch.streamId), m.itemSrc)
        listLabel = "In Lists"
        listIcon = Chr(&hE065)
    end if

    ' `widest` is what the button is SIZED to; `text` is what it says today.
    ' Two of these change their words when they are pressed, and sizing to the
    ' current text has a fault the film page already found and fixed: the row
    ' re-wraps under the member's hand the moment Favorites is pressed, because
    ' "Remove from Favorites" is five characters longer than "Add to Favorites".
    ' Sizing to the longer state costs a few pixels of air and makes the block
    ' completely static. (MovieDetailScreen calls this secLabelWidest(); it is a
    ' field here because these specs are built in one place.)
    specs = [
        { key: "watch", text: "Watch Live", widest: "Watch Live", icon: m.theme.iconPlay, primary: true, fav: false },
        ' The second way into Multi-View, and the one Android calls "before I
        ' start, put these two up together" — you are already deciding what to
        ' watch, so this channel is handed to the picker as the first pane.
        ' Material "grid_view", which is what Android puts on it.
        { key: "multiview", text: "Watch Together", widest: "Watch Together", icon: Chr(&hE9B0), primary: false, fav: false },
        { key: "favorite", text: favLabel, widest: "Remove from Favorites", icon: favIcon, primary: false, fav: isFav },
        { key: "addlist", text: listLabel, widest: "Add to List", icon: listIcon, primary: false, fav: false }
    ]

    ' ---- Android's terminal button geometry, doubled, the film page's own ---
    ' primaryButtonHeight 42 -> 84, secondaryButtonHeight 36 -> 72,
    ' actionSpacing 18 -> 36, actionRunSpacing 8 -> 16, gapAfterPrimary 14 ->
    ' 28, horizontal padding 16/12 -> 32/24, the icon slot 44 with 8dp/6dp ->
    ' 16/12 after it, the hard offset shadow 3/5 -> 6/10, the focus lift -2 ->
    ' -4. The film page does not wrap and so has no runSpacing; this one does,
    ' which is Android's own Wrap on this page.
    gap = 36
    runGap = 16
    afterPri = 28
    iconW = 44
    iconGapPri = 16
    iconGapSec = 12

    ' Lay the rows out first, then build the nodes: a button has to know its
    ' own width before it can be placed, and the row it lands on is not known
    ' until the one before it has been measured.
    x = 0
    y = 0
    rowIdx = -1
    for each spec in specs
        if spec.primary
            f = m.btnFont
            iconFont = m.btnIconFontPri
            iconGap = iconGapPri
            w = BTNCOLW()
            h = BTNPRIH()
        else
            f = m.btnFontSmall
            iconFont = m.btnIconFont
            iconGap = iconGapSec
            ' 24px of padding each side, a 44px icon slot, 12px after it.
            w = cdTextWidth(spec.widest, f) + 48 + iconW + iconGapSec
            if w > BTNCOLW() then w = BTNCOLW()
            h = BTNSECH()
        end if
        if spec.primary or rowIdx < 0 or x + w > BTNCOLW()
            rowIdx = rowIdx + 1
            m.btnRows.push([])
            x = 0
            ' Row 0 is always the primary, alone. Row 1 clears it by
            ' gapAfterPrimary; every row after that is a secondary row under a
            ' secondary row and clears by runSpacing.
            if rowIdx = 1
                y = BTNPRIH() + afterPri
            else if rowIdx > 1
                y = y + BTNSECH() + runGap
            end if
        end if
        idx = m.buttons.count()
        m.btnRows[rowIdx].push(idx)
        m.buttons.push(makeButton(col, spec, x, y, w, h, f, iconFont, iconW, iconGap, rowIdx, m.btnRows[rowIdx].count() - 1))
        x = x + w + gap
    end for

    if m.btnFocus >= m.buttons.count() then m.btnFocus = 0
    redrawButtons()
end sub

' One button: the hard offset shadow, the rounded plate, the frame, the icon
' and the label. Five nodes, and every one of them is written BOTH WAYS on
' every redraw — see redrawButtons(). The icon and the label are placed as one
' centred pair, which is what makes an action read as an action from ten feet
' without relying on colour alone.
'
' THE SHADOW NEVER MOVES. Its translation is fixed here, at build time, and is
' never written again; only the four nodes sitting ON it move when focus
' arrives. That is what makes the effect read as depth instead of as sliding,
' and it is four translation writes per redraw rather than five.
function makeButton(col as object, spec as object, x as integer, y as integer, w as integer, h as integer, f as object, iconFont as object, iconW as integer, iconGap as integer, bRow as integer, bCol as integer) as object
    ' Created FIRST so everything else paints over it.
    shadow = col.createChild("Poster")
    shadow.uri = "pkg:/images/card_fill.9.png"
    shadow.width = w
    shadow.height = h
    shadow.translation = [x + 6, y + 6]

    fill = col.createChild("Poster")
    fill.uri = "pkg:/images/card_fill.9.png"
    fill.width = w
    fill.height = h
    fill.translation = [x, y]

    edge = col.createChild("Poster")
    edge.uri = "pkg:/images/card_edge.9.png"
    edge.width = w
    edge.height = h
    edge.translation = [x, y]

    ' No width on either label, deliberately: redrawButtons measures the label
    ' with boundingRect() to centre the icon-and-words pair, and a Label given
    ' an explicit width reports that width back rather than its text's.
    icon = col.createChild("Label")
    icon.font = iconFont
    icon.text = ToStr(spec.icon)
    icon.width = iconW
    icon.height = h
    icon.horizAlign = "center"
    icon.vertAlign = "center"

    lbl = col.createChild("Label")
    lbl.font = f
    lbl.text = ToStr(spec.text)
    lbl.height = h
    lbl.vertAlign = "center"

    return { key: spec.key, primary: spec.primary, fav: spec.fav, bRow: bRow, bCol: bCol, shadow: shadow, fill: fill, edge: edge, icon: icon, label: lbl, x: x, y: y, w: w, h: h, iconW: iconW, iconGap: iconGap }
end function

' EVERY VISUAL SET BOTH WAYS, EVERY TIME — the fill, the frame, the shadow,
' the ink and the four translations, on every arm. A button whose "focused" arm
' was the only one that ran would keep the yellow after the highlight moved on,
' and on this page the highlight is the only thing telling the member which of
' four actions OK is about to press. Losing focus has to put back BOTH the
' resting fill and the resting ink, which is why the three arms below each
' write all four values rather than patching the one that differs.
'
' THE INK RULE. Both light fills take the page colour as ink. focusHighlight
' is nord yellow (0xEBCB8B) and the page is nord0 (0x2E3440): measured, that is
' 8.29:1, where textPrimary on the same yellow is about 1.9:1 and cannot be
' read across a room at all. The accent is FROST and the same rule gives
' 6.24:1. On the dark surfaceElevated fill it is the other way round and
' textPrimary sits at 7.49:1.
'
' THE FAVOURITE STATE IS CARRIED BY THE ICON ONLY, and this is the one place
' this page deliberately does not copy the film page. Android colours the whole
' label nord purple when a title is favourited; measured, that purple on
' surfaceElevated is 3.04:1, which scrapes the large-text bar and fails the
' 4.5:1 one. So the words stay textPrimary and the STAR carries the state — a
' solid star against a hollow one, which is 3:1 non-text and the same trick the
' Media Bar's heart uses. On either light fill (focused, or the primary) the
' purple would be under 2:1, so there the glyph alone carries it too.
'
' Focus is only shown while the ACTIONS are the pane that is listening. With
' the member over in the listings every button paints at rest, or the page
' would show two cursors.
sub redrawButtons()
    for i = 0 to m.buttons.count() - 1
        b = m.buttons[i]
        focused = (i = m.btnFocus and m.pane = 0)

        ' ---- the fill, and the frame and shadow derived from it -------------
        ' Precedence is still Android's — focus first, then primary, then
        ' quiet — but focus and primary no longer share a fill. See the block
        ' above redrawButtons for why they used to and why they don't now.
        ' THREE ARMS, and each one writes all four — fill, frame, shadow, ink.
        ' Not "set the odd one out and let the rest fall through": these
        ' buttons are rebuilt and rebound as the channel changes, and a value
        ' written on only one arm is how the last channel's state smears onto
        ' the next one.
        onLight = (focused or b.primary)
        if focused
            b.fill.blendColor = m.theme.focusHighlight
            b.edge.blendColor = m.btnEdgeOnLight
            b.shadow.blendColor = m.btnEdgeOnLight
            ink = m.theme.background
        else if b.primary
            b.fill.blendColor = m.theme.accent
            b.edge.blendColor = m.btnEdgeOnLight
            b.shadow.blendColor = m.btnEdgeOnLight
            ink = m.theme.background
        else
            b.fill.blendColor = m.theme.surfaceElevated
            b.edge.blendColor = m.btnEdgeOnSurface
            b.shadow.blendColor = m.btnEdgeOnSurface
            ink = m.theme.textPrimary
        end if
        b.label.color = ink
        if b.fav and not onLight
            b.icon.color = m.theme.favorite
        else
            b.icon.color = ink
        end if

        ' ---- the lift, and the shadow it lifts off --------------------------
        ' The shadow's own translation was fixed in makeButton and is never
        ' touched again; only the four nodes ON it move, so the gap between
        ' button and shadow goes from 6 to 10.
        if focused
            dx = b.x - 4
            dy = b.y - 4
        else
            dx = b.x
            dy = b.y
        end if
        b.fill.translation = [dx, dy]
        b.edge.translation = [dx, dy]
        ' The icon and the words sit as one block, centred together inside the
        ' button — Android centres its Row the same way. Measured HERE and not
        ' at build time because two of these labels change width when their
        ' state changes, and a block centred on the old text sits off to one
        ' side.
        tw = Int(b.label.boundingRect().width) + b.iconW + b.iconGap
        tx = dx + Int((b.w - tw) / 2)
        if tx < dx + 12 then tx = dx + 12
        b.icon.translation = [tx, dy]
        b.label.translation = [tx + b.iconW + b.iconGap, dy]
    end for
end sub

' Move the action cursor. dx walks along a row, dy between rows keeping the
' nearest column (a two-button row above a one-button row must not strand the
' cursor). Returns false when there is nowhere to go, which is how RIGHT knows
' it has run off the end of a row and should cross into the listings.
function moveButtons(dx as integer, dy as integer) as boolean
    if m.buttons.count() = 0 then return false
    b = m.buttons[m.btnFocus]
    r = b.bRow
    c = b.bCol
    if dy <> 0
        r = r + dy
        if r < 0 or r >= m.btnRows.count() then return false
        if c > m.btnRows[r].count() - 1 then c = m.btnRows[r].count() - 1
    else
        c = c + dx
        if c < 0 or c > m.btnRows[r].count() - 1 then return false
    end if
    m.btnFocus = m.btnRows[r][c]
    redrawButtons()
    return true
end function

' How wide `text` is in `font`, in pixels. One detached node, reused. Named
' cdTextWidth rather than textWidth because two other components already carry
' a helper of that name and a reader should not have to work out which one a
' component's namespace handed it.
function cdTextWidth(text as string, font as object) as integer
    m.measure.font = font
    m.measure.text = text
    return Int(m.measure.boundingRect().width)
end function

' (cdWithAlpha lived here. It existed for exactly one caller — the old focus
' ring, which took focusHighlight at alpha 120 — and went with it when the
' buttons were rebuilt to match the film page. Every other colour on this page
' comes out of Theme.brs with the alpha it is meant to have.)

' ---- EPG --------------------------------------------------------------------

sub loadEpg()
    ch = m.top.channel
    if m.provider = invalid or ToStr(ch.streamId) = ""
        buildDayGuide()
        return
    end if
    if m.provider.ptype = "m3u"
        loadXmltvEpg()
        return
    end if
    m.spinner.visible = true
    m.spinner.control = "start"
    task = CreateObject("roSGNode", "ApiTask")
    ' ONE call, for the whole day. limit is a count of PROGRAMMES, not hours,
    ' so 30 (what the guide grid asks for, and what this page used to ask for)
    ' is about 15 hours on a channel of half-hour shows and less on a busy
    ' one — short of the 24 hours Android draws. 60 covers the day with room
    ' to spare and is still a single request of roughly one screen of JSON.
    ' Anything the panel sends past the 24h horizon is dropped when the rows
    ' are built, so a generous panel costs nothing on screen.
    task.url = XtreamApiUrl(m.provider, "get_short_epg") + "&stream_id=" + UrlEncode(ToStr(ch.streamId)) + "&limit=60"
    task.observeField("result", "onEpg")
    m.task = task
    task.control = "RUN"
end sub

' ---- M3U guide (XMLTV cache, T5) --------------------------------------------
' The playlist + guide load once per session (LiveTvScreen or here). This
' page resolves its channel's tvg-id by stream url and reads the cache.

sub loadXmltvEpg()
    if m.global.m3uChannels.count() = 0
        ' Straight from Home before Live TV ever loaded — parse the playlist.
        ' That playlist is also what carries this channel's group name, so the
        ' parental gate has to wait for it too (onDetailM3u calls back in).
        m.catDone = false
        m.spinner.visible = true
        m.spinner.control = "start"
        task = CreateObject("roSGNode", "M3uTask")
        task.url = m.provider.m3uUrl
        task.observeField("result", "onDetailM3u")
        m.m3uTask = task
        task.control = "RUN"
        return
    end if
    xmltvReady()
end sub

sub onDetailM3u(event as object)
    try
        onDetailM3uInner(event)
    catch e
        GuardFailed("channel/onDetailM3u", e)
    end try
end sub

sub onDetailM3uInner(event as object)
    res = event.getData()
    m.spinner.visible = false
    m.spinner.control = "stop"
    if res = invalid or res.ok <> true
        ' No playlist, so no group name — that is as much as will ever be
        ' known, and a held press must not be held forever.
        resolveCatName()
        buildChips()
        buildDayGuide()
        flushPendingPlay()
        return
    end if
    ' Publish through the per-source slots — a straight global write would
    ' wipe the other M3U sources' channels out of the merged list.
    PublishM3uParse(ToStr(m.provider.id), ToArray(res.channels), ToStr(GetField(res, "tvgUrl")))
    ' The group name is knowable now the playlist is in the globals.
    resolveCatName()
    buildChips()
    xmltvReady()
    flushPendingPlay()
end sub

' Did the app give the guide back to Roku to stay alive?
'
' AppScene.shedOnMemWarning drops the parsed guide on a real Roku memory alarm
' -- member key D62C10 was killed on v1.0.39 after twenty-three of them -- and
' deliberately leaves m.global.xmltvState reading "ready", because this page,
' Live TV and the TV Guide all watch that field and would otherwise all start
' downloading at once on a box that has just said it has no room. This flag is
' how this page finds out instead.
'
' Tested on the flag and not on an empty map: a guide can parse perfectly and
' still name none of the member's channels, which leaves an empty map reading
' "ready" as well, and re-reading on that would cost a download every time a
' channel page was opened.
function detailGuideWasShed() as boolean
    if m.global = invalid or not m.global.hasField("xmltvShed") then return false
    if m.global.xmltvShed <> true then return false
    return LCase(ToStr(m.global.xmltvState)) <> "loading"
end function

sub xmltvReady()
    ' Answered before anything else, so the block under it is the ordinary
    ' cold-start path and a channel page opened after a shed behaves exactly
    ' like one opened at launch. Note this page only ever re-reads the
    ' playlist's own url-tvg, never the member's custom guide list -- same as
    ' it has always done on a cold start. The fuller chain is read the next
    ' time Live TV or the TV Guide is opened.
    if detailGuideWasShed()
        KLog("livetv", "the guide was let go of to keep the app alive - reading it again")
        m.global.xmltvShed = false
        m.global.xmltvState = ""
    end if
    ' Kick the guide download if nobody has yet.
    if m.global.xmltvState = "" and m.global.m3uTvgUrl <> ""
        m.global.xmltvState = "loading"
        wanted = []
        seen = {}
        for each c in m.global.m3uChannels
            tid = ToStr(GetField(c, "tvgId"))
            if tid <> "" and not seen.doesExist(tid)
                seen[tid] = true
                wanted.push(tid)
            end if
        end for
        task = CreateObject("roSGNode", "XmltvTask")
        task.url = m.global.m3uTvgUrl
        task.wantedJson = FormatJson(wanted)
        task.observeField("result", "onDetailXmltv")
        m.xmltvTask = task
        task.control = "RUN"
        m.spinner.visible = true
        m.spinner.control = "start"
        return
    end if
    if m.global.xmltvState = "loading"
        ' Someone else is downloading it — listen for the flip.
        m.global.observeField("xmltvState", "onXmltvState")
        m.spinner.visible = true
        m.spinner.control = "start"
        return
    end if
    applyXmltv()
end sub

sub onDetailXmltv(event as object)
    try
        onDetailXmltvInner(event)
    catch e
        GuardFailed("channel/onDetailXmltv", e)
    end try
end sub

sub onDetailXmltvInner(event as object)
    res = event.getData()
    m.spinner.visible = false
    m.spinner.control = "stop"
    if res <> invalid and res.ok = true
        m.global.xmltvById = res.byId
        m.global.xmltvState = "ready"
    else
        m.global.xmltvState = "failed"
    end if
    applyXmltv()
end sub

sub onXmltvState()
    try
        onXmltvStateInner()
    catch e
        GuardFailed("channel/onXmltvState", e)
    end try
end sub

sub onXmltvStateInner()
    if m.global.xmltvState = "loading" then return
    m.global.unobserveField("xmltvState")
    m.spinner.visible = false
    m.spinner.control = "stop"
    applyXmltv()
end sub

sub applyXmltv()
    m.listings = []
    if m.global.xmltvState = "ready"
        ' Find this channel in the playlist by url (stable across loads).
        ch = m.top.channel
        tid = ""
        for each c in m.global.m3uChannels
            if ToStr(c.url) = ToStr(ch.url) or (ToStr(ch.url) = "" and ToStr(c.streamId) = ToStr(ch.streamId))
                tid = ToStr(GetField(c, "tvgId"))
                exit for
            end if
        end for
        if tid <> "" and m.global.xmltvById.doesExist(tid)
            m.listings = m.global.xmltvById[tid]
        end if
    end if
    normalizeListings()
    refreshNowBlock()
    buildDayGuide()
end sub

' Put the listings in time order and drop anything undated.
'
' Four rows could be picked out of an unsorted list without anyone noticing.
' A DAY of rows cannot: the day separators are decided by walking the list in
' order, so one programme out of place would print "Tomorrow" in the middle
' of this afternoon. The XMLTV cache is in FILE order, which is usually but
' not always chronological, and it is shared with the guide grid — so this
' sorts a COPY of the array (the same programme objects, just a fresh list of
' pointers) rather than reordering m.global.xmltvById under the other screens.
sub normalizeListings()
    out = []
    for each p in m.listings
        if p <> invalid and ToInt(GetField(p, "startS")) > 0 then out.push(p)
    end for
    out.sortBy("startS")
    m.listings = out
end sub

sub onEpg(event as object)
    try
        onEpgInner(event)
    catch e
        GuardFailed("channel/onEpg", e)
    end try
end sub

sub onEpgInner(event as object)
    res = event.getData()
    m.spinner.visible = false
    m.spinner.control = "stop"
    m.listings = []
    if res <> invalid and res.ok = true
        for each e in ToArray(GetField(res.data, "epg_listings"))
            m.listings.push({
                title: B64Decode(ToStr(GetField(e, "title")))
                desc: B64Decode(ToStr(GetField(e, "description")))
                startS: ToInt(GetField(e, "start_timestamp"))
                stopS: ToInt(GetField(e, "stop_timestamp"))
            })
        end for
    end if
    normalizeListings()
    refreshNowBlock()
    buildDayGuide()
end sub

' 30s ticker: keep the progress bar honest and roll the guide over when the
' current show ends. The rebuild is an array walk over at most a day of
' listings and a re-fill of the row slots — no nodes are created or thrown
' away — and buildDayGuide keeps the cursor on whatever the member had
' selected, so a scroll in progress is not yanked out from under them.
sub onTick()
    try
        onTickInner()
    catch e
        GuardFailed("channel/onTick", e)
    end try
end sub

sub onTickInner()
    refreshNowBlock()
    buildDayGuide()
end sub

' The "on now" block: title, progress, times, synopsis, and up-next line.
sub refreshNowBlock()
    now = CreateObject("roDateTime").asSeconds()
    nowPlaying = invalid
    upNext = invalid
    ' A locked channel gets no synopsis either. This block is a listing like
    ' any other — the title of what is on right now and two lines about it is
    ' precisely what the lock is there to keep off the screen — so when the
    ' listings are held back it goes blank with them.
    listings = m.listings
    if listingsSuppressed() then listings = []
    for each p in listings
        if p.startS <= now and p.stopS > now
            nowPlaying = p
        else if p.startS > now
            if upNext = invalid then upNext = p
        end if
    end for

    ' THE PROGRESS BAR IS ROUNDED AT BOTH ENDS, 10px tall, 744px long — see
    ' the note in the XML for why it is a Rectangle between two circles and not
    ' a nine-patch. Track and fill are each three nodes, and all six are
    ' written on BOTH arms below.
    if nowPlaying <> invalid
        m.nowCard.visible = true
        m.nowEdge.visible = true
        m.nowTitle.text = nowPlaying.title
        total = nowPlaying.stopS - nowPlaying.startS
        frac = 0.0
        if total > 0 then frac = (now - nowPlaying.startS) / total
        if frac < 0 then frac = 0
        if frac > 1 then frac = 1
        m.progressTrack.visible = true
        m.trackCapL.visible = true
        m.trackCapR.visible = true
        ' How much of the 744 is filled, INCLUDING both caps. A bar shorter
        ' than its own two caps cannot be drawn, so anything under 10px is
        ' pulled up to 10 — the two circles then land on each other and the
        ' bar reads as a dot, which is what a programme 40 seconds into an
        ' hour should look like. Exactly 0 is the only value that draws
        ' nothing, and it cannot happen for something that is already on air.
        fw = Int(744 * frac)
        if fw > 744 then fw = 744
        if fw < 10 and frac > 0 then fw = 10
        m.fillCapL.visible = (fw >= 10)
        m.progressFill.visible = (fw >= 10)
        m.fillCapR.visible = (fw >= 10)
        m.progressFill.width = fw - 10
        if m.progressFill.width < 0 then m.progressFill.width = 0
        ' 148 is the bar's left edge and 441 its top, both fixed in the XML.
        m.fillCapR.translation = [148 + fw - 10, 441]
        m.timeLine.text = fmtTime(nowPlaying.startS) + " - " + fmtTime(nowPlaying.stopS)
        m.desc.text = nowPlaying.desc
    else
        ' The plate goes with the block it is a plate for — an empty card
        ' sitting in the middle of the page reads as something that failed to
        ' load rather than as a channel with no guide.
        m.nowCard.visible = false
        m.nowEdge.visible = false
        m.nowTitle.text = ""
        m.progressTrack.visible = false
        m.trackCapL.visible = false
        m.trackCapR.visible = false
        m.progressFill.visible = false
        m.fillCapL.visible = false
        m.fillCapR.visible = false
        m.timeLine.text = ""
        m.desc.text = ""
    end if

    if upNext <> invalid
        m.upNext.text = "Up next: " + upNext.title + " at " + fmtTime(upNext.startS)
    else
        m.upNext.text = ""
    end if
end sub

' ---- The day's listings ------------------------------------------------------
'
' Android draws every programme from now to now+24h, in a scrolling list, with
' a small accent heading each time the local day rolls over ("Today",
' "Tomorrow", "Wed, Aug 26") and a red NOW badge on the one that is on air
' (channel_detail_screen.dart, _guideRows at :520 and the badge at :576). The
' first group gets no heading — Android only prints one when the day CHANGES,
' so a page that starts today does not open with the word "Today". This is
' that list, with Android's recording affordances left out: Roku apps cannot
' save video (K1), so OK on a row shows the programme instead of booking it.
'
' MEMORY — the whole reason this is built the way it is.
'
' Four rows were eight labels. A day is 30-50 programmes, and drawing them the
' old way (create a node per row, throw them all away and do it again on every
' 30-second tick and every press of Down) would be a few hundred nodes
' churning on a box that has already killed this app five times for going over
' its allowance, and that caps the guide grid at 150 channels for the same
' reason.
'
' So the nodes are a FIXED POOL. buildRowPool() creates GUIDEVISROWS() row
' slots ONCE, at init, and they are then filled and re-filled with text as the
' list scrolls. A day of listings and four rows cost exactly the same nodes,
' and so would a week. The only thing that grows with the length of the day is
' m.entries, and that is a small array of pointers to programme objects that
' already exist in m.listings — no copies, no new strings.
'
' The programme rows are capped at MAXDETAILROWS() anyway, deliberately, and
' the overflow is counted and shown rather than silently dropped.

' How tall one row is, and how many of them fit between the header (y=186 in
' the XML) and the "+N more" footer.
'
' 58 -> 76, AND 13 ROWS -> 10. A row carries Android's synopsis line under the
' programme title now (ListTile subtitle, channel_detail_screen.dart :569), so
' it is two lines of text on a plate rather than one line of text on the page.
' Ten rows of what a programme actually is beats thirteen bare titles, and the
' NODE cost went DOWN — the pool is 10 slots of 8 nodes where it was 13 of 6.
function GUIDEROWH() as integer
    return 76
end function

function GUIDEVISROWS() as integer
    return 10
end function

' How far ahead the list goes. Android's window exactly.
function GUIDEHORIZONSECS() as integer
    return 24 * 3600
end function

' The most programme rows this page will ever put in the list.
'
' 60 is a day of half-hour shows with a dozen to spare, which covers every
' normal channel; the ones that go past it are the news and music channels
' whose guide is a five-minute loop, and cutting those off after 60 rows
' costs the member nothing they were going to scroll to. It is a ceiling on
' the ARRAY, not on the nodes — the nodes are fixed by the pool either way —
' so its job is to stop a pathological guide (some XMLTV feeds carry hundreds
' of tiny entries per channel per day) from turning into a list nobody can
' reach the end of. Whatever it drops is counted into m.truncated and printed
' under the list, the same way the XMLTV parser reports its own cap.
function MAXDETAILROWS() as integer
    return 60
end function

' The row slots, made once. Eight nodes each, 10 slots: 80 nodes for the whole
' feature, whatever the guide turns out to hold.
'
' EVERY SHAPE IN A SLOT IS A NINE-PATCH. A row is a card now — 8px corner,
' frost frame at rest, focus colour on the frame and a halo behind it when the
' cursor is on it — which is the same treatment the Guide grid's programme
' blocks got and the same pair of files. Two 42x42 nine-patches decoded ONCE
' for the whole screen however many rows point at them: 14,112 bytes of
' texture against a ~90MB budget, and no new file in the 4MB zip.
sub buildRowPool()
    m.rowPool = []
    for i = 0 to GUIDEVISROWS() - 1
        g = m.guideRows.createChild("Group")
        g.translation = [0, i * GUIDEROWH()]
        g.visible = false

        ' The halo, drawn first so the plate paints over its middle. 3px
        ' proud rather than 4: the row pitch is 76 and the plate 68, so 4
        ' would leave neighbouring haloes touching.
        halo = g.createChild("Poster")
        halo.uri = "pkg:/images/card_fill.9.png"
        halo.width = 806
        halo.height = 74
        halo.translation = [-3, -3]
        halo.blendColor = m.theme.focusHighlight
        halo.visible = false

        plate = g.createChild("Poster")
        plate.uri = "pkg:/images/card_fill.9.png"
        plate.width = 800
        plate.height = 68
        plate.translation = [0, 0]
        plate.blendColor = m.theme.surface
        plate.visible = false

        edge = g.createChild("Poster")
        edge.uri = "pkg:/images/card_edge.9.png"
        edge.width = 800
        edge.height = 68
        edge.translation = [0, 0]
        edge.blendColor = m.theme.cardIdleBorder
        edge.visible = false

        tm = g.createChild("Label")
        tm.width = 130
        tm.height = 68
        tm.translation = [14, 0]
        tm.vertAlign = "center"
        tm.font = m.rowTimeFont
        tm.color = m.theme.textSecondary

        ti = g.createChild("Label")
        ti.width = 534
        ti.height = 30
        ti.translation = [156, 8]
        ti.maxLines = 1
        ti.vertAlign = "center"
        ti.font = m.rowFont
        ti.color = m.theme.textPrimary

        ' Android's ListTile subtitle: what the programme actually is, under
        ' its name. It comes out of the listing this page already holds — no
        ' request, no lookup, nothing fetched per row.
        sy = g.createChild("Label")
        sy.width = 534
        sy.height = 24
        sy.translation = [156, 38]
        sy.maxLines = 1
        sy.vertAlign = "center"
        sy.font = m.rowSubFont
        sy.color = m.theme.textSecondary

        bdg = g.createChild("Poster")
        bdg.uri = "pkg:/images/card_fill.9.png"
        bdg.width = 84
        bdg.height = 30
        bdg.translation = [702, 19]
        bdg.blendColor = m.theme.liveBadge
        bdg.visible = false

        bl = g.createChild("Label")
        bl.width = 84
        bl.height = 30
        bl.translation = [702, 19]
        bl.horizAlign = "center"
        bl.vertAlign = "center"
        bl.font = m.badgeFont
        ' Was flat white; textPrimary is the palette's word for the same thing
        ' and is 3.9:1 on the nord-red badge.
        bl.color = m.theme.textPrimary
        bl.text = "NOW"
        bl.visible = false

        m.rowPool.push({ group: g, halo: halo, plate: plate, edge: edge, time: tm, title: ti, synopsis: sy, badge: bdg, badgeLbl: bl })
    end for
end sub

' Should this channel's listings be kept off the screen entirely?
'
' The Live TV list hides or gates a locked category on the way in, but this
' page is also reached from a favorite, from Recently Watched, from a list and
' from a deep link — see the long note over the parental block below. The same
' argument that keeps the PIN next to the play call applies to the LISTINGS:
' the point of locking a category is that the member does not get to see what
' is on it, and a full day of titles is a far bigger leak than the four rows
' this page used to print. GuideScreen already draws "Locked — press OK and
' enter your PIN" across a locked row instead of its programmes, and this is
' the same answer in the same words.
'
' This ASKS NOTHING. ParentalCatVerdict is a pair of lookups in the snapshot
' taken once in onChannel — no registry read, no request, no PIN pad. The pad
' still belongs to the play call, where the member has actually asked for
' something; a page that popped it just for being opened would be a different
' app. Get the PIN right there and onParentalPin redraws these rows.
' Known to be locked: the category is settled AND the rules say no.
function listingsLocked() as boolean
    if m.pgate = invalid then return false
    if not m.catDone then return false
    if m.catName = "" then return false
    return ParentalCatVerdict(m.pgate, m.catName) <> "show"
end function

' Keep the listings off the screen. That is either "known locked" or "not yet
' known, and this member has locks that could still apply" — the same hold
' parentalOkToPlay puts on a press while the playlist is parsing, for the same
' reason: beating the parse must not be the way past the rules. In practice
' nothing is on screen during that window anyway (the listings arrive from the
' same parse), which is why the hold shows no message — see updateGuideChrome.
function listingsSuppressed() as boolean
    if m.pgate = invalid then return false
    if listingsLocked() then return true
    if m.catDone then return false
    if parentalIdle() then return false
    return m.pgate.locked.count() > 0
end function

' Build the render list: every programme still to come inside the horizon,
' with a day separator wherever the local date changes.
' EVERY EVENT HANDLER ON THIS PAGE RUNS UNDER A GUARD. Two boxes died with
' EXIT_BRIGHTSCRIPT_CRASH seconds after this page logged "channel detail:
' guide 0 row(s) over the next 24h" - a Westinghouse WR32EX2100 on v1.0.37
' (key 7B44D7, its 7,250-channel playlist refused for room, so zero channels
' in memory) and an AIWA AW50RKQ on v1.0.36 (key 0CE33A, after a stream that
' would not play). Both pages had nothing to stand on: no guide rows and, on
' the first, no channels at all. A crash report carries no stack, so rather
' than guess at the deref, every entry point here names its line when it
' faults and leaves the page standing. See CrashLine in Util.brs.
sub buildDayGuide()
    try
        buildDayGuideInner()
    catch e
        GuardFailed("channel/buildDayGuide", e)
    end try
end sub

sub buildDayGuideInner()
    prevKey = m.cursorKey
    m.entries = []
    m.truncated = 0

    now = CreateObject("roDateTime").asSeconds()
    horizon = now + GUIDEHORIZONSECS()
    todayKey = localDayKey(now)
    tomorrowKey = localDayKey(now + 86400)
    lastDay = 0
    kept = 0

    if not listingsSuppressed()
        for each p in m.listings
            ' Android skips anything already over and keeps the one that is
            ' still on air, which is what stopS > now says.
            if p.stopS > now and p.startS < horizon
                if kept >= MAXDETAILROWS()
                    m.truncated = m.truncated + 1
                else
                    dk = localDayKey(p.startS)
                    ' No heading on the first group — Android prints one only
                    ' when the day CHANGES.
                    if lastDay <> 0 and dk <> lastDay
                        m.entries.push({ kind: "day", text: dayLabel(p.startS, todayKey, tomorrowKey) })
                    end if
                    lastDay = dk
                    m.entries.push({ kind: "pgm", p: p, isNow: (p.startS <= now) })
                    kept = kept + 1
                end if
            end if
        end for
    end if

    ' Put the cursor back on the programme it was on. The ticker rebuilds this
    ' list every 30 seconds and the show that just ended drops off the top, so
    ' matching by position would walk the selection up the list once a minute.
    m.cursor = -1
    if prevKey <> 0
        for i = 0 to m.entries.count() - 1
            if m.entries[i].kind = "pgm" and m.entries[i].p.startS = prevKey
                m.cursor = i
                exit for
            end if
        end for
    end if
    if m.cursor < 0 then m.cursor = defaultCursor()
    if m.cursor >= 0
        m.cursorKey = m.entries[m.cursor].p.startS
    else
        m.cursorKey = 0
        ' Nothing left to stand on (guide expired, or a lock came down while
        ' the member was in the list) — hand focus back to the buttons rather
        ' than leave a pane that answers no keys.
        if m.pane = 1
            m.pane = 0
            redrawButtons()
        end if
    end if

    clampView()
    renderRows()
    updateGuideChrome()

    if kept <> m.lastRowLog
        m.lastRowLog = kept
        msg = "channel detail: guide " + kept.toStr() + " row(s) over the next 24h"
        if m.truncated > 0 then msg = msg + " - CAPPED at " + MAXDETAILROWS().toStr() + ", " + m.truncated.toStr() + " more not shown"
        if listingsLocked() then msg = "channel detail: listings held back - [" + m.catName + "] is locked"
        KLog("livetv", msg)
    end if
end sub

' Where the cursor lands the first time RIGHT is pressed: whatever is on now,
' or failing that the first thing coming up.
function defaultCursor() as integer
    first = -1
    for i = 0 to m.entries.count() - 1
        if m.entries[i].kind = "pgm"
            if first = -1 then first = i
            if m.entries[i].isNow then return i
        end if
    end for
    return first
end function

function hasGuideRows() as boolean
    return defaultCursor() >= 0
end function

' Keep m.viewTop somewhere that shows the cursor.
sub clampView()
    total = m.entries.count()
    if total <= GUIDEVISROWS()
        m.viewTop = 0
        return
    end if
    if m.cursor >= 0
        if m.cursor < m.viewTop then m.viewTop = m.cursor
        ' If the row above the cursor is that day's heading, bring it in too —
        ' scrolling onto the first show of tomorrow with the word "Tomorrow"
        ' hidden one row off the top is how a list stops making sense.
        if m.cursor - 1 >= 0 and m.cursor - 1 < m.viewTop and m.entries[m.cursor - 1].kind = "day"
            m.viewTop = m.cursor - 1
        end if
        if m.cursor > m.viewTop + GUIDEVISROWS() - 1 then m.viewTop = m.cursor - GUIDEVISROWS() + 1
    end if
    if m.viewTop > total - GUIDEVISROWS() then m.viewTop = total - GUIDEVISROWS()
    if m.viewTop < 0 then m.viewTop = 0
end sub

' Fill the slot pool from m.viewTop. This is the whole cost of a key press:
' ten slots' worth of text and blend colours, no nodes made or destroyed and
' no image reloaded (a blendColor write does not touch the texture),
' comfortably inside the 250 ms certification 3.5 asks for.
sub renderRows()
    total = m.entries.count()
    for i = 0 to m.rowPool.count() - 1
        slot = m.rowPool[i]
        idx = m.viewTop + i
        if idx >= total
            slot.group.visible = false
        else
            e = m.entries[idx]
            slot.group.visible = true
            if e.kind = "day"
                ' A separator is a label, not a card: no plate, no frame, no
                ' badge. It is dropped to the bottom of its slot and pulled
                ' left to the time column so it hugs the row it heads, which
                ' is Android's own padding (14 above, 4 below).
                slot.halo.visible = false
                slot.plate.visible = false
                slot.edge.visible = false
                slot.time.text = ""
                slot.title.translation = [14, 34]
                slot.title.font = m.sepFont
                slot.title.color = m.theme.accent
                slot.title.text = UCase(ToStr(e.text))
                slot.synopsis.text = ""
                slot.badge.visible = false
                slot.badgeLbl.visible = false
            else
                focused = (m.pane = 1 and idx = m.cursor)
                slot.halo.visible = focused
                slot.plate.visible = true
                slot.edge.visible = true
                ' Three states, all three written on every bind: focused (the
                ' lifted plate and the focus frame), on air (the same
                ' accent-tinted plate the Guide grid gives "on now"), and at
                ' rest.
                if focused
                    slot.plate.blendColor = m.theme.surfaceLift
                    slot.edge.blendColor = m.theme.focusHighlight
                else
                    if e.isNow
                        slot.plate.blendColor = m.theme.surfaceAccent
                    else
                        slot.plate.blendColor = m.theme.surface
                    end if
                    slot.edge.blendColor = m.theme.cardIdleBorder
                end if
                slot.time.text = fmtTime(e.p.startS)
                if e.isNow then slot.time.color = m.theme.accent else slot.time.color = m.theme.textSecondary
                slot.title.translation = [156, 8]
                slot.title.font = m.rowFont
                slot.title.color = m.theme.textPrimary
                slot.title.text = ToStr(e.p.title)
                slot.synopsis.text = ToStr(GetField(e.p, "desc"))
                slot.badge.visible = e.isNow
                slot.badgeLbl.visible = e.isNow
            end if
        end if
    end for
end sub

' The heading, the hint line, the empty/locked message and the overflow line.
sub updateGuideChrome()
    if listingsSuppressed()
        m.guideHead.visible = false
        m.guideHint.text = ""
        m.guideMore.visible = false
        ' Say "locked" only when it IS locked. The other case — still working
        ' out which category this channel is in — says nothing at all, because
        ' most channels in that second are perfectly ordinary and telling every
        ' one of them it is locked would be a lie the member then watches
        ' correct itself.
        m.noGuide.text = "Locked — press OK on Watch Live and enter your PIN"
        m.noGuide.visible = listingsLocked()
        return
    end if
    if m.entries.count() = 0
        m.guideHead.visible = false
        m.guideHint.text = ""
        m.guideMore.visible = false
        m.noGuide.text = "No guide data for this channel"
        ' Don't call it empty while it is still downloading.
        m.noGuide.visible = not m.spinner.visible
        return
    end if
    m.noGuide.visible = false
    m.guideHead.visible = true
    if m.pane = 1
        m.guideHint.text = "OK for details  ·  LEFT for the buttons"
    else
        m.guideHint.text = "Press RIGHT for the full day"
    end if
    if m.truncated > 0
        m.guideMore.text = "+ " + m.truncated.toStr() + " more in the next 24 hours"
        m.guideMore.visible = true
    else
        m.guideMore.visible = false
    end if
end sub

' ---- Listing focus and movement ---------------------------------------------

sub focusGuide()
    if not hasGuideRows() then return
    m.pane = 1
    if m.cursor < 0 then m.cursor = defaultCursor()
    if m.cursor >= 0 then m.cursorKey = m.entries[m.cursor].p.startS
    clampView()
    redrawButtons()
    renderRows()
    updateGuideChrome()
end sub

sub focusButtons()
    m.pane = 0
    redrawButtons()
    renderRows()
    updateGuideChrome()
end sub

' Move the cursor, stepping straight over the day headings — they are labels,
' not choices, so landing on one would be a press of Down that appears to do
' nothing.
sub moveGuide(delta as integer)
    if m.entries.count() = 0 or m.cursor < 0 then return
    i = m.cursor + delta
    while i >= 0 and i < m.entries.count()
        if m.entries[i].kind = "pgm" then exit while
        i = i + delta
    end while
    if i < 0 or i >= m.entries.count() then return
    m.cursor = i
    m.cursorKey = m.entries[i].p.startS
    clampView()
    renderRows()
end sub

' A page at a time on the skip keys. A day can be sixty rows and holding Down
' through all of them is a long hold. The target is worked out first and the
' rows are drawn ONCE — walking there through moveGuide would redraw the list
' a dozen times for one press.
sub pageGuide(delta as integer)
    if m.entries.count() = 0 or m.cursor < 0 then return
    target = m.cursor
    hops = GUIDEVISROWS() - 1
    for h = 1 to hops
        i = target + delta
        while i >= 0 and i < m.entries.count()
            if m.entries[i].kind = "pgm" then exit while
            i = i + delta
        end while
        if i < 0 or i >= m.entries.count() then exit for
        target = i
    end for
    if target = m.cursor then return
    m.cursor = target
    m.cursorKey = m.entries[target].p.startS
    clampView()
    renderRows()
end sub

' OK on a row: what the programme is, when it is on, and Watch if it is the
' one on air now. No recording — Roku apps can't save video (K1) — so this is
' the whole of what a row can do, which is why Android's "select a future show
' to record it" hint is not ported.
sub showProgramDialog()
    if m.cursor < 0 or m.cursor >= m.entries.count() then return
    e = m.entries[m.cursor]
    if e.kind <> "pgm" then return
    p = e.p
    now = CreateObject("roDateTime").asSeconds()
    msg = dayLabel(p.startS, localDayKey(now), localDayKey(now + 86400)) + "  ·  " + fmtTime(p.startS) + " - " + fmtTime(p.stopS)
    body = ToStr(GetField(p, "desc"))
    ' A dialog taller than the screen has no scrollbar and no way out of the
    ' bottom of it, so the synopsis is trimmed rather than trusted.
    if body.len() > 420 then body = body.left(417) + "..."
    if body <> "" then msg = msg + Chr(10) + Chr(10) + body

    d = CreateObject("roSGNode", "Dialog")
    d.title = ToStr(p.title)
    d.message = msg
    m.pgmWatch = e.isNow
    if m.pgmWatch
        d.buttons = ["Watch Live", "Close"]
    else
        d.buttons = ["Close"]
    end if
    d.observeField("buttonSelected", "onProgramDialog")
    m.top.getScene().dialog = d
end sub

sub onProgramDialog(event as object)
    idx = ToInt(event.getData())
    watch = (m.pgmWatch and idx = 0)
    m.pgmWatch = false
    m.top.getScene().dialog.close = true
    m.top.setFocus(true)
    ' playChannel runs the parental gate itself, exactly as the button does —
    ' a row is not a way round it.
    if watch then playChannel()
end sub

' ---- Dates ------------------------------------------------------------------

' A local calendar day as one comparable number (20260824). Comparing epoch
' seconds would put 11pm and 1am on the same day or on different ones
' depending on the box's timezone, which is how a separator ends up in the
' wrong place.
function localDayKey(secs as integer) as integer
    dt = CreateObject("roDateTime")
    dt.fromSeconds(secs)
    dt.toLocalTime()
    return dt.getYear() * 10000 + dt.getMonth() * 100 + dt.getDayOfMonth()
end function

' "Today" / "Tomorrow" / "Wed, Aug 26" — Android's _dayLabel (:224), whose
' third case is DateFormat.MMMEd().
function dayLabel(secs as integer, todayKey as integer, tomorrowKey as integer) as string
    k = localDayKey(secs)
    if k = todayKey then return "Today"
    if k = tomorrowKey then return "Tomorrow"
    dt = CreateObject("roDateTime")
    dt.fromSeconds(secs)
    dt.toLocalTime()
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    mi = dt.getMonth() - 1
    mon = ""
    if mi >= 0 and mi <= 11 then mon = months[mi]
    wd = ToStr(dt.getWeekday())
    if wd.len() > 3 then wd = wd.left(3)
    return wd + ", " + mon + " " + dt.getDayOfMonth().toStr()
end function

' ---- Actions ----------------------------------------------------------------

sub playChannel()
    ch = m.top.channel
    ' The `m.provider = invalid` guard that used to sit here has gone: it was
    ' itself a silent dead button, and it refused a playlist channel that
    ' carries a perfectly good address of its own. The one test that matters
    ' is now further down — did an address come out the other end. This line
    ' keeps the only guard that was ever load-bearing, the same one
    ' openMultiView makes.
    if ch = invalid then return
    ' Parental gate, ahead of everything else the press does — a refused Watch
    ' Live must not write Continue Watching either.
    if not parentalOkToPlay({ kind: "watch" }) then return

    ' >>> THE ADDRESS, AND WHO IS ALLOWED TO BUILD ONE <<<
    '
    ' A channel that carries its own address (a playlist row) plays from that.
    ' A panel channel carries no address at all — it is a stream id — so an
    ' address has to be BUILT from a source, and only an Xtream panel can
    ' build one. This is a POSITIVE test for the two kinds that can, the same
    ' shape HomeScreen.resumeOrNext uses (:1149), and deliberately not a list
    ' of exclusions: the old `<> "m3u"` style test is what let a media server
    ' through on the Home page and halted the app there.
    '
    ' It is needed because m.provider is the channel's OWN source only while
    ' that source's src token still resolves (onChannel :323). When it does
    ' not, m.provider is still whatever source happens to be active, which can
    ' be any kind at all.
    '
    ' LOG KEY FCF117 — Hisense 6Series-58, v1.0.39, 29 September 2026. What
    ' happened on the member's television, in plain words: they removed their
    ' source in Settings, a different one came back from the website on its
    ' own three seconds later, and the first channel they pressed Watch Live
    ' on was a leftover from the source they had just taken out. The app had
    ' nothing left to match it against, so it reached for the source that had
    ' just arrived — an ordinary playlist, which has no panel address to build
    ' a stream from — and the television froze with the spinner still turning
    ' and nothing on screen to say why. Util.brs now answers "" there instead
    ' of stopping the app; this is the half that tells the member something.
    url = LivePlayUrl(ToStr(ch.url))
    if url = ""
        pt = ""
        if m.provider <> invalid then pt = LCase(ToStr(m.provider.ptype))
        if pt = "xtream" or pt = "kwicktv"
            url = XtreamLiveUrl(m.provider, ToStr(ch.streamId))
        end if
    end if
    ' Checked BEFORE PushRecentChannel, for the same reason the parental
    ' refusal above sits where it does: a press that cannot become playback
    ' must not leave a trace of a channel the member never watched.
    if url = ""
        cannotPlayNote(ToStr(ch.name))
        return
    end if
    rec = { streamId: ToStr(ch.streamId), name: ToStr(ch.name), logo: ToStr(ch.logo), url: ToStr(ch.url) }
    if m.itemSrc <> invalid then rec.src = m.itemSrc
    PushRecentChannel(rec)
    m.player = m.top.getScene().createChild("PlayerScreen")
    m.player.titleText = ToStr(ch.name)
    m.player.channel = { streamId: ToStr(ch.streamId), name: ToStr(ch.name), logo: ToStr(ch.logo), url: ToStr(ch.url) }
    m.player.streamUrl = url
    m.player.streamFormat = StreamFormatFor(url, "")
    m.player.isLive = true
    m.player.observeField("closed", "onPlayerClosed")
    m.player.setFocus(true)
    m.player.start = true
end sub

sub onPlayerClosed()
    try
        onPlayerClosedInner()
    catch e
        GuardFailed("channel/onPlayerClosed", e)
    end try
end sub

sub onPlayerClosedInner()
    if m.player <> invalid
        m.top.getScene().removeChild(m.player)
        m.player = invalid
    end if
    m.top.setFocus(true)
end sub

' ---- Multi-View -------------------------------------------------------------

sub openMultiView()
    ch = m.top.channel
    if ch = invalid then return
    ' Watch Together is gated exactly like Watch Live. The picker filters
    ' locked categories out of its own lists (MultiViewPicker: a picker has
    ' nowhere sensible to put a PIN prompt) — but this channel does not go
    ' through those lists: it is handed over as seedJson and pushed straight
    ' into the chosen panes, so the picker's filter never sees it. A detail
    ' screen DOES have somewhere to put the prompt, so it asks here instead,
    ' and a correct PIN unlocks the session for the picker's lists too.
    if not parentalOkToPlay({ kind: "multiview" }) then return
    seedCh = { streamId: ToStr(ch.streamId), name: ToStr(ch.name), logo: ToStr(ch.logo), url: ToStr(ch.url) }
    if m.itemSrc <> invalid then seedCh.src = m.itemSrc
    seed = MvLiveSlot(seedCh)
    m.mvPicker = m.top.getScene().createChild("MultiViewPicker")
    if seed <> invalid then m.mvPicker.seedJson = FormatJson(seed)
    m.mvPicker.observeField("closed", "onMvPickerClosed")
    m.mvPicker.setFocus(true)
    m.mvPicker.start = true
end sub

sub onMvPickerClosed()
    res = ""
    if m.mvPicker <> invalid
        res = m.mvPicker.result
        m.top.getScene().removeChild(m.mvPicker)
        m.mvPicker = invalid
    end if
    if res = ""
        m.top.setFocus(true)
        return
    end if
    ' On the scene, not inside this page — same rule as the player.
    m.mvScreen = m.top.getScene().createChild("MultiViewScreen")
    m.mvScreen.slotsJson = res
    m.mvScreen.observeField("closed", "onMultiViewClosed")
    m.mvScreen.setFocus(true)
    m.mvScreen.start = true
end sub

sub onMultiViewClosed()
    if m.mvScreen <> invalid
        m.top.getScene().removeChild(m.mvScreen)
        m.mvScreen = invalid
    end if
    m.top.setFocus(true)
end sub

sub openAddToList()
    ch = m.top.channel
    m.addList = m.top.getScene().createChild("AddToListScreen")
    itemAA = { kind: "channel", id: ToStr(ch.streamId), name: ToStr(ch.name), icon: ToStr(ch.logo), ext: "" }
    if m.itemSrc <> invalid then itemAA.src = m.itemSrc
    m.addList.item = itemAA
    m.addList.observeField("closed", "onAddListClosed")
    m.addList.setFocus(true)
end sub

sub onAddListClosed()
    if m.addList <> invalid
        m.top.getScene().removeChild(m.addList)
        m.addList = invalid
    end if
    buildButtons()
    m.top.setFocus(true)
end sub

' ---- Parental gate -----------------------------------------------------------
'
' The Live TV category list hides or gates a locked category, but this page is
' also reached from a favorite, from Recently Watched, from a saved list and
' from a deep link — none of which passed that list. So the last word on
' whether a locked channel plays belongs here, next to the play call, the same
' way GuideScreen keeps it next to its own.
'
' The rule, the PIN pad and the session unlock are the shared ones in
' GuideMeta.brs. A locked category asks here EVEN IN "hide" mode, for the
' reason the helper gives: hiding never applied on the way in.
'
' The adult rule (certification 6.3) rides along, because it is the same
' helper: an adult category with the Settings switch off answers "blocked",
' which no PIN opens. That is the one verdict that says no rather than asking.
'
' COST. ParentalGate() is about a dozen registry reads, taken ONCE in
' onChannel — never per button. A member with nothing locked AND adult
' categories already allowed takes parentalIdle()'s early exit and this block
' does nothing at all; everyone else pays one walk of the playlist already in
' memory, and one hash lookup per press. No request is made for any of it.

function parentalIdle() as boolean
    if m.pgate = invalid then return true
    if not m.pgate.adultOk then return false
    return m.pgate.locked.count() = 0
end function

' WHICH CATEGORY IS THIS CHANNEL IN? Honestly: it depends on the source.
'
'   · M3U — free. The parsed playlist carries every channel's group-title, and
'     it is already in the globals (this page parses it itself for the guide
'     when Live TV hasn't). Matched by url, the same match applyXmltv makes.
'   · Xtream — NOT KNOWABLE HERE. A channel arrives as {streamId, name, logo,
'     url, src}: favorites, recents and lists have never stored a category,
'     and the only call this page makes (get_short_epg) does not return one.
'     The category lives in get_live_streams, which is fetched PER CATEGORY by
'     Live TV and the guide, so answering it here would mean a fresh request
'     on every detail open — the exact per-item request pattern the audit
'     blamed for the memory and stutter incidents. So this returns "" and the
'     channel is let through, which is the same honest limitation
'     ParentalBlockedCatIds already documents for a cold id->name cache.
'     THE CHEAPEST CORRECT FIX, if this gap is to be closed: when (and only
'     when) the member actually has live categories locked, fetch
'     get_live_streams&category_id=<locked id> for those categories alone —
'     one request per LOCKED category, not per item — and keep the resulting
'     stream-id set in a session-scoped global (m.global.addFields, the way
'     SettingsCategoryScreen keeps its task handles) so the whole app pays for
'     it at most once per launch. Nothing was fetched here without that
'     decision being taken deliberately.
' Find this channel's row in the parsed playlist, ONCE, and keep its group.
'
' ONE WALK, NO REQUEST. This is the same match applyXmltv makes on the same
' in-memory array; it is not a lookup that can be indexed, because a channel
' arrives here from a favourite or a deep link carrying only {streamId, name,
' logo, url, src} and the playlist is keyed on neither. The walk happens once
' per channel opened, never per key press and never per row.
'
' It used to live inside resolveCatName and only ran when the member actually
' had parental locks set. The group chip needs it either way, so it moved out
' — a member with nothing locked now pays one walk of an array that is already
' in memory, on a screen open. Nothing else changed about it.
sub resolveChannelMeta()
    m.chGroup = ""
    m.chMatched = false
    ch = m.top.channel
    if ch = invalid or m.provider = invalid then return
    if m.provider.ptype <> "m3u" then return
    if m.global.m3uChannels.count() = 0 then return
    url = ToStr(GetField(ch, "url"))
    sid = ToStr(GetField(ch, "streamId"))
    for each c in m.global.m3uChannels
        hit = false
        if url <> "" and ToStr(c.url) = url
            hit = true
        else if url = "" and sid <> "" and ToStr(c.streamId) = sid
            hit = true
        end if
        if hit
            m.chMatched = true
            m.chGroup = ToStr(GetField(c, "group"))
            exit for
        end if
    end for
end sub

sub resolveCatName()
    resolveChannelMeta()
    m.catName = ""
    m.catDone = true
    ' Nothing to enforce: the group is still resolved above for the chip, but
    ' no category name is claimed here, so parentalOkToPlay's early exit and
    ' listingsLocked's "" test behave exactly as they did.
    if parentalIdle() then return
    if not m.chMatched then return
    ' Same naming LiveTvScreen.m3uGroupCats gives these categories, since the
    ' locks are stored under the name it shows.
    m.catName = m.chGroup
    if m.catName = "" then m.catName = "Uncategorized"
end sub

' May this press start playback (or open Multi-View)? "asked" leaves the PIN
' pad on screen and the press is replayed if the member gets it right.
function parentalOkToPlay(pending as object) as boolean
    if parentalIdle() then return true
    if not m.catDone
        ' Pressed while the playlist that carries the group name is still
        ' being parsed. With a category actually LOCKED, hold the press rather
        ' than let it through blind — otherwise beating the parse to the
        ' button would be the way past the PIN. The page's spinner is already
        ' up, and every answer (including a failed one) releases it.
        '
        ' Nothing locked means the only rule left is the adult one, which is
        ' every member's default state — holding every first press on it would
        ' change what a member with no parental controls at all feels, for a
        ' case that is already dropped from every list they can browse. So
        ' that one is judged when the answer lands, and not before.
        if m.pgate.locked.count() = 0 then return true
        m.pendingPlay = pending
        KLog("livetv", "channel detail: holding play until the category is known")
        return false
    end if
    if m.catName = "" then return true
    v = ParentalGuardWith(m.pgate, m.top, m.catName, "onParentalPin", "onParentalPinCancel")
    if v = "allow" then return true
    if v = "asked"
        KLog("livetv", "channel detail: [" + m.catName + "] is locked - asking for the PIN")
        m.pendingPlay = pending
        return false
    end if
    ' "blocked": an adult category with the Settings switch off. No PIN gets
    ' in, so say so rather than leave the button looking broken.
    KLog("livetv", "channel detail: [" + m.catName + "] is an adult category and the Settings switch is off")
    m.pendingPlay = invalid
    note = CreateObject("roSGNode", "Dialog")
    note.title = "Not Available"
    note.message = "Adult categories are switched off. Turn on 'Show adult categories' under Settings > Parental controls to watch this."
    note.buttons = ["OK"]
    note.observeField("buttonSelected", "onParentalPinNote")
    m.top.getScene().dialog = note
    return false
end function

' Carry out the press that was held (or unlocked). Cleared FIRST so a second
' refusal can't loop.
sub flushPendingPlay()
    p = m.pendingPlay
    if p = invalid then return
    m.pendingPlay = invalid
    if ToStr(p.kind) = "multiview"
        openMultiView()
    else
        playChannel()
    end if
end sub

sub onParentalPin()
    if ParentalAcceptPin()
        ' Unlocked for the rest of the session — take a fresh snapshot (it now
        ' loads no locks at all) and carry out what was asked for.
        m.pgate = ParentalGate("live")
        ' The listings were being held back by that lock, so put them up: the
        ' member has just proved they are allowed to see them, and coming back
        ' from the player to a page still saying "Locked" would be wrong.
        ' The group chip was held back with them, so it comes back too.
        refreshNowBlock()
        buildChips()
        buildDayGuide()
        flushPendingPlay()
    else
        ParentalWrongPinNote(m.top, "onParentalPinNote")
    end if
end sub

sub onParentalPinCancel()
    ParentalClosePin()
    m.pendingPlay = invalid
    m.top.setFocus(true)
end sub

sub onParentalPinNote()
    m.top.getScene().dialog.close = true
    m.pendingPlay = invalid
    m.top.setFocus(true)
end sub

' ---- "Can't play this right now" --------------------------------------------
'
' The same refusal MovieDetailScreen (:1384) and SeriesDetailScreen (:1116)
' already put up when a source cannot open the thing being asked for: one
' Dialog, one OK button, focus handed back to the page. Written out again here
' rather than shared, because a component only ever sees the scripts its own
' XML names and those two live in their own screens' files.
'
' Its own close handler rather than the parental one's, for the reason those
' two give: onParentalPinNote also clears m.pendingPlay, and this refusal
' never sets it.
'
' LOG KEY FCF117: before this, the member's press did nothing whatsoever. The
' guard in Util.brs stops the app dying, but on its own it turns a crash into
' a button that silently does nothing — the television just sits there. This
' is the part that says something.
'
' THE WORDING names no cause it cannot be sure of. The commonest reason is a
' channel left behind by a removed source, but the same dead end is reached by
' a playlist row that carries no address, so it says "probably" and offers the
' one thing the member can actually do about it.
sub cannotPlayNote(chName as string)
    KLog("livetv", "channel detail: refused play - no source on this box can open [" + chName + "]")
    note = CreateObject("roSGNode", "Dialog")
    note.title = "Can't Play This Right Now"
    note.message = "Kwick Player has no working source for this channel. It was probably left behind by a source you removed. Check your sources under Settings, or pick another channel."
    note.buttons = ["OK"]
    note.observeField("buttonSelected", "onCannotPlayNote")
    m.top.getScene().dialog = note
end sub

sub onCannotPlayNote()
    m.top.getScene().dialog.close = true
    m.top.setFocus(true)
end sub

' ---- Keys -------------------------------------------------------------------

function onKeyEvent(key as string, press as boolean) as boolean
    try
        return onKeyEventInner(key, press)
    catch e
        GuardFailed("channel/onKeyEvent", e)
        return true
    end try
end function

function onKeyEventInner(key as string, press as boolean) as boolean
    if not press then return false

    if key = "back"
        ' One step out of the listings first. Back still leaves the page on
        ' the next press, so certification 4.6 holds — it just does not throw
        ' away where the member was in the day.
        '
        ' The clause VERBATIM, because a paraphrase of this one has already
        ' cost us once (3.4 is the loading-indicator rule, not this):
        '
        '   "Apps must directly return the user to the previous screen and/or
        '    state when the back button on the Roku remote is pressed. When the
        '    back button is pressed on the app's home screen, apps must exit the
        '    app and return the user to the Roku home screen. Apps may display a
        '    single confirmation dialog immediately before the user exits the
        '    app—and then return the user to the Roku home screen upon receiving
        '    confirmation that they want to leave the app."
        '
        ' Note the third sentence: a single confirm dialog on the way out is
        ' expressly ALLOWED. The vault note carried only the first two, which
        ' made it look forbidden. Full text and the warning are in
        ' Wiki\Roku\Roku - Store Certification Analysis.md.
        if m.pane = 1
            focusButtons()
            return true
        end if
        m.top.closed = true
        return true
    end if

    ' The listings pane owns up/down/OK while it has the cursor. The button
    ' chain below is untouched and still runs whenever m.pane = 0.
    if m.pane = 1
        if key = "left"
            focusButtons()
            return true
        else if key = "down"
            moveGuide(1)
            return true
        else if key = "up"
            moveGuide(-1)
            return true
        else if key = "fastforward"
            pageGuide(1)
            return true
        else if key = "rewind"
            pageGuide(-1)
            return true
        else if key = "OK"
            showProgramDialog()
            return true
        end if
        return false
    end if

    if key = "right"
        ' Along the row first; off the end of it, into the listings. Only
        ' cross if there is something to cross to — a right press with no
        ' listings must not park the cursor where nothing answers.
        if moveButtons(1, 0) then return true
        if hasGuideRows()
            focusGuide()
            return true
        end if
        return false
    end if

    if key = "left"
        ' Nothing to the left means the press was not ours, which is what
        ' this screen has always answered to a left press on the actions.
        return moveButtons(-1, 0)
    else if key = "down"
        moveButtons(0, 1)
        return true
    else if key = "up"
        moveButtons(0, -1)
        return true
    else if key = "OK"
        k = m.buttons[m.btnFocus].key
        if k = "watch"
            playChannel()
        else if k = "multiview"
            openMultiView()
        else if k = "favorite"
            ch = m.top.channel
            fav = { streamId: ToStr(ch.streamId), name: ToStr(ch.name), logo: ToStr(ch.logo), url: ToStr(ch.url) }
            if m.itemSrc <> invalid then fav.src = m.itemSrc
            ToggleFavoriteChannel(fav)
            buildButtons()
        else if k = "addlist"
            openAddToList()
        end if
        return true
    end if
    return false
end function

' "8:05 PM" from epoch seconds, in the device's local time.
function fmtTime(secs as integer) as string
    dt = CreateObject("roDateTime")
    dt.fromSeconds(secs)
    dt.toLocalTime()
    h = dt.getHours()
    mm = dt.getMinutes()
    suffix = "AM"
    if h >= 12 then suffix = "PM"
    h12 = h mod 12
    if h12 = 0 then h12 = 12
    mStr = mm.toStr()
    if mm < 10 then mStr = "0" + mStr
    return h12.toStr() + ":" + mStr + " " + suffix
end function
