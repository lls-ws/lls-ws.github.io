' One add-on's page: the member's own account on OpenSubtitles, Trakt or
' Simkl. Opened from Settings -> Add-ons with `addon` set to the id.
'
' MASON'S RULE, and the reason there is no "sign in with our account"
' anywhere here: members use THEIR OWN logins on every add-on. No shared
' Kwick account behind any of them.
'
' TWO SHAPES, because the services allow two different sign-ins (JB-9, and
' the table at the top of AddOns.brs). OpenSubtitles' API takes a username
' and a password from an app — the only one of the three that does — so the
' member types them here, on Roku's own keyboard. Trakt and Simkl are OAuth
' only: they hand out a short code, the member types it on the SERVICE'S own
' page, and this box shows the code, the address in words, and a QR square
' of that address with the code already in it. Nothing is ever typed into
' this app for those two, which is also why they are fine under Roku's rules
' — the box never puts up a password box for somebody else's service.
'
' WHAT NEVER HAPPENS HERE: the token is never drawn, never logged, never put
' on the sync wire. It goes to the registry through Store.brs and nowhere
' else. The password is held only for as long as the sign-in request takes
' and is wiped the moment it lands.
'
' WHAT STOPS THE POLLING. Trakt and Simkl are asked, over and over, whether
' the member has finished on their phone. Every one of those requests costs
' the whole membership something — Simkl's own note is that ONE PIN sign-in
' can eat about 180 of the app's 1,000 requests for the day — so:
'
'   * nothing is asked until the member presses Sign in. Opening this page
'     to look at it costs one nothing.
'   * the gap between questions is the one the relay asked for and never
'     shorter, with a five-second floor if the relay says something silly.
'   * Cancel, Back, a sign-in landing, a code running out and the screen
'     being taken away all run through stopWaiting(), which stops both
'     timers and the request in the air.
'   * both timers check on every tick that this screen is still attached to
'     a scene, and shut themselves down if it is not — so there is no such
'     thing as an orphaned poll even if a host throws the screen away
'     without saying so.

sub init()
    m.theme = KwickTheme()

    m.top.findNode("bg").color = m.theme.background
    ' This screen is a scene-level overlay, so its own backdrop covers
    ' AppScene's grid wash. AddPageGrid() puts the mesh in at child 1, just
    ' above that backdrop and under everything drawn here.
    AddPageGrid(m.top)

    ' JB-4's accent block. This screen IS the open group — it is built when a
    ' row is pressed and removed whole when the member backs out — so there
    ' is no closed state to paint back, exactly as on SettingsCategoryScreen.
    ' 1A is 26/255, i.e. 10.2%: the 10% Mason approved on Windows, and the
    ' ceiling rather than a starting point.
    m.wash = m.top.findNode("wash")
    m.wash.color = ColorWithAlpha(m.theme.accent, 26)
    m.rule = m.top.findNode("rule")
    m.rule.color = m.theme.accent

    m.header = m.top.findNode("header")
    m.header.font = UiBoldFont(46)
    m.header.color = m.theme.textPrimary

    m.subhead = m.top.findNode("subhead")
    m.subhead.font = UiFont(25)
    m.subhead.color = m.theme.textSecondary

    m.intro = m.top.findNode("intro")
    m.intro.font = UiFont(24)
    m.intro.color = m.theme.textSecondary

    m.fieldUser = m.top.findNode("fieldUser")
    m.fieldPass = m.top.findNode("fieldPass")
    ' `secure` has no onChange on FormField, so it is set before the label
    ' and the value — whichever of those lands last is what triggers the
    ' field's own redraw, and it has to read the right mask setting when it
    ' does.
    m.fieldPass.secure = true
    m.fieldUser.fieldWidth = 620
    m.fieldPass.fieldWidth = 620
    m.fieldUser.label = "Username"
    m.fieldPass.label = "Password"

    m.step1 = m.top.findNode("step1")
    m.step1.font = UiFont(26)
    m.step1.color = m.theme.textSecondary
    m.codeUrl = m.top.findNode("codeUrl")
    m.codeUrl.font = UiBoldFont(38)
    m.codeUrl.color = m.theme.accentAlt
    m.step2 = m.top.findNode("step2")
    m.step2.font = UiFont(26)
    m.step2.color = m.theme.textSecondary
    m.codeBg = m.top.findNode("codeBg")
    m.codeBg.color = m.theme.surfaceElevated
    m.codeLabel = m.top.findNode("codeLabel")
    m.codeLabel.color = m.theme.textPrimary
    m.expiryLabel = m.top.findNode("expiryLabel")
    m.expiryLabel.font = UiFont(24)
    m.expiryLabel.color = m.theme.textSecondary

    m.acctLabel = m.top.findNode("acctLabel")
    m.acctLabel.font = UiBoldFont(34)
    m.acctLabel.color = m.theme.textPrimary
    m.quotaLabel = m.top.findNode("quotaLabel")
    m.quotaLabel.font = UiFont(27)
    m.acctSub = m.top.findNode("acctSub")
    m.acctSub.font = UiFont(23)
    m.acctSub.color = m.theme.textSecondary

    ' The signed-in Trakt / Simkl page: the same row list Settings uses, its
    ' sticky group name above it and the focused row's own explanation below.
    m.sectionTitle = m.top.findNode("sectionTitle")
    m.sectionTitle.font = UiBoldFont(26)
    m.sectionTitle.color = m.theme.accent
    m.rowList = m.top.findNode("rowList")
    m.rowList.observeField("itemSelected", "onRowSelected")
    m.rowList.observeField("itemFocused", "onRowFocused")
    m.rowSub = m.top.findNode("rowSub")
    m.rowSub.font = UiFont(24)
    m.rowSub.color = m.theme.textSecondary

    m.statusLabel = m.top.findNode("statusLabel")
    m.statusLabel.font = UiFont(26)
    m.hintLabel = m.top.findNode("hintLabel")
    m.hintLabel.font = UiFont(23)
    m.hintLabel.color = m.theme.textSecondary

    m.qrPlate = m.top.findNode("qrPlate")
    ' Pure white whatever the palette does: this is the quiet zone a phone
    ' camera needs to read the square, not a surface in the theme.
    m.qrPlate.color = "0xFFFFFFFF"
    m.qrGrid = m.top.findNode("qrGrid")
    m.qrCaption = m.top.findNode("qrCaption")
    m.qrCaption.font = UiFont(23)
    m.qrCaption.color = m.theme.textSecondary

    m.buttons = [
        { wrap: m.top.findNode("btn0"), ring: m.top.findNode("btn0Ring"), bg: m.top.findNode("btn0Bg"), lbl: m.top.findNode("btn0Label") },
        { wrap: m.top.findNode("btn1"), ring: m.top.findNode("btn1Ring"), bg: m.top.findNode("btn1Bg"), lbl: m.top.findNode("btn1Label") }
    ]
    for each b in m.buttons
        b.lbl.font = UiBoldFont(28)
        b.ring.color = m.theme.focusHighlight
    end for

    m.pollTimer = m.top.findNode("pollTimer")
    m.pollTimer.observeField("fire", "onPollTimer")
    m.tickTimer = m.top.findNode("tickTimer")
    m.tickTimer.observeField("fire", "onTick")

    m.values = { "username": "", "password": "" }
    m.controls = []
    m.focus = 0
    ' The signed-in Trakt / Simkl page hands its keys to the row list instead
    ' of to m.controls. Set up front, not left invalid: onKeyEvent and
    ' onFocusIn both read it back on the very first press.
    m.listMode = false
    m.rows = []
    m.rowSection = ""
    ' Which row the highlight is on, so a redraw after a switch puts the group
    ' line and the explanation back on the right row instead of on row 0 for a
    ' frame. And which row the "Sync every..." picker was opened from, read
    ' back in its handler.
    m.rowFocus = 0
    m.syncEveryIdx = 0
    m.stage = "signedout"
    m.statusText = ""
    m.statusKind = ""      ' "" | "error" | "good"
    m.task = invalid
    m.qrTask = invalid
    m.qrRows = invalid
    m.codeSpaced = ""
    m.codeShown = ""
    m.expiryText = ""
    m.quotaGone = false
    m.pendingToken = ""
    m.pendingRefresh = ""
    m.kbDialog = invalid
    m.kbKey = ""
    m.confirmDialog = invalid
    m.polling = false
    m.pollSecs = 6
    m.userCode = ""
    m.deviceCode = ""
    m.expiresAt = 0
    m.pollFails = 0
    m.acct = invalid

    m.top.observeField("focusedChild", "onFocusIn")

    ' The parent sets `addon` straight after createChild, so whichever of the
    ' two arrives second is the one that draws the page. Both orders are
    ' covered and neither draws twice.
    m.ready = true
    if m.top.addon <> "" then refresh()
end sub

sub onAddOnChanged()
    if m.ready <> true then return
    if m.top.addon = "" then return
    refresh()
end sub

sub onFocusIn()
    ' A dialog of ours is a child of this screen, so it owns the keys while
    ' it is up and must not have focus pulled back out from under it.
    if m.confirmDialog <> invalid then return
    if not m.top.hasFocus() then return
    ' On the row-list page focus is FORWARDED, never a redraw. Rebuilding here
    ' would re-enter through the setFocus below and there would be no end to
    ' it; this is the same thing SettingsCategoryScreen.onFocusIn does, for the
    ' same reason. The second pass, with the list holding focus, leaves through
    ' the hasFocus test above.
    if m.listMode = true
        if m.rows.count() > 0 then m.rowList.setFocus(true)
        return
    end if
    redraw()
end sub

' ---- Which service this page is -------------------------------------------
'
' Everything that differs between the three lives in one map, built fresh
' each time it is asked for, so there is no second copy to fall out of step.
' The URLs come from AddOns.brs, which is the contract; nothing here builds
' a relay address by hand.

function svcInfo() as object
    id = ToStr(m.top.addon)
    nm = AddOnLabel(id)
    if id = "trakt"
        return {
            "id": id,
            "name": nm,
            "flow": "code",
            "subhead": "Keep a record on Trakt of what you watch here",
            "intro": "Kwick Player can mark what you watch on your own Trakt account. Trakt never lets an app see your password, so you sign in on Trakt's own page.",
            "introIn": "What you watch here is now marked on Trakt as you watch it.",
            "startUrl": TraktUrl("device_code"),
            "pollUrl": TraktUrl("device_token"),
            "meUrl": TraktUrl("me"),
            "revokeUrl": TraktUrl("revoke"),
            "fallbackUrl": "trakt.tv/activate",
            ' Trakt asks to be polled every 6 seconds, measured against the
            ' live API on 2026-09-15. Only ever used when the relay's own
            ' answer leaves the interval out.
            "interval": 6,
            "signOutWhy": "Kwick Player stops marking what you watch on Trakt, and your Trakt rows stop appearing on Home. Nothing on your Trakt account is deleted, and you can sign in again whenever you like.",
            ' The one line under the Sign out ROW, which is a shorter thing
            ' than the dialog's own message above. Android's words, verbatim.
            "signOutSub": "Forgets this account on this device"
        }
    end if
    if id = "simkl"
        return {
            "id": id,
            "name": nm,
            "flow": "code",
            "subhead": "Keep a record on Simkl of what you watch here",
            "intro": "Kwick Player can mark what you watch on your own Simkl account. Simkl never lets an app see your password, so you sign in on Simkl's own page.",
            "introIn": "What you watch here is now marked on Simkl as you watch it.",
            "startUrl": SimklUrl("pin"),
            "pollUrl": SimklUrl("pin_token"),
            "meUrl": SimklUrl("me"),
            "revokeUrl": "",
            "fallbackUrl": "simkl.com/pin",
            ' Deliberately slower than Trakt's when the relay says nothing.
            ' Simkl allows the WHOLE APP 1,000 requests a day until they
            ' approve it, and one PIN sign-in can spend about 180 of them.
            "interval": 10,
            ' Mason's own words on the Android card, kept because they are
            ' the honest answer: Simkl has no revoke for an app to call.
            "signOutWhy": "Kwick Player stops marking what you watch on Simkl. Nothing on your Simkl account is deleted." + Chr(10) + Chr(10) + "Simkl has no way for an app to sign itself out, so remove Kwick Player under your Simkl settings if you want it gone there too.",
            ' Longer than Trakt's on purpose, and Android's words verbatim:
            ' Simkl is the one service an app cannot sign itself out of, so the
            ' row says so before the member presses it rather than only in the
            ' dialog afterwards.
            "signOutSub": "Forgets this account on this device. Simkl keeps the app listed under Connected Apps until you remove it there."
        }
    end if
    return {
        "id": "opensubtitles",
        "name": AddOnLabel("opensubtitles"),
        "flow": "password",
        "subhead": "Subtitles for films and episodes, from your own account",
        "intro": "Sign in with the username and password from your own opensubtitles.com account. Kwick Player does not keep your password.",
        "introIn": "While a film or episode is playing, open Subtitles and choose Find subtitles online.",
        "startUrl": SubsLoginUrl(),
        "pollUrl": "",
        "meUrl": "",
        "revokeUrl": SubsLogoutUrl(),
        "fallbackUrl": "opensubtitles.com",
        "interval": 0,
        "signOutWhy": "Finding subtitles online stops working on this TV until you sign in again. Your OpenSubtitles account and your daily allowance are not affected.",
        ' Never read — OpenSubtitles keeps the button page it has and has no
        ' Sign out ROW. Set anyway so every branch of this map has every field
        ' and nothing here can read back invalid.
        "signOutSub": ""
    }
end function

' ---- Opening the page -------------------------------------------------------

sub refresh()
    m.svc = svcInfo()
    m.acct = AddOnAccount(m.svc.id)
    m.values = { "username": "", "password": "" }
    m.statusText = ""
    m.statusKind = ""
    stopWaiting()

    if AddOnSignedIn(m.svc.id)
        m.stage = "signedin"
    else if m.svc.flow = "password"
        m.stage = "form"
    else
        m.stage = "signedout"
    end if
    m.focus = 0
    ' A fresh visit starts on the first row, not wherever the last visit to
    ' some other add-on's page left the highlight.
    m.rowFocus = 0
    redraw()
end sub

' ---- Drawing ----------------------------------------------------------------
'
' ONE redraw for the whole page, and it turns EVERYTHING off first and then
' turns back on only what this page needs, with all of its properties set —
' text, colour, width, position, visibility. Nothing here is set in an "on"
' branch alone: a node that is only hidden keeps its old width and colour and
' flashes the last page's shape for a frame before the new one lands.

sub redraw()
    if m.svc = invalid then return
    hideEverything()

    m.header.text = m.svc.name
    m.subhead.text = m.svc.subhead

    if m.stage = "signedin"
        drawSignedIn()
    else if m.stage = "form"
        drawForm(false)
    else if m.stage = "busy" and m.svc.flow = "password"
        drawForm(true)
    else if m.stage = "code"
        drawCode()
    else if m.stage = "busy"
        drawGettingCode()
    else if m.stage = "expired"
        drawExpired()
    else
        drawSignedOut()
    end if

    paintStatus()
    paintFocus()
end sub

sub hideEverything()
    m.intro.visible = false
    m.fieldUser.visible = false
    m.fieldPass.visible = false
    m.fieldUser.focused = false
    m.fieldPass.focused = false
    m.step1.visible = false
    m.codeUrl.visible = false
    m.step2.visible = false
    m.codeBg.visible = false
    m.codeLabel.visible = false
    m.expiryLabel.visible = false
    m.acctLabel.visible = false
    m.quotaLabel.visible = false
    m.acctSub.visible = false
    m.sectionTitle.visible = false
    m.rowList.visible = false
    m.rowSub.visible = false
    m.hintLabel.visible = false
    m.statusLabel.visible = false
    m.qrPlate.visible = false
    m.qrCaption.visible = false
    m.qrGrid.visible = false
    for each b in m.buttons
        b.wrap.visible = false
        b.ring.visible = false
    end for
    m.controls = []
    ' Off on every redraw and back on only where the list is really drawn, so
    ' a page that follows the Trakt one cannot leave the keys pointing at a
    ' hidden list.
    m.listMode = false
end sub

' OpenSubtitles, signed out. `working` is the same page with the request in
' the air: the boxes stay on screen so the member can see what they typed,
' and the button becomes Cancel.
sub drawForm(working as boolean)
    setIntro(m.svc.intro)

    m.fieldUser.visible = true
    m.fieldUser.translation = [192, 300]
    m.fieldUser.value = m.values["username"]
    m.fieldPass.visible = true
    m.fieldPass.translation = [192, 412]
    m.fieldPass.value = m.values["password"]

    if working
        paintButton(0, "Cancel", false, 192, 540)
        m.controls = [{ "kind": "cancel", "btn": 0 }]
    else
        m.controls = [{ "kind": "user" }, { "kind": "pass" }, { "kind": "signin", "btn": 0 }]
        paintButton(0, "Sign in", true, 192, 540)
    end if

    m.statusLabel.translation = [192, 650]
    m.hintLabel.text = "Highlight a box and press OK to type. Press Back to go back to Add-ons."
    layoutBlock(768)
end sub

' Trakt and Simkl before anything has been asked for. Nothing has been
' requested yet and nothing will be until this button is pressed.
sub drawSignedOut()
    setIntro(m.svc.intro)
    paintButton(0, "Sign in to " + m.svc.name, true, 192, 330)
    m.controls = [{ "kind": "start", "btn": 0 }]
    m.statusLabel.translation = [192, 440]
    m.hintLabel.text = "Press Back to go back to Add-ons."
    layoutBlock(560)
end sub

' The half-second between pressing Sign in and the code arriving. The Cancel
' button is built and in its final place on this frame, not when the answer
' lands — directional focus is decided by geometry, and a button that is not
' there yet sends the highlight somewhere else entirely.
sub drawGettingCode()
    setIntro(m.svc.intro)
    paintButton(0, "Cancel", false, 192, 330)
    m.controls = [{ "kind": "cancel", "btn": 0 }]
    m.statusLabel.translation = [192, 440]
    m.hintLabel.text = "Press Back to go back to Add-ons."
    layoutBlock(560)
end sub

' The code page. Everything the member needs is on it at once: where to go,
' what to type, the square that does both for them, and how long the code
' lasts.
sub drawCode()
    m.step1.visible = true
    m.step1.text = "On any phone or computer, go to:"
    m.codeUrl.visible = true
    m.codeUrl.text = m.codeShown
    m.step2.visible = true
    m.step2.text = "and enter this code:"

    m.codeBg.visible = true
    m.codeLabel.visible = true
    ' SIZED FROM THE CODE, on every bind. Trakt's codes are eight characters
    ' and the pairing screen's are six; spaced out for reading across a room
    ' that is fifteen glyphs against eleven, and one font size cannot serve
    ' both inside a 760px box. JetBrains Mono's advance is a flat 0.6em, so
    ' the widest size that fits N glyphs in 720px of the box is 1200/N.
    spaced = ToStr(m.codeSpaced)
    glyphs = spaced.len()
    if glyphs < 1 then glyphs = 1
    pts = Int(1200 / glyphs)
    if pts > 104 then pts = 104
    if pts < 44 then pts = 44
    m.codeLabel.font = UiBoldFont(pts)
    m.codeLabel.text = spaced

    m.expiryLabel.visible = true
    m.expiryLabel.text = m.expiryText

    drawQrSquare()

    paintButton(0, "Cancel", false, 192, 720)
    m.controls = [{ "kind": "cancel", "btn": 0 }]
    m.statusLabel.translation = [192, 606]
    m.hintLabel.text = "When you have finished on your phone, this page signs itself in. Press Cancel or Back to stop waiting."
    layoutBlock(812)
end sub

sub drawExpired()
    setIntro(m.svc.intro)
    ' STACKED, not side by side. Every control on every page of this screen
    ' is in one column, so Up and Down are the only keys that move the
    ' highlight and Left always means "go back" — the same as everywhere else
    ' in Settings. Two buttons laid out horizontally here would be the one
    ' place on the screen where Left meant something different, and
    ' directional focus on Roku is decided purely by geometry.
    paintButton(0, "Try again", true, 192, 430)
    paintButton(1, "Back to Add-ons", false, 192, 522)
    m.controls = [{ "kind": "start", "btn": 0 }, { "kind": "leave", "btn": 1 }]
    m.statusLabel.translation = [192, 300]
    m.hintLabel.text = "Press Back to go back to Add-ons."
    layoutBlock(626)
end sub

sub drawSignedIn()
    ' Trakt and Simkl get the eight-row page; OpenSubtitles keeps the one
    ' button it has always had. None of the switches below belong to it — it
    ' finds subtitles and tracks nothing.
    if IsTrackerId(m.svc.id)
        drawSignedInTracker()
        return
    end if

    setIntro(m.svc.introIn)

    m.acctLabel.visible = true
    ' Position set here as well as in the XML: the tracker page moves this
    ' line to y 210, and a field only set on the other branch would draw
    ' OpenSubtitles' account line wherever Trakt's had been.
    m.acctLabel.translation = [192, 300]
    m.acctLabel.text = signedInLine()

    quota = quotaLine()
    if quota <> ""
        m.quotaLabel.visible = true
        m.quotaLabel.translation = [192, 356]
        m.quotaLabel.text = quota
        ' Green while there is something left, the app's error red when
        ' today's allowance is gone — colour said as well as words, because
        ' the number itself is the thing being read from a sofa.
        if m.quotaGone
            m.quotaLabel.color = m.theme.errorColor
        else
            m.quotaLabel.color = m.theme.accentAlt
        end if
    end if

    paintButton(0, "Sign out", false, 192, 460)
    m.controls = [{ "kind": "signout", "btn": 0 }]
    m.statusLabel.translation = [192, 570]
    m.hintLabel.text = "Press Back to go back to Add-ons."
    layoutBlock(690)
end sub

' ---- The signed-in Trakt / Simkl page ---------------------------------------
'
' What Mason asked for on the v1.0.39 build: "there is no submenu for the sync
' times and show on home etc like android and windows". Android's Trakt and
' Simkl pages are the SAME page with two names — every label identical bar the
' service's name, the checkmark row and the sign-out line — so this is one page
' built twice and not two, and swapping the name is all that differs.
'
' THE ROWS ARE THE SETTINGS ROWS. Same SettingRow, same 1200 x 66, same focus
' ring, so a member arriving from Settings -> Playback -> Trakt does not land
' on a list that looks like a different app. What that costs is sub-labels:
' SettingRow has a label and a value and nothing else, and widening it would
' change every settings row and every overlay row in the app. Android's
' sub-labels are therefore printed ONE AT A TIME under the list, for whichever
' row the highlight is on — see `rowSub` in the XML.
'
' THE CAPTION "Keep up to date" is the sticky group line above the list, which
' is the same thing SettingsCategoryScreen does with its sections and is why it
' is not a row: a row a member can focus and press and that then does nothing
' is a trap on a remote. The three rows above it have no caption on Android
' either, so the line is simply empty while the highlight is on them.
'
' NOTHING HERE TALKS TO A SERVICE. Every row writes the registry and returns;
' the only row that would make a request is Sync now, and nothing in this build
' fetches these lists yet — see pressSyncNow, which says so in plain words
' rather than pretending it did something.

sub drawSignedInTracker()
    m.listMode = true

    m.acctLabel.visible = true
    ' Higher than OpenSubtitles' account line, to leave the list its 462px.
    m.acctLabel.translation = [192, 210]
    m.acctLabel.text = signedInLine()

    m.acctSub.visible = true
    ' Android's own sub-label on this line, and worth saying: this sign-in
    ' belongs to the television, not to whoever is watching, and it does not
    ' travel to the member's other devices.
    m.acctSub.text = "This device only"

    buildTrackerRows()

    content = CreateObject("roSGNode", "ContentNode")
    for each r in m.rows
        node = content.createChild("ContentNode")
        node.title = r.label
        node.description = r.value
    end for
    m.rowList.content = content
    m.rowList.visible = true

    m.sectionTitle.visible = true
    m.rowSub.visible = true
    paintRowLine(m.rowFocus)

    m.statusLabel.translation = [192, 878]
    ' The block covers the heading lines and the rows; the sub-label and the
    ' status line sit under it, the same way the footnote does on a Settings
    ' category. 330 + 7 rows x 66 + 16 = 808.
    layoutBlock(808)
    ' No hint line on this page. Back out of a list of settings rows is what
    ' every other settings screen in the app does without being told, and the
    ' rows themselves need the room.
    m.hintLabel.visible = false

    ' HAND THE KEYS OVER. Reaching this page from the code flow — the member
    ' finishes on their phone and handleMe redraws — arrives with the focus
    ' still on the screen itself, where Up, Down and OK now do nothing because
    ' onKeyEvent gives them to the list. Guarded on hasFocus so the first draw
    ' (before the parent has given this screen focus at all) does not take
    ' focus off whatever has it; the parent's own setFocus then arrives at
    ' onFocusIn and is forwarded from there.
    if m.top.hasFocus() then m.rowList.setFocus(true)
end sub

sub buildTrackerRows()
    m.rows = []
    m.rowSection = ""
    svcId = ToStr(m.svc.id)
    svcName = ToStr(m.svc.name)

    ' Android's labels and sub-labels, word for word, with the service's name
    ' swapped in. Defaults are all ON and live in Store.brs, not here.
    addTrackerRow("toggle", "scrobble", "Scrobble what I watch", onOffText(ScrobbleOn(svcId)), "Tells " + svcName + " what is playing, and how far through you are")
    addTrackerRow("toggle", "history", "Mark watched on " + svcName + " when I check it off here", onOffText(HistoryOn(svcId)), "And takes it off " + svcName + " again when you untick it")
    addTrackerRow("toggle", "watchlist_row", "Show my " + svcName + " watchlist on Home", onOffText(WatchlistRowOn(svcId)), "Only the titles your own playlists actually carry")

    m.rowSection = "KEEP UP TO DATE"
    addTrackerRow("toggle", "sync_on_start", "Sync at startup", onOffText(SyncOnStart(svcId)), "Checks " + svcName + " for changes each time the app opens")
    ' Three dots rather than the one-character ellipsis: every "..." in this
    ' app is written this way, and it keeps the source plain ASCII.
    '
    ' TWO WORDINGS FOR ONE SETTING, on purpose. The value column is 276px at 23
    ' mono and "Every 12 hours" does not fit it, so the column gets the short
    ' form and the sub-label under the list gets Android's full wording. A
    ' value that truncates on a television is worse than a shorter word.
    hours = SyncEveryHours(svcId)
    addTrackerRow("syncEvery", "", "Sync every...", TrackerHoursShortLabel(hours), TrackerHoursLabel(hours))
    addTrackerRow("syncNow", "", "Sync now", lastSyncStamp(), lastSyncLine())
    ' ALWAYS LAST, on both services.
    addTrackerRow("signout", "", "Sign out", "", ToStr(m.svc.signOutSub))
end sub

sub addTrackerRow(kind as string, leaf as string, label as string, value as string, subText as string)
    ' `subText` and not `sub`: "sub" is a BrightScript keyword and a map field
    ' called that does not fail politely.
    m.rows.push({ kind: kind, id: leaf, label: label, value: value, subText: subText, section: m.rowSection })
end sub

function onOffText(v as boolean) as string
    if v then return "ON"
    return "OFF"
end function

' The group line above the list and the explanation below it, both set on every
' move of the highlight and both set on BOTH branches — a line left holding the
' last row's words is the same smear a recycled card gets.
sub paintRowLine(idx as integer)
    if m.rows.count() = 0
        m.sectionTitle.text = ""
        m.rowSub.text = ""
        m.rowFocus = 0
        return
    end if
    i = idx
    if i < 0 then i = 0
    if i > m.rows.count() - 1 then i = m.rows.count() - 1
    m.rowFocus = i
    m.sectionTitle.text = m.rows[i].section
    m.rowSub.text = m.rows[i].subText
end sub

sub onRowFocused()
    if m.listMode <> true then return
    paintRowLine(m.rowList.itemFocused)
end sub

sub onRowSelected()
    if m.listMode <> true then return
    idx = m.rowList.itemSelected
    if idx < 0 or idx >= m.rows.count() then return
    r = m.rows[idx]
    if r.kind = "toggle"
        toggleTrackerPref(ToStr(r.id))
        rebuildRows(idx)
    else if r.kind = "syncEvery"
        m.syncEveryIdx = idx
        showSyncEveryPicker()
    else if r.kind = "syncNow"
        pressSyncNow()
    else if r.kind = "signout"
        askSignOut()
    end if
end sub

' One switch per press, written through Store.brs. The four are separate
' settings and none of them implies another — scrobbling on with checkmark
' filing off is a combination a member is allowed to want.
sub toggleTrackerPref(leaf as string)
    svcId = ToStr(m.svc.id)
    nowOn = false
    if leaf = "scrobble"
        nowOn = not ScrobbleOn(svcId)
        SetScrobbleOn(svcId, nowOn)
    else if leaf = "history"
        nowOn = not HistoryOn(svcId)
        SetHistoryOn(svcId, nowOn)
    else if leaf = "watchlist_row"
        nowOn = not WatchlistRowOn(svcId)
        SetWatchlistRowOn(svcId, nowOn)
    else if leaf = "sync_on_start"
        nowOn = not SyncOnStart(svcId)
        SetSyncOnStart(svcId, nowOn)
    else
        return
    end if
    ' A switch name and its position. No token, no member name — the same rule
    ' every other line in this file follows.
    KLog("addons", svcId + ": " + leaf + " " + onOffText(nowOn))
end sub

' Redraw and put the highlight back where it was. Straight out of
' SettingsCategoryScreen — a row that moves the cursor to the top every time it
' is pressed cannot be switched twice.
sub rebuildRows(idx as integer)
    redraw()
    if idx >= 0 and idx < m.rows.count() then m.rowList.jumpToItem = idx
    m.rowList.setFocus(true)
end sub

' ---- Sync every... -----------------------------------------------------------
' A list to pick from rather than a row that cycles, for the same reason the
' Media Bar numbers are: a member who wants twelve hours should not have to
' press a row five times to find out twelve was on offer.
'
' THE SIX CHOICES AND THE DEFAULT LIVE IN Store.brs (TrackerHourChoices /
' SyncEveryHours), so this page and whatever ends up scheduling the pull cannot
' come to different conclusions about what is set. THERE IS NO THIRTY MINUTES
' and there must not be one — the one-hour floor is Simkl's rule and this house
' has had a provider's access banned once already for asking too often.

sub showSyncEveryPicker()
    dlg = CreateObject("roSGNode", "Dialog")
    dlg.title = "Sync " + m.svc.name + " every..."
    dlg.message = "How often this TV checks " + m.svc.name + " for changes while the app is open."
    btns = []
    for each hours in TrackerHourChoices()
        btns.push(TrackerHoursLabel(hours))
    end for
    btns.push("Cancel")
    dlg.buttons = btns
    ' Open on the setting's CURRENT value, so the list says what it is now
    ' before it says what it could be.
    dlg.focusButton = syncEveryChoiceIndex(SyncEveryHours(m.svc.id))
    dlg.observeField("buttonSelected", "onSyncEveryPicked")
    m.top.getScene().dialog = dlg
end sub

function syncEveryChoiceIndex(current as integer) as integer
    ch = TrackerHourChoices()
    for i = 0 to ch.count() - 1
        if ch[i] = current then return i
    end for
    return 0
end function

sub onSyncEveryPicked()
    ' The scene is asked for rather than assumed: an answer that lands after
    ' this screen was taken away must change nothing, the same guard
    ' onCallResult and the Export Logs popup both use.
    scene = m.top.getScene()
    if scene = invalid then return
    dlg = scene.dialog
    if dlg = invalid then return
    choice = dlg.buttonSelected
    dlg.close = true
    opts = TrackerHourChoices()
    ' Cancel is the last button.
    if choice >= 0 and choice < opts.count()
        SetSyncEveryHours(m.svc.id, opts[choice])
        KLog("addons", ToStr(m.svc.id) + ": sync every " + ToStr(opts[choice]) + "h")
    end if
    rebuildRows(m.syncEveryIdx)
end sub

' ---- Sync now ----------------------------------------------------------------
'
' NOTHING IN THIS BUILD FETCHES THESE LISTS. The watchlist pull is somebody
' else's half and has not landed, so this row does not call anything, does not
' spin, and above all DOES NOT WRITE A LAST-SYNC STAMP — a row that says "Last
' synced 10:32" when nothing was synced is a lie the member cannot check. It
' says what is true instead, and the settings above it are stored and waiting.
'
' THE THIRTY-SECOND GUARD IS BUILT NOW rather than left for later, because it
' is the thing that protects the service's allowance and it is cheap: a held OK
' on a Roku remote repeats about every 400 ms, so one lean on this button is a
' burst of requests the moment a real pull is wired in. A press inside the
' window gives back the last summary and makes no call, exactly as Android's
' syncNow does.
sub pressSyncNow()
    svcId = ToStr(m.svc.id)
    atSecs = LastSyncAt(svcId)
    nowSecs = CreateObject("roDateTime").asSeconds()
    ' A clock that went backwards (a box that has just picked the time up off
    ' the network) is not a reason to refuse the press.
    if atSecs > 0 and nowSecs >= atSecs and (nowSecs - atSecs) < TrackerSyncNowCooldownSecs()
        words = LastSyncSummary(svcId)
        if words = "" then words = "Already up to date."
        setStatus(words, "")
        return
    end if
    ' ASK THE SHELL TO RUN ONE. This page cannot do the pull itself — the
    ' watchlist fetch, the catalogue match and the cache all live in
    ' AppShell's scheduler, which is the one node that outlives every screen.
    ' Its contract is a single global field:
    '
    '     m.global.addOnSyncRequest = "<service>|<nonce>"
    '
    ' THE NONCE IS LOAD-BEARING. A field made with addFields cannot be
    ' alwaysNotify, so writing the same string twice does not notify and the
    ' second press would do nothing at all. The clock changes every second,
    ' and the thirty-second guard above means two presses can never land
    ' inside the same one.
    '
    ' This line replaced a placeholder that said nothing was fetched on this
    ' TV yet. It was true for about a day and then read as a flat
    ' contradiction of the line above it, which by then said "Last synced
    ' 04:55 · 2 titles · 2 in your playlists".
    nonce = nowSecs.toStr()
    if m.global <> invalid and m.global.hasField("addOnSyncRequest")
        m.global.addOnSyncRequest = svcId + "|" + nonce
        setStatus("Checking " + m.svc.name + "...", "")
        return
    end if
    ' Only reachable in a build whose shell never created the field.
    setStatus("This TV cannot check " + m.svc.name + " right now. Try again after reopening the app.", "error")
end sub

' ---- When it last ran --------------------------------------------------------

' "10:32" when it was today, "14 Sep" and the clock when it was not, both read
' off THIS television's own clock. Android's formatSyncTime, same shapes.
function syncTimeParts(atSecs as integer) as object
    out = { clock: "", dayText: "", sameDay: false }
    if atSecs <= 0 then return out
    dt = CreateObject("roDateTime")
    dt.fromSeconds(atSecs)
    dt.toLocalTime()
    out.clock = twoDigits(dt.getHours()) + ":" + twoDigits(dt.getMinutes())
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    mIdx = dt.getMonth() - 1
    if mIdx < 0 or mIdx > 11 then mIdx = 0
    out.dayText = dt.getDayOfMonth().toStr() + " " + months[mIdx]
    today = CreateObject("roDateTime")
    today.toLocalTime()
    out.sameDay = (dt.getYear() = today.getYear() and dt.getMonth() = today.getMonth() and dt.getDayOfMonth() = today.getDayOfMonth())
    return out
end function

function twoDigits(n as integer) as string
    out = n.toStr()
    if n < 10 then out = "0" + out
    return out
end function

' The Sync now row's sub-label: "Never synced yet", "Last synced 10:32", or
' "Last synced 10:32 - 14 titles" with the service's own summary on the end.
function lastSyncLine() as string
    svcId = ToStr(m.svc.id)
    atSecs = LastSyncAt(svcId)
    if atSecs <= 0 then return "Never synced yet"
    parts = syncTimeParts(atSecs)
    if parts.sameDay
        out = "Last synced " + parts.clock
    else
        out = "Last synced " + parts.dayText + " " + parts.clock
    end if
    words = LastSyncSummary(svcId)
    if words <> "" then out = out + " " + Chr(183) + " " + words
    return out
end function

' The same thing in the six characters the value column can hold.
function lastSyncStamp() as string
    atSecs = LastSyncAt(ToStr(m.svc.id))
    if atSecs <= 0 then return "Never"
    parts = syncTimeParts(atSecs)
    if parts.sameDay then return parts.clock
    return parts.dayText
end function

sub setIntro(text as string)
    m.intro.visible = true
    m.intro.text = text
end sub

' The accent block behind the page, fitted to whatever this page drew. The
' hint line under it is deliberately OUTSIDE: it is an explanation printed
' under the group rather than part of it, the same call the Settings
' category screens make about their footnote.
sub layoutBlock(bottomY as integer)
    blockTop = 92
    m.wash.translation = [180, blockTop]
    m.wash.height = bottomY - blockTop
    m.rule.translation = [176, blockTop]
    m.rule.height = bottomY - blockTop
    m.hintLabel.translation = [192, bottomY + 24]
    m.hintLabel.visible = true
end sub

' Both slots, both ways, every time — position, width, fill AND ink, not
' just visibility. Answers the width it used so a caller can put the second
' button beside the first without guessing.
function paintButton(idx as integer, text as string, primary as boolean, x as integer, y as integer) as integer
    b = m.buttons[idx]
    ' 48px of padding plus 17px a character: JetBrains Mono Bold at 28pt is
    ' a flat 0.6em advance, i.e. 16.8px.
    w = 48 + text.len() * 17
    if w < 300 then w = 300
    if w > 640 then w = 640
    b.wrap.visible = true
    b.wrap.translation = [x, y]
    b.ring.width = w + 8
    b.ring.height = 80
    b.ring.color = m.theme.focusHighlight
    b.ring.visible = false
    b.bg.width = w
    b.bg.height = 72
    b.lbl.width = w
    b.lbl.height = 72
    b.lbl.text = text
    if primary
        b.bg.color = m.theme.accent
        ' The palette accent is a light frost blue, so white on it is 1.9:1
        ' and unreadable from a sofa. The page colour on the light fill is
        ' 6:1.
        b.lbl.color = m.theme.background
    else
        b.bg.color = m.theme.surfaceElevated
        b.lbl.color = m.theme.textPrimary
    end if
    return w
end function

sub paintStatus()
    if m.statusText = ""
        m.statusLabel.visible = false
        return
    end if
    m.statusLabel.visible = true
    m.statusLabel.text = m.statusText
    if m.statusKind = "error"
        m.statusLabel.color = m.theme.errorColor
    else if m.statusKind = "good"
        m.statusLabel.color = m.theme.accentAlt
    else
        m.statusLabel.color = m.theme.textSecondary
    end if
end sub

' The focus ring, on every control, both ways. A one-step lift in grey is
' invisible from ten feet; what marks focus here is the theme's yellow ring,
' the same one every other screen in the app uses.
sub paintFocus()
    if m.controls.count() = 0 then return
    if m.focus < 0 then m.focus = 0
    if m.focus > m.controls.count() - 1 then m.focus = m.controls.count() - 1
    m.fieldUser.focused = false
    m.fieldPass.focused = false
    for each b in m.buttons
        b.ring.visible = false
    end for
    c = m.controls[m.focus]
    if c.kind = "user"
        m.fieldUser.focused = true
    else if c.kind = "pass"
        m.fieldPass.focused = true
    else if c.doesExist("btn")
        m.buttons[c.btn].ring.visible = true
    end if
end sub

sub setStatus(text as string, kind as string)
    m.statusText = text
    m.statusKind = kind
    paintStatus()
end sub

' ---- The QR square ----------------------------------------------------------
'
' The square carries the service's own sign-in page WITH THE CODE ALREADY IN
' IT, so a phone that scans it lands where the member can type their own
' username and password — on the service's site, never here. The links are
' built by AddOns.brs and both come to about 30 bytes, inside the version 3-M
' encoder's 42. TMDB's approve link is about 95 and does not fit, which is
' why TMDB is not in this build.
'
' The encode itself is a few hundred thousand small steps, so it happens on
' QrEncodeTask and not on the thread that has 250 ms to answer the remote.

sub startQrFor(userCode as string)
    stopQr()
    addr = ""
    if m.svc.id = "trakt"
        addr = TraktActivateUrl(userCode)
    else if m.svc.id = "simkl"
        addr = SimklPinUrl(userCode)
    end if
    if addr = "" then return
    t = CreateObject("roSGNode", "QrEncodeTask")
    if t = invalid then return
    t.text = addr
    t.observeField("rows", "onQrRows")
    m.qrTask = t
    t.control = "RUN"
end sub

sub onQrRows(event as object)
    if m.qrTask = invalid then return
    m.qrTask = invalid
    if m.top.getScene() = invalid then return
    m.qrRows = event.getData()
    if m.stage = "code" then drawQrSquare()
end sub

' Painted from whatever rows are in hand — none until the encoder answers,
' and none at all if the address would not fit. Both ways, every time: the
' plate, the caption and the grid go off together, so a square from a code
' that has been cancelled can never sit under a code that replaced it.
sub drawQrSquare()
    hasQr = DrawQrModules(m.qrGrid, m.qrRows, 12)
    m.qrGrid.visible = hasQr
    m.qrPlate.visible = hasQr
    m.qrCaption.visible = hasQr
    if hasQr
        m.qrCaption.text = "Or scan this square with a phone camera - it opens the page with your code already filled in."
    else
        m.qrCaption.text = ""
    end if
end sub

sub stopQr()
    m.qrRows = invalid
    if m.qrTask = invalid then return
    m.qrTask.unobserveField("rows")
    m.qrTask.control = "STOP"
    m.qrTask = invalid
end sub

' ---- Talking to the relay ---------------------------------------------------
'
' One request at a time, always through Nia's AddOnTask, which is the only
' thing in this app that speaks to the add-on relays. Nothing here opens a
' connection itself.

' `svcId` is left empty on every call but `me`, and that is deliberate.
' AddOnTask renews a refused Trakt sign-in only when it is told which service
' the request belongs to, and only two of the calls below should ever set that
' off. The sign-in calls (`login`, `start`, `poll`) go out with no token at
' all, so a refusal there is a failed sign-in, not an expired one. `signout`
' is the pointed one: doSignOut clears the account on this thread the moment
' after firing it, so a renewal racing that would be this app arguing with a
' member who has just pressed Sign out.
sub startCall(tag as string, addr as string, verb as string, body as dynamic, bearer as string, svcId = "" as string)
    stopCall()
    t = CreateObject("roSGNode", "AddOnTask")
    if t = invalid
        ' Only reachable in a build that is missing the task component.
        ' Saying so plainly beats a screen that sits there doing nothing.
        setStatus("This part of the app isn't ready in this build yet.", "error")
        KLog("addons", "AddOnTask is missing - " + tag + " not sent")
        return
    end if
    t.url = addr
    t.method = verb
    if body <> invalid then t.bodyJson = FormatJson(body)
    if bearer <> "" then t.bearer = bearer
    t.timeoutMs = 15000
    t.tag = tag
    if svcId <> "" then t.service = svcId
    t.observeField("result", "onCallResult")
    m.task = t
    t.control = "RUN"
end sub

sub stopCall()
    if m.task = invalid then return
    m.task.unobserveField("result")
    m.task.control = "STOP"
    m.task = invalid
end sub

sub onCallResult(event as object)
    if m.task = invalid then return
    tag = ToStr(m.task.tag)
    m.task = invalid
    ' An answer that lands after this screen was taken away changes nothing.
    if m.top.getScene() = invalid then return
    res = event.getData()
    if tag = "login"
        handleLogin(res)
    else if tag = "start"
        handleCodeArrived(res)
    else if tag = "poll"
        handlePoll(res)
    else if tag = "me"
        handleMe(res)
    else if tag = "signout"
        ' Best effort and nothing waits on it — the account was already
        ' cleared on this box before the request went out.
        KLog("addons", m.svc.id + ": sign-out request answered")
    end if
end sub

' The relay always says what went wrong in words a member can read;
' AddOnErrorText turns the machine code into a sentence when it does not.
' NO MACHINE CODES EVER REACH THE SCREEN.
function callFailedText(res as dynamic) as string
    kind = ToStr(GetField(res, "errorCode"))
    words = ToStr(GetField(res, "error"))
    data = GetField(res, "data")
    if kind = "" then kind = ToStr(GetField(data, "error"))
    if words = "" then words = ToStr(GetField(data, "message"))
    if kind = "" and words = ""
        return "Couldn't reach " + m.svc.name + " right now. Check the Roku's internet connection, then try again."
    end if
    return AddOnErrorText(kind, words, m.svc.name)
end function

' ---- OpenSubtitles: username and password -----------------------------------

sub beginLogin()
    user = m.values["username"].trim()
    pass = m.values["password"]
    if user = "" or pass = ""
        setStatus("Fill in both boxes, then press Sign in.", "error")
        return
    end if
    m.stage = "busy"
    m.focus = 0
    setStatus("Signing in to " + m.svc.name + "...", "")
    redraw()
    ' The password is on the wire to our own relay and nowhere else, and it
    ' is never written to a log: KLog says the action, never the values.
    startCall("login", m.svc.startUrl, "POST", { "username": user, "password": pass }, "")
end sub

sub handleLogin(res as dynamic)
    if res = invalid or GetField(res, "ok") <> true
        m.stage = "form"
        m.focus = 0
        redraw()
        setStatus(callFailedText(res), "error")
        return
    end if
    data = GetField(res, "data")
    token = ToStr(GetField(data, "token"))
    if token = ""
        m.stage = "form"
        m.focus = 0
        redraw()
        setStatus("That sign-in didn't come back with everything it needed. Try again in a moment.", "error")
        return
    end if

    who = GetField(data, "user")
    ' Lower-case keys, written as quoted strings on both sides. A map that
    ' goes through the registry comes back CASE-SENSITIVE while a field
    ' written as code folds to lower case, and a `resetUtc` written one way
    ' and read the other never matches. This has bitten the app four times.
    extra = {
        "level": ToStr(GetField(who, "level")),
        "vip": (GetField(who, "vip") = true),
        "allowed": ToInt(GetField(who, "allowed_downloads")),
        "reset_utc": ToStr(GetField(who, "reset_utc")),
        "base_url": ToStr(GetField(data, "base_url"))
    }
    ' `remaining` IS DELIBERATELY ABSENT UNTIL A DOWNLOAD ANSWERS WITH ONE,
    ' and this key is only written when the relay sent a real number. The
    ' relay sends null at sign-in on purpose — OpenSubtitles does not say how
    ' much of today's allowance is left until the first download — and
    ' ToInt(invalid) is 0, so writing it unconditionally told a member who had
    ' just signed in "0 of 1000 downloads left today", in red, and set
    ' m.quotaGone. Seen on the office stick 2026-09-19 on a VIP account that
    ' had spent nothing. Absent means "not known yet" and quotaLine says so.
    if GetField(who, "remaining") <> invalid
        extra["remaining"] = ToInt(GetField(who, "remaining"))
    end if
    storeAccount(token, "", ToStr(GetField(who, "name")), extra)
    ' Gone from memory the moment it has been used.
    m.values["password"] = ""
    m.values["username"] = ""
    m.stage = "signedin"
    m.focus = 0
    redraw()
    setStatus("", "")
end sub

' ---- Trakt and Simkl: a code and a square -----------------------------------

sub beginCode()
    m.stage = "busy"
    m.focus = 0
    m.userCode = ""
    m.deviceCode = ""
    m.codeSpaced = ""
    m.codeShown = ""
    m.expiryText = ""
    m.pollFails = 0
    stopQr()
    setStatus("Getting your code...", "")
    redraw()
    startCall("start", m.svc.startUrl, "POST", {}, "")
end sub

sub handleCodeArrived(res as dynamic)
    if res = invalid or GetField(res, "ok") <> true
        m.stage = "expired"
        m.focus = 0
        redraw()
        setStatus(callFailedText(res), "error")
        return
    end if
    data = GetField(res, "data")
    m.userCode = ToStr(GetField(data, "user_code"))
    ' TRAKT HANDS BACK A SEPARATE DEVICE CODE TO POLL WITH. SIMKL DOES NOT —
    ' it is polled with the very code the member types, and this is asked
    ' service by service rather than by falling back on an empty field.
    '
    ' Mason, 2026-09-17, signing in to Simkl on the office stick: "Simkl is
    ' saying the code could not be read when i enter it". Those words were
    ' OURS, not Simkl's. Simkl answers `a=pin` with
    ' `"device_code": "DEVICE_CODE"` — a literal placeholder, not a code and
    ' not empty — so the old "empty means use the user code" fallback never
    ' fired, every poll went out carrying the text DEVICE_CODE, and the relay
    ' refused it on shape (it allows letters and digits only, and that string
    ' has an underscore) with exactly the message he read. It could never
    ' have signed anyone in, however carefully they typed.
    if m.svc.id = "simkl"
        m.deviceCode = m.userCode
    else
        m.deviceCode = ToStr(GetField(data, "device_code"))
        if m.deviceCode = "" then m.deviceCode = m.userCode
    end if
    if m.userCode = ""
        m.stage = "expired"
        m.focus = 0
        redraw()
        setStatus("That didn't come back with a code. Try again in a moment.", "error")
        return
    end if

    m.codeSpaced = spacedOut(m.userCode)
    ' What the relay says the member should go to, in the service's own
    ' words. Only falls back to a name written here if the relay left it out.
    m.codeShown = tidyUrl(ToStr(GetField(data, "verification_url")))
    if m.codeShown = "" then m.codeShown = m.svc.fallbackUrl

    ' NEVER FASTER THAN THE RELAY ASKED FOR. A five-second floor guards
    ' against a relay answering 0 or 1, which would be a request a second
    ' against Simkl's 1,000-a-day allowance for the whole membership.
    secs = ToInt(GetField(data, "interval"))
    if secs < 5 then secs = m.svc.interval
    if secs < 5 then secs = 5
    m.pollSecs = secs

    lifeSecs = ToInt(GetField(data, "expires_in"))
    if lifeSecs <= 0 then lifeSecs = 600
    m.expiresAt = CreateObject("roDateTime").asSeconds() + lifeSecs
    m.expiryText = "This code works for another " + mmss(lifeSecs)

    m.stage = "code"
    m.focus = 0
    m.polling = true
    m.pollFails = 0
    redraw()
    setStatus("Waiting for you to finish on your phone...", "")

    ' The square is drawn when the encoder answers; the code and the address
    ' are already readable, so a slow encode costs nothing.
    startQrFor(m.userCode)

    m.tickTimer.control = "start"
    schedulePoll(m.pollSecs)
end sub

sub schedulePoll(secs as integer)
    if not m.polling then return
    m.pollTimer.control = "stop"
    m.pollTimer.duration = secs
    m.pollTimer.control = "start"
end sub

sub onPollTimer()
    ' Belt and braces: a host that threw this screen away without clearing
    ' anything takes the polling with it rather than leaving it running for
    ' the life of the app.
    if m.top.getScene() = invalid
        stopWaiting()
        return
    end if
    if not m.polling then return
    body = {}
    if m.svc.id = "simkl"
        body = { "user_code": m.deviceCode }
    else
        body = { "device_code": m.deviceCode }
    end if
    startCall("poll", m.svc.pollUrl, "POST", body, "")
end sub

sub handlePoll(res as dynamic)
    if not m.polling then return
    status = ToInt(GetField(res, "status"))
    data = GetField(res, "data")

    if status = 200
        token = ToStr(GetField(data, "access_token"))
        if token <> ""
            finishCodeSignIn(token, ToStr(GetField(data, "refresh_token")))
            return
        end if
        ' A 200 with nothing in it is not a sign-in. Treat it as "still
        ' waiting" rather than storing an empty token.
        schedulePoll(m.pollSecs)
        return
    end if

    if status = 202
        ' Still waiting for the member. Simkl's relay may add its own words
        ' about a code that has been refused; when it does, stop early
        ' rather than polling out the full ten minutes for nothing.
        detail = LCase(ToStr(GetField(data, "detail")))
        if detail <> "" and (Instr(1, detail, "expire") > 0 or Instr(1, detail, "denied") > 0)
            codeDied("That code is no longer good. Get a new one and try again.")
            return
        end if
        m.pollFails = 0
        schedulePoll(m.pollSecs)
        return
    end if

    if status = 410
        codeDied("That code ran out before it was used. Get a new one and try again.")
        return
    end if

    if status = 409
        codeDied("That sign-in was turned down on " + m.svc.name + ". Try again if that wasn't you.")
        return
    end if

    if status = 429
        ' The relay is asking us to slow down, which is not a failure. Take
        ' the interval it offers, or back off to double what we were using,
        ' and never count it against the retries.
        secs = ToInt(GetField(data, "interval"))
        if secs < m.pollSecs then secs = m.pollSecs * 2
        if secs > 60 then secs = 60
        m.pollSecs = secs
        schedulePoll(secs)
        return
    end if

    ' Anything else is a hiccup. Three in a row is a real problem worth
    ' saying out loud; one is not worth frightening anybody with.
    m.pollFails = m.pollFails + 1
    if m.pollFails >= 3
        stopWaiting()
        m.stage = "expired"
        m.focus = 0
        redraw()
        setStatus(callFailedText(res), "error")
        return
    end if
    schedulePoll(m.pollSecs)
end sub

sub codeDied(words as string)
    stopWaiting()
    m.stage = "expired"
    m.focus = 0
    redraw()
    setStatus(words, "error")
end sub

' The member has finished on their phone.
'
' STORED THE MOMENT THE TOKEN LANDS, before anything else is asked. The token
' IS the sign-in; the member's name is a nicety printed on top of it. Doing
' it the other way round — hold the token, look the name up, store both —
' means a Cancel, a Back or a service that does not answer throws away a
' sign-in the member has already finished on their phone, and they have to do
' the whole thing again. Nothing here is allowed to cost them that.
sub finishCodeSignIn(token as string, refreshToken as string)
    stopWaiting()
    storeAccount(token, refreshToken, "", {})
    m.pendingToken = token
    m.pendingRefresh = refreshToken
    m.stage = "signedin"
    m.focus = 0
    redraw()
    setStatus("Signed in. Getting your account details...", "good")
    startCall("me", m.svc.meUrl, "GET", invalid, token, ToStr(m.svc.id))
end sub

' The name, arriving after the fact. The account is already saved, so this
' only ever adds to it — and a failure here leaves the member signed in, with
' the page saying so plainly rather than looking half-finished.
sub handleMe(res as dynamic)
    token = ToStr(m.pendingToken)
    refreshTok = ToStr(m.pendingRefresh)
    m.pendingToken = ""
    m.pendingRefresh = ""
    if token = "" then return

    if res = invalid or GetField(res, "ok") <> true
        setStatus("Signed in. " + m.svc.name + " didn't send your name back this time.", "good")
        return
    end if

    data = GetField(res, "data")
    nm = ToStr(GetField(data, "username"))
    if nm = "" then nm = ToStr(GetField(data, "name"))
    extra = {
        "vip": (GetField(data, "vip") = true),
        "slug": ToStr(GetField(data, "slug")),
        "account_type": ToStr(GetField(data, "account_type"))
    }
    storeAccount(token, refreshTok, nm, extra)
    m.stage = "signedin"
    m.focus = 0
    redraw()
    setStatus("", "")
end sub

' ---- Storing the account ----------------------------------------------------

sub storeAccount(token as string, refreshToken as string, nm as string, extra as object)
    acct = {
        "signedIn": true,
        "token": token,
        "refresh": refreshToken,
        "name": nm,
        "extra": extra,
        "since": CreateObject("roDateTime").asSeconds()
    }
    SaveAddOnAccount(m.svc.id, acct)
    m.acct = AddOnAccount(m.svc.id)
    ' The service and the fact, never the token and never the name.
    KLog("addons", m.svc.id + ": signed in")
end sub

' ---- Signing out ------------------------------------------------------------
'
' MASON'S RULING, through Fred on JB-7, after he signed out of Simkl by
' accident: "all the addons need a confirm before logout button". So every
' one of the three asks first, with Cancel focused, and a held OK cannot
' answer the question — see SignOutConfirmDialog.

sub askSignOut()
    if m.confirmDialog <> invalid then return
    dlg = m.top.createChild("SignOutConfirmDialog")
    if dlg = invalid then return
    dlg.title = "Sign out of " + m.svc.name + "?"
    dlg.message = m.svc.signOutWhy
    dlg.confirmText = "Sign out"
    dlg.cancelText = "Cancel"
    dlg.observeField("choice", "onSignOutChoice")
    m.confirmDialog = dlg
    dlg.setFocus(true)
end sub

sub onSignOutChoice(event as object)
    kind = ToStr(event.getData())
    if kind = "" then return
    closeConfirm()
    if kind <> "confirm" then return
    doSignOut()
end sub

sub closeConfirm()
    if m.confirmDialog = invalid then return
    m.confirmDialog.unobserveField("choice")
    m.top.removeChild(m.confirmDialog)
    m.confirmDialog = invalid
    m.top.setFocus(true)
end sub

sub doSignOut()
    token = ""
    if m.acct <> invalid then token = ToStr(GetField(m.acct, "token"))
    addr = ToStr(m.svc.revokeUrl)

    ' Told to the service FIRST, while we still have the token to say it
    ' with. Trakt has a revoke and OpenSubtitles has a logout; Simkl has
    ' neither, which is why its dialog says so in plain words instead.
    if addr <> "" and token <> ""
        startCall("signout", addr, "POST", {}, token)
    end if

    ' Then cleared here, whatever the service says back. A revoke that
    ' cannot get through must never leave a member stuck signed in on their
    ' own television.
    '
    ' ONE SUB DOES IT, and that is the point of it being one sub. It clears the
    ' account AND the seven switches that govern that sign-in — this service's
    ' only, because signing out of Trakt must not touch Simkl's, and leaving
    ' them behind would mean the next person to sign in on this television
    ' inherits somebody else's scrobbling switch and somebody else's "last
    ' synced" line (unlike the account settings, none of it comes back from
    ' KwickSync, because none of it is on the wire). AddOnAuth.brs calls the
    ' same sub when a Trakt sign-in cannot be renewed, so a sign-in that ran
    ' out leaves this box in exactly the state this button does.
    SignOutAddOnAccount(m.svc.id, "signed out on this TV")
    m.acct = invalid
    m.values = { "username": "", "password": "" }

    if m.svc.flow = "password"
        m.stage = "form"
    else
        m.stage = "signedout"
    end if
    m.focus = 0
    redraw()
    ' THE KEYS COME BACK. Signing out of Trakt or Simkl leaves the row list
    ' hidden but still holding focus — closeConfirm handed focus to this screen
    ' while the list was still up, and onFocusIn forwarded it straight into the
    ' list. Without this line the member is left on a page whose buttons answer
    ' nothing but Back.
    if m.listMode <> true then m.top.setFocus(true)
    if m.svc.id = "simkl"
        setStatus("Signed out on this TV. Simkl has no way for an app to sign itself out, so remove Kwick Player under your Simkl settings if you want it gone there too.", "")
    else
        setStatus("Signed out of " + m.svc.name + " on this TV.", "")
    end if
end sub

' ---- The keyboard -----------------------------------------------------------
'
' Certification 4.12: "Apps must use Roku voice keyboards for email, PIN, and
' password entry." Every box on this screen goes through
' StandardKeyboardDialog, which is the voice keyboard, exactly as the KwickTV
' sign-in on OnboardScreen does.

sub openKeyboard(key as string)
    kb = CreateObject("roSGNode", "StandardKeyboardDialog")
    if kb = invalid then return
    isSecret = (key = "password")
    if isSecret
        kb.title = "Password"
    else
        kb.title = "Username"
    end if
    kb.text = m.values[key]
    kb.buttons = ["OK", "Cancel"]
    ' "password" and "email" are spelled out letter by letter by the voice
    ' keyboard, which is the only way a spoken password can land right.
    if isSecret
        kb.keyboardDomain = "password"
    else
        kb.keyboardDomain = "alphanumeric"
    end if

    edit = kb.textEditBox
    ' keyboardDomain is documented as something the keyboard "may" act on;
    ' the microphone and the dictation style are not worth leaving to a
    ' "may", so they are set on the box as well.
    edit.voiceEnabled = true
    edit.voiceEntryType = kb.keyboardDomain
    ' Roku's boxes default to 15 characters, which would silently cut a long
    ' username in half.
    edit.maxTextLength = 128
    ' Covered while it is typed, exactly as the row behind the dialog shows
    ' it.
    if isSecret then edit.secureMode = true

    m.kbKey = key
    m.kbDialog = kb
    kb.observeField("buttonSelected", "onKeyboardButton")
    kb.observeField("wasClosed", "onKeyboardClosed")
    m.top.getScene().dialog = kb
end sub

sub onKeyboardButton()
    kb = m.kbDialog
    if kb = invalid then return
    if kb.buttonSelected = 0 then m.values[m.kbKey] = StdKeyboardText(kb)
    kb.close = true
end sub

' Back closes the keyboard without going through a button, so focus has to
' come back here rather than in the OK branch — otherwise backing out of a
' keyboard leaves a screen that answers nothing.
sub onKeyboardClosed()
    m.kbDialog = invalid
    m.kbKey = ""
    m.top.setFocus(true)
    redraw()
end sub

' ---- Keys -------------------------------------------------------------------

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    ' The confirm dialog is a child of this screen and swallows every key
    ' while it is up. This is the second lock on the same door.
    if m.confirmDialog <> invalid then return true
    if m.kbDialog <> invalid then return false

    if key = "back" or key = "left"
        closeScreen()
        return true
    end if

    ' On the Trakt / Simkl page the row list owns Up, Down and OK: it holds
    ' focus, so those three never reach here at all — a MarkupList swallows
    ' them and moves its own highlight. Back and Left are handled above
    ' because a vertical list does not take those and they bubble up, which is
    ' exactly how SettingsCategoryScreen backs out of its own list. This is
    ' the second lock on the same door: handling them here as well would move
    ' the cursor twice on any box where they did arrive.
    if m.listMode = true then return false

    if key = "up"
        moveFocus(-1)
        return true
    else if key = "down"
        moveFocus(1)
        return true
    else if key = "OK"
        pressCurrent()
        return true
    end if
    return false
end function

sub moveFocus(by as integer)
    if m.controls.count() < 2 then return
    idx = m.focus + by
    if idx < 0 then idx = 0
    if idx > m.controls.count() - 1 then idx = m.controls.count() - 1
    if idx = m.focus then return
    m.focus = idx
    paintFocus()
end sub

sub pressCurrent()
    if m.controls.count() = 0 then return
    c = m.controls[m.focus]
    kind = ToStr(c.kind)
    if kind = "user"
        openKeyboard("username")
    else if kind = "pass"
        openKeyboard("password")
    else if kind = "signin"
        beginLogin()
    else if kind = "start"
        beginCode()
    else if kind = "signout"
        askSignOut()
    else if kind = "leave"
        closeScreen()
    else if kind = "cancel"
        cancelBack()
    end if
end sub

' Cancel from any waiting page: stop everything in the air and go back to
' the page this add-on starts on.
sub cancelBack()
    stopWaiting()
    if m.svc.flow = "password"
        m.stage = "form"
    else
        m.stage = "signedout"
    end if
    m.focus = 0
    redraw()
    setStatus("", "")
end sub

' ---- Stopping ---------------------------------------------------------------
'
' The one place polling dies, and everything that can end a wait goes through
' it: Cancel, Back, a sign-in landing, a code running out, and a timer that
' notices the screen is no longer on a scene.

sub stopWaiting()
    m.polling = false
    m.pollTimer.control = "stop"
    m.tickTimer.control = "stop"
    m.pollFails = 0
    m.deviceCode = ""
    m.expiresAt = 0
    stopCall()
    stopQr()
end sub

' Leaving takes everything with it: no timer left ticking, no request left in
' the air, and nothing still asking the relay in the background.
sub closeScreen()
    closeConfirm()
    stopWaiting()
    m.values = { "username": "", "password": "" }
    m.top.closed = true
end sub

' ---- The code's own clock ---------------------------------------------------

sub onTick()
    if m.top.getScene() = invalid
        stopWaiting()
        return
    end if
    if m.stage <> "code" then return
    if m.expiresAt <= 0 then return
    remaining = m.expiresAt - CreateObject("roDateTime").asSeconds()
    if remaining <= 0
        ' Never leave somebody staring at a code that stopped working, and
        ' never keep asking the relay about one.
        codeDied("That code ran out. Press Try again for a new one.")
        return
    end if
    m.expiryText = "This code works for another " + mmss(remaining)
    m.expiryLabel.text = m.expiryText
end sub

' ---- Words and numbers ------------------------------------------------------

function signedInLine() as string
    nm = ""
    if m.acct <> invalid then nm = ToStr(GetField(m.acct, "name")).trim()
    ' Plain "Signed in" while the name is still on its way, or when the
    ' service never sent one. Never a stand-in like "your account", which
    ' reads as a bug.
    if nm = ""
        out = "Signed in"
    else
        out = "Signed in as " + nm
    end if

    extra = invalid
    if m.acct <> invalid then extra = GetField(m.acct, "extra")
    ' The service's own word for the membership, when it sent one — Mason
    ' asked for the VIP level to show, and the level is the service's
    ' wording, not ours.
    level = ToStr(GetField(extra, "level")).trim()
    if level = "" then level = capitalise(ToStr(GetField(extra, "account_type")).trim())
    if level <> ""
        out = out + " " + Chr(183) + " " + level
    else if GetField(extra, "vip") = true
        out = out + " " + Chr(183) + " VIP"
    end if
    return out
end function

' "999 of 1000 downloads left today - resets 18:59", and empty on a service
' that has no allowance to report. Sets m.quotaGone so the colour can say the
' same thing the words do.
function quotaLine() as string
    m.quotaGone = false
    if m.acct = invalid then return ""
    extra = GetField(m.acct, "extra")
    ' doesExist() only exists on an associative array, so the type is checked
    ' before it is asked: a stored account that came back as something else
    ' must leave this line blank, not kill the render thread.
    if type(extra) <> "roAssociativeArray" then return ""
    allowed = ToInt(GetField(extra, "allowed"))
    ' NOT KNOWN YET, which is the ordinary state of a member who has just
    ' signed in: the service only reports what is left once a download has
    ' answered. The allowance is still worth saying, and it is not a warning.
    ' `rem_src` is what separates a real count from the 0 that builds before
    ' 2026-09-19 wrote at sign-in — see UpdateAddOnQuota for why it exists.
    known = extra.doesExist("remaining") and ToStr(GetField(extra, "rem_src")) = "dl"
    if not known
        if allowed <= 0 then return ""
        return allowed.toStr() + " downloads a day on this account"
    end if
    remaining = ToInt(GetField(extra, "remaining"))
    m.quotaGone = (remaining <= 0)

    out = remaining.toStr()
    if allowed > 0 then out = out + " of " + allowed.toStr()
    out = out + " downloads left today"
    at = localHhMm(ToStr(GetField(extra, "reset_utc")))
    if at <> "" then out = out + " " + Chr(183) + " resets " + at
    return out
end function

' An ISO-8601 UTC time as this television's own clock reads it. Empty when
' the string did not parse — a made-up "00:00" on a member's screen is worse
' than no time at all.
function localHhMm(iso as string) as string
    if iso.trim() = "" then return ""
    dt = CreateObject("roDateTime")
    dt.fromISO8601String(iso)
    if dt.asSeconds() < 1000000 then return ""
    dt.toLocalTime()
    hh = dt.getHours()
    mm = dt.getMinutes()
    out = hh.toStr()
    if hh < 10 then out = "0" + out
    tail = mm.toStr()
    if mm < 10 then tail = "0" + tail
    return out + ":" + tail
end function

' Spaced out, because a run of characters at this size is easy to misread
' across a room.
function spacedOut(text as string) as string
    out = ""
    for i = 0 to text.len() - 1
        if i > 0 then out = out + " "
        out = out + text.mid(i, 1)
    end for
    return out
end function

' The address as a member would write it down: no scheme, no trailing slash.
' What they are told to type has to match what is printed on the service's
' own page.
function tidyUrl(addr as string) as string
    out = addr.trim()
    if out = "" then return ""
    if LCase(Left(out, 8)) = "https://" then out = Mid(out, 9)
    if LCase(Left(out, 7)) = "http://" then out = Mid(out, 8)
    if out <> "" and Right(out, 1) = "/" then out = Left(out, out.len() - 1)
    return out
end function

function mmss(secs as integer) as string
    mins = Int(secs / 60)
    rest = secs - mins * 60
    tail = rest.toStr()
    if rest < 10 then tail = "0" + tail
    return mins.toStr() + ":" + tail
end function

function capitalise(text as string) as string
    if text = "" then return ""
    return UCase(Left(text, 1)) + Mid(text, 2)
end function
