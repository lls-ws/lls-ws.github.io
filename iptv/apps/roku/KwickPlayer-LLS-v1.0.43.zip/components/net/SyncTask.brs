' KwickSync engine — one full reconcile/push/pull/apply cycle, off the render
' thread. A direct port of the Android SyncService protocol (sync_service.dart):
' compares the real per-profile stores to a local mirror, pushes local
' changes to the locker, and projects the server's change-feed back into the
' stores. Gated on a KwickTV login + the per-device toggle.
'
' Kinds synced: profile, favvod, favlist, favch, hist, pset, seen, srccol,
' favmedia, medhist.
'
' Four of those are not symmetrical, and deliberately:
'   seen      finished marks. Read in full; WRITTEN only for marks this box
'             holds and only DELETED on an explicit "mark as unwatched" from
'             the member. It never says a mark is gone just because it no
'             longer has it — see collectSeenPuts and the unmark queue in
'             Store.brs.
'   srccol    the colour the member painted a source. Read only. There is no
'             picker on this box, so it has nothing to say about them.
'   favmedia  favourited films and shows on a member's OWN media server.
'             READ ONLY — this box says nothing about them.
'   medhist   watch progress on one. Read in full; WRITTEN, from this build,
'             for titles watched HERE on a server that is actually on this box
'             — and, like "seen", collected OUTSIDE the snapshot so it can only
'             ever add or update. It never says a resume point is gone. See
'             collectMedHistPuts.
'             Both kinds are kept only for a server that is actually on this
'             box. See the block above IsKnownSyncKind for the registry rule
'             that gates them.

sub init()
    m.top.functionName = "runSync"
    m.syncUrl = KwickBranding().syncApiUrl
end sub

sub runSync()
    st = { phase: "done", lastAt: SyncLastAt(), message: "" }

    if not SyncEnabled()
        st.phase = "off"
        m.top.result = st
        return
    end if
    creds = KwickTvProvider()
    if creds = invalid
        st.phase = "gated"
        m.top.result = st
        return
    end if

    ' ONE cycle at a time, across every caller. The claim lives here rather
    ' than at the call sites because there are four of them (AppShell's 90s
    ' timer, Settings' "Sync now", AppScene's profile fetch, Settings' sign-out
    ' push) and each could only ever see its own task node — so none of them
    ' could tell another was already running. Claiming inside runSync covers
    ' all four, and every caller added later, without them knowing about it.
    '
    ' Deliberately AFTER the two gates above: neither reads or writes the
    ' mirror, so a cycle that is switched off or not signed in has nothing to
    ' protect and must not hold the slot while it says so.
    '
    ' A refusal is silent by design — no error, no alert. The result still gets
    ' set, because Settings' "Sync now" sits on "Syncing…" until it arrives;
    ' phase "busy" falls through syncStatusLine() to the ordinary "Last synced
    ' X ago", which is the truth. The next 90s tick does the work.
    if not SyncClaimSlot()
        KLog("sync", "a cycle is already running - skipping this one")
        st.phase = "busy"
        m.top.result = st
        return
    end if

    host = HostOf(ToStr(creds.server))
    mirror = LoadSyncMirror()
    m.unknownDropped = 0
    m.unknownKinds = {}
    m.foreignMediaDropped = 0
    sweepUnknownKindRows(mirror)
    sweepMediaRowsOffHistWire(mirror)
    sweepRetiredSrcRows(mirror)
    restoreLoopCasualties(mirror)
    replayHistFromMirror(mirror)
    replaySeenFromMirror(mirror)
    replayMediaFromMirror(mirror)
    replayPendingPset(mirror)
    purgeLegacyVodRows(mirror)
    normalizeStoredLists()
    healFavVodArt(mirror)
    ' Put the source colours already on this box in front of the cards before
    ' anything is asked of the network. The map that matters is rebuilt from
    ' the mirror at the far end of the cycle, but that end is only reached when
    ' the push and the pull both succeed — and a member on a dead connection
    ' should still see the colours they painted last week, not have their tags
    ' fall back to the hashed guess until the internet comes back.
    RefreshSrcColorIndex()

    ' LISTEN, DON'T SPEAK — SyncPullOnly() in Store.brs says when and why.
    ' Straight after a first sign-in this device holds no profiles while the
    ' account's real ones are still in the locker, so anything it said about
    ' them would be wrong. Everything this device would SAY is skipped, and
    ' skipping it is what makes the cycle harmless: with no snapshot nothing
    ' can be marked dirty, so nothing new is pushed, and with no reconcile
    ' nothing can be tombstoned, so nothing is deleted. The finished-mark
    ' collectors go with them for the same reason. Everything below still runs.
    '
    ' Note what is NOT done here: reconcile() is not handed an empty snapshot.
    ' That would not be a gentler version of the same thing, it would be the
    ' disaster itself — an empty snapshot means "it is all gone" and tombstones
    ' the member's entire locker account-wide. The CALL is skipped, not its
    ' input emptied.
    pullOnly = SyncPullOnly()
    if pullOnly
        KLog("sync", "pull-only cycle - this device does not know the account's profiles yet")
    else
        snap = buildSnapshot(host, mirror)
        nowMs = CreateObject("roDateTime").asSeconds() * 1000&
        reconcile(snap, mirror, nowMs)

        ' Finished marks (GAP F2) are collected HERE rather than in the
        ' snapshot above, and that is the entire safety of the push half.
        ' buildSnapshot feeds reconcile, and reconcile deletes anything the
        ' snapshot stops mentioning — which for a store that evicts its own
        ' oldest rows would mean deleting the member's oldest checkmarks off
        ' every device they own. So this kind never enters `snap` at all: it
        ' can only ever add and update, and it deletes strictly on the
        ' member's own word. Read collectSeenPuts before touching any of it.
        '
        ' Skipped on a pull-only cycle for the same reason the snapshot is:
        ' a device that does not know the account's profiles yet must listen
        ' and not speak, and pruneSeenMirror in particular would have nothing
        ' to measure against.
        liveSeen = collectSeenPuts(mirror, nowMs)
        collectSeenDeletes(mirror, nowMs)
        pruneSeenMirror(mirror, liveSeen)

        ' Media-server watch progress (medhist, the PUSH half) is collected
        ' here for exactly the same reason finished marks are: everything in
        ' `snap` is subject to reconcile's deletion arm, and a resume point
        ' that merely stopped being in this box's registry is not a member
        ' saying "delete this". Read collectMedHistPuts before touching it.
        collectMedHistPuts(mirror, nowMs)
    end if

    ' Collect the dirty ops to push. A pull-only cycle took no snapshot, so it
    ' added nothing to this list — anything still dirty was marked by an EARLIER
    ' cycle and is a real local change of the member's still waiting to go up.
    ' Dropping those would be throwing their work away, so they still push.
    ops = []
    pushedTs = {}
    for each key in mirror
        r = mirror[key]
        if r.dirty = true
            op = { key: key, kind: ToStr(r.kind), ts: r.ts }
            if r.deleted = true
                op.action = "delete"
            else
                op.action = "put"
                op.data = ParseJson(ToStr(r.data))
            end if
            ops.push(op)
            pushedTs[key] = r.ts
        end if
    end for
    if ops.count() > 0 then KLog("sync", "pushing " + ops.count().toStr() + " change(s)")

    ' Push in chunks; collect the change feed across responses.
    chunks = chunkOps(ops, 400)
    device = SyncDeviceId()
    cursor = SyncCursor()
    collected = {}
    ok = true
    for each chunk in chunks
        body = {
            action: "sync"
            username: ToStr(creds.username)
            password: ToStr(creds.password)
            device: device
            since: cursor
            ops: chunk
        }
        resp = httpPost(FormatJson(body))
        if resp = invalid or GetField(resp, "ok") <> true
            ok = false
            st.phase = "error"
            st.message = friendlyErr(resp)
            exit for
        end if
        for each raw in ToArray(GetField(resp, "changes"))
            k = GetField(raw, "key")
            if k <> invalid then collected[ToStr(k)] = raw
        end for
        c = GetField(resp, "cursor")
        if c <> invalid then cursor = ToInt(c)
        ' Still alive. A big first sync is several chunks and each one waits up
        ' to 25s, so without this the slot would look abandoned partway through
        ' a perfectly healthy push and the next tick would steal it.
        SyncTouchSlot()
    end for

    if not ok
        SaveSyncMirror(mirror)   ' keep dirty flags for the next attempt
        SyncReleaseSlot()
        m.top.result = st
        return
    end if

    ' Mark pushed rows clean (only if unchanged since we pushed them).
    for each key in pushedTs
        if mirror.doesExist(key)
            if mirror[key].ts = pushedTs[key] then mirror[key].dirty = false
        end if
    end for

    ' Apply the feed: profiles first, then by rev, newest-wins per key.
    ' Touched first — projecting a large first pull into the stores is the
    ' other stretch that can run long without touching the network.
    SyncTouchSlot()
    ordered = orderChanges(collected)
    for each raw in ordered
        applyRemote(mirror, raw)
    end for
    ' Finished marks are written straight into their section by projectSeen
    ' without trimming, so the whole feed costs ONE walk of the section
    ' instead of one per mark. Cheap when nothing arrived: a key-list read
    ' that is already inside both caps returns immediately.
    TrimSeen()
    ' Source colours (GAP F1) are rebuilt from the WHOLE mirror rather than
    ' from the feed that just arrived — see rebuildSrcColors for why that is
    ' the only way this box can see the colours it is already carrying.
    rebuildSrcColors(mirror)

    SaveSyncMirror(mirror)
    SetSyncCursor(cursor)
    ' The locker can add or remove VOD favorites behind the app's back —
    ' projectFavVod writes the store directly rather than going through
    ' ToggleFavoriteVod — so rebuild the poster index here too, or a title
    ' favorited on the phone shows no heart until the next launch.
    RefreshFavVodIndex()
    nowSecs = CreateObject("roDateTime").asSeconds()
    SetSyncLastAt(nowSecs)
    ' Say so even when there was nothing to do. A quiet, healthy cycle used to
    ' log NOTHING at all, which made "the cycle ran and had nothing to push"
    ' and "the cycle never ran" look identical on the console — and telling
    ' those two apart is the whole test for the hist/url tolerance, where the
    ' correct result IS zero ops, cycle after cycle. Cheap, once per cycle.
    KLog("sync", "cycle done - pushed " + ops.count().toStr() + ", applied " + ordered.count().toStr())
    if ToInt(m.unknownDropped) > 0
        names = ""
        for each k in m.unknownKinds
            if names <> "" then names = names + ", "
            names = names + ToStr(k)
        end for
        KLog("sync", "ignored " + ToInt(m.unknownDropped).toStr() + " row(s) of kind(s) this version does not handle: " + names)
    end if
    if ToInt(m.foreignMediaDropped) > 0
        ' Plain ASCII on purpose: this line ends up in uploaded member logs.
        KLog("sync", "ignored " + ToInt(m.foreignMediaDropped).toStr() + " media-server row(s) for a server that is not on this box (still on the account)")
    end if
    SyncReleaseSlot()
    st.phase = "done"
    st.lastAt = nowSecs
    m.top.result = st
end sub

' ---- Snapshot (real stores -> sync keys) ------------------------------------

function buildSnapshot(host as string, mirror as object) as object
    snap = {}
    ' Favorite lists live under a per-provider registry key but sync under
    ' source-less wire keys — so list sync is pinned to the KwickTV login's
    ' store. Snapshotting whatever source happens to be ACTIVE would drop
    ' the account's lists from the snapshot on a source switch, and
    ' reconcile would read that as "the member deleted their lists".
    listProv = KwickTvProvider()
    listProvId = ""
    if listProv <> invalid then listProvId = ToStr(listProv.id)
    ' Keep a blank auto-created Default off the wire until the locker's copy
    ' has been pulled. "default" is a SHARED cross-device identity, so a
    ' just-set-up box pushing its empty one would wipe the real profile's
    ' name, colour, avatar and PIN on every other device. The mirror check
    ' earns its place twice: once the row has been pulled, newest-wins is
    ' correct again, and omitting a mirrored key would make reconcile()
    ' tombstone it — profiles are exempt from the ownership rule.
    hideBlankDefault = HasOnlyPristineDefaultProfile() and not mirror.doesExist("profile:default")
    for each p in LoadProfiles()
        sid = ToStr(p.syncId)
        if hideBlankDefault then sid = ""
        if sid <> ""
            suffix = ProfileSuffixFor(ToStr(p.id))

            ' Per-profile settings (pset, T7 phase 2) — merged over the last
            ' synced blob so keys other platforms own always survive a Roku
            ' push (the phone does the same in reverse).
            baseS = invalid
            psRow = mirror["pset:" + sid]
            if psRow <> invalid and psRow.deleted <> true and ToStr(psRow.data) <> ""
                psParsed = ParseJson(ToStr(psRow.data))
                if psParsed <> invalid then baseS = GetField(psParsed, "s")
            end if
            snap["pset:" + sid] = { kind: "pset", data: { p: sid, s: BuildPsetMap(ToStr(p.id), baseS) } }

            pdata = { name: ToStr(p.name), color: ToInt(p.color) }
            if ToStr(p.pin) <> "" then pdata.pin = ToStr(p.pin)
            if ToStr(p.avatar) <> "" then pdata.avatar = ToStr(p.avatar)
            snap["profile:" + sid] = { kind: "profile", data: pdata }

            ' VOD favorites — the WIRE shape must match the Android app
            ' exactly ({type, id:number, name, poster, src?}) so posters and
            ' ids survive the round trip on both sides. USB-playlist rows
            ' ("file:" src) have no cross-device identity and stay off the
            ' wire, like Android leaves hostless playlists out of sync.
            for each v in LoadJsonArray("fav_vod" + suffix)
                vsrc = ""
                if GetField(v, "src") <> invalid then vsrc = ToStr(v.src)
                ' The media-server test is belt and braces: IsPortableSrcToken
                ' already answers no to a "jf:"/"emby:"/"plex:" token, and this
                ' line makes sure that stays true if someone ever widens it. A
                ' media favourite on the favvod wire is the ONE shape that
                ' corrupts an account — see the note on IsPortableSrcToken in
                ' Store.brs. Those favourites travel as "favmedia" instead.
                if vsrc = "" or (IsPortableSrcToken(vsrc) and not IsMediaSrcToken(vsrc))
                    vodKey = ToStr(v.kind) + ":" + ToStr(v.id)
                    if vsrc <> "" then vodKey = vsrc + ":" + vodKey
                    vdata = { p: sid, type: ToStr(v.kind), id: ToInt(v.id), name: ToStr(v.name), poster: ToStr(v.icon) }
                    if ToStr(v.ext) <> "" then vdata.ext = ToStr(v.ext)
                    if vsrc <> "" then vdata.src = vsrc
                    snap["favvod:" + sid + ":" + vodKey] = { kind: "favvod", data: vdata }
                end if
            end for

            ' Locally watched titles -> the phone's Continue Watching (hist
            ' kind, T7 push half). Only entries WITH local metadata push —
            ' positions pulled FROM other devices never get metadata, so
            ' they never churn back under a different shape.
            hsec = CreateObject("roRegistrySection", "kwick_hist")
            rsec = CreateObject("roRegistrySection", "kwick_resume")
            hprefix = ""
            if ToStr(p.id) <> "default" then hprefix = ToStr(p.id) + "|"
            for each hk in hsec.getKeyList()
                hks = ToStr(hk)
                mine = false
                if hprefix = ""
                    mine = (Instr(1, hks, "|") = 0)
                else
                    mine = (hks.left(Len(hprefix)) = hprefix)
                end if
                if mine and rsec.exists(hks)
                    hmeta = ParseJson(hsec.read(hks))
                    rparts = rsec.read(hks).split("|")
                    if hmeta <> invalid and rparts.count() >= 2
                        bare = Mid(hks, Len(hprefix) + 1)
                        ' Source-qualified ids ("<src>~<id>") pass through
                        ' whole — that IS Android's merged-source media-id
                        ' shape. USB-source rows ("file:") stay local.
                        media = ""
                        if bare.left(6) = "movie:" then media = "vod:" + Mid(bare, 7)
                        if bare.left(3) = "ep:" then media = "episode:" + Mid(bare, 4)
                        if Instr(1, media, "file:") > 0 then media = ""
                        ' A member's OWN Jellyfin or Emby does NOT belong on
                        ' this wire. It has a kind of its own ("medhist"), which
                        ' carries no address at all — and a "hist" row carries
                        ' the stream address, which for a media server is the
                        ' machine in the member's house. Older builds sent these
                        ' by accident; sweepMediaRowsOffHistWire cleans up after
                        ' them.
                        '
                        ' These rows DO go up now, but not from here and not in
                        ' this shape: collectMedHistPuts reads the same two
                        ' registry sections and emits them as "medhist",
                        ' deliberately outside the snapshot so that a row this
                        ' box stops holding can never be read as a deletion.
                        if histMediaIsMediaServer(media) then media = ""
                        if media <> ""
                            ' "url" is still emitted ON PURPOSE. It carries the
                            ' member's provider username and password and is on
                            ' its way out, but neither app may stop sending it
                            ' until both have shipped the tolerance in
                            ' reconcile() / histSameIgnoringUrl() below. Do not
                            ' delete it here until Android has confirmed that
                            ' has soaked on the fleet — see the Sync
                            ' credentials memo in the wiki.
                            ' THE KIND COMES OFF THE KEY, NOT OUT OF THE STORED ROW.
                            ' `bare` above has already told us which this is —
                            ' "movie:" or "ep:" — and it is right on every
                            ' profile. The stored `kind` field is not: until
                            ' 2026-09-18 the player wrote it by testing the
                            ' FULL key, which only starts "ep:" on the default
                            ' profile, so every episode watched on any other
                            ' profile was filed as a film and travelled to the
                            ' member's phone that way. The writer is fixed, but
                            ' rows already in this box's registry still carry
                            ' the wrong word and would keep sending it — and
                            ' there is no reason to trust a stored copy of
                            ' something the key states outright.
                            hkind = "movie"
                            if bare.left(3) = "ep:" then hkind = "episode"
                            hdata = { p: sid, kind: hkind, title: ToStr(GetField(hmeta, "title")), url: ToStr(GetField(hmeta, "url")), media: media, at: GetField(hmeta, "at"), pos: ToInt(rparts[0]) }
                            if GetField(hmeta, "sub") <> invalid then hdata.sub = ToStr(hmeta.sub)
                            if GetField(hmeta, "poster") <> invalid then hdata.poster = ToStr(hmeta.poster)
                            if GetField(hmeta, "parent") <> invalid then hdata.parent = ToStr(hmeta.parent)
                            durS = ToInt(rparts[1])
                            if durS > 0 then hdata.dur = durS
                            snap["hist:" + sid + ":" + media] = { kind: "hist", data: hdata }
                        end if
                    end if
                end if
            end for

            ' Favorite lists — Android group shape: {id, name, home,
            ' items:[{key, kind, name, img, route}]}.
            for each l in LoadJsonArray("fav_lists_" + listProvId + suffix)
                wireItems = []
                for each it in ToArray(l.items)
                    wireItems.push(listItemToWire(it, host))
                end for
                snap["favlist:" + sid + ":" + ToStr(l.id)] = { kind: "favlist", data: { p: sid, id: ToStr(l.id), name: ToStr(l.name), home: (l.homeRow = true), items: wireItems } }
            end for

            ' Channel favorites — wire is Android's minimal {p, ch}; anything
            ' extra would re-mark these dirty on every cycle (json mismatch
            ' with rows pulled from the phone). Name/logo are re-derived on
            ' each device from its channel list (EnrichFavoriteChannels).
            '
            ' Each row syncs under ITS OWN source: bare rows are the KwickTV
            ' login's (its host), extra Xtream rows already carry the exact
            ' "xt:<host>" prefix Android builds its channel ids from. M3U
            ' rows stay local — this app's stable ids ("m3uh<hex>") and
            ' Android's ordinal ids can never name the same channel.
            if host <> ""
                for each c in LoadJsonArray("fav_channels" + suffix)
                    csrc = ToStr(GetField(c, "src"))
                    ch = ""
                    if csrc = ""
                        ch = "xt:" + host + ":" + ToStr(c.streamId)
                    else if csrc.left(3) = "xt:"
                        ch = csrc + ":" + ToStr(c.streamId)
                    end if
                    if ch <> ""
                        snap["favch:" + sid + ":" + ch] = { kind: "favch", data: { p: sid, ch: ch } }
                    end if
                end for
            end if
        end if
    end for
    return snap
end function

' ---- Reconcile (mark local changes dirty) -----------------------------------

' Deletion propagation is LIVE (paired with Android v1.0.77's portable-key
' release), governed by OWNERSHIP: a mirror row is "ours" (origin=local)
' when this device last wrote it — from the snapshot, or by re-owning a
' pulled row whose content we also hold locally. Only OUR rows tombstone
' when they disappear locally. Rows we merely pulled (the phone's watch
' history, foreign-source favorites, pset, anything future) are never ours
' and can never be deleted by us — the device only deletes what it emits.
sub reconcile(snap as object, mirror as object, nowMs as dynamic)
    for each key in snap
        entry = snap[key]
        dataJson = FormatJson(entry.data)
        ex = mirror[key]
        changed = (ex = invalid)
        if not changed
            changed = (ex.deleted = true)
            if not changed and ToStr(ex.data) <> dataJson
                changed = true
                ' hist rows: the stream url carries the member's provider
                ' username and password, and both apps are being moved off
                ' emitting it (see the Sync credentials memo in the wiki).
                ' Neither side can stop first while the other still compares
                ' raw strings — the row would mismatch every cycle and the two
                ' devices would re-push it at each other forever. So BOTH
                ' sides learn to tolerate the field's absence first, and only
                ' then does either stop sending it. This is the Roku half of
                ' that tolerance: a hist row whose ONLY difference is "url" is
                ' not a change. Nothing else about the wire moves yet.
                if ToStr(entry.kind) = "hist" and histSameIgnoringUrl(ToStr(ex.data), entry.data) then changed = false
            end if
        end if
        if changed
            mirror[key] = { kind: entry.kind, data: dataJson, ts: nowMs, deleted: false, dirty: true, origin: "local" }
        else
            ' Unchanged and present locally -> we (co-)own it now. This is
            ' also the safe on-ramp: nothing can tombstone until it has
            ' first been seen in a snapshot on THIS device.
            ex.origin = "local"
        end if
    end for
    for each key in mirror
        if not snap.doesExist(key)
            ex = mirror[key]
            if ex.deleted <> true
                ' Finished marks and media-server watch progress are never
                ' deleted by absence, whatever the ownership rule would
                ' otherwise say. This is a HARDENING of the rule above, not a
                ' hole in it: it only ever removes deletions, and the rule that
                ' a key is tombstoned solely when it is a profile row or
                ' locally owned still holds exactly as written. Nothing is
                ' being added to the profile exception; two kinds are being
                ' taken out of reach of the arm entirely.
                '
                ' It exists because "the Roku no longer has this mark" has two
                ' meanings and only one of them is a deletion. The store is
                ' capped (SeenMaxRows/SeenMaxBytes in Store.brs) and evicts
                ' its own oldest rows; the phone's is uncapped precisely
                ' because this protocol reads absence as deletion
                ' (watched_items_repository.dart:168-177). So an evicted mark
                ' reaching this line would wipe the member's oldest checkmarks
                ' account-wide, on every device, every time this small box ran
                ' out of room.
                '
                ' "medhist" is the same story told about a different store. Its
                ' rows are built from kwick_hist + kwick_resume, and BOTH of
                ' those lose rows for reasons that are not a member deleting
                ' anything: a title finished past 95% has its resume point (and
                ' its history row with it) thrown away by ClearResume, a
                ' registry that is full refuses the write, a server that is
                ' removed takes its rows out of reach, and this box's own wire
                ' cap is smaller than the phone's. Every one of those would
                ' otherwise post a deletion for a resume point the member still
                ' has on their phone.
                '
                ' Today nothing can reach it: collectSeenPuts and
                ' collectMedHistPuts keep these kinds out of `snap` entirely
                ' and write their rows origin "remote", so the test below
                ' already fails for them. This clause is the second lock — it
                ' holds even if someone later adds one of them to buildSnapshot
                ' without reading any of this, which is the mistake that is
                ' actually available to be made. If you are here to make
                ' finished marks or media watch progress push, do it in those
                ' collectors and delete nothing from this line.
                if ToStr(ex.kind) <> "seen" and ToStr(ex.kind) <> "medhist"
                    if ToStr(ex.kind) = "profile" or ToStr(GetField(ex, "origin")) = "local"
                        mirror[key] = { kind: ex.kind, data: "", ts: nowMs, deleted: true, dirty: true, origin: "local" }
                    end if
                end if
            end if
        end if
    end for
end sub

' Every key a hist row is built from in buildSnapshot() — deliberately
' WITHOUT "url", which is the one being ignored. Kept as an explicit list so
' the comparison below has a fixed, known shape that does not depend on the
' order keys happen to come out of a map in. A key that is not on this list
' (or "url") makes the row count as changed, so a field added later can never
' be silently ignored by this code — it just falls back to today's behaviour.
function histCompareKeys() as object
    return ["p", "kind", "title", "media", "at", "pos", "sub", "poster", "parent", "dur"]
end function

' Are these two hist rows the same apart from "url"?
'
' exJson is the mirror's stored copy (a JSON string); localData is the freshly
' built snapshot map. This is only ever called AFTER the two have already
' failed the plain string comparison, which matters a lot: the only thing this
' can do is downgrade a "changed" to "unchanged". If anything at all here is
' unclear — unparseable json, a key we do not recognise, a value we cannot
' render — it answers false and the row is treated as changed exactly as it is
' today. Re-pushing a row we built ourselves is harmless; wrongly deciding a
' row did NOT change would silently lose a member's watch position, so every
' doubt resolves towards "changed".
'
' Deliberately NOT done by stripping "url" and re-serialising both sides with
' FormatJson: key order out of ParseJson -> FormatJson is not something to
' trust to be identical between a server-mirrored blob and a locally built
' map, and if it ever differed we would have manufactured the exact endless
' re-push this whole change exists to prevent. Comparing named fields one at a
' time cannot be affected by ordering at all.
function histSameIgnoringUrl(exJson as string, localData as object) as boolean
    if exJson = "" then return false
    if type(localData) <> "roAssociativeArray" then return false
    remote = ParseJson(exJson)
    if remote = invalid then return false
    if type(remote) <> "roAssociativeArray" then return false

    keys = histCompareKeys()

    ' Reject anything carrying a key outside the known shape, either side.
    known = { url: true }
    for each k in keys
        known[k] = true
    end for
    for each k in remote
        ' ParseJson maps are case-SENSITIVE, and the reads below all use
        ' lower-case names — so an oddly-cased key would be invisible to
        ' them. Refuse the whole row instead.
        if k <> LCase(k) then return false
        if not known.doesExist(k) then return false
    end for
    for each k in localData
        if not known.doesExist(k) then return false
    end for

    for each k in keys
        lHas = localData.doesExist(k)
        rHas = remote.doesExist(k)
        if lHas <> rHas then return false
        if lHas
            lv = localData[k]
            rv = remote[k]
            lMissing = (lv = invalid)
            rMissing = (rv = invalid)
            if lMissing <> rMissing then return false
            if not lMissing
                lTok = jsonValueToken(lv)
                rTok = jsonValueToken(rv)
                ' "" means it could not be rendered — never call that a match.
                if lTok = "" or rTok = "" then return false
                if lTok <> rTok then return false
            end if
        end if
    end for
    return true
end function

' One value, rendered as json inside a single-key wrapper so that key order
' cannot come into it. Both sides go through this same call, which is the
' point: the number 5 and the text "5" stay distinguishable, and numbers keep
' whatever formatting FormatJson gives them rather than one we invented.
' Returns "" for anything it cannot render, which the caller reads as "do not
' claim these match".
function jsonValueToken(v as dynamic) as string
    if v = invalid then return ""
    tok = ""
    try
        tok = FormatJson({ x: v })
    catch e
        tok = ""
    end try
    return tok
end function

' ---- Apply (feed -> real stores) --------------------------------------------

sub applyRemote(mirror as object, c as object)
    key = ToStr(GetField(c, "key"))
    kind = ToStr(GetField(c, "kind"))
    if key = "" or kind = "" then return
    ' Old-format Android rows (device-local UUID keys) are dead: never
    ' mirror, never project, and — by never holding them — never tombstone.
    if kind = "favvod" and isLegacyUuidVodKey(favvodTail(key)) then return
    ' A kind this build does not understand is DROPPED, not carried. See
    ' IsKnownSyncKind() for why, and for what it costs.
    if not IsKnownSyncKind(kind)
        m.unknownDropped = ToInt(m.unknownDropped) + 1
        m.unknownKinds[kind] = true
        return
    end if
    ' A media row is kept only for a server that is actually on this box — see
    ' the registry note above IsKnownSyncKind. A tombstone carries no payload to
    ' test, so it is kept exactly when this box is already holding the row it
    ' would remove: applying a delete for something we never had would write a
    ' tombstone into the mirror for no reason, and refusing one for a row we DO
    ' hold would leave a favourite on this television that the member took off
    ' on their phone.
    if kind = "favmedia" or kind = "medhist"
        keepRow = false
        if ToInt(GetField(c, "deleted")) <> 0
            keepRow = (mirror[key] <> invalid)
        else
            keepRow = MediaSrcTokenIsHere(ToStr(GetField(GetField(c, "data"), "src")))
        end if
        if not keepRow
            ' Counted apart from the unknown-kind tally: this build DOES
            ' understand the kind, it simply does not have the server, and the
            ' two read very differently in a member's uploaded log.
            m.foreignMediaDropped = ToInt(m.foreignMediaDropped) + 1
            return
        end if
    end if
    cts = GetField(c, "ts")
    ex = mirror[key]
    if ex <> invalid and ex.ts >= cts then return   ' ours is same-or-newer

    deleted = (ToInt(GetField(c, "deleted")) <> 0)
    dataObj = GetField(c, "data")
    dataJson = ""
    if not deleted and dataObj <> invalid then dataJson = FormatJson(dataObj)
    ' Rows written from the feed are REMOTE-owned: this device never
    ' tombstones them, no matter what happens locally.
    mirror[key] = { kind: kind, data: dataJson, ts: cts, deleted: deleted, dirty: false, origin: "remote" }
    ' Projection runs inside try/catch: feed data comes from other apps and
    ' the server's PHP re-encoding, and a runtime error here froze the whole
    ' channel once (v1.0.8, s:[] instead of s:{}). Bad rows get logged and
    ' skipped — never a crash.
    try
        ' Settings blobs are applied here (not in projectChange) so the
        ' cold-cache retry flag can live on the mirror row. A tombstoned pset
        ' row needs no projection — settings die with their profile.
        if kind = "pset"
            if not deleted
                sid = Mid(key, Len("pset:") + 1)
                if sid <> "" then mirror[key].pending = ApplyPsetMap(sid, GetField(dataObj, "s"), false)
            end if
            return
        end if
        ' Deletion sync is live (Android v1.0.77 pairing) — deletes from other
        ' devices apply here, same as puts.
        projectChange(kind, key, deleted, dataObj)
    catch err
        KLog("sync", "apply failed for " + key + ": " + ToStr(err.message))
        ' Arm a next-launch crash report: on sideloaded builds uncaught
        ' errors freeze silently into the debugger, so caught sites like
        ' this are the crash telemetry that actually reaches the server.
        ArmCrashReport("CAUGHT sync-apply: " + ToStr(err.message))
    end try
end sub

' A source whose address was edited on the website changes its source token,
' and everything saved against it is moved across to the new one (see the
' source-edit block in Store.brs). The mirror rows under the OLD token are
' dropped there and then — but this cycle may already have been in the air
' when that happened, in which case it saves its own older copy of the
' mirror afterwards and the old rows come back. So the old token is kept on
' a retired list and swept again here, at the top of every cycle, before
' reconcile() gets a chance to read those rows as deletions.
'
' Dropped, never tombstoned: the rows still exist in the locker, and the
' member's other devices — which may not have made the same move yet — must
' keep theirs. A token stops being swept the moment a real source answers to
' it again (IsRetiredSrcToken).
' ---- Kinds this build understands -------------------------------------------
'
' Every kind the locker can send that this app can do something with. Keep it
' in step with projectChange() AND with the two kinds that are not projected
' row-by-row: "pset" (applied in applyRemote itself) and "srccol" (rebuilt
' from the whole mirror once a cycle by rebuildSrcColors). Dropping either of
' those by leaving it out of this list would take the member's per-profile
' settings and their source colours with it.
'
' ---- The two media kinds are known, but they are ALSO gated per row --------
'
' "favmedia" and "medhist" carry a member's favourites and watch progress from
' their OWN Jellyfin or Emby. Saying "known" here is not enough on its own and
' must never be read as enough: a heavy media-server member carries roughly
' 48 KB of these on their account, and this box has 16-32 KB of registry for
' the WHOLE app with a silent failure past it. Keeping all of them would push
' the registry over and start refusing writes to the things the member can
' actually see — their profiles, their favourites, their resume points.
'
' So a second question is asked of every media row, in mediaRowIsForThisBox()
' below and in applyRemote(): does its "src" name a media server that is
' actually ON THIS BOX? A member with no Jellyfin or Emby on their Roku keeps
' exactly today's behaviour, every one of those rows let go of; a member with
' one keeps only their own server's rows, which is a handful.
'
' Whoever adds the third media brand adds it to IsMediaSrcToken in Store.brs,
' NOT here.
function IsKnownSyncKind(kind as string) as boolean
    if kind = "profile" then return true
    if kind = "favvod" then return true
    if kind = "favlist" then return true
    if kind = "favch" then return true
    if kind = "hist" then return true
    if kind = "seen" then return true
    if kind = "pset" then return true
    if kind = "srccol" then return true
    if kind = "favmedia" then return true
    if kind = "medhist" then return true
    return false
end function

' The per-row half of the gate described above: is this stored mirror row one
' this box should go on carrying?
'
' Only the two media kinds can ever answer no — everything else this build
' knows is small and belongs to the account as a whole. `dataJson` is the row's
' stored payload exactly as the mirror holds it.
'
' Anything unreadable answers NO, which is the safe direction here and the
' opposite of the one histSameIgnoringUrl takes: this decides whether to go on
' CARRYING a copy, and letting go of a row can never delete anything (the
' ownership rule in reconcile only ever tombstones a profile row or one this
' device emitted, and this device emits neither of these kinds). Getting it
' wrong costs a row this box could not have drawn anyway.
function mediaRowIsForThisBox(kind as string, dataJson as string) as boolean
    if kind <> "favmedia" and kind <> "medhist" then return true
    if dataJson = "" then return false
    d = ParseJson(dataJson)
    if d = invalid then return false
    if type(d) <> "roAssociativeArray" then return false
    return MediaSrcTokenIsHere(ToStr(GetField(d, "src")))
end function

' ---- Rows of a kind this build has never understood --------------------------
'
' WHY THEY HAVE TO GO. applyRemote used to write the mirror BEFORE it looked
' the kind up, so every row of every kind the phone has ever emitted was kept
' here forever — understood or not, projected or not. The mirror lives in the
' registry, which is 16-32 KB FOR THE WHOLE APP and fails silently when full
' (RegWrite now says so out loud; it did not before). A member using the
' phone's media-server features heavily carries roughly 48 KB of favmedia and
' medhist rows on their account — none of which this app can draw, all of
' which this app was holding, and which is comfortably enough on its own to
' push the registry over and start refusing writes to the things that DO
' matter: their profiles, their favourites, their resume points.
'
' That is the trade, and it is not close: rows we cannot use were crowding out
' rows the member can see.
'
' WHY DROPPING IS SAFE, and it is worth being exact because getting this wrong
' silently deletes a member's things off their other devices. reconcile()
' tombstones a mirror key that is missing from the local snapshot ONLY when
' the row is a profile row or origin "local". Rows from the feed are written
' origin "remote" by applyRemote and can never be tombstoned. So a dropped row
' is forgotten HERE and nowhere else — it stays in the locker, and the phone
' that owns it keeps it. Do not weaken that ownership rule; this sweep leans
' on it entirely.
'
' Android learned this the hard way in the other direction: a build that had
' merely CARRIED "seen" rows without understanding them later compared an
' empty local table against a full mirror and pushed a tombstone for every one
' (_backfillSeenFromMirror, sync_service.dart:557-590).
'
' WHAT IT COSTS, stated plainly because it is a real cost and the opposite
' choice is what once saved us. Sync is CURSOR-based: a row already behind the
' cursor is never offered again. Hoarding is precisely why source colours
' worked the day this app learned "srccol" — the rows were already here, months
' of them, and rebuildSrcColors could walk them. After this change that no
' longer happens for the NEXT new kind: it will start from the day the member
' upgrades and know nothing before it.
'
' >>> SO WHOEVER TEACHES THIS APP A NEW KIND HAS TO BRING THE HISTORY WITH IT.
'     The mirror will not have it any more. That means a one-off full pull for
'     that member — which is deliberately NOT done here, because the pull
'     endpoint still has no LIMIT and old Rokus abort a feed over 25 seconds,
'     after which sync is broken for that box for good. Pagination on the pull
'     is already parked in the kwicksync server lane; that lands first, then a
'     new kind can safely ask for its history. <<<
sub sweepUnknownKindRows(mirror as object)
    drop = []
    kinds = {}
    foreignMedia = 0
    for each key in mirror
        r = mirror[key]
        ' This is now the FIRST thing in the cycle to read every row, so it is
        ' the one that meets a malformed mirror first. Anything that is not a
        ' row goes with the rest — it is unusable either way, and reading
        ' `.kind` off it would take the cycle down.
        k = ""
        if type(r) = "roAssociativeArray" then k = ToStr(GetField(r, "kind"))
        if not IsKnownSyncKind(k)
            drop.push(ToStr(key))
            if k = "" then k = "(no kind)"
            kinds[k] = true
        else if GetField(r, "dirty") <> true
            ' A media row for a server that is not on this box goes too, for
            ' the registry reason in the note above IsKnownSyncKind — the kind
            ' is understood, the SERVER is not here. Counted separately so a
            ' member's log says which of the two happened.
            '
            ' Dirty rows are stepped over deliberately, and from this build
            ' that matters rather than being groundwork: collectMedHistPuts
            ' makes dirty "medhist" rows, and a film the member watched here
            ' minutes ago may be sitting in the mirror waiting for the next
            ' push. Sweeping it would throw their progress away on its way out
            ' — and, because nothing in this app tombstones a medhist row, it
            ' would simply never arrive rather than arriving as a deletion.
            if not mediaRowIsForThisBox(k, ToStr(GetField(r, "data")))
                drop.push(ToStr(key))
                foreignMedia = foreignMedia + 1
            end if
        end if
    end for
    if drop.count() = 0 then return
    for each k in drop
        mirror.delete(k)
    end for
    names = ""
    for each k in kinds
        if names <> "" then names = names + ", "
        names = names + ToStr(k)
    end for
    if names = "" then names = "(none)"
    ' Plain ASCII on purpose: this line ends up in uploaded member logs.
    KLog("sync", "let go of " + drop.count().toStr() + " stored row(s) this version cannot use, freeing registry space: " + names + "; " + foreignMedia.toStr() + " for a media server that is not on this box")
end sub

' ---- Media-server rows that went out on the WRONG wire -----------------------
'
' Until this build, a film or an episode watched from a member's own Jellyfin
' or Emby was pushed up as an ordinary "hist" row. That was wrong in two ways
' and both of them mattered.
'
' The first is what the phone does with it. A "hist" row is an IPTV row by
' definition — the phone's own history snapshot reads only its IPTV side — so a
' media row landing there is filed on the wrong side of the phone's table under
' a media id ("vod:jf:<serverId>~<guid>") that its IPTV half can make no sense
' of. The media kinds exist precisely so that cannot happen.
'
' The second is privacy. A "hist" row carries the stream address, and for a
' media server that address is the member's own server — the machine in their
' house, by whatever name this Roku reaches it. The media kinds carry NO address
' of any kind, on purpose, and every device rebuilds its own from its own copy
' of the server.
'
' So buildSnapshot no longer emits those rows. What that leaves behind is the
' dangerous part: reconcile() reads a mirror key that has stopped appearing in
' the snapshot as a DELETION, and these rows are origin "local" because this
' box emitted them — so simply stopping would tombstone every one of them and
' take the member's matching watch-history rows off their phone with it.
'
' They are therefore DROPPED here, at the top of the cycle, before reconcile
' can see them go missing. Dropped, never tombstoned: the row stays in the
' locker and on the phone, and this box just stops claiming it. Nothing the
' member can see on this television is lost — the resume point lives in
' kwick_resume, which this does not touch.
'
' It runs every cycle rather than once behind a flag, because a row pushed by
' an older build can still be in the air, or arrive from another Roku that has
' not been updated yet.
'
' The stale copies left on the phone are a known loose end and are named in the
' report — they are junk rows in the phone's watch history and want an Android
' or server-side tidy-up, not a deletion posted from here.
sub sweepMediaRowsOffHistWire(mirror as object)
    drop = []
    for each key in mirror
        r = mirror[key]
        if type(r) = "roAssociativeArray" and ToStr(GetField(r, "kind")) = "hist"
            ' A tombstone carries no data. ParseJson("") is not an error but the
            ' OS prints one to the console for it, three times a cycle on the
            ' office stick - noise that buries a real line.
            raw = ToStr(GetField(r, "data"))
            d = invalid
            if raw <> "" then d = ParseJson(raw)
            if d <> invalid and type(d) = "roAssociativeArray"
                if histMediaIsMediaServer(ToStr(GetField(d, "media"))) then drop.push(ToStr(key))
            end if
        end if
    end for
    if drop.count() = 0 then return
    for each k in drop
        mirror.delete(k)
    end for
    ' Plain ASCII on purpose: this line ends up in uploaded member logs.
    KLog("sync", "stopped claiming " + drop.count().toStr() + " watch-history row(s) that belong to a media server (still on the account)")
end sub

' Does a hist wire media id ("vod:<ref>" / "episode:<ref>") name a media
' server? The reference keeps the local "<src>~<id>" shape, so the source token
' is everything before the "~".
function histMediaIsMediaServer(media as string) as boolean
    ref = ""
    if media.left(4) = "vod:" then ref = Mid(media, 5)
    if media.left(8) = "episode:" then ref = Mid(media, 9)
    if ref = "" then return false
    return IsMediaSrcToken(SplitSrcQualifiedId(ref).src)
end function

sub sweepRetiredSrcRows(mirror as object)
    retired = RetiredSrcTokens()
    if retired.count() = 0 then return
    live = []
    for each t in retired
        if IsRetiredSrcToken(ToStr(t)) then live.push(ToStr(t))
    end for
    if live.count() = 0 then return
    drop = []
    for each key in mirror
        ks = ToStr(key)
        for each t in live
            if SyncKeyNamesSrc(ks, t)
                drop.push(ks)
                exit for
            end if
        end for
    end for
    if drop.count() = 0 then return
    for each k in drop
        mirror.delete(k)
    end for
    KLog("sync", "forgot " + drop.count().toStr() + " row(s) from a source whose address changed")
end sub

' Retry pset category-name translation for rows that arrived while the
' id->name cache was cold (list keys only — scalars were already applied,
' and a full re-apply could revert newer local changes).
sub replayPendingPset(mirror as object)
    for each key in mirror
        r = mirror[key]
        if ToStr(r.kind) = "pset" and GetField(r, "pending") = true and r.deleted <> true
            parsed = ParseJson(ToStr(r.data))
            if parsed <> invalid
                sid = Mid(ToStr(key), Len("pset:") + 1)
                if sid <> "" then r.pending = ApplyPsetMap(sid, GetField(parsed, "s"), true)
            end if
        end if
    end for
end sub

sub projectChange(kind as string, key as string, deleted as boolean, data as object)
    if kind = "profile"
        projectProfile(key, deleted, data)
    else if kind = "favvod"
        projectFavVod(key, deleted, data)
    else if kind = "favlist"
        projectFavList(key, deleted, data)
    else if kind = "favch"
        projectFavCh(key, deleted, data)
    else if kind = "hist"
        projectHist(key, deleted, data)
    else if kind = "seen"
        projectSeen(key, deleted, data)
    else if kind = "favmedia"
        projectFavMedia(key, deleted, data)
    else if kind = "medhist"
        projectMedHist(key, deleted, data)
    end if
    ' "srccol" is deliberately absent. Source colours are not projected one
    ' row at a time: the mirror is the record, and the whole local map is
    ' rebuilt from it once per cycle by rebuildSrcColors — which is the only
    ' arrangement that can see the rows this box was already carrying before
    ' it understood the kind. See there.
end sub

' ---- Finished marks from the phone (GAP D0, the PULL half) ------------------
'
' The phone's "seen" rows written into the Roku's own finished-marks store.
' The push half is GAP F2 and lives in collectSeenPuts, well away from
' buildSnapshot; the note there explains why the two halves are kept apart.
'
' The pull half's own safety is the ownership rule in reconcile(): a mirror
' key missing from the snapshot is tombstoned only when it is a profile row or
' origin "local". Rows that arrived from the feed are written origin "remote"
' by applyRemote and can never be tombstoned here, no matter what this device
' does or does not hold locally. Do not weaken that, and do not add "seen" to
' the profile exception.
'
' What that spared this app is worth knowing, because the phone did not get
' away with it: on Android a build that had merely CARRIED these rows without
' understanding them later compared an empty local table against a full mirror
' and pushed a tombstone for every row — see _backfillSeenFromMirror
' (sync_service.dart:557-590). Roku was never exposed to that, and the push
' half below is built so it still is not.
sub projectSeen(key as string, deleted as boolean, data as object)
    ' "seen:<profileSyncId>:<mediaId>", and the media id carries colons of
    ' its own ("episode:839625") — so this splits at the FIRST colon only and
    ' keeps the whole remainder, exactly as Android does
    ' (favorite_sync_types.dart:694-698).
    parts = splitFirstColon(Mid(key, Len("seen:") + 1))
    if parts = invalid then return
    sid = parts.head
    if sid = "" then return

    ' Android takes the media id off the KEY when the row is a tombstone and
    ' out of the PAYLOAD otherwise, because a tombstone carries no payload
    ' (favorite_sync_types.dart:700-714). Same here.
    media = parts.tail
    if not deleted
        if data = invalid then return
        media = ToStr(GetField(data, "media"))
    end if
    if media = "" then return

    localKey = seenLocalKey(sid, media)
    if localKey = "" then return

    if deleted
        ' Unmarked on another device. No profile is created on the strength
        ' of a deletion — there is nothing to create it for.
        '
        ' "false" says this unmark is not OURS. It matters: a local unmark
        ' queues itself for upload (UnmarkSeen in Store.brs), and queuing this
        ' one would post the phone's own decision straight back at it every
        ' cycle. The two devices would spend the rest of their lives telling
        ' each other about a checkmark neither of them has.
        UnmarkSeen(localKey, false)
        return
    end if

    ' An unreadable timestamp is not a reason to mark something watched. A
    ' forgotten mark shows the member an episode again; a wrong one hides an
    ' episode they never saw — so this bails rather than guessing a date.
    at = seenAtText(GetField(data, "at"))
    if at = "" then return

    ' "parent" is OPTIONAL on the wire: Android omits the key entirely rather
    ' than sending null (favorite_sync_types.dart:681). Absent is normal.
    parent = ""
    if GetField(data, "parent") <> invalid then parent = ToStr(GetField(data, "parent"))

    ' Raw: the cycle trims once when it has applied everything, rather than
    ' walking the whole section once per row.
    MarkSeenRaw(localKey, parent, at)
end sub

' Android's media id -> this profile's local finished-mark key. The mapping
' is character for character the one projectHist already uses for resume
' points, which is what makes a mark and the resume point it replaced name
' the same thing:
'
'     "vod:<rest>"      -> "<profile>|movie:<rest>"
'     "episode:<rest>"  -> "<profile>|ep:<rest>"
'
' <rest> passes through WHOLE, source qualifier and all — "<src>~<id>" is
' Android's merged-source media-id shape and the Roku's key shape both.
'
' Anything else comes back empty and is skipped. Live rows have no end to
' reach, so they can never be "finished".
'
' Known gap, stated rather than papered over: Android qualifies a MOVIE id
' with its source ("vod:3~1041", vod_detail_screen.dart:183) but writes an
' EPISODE id bare ("episode:839625", series_detail_screen.dart:857) even on
' an extra source. A bare episode id therefore lands in the KwickTV
' namespace here. That is not new and is not this build's to fix — the
' existing hist projector maps them the identical way, so marks and resume
' points at least stay consistent with each other. Diverging here would be
' worse than the gap.
function seenLocalKey(sid as string, media as string) as string
    prefix = ""
    if sid <> "default" then prefix = sid + "|"
    if media.left(4) = "vod:" then return prefix + "movie:" + Mid(media, 5)
    if media.left(8) = "episode:" then return prefix + "ep:" + Mid(media, 9)
    return ""
end function

' The wire's "at" as the plain decimal text this app stores.
'
' It is milliseconds since 1970, which does NOT fit the 32-bit integer
' ToInt() hands back — the same trap kwick_hist's "at" carries (see
' mediaBarIdxPut in Store.brs). ParseJson gives a LongInteger for a number
' that size and ToStr renders it exactly; but a build or a server that handed
' back a float instead would render as "1.75604e+12", so the result is
' checked for being nothing but digits and refused otherwise. Returning ""
' means "do not claim to know when this was finished", and the caller reads
' that as "do not mark it".
function seenAtText(v as dynamic) as string
    s = ToStr(v)
    if s = "" then return ""
    if Len(s) > 15 then return ""
    for i = 0 to Len(s) - 1
        c = Mid(s, i + 1, 1)
        if c < "0" or c > "9" then return ""
    end for
    return s
end function

' ---- Finished marks: the PUSH half (GAP F2) ---------------------------------
'
' Finish an episode on the television and it should be ticked on the phone.
' That is the feature. Everything below is about it being that and NOTHING
' else — in particular, about it never being able to UNtick anything.
'
' ---- Why this is not in buildSnapshot ---------------------------------------
'
' The obvious way to push a kind is to add it to buildSnapshot and let
' reconcile do the rest. For this one kind that is a data-destroying mistake,
' and the reason is a mismatch between two stores that were each sized
' correctly on their own:
'
'   this box   kwick_seen is CAPPED (SeenMaxRows 200 / SeenMaxBytes 4096) and
'              evicts its oldest marks, because the registry is 16-32 KB for
'              the whole app and a write past it fails silently, taking the
'              member's providers with it.
'   the phone  its snapshot is deliberately UNCAPPED
'              (watched_items_repository.dart:168-177), for exactly this
'              reason, stated there in as many words: "a capped snapshot here
'              would tombstone a member's oldest marks account-wide".
'
' reconcile() reads a key that has gone missing from a snapshot as a deletion.
' Put a capped store behind that and the protocol cannot tell "the member
' unmarked it" from "this small box ran out of room" — so the day this Roku
' evicts its two hundredth mark, it deletes the member's oldest checkmarks off
' their phone, their tablet and every other device on the account. Silently,
' and again on every eviction after that.
'
' ---- How it is resolved -----------------------------------------------------
'
' Absence is not a deletion. This kind is collected here, outside the snapshot,
' and can only ever ADD or UPDATE a row. A mark leaves the account only when
' the member presses "Mark as unwatched", which is recorded at that moment in
' its own queue (UnmarkSeen / QueueSeenUnmark in Store.brs) and posted by
' collectSeenDeletes below. Eviction goes straight to the registry section and
' never touches that queue, which is what makes the two distinguishable at all
' — and it is a distinction the snapshot approach cannot make in principle, at
' any cap, which is why the cap was not simply raised instead.
'
' Rows written here are origin "remote", which is not a lie about where they
' came from so much as the plain truth about deletion authority: this device
' does not own their existence and must never tombstone them. reconcile's
' deletion arm tests exactly that field, so today's code is already safe, and
' the kind guard added beside that test is a second, independent lock.
'
' ---- Proof that this cannot delete a mark another device has ----------------
'
' There is exactly ONE line in this app that creates a tombstone: the
' `deleted: true` write in reconcile(), plus the explicit one in
' collectSeenDeletes. For a "seen" key to reach reconcile's it would have to
' pass all four of:
'   1. be in the mirror                              — true, it is;
'   2. be missing from `snap`                        — always true, this kind
'      is never put in `snap` by anything;
'   3. not be `deleted` already;
'   4. be a profile row, or origin "local".
' Every seen row in the mirror is written by exactly two places — applyRemote
' (origin "remote") and this function (origin "remote") — so (4) is false for
' all of them, and the kind guard fails before (4) is even reached. The only
' remaining tombstone is the one in collectSeenDeletes, which is driven solely
' by a queue that only a member's button press can write to.
'
' ---- The known gap, stated rather than papered over -------------------------
'
' A film finished ON THIS BOX goes up without a "parent". The phone records
' one for its own films (`mediaId: vod:<ref>, parentId: movie:<ref>`,
' vod_detail_screen.dart) and uses it for "mark this film unwatched" from the
' detail page; this app's MovieDetailScreen calls MarkSeen(key, "") and so has
' nothing to send. Nothing is lost or churned by it — a mark pulled FROM the
' phone keeps the parent it arrived with, so those rows round-trip unchanged —
' and the fix is one argument at MovieDetailScreen.brs:389, in a file this
' lane does not own.
'
' Returns the set of wire keys this box stands behind this cycle, which
' pruneSeenMirror uses and nothing else should.
function collectSeenPuts(mirror as object, nowMs as dynamic) as object
    live = {}
    sec = CreateObject("roRegistrySection", "kwick_seen")
    keys = sec.getKeyList()
    if keys.count() = 0 then return live

    ' The same rule buildSnapshot uses, and for the same reason: a blank
    ' auto-created Default is a SHARED cross-device identity this box has not
    ' earned the right to speak for yet. Marks are additive so pushing them
    ' could not overwrite anything, but a device that is being quiet about a
    ' profile should be quiet about all of it, and the window closes the
    ' moment the locker's copy of that profile arrives.
    hideBlankDefault = HasOnlyPristineDefaultProfile() and not mirror.doesExist("profile:default")
    n = 0
    for each p in LoadProfiles()
        sid = ToStr(p.syncId)
        if hideBlankDefault then sid = ""
        if sid <> ""
            ' Read off p.id, not the sync id. They are the same string on
            ' every profile this app can create (CreateProfile and
            ' UpsertProfileBySyncId both set them together), and writing it
            ' this way means they would not have to stay that way.
            prefix = ""
            if ToStr(p.id) <> "default" then prefix = ToStr(p.id) + "|"
            for each k in keys
                ks = ToStr(k)
                mine = false
                if prefix = ""
                    mine = (Instr(1, ks, "|") = 0)   ' default owns the bare keys
                else
                    mine = (Len(ks) > Len(prefix) and ks.left(Len(prefix)) = prefix)
                end if
                if mine
                    media = seenWireMedia(Mid(ks, Len(prefix) + 1))
                    if media <> ""
                        v = parseSeenValue(sec.read(ks))
                        if v <> invalid
                            at = seenAtNumber(ToStr(v.at))
                            if at <> invalid
                                ' Field order matches the phone's map literal
                                ' (favorite_sync_types.dart:673-687) — p,
                                ' media, parent when there is one, at. The
                                ' reconciler compares encoded STRINGS, so a
                                ' payload assembled a different way would look
                                ' changed on every cycle and re-push for ever.
                                data = { p: sid, media: media }
                                pr = ToStr(v.parent)
                                if pr <> "" then data.parent = pr
                                data.at = at
                                wk = "seen:" + sid + ":" + media
                                live[wk] = true
                                dataJson = FormatJson(data)
                                ex = mirror[wk]
                                ' A tombstone counts as different: the member
                                ' has since marked it again on this box, and
                                ' the newer word is theirs.
                                if ex = invalid or ex.deleted = true or ToStr(ex.data) <> dataJson
                                    mirror[wk] = { kind: "seen", data: dataJson, ts: nowMs, deleted: false, dirty: true, origin: "remote" }
                                    n = n + 1
                                end if
                            end if
                        end if
                    end if
                end if
            end for
        end if
    end for
    if n > 0 then KLog("sync", "finished marks: " + n.toStr() + " to push")
    return live
end function

' The member's own unmarks, and nothing else, turned into deletions.
'
' The queue this drains can only be written by UnmarkSeen with byMember=true,
' which is the two "Mark as unwatched" buttons and nothing else — eviction
' (TrimSeen), profile deletion (ClearSeenForProfile) and the sync projector
' all take their marks off by other doors on purpose. See the note above
' QueueSeenUnmark in Store.brs.
sub collectSeenDeletes(mirror as object, nowMs as dynamic)
    q = SeenUnmarkQueue()
    if q.count() = 0 then return

    profs = []
    for each p in LoadProfiles()
        sid = ToStr(p.syncId)
        if sid <> ""
            prefix = ""
            if ToStr(p.id) <> "default" then prefix = ToStr(p.id) + "|"
            profs.push({ sid: sid, prefix: prefix })
        end if
    end for

    n = 0
    for each raw in q
        ks = ToStr(raw)
        for each pr in profs
            mine = false
            if pr.prefix = ""
                mine = (Instr(1, ks, "|") = 0)
            else
                mine = (Len(ks) > Len(pr.prefix) and ks.left(Len(pr.prefix)) = pr.prefix)
            end if
            if mine
                media = seenWireMedia(Mid(ks, Len(pr.prefix) + 1))
                if media <> ""
                    wk = "seen:" + pr.sid + ":" + media
                    ' Only tombstone a row the locker actually holds. A mark
                    ' made and taken off again between two cycles was never
                    ' pushed, so there is nothing out there to delete and a
                    ' tombstone would be a row invented out of nothing.
                    ex = mirror[wk]
                    if ex <> invalid and ex.deleted <> true
                        mirror[wk] = { kind: "seen", data: "", ts: nowMs, deleted: true, dirty: true, origin: "remote" }
                        n = n + 1
                    end if
                end if
                exit for
            end if
        end for
    end for

    ' Emptied now, because from this point the MIRROR is the durable record of
    ' the intention: the tombstones above are dirty, and the mirror is saved on
    ' both the success and the failure path below, so a push that fails retries
    ' from there rather than from here. The one thing this loses is an unmark
    ' the box is killed in the middle of uploading, which costs a stale
    ' checkmark elsewhere and nothing worse.
    ClearSeenUnmarkQueue()
    if n > 0 then KLog("sync", "finished marks: " + n.toStr() + " unmarked here, telling the other devices")
end sub

' Keep the mirror's copy of this kind roughly the size of the store it feeds.
'
' The mirror is one registry blob and nothing prunes it. A "seen" row costs
' three to seven times more there than in kwick_seen — the payload is JSON
' escaped inside more JSON and carries the row bookkeeping too, so a mark that
' costs 25-95 bytes in its own section costs about 185-295 in the mirror. Left
' alone, a member whose phone has a few hundred finished titles would push that
' single blob past the whole app's 16-32 KB registry budget, and a registry
' write past the limit fails SILENTLY. That is a bigger risk than anything the
' marks themselves are worth, and it is one this box already had while it was
' only READING these rows: it hoarded every one it was ever sent.
'
' Worth stating plainly for whoever owns the caps: SeenMaxBytes (4096) was
' sized against kwick_seen's own section, where it buys 43-163 marks. Mirrored,
' those same marks are 13-30 KB — so the real price of the finished-marks
' feature is roughly seven times its stated one, and the number to turn down if
' the budget bites is SeenMaxBytes rather than anything here.
'
' So a mirror row is kept only when this cycle actually stood behind it —
' `live` is the exact set collectSeenPuts just emitted or verified. Anything
' else is a mark this box does not hold: evicted by the cap, belonging to a
' profile that is not here, or a spent tombstone.
'
' DROPPING IS NOT DELETING. The row stays in the locker and on every other
' device; this box simply stops carrying a copy of something it cannot show.
' Nothing here can tombstone, and nothing here can start a push storm: the set
' being kept is the set the emitter produced, in the same cycle, from the same
' helpers, so a row that would be re-emitted next cycle is by construction a
' row that was kept.
'
' Dirty rows are never touched — a tombstone that has not been posted yet is
' the member's own unmark waiting to go up.
sub pruneSeenMirror(mirror as object, live as object)
    drop = []
    for each key in mirror
        r = mirror[key]
        if ToStr(r.kind) = "seen" and r.dirty <> true
            if not live.doesExist(ToStr(key)) then drop.push(ToStr(key))
        end if
    end for
    if drop.count() = 0 then return
    for each k in drop
        mirror.delete(k)
    end for
    ' Plain ASCII on purpose: this line ends up in uploaded member logs.
    KLog("sync", "finished marks: stopped carrying " + drop.count().toStr() + " row(s) this box has no mark for (still on the account)")
end sub

' A local finished-mark key, minus its profile prefix, as the phone's media id.
' The exact inverse of seenLocalKey — they are a pair and must stay one:
'
'     "movie:<rest>"  -> "vod:<rest>"
'     "ep:<rest>"     -> "episode:<rest>"
'
' <rest> passes through whole, source qualifier and all. USB-playlist rows
' ("file:") return "" and stay on this box, the same rule buildSnapshot applies
' to watch history — a stick in this Roku means nothing on anybody's phone.
' Anything else returns "" too: live has no end to reach, so it can never be
' finished.
function seenWireMedia(bare as string) as string
    if Instr(1, bare, "file:") > 0 then return ""
    if bare.left(6) = "movie:" then return "vod:" + Mid(bare, 7)
    if bare.left(3) = "ep:" then return "episode:" + Mid(bare, 4)
    return ""
end function

' A stored "at" as the NUMBER the wire wants, or invalid.
'
' The store keeps it as text on purpose: it is milliseconds since 1970, which
' does not fit the 32-bit integer ToInt() hands back (the same trap kwick_hist
' carries — see mediaBarIdxPut in Store.brs). Val() would give a float and
' FormatJson would then write "1.75604e+12", which is not a timestamp any more
' and would make the row differ from the phone's every single cycle.
'
' So the text is handed to ParseJson, which returns a LongInteger for a number
' that size and is the same parser that produced the phone's value in the first
' place — the two cannot disagree about how to read it. Wrapped in an array
' because a bare number is not valid JSON everywhere.
'
' Anything that is not plain digits is refused rather than guessed at, and the
' caller drops the mark from this cycle: a mark with no trustworthy date is
' better left alone than sent up with an invented one, since the date is what
' the eviction order is decided on at the other end too.
function seenAtNumber(s as string) as dynamic
    if s = "" then return invalid
    if Len(s) > 15 then return invalid
    for i = 0 to Len(s) - 1
        c = Mid(s, i + 1, 1)
        if c < "0" or c > "9" then return invalid
    end for
    p = ParseJson("[" + s + "]")
    if p = invalid then return invalid
    if type(p) <> "roArray" then return invalid
    if p.count() <> 1 then return invalid
    return p[0]
end function

' ---- Source colours from the phone (GAP F1) ---------------------------------
'
' The colour the member painted a source with, taken off the wire and turned
' into the map the cards paint their corner tags from. PULL ONLY — see the
' section note in Store.brs.
'
' ---- Why this rebuilds instead of projecting --------------------------------
'
' Every other kind is projected one row at a time as it arrives. This one
' cannot be, because of what the FIRST cycle of this build looks like.
'
' This box has been carrying "srccol" rows for as long as the member has had a
' phone that emits them: applyRemote writes the mirror before it looks the kind
' up, so rows of a kind this app did not understand were stored anyway, just
' never acted on. And sync is CURSOR-based — a row pulled under an older build
' is behind the cursor forever and will never be offered again. A projector
' alone would therefore leave a member who painted their sources months ago
' with a mirror full of their choices and not one of them on screen, and only
' a colour they changed AFTER upgrading would ever show up.
'
' The same reasoning is why this runs every cycle rather than once behind a
' flag, and it is the second half of the same problem: a source ADDED to this
' box today has to find the colour the account already has for it, and that
' colour arrived long before the source did. Rebuilding from the whole mirror
' answers both with one walk and no bookkeeping.
'
' It is also why this box needs none of the phone's adoption machinery
' (adoptFromMirror, syncSourceColorsSeen). That exists to tell "the member just
' added this source" from "the member just cleared its colour", which are the
' same thing seen from the local map. This device cannot clear a colour — there
' is no picker — so the second case does not exist here and the question does
' not arise. THAT CHANGES THE DAY A PICKER LANDS: a Roku that can paint a
' source can also unpaint one, and a rebuild like this would put back every
' colour the member ever removed. See the report note on what Settings needs.
sub rebuildSrcColors(mirror as object)
    ' Wire token -> palette index, from every row the mirror holds.
    wire = {}
    for each key in mirror
        r = mirror[key]
        if ToStr(r.kind) = "srccol" and r.deleted <> true and ToStr(r.data) <> ""
            d = ParseJson(ToStr(r.data))
            if d <> invalid and type(d) = "roAssociativeArray"
                src = ToStr(GetField(d, "src"))
                c = GetField(d, "c")
                ' The key and the payload have to agree, the same test the
                ' phone makes (source_color_sync_types.dart:311). Acting on
                ' the payload alone would let a malformed key paint the wrong
                ' source, and nothing could ever find it again to unpaint it.
                if src <> "" and c <> invalid and ToStr(key) = "srccol:" + src
                    ci = ToInt(c)
                    if ci >= 0 then wire[src] = ci
                end if
            end if
        end if
    end for

    ' Local token -> index, for the sources this box actually has. A colour for
    ' a source that is not here is CARRIED and not written down: the mirror
    ' already holds it, this device never emits it, and the day that source is
    ' added the next cycle picks it up. (A phone's Jellyfin or Plex row is the
    ' ordinary case of that — this app has no such sources at all.)
    out = {}
    for each p in LoadProviders()
        tok = SrcTokenFor(p)
        w = tok
        if tok = "" then w = KwickTvSrcWireToken()
        if wire.doesExist(w) then out[SrcColorMemoKey(tok)] = wire[w]
    end for

    ' Publishing is unconditional even when the stored map did not change: the
    ' global is session state and starts empty on every launch, so the first
    ' cycle after a cold start has to fill it whether or not anything is new.
    changed = SaveSyncedSrcColors(out)
    RefreshSrcColorIndex()
    if changed then KLog("sync", "source colours: now painting " + out.count().toStr() + " of this box's sources from the account")
end sub

' Watch-history from the phone -> Roku resume points (PULL-ONLY for now:
' the Roku's resume store has no titles/posters yet, so pushing would fill
' the phone's Continue Watching with blank entries — T7 tracks the rest).
' media "vod:<id>" -> movie resume; "episode:<id>" -> episode resume.
sub projectHist(key as string, deleted as boolean, data as object)
    parts = splitFirstColon(Mid(key, Len("hist:") + 1))
    if parts = invalid then return
    sid = parts.head
    if deleted
        ' History cleared on another device — drop the local resume point
        ' (the media id is right in the key).
        rk = histResumeKey(parts.tail)
        if rk <> ""
            prefix = ""
            if sid <> "default" then prefix = sid + "|"
            for each section in ["kwick_resume", "kwick_hist"]
                sec = CreateObject("roRegistrySection", section)
                if sec.exists(prefix + rk)
                    sec.delete(prefix + rk)
                    sec.flush()
                end if
            end for
        end if
        return
    end if
    if data = invalid then return
    media = ToStr(GetField(data, "media"))
    posS = ToInt(GetField(data, "pos"))
    durS = ToInt(GetField(data, "dur"))
    ' Live has no resume point to keep, but it IS watch history: without this
    ' a channel watched on the phone never reached the Roku's Recently
    ' Watched Channels row, which only ever showed what was played on the
    ' Roku itself. Handled before the posS guard because a live row's
    ' position is meaningless and often zero.
    if ToStr(GetField(data, "kind")) = "live"
        projectHistChannel(sid, media, data)
        return
    end if

    if media = "" or posS <= 0 then return

    resumeKey = ""
    if media.left(4) = "vod:"
        ' Merged-source ids look like "src~123" — kept WHOLE, because local
        ' resume keys now use the same source-qualified shape. (Stripping
        ' the src used to land another source's position on the same-
        ' numbered KwickTV movie.)
        resumeKey = "movie:" + Mid(media, 5)
    else if media.left(8) = "episode:"
        resumeKey = "ep:" + Mid(media, 9)
    else
        return   ' live/recording history has no Roku resume counterpart
    end if

    ' Per-profile resume namespace (the default profile owns bare keys).
    prefix = ""
    if sid <> "default" then prefix = sid + "|"
    sec = CreateObject("roRegistrySection", "kwick_resume")
    if durS > 0 and posS > Int(durS * 0.95)
        ' Finished on the other device — clear any local resume point.
        if sec.exists(prefix + resumeKey)
            sec.delete(prefix + resumeKey)
            sec.flush()
        end if
    else
        sec.write(prefix + resumeKey, posS.toStr() + "|" + durS.toStr())
        sec.flush()
    end if

    projectHistRecent(sid, media, data)
end sub

' A synced LIVE watch-history row -> that profile's Recently Watched
' Channels. Android's live media id is the channel id with no kind prefix
' (`mediaId: channel.id`), in the same "<src>~<id>" shape as everything else.
sub projectHistChannel(sid as string, media as string, data as object)
    if media = "" then return
    ' A LIVE media id is the channel's source-qualified id in COLON form,
    ' "xt:<host>:<streamId>" (KwickSync's live shape), NOT the "~" form VOD
    ' uses — so SplitSrcQualifiedId parsed it wrong and stored the whole string
    ' as the stream id, which then built .../live/u/p/xt:kwick.cc:1038.m3u8 and
    ' never played. Parse it the same way projectFavCh does: the stream id is
    ' the trailing segment, the prefix is the src token, and the KwickTV login's
    ' own host maps to the bare (src "") store shape.
    streamId = lastSegment(media)
    if streamId = "" then return
    token = ""
    if Len(media) > Len(streamId) then token = Left(media, Len(media) - Len(streamId) - 1)
    kprov = KwickTvProvider()
    if kprov <> invalid and token = "xt:" + HostOf(ToStr(kprov.server)) then token = ""

    entry = { streamId: streamId, name: ToStr(GetField(data, "title")), logo: ToStr(GetField(data, "poster")), url: "" }
    sp = { src: token, id: streamId }
    if token <> "" then entry["src"] = token

    EnsureProfileExists(sid)
    storeKey = "recent_channels" + ProfileSuffixFor(sid)
    ' Same per-source cap as PushRecentChannel (20).
    kept = [entry]
    own = 1
    for each r in LoadJsonArray(storeKey)
        rsrc = ""
        if GetField(r, "src") <> invalid then rsrc = ToStr(r.src)
        if ToStr(r.streamId) <> "" or ToStr(r.url) <> ""
            same = (rsrc = sp.src and ToStr(r.streamId) = sp.id)
            if not same
                if rsrc = sp.src
                    if own < 20
                        kept.push(r)
                        own = own + 1
                    end if
                else
                    kept.push(r)
                end if
            end if
        end if
    end for
    SaveJsonArray(storeKey, kept)
end sub

' A synced watch-history row -> that profile's Recently Watched list.
'
' Until now the pull half wrote ONLY the resume point, so a film watched on
' the phone had the right position waiting on the Roku but never appeared on
' Home — the member had to go and find it before the sync showed at all.
' Recently Watched is its own registry list, written only by the two detail
' screens when something is played HERE, so anything watched elsewhere was
' simply missing from it.
'
' This does not reintroduce the churn the push half guards against: that
' half reads kwick_hist + kwick_resume and never this list, so a row landing
' here cannot echo back out.
sub projectHistRecent(sid as string, media as string, data as object)
    kind = ""
    tail = ""
    if media.left(4) = "vod:"
        kind = "movie"
        tail = Mid(media, 5)
    else if media.left(8) = "episode:"
        ' Recents hold the SERIES, exactly as SeriesDetailScreen does locally
        ' — an episode id here would open nothing. Android writes the parent
        ' WITH its kind prefix ("series:<ref>", see series_detail_screen.dart),
        ' which has to come off or the source split below eats it.
        kind = "series"
        tail = ToStr(GetField(data, "parent"))
        if tail.left(7) = "series:" then tail = Mid(tail, 8)
        if tail.left(6) = "movie:" then tail = Mid(tail, 7)
    else
        return
    end if
    if tail = "" then return

    ' Media ids are "<src>~<id>" off-KwickTV and bare on it. The recents list
    ' keeps the id BARE with the source in its own field.
    sp = SplitSrcQualifiedId(tail)
    src = sp.src
    id = sp.id
    if id = "" then return

    art = ToStr(GetField(data, "poster"))
    if art = "" then art = ToStr(GetField(data, "icon"))
    entry = { kind: kind, id: id, name: ToStr(GetField(data, "title")), icon: art, ext: ToStr(GetField(data, "ext")) }
    entry["src"] = src

    pushSyncedRecentVod(sid, entry)
end sub

' One assembled Recently Watched row into that profile's list.
'
' Shared by the IPTV half above and the media-server half below, on purpose:
' both have to obey the SAME per-source cap and the same backdrop rule, and two
' copies of that would drift the first time one of them was tuned. `entry` must
' already carry kind, id, name, icon, ext and src.
sub pushSyncedRecentVod(sid as string, entry as object)
    src = ToStr(GetField(entry, "src"))
    kind = ToStr(GetField(entry, "kind"))
    id = ToStr(GetField(entry, "id"))
    if id = "" then return

    EnsureProfileExists(sid)
    storeKey = "recent_vod" + ProfileSuffixFor(sid)

    ' Carry the backdrop forward. The phone's watch history has no such field,
    ' so a row rebuilt from it arrives with none - and the loop below drops
    ' the row it replaces. Without this, watching something on the phone would
    ' quietly strip the Media Bar's picture for that title on this TV, and it
    ' would not come back until the member opened its page here again. Same
    ' inherit-from-the-row-being-replaced rule PushRecentVod uses.
    for each r in LoadJsonArray(storeKey)
        rsrc0 = ""
        if GetField(r, "src") <> invalid then rsrc0 = ToStr(r.src)
        if rsrc0 = src and ToStr(r.kind) = kind and ToStr(r.id) = id
            oldBd = ToStr(GetField(r, "bd"))
            if oldBd <> "" then entry["bd"] = oldBd
            exit for
        end if
    end for
    ' Same per-source cap as PushRecentVod: one source's viewing must never
    ' push another's recents off the list.
    kept = [entry]
    own = 1
    for each r in LoadJsonArray(storeKey)
        rsrc = ""
        if GetField(r, "src") <> invalid then rsrc = ToStr(r.src)
        same = (rsrc = src and ToStr(r.kind) = kind and ToStr(r.id) = id)
        if not same
            if rsrc = src
                if own < 30
                    kept.push(r)
                    own = own + 1
                end if
            else
                kept.push(r)
            end if
        end if
    end for
    SaveJsonArray(storeKey, kept)
end sub

' ---- A member's OWN media server: favourites and watch progress -------------
'
' Two kinds of their own, "favmedia" and "medhist", because a Jellyfin or Emby
' record cannot travel as an ordinary favourite or an ordinary history row: a
' build without media servers cannot rebuild one, so it would push a deletion
' for it within ninety seconds of receiving it, and that deletion would land on
' the device the member actually made it on. A kind an old build has never
' heard of is simply carried, which is what makes these safe to add at all.
'
' "favmedia" IS STILL READ-ONLY. This box has no way to favourite a film on a
' media server that another device could not already tell it about, and adding
' a second writer is a second chance to get the shape wrong.
'
' "medhist" NOW WRITES, in collectMedHistPuts below — the previous build listened
' for one release so the shapes could be checked against real rows first, which
' is what that pass bought. Two things about how it writes are load-bearing:
'
'   NOTHING MEDIA EVER ENTERS `snap`. The push half is a collector of its own,
'   like collectSeenPuts, so it can only add or update. reconcile() reads a key
'   that has left the snapshot as a deletion, and every reason a resume point
'   leaves this box's registry — finished past 95%, a full registry, a server
'   removed, this box's own smaller wire cap — is a reason that is NOT the
'   member deleting anything. There is no cap value that tells those apart, so
'   the kind stays out of the snapshot instead.
'
'   IT ONLY SPEAKS WITH A NEWER WORD. Both reconcilers decide "has this
'   changed?" by comparing the row as a RAW SERIALISED STRING, and this box
'   does NOT take the phone's copy of a title's title, episode label or watch
'   time into its own kwick_hist row. So a row the phone has since updated
'   would rebuild here in this box's older shape, differ from the mirror, and
'   the two devices would push their two versions at each other every ninety
'   seconds for ever. medHistPut therefore refuses to write unless this box's
'   own watch time is STRICTLY NEWER than the copy it is holding. The time only
'   moves when the member actually watches something here, so the exchange
'   cannot run away.
'
' NO ADDRESS TRAVELS on either kind, and that is the point of them rather than
' a detail: the sending device's address for the member's server is very often
' not reachable from here, and it is the member's own home machine besides. So
' every address — the stream and the artwork alike — is rebuilt on this box
' from this box's own copy of the server, which costs no request.

' ---- Media-server watch progress: the PUSH half ------------------------------
'
' Watch a film on the member's own Jellyfin HERE and it should appear in
' Continue Watching on their phone. That is the whole feature. Everything below
' is about it being that and NOTHING else — in particular, about it never being
' able to take a resume point OFF their phone.
'
' ---- Why this is not in buildSnapshot ---------------------------------------
'
' The obvious way to push a kind is to add it to buildSnapshot and let reconcile
' do the rest. reconcile reads a key that has stopped appearing in the snapshot
' as a DELETION, so that only works when "this box no longer has the row" means
' "the member got rid of it". For these rows it means five other things first:
'
'   finished    a title watched past 95% has its resume point thrown away, and
'               ClearResume takes the kwick_hist row with it. Perfectly normal,
'               and it would post a deletion for a film the member just watched.
'   full        a registry write past the 16-32 KB limit fails SILENTLY, so the
'               row simply is not there next time.
'   removed     the member takes the server off this box; MediaSrcTokenIsHere
'               stops answering for it and nothing can be built.
'   capped      this box sends fewer rows than the phone keeps (see
'               mediaHistWireCap) — so most of a busy member's media history is
'               outside this box's snapshot by design.
'   profile     a profile with no syncId, or a pristine Default this box is
'               deliberately being quiet about.
'
' No cap value and no extra read makes any of those distinguishable from a
' member clearing their history, which is why the kind is collected HERE,
' outside the snapshot, exactly as finished marks are. It can only ever ADD or
' UPDATE. This box never tombstones a medhist row, at all, ever — deletions
' travel the other way only (projectMedHist applies the phone's).
'
' ---- The re-push trap, and what actually stops it ---------------------------
'
' Both reconcilers ask "has this changed?" by comparing the row as a RAW
' SERIALISED STRING. This box does not adopt the phone's copy of a title, an
' episode label or a watch time into its own kwick_hist row — projectMedHist
' writes the resume point and the Recently Watched entry and nothing else — so
' after the phone updates a row, this box would rebuild its OWN older version,
' see a mismatch, and push it back. The phone's applySynced refuses a record
' older than the one it holds, regenerates its own, sees a mismatch in turn,
' and pushes that. Forever, every ninety seconds, per row.
'
' So medHistPut will not write unless this box's own watch time is STRICTLY
' NEWER than whatever it is already holding for that key. The time comes from
' kwick_hist and only moves when the member actually watches something on this
' television, so there is no sequence of syncs that can make this box speak
' twice about one watch. The cost is named rather than hidden: when the phone
' holds a newer copy, this box stays quiet and the phone's title, label and
' date stand on the account. That is the right way round — the newer word is
' the truer one — and the resume POSITION is unaffected either way, because
' projectMedHist has already written the phone's.
'
' ---- What never goes out -----------------------------------------------------
'
' No address of any kind: not the stream URL, not the poster URL, not the
' server's hostname. The payload is the profile, the server's own id, the
' server's own item ids, a title, an episode label, and three numbers. And the
' server id is checked for being a REAL one — a server that has been paired but
' not signed in to yet answers to a stand-in built from its address
' ("jf:@<host>"), and MediaSrcTokenIsHere says yes to that quite happily,
' because it is comparing the stand-in against itself. See realMediaWireTokens.

' How many media rows this box will put on the wire per profile.
'
' DELIBERATELY BELOW the phone's fifty (kMediaHistoryCap, media_sync_types.dart)
' and it is a registry decision, not a protocol one. A medhist row costs roughly
' 400 bytes once it is sitting in the mirror — the payload is JSON escaped
' inside more JSON, plus its key and its row bookkeeping — and the mirror is one
' blob inside the 16-32 KB this whole app gets, where a write past the limit
' fails SILENTLY and takes whatever else was mid-write with it. Fifty rows would
' be about 20 KB on their own, which is the budget. Twenty is about 8 KB, which
' is still a lot and is the number to turn down first if the registry bites on
' a real box.
'
' Sending fewer than the phone keeps costs NOTHING here, and that is only true
' because of the paragraph above: nothing this box leaves out is read as a
' deletion. The phone keeps its own fifty; this box simply has less to say. The
' phone's cap deletes and so has to be careful about which rows fall outside it
' (hence its four-times over-read); this one does not, so the rows that are
' skipped for a server this box has lost cost no slot either — only what is
' actually EMITTED is counted, which is the same behaviour the over-read exists
' to produce.
function mediaHistWireCap() as integer
    return 20
end function

' Media-server resume points watched ON THIS BOX -> the account.
'
' Reads the same two registry sections buildSnapshot's hist loop reads —
' kwick_hist for the metadata the player writes beside every resume point, and
' kwick_resume for the position — and takes the rows the hist loop deliberately
' steps over: the ones whose source token is a member's own Jellyfin or Emby.
' A row that exists ONLY because it was pulled from the phone has no kwick_hist
' entry (projectMedHist does not write one), so it is invisible here and can
' never echo back out.
sub collectMedHistPuts(mirror as object, nowMs as dynamic)
    ' Built ONCE, not once per row. MediaSrcTokenIsHere re-reads and re-parses
    ' the whole provider list every time it is asked, and asking it per history
    ' key would be a few dozen registry reads a cycle for an answer that cannot
    ' change while this runs.
    '
    ' Also the cheap exit for every member who has no media server, or whose
    ' only one has not been signed in to yet: nothing else below is touched.
    tokens = realMediaWireTokens()
    if tokens.count() = 0 then return
    hsec = CreateObject("roRegistrySection", "kwick_hist")
    keys = hsec.getKeyList()
    if keys.count() = 0 then return
    rsec = CreateObject("roRegistrySection", "kwick_resume")

    ' The same rule buildSnapshot and collectSeenPuts use: a blank
    ' auto-created Default is a SHARED cross-device identity this box has not
    ' earned the right to speak for until the locker's copy has arrived.
    hideBlankDefault = HasOnlyPristineDefaultProfile() and not mirror.doesExist("profile:default")
    n = 0
    for each p in LoadProfiles()
        sid = ToStr(p.syncId)
        if hideBlankDefault then sid = ""
        if sid <> ""
            ' Read off p.id, not the sync id — the same reason collectSeenPuts
            ' gives: they are the same string on every profile this app can
            ' make, and writing it this way means they would not have to be.
            prefix = ""
            if ToStr(p.id) <> "default" then prefix = ToStr(p.id) + "|"
            cand = []
            for each k in keys
                ks = ToStr(k)
                mine = false
                if prefix = ""
                    mine = (Instr(1, ks, "|") = 0)   ' default owns the bare keys
                else
                    mine = (Len(ks) > Len(prefix) and ks.left(Len(prefix)) = prefix)
                end if
                if mine
                    ent = medHistRowFor(sid, Mid(ks, Len(prefix) + 1), ks, hsec, rsec, tokens)
                    if ent <> invalid then cand.push(ent)
                end if
            end for
            sortMedHistRows(cand)
            emitted = 0
            for each ent in cand
                if emitted >= mediaHistWireCap() then exit for
                emitted = emitted + 1
                if medHistPut(mirror, ent, nowMs) then n = n + 1
            end for
        end if
    end for
    ' Plain ASCII on purpose: this line ends up in uploaded member logs.
    if n > 0 then KLog("sync", "media-server watch progress: " + n.toStr() + " to push")
end sub

' One kwick_hist key turned into the wire row it would become, or invalid.
'
' `bare` is the key with the profile prefix already taken off; `storeKey` is the
' whole thing, which is what the two sections are actually read with.
'
' Every refusal below is silent and costs nothing, because this kind cannot
' tombstone: a row this cannot build simply is not mentioned, and not mentioning
' a row is not a deletion here.
function medHistRowFor(sid as string, bare as string, storeKey as string, hsec as object, rsec as object, tokens as object) as dynamic
    ' Which half of the pair this is, read off the BARE key rather than out of
    ' the stored metadata. The player writes its "kind" from the FULL resume
    ' key (PlayerScreen.brs, saveProgress), so on every profile except the
    ' default it calls every episode a movie — markFinished had to stop
    ' trusting the same field for the same reason. The key cannot lie.
    ref = ""
    wireMedia = ""
    recKind = ""
    if bare.left(6) = "movie:"
        ref = Mid(bare, 7)
        wireMedia = "vod:"
        recKind = "movie"
    else if bare.left(3) = "ep:"
        ref = Mid(bare, 4)
        wireMedia = "episode:"
        recKind = "episode"
    else
        return invalid
    end if

    ' Local ids are "<src>~<id>". The wire's media id is the SERVER'S OWN id
    ' with no server named beside it — "vod:<guid>" / "episode:<guid>" — which
    ' is what lets two devices produce the same key for the same resume point.
    ' The server is named once, in "src".
    sp = SplitSrcQualifiedId(ref)
    if sp.id = "" then return invalid
    ' Not a media server's row at all (an IPTV title, a USB one), or one whose
    ' server this box no longer has, or one filed under the stand-in name a
    ' server answers to before it has been signed in to. All three are silent.
    if not tokens.doesExist(sp.src) then return invalid
    wireMedia = wireMedia + sp.id

    ' Both halves, the same pairing the hist loop insists on. A resume point
    ' with no metadata beside it is a row that arrived from another device.
    if not rsec.exists(storeKey) then return invalid
    rparts = rsec.read(storeKey).split("|")
    if rparts.count() < 2 then return invalid
    posS = ToInt(rparts[0])
    if posS <= 0 then return invalid
    durS = ToInt(rparts[1])

    hmeta = ParseJson(hsec.read(storeKey))
    if hmeta = invalid then return invalid
    if type(hmeta) <> "roAssociativeArray" then return invalid

    atVal = medHistAtValue(GetField(hmeta, "at"))
    if atVal = invalid then return invalid

    parentWire = medHistParentWire(ToStr(GetField(hmeta, "parent")), sp.src)
    if parentWire = "" then return invalid

    ' FIELD ORDER IS PART OF THE WIRE, not a style choice. The reconcilers on
    ' both sides compare the ENCODED STRING, so a payload assembled in a
    ' different order than the phone's map literal
    ' (media_sync_types.dart:651-662 — p, src, kind, title, sub?, media,
    ' parent, at, pos, dur?) would look changed on every cycle and re-push for
    ' ever. Brackets rather than dot notation for the tail: an identifier key
    ' is folded to lower case, and "pos" is a reserved word besides.
    d = { p: sid, src: sp.src, kind: recKind, title: ToStr(GetField(hmeta, "title")) }
    if ToStr(GetField(hmeta, "sub")) <> "" then d["sub"] = ToStr(GetField(hmeta, "sub"))
    d["media"] = wireMedia
    d["parent"] = parentWire
    d["at"] = atVal
    d["pos"] = posS
    ' Absent, not zero, when unknown — the phone omits the key entirely
    ' (`if (e.durationSeconds != null)`), and a zero written where it omits
    ' would differ from its copy on every cycle.
    if durS > 0 then d["dur"] = durS

    return { sid: sid, media: wireMedia, at: atVal, data: d }
end function

' The stored watch time as the NUMBER the wire wants, or invalid.
'
' kwick_hist keeps it in MILLISECONDS since 1970, which does NOT fit the 32-bit
' integer ToInt() hands back (the same trap mediaBarIdxPut carries in
' Store.brs), so it is never converted — only checked and passed through.
' ParseJson returns a LongInteger for a number that size and FormatJson renders
' it exactly; a value that had somehow become a float would render as
' "1.75604e+12", which is not a time any more and would differ from the phone's
' copy every single cycle. Anything that does not render as plain digits is
' refused and the row is left out, rather than sent up as a number nobody can
' read — and the phone's own rounding rule (wholeSeconds, media_sync_types.dart)
' is satisfied for free, because this box only ever writes whole seconds times a
' thousand.
function medHistAtValue(v as dynamic) as dynamic
    if v = invalid then return invalid
    tok = ""
    try
        tok = FormatJson([v])
    catch e
        tok = ""
    end try
    if Len(tok) < 3 then return invalid
    body = Mid(tok, 2, Len(tok) - 2)
    if Len(body) > 15 then return invalid
    for i = 0 to Len(body) - 1
        c = Mid(body, i + 1, 1)
        if c < "0" or c > "9" then return invalid
    end for
    return v
end function

' A local parent id as the wire's. Local is "<type>:<src>~<id>"; the wire
' carries the SERVER'S own parent and nothing else — "movie:<guid>" for a film,
' "series:<guid>" for an episode — because the local "<src>~<id>" form names a
' source row that means nothing on another device.
'
' The source inside the parent has to be the SAME server the media id named. A
' parent that disagrees is a row this build does not understand well enough to
' describe, and describing it wrongly would put an episode under the wrong show
' on the member's phone.
function medHistParentWire(localParent as string, tokenSrc as string) as string
    if localParent = "" then return ""
    sep = Instr(1, localParent, ":")
    if sep <= 1 then return ""
    kindPart = Left(localParent, sep - 1)
    if kindPart <> "movie" and kindPart <> "series" then return ""
    sp = SplitSrcQualifiedId(Mid(localParent, sep + 1))
    if sp.id = "" then return ""
    if sp.src <> tokenSrc then return ""
    return kindPart + ":" + sp.id
end function

' Every media server on this box that has told us its OWN ID, as a set of the
' tokens the wire uses. Built once a cycle by collectMedHistPuts.
'
' The "@" test is the one that matters and MediaSrcTokenIsHere cannot do it for
' us here. A server that has been paired but not signed in to yet answers to a
' stand-in name built from its ADDRESS ("jf:@<host>", MsPendingSrcToken in
' MediaServer.brs). On the RECEIVING side that is harmless — a real token can
' never equal it, so those rows are simply let go of — but on the SENDING side
' MsSrcToken hands the stand-in straight back, and putting it on the wire would
' publish the address of the machine in the member's house to their account.
' That is the single thing these kinds exist to prevent. A real server id is
' plain hex and can never contain "@", which is the whole test.
'
' Such a row is not lost, only quiet: RunPendingSrcTokenMove renames its resume
' and history keys to the real token the moment the sign-in lands, and the next
' cycle picks it up.
function realMediaWireTokens() as object
    out = {}
    for each p in MediaServerProviders()
        t = MsSrcToken(p)
        if t <> "" and IsMediaSrcToken(t) and Instr(1, t, "@") = 0 then out[t] = true
    end for
    return out
end function

' Newest first, ties broken by the media id DESCENDING.
'
' The tie-break is not decoration, and it is copied from the phone deliberately
' (watch_history_repository.dart, recentSyncableSide). Watch times are whole
' seconds and a synced row keeps the sender's second exactly, so two rows tying
' at the cap boundary is ordinary — and two devices breaking that tie by their
' own arbitrary order would each choose a different set to stand behind. It
' cannot cost a deletion here, because this kind never deletes, but it would
' make which rows reach the phone depend on the order a registry section
' happened to hand its keys back, which is no way to answer a support question.
'
' A plain insertion sort on purpose: this list is bounded by what kwick_hist can
' hold inside a 16-32 KB registry, which is a few dozen rows at the very most.
sub sortMedHistRows(rows as object)
    for i = 1 to rows.count() - 1
        cur = rows[i]
        j = i - 1
        while j >= 0 and medHistBefore(cur, rows[j])
            rows[j + 1] = rows[j]
            j = j - 1
        end while
        rows[j + 1] = cur
    end for
end sub

function medHistBefore(a as object, b as object) as boolean
    if a.at > b.at then return true
    if a.at < b.at then return false
    return a.media > b.media
end function

' One built row into the mirror as a dirty put — if, and only if, this box has
' something newer to say than the copy it is already holding.
'
' Answers true when it wrote one.
'
' ORIGIN "REMOTE" IS NOT A LIE ABOUT WHERE THE ROW CAME FROM, it is the plain
' truth about deletion authority: this device does not own these rows'
' existence and must never tombstone them. reconcile's deletion arm tests
' exactly that field, so this is already safe, and the kind guard beside that
' test is a second, independent lock.
function medHistPut(mirror as object, ent as object, nowMs as dynamic) as boolean
    wk = "medhist:" + ent.sid + ":" + ent.media
    dataJson = FormatJson(ent.data)
    ex = mirror[wk]
    if ex <> invalid
        ' Byte-identical and live: there is nothing to say and saying it would
        ' be the churn this whole kind is careful about.
        if ex.deleted <> true and ToStr(ex.data) = dataJson then return false
        ' THE ONE RULE THAT STOPS THE PING-PONG. Read the section note above.
        ' A tombstone is measured by when it was made, because it carries no
        ' payload to read a time out of — so a resume point the member cleared
        ' on their phone stays cleared unless they have watched it HERE since.
        theirAt = 0&
        if ex.deleted = true
            theirAt = ex.ts
        else
            theirAt = medHistMirrorAt(ToStr(ex.data))
        end if
        if not (ent.at > theirAt) then return false
    end if
    mirror[wk] = { kind: "medhist", data: dataJson, ts: nowMs, deleted: false, dirty: true, origin: "remote" }
    return true
end function

' The "at" out of a mirrored row's stored payload, or 0 when it cannot be read.
'
' Zero lets this box speak, which is the right direction for a row it cannot
' understand: the thing it would write is built from a real watch on this
' television, and once written the next cycle compares against a copy this box
' wrote itself and can read. So an unreadable mirror row costs exactly one push
' and then heals, rather than either looping or going permanently quiet.
function medHistMirrorAt(dataJson as string) as dynamic
    if dataJson = "" then return 0&
    d = ParseJson(dataJson)
    if d = invalid then return 0&
    if type(d) <> "roAssociativeArray" then return 0&
    v = medHistAtValue(GetField(d, "at"))
    if v = invalid then return 0&
    return v
end function

' A favourited film or show on a media server -> this profile's favourites.
'
' The key is "favmedia:<profileSyncId>:<src>:<type>:<id>", and everything after
' the profile is CHARACTER FOR CHARACTER the key this app already builds for a
' favourite of its own ("<src>:<kind>:<id>", see projectFavVod and
' buildSnapshot) — so the row slots into the same one list the member sees, and
' a delete finds the same entry a put would have replaced.
sub projectFavMedia(key as string, deleted as boolean, data as object)
    parts = splitFirstColon(Mid(key, Len("favmedia:") + 1))
    if parts = invalid then return
    sid = parts.head
    vodKey = parts.tail
    if vodKey = "" then return

    ' The payload is the record's identity and nothing else: {p, src, type,
    ' id}. No title and no artwork travel — see the section note. Read BEFORE
    ' the list is touched, because a put this build cannot use must leave the
    ' member's favourites exactly as they were: only a real deletion, or a put
    ' that will be re-added below, may take an entry off the list.
    tokenSrc = ""
    itemId = ""
    favKind = "movie"
    if not deleted
        if data = invalid then return
        tokenSrc = ToStr(GetField(data, "src"))
        itemId = ToStr(GetField(data, "id"))
        if ToStr(GetField(data, "type")) <> "" then favKind = ToStr(GetField(data, "type"))
        ' Asked again even though applyRemote already asked it, because this is
        ' the line that writes to the member's real favourites list and it must
        ' not depend on a caller having checked. A favourite for a server that
        ' is not here would be a poster on the favourites page that cannot open.
        if itemId = "" or not MediaSrcTokenIsHere(tokenSrc) then return
    end if

    storeKey = "fav_vod" + ProfileSuffixFor(sid)
    kept = []
    for each it in LoadJsonArray(storeKey)
        isrc = ""
        if GetField(it, "src") <> invalid then isrc = ToStr(it.src)
        ikey = ToStr(it.kind) + ":" + ToStr(it.id)
        if isrc <> "" then ikey = isrc + ":" + ikey
        if ikey <> vodKey then kept.push(it)
    end for

    if not deleted
        EnsureProfileExists(sid)
        ' The NAME is not on the wire and this box has no stored catalogue to
        ' look it up in, so a favourite made on the phone arrives here with a
        ' poster and no caption until the member opens it. That is a known gap
        ' and it is named in the report; it is not a reason to write a blank
        ' poster as well, which would set EnrichTask hunting the member's IPTV
        ' panel for it on every visit to Home (see MediaSrcPosterUrl).
        entry = { kind: favKind, id: itemId, name: "", icon: MediaSrcPosterUrl(tokenSrc, itemId), ext: "" }
        entry["src"] = tokenSrc
        kept.push(entry)
    end if
    SaveJsonArray(storeKey, kept)
end sub

' Watch progress on a media server -> this profile's resume point and its
' Recently Watched list.
'
' The key is "medhist:<profileSyncId>:<mediaId>" and the media id is
' "vod:<guid>" or "episode:<guid>" — the SERVER'S own id for the item, with NO
' server named in the key at all. That matches the IPTV "hist" kind and is
' deliberate: two devices have to produce the same key for the same resume
' point or they push against each other forever, and the profile plus the
' server's own item id is the one pair that does not depend on how a device
' reaches the box.
'
' Locally the same record is keyed the way this app keys everything else,
' "<kind>:<src>~<id>", so the src comes out of the PAYLOAD rather than the key.
sub projectMedHist(key as string, deleted as boolean, data as object)
    parts = splitFirstColon(Mid(key, Len("medhist:") + 1))
    if parts = invalid then return
    sid = parts.head
    media = parts.tail

    prefix = ""
    if sid <> "default" then prefix = sid + "|"

    if deleted
        ' History cleared on another device. The key names no server, so the
        ' one local row it can mean is looked for under each media server this
        ' box has — a handful at most, and a guid can only belong to one of
        ' them. Nothing is created on the strength of a deletion.
        bareKey = histResumeKey(media)
        if bareKey = "" then return
        sepAt = Instr(1, bareKey, ":")
        if sepAt <= 0 then return
        for each p in MediaServerProviders()
            localKey = prefix + Left(bareKey, sepAt) + MsSrcToken(p) + "~" + Mid(bareKey, sepAt + 1)
            for each section in ["kwick_resume", "kwick_hist"]
                sec = CreateObject("roRegistrySection", section)
                if sec.exists(localKey)
                    sec.delete(localKey)
                    sec.flush()
                end if
            end for
        end for
        return
    end if

    if data = invalid then return
    tokenSrc = ToStr(GetField(data, "src"))
    if not MediaSrcTokenIsHere(tokenSrc) then return
    guid = ""
    recKind = ""
    if media.left(4) = "vod:"
        guid = Mid(media, 5)
        recKind = "movie"
    else if media.left(8) = "episode:"
        guid = Mid(media, 9)
        recKind = "series"
    else
        return
    end if
    if guid = "" then return

    posS = ToInt(GetField(data, "pos"))
    durS = ToInt(GetField(data, "dur"))
    if posS <= 0 then return

    resumeKey = "movie:" + tokenSrc + "~" + guid
    if recKind = "series" then resumeKey = "ep:" + tokenSrc + "~" + guid

    sec = CreateObject("roRegistrySection", "kwick_resume")
    if durS > 0 and posS > Int(durS * 0.95)
        ' Finished on the other device — clear any local resume point, the
        ' same rule SaveResume applies to something finished on this box.
        if sec.exists(prefix + resumeKey)
            sec.delete(prefix + resumeKey)
            sec.flush()
        end if
    else
        sec.write(prefix + resumeKey, posS.toStr() + "|" + durS.toStr())
        sec.flush()
    end if

    ' Recently Watched holds the SERIES for an episode, exactly as the local
    ' series page does — an episode id there would open nothing. The parent on
    ' the wire is the server's own id for it ("series:<guid>" / "movie:<guid>"),
    ' never this box's local "<src>~<id>" form, so it needs no unpicking.
    recId = guid
    if recKind = "series"
        parentRef = ToStr(GetField(data, "parent"))
        atColon = Instr(1, parentRef, ":")
        if atColon <= 0 then return
        recId = Mid(parentRef, atColon + 1)
        if recId = "" then return
    end if

    entry = { kind: recKind, id: recId, name: ToStr(GetField(data, "title")), icon: MediaSrcPosterUrl(tokenSrc, recId), ext: "" }
    entry["src"] = tokenSrc
    pushSyncedRecentVod(sid, entry)
end sub

sub projectProfile(key as string, deleted as boolean, data as object)
    sid = Mid(key, Len("profile:") + 1)
    if sid = "" then return
    if deleted
        DeleteProfileBySyncId(sid)
        return
    end if
    if data = invalid then return
    name = ToStr(GetField(data, "name"))
    if name = "" then name = "Profile"
    pin = ""
    if GetField(data, "pin") <> invalid then pin = ToStr(GetField(data, "pin"))
    avatar = ""
    if GetField(data, "avatar") <> invalid then avatar = ToStr(GetField(data, "avatar"))
    UpsertProfileBySyncId(sid, name, ToInt(GetField(data, "color")), pin, avatar)
end sub

sub projectFavVod(key as string, deleted as boolean, data as object)
    parts = splitFirstColon(Mid(key, Len("favvod:") + 1))
    if parts = invalid then return
    sid = parts.head
    vodKey = parts.tail
    ' Extra-source rows (xt:/m3u: prefixed) project too, tagged with their
    ' src — Home and the hearts route them by it. They MUST project:
    ' this device now pushes its own extra-source favorites, and a row that
    ' is pushed but whose deletions are ignored would resurrect account-wide
    ' on every sync cycle.
    storeKey = "fav_vod" + ProfileSuffixFor(sid)
    kept = []
    for each it in LoadJsonArray(storeKey)
        isrc = ""
        if GetField(it, "src") <> invalid then isrc = ToStr(it.src)
        ikey = ToStr(it.kind) + ":" + ToStr(it.id)
        if isrc <> "" then ikey = isrc + ":" + ikey
        if ikey <> vodKey then kept.push(it)
    end for
    if not deleted and data <> invalid
        EnsureProfileExists(sid)
        ' Android wire: poster is the artwork field; icon is our own legacy.
        art = ToStr(GetField(data, "poster"))
        if art = "" then art = ToStr(GetField(data, "icon"))
        entry = { kind: ToStr(GetField(data, "type")), id: ToStr(GetField(data, "id")), name: ToStr(GetField(data, "name")), icon: art, ext: ToStr(GetField(data, "ext")) }
        if GetField(data, "src") <> invalid then entry.src = ToStr(GetField(data, "src"))
        kept.push(entry)
    end if
    SaveJsonArray(storeKey, kept)
end sub

sub projectFavList(key as string, deleted as boolean, data as object)
    parts = splitFirstColon(Mid(key, Len("favlist:") + 1))
    if parts = invalid then return
    sid = parts.head
    groupId = parts.tail
    ' Same pinning as the snapshot: synced lists are the KwickTV login's.
    prov = KwickTvProvider()
    if prov = invalid then return
    storeKey = "fav_lists_" + ToStr(prov.id) + ProfileSuffixFor(sid)
    kept = []
    for each g in LoadJsonArray(storeKey)
        if ToStr(g.id) <> groupId then kept.push(g)
    end for
    if not deleted and data <> invalid
        EnsureProfileExists(sid)
        ' Accept both wire shapes: Android's {home, items:[{key,kind,name,
        ' img,route}]} and our own legacy {homeRow, items:[{kind,id,...}]}.
        ' The legacy spelling is read BOTH ways: a build that emitted it
        ' wrote it as an identifier, which BrightScript folds to "homerow",
        ' so the exact-case probe alone was tolerance that could never fire.
        ' Read only — nothing here changes what goes out on the wire.
        home = (GetField(data, "home") = true) or (GetField(data, "homerow") = true) or (GetField(data, "homeRow") = true)
        items = []
        for each wi in ToArray(GetField(data, "items"))
            items.push(listItemFromWire(wi))
        end for
        kept.push({ id: ToStr(GetField(data, "id")), name: ToStr(GetField(data, "name")), homeRow: home, items: items })
    end if
    SaveJsonArray(storeKey, kept)
end sub

sub projectFavCh(key as string, deleted as boolean, data as object)
    parts = splitFirstColon(Mid(key, Len("favch:") + 1))
    if parts = invalid then return
    sid = parts.head
    ch = parts.tail                 ' "xt:host:streamId"
    ' Android M3U ids ("m3u:<url>:<n>") can never name a channel here (its
    ' ids are ordinal, ours are stable) — mirrored, never projected.
    if ch.left(3) <> "xt:" then return
    streamId = lastSegment(ch)
    if streamId = "" then return
    ' Which local source the row belongs to: the prefix before the trailing
    ' streamId is exactly our src token ("xt:<host>"), and the KwickTV
    ' login's own host maps to the bare (src "") store shape.
    token = Left(ch, Len(ch) - Len(streamId) - 1)
    kprov = KwickTvProvider()
    if kprov <> invalid and token = "xt:" + HostOf(ToStr(kprov.server)) then token = ""
    storeKey = "fav_channels" + ProfileSuffixFor(sid)
    kept = []
    for each f in LoadJsonArray(storeKey)
        ' Same id on a DIFFERENT source is a different channel — only the
        ' matching source's row is replaced or removed.
        if ToStr(GetField(f, "src")) <> token or ToStr(f.streamId) <> streamId then kept.push(f)
    end for
    if not deleted
        EnsureProfileExists(sid)
        nm = ""
        lg = ""
        if data <> invalid
            if GetField(data, "name") <> invalid then nm = ToStr(GetField(data, "name"))
            if GetField(data, "logo") <> invalid then lg = ToStr(GetField(data, "logo"))
        end if
        entry = { streamId: streamId, name: nm, logo: lg, url: "" }
        if token <> "" then entry.src = token
        kept.push(entry)
    end if
    SaveJsonArray(storeKey, kept)
end sub

' ---- List-item wire translation ---------------------------------------------
' Store shape: {kind, id, name, icon, ext} (+ wireKey/route kept verbatim when
' the item came from another device, so round trips never churn).
' Wire shape (Android GroupItem): {key, kind, name, img?, route?}.

function listItemToWire(it as object, host as string) as object
    kind = ToStr(it.kind)
    ' A list item's channel id carries ITS OWN source prefix — an item
    ' from a second Xtream or an M3U source must not masquerade as a
    ' KwickTV channel on the wire (Android matches by that prefix).
    isrc = ToStr(GetField(it, "src"))
    chId = "xt:" + host + ":" + ToStr(it.id)
    if isrc <> "" then chId = isrc + ":" + ToStr(it.id)
    ' CASE TRAP, the same one ProviderCustomEpgUrl warns about (Store.brs):
    ' older builds saved this key with dot notation, which folds it to
    ' "wirekey", and ParseJson hands the stored list back CASE-SENSITIVE —
    ' so both spellings are read and whichever one is actually there wins.
    ' Miss it and the key the item arrived with is lost on every save/load
    ' and rebuilt from scratch, which is the churn this whole field prevents.
    wkey = ToStr(GetField(it, "wireKey"))
    if wkey = "" then wkey = ToStr(GetField(it, "wirekey"))
    if wkey = ""
        if kind = "channel"
            wkey = "channel:" + chId
        else
            wkey = kind + ":" + ToStr(it.id)
        end if
    end if
    wroute = ""
    if GetField(it, "route") <> invalid then wroute = ToStr(it.route)
    if wroute = ""
        if kind = "channel"
            wroute = "/channel/" + chId
        else
            wroute = "/" + kind + "/" + ToStr(it.id)
        end if
    end if
    wire = { key: wkey, kind: kind, name: ToStr(it.name) }
    if ToStr(it.icon) <> "" then wire.img = ToStr(it.icon)
    if wroute <> "" then wire.route = wroute
    return wire
end function

function listItemFromWire(wi as object) as object
    kind = ToStr(GetField(wi, "kind"))
    if kind = "" then kind = "channel"
    wkey = ToStr(GetField(wi, "key"))
    ' Derive our id: channels use the trailing streamId of the channel id;
    ' movies/series use the trailing id of "type:id" / "src:type:id".
    id = ToStr(GetField(wi, "id"))   ' legacy Roku shape carried id directly
    if id = "" and wkey <> "" then id = lastSegment(wkey)
    art = ToStr(GetField(wi, "img"))
    if art = "" then art = ToStr(GetField(wi, "icon"))
    entry = { kind: kind, id: id, name: ToStr(GetField(wi, "name")), icon: art, ext: ToStr(GetField(wi, "ext")) }
    ' Brackets, not dot notation — dot-assignment folds this to "wirekey"
    ' and listItemToWire's exact-case read would never find it again. Same
    ' trap, same fix, as SetProviderCustomEpgUrl in Store.brs. ("route" is
    ' safe either way: it is already all lowercase, so nothing to fold.)
    if wkey <> "" then entry["wireKey"] = wkey
    if GetField(wi, "route") <> invalid then entry.route = ToStr(GetField(wi, "route"))
    return entry
end function

' One-time: hist rows pulled before the hist kind existed sat unprojected
' in the mirror — replay them so the phone's existing watch positions show
' up as Roku resume points immediately, not just future ones.
sub replayHistFromMirror(mirror as object)
    ' Flag deliberately bumped to "2". Sync is cursor-based, so history
    ' already pulled never arrives again — and projectHist now fills
    ' Recently Watched as well as the resume point. Without a re-run, a
    ' member's existing phone history would stay missing from Home forever
    ' and only newly watched titles would show up, which reads as the bug
    ' not being fixed. Re-projecting is idempotent: the resume points get
    ' written with the values they already hold.
    if RegRead("hist_recents_backfill3") = "1" then return
    RegWrite("hist_recents_backfill3", "1")
    seen = 0
    nVod = 0
    nEp = 0
    nLive = 0
    nOther = 0
    for each key in mirror
        r = mirror[key]
        if ToStr(r.kind) = "hist" and r.deleted <> true and ToStr(r.data) <> ""
            data = ParseJson(ToStr(r.data))
            if data <> invalid
                seen = seen + 1
                md = ToStr(GetField(data, "media"))
                if md.left(4) = "vod:"
                    nVod = nVod + 1
                else if md.left(8) = "episode:"
                    nEp = nEp + 1
                else if ToStr(GetField(data, "kind")) = "live"
                    nLive = nLive + 1
                else
                    nOther = nOther + 1
                end if
                projectHist(key, false, data)
            end if
        end if
    end for
    ' Broken down by kind on purpose. An empty Recently Watched row cannot
    ' otherwise be told apart from a backfill that silently did nothing, and
    ' the split says which half of the sync is at fault.
    ' Plain ASCII on purpose: this line ends up in uploaded member logs.
    KLog("sync", "watch-history backfill: " + seen.toStr() + " row(s) - " + nVod.toStr() + " movie, " + nEp.toStr() + " episode, " + nLive.toStr() + " live, " + nOther.toStr() + " other")
end sub

' One-time: project the finished marks ALREADY sitting in the mirror.
'
' This device has been carrying the phone's "seen" rows for as long as the
' member has had a phone build that emits them — applyRemote writes the
' mirror before it looks the kind up, so rows of a kind this app did not
' understand were still stored, just never acted on. Now that projectSeen
' exists they have to be acted on, and the feed will never offer them again:
' sync is CURSOR-based, so a row pulled under an older build is behind the
' cursor forever. Without this pass a member arrives on this build with a
' complete record of everything they have finished sitting in the mirror and
' not one tick showing, and only newly finished titles would ever appear.
'
' Tombstones are skipped deliberately, for the same reason Android skips them
' in _backfillSeenFromMirror: a deleted row means the mark was taken off
' somewhere else, and putting it back would restore a checkmark the member
' removed on purpose.
'
' Note what this is NOT. Android's backfill of the same name exists to stop
' its reconciler tombstoning the whole kind account-wide; this one cannot do
' that and does not need to, because Roku never tombstones a row it did not
' emit (see the ownership rule in reconcile, and the note on projectSeen).
' This is only about not throwing away what the box already holds.
sub replaySeenFromMirror(mirror as object)
    if RegRead("seen_backfill1") = "1" then return
    RegWrite("seen_backfill1", "1")
    rows = 0
    before = SeenCount()
    for each key in mirror
        r = mirror[key]
        if ToStr(r.kind) = "seen" and r.deleted <> true and ToStr(r.data) <> ""
            data = ParseJson(ToStr(r.data))
            if data <> invalid
                rows = rows + 1
                projectSeen(ToStr(key), false, data)
            end if
        end if
    end for
    ' The mirror can hold more marks than this device will keep — the local
    ' store is capped and the locker is not — so the trim runs once here,
    ' after the whole pass, and keeps the NEWEST. Doing it per row would walk
    ' the section once per mark.
    TrimSeen()
    ' Rows found in the mirror AND marks actually held afterwards, because
    ' the two come apart in ways worth seeing in a member's log: rows the
    ' local key mapping skipped, and rows the cap evicted, both show up as a
    ' gap between these numbers rather than as silence.
    ' Plain ASCII on purpose: this line ends up in uploaded member logs.
    KLog("sync", "finished-marks backfill: " + rows.toStr() + " row(s) in the mirror, holding " + SeenCount().toStr() + " mark(s) (was " + before.toStr() + ")")
end sub

' One-time: project any media-server rows ALREADY sitting in the mirror.
'
' Worth doing but NOT worth expecting much from, and the difference matters
' because it is the difference between what a member sees and what the
' changelog should promise them.
'
' Sync is CURSOR-based: a row that has already been pulled is never offered
' again. So the only media rows this box can ever show are the ones it happens
' to be holding — and the previous build let go of them precisely to keep the
' registry clear, which is the right trade and cost exactly this. A member who
' has been running that build has nothing left here to find, and their existing
' media favourites and watch progress will not appear on this television until
' a one-off full pull exists. That is parked behind pagination on the sync
' server's pull, and it is deliberately NOT attempted here: the pull endpoint
' still has no limit and an older Roku abandons a feed that runs past twenty-
' five seconds, after which sync is broken for that box for good.
'
' So this pass is for whoever DOES still hold rows. It costs one walk of the
' mirror, once, and it is idempotent — projecting a resume point writes the
' value it already holds.
'
' Tombstones are skipped, the same way replaySeenFromMirror skips them: a
' deleted row means the member took that favourite off somewhere else, and
' putting it back would undo a decision of theirs.
sub replayMediaFromMirror(mirror as object)
    if RegRead("media_backfill1") = "1" then return
    RegWrite("media_backfill1", "1")
    nFav = 0
    nHist = 0
    for each key in mirror
        r = mirror[key]
        k = ToStr(GetField(r, "kind"))
        if (k = "favmedia" or k = "medhist") and r.deleted <> true and ToStr(r.data) <> ""
            d = ParseJson(ToStr(r.data))
            if d <> invalid
                if k = "favmedia"
                    nFav = nFav + 1
                else
                    nHist = nHist + 1
                end if
                projectChange(k, ToStr(key), false, d)
            end if
        end if
    end for
    ' Plain ASCII on purpose: this line ends up in uploaded member logs.
    KLog("sync", "media-server backfill: " + nFav.toStr() + " favourite(s), " + nHist.toStr() + " watch-progress row(s) found in the mirror")
end sub

' One-time recovery from the deletion loop of 2026-07-19: a phone-side key
' mismatch mass-tombstoned the default profile's favorites, and the Roku
' obeyed. The tombstones still name every lost item — recreate bare store
' entries from them (EnrichTask fills names/art back in) and drop the rows
' from the mirror so the next reconcile re-pushes them as fresh puts.
sub restoreLoopCasualties(mirror as object)
    if RegRead("loop_restore_done") = "1" then return
    RegWrite("loop_restore_done", "1")
    favch = LoadJsonArray("fav_channels")
    favvod = LoadJsonArray("fav_vod")
    chSeen = {}
    for each c in favch
        chSeen[ToStr(c.streamId)] = true
    end for
    vodSeen = {}
    for each v in favvod
        vodSeen[ToStr(v.kind) + ":" + ToStr(v.id)] = true
    end for
    removeKeys = []
    for each key in mirror
        r = mirror[key]
        if r.deleted = true
            if ToStr(r.kind) = "favch" and key.left(Len("favch:default:")) = "favch:default:"
                chid = lastSegment(key)
                if chid <> "" and not chSeen.doesExist(chid)
                    favch.push({ streamId: chid, name: "", logo: "", url: "" })
                    chSeen[chid] = true
                end if
                removeKeys.push(key)
            else if ToStr(r.kind) = "favvod" and key.left(Len("favvod:default:")) = "favvod:default:"
                ' vodKey is "movie:ID", "series:ID", or "<src>:movie:ID".
                parts = Mid(key, Len("favvod:default:") + 1).split(":")
                if parts.count() >= 2
                    vkind = ToStr(parts[parts.count() - 2])
                    vid = ToStr(parts[parts.count() - 1])
                    if (vkind = "movie" or vkind = "series") and not vodSeen.doesExist(vkind + ":" + vid)
                        favvod.push({ kind: vkind, id: vid, name: "", icon: "", ext: "" })
                        vodSeen[vkind + ":" + vid] = true
                    end if
                end if
                removeKeys.push(key)
            end if
        end if
    end for
    if removeKeys.count() > 0
        for each k in removeKeys
            mirror.delete(k)
        end for
        RegWrite("fav_channels", FormatJson(favch))
        RegWrite("fav_vod", FormatJson(favvod))
    end if
end sub

' Self-heal: VOD favorites projected before the wire-format fix lost their
' poster (we read the wrong field). Restore art from the mirror's stored wire
' data so the next push carries the real poster instead of blanking it
' everywhere. Idempotent.
sub healFavVodArt(mirror as object)
    for each key in mirror
        r = mirror[key]
        if ToStr(r.kind) = "favvod" and r.deleted <> true and ToStr(r.data) <> ""
            data = ParseJson(ToStr(r.data))
            if data <> invalid
                art = ToStr(GetField(data, "poster"))
                if art <> ""
                    parts = splitFirstColon(Mid(key, Len("favvod:") + 1))
                    if parts <> invalid
                        storeKey = "fav_vod" + ProfileSuffixFor(parts.head)
                        entries = LoadJsonArray(storeKey)
                        changed = false
                        for each it in entries
                            if ToStr(it.kind) = ToStr(GetField(data, "type")) and ToStr(it.id) = ToStr(GetField(data, "id")) and ToStr(GetField(it, "src")) = ToStr(GetField(data, "src")) and ToStr(it.icon) = ""
                                it.icon = art
                                changed = true
                            end if
                        end for
                        if changed then SaveJsonArray(storeKey, entries)
                    end if
                end if
            end if
        end if
    end for
end sub

' One-time self-heal: earlier builds projected Android-shaped list items
' straight into the store (no id/icon fields). Normalize any such items so
' Home rows and snapshots always see the store shape. Idempotent.
sub normalizeStoredLists()
    prov = KwickTvProvider()
    if prov = invalid then return
    provId = ToStr(prov.id)
    for each p in LoadProfiles()
        storeKey = "fav_lists_" + provId + ProfileSuffixFor(ToStr(p.id))
        lists = LoadJsonArray(storeKey)
        changed = false
        for each l in lists
            fixed = []
            for each it in ToArray(l.items)
                if GetField(it, "id") = invalid or ToStr(it.id) = ""
                    fixed.push(listItemFromWire(it))
                    changed = true
                else
                    fixed.push(it)
                end if
            end for
            l.items = fixed
            ' CASE TRAP, the same one ProviderCustomEpgUrl warns about
            ' (Store.brs) — and this one was live, not theoretical.
            '
            ' EVERY writer of this flag names it as an IDENTIFIER: the
            ' literal in CreateList ({ homeRow: true }), the literal in
            ' projectFavList, and the toggle in Store.brs
            ' (ToggleListHomeRow). BrightScript folds an identifier key to
            ' lowercase, so what is actually sitting in the registry is
            ' "homerow" — and ParseJson hands the list back CASE-SENSITIVE,
            ' so the exact-case GetField(l, "homeRow") that used to be here
            ' could NEVER match it. Every launch, this "one-time" heal
            ' therefore fired on every list, and healed it from "home" — a
            ' key that only exists on the WIRE, never in the store — which
            ' is absent, which reads as false. That is the member's Home row
            ' switching itself off on every relaunch, and then being pushed
            ' off to their phone as well on the same cycle.
            '
            ' So: look for the flag under BOTH spellings, and heal only a
            ' list that genuinely has no opinion. Dot notation to write it,
            ' because that is what every reader uses (HomeScreen,
            ' SettingsCategoryScreen, buildSnapshot) and the two must agree.
            ' Asked as "is the key THERE", not "is its value invalid": the
            ' answer is a stored boolean, and a stored false must count as
            ' an opinion and be left alone. doesExist on a ParseJson map is
            ' exact-case, which is exactly why both spellings are asked for.
            if not (l.doesExist("homerow") or l.doesExist("homeRow"))
                if l.doesExist("home")
                    l.homeRow = (l.home = true)
                else
                    ' No flag at all = a list from before the flag existed.
                    ' It shows on Home, which is what CreateList does for a
                    ' new list and what Android does for a group with no
                    ' "home" key (`j['home'] as bool? ?? true`). Defaulting
                    ' to false here is what turned rows off.
                    l.homeRow = true
                end if
                changed = true
            end if
        end for
        if changed then SaveJsonArray(storeKey, lists)
    end for
end sub

' ---- Legacy / foreign favvod key detection ----------------------------------
' Android's old favvod keys embedded its device-local playlist UUID
' (favvod:<sid>:<uuid>:movie:<id>). After the Android key fix those rows are
' dead: BOTH apps ignore them forever, and CRITICALLY neither may ever
' tombstone them — a fresh device pulling the full feed would otherwise
' delete them out from under not-yet-updated Androids.

' "vod:123" / "episode:456" (a hist key's media segment) -> our resume key.
' Source-qualified ids ("src~123") stay whole — local keys use that shape.
function histResumeKey(media as string) as string
    if media.left(4) = "vod:"
        return "movie:" + Mid(media, 5)
    else if media.left(8) = "episode:"
        return "ep:" + Mid(media, 9)
    end if
    return ""
end function

' The vodKey segment of a favvod key (everything after favvod:<sid>:).
function favvodTail(key as string) as string
    parts = splitFirstColon(Mid(key, Len("favvod:") + 1))
    if parts = invalid then return ""
    return parts.tail
end function

' Old Android device-local rows: vodKey starts with a 36-char UUID + ":".
function isLegacyUuidVodKey(vodKey as string) as boolean
    rx = CreateObject("roRegex", "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}:", "")
    return rx.isMatch(vodKey)
end function

' (isForeignSourceVodKey used to gate extra-source rows out of projection
' back when the Roku was KwickTV-only. Multi-source keying made projection
' src-aware, so the gate — and the function — are gone.)

' One-time: drop any legacy-UUID favvod rows already sitting in OUR mirror
' (pulled before this guard existed) so they can never be tombstoned when
' deletion sync is eventually re-enabled.
sub purgeLegacyVodRows(mirror as object)
    if RegRead("legacy_vod_purge_done") = "1" then return
    RegWrite("legacy_vod_purge_done", "1")
    removeKeys = []
    for each key in mirror
        if ToStr(mirror[key].kind) = "favvod" and isLegacyUuidVodKey(favvodTail(key))
            removeKeys.push(key)
        end if
    end for
    for each k in removeKeys
        mirror.delete(k)
    end for
    if removeKeys.count() > 0 then KLog("sync", "purged " + removeKeys.count().toStr() + " legacy favvod row(s) from the mirror")

    ' Also scrub UUID src fields that were projected into OUR store before
    ' this guard existed — otherwise the snapshot would push legacy-format
    ' keys right back to the server.
    for each p in LoadProfiles()
        storeKey = "fav_vod" + ProfileSuffixFor(ToStr(p.id))
        entries = LoadJsonArray(storeKey)
        seen = {}
        kept = []
        changed = false
        for each v in entries
            vsrc = ""
            if GetField(v, "src") <> invalid then vsrc = ToStr(v.src)
            if vsrc <> "" and isLegacyUuidVodKey(vsrc + ":")
                v.delete("src")
                changed = true
            end if
            ' Dedup key carries the (post-strip) src — the same numeric id
            ' on two sources is two favorites, not a duplicate.
            dk = ToStr(GetField(v, "src")) + "|" + ToStr(v.kind) + ":" + ToStr(v.id)
            if not seen.doesExist(dk)
                seen[dk] = true
                kept.push(v)
            else
                changed = true   ' duplicate after src strip — drop it
            end if
        end for
        if changed then SaveJsonArray(storeKey, kept)
    end for
end sub

' ---- Helpers ----------------------------------------------------------------

' Split "a:b:c" into { head:"a", tail:"b:c" } on the FIRST colon.
function splitFirstColon(s as string) as dynamic
    sep = Instr(1, s, ":")
    if sep <= 1 then return invalid
    return { head: Left(s, sep - 1), tail: Mid(s, sep + 1) }
end function

function lastSegment(s as string) as string
    last = 0
    for i = 1 to Len(s)
        if Mid(s, i, 1) = ":" then last = i
    end for
    if last = 0 then return s
    return Mid(s, last + 1)
end function

function chunkOps(ops as object, size as integer) as object
    if ops.count() = 0 then return [[]]
    chunks = []
    i = 0
    while i < ops.count()
        chunk = []
        j = i
        while j < ops.count() and j < i + size
            chunk.push(ops[j])
            j = j + 1
        end while
        chunks.push(chunk)
        i = i + size
    end while
    return chunks
end function

' Order the feed: profile changes first, then ascending rev.
function orderChanges(collected as object) as object
    arr = []
    for each k in collected
        arr.push(collected[k])
    end for
    for i = 1 to arr.count() - 1
        cur = arr[i]
        j = i - 1
        while j >= 0 and changeAfter(arr[j], cur)
            arr[j + 1] = arr[j]
            j = j - 1
        end while
        arr[j + 1] = cur
    end for
    return arr
end function

function changeAfter(a as object, b as object) as boolean
    ap = 1
    if ToStr(GetField(a, "kind")) = "profile" then ap = 0
    bp = 1
    if ToStr(GetField(b, "kind")) = "profile" then bp = 0
    if ap <> bp then return ap > bp
    return ToInt(GetField(a, "rev")) > ToInt(GetField(b, "rev"))
end function

function friendlyErr(resp as object) as string
    if resp = invalid then return "Can't reach sync right now"
    code = ToStr(GetField(resp, "code"))
    if code = "auth" then return "Your KwickTV account is no longer active"
    if code = "panel_unreachable" then return "Can't reach KwickTV right now"
    return "Sync unavailable"
end function

function httpPost(bodyStr as string) as object
    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.enableEncodings(true)
    xfer.addHeader("Content-Type", "application/json")
    xfer.addHeader("User-Agent", KwickUserAgent())
    xfer.setUrl(m.syncUrl)
    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)
    if not xfer.asyncPostFromString(bodyStr) then return invalid
    msg = wait(25000, port)
    if type(msg) <> "roUrlEvent"
        xfer.asyncCancel()
        return invalid
    end if
    return ParseJson(msg.getString())
end function
