' Sports hub data build — the Roku port of Android's sportsDataProvider
' (sports_providers.dart). Read that file's comments before changing the
' shape of this: every cap and guard here is a bug someone already hit.
'
' Steps: fetch the channel list, read fixtures out of channel NAMES, add
' EPG programmes (real times) for sports/event channels, merge duplicates,
' work out countries, resolve team badges (bounded), sort art-first, done.

sub init()
    m.top.functionName = "runSports"
end sub

' GUARDED, the same way XmltvTask is and for the same reason: a fault on a task
' thread kills the whole app and the report that goes up names nothing. This
' build is long and it walks data the app does not control — channel names off
' a provider panel, EPG rows, badge lookups — so it has plenty of places to
' fault.
'
' WHAT IT OWES THE SPORTS SCREEN. That screen puts a spinner up, starts this
' task and waits on `result` and nothing else. If this never answers, the
' spinner turns for the rest of the session. So the catch writes { ok: false },
' which SportsScreen.onSportsData already treats as "Could not read your
' guide." — the spinner stops and the member is told. An answer that is already
' there is never overwritten: a second write would run that handler twice.
sub runSports()
    try
        runSportsInner()
    catch e
        GuardFailed("sports/run", e)
        r = m.top.result
        hasAnswer = (type(r) = "roAssociativeArray" and r.count() > 0)
        if not hasAnswer then m.top.result = { ok: false }
    end try
end sub

sub runSportsInner()
    started = CreateObject("roDateTime").asSeconds()
    ctx = SportsCtx()
    sources = LoadProviders()
    if sources.count() = 0
        m.top.result = { ok: false }
        return
    end if

    nowDt = CreateObject("roDateTime")
    nowS = nowDt.asSeconds()
    nowDt.toLocalTime()
    tzOffsetS = nowDt.asSeconds() - nowS
    windowStart = nowS - 4 * 3600
    windowEnd = nowS + 7 * 24 * 3600

    ' ---- Channel list (every source, merged) --------------------------------
    ' Android scans all sources for fixtures and lets one event list the
    ' channels showing it across providers. Same here: every channel carries
    ' its source so the "watch on" list can play the right stream.
    '
    ' THIS LIST IS CAPPED, and it is capped because it was not. A member on a
    ' Roku Premiere (4620X) was killed with EXIT_CHANNEL_MEM_LIMIT_FG on
    ' 2026-08-23 with Sports on screen: their line carries 54,151 channels,
    ' the scan built a record for every one of them up front, and the box went
    ' over its limit 54 seconds in. `_FG` — the member was looking at it.
    '
    ' Everything AFTER this point was already bounded (the per-panel EPG fetch
    ' cap, the team cap, the lanes, the deadline). The list built up front was
    ' the one thing left that scales with the size of the member's line, which
    ' is exactly the thing we do not control.
    '
    ' The cap is the one Search already uses (SearchScreen.brs:292) and
    ' MultiViewPicker copied second — a memory reading rather than a fixed
    ' count, because no fixed count is right for both a 2017 Roku TV and a
    ' Streaming Stick 4K. See roomForMoreChannels() at the foot of this file.
    chans = []
    m.rowsHeld = 0
    m.capped = false
    m.memMon = CreateObject("roAppMemoryMonitor")
    ' Playlist sources cost nothing — they're already parsed in the session
    ' cache, so take them first and let the network work happen after.
    xtream = []
    for each prov in sources
        tok = SrcTokenFor(prov)
        pid = ToStr(prov.id)
        if ToStr(prov.ptype) = "m3u"
            ' The playlist the guide already parsed; the SCREEN runs M3uTask
            ' first for any playlist that isn't in the cache yet.
            slots = m.global.m3uByProv
            if slots.doesExist(pid)
                for each c in slots[pid].channels
                    if not roomForMoreChannels() then exit for
                    chans.push({ channelId: ToStr(c.url), streamId: "", name: ToStr(c.name), logo: ToStr(GetField(c, "logo")), url: ToStr(c.url), tvgId: ToStr(GetField(c, "tvgId")), group: ToStr(GetField(c, "group")), src: tok, provId: pid })
                end for
            end if
        else
            xtream.push({ prov: prov, tok: tok, pid: pid })
        end if
    end for

    ' Panels are fetched IN PARALLEL, not one after another. Serially, a
    ' source that never answers cost its full deadline before the next one
    ' was even tried — with the owner's panel unreachable this screen took
    ' 61 seconds to show games that came from playlists it already had in
    ' memory. The category call doubles as a reachability probe on a short
    ' leash: a panel that can't answer it inside CATPROBEMS is dropped, and
    ' only the ones that did answer get the big channel-list request.
    if xtream.count() > 0
        catReqs = []
        for each x in xtream
            catReqs.push({ tag: x.pid, url: XtreamApiUrl(x.prov, "get_live_categories") })
        end for
        catBodies = parallelFetch(catReqs, 4, CATPROBEMS())

        listReqs = []
        catNames = {}
        for each x in xtream
            body = ToStr(catBodies[x.pid])
            if body = ""
                KLog("sports", "source " + x.pid + " did not answer - skipped")
            else
                names = {}
                parsed = ParseJson(body)
                if parsed <> invalid
                    for each cat in ToArray(parsed)
                        names[ToStr(GetField(cat, "category_id"))] = ToStr(GetField(cat, "category_name"))
                    end for
                end if
                catNames[x.pid] = names
                listReqs.push({ tag: x.pid, url: XtreamApiUrl(x.prov, "get_live_streams") })
            end if
        end for

        if listReqs.count() > 0
            listBodies = parallelFetch(listReqs, 4, 90000)
            for each x in xtream
                body = ToStr(listBodies[x.pid])
                if body <> ""
                    parsed = ParseJson(body)
                    if parsed <> invalid
                        names = catNames[x.pid]
                        if names = invalid then names = {}
                        for each s in ToArray(parsed)
                            if not roomForMoreChannels() then exit for
                            catId = ToStr(GetField(s, "category_id"))
                            grp = ""
                            if names.doesExist(catId) then grp = names[catId]
                            chans.push({ channelId: x.tok + "|" + ToStr(GetField(s, "stream_id")), streamId: ToStr(GetField(s, "stream_id")), name: ToStr(GetField(s, "name")), logo: ToStr(GetField(s, "stream_icon")), url: "", tvgId: ToStr(GetField(s, "epg_channel_id")), group: grp, src: x.tok, provId: x.pid })
                        end for
                    end if
                end if
            end for
        end if
    end if

    if chans.count() = 0
        m.top.result = { ok: false }
        return
    end if
    KLog("sports", chans.count().toStr() + " channel(s) to scan across " + sources.count().toStr() + " source(s)")
    if m.capped
        KLog("sports", "memory ceiling reached at " + chans.count().toStr() + " channel(s) - fixtures will be partial")
    end if

    ' ---- Pass 1: fixtures baked into channel names --------------------------
    ' Across the WHOLE list, not just sports categories — this provider files
    ' one-off event channels under all sorts of groups, and the parser is
    ' conservative enough to ignore ordinary channels. A cheap substring
    ' pre-filter keeps the regex work off the 95% that can't be fixtures.
    sightings = []
    for each rec in chans
        lower = LCase(rec.name)
        maybe = (Instr(1, lower, " v ") > 0 or Instr(1, lower, " vs") > 0 or Instr(1, lower, " @ ") > 0 or Instr(1, lower, " - ") > 0 or Instr(1, lower, "versus") > 0)
        rec.isEvent = false
        if maybe
            parsed = ParseChannelName(ctx, rec.name, rec.group + " " + rec.name)
            if parsed <> invalid and IsRealSportsEvent(ctx, parsed)
                rec.isEvent = true
                sightings.push({ event: parsed, event_channel: sightingChannel(ctx, rec) })
            end if
        end if
    end for
    KLog("sports", sightings.count().toStr() + " name-based sighting(s)")

    ' ---- Pass 2: EPG programmes (the only trusted source of times) ----------
    ' Any channel that produced an event counts as a sports channel whatever
    ' its category says — relying on the category alone once left every
    ' fixture reading "Time not listed". The guide bucket lookup is memoised
    ' per group name; running ~60 regexes on 10k channels is not a plan.
    bucketCache = {}
    eligible = []
    ' An Adult category can't bucket as Sports, but a channel inside one
    ' named "PPV ..." would be taken on its NAME alone — so the category is
    ' checked either way (certification 6.3, see GuideMeta.brs).
    adultOk = AdultCatsAllowed()
    for each rec in chans
        take = rec.isEvent
        ck = rec.group
        if not bucketCache.doesExist(ck) then bucketCache[ck] = GuideMetaCategory(ck)
        b = bucketCache[ck]
        if not take
            take = (b = "Sports" or b = "PPV" or LooksPpv(rec.name))
        end if
        if take and not adultOk and b = "Adult" then take = false
        if take then eligible.push(rec)
    end for

    ' Each eligible channel gets its listings from ITS OWN source: playlist
    ' channels from the shared XMLTV, panel channels from their own panel's
    ' short-EPG. The per-panel fetch cap is applied per source, so adding a
    ' second provider can't multiply the request count without limit.
    m3uEligible = []
    byProv = {}
    provOrder = []
    for each rec in eligible
        pid = ToStr(GetField(rec, "provId"))
        p = invalid
        for each cand in sources
            if ToStr(cand.id) = pid then p = cand
        end for
        if p = invalid or ToStr(p.ptype) = "m3u"
            m3uEligible.push(rec)
        else
            if not byProv.doesExist(pid)
                byProv[pid] = { prov: p, recs: [] }
                provOrder.push(pid)
            end if
            byProv[pid].recs.push(rec)
        end if
    end for
    if m3uEligible.count() > 0
        addXmltvSightings(ctx, m3uEligible, sightings, windowStart, windowEnd)
    end if
    for each pid in provOrder
        addShortEpgSightings(ctx, byProv[pid].prov, byProv[pid].recs, sightings, windowStart, windowEnd)
    end for
    KLog("sports", sightings.count().toStr() + " sighting(s) after EPG")

    ' ---- Merge, country, badges, sort ---------------------------------------
    events = MergeSightings(ctx, sightings)
    for each e in events
        regions = []
        for each c in e.channels
            regions.push(c.region)
        end for
        e.country = SportsCountryOf(ctx, e.league, e.title, regions)
    end for

    ' Soonest first BEFORE the badge pass, so the teams that get looked up
    ' are the ones a member is about to see.
    for each e in events
        e.sk = timeKey(e.startS) + LCase(e.title)
    end for
    events.sortBy("sk")

    badges = resolveBadges(events)

    ' Crested games first, then the rest — each block in time order. Decided
    ' HERE, before anything renders, and never re-decided on screen.
    for each e in events
        artFlag = "1"
        if eventHasArt(e, badges) then artFlag = "0"
        e.sk = artFlag + timeKey(e.startS) + LCase(e.title)
    end for
    events.sortBy("sk")
    for each e in events
        e.delete("sk")
    end for

    present = {}
    for each e in events
        present[e.sport] = true
    end for
    chips = []
    for each s in ctx.chipOrder
        if present.doesExist(s) then chips.push(s)
    end for

    took = CreateObject("roDateTime").asSeconds() - started
    KLog("sports", events.count().toStr() + " event(s), " + chips.count().toStr() + " sport(s), built in " + took.toStr() + "s")
    m.top.result = { ok: true, events: events, sports: chips, badges: badges, tzOffsetS: tzOffsetS }
end sub

' src rides along so the "watch on" list plays each channel against the
' source it actually came from (a merged event can list channels from
' several providers).
function sightingChannel(ctx as object, rec as object) as object
    return { channelId: rec.channelId, channelName: rec.name, logo: rec.logo, url: rec.url, streamId: rec.streamId, quality: QualityOf(ctx, rec.name), region: RegionOf(ctx, rec.name), src: ToStr(GetField(rec, "src")) }
end function

' ---- EPG: Xtream get_short_epg ---------------------------------------------

' One fetch per distinct EPG id (regional duplicates share one), capped and
' deadlined. Event channels go first — they are the ones that need times.
sub addShortEpgSightings(ctx as object, prov as object, eligible as object, sightings as object, windowStart as integer, windowEnd as integer)
    groups = {}
    order = []
    for each rec in eligible
        gk = rec.tvgId
        if gk = "" then gk = "sid:" + rec.streamId
        if not groups.doesExist(gk)
            groups[gk] = []
            order.push(gk)
        end if
        groups[gk].push(rec)
    end for
    ' Event-channel groups to the front.
    front = []
    back = []
    for each gk in order
        isEvent = false
        for each rec in groups[gk]
            if rec.isEvent then isEvent = true
        end for
        if isEvent then front.push(gk) else back.push(gk)
    end for
    queue = []
    for each gk in front
        queue.push(gk)
    end for
    for each gk in back
        queue.push(gk)
    end for

    maxFetches = 80
    reqs = []
    for i = 0 to queue.count() - 1
        if i >= maxFetches then exit for
        gk = queue[i]
        first = groups[gk][0]
        reqs.push({ tag: gk, url: XtreamApiUrl(prov, "get_short_epg") + "&stream_id=" + UrlEncode(first.streamId) + "&limit=30" })
    end for
    if queue.count() > maxFetches
        KLog("sports", "EPG capped: " + maxFetches.toStr() + " of " + queue.count().toStr() + " channel group(s) fetched")
    end if
    bodies = parallelFetch(reqs, 6, 12000)

    for each gk in bodies
        body = bodies[gk]
        if body <> ""
            parsed = ParseJson(body)
            if parsed <> invalid
                carriers = groups[gk]
                context = carriers[0].group + " " + carriers[0].name
                for each listing in ToArray(GetField(parsed, "epg_listings"))
                    startS = ToInt(GetField(listing, "start_timestamp"))
                    stopS = ToInt(GetField(listing, "stop_timestamp"))
                    if stopS > windowStart and startS < windowEnd
                        title = B64Decode(ToStr(GetField(listing, "title")))
                        addEpgSighting(ctx, title, context, startS, stopS, carriers, sightings)
                    end if
                end for
            end if
        end if
    end for
end sub

' ---- EPG: M3U / XMLTV (already parsed into m.global by the guide) ----------

sub addXmltvSightings(ctx as object, eligible as object, sightings as object, windowStart as integer, windowEnd as integer)
    if m.global.xmltvState <> "ready" then return
    byId = m.global.xmltvById
    for each rec in eligible
        if rec.tvgId <> "" and byId.doesExist(rec.tvgId)
            context = rec.group + " " + rec.name
            for each p in byId[rec.tvgId]
                if p.stopS > windowStart and p.startS < windowEnd
                    addEpgSighting(ctx, ToStr(p.title), context, p.startS, p.stopS, [rec], sightings)
                end if
            end for
        end if
    end for
end sub

sub addEpgSighting(ctx as object, title as string, context as string, startS as integer, stopS as integer, carriers as object, sightings as object)
    parsed = ParseEventTitle(ctx, title, context, startS)
    if parsed = invalid then return
    if not IsRealSportsEvent(ctx, parsed) then return
    ' A placeholder guide entry named after the channel is not an event.
    if TitleIsJustTheChannel(ctx, parsed.title, carriers[0].name) then return
    parsed.stopS = stopS
    for each rec in carriers
        sightings.push({ event: parsed, event_channel: sightingChannel(ctx, rec) })
    end for
end sub

' ---- Badges ----------------------------------------------------------------

' Asks kwickplayer.tv's sportsart.php — NEVER TheSportsDB directly. The
' server holds the premium key, picks the right club by sport/league (a free
' search returns a defunct netball team for "Collingwood"), caches
' permanently, and returns badge:null rather than guessing.
'
' Bounded three ways — team cap, lanes, deadline — because the first Android
' version fired every lookup at once, swamped the client, timed out, and the
' art-first sort silently degraded while rows still drew badges: it looked
' like the sort was ignored rather than failing.
function resolveBadges(events as object) as object
    maxTeams = 60
    maxLeagues = 20
    reqs = []
    seen = {}
    for each e in events
        if e.homeTeam <> "" and e.awayTeam <> ""
            for each t in [e.homeTeam, e.awayTeam]
                k = "team|" + t
                if not seen.doesExist(k) and seen.count() < maxTeams
                    seen[k] = true
                    u = "https://kwickplayer.tv/kwicksync/sportsart.php?kind=team&team=" + UrlEncode(t) + "&sport=" + UrlEncode(e.sport)
                    if e.league <> "" then u = u + "&league=" + UrlEncode(e.league)
                    reqs.push({ tag: k, url: u })
                end if
            end for
        end if
    end for
    ' League artwork for events with no two sides — a fight card or a race
    ' can never resolve two crests, but PFL has a logo and that identifies it.
    leagues = 0
    for each e in events
        if e.homeTeam = "" or e.awayTeam = ""
            nm = e.league
            if nm = "" then nm = e.title
            k = "league|" + nm
            if nm <> "" and not seen.doesExist(k) and leagues < maxLeagues
                seen[k] = true
                leagues = leagues + 1
                reqs.push({ tag: k, url: "https://kwickplayer.tv/kwicksync/sportsart.php?kind=league&team=" + UrlEncode(nm) + "&sport=" + UrlEncode(e.sport) })
            end if
        end if
    end for

    bodies = parallelFetch(reqs, 6, 8000)
    badges = {}
    got = 0
    for each k in bodies
        badge = ""
        parsed = ParseJson(bodies[k])
        if parsed <> invalid
            b = GetField(parsed, "badge")
            if b <> invalid then badge = ToStr(b)
        end if
        badges[k] = badge
        if badge <> "" then got = got + 1
    end for
    KLog("sports", "badges: " + got.toStr() + "/" + reqs.count().toStr() + " resolved")
    return badges
end function

function eventHasArt(e as object, badges as object) as boolean
    if e.homeTeam <> "" and ToStr(GetField(badges, "team|" + e.homeTeam)) <> "" then return true
    if e.awayTeam <> "" and ToStr(GetField(badges, "team|" + e.awayTeam)) <> "" then return true
    return false
end function

' ---- Sorting helper ---------------------------------------------------------

' Zero-padded epoch so string sort keys order by time; undated events last.
function timeKey(startS as integer) as string
    if startS <= 0 then return "9999999999"
    s = startS.toStr()
    while s.len() < 10
        s = "0" + s
    end while
    return s
end function

' ---- HTTP -------------------------------------------------------------------

' (httpGetBody retired: every fetch here now goes through parallelFetch,
' so one unreachable source can no longer hold up the others.)

' A few requests at a time on one message port — NOT all at once (that was
' the Android badge stampede), and never past the deadline. Returns
' tag -> body ("" for failures); missing tags simply weren't reached.
' How long a panel gets to answer the (small) category list before it is
' treated as unreachable and skipped. Generous enough for a slow provider
' on a busy night, short enough that a dead one doesn't hold up the games
' that came from sources which answered.
function CATPROBEMS() as integer
    return 20000
end function

function parallelFetch(reqs as object, lanes as integer, deadlineMs as integer) as object
    out = {}
    if reqs.count() = 0 then return out
    port = CreateObject("roMessagePort")
    active = {}
    nextIdx = 0
    deadline = CreateObject("roDateTime").asSeconds() * 1000& + deadlineMs

    while true
        ' Fill free lanes.
        while active.count() < lanes and nextIdx < reqs.count()
            r = reqs[nextIdx]
            nextIdx = nextIdx + 1
            xfer = CreateObject("roUrlTransfer")
            xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
            xfer.enableEncodings(true)
            xfer.addHeader("User-Agent", KwickUserAgent())
            xfer.setUrl(r.url)
            xfer.setMessagePort(port)
            if xfer.asyncGetToString()
                active[xfer.getIdentity().toStr()] = { xfer: xfer, tag: r.tag }
            else
                out[r.tag] = ""
            end if
        end while
        if active.count() = 0 then return out

        remaining = deadline - CreateObject("roDateTime").asSeconds() * 1000&
        if remaining <= 0
            for each k in active
                active[k].xfer.asyncCancel()
            end for
            KLog("sports", "fetch deadline hit with " + (reqs.count() - nextIdx + active.count()).toStr() + " request(s) unfinished")
            return out
        end if

        msg = wait(remaining, port)
        if type(msg) = "roUrlEvent"
            k = msg.getSourceIdentity().toStr()
            if active.doesExist(k)
                entry = active[k]
                body = ""
                if msg.getResponseCode() >= 200 and msg.getResponseCode() < 300 then body = msg.getString()
                out[entry.tag] = body
                active.delete(k)
            end if
        end if
    end while
    return out
end function

' ---- The channel-list memory cap -------------------------------------------
'
' Is there room to hold one more channel record, or is this box close enough
' to its limit that carrying on risks the whole app being killed?
'
' WHY A MEMORY READING AND NOT A ROW COUNT. roAppMemoryMonitor measures usage
' against THIS device's limit, so one number works from a 2017 Roku TV to a
' Streaming Stick 4K. Any fixed count is wrong on one or the other: Search
' measured this account alone holding more than 60,000 rows on the office
' stick without ever passing 70%, and an earlier 60,000 backstop capped that
' healthy device for no reason.
'
' 70% is the same ceiling Search and MultiViewPicker use, and it leaves head
' room for what comes AFTER the list: the EPG pass, the badge art, the event
' grid and its posters. An OOM kill is not a Sports problem when it happens,
' it is a dead app.
'
' CHECKED EVERY 500 ROWS, not every row. GetMemoryLimitPercent is a syscall
' and a big line runs to tens of thousands — Search settled on the same
' interval for the same reason.
'
' THE COARSE LEVEL IS READ TOO, and only here among the three. This runs on a
' TASK thread, not the render thread, and GetGeneralMemoryLevel is the reading
' XmltvTask already trusts from a task (MemoryTight there). Two readings cost
' nothing at one per 500 rows and either one is enough to stop.
'
' THE 150000 BACKSTOP only catches a device whose monitor is unavailable or
' stuck reporting low usage. It is deliberately far above any real line — the
' memory reading is what should decide.
'
' PARTIAL IS THE RIGHT ANSWER HERE. Sports is a "what's on" hub, not a
' catalogue the member browses to the end: fixtures come from channel names
' and EPG, both of which are already bounded further down, and a member whose
' line is big enough to reach this cap still gets a full screen of games.
' The alternative on the boxes that hit it is no screen at all.
function roomForMoreChannels() as boolean
    if m.capped then return false
    if m.rowsHeld mod 500 = 0
        if atSportsMemoryCeiling()
            m.capped = true
            return false
        end if
    end if
    m.rowsHeld = m.rowsHeld + 1
    return true
end function

' CORRECTED 2026-08-31. This shipped in v1.0.29 reading roAppMemoryMonitor as
' if it were app-wide. It is NOT app-wide from a Task: measured on the office
' stick, a task read 14-17% while the app was really at 47-56%. So the 70% test
' below could essentially never fire and this cap was resting entirely on its
' row backstop and the coarse level.
'
' The app-wide figure comes from the render thread instead - PublishM3uParse
' stamps m.global.appMemPct after each playlist lands - and our own reading is
' added to it as this task's share.
function atSportsMemoryCeiling() as boolean
    if m.rowsHeld >= 150000 then return true
    lvl = LCase(ToStr(CreateObject("roDeviceInfo").GetGeneralMemoryLevel()))
    if lvl = "low" or lvl = "critical" then return true
    base = 0
    if m.global <> invalid then base = ToInt(m.global.appMemPct)
    mine = 0
    if m.memMon <> invalid
        used = m.memMon.GetMemoryLimitPercent()
        if used <> invalid then mine = ToInt(used)
    end if
    return (base + mine) >= 70
end function
