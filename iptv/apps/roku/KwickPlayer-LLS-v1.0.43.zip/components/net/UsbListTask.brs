' Lists what's on an attached USB drive, off the render thread.
'
' roFileSystem is not safe to touch from the render thread, and a directory
' listing on a slow stick is not instant, so every bit of it happens here.
'
' Roku mounts USB volumes as ext1: .. ext9:, read-only, and only on models
' that actually have a port — the sticks and the Express line don't. An empty
' volume list is therefore the NORMAL answer on most devices, not an error,
' and the screen says so in plain words rather than showing a failure.

sub init()
    m.top.functionName = "listPath"
end sub

sub listPath()
    fs = CreateObject("roFileSystem")
    path = m.top.path
    entries = []

    if path = ""
        ' Top level: the drives themselves.
        '
        ' ext1: .. ext4: are ALWAYS listed and always report Exists() = true,
        ' whether or not anything is plugged in — they're mount points, not
        ' drives. What actually tells them apart is GetVolumeInfo: empty for
        ' a slot with nothing in it, populated (blocks, label...) for a real
        ' drive. Without this the member is offered four phantom drives that
        ' all turn out to be empty.
        slots = 0
        for each v in fs.GetVolumeList()
            vol = ToStr(v)
            ' Only external volumes. tmp:, cachefs: and friends are ours and
            ' hold nothing a member put there.
            if LCase(vol.left(3)) = "ext"
                slots = slots + 1
                info = fs.GetVolumeInfo(vol)
                hasInfo = (info <> invalid and info.count() > 0)
                ' DON'T trust GetVolumeInfo on its own. On the model this was
                ' first written against it returns {} for an empty slot, which
                ' looked like a clean way to tell a real drive apart — but on
                ' other models it returns {} for a MOUNTED drive too, and
                ' members with a stick plugged in were told no drive was
                ' found. Listing the volume is the answer that can't lie: a
                ' drive with anything on it returns entries, an empty slot
                ' returns none.
                kids = 0
                listing = fs.GetDirectoryListing(vol + "/")
                if listing <> invalid then kids = listing.count()
                if hasInfo or kids > 0
                    label = vol
                    if hasInfo and ToStr(GetField(info, "label")) <> "" then label = ToStr(info.label) + "  (" + vol + ")"
                    entries.push({ name: label, path: vol + "/", isDir: true })
                end if
                KLog("usb", "slot " + vol + " info=" + ToStr(hasInfo) + " items=" + kids.toStr())
            end if
        end for
        KLog("usb", "USB: " + entries.count().toStr() + " drive(s) of " + slots.toStr() + " slot(s)")
        m.top.result = { ok: true, entries: entries, atRoot: true }
        return
    end if

    if not fs.Exists(path)
        m.top.result = { ok: false, error: "gone", entries: [] }
        return
    end if

    dirs = []
    files = []
    for each nm in fs.GetDirectoryListing(path)
        name = ToStr(nm)
        if name <> ""
            full = path
            if full.right(1) <> "/" then full = full + "/"
            full = full + name
            st = fs.Stat(full)
            isDir = (st <> invalid and ToStr(GetField(st, "type")) = "directory")
            if isDir
                dirs.push({ name: name, path: full + "/", isDir: true })
            else if looksLikePlaylist(name)
                ' Only playlists are offered. A USB stick is somebody's
                ' whole life — listing every file would bury the one thing
                ' they came here for.
                files.push({ name: name, path: full, isDir: false })
            end if
        end if
    end for

    ' Folders first, then playlists; each alphabetical.
    dirs.sortBy("name", "i")
    files.sortBy("name", "i")
    for each d in dirs
        entries.push(d)
    end for
    for each f in files
        entries.push(f)
    end for

    m.top.result = { ok: true, entries: entries, atRoot: false }
end sub

function looksLikePlaylist(name as string) as boolean
    n = LCase(name)
    return n.right(4) = ".m3u" or n.right(5) = ".m3u8"
end function
