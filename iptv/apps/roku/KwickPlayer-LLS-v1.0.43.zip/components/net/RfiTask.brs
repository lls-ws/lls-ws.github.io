' Roku's Request For Information (RFI), as a Task because roChannelStore is a
' plain BrightScript object and Roku's own guidance keeps it off the render
' thread.
'
' WHY THIS EXISTS. Certification RP 2.1 / RP 4.1 and 2.2: an app whose members
' sign in must call GetUserData() during the sign-in flow, so a member can
' hand over the email on their Roku account instead of typing it. Roku's
' static analysis refused the first store package (2026-09-03, finding 1, an
' ERROR) until the call existed. Only the email is requested, in the
' "signin" context - see runRfi for what the default asked for instead. It
' is asked ONCE per box - OnboardScreen remembers - and the member can say no.
'
' A KwickTV username is not usually an email, so what this buys most members
' is nothing and what it costs them is one Roku dialog, once. That is the price
' of the listing; the certification text is not ambiguous about it.
'
' EVERYTHING IS INSIDE try/catch. Three launch crashes on 2026-09-03 came from
' guessing Roku API names on the memory interfaces; nothing on this path may
' be able to do that again. A wrong name here fails the pre-fill and nothing
' else - the sign-in form is exactly as usable as it was.

sub init()
    m.top.functionName = "runRfi"
end sub

sub runRfi()
    res = { ok: false }
    try
        store = CreateObject("roChannelStore")
        if store = invalid
            m.top.result = res
            return
        end if
        ' GetPartialUserData, NOT GetUserData. The first cut used GetUserData
        ' and Roku put up "Let's create your account - share your name,
        ' address, email address and phone number", which asks for far more
        ' than this app wants and describes something it does not do. With
        ' only "email" requested and context "signin", Roku titles the dialog
        ' "Sign in" and shows the email alone. Documented as synchronous: it
        ' blocks until the member answers and returns invalid on Cancel.
        data = store.getPartialUserData("email", { context: "signin" })
        if data <> invalid
            email = ToStr(GetField(data, "email"))
            if email <> "" then res = { ok: true, email: email }
        end if
    catch e
        KLog("rfi", "request for information failed safely: " + ToStr(GetField(e, "message")))
        res = { ok: false }
    end try
    m.top.result = res
end sub
