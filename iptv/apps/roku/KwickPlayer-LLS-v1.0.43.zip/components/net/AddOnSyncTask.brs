' ---- The member's Trakt / Simkl watchlist, pulled and matched -----------------
'
' One run of the watchlist sync for one or both add-ons, entirely on this
' background thread. It asks the relay for the member's list, throws away
' everything their own playlists cannot play, and writes what is left to
' cachefs: for HomeScreen to draw. NOTHING here touches the render thread and
' nothing here draws.
'
' ANDROID IS THE SPEC. Up to 60 entries, capped BEFORE the catalogue is
' touched; matched against the member's own catalogue by kind + title + year;
' anything their playlists do not carry is dropped, so the row only ever shows
' things that will actually play; one tile per watchlist entry however many
' sources carry it; the tile shows OUR title and OUR poster and opens the
' ordinary movie or series page.
'
' WHY THE CACHE IS A FILE AND NOT THE REGISTRY. The registry is 16-32 KB for
' the WHOLE app and a write past it fails SILENTLY, taking whatever else was
' mid-write with it (Store.brs). Android keeps its pulled rows in preferences;
' this box cannot. cachefs: is scratch the firmware may clear whenever it
' likes, which for a cache is correct behaviour - losing it costs one refetch.
' TitleMetaTask.brs:342-404 made the same call for the same reasons and is the
' precedent this follows.
'
' THE FILE NAMES CANNOT BE SWEPT BY ANYTHING ELSE. Three sweeps already run
' over cachefs: ApiTask deletes "kwick_api_" (ApiTask.brs:302), XmltvTask
' deletes "kwick_xmltv_" (XmltvTask.brs:777) and SubFileTask deletes
' "kwicksub_" (SubFileTask.brs:99). "kwickwl_" matches none of the three - and
' this file's own scratch body is "kwickwl_body_", which matches none of them
' either.
'
' NO REQUEST PER TILE, PER ROW OR PER ROTATION. A run makes at most two relay
' calls for Trakt and five for Simkl, plus two catalogue calls per Xtream
' source, and the catalogue is fetched ONCE per run however many add-ons are
' due. The pattern that got this house's provider access banned in August 2026
' was a request per item; this is a handful per three hours.
'
' THE MEMBER'S TOKEN is read from the registry here and put on exactly one
' header. It is never logged, never returned in `result`, and never compared
' anywhere a log line could see it.

sub init()
    m.top.functionName = "runAddOnSync"
end sub

' ---- Constants ---------------------------------------------------------------

' The most watchlist entries we will carry, applied BEFORE the catalogue is
' touched so a member with a 400-title Trakt list costs the same as one with
' forty. Android's number.
function WLMAXITEMS() as integer
    return 60
end function

' Fifteen minutes, both services. Only "Sync now" skips it.
function WLTHROTTLES() as integer
    return 900
end function

' The hard ceiling on one service's cache file. At about 190 bytes a matched
' row plus about 45 for the raw entry it came from, 60 of each is roughly
' 14.5 KB, so this is a backstop for a provider sending very long poster
' addresses rather than a limit that normally bites. Over it, matched rows are
' dropped from the END (the oldest part of the member's list) until it fits -
' never truncated mid-row, because half a JSON document reads back as no cache
' at all and would cost a whole refetch.
function WLCACHEMAXBYTES() as integer
    return 16384
end function

function WLCACHESCHEMA() as integer
    return 1
end function

function WLCachePath(svc as string) as string
    return "cachefs:/kwickwl_" + svc + ".json"
end function

' ---- The run -----------------------------------------------------------------

sub runAddOnSync()
    services = ToArray(ParseJson(ToStr(m.top.servicesJson)))
    forced = (m.top.forced = true)

    ' AT MOST ONE SIGN-IN RENEWAL PER RUN, whichever call runs into the refusal
    ' first. A Simkl run makes five relay calls and a Trakt run two, and
    ' without this a box that is refused every time would ask kwickplayer.tv to
    ' renew the sign-in five times in a row. See relayGet.
    m.wlRenewed = false

    ' ---- Three phases, and the middle one is why -------------------------
    '
    ' 1. Ask each add-on's relay for the member's list. ONE AFTER ANOTHER,
    '    NEVER IN PARALLEL, and a failure records itself while the next one
    '    still runs - there is no early exit out of any of these loops.
    ' 2. ONE catalogue pass for the WHOLE run, matching every add-on's list at
    '    the same time. The catalogue is the only expensive thing this job
    '    does (the office stick's own movies catalogue is 15 MB) and running
    '    it per add-on would double it for no gain. Two hash lookups per
    '    catalogue row is free; a second 15 MB download is not.
    ' 3. Write each add-on's answer down.
    pend = []
    for each raw in services
        svc = LCase(ToStr(raw)).trim()
        if svc = "trakt" or svc = "simkl"
            pend.push(prepareService(svc, forced))
        end if
    end for

    jobs = []
    for each j in pend
        if j.needsMatch = true then jobs.push(j)
    end for
    if jobs.count() > 0 then matchAgainstCatalog(jobs)

    runs = []
    for each j in pend
        runs.push(finishService(j))
    end for
    m.top.result = { ok: true, runs: runs }
end sub

' Everything one add-on does BEFORE the catalogue: the switches, the throttle
' and the relay calls. Hands back a job — `needsMatch` true means phase 2 has
' work to do for it, `done` true means it finished here and phase 3 has only to
' hand its answer back.
'
' Every field of `out` is set on every branch. AppShell reads `summary`
' whatever happened, and a shape that only grew its fields on the happy path
' would put the last service's words on this one's Settings row.
function prepareService(svc as string, forced as boolean) as object
    out = {
        service: svc
        ok: false          ' did the pull finish?
        changed: false     ' is there new artwork on the box to redraw?
        throttled: false   ' asked too recently - nothing happened at all
        dropped: false     ' signed out mid-pull - NOTHING was recorded
        total: 0           ' titles on the member's list at the service
        matched: 0         ' how many of those this box can actually play
        summary: ""
        at: wlNowS()
    }
    job = { svc: svc, out: out, startToken: "", wanted: [], stamp: "", rows: [], hits: {}, needsMatch: false, done: true }

    ' THE SWITCH DECIDES WHETHER THE PULL HAPPENS AT ALL, not just whether the
    ' row is drawn - Android does the same. A member who turns the row off has
    ' asked us to stop talking to the service, not to fetch quietly and hide it.
    if not WatchlistRowOn(svc)
        out.ok = true
        out.summary = "Nothing to sync while the Home row is off"
        return job
    end if

    acct = AddOnAccount(svc)
    if acct.signedIn <> true
        out.ok = true
        out.summary = "Not signed in"
        return job
    end if
    ' >>> THE GENERATION COUNTER, and it is the credential itself. <<<
    ' Android carries a counter that a sign-out bumps so a pull already in
    ' flight cannot record anything. The sign-out button lives in another
    ' lane's file here, so there is nothing to bump - but the token IS the
    ' generation: signing out clears it, and a different member signing in
    ' replaces it. Held in memory for the length of this run, compared once
    ' before anything is written, and never logged or returned.
    job.startToken = acct.token

    cached = wlCacheRead(svc)

    ' The 15-minute throttle. Nothing happened, so nothing is recorded - a
    ' throttled run must not move the "Last synced" line in Settings.
    lastAsk = ToInt(GetField(cached, "at"))
    if not forced and lastAsk > 0 and (wlNowS() - lastAsk) < WLTHROTTLES()
        out.ok = true
        out.throttled = true
        out.summary = ToStr(GetField(cached, "sm"))
        return job
    end if

    if svc = "trakt"
        pull = pullTrakt(job.startToken)
    else
        pull = pullSimkl(job.startToken, cached)
    end if

    ' >>> THE GENERATION COUNTER MOVES WHEN THE SIGN-IN IS RENEWED. <<<
    ' A Trakt token that ran out mid-pull is swapped for a fresh one inside
    ' relayGet, which means the credential this run belongs to has legitimately
    ' changed. Without this line wlCacheWrite would compare the run against the
    ' token it started with, see a different one stored, and correctly conclude
    ' "somebody signed out" - throwing away a pull that actually succeeded. A
    ' renewal is not a sign-out, so the run follows it.
    ' A sign-out still fails the comparison, because that clears the token to
    ' "" and this only ever moves to a real one.
    renewed = ToStr(GetField(pull, "token"))
    if renewed <> "" then job.startToken = renewed

    ' A FAILED PULL WRITES NOTHING AND DOES NOT REDRAW. The tiles already on
    ' screen are the last good answer and stay exactly as they are.
    if pull.ok <> true
        out.summary = pull.summary
        return job
    end if

    ' Simkl said its list has not moved since last time. The items are left
    ' untouched; only the "we asked just now" stamp moves, so the next minute
    ' tick does not ask all over again - and no catalogue is pulled at all,
    ' which is the whole point of asking `activities` first.
    if pull.unchanged = true
        out.ok = true
        out.total = ToInt(GetField(cached, "n"))
        out.matched = ToInt(GetField(cached, "m"))
        out.summary = "Nothing changed"
        wlCacheTouch(svc, job.startToken, out.summary)
        return job
    end if

    job.wanted = pull.wanted
    job.stamp = pull.stamp
    out.total = job.wanted.count()

    if job.wanted.count() = 0
        ' Nothing to match, so nothing to pull a catalogue for.
        out.summary = "Nothing on your list"
        job.done = false
        return job
    end if

    job.done = false
    job.needsMatch = true
    return job
end function

' Phase 3: write one add-on's answer down.
function finishService(job as object) as object
    if job.done = true then return job.out
    if job.needsMatch = true
        ' Back into the member's own watchlist order.
        rows = []
        for i = 0 to job.wanted.count() - 1
            k = i.toStr()
            if job.hits.doesExist(k) then rows.push(job.hits[k])
        end for
        job.rows = rows
        job.out.matched = rows.count()
        job.out.summary = wlSummary(job.out.total, job.out.matched)
    end if
    return finishWith(job.out, job.svc, job.startToken, job.rows, job.wanted, job.stamp)
end function

' Write the answer down, or throw the whole run away if the member signed out
' while it was in the air.
function finishWith(out as object, svc as string, startToken as string, rows as object, wanted as object, stamp as string) as object
    st = wlCacheWrite(svc, startToken, rows, wanted, stamp, out.summary)
    if st = "signedout"
        ' Record NOTHING - not the rows, not the stamp, not the summary. The
        ' next member on this box must not inherit the last one's row.
        out.ok = false
        out.dropped = true
        out.changed = false
        out.summary = ""
        out.total = 0
        out.matched = 0
        return out
    end if
    ' A refused write is not a failed pull: the numbers are real and belong on
    ' the Settings row. There is simply nothing new to draw, so `changed` stays
    ' false and whatever is on Home now stays where it is.
    out.ok = true
    out.changed = (st = "ok")
    return out
end function

' The words the Settings row shows, and they are Android's words, separator
' included, so a support call reads the same on either device: "14 titles",
' "1 title", "14 titles · 9 in your playlists".
'
' THE LONGEST THIS CAN PRODUCE is "60 titles · 60 in your playlists", 32
' characters, against the 40 nia's SetLastSync truncates at. The failure
' sentences further down are NOT under it — see the report.
function wlSummary(total as integer, matched as integer) as string
    if total <= 0 then return "Nothing on your list"
    word = " titles"
    if total = 1 then word = " title"
    if matched <= 0 then return total.toStr() + word
    return total.toStr() + word + " · " + matched.toStr() + " in your playlists"
end function

' ---- Trakt --------------------------------------------------------------------
'
' Two calls, movies then shows. Trakt always answers the WHOLE watchlist, so
' there is no delta to merge and no stamp to keep.

function pullTrakt(token as string) as object
    ' `token` is also handed BACK, because the first call may have renewed a
    ' sign-in that had run out - the second call and the caller's sign-out
    ' check both need the new one. Set on every branch, including the failures.
    out = { ok: false, unchanged: false, summary: "", stamp: "", wanted: [], token: token }
    wanted = []
    for each ask in [["movies", "movie"], ["shows", "series"]]
        res = relayGet(TraktUrl("watchlist") + "&type=" + ask[0], token, "trakt-" + ask[0], "trakt")
        token = ToStr(res.token)
        out.token = token
        if res.ok <> true
            out.summary = relayFailWords(res, "Trakt")
            return out
        end if
        for each it in ToArray(GetField(res.data, "items"))
            row = wantedRow(ask[1], it)
            if row <> invalid then wanted.push(row)
        end for
    end for
    out.wanted = capWanted(wanted)
    out.ok = true
    return out
end function

' ---- Simkl --------------------------------------------------------------------
'
' ACTIVITIES FIRST, EVERY RUN, INCLUDING THE FIRST. The relay note is emphatic
' about it: "never poll without checking /sync/activities first - an
' unconditional timer gets the client id suspended". If Simkl's `all` stamp
' equals the one we stored, this stops there and asks nothing else.
'
' Otherwise up to four calls, sequentially (Simkl: "wait for each request to
' finish sequentially"), with date_from set to the OLD stamp so the answer is a
' delta.
'
' THE DELTA IS MERGED ONTO WHAT WE ALREADY HAD, which is why the cache keeps
' the raw list (`w`) beside the matched rows. The new rows go in FIRST so that
' if the 60 cap bites it is the stale end of the list that loses.
'
' HONEST LIMIT, and it is in the shape of Simkl's own API rather than in this
' code: a delta carries additions and changes, never removals. A title the
' member takes OFF their Simkl watchlist keeps its tile until a run happens
' with no stored stamp (a fresh sign-in, or cachefs being cleared). Flagged for
' Dave rather than papered over.
'
' THE STAMP ONLY ADVANCES ON A PULL THAT FULLY FINISHED. Every `return` on the
' failure path below leaves `stamp` empty and `ok` false, and the caller writes
' nothing at all - so a run that died after two of the four calls asks again
' from the same place next time rather than skipping what it never read.

function pullSimkl(token as string, cached as object) as object
    ' Handed back for the same reason pullTrakt does it. Simkl has no refresh
    ' and never renews - a refusal signs this box out - but the shape is the
    ' same on both so the caller has one rule, not two.
    out = { ok: false, unchanged: false, summary: "", stamp: "", wanted: [], token: token }

    act = relayGet(SimklUrl("activities"), token, "simkl-activities", "simkl")
    token = ToStr(act.token)
    out.token = token
    if act.ok <> true
        out.summary = relayFailWords(act, "Simkl")
        return out
    end if
    allStamp = ToStr(GetField(act.data, "all"))
    oldStamp = ToStr(GetField(cached, "st"))
    if allStamp <> "" and allStamp = oldStamp
        KLog("sync-simkl", "watchlist unchanged")
        out.ok = true
        out.unchanged = true
        out.stamp = allStamp
        return out
    end if

    fresh = []
    for each ask in [["movies", "movie"], ["shows", "series"]]
        for each state in ["plantowatch", "watching"]
            u = SimklUrl("watchlist") + "&type=" + ask[0] + "&status=" + state
            if oldStamp <> "" then u = u + "&date_from=" + UrlEncode(oldStamp)
            res = relayGet(u, token, "simkl-" + ask[0] + "-" + state, "simkl")
            token = ToStr(res.token)
            out.token = token
            if res.ok <> true
                out.summary = relayFailWords(res, "Simkl")
                return out
            end if
            for each it in ToArray(GetField(res.data, "items"))
                row = wantedRow(ask[1], it)
                if row <> invalid then fresh.push(row)
            end for
        end for
    end for

    ' Carry the previous list forward behind the fresh rows - only when this
    ' WAS a delta. With no old stamp the four calls above asked for everything,
    ' so there is nothing to merge and merging would resurrect removed titles.
    if oldStamp <> ""
        for each w in ToArray(GetField(cached, "w"))
            row = { k: ToStr(GetField(w, "k")), t: ToStr(GetField(w, "t")), y: ToStr(GetField(w, "y")) }
            if row.k <> "" and row.t <> "" then fresh.push(row)
        end for
    end if

    out.wanted = capWanted(fresh)
    out.stamp = allStamp
    out.ok = true
    return out
end function

' ---- One watchlist entry ------------------------------------------------------

' >>> THE ONE PLACE `show` BECOMES `series`. <<<
' Trakt files a television series as "show" and asks for "shows"; Simkl does
' the same. Every screen in this app calls it "series" - normVod, open(),
' FavVodKeyFor, SeriesDetailScreen. One translation, here, so nothing
' downstream ever has to know where a row came from.
function wlKind(raw as string) as string
    k = LCase(ToStr(raw)).trim()
    if k = "show" or k = "shows" or k = "series" or k = "tv" then return "series"
    if k = "movie" or k = "movies" or k = "film" then return "movie"
    return ""
end function

' { k, t, y } - kind, title as the service spells it, release year or "".
' Both relays answer the same four fields for a watchlist row, so one reader
' serves both.
function wantedRow(fallbackKind as string, it as dynamic) as object
    if it = invalid then return invalid
    title = ToStr(GetField(it, "title")).trim()
    if title = "" then return invalid
    kind = wlKind(ToStr(GetField(it, "type")))
    if kind = "" then kind = fallbackKind
    if kind = "" then return invalid
    yr = ToStr(GetField(it, "year"))
    if Len(yr) > 4 then yr = Left(yr, 4)
    if not wlIsYear(yr) then yr = ""
    return { k: kind, t: title, y: yr }
end function

' Dedupe and cap. THE CAP IS APPLIED HERE, before a single catalogue byte is
' fetched - that is the whole reason this function exists rather than the cap
' living down beside the matcher.
function capWanted(rows as object) as object
    seen = {}
    out = []
    for each r in rows
        if out.count() >= WLMAXITEMS() then exit for
        key = r.k + "|" + LCase(r.t) + "|" + r.y
        if seen.doesExist(key) then continue for
        seen[key] = true
        out.push(r)
    end for
    return out
end function

' ---- Matching against the member's own catalogue ------------------------------
'
' The watchlist is at most 60 entries and the catalogue can be 50,000, so the
' loop is INVERTED: the 60 wanted titles become a lookup and the catalogue is
' streamed past it. What is held at the end is at most 60 rows, never the
' catalogue.

sub matchAgainstCatalog(jobs as object)
    ' THREE LOOKUPS, not one, so "no year" never silently becomes "any year".
    '   strict   a wanted entry that HAS a year, keyed with it
    '   named    the same entries by name alone - consulted only when the
    '            CATALOGUE row has no year, which is most film rows
    '   noYear   wanted entries with no year at all, by name
    ' Every key carries the job number in front of it, so both add-ons share
    ' one pass over the catalogue without either seeing the other's entries.
    idx = { strict: {}, named: {}, noYear: {} }
    for jn = 0 to jobs.count() - 1
        wanted = jobs[jn].wanted
        for i = 0 to wanted.count() - 1
            w = wanted[i]
            parted = wlSplitTitle(w.t)
            yr = w.y
            if yr = "" then yr = parted.y
            nameKey = jn.toStr() + "|" + w.k + "|" + parted.n
            if yr <> ""
                idx.strict[nameKey + "|" + yr] = i
                if not idx.named.doesExist(nameKey) then idx.named[nameKey] = i
            else
                if not idx.noYear.doesExist(nameKey) then idx.noYear[nameKey] = i
            end if
        end for
    end for

    ' ONE gate for the whole run, the way SearchScreen builds one for three
    ' scopes: ParentalBlockedCatIds makes its own sub-gate per scope off this
    ' and shares its caches, so the dozen registry reads are paid once.
    gate = ParentalGate("movies")

    for each p in wlXtreamSources()
        pid = ToStr(p.id)
        srcTok = SrcTokenFor(p)
        for each scope in ["movies", "series"]
            action = "get_vod_streams"
            if scope = "series" then action = "get_series"
            rows = fetchCatalogue(XtreamApiUrl(p, action))
            if rows = invalid then continue for
            blocked = ParentalBlockedCatIds(gate, scope, pid, true)
            kind = "movie"
            if scope = "series" then kind = "series"
            for each s in rows
                ' Adult, hidden and PIN-locked categories never reach a
                ' recommendations-style row - certification 6.3 and the same
                ' strict call Home's own Kwick Picks makes.
                if blocked.doesExist(ToStr(GetField(s, "category_id"))) then continue for
                nm = ToStr(GetField(s, "name"))
                if nm = "" then continue for
                ' Split ONCE per catalogue row, not once per add-on: this walks
                ' the name a character at a time and a catalogue can run to
                ' tens of thousands of rows. Nothing is waiting on this thread,
                ' but there is no reason to do it twice.
                parted = wlSplitTitle(nm)
                if parted.n = "" then continue for
                for jn = 0 to jobs.count() - 1
                    found = wlLookup(idx, jn, kind, parted)
                    if found < 0 then continue for
                    ' DEDUPED BY ROUTE: the first source carrying a title wins
                    ' and the same film on a second source never becomes a
                    ' second tile.
                    if jobs[jn].hits.doesExist(found.toStr()) then continue for
                    jobs[jn].hits[found.toStr()] = catalogRowFor(kind, s, srcTok)
                end for
            end for
            ' Let the catalogue go before the next one is asked for. One at a
            ' time, and never two in memory together.
            rows = invalid
        end for
    end for
end sub

' The tile, in HomeScreen's own item shape: OUR id, OUR title, OUR poster, so
' opening it is the ordinary movie or series page and nothing downstream knows
' or cares that it came from Trakt.
function catalogRowFor(kind as string, s as object, srcTok as string) as object
    row = { k: kind, i: "", n: ToStr(GetField(s, "name")), p: "", e: "", s: srcTok }
    if kind = "series"
        row.i = ToStr(GetField(s, "series_id"))
        row.p = ToStr(GetField(s, "cover"))
    else
        row.i = ToStr(GetField(s, "stream_id"))
        row.p = ToStr(GetField(s, "stream_icon"))
        row.e = ToStr(GetField(s, "container_extension"))
    end if
    return row
end function

' Which wanted entry, if any, this catalogue row is. -1 for none.
'
' The one place a year can be ignored is where a year genuinely does not exist:
' get_vod_streams usually carries no date at all (VodContentTask.brs:220), so a
' name-only fallback is not laxness, it is the only way most film rows can ever
' match. What it cannot do is pair two entries that BOTH name a year and
' disagree - that is a different film and is left out.
function wlLookup(idx as object, jn as integer, kind as string, parted as object) as integer
    if parted.n = "" then return -1
    nameKey = jn.toStr() + "|" + kind + "|" + parted.n
    if parted.y <> ""
        ' This row names a year. It may match a wanted entry with the same
        ' year, or one that named no year at all. It must NOT match a wanted
        ' entry that named a different year.
        if idx.strict.doesExist(nameKey + "|" + parted.y) then return ToInt(idx.strict[nameKey + "|" + parted.y])
        if idx.noYear.doesExist(nameKey) then return ToInt(idx.noYear[nameKey])
        return -1
    end if
    ' This row names no year, so the name is all there is to go on.
    if idx.noYear.doesExist(nameKey) then return ToInt(idx.noYear[nameKey])
    if idx.named.doesExist(nameKey) then return ToInt(idx.named[nameKey])
    return -1
end function

' A title split into the part worth comparing and its year. The year rules are
' the same two markings VodContentTask.brs:250-295 found in real libraries -
' bracketed anywhere, or bare at the very end - written out again here because
' a component only gets the scripts its own XML names and that file is a Task
' with an init() of its own.
function wlSplitTitle(rawName as string) as object
    yr = wlYearOf(rawName)
    norm = wlNormText(rawName)
    if yr <> "" then norm = wlDropWord(norm, yr)
    ' A trailing quality tag is decoration the provider added, not part of the
    ' name. Only these, only at the end, and only one - anything broader starts
    ' eating real titles.
    for each tag in ["4k", "uhd", "fhd", "hd", "sd", "hdr"]
        if Len(norm) > Len(tag) + 1 and Right(norm, Len(tag) + 1) = " " + tag
            norm = Left(norm, Len(norm) - Len(tag) - 1).trim()
            exit for
        end if
    end for
    return { n: norm, y: yr }
end function

' Lower case, every non-alphanumeric run collapsed to one space. Applied to
' BOTH sides, so "Spider-Man: No Way Home" and "Spider Man No Way Home" are the
' same string by the time they are compared.
function wlNormText(s as string) as string
    low = LCase(ToStr(s))
    out = ""
    gap = false
    for i = 0 to low.len() - 1
        ch = low.mid(i, 1)
        code = Asc(ch)
        if (code >= 97 and code <= 122) or (code >= 48 and code <= 57)
            out = out + ch
            gap = false
        else
            if out <> "" and not gap
                out = out + " "
                gap = true
            end if
        end if
    end for
    return out.trim()
end function

' Remove one whole word from a normalised string. Never leaves it empty: a film
' called "1917" or "2012" is a name, not a date.
function wlDropWord(norm as string, word as string) as string
    parts = norm.split(" ")
    out = ""
    done = false
    for each w in parts
        if w = word and not done
            done = true
            continue for
        end if
        if out <> "" then out = out + " "
        out = out + w
    end for
    if out.trim() = "" then return norm
    return out.trim()
end function

function wlYearOf(rawName as string) as string
    t = ToStr(rawName).trim()
    n = Len(t)
    if n < 4 then return ""
    ' Bracketed wins - it is the deliberate marking, so it beats a number that
    ' merely happens to sit in the name ("Blade Runner 2049").
    scanAt = 1
    while scanAt <= n
        o = Instr(scanAt, t, "(")
        b = Instr(scanAt, t, "[")
        if o = 0 and b = 0 then exit while
        if o = 0 or (b > 0 and b < o) then o = b
        if o + 5 <= n
            cl = Mid(t, o + 5, 1)
            if cl = ")" or cl = "]"
                y = Mid(t, o + 1, 4)
                if wlIsYear(y) then return y
            end if
        end if
        scanAt = o + 1
    end while
    ' Bare at the very end, with a real word in front of it.
    if n >= 6
        y = Right(t, 4)
        if wlIsYear(y)
            j = n - 4
            gap = false
            while j >= 1 and Mid(t, j, 1) = " "
                gap = true
                j = j - 1
            end while
            if gap and j >= 1 then return y
        end if
    end if
    return ""
end function

function wlIsYear(y as string) as boolean
    if Len(y) <> 4 then return false
    p = Left(y, 2)
    if p <> "19" and p <> "20" then return false
    d = "0123456789"
    if Instr(1, d, Mid(y, 3, 1)) = 0 then return false
    if Instr(1, d, Mid(y, 4, 1)) = 0 then return false
    return true
end function

' Xtream panels only. An M3U playlist carries channels, not a VOD catalogue
' with ids and covers, and a media server answers a different API entirely -
' neither can be matched by this and asking them would be a wasted request.
function wlXtreamSources() as object
    out = []
    for each p in LoadProviders()
        if ToStr(p.ptype) = "m3u" then continue for
        if IsMediaSrcToken(SrcTokenFor(p)) then continue for
        out.push(p)
    end for
    return out
end function

' ---- The catalogue fetch ------------------------------------------------------
'
' ONE AT A TIME, NEVER TWO, AND NEVER UNBOUNDED. This is ApiTask's fetchBounded
' (ApiTask.brs:102-190) in miniature, written out here because that is a Task
' node and a Task cannot usefully observe another Task's answer. Same three
' steps and the same reasons:
'
'   1. Content-Length off the GET's own headers refuses an oversized answer
'      before a byte of the body is read. No HEAD, so no extra request.
'   2. The body lands on cachefs:, which does NOT count against the app's
'      memory allowance, and the transfer is cancelled the moment the
'      part-file passes the cap.
'   3. The finished file is measured once more before a byte of it is read.
'
' The office stick's own movies catalogue is 15 MB (SearchScreen.brs:461) and
' two members' boxes were killed outright by an unbounded one on v1.0.36
' (keys 9BB92E and E1DFE0). maxBytes is worked out on the RENDER thread and
' handed in: a Task's roAppMemoryMonitor reports only its own thread, which is
' the trap that made the v1.0.29 Sports cap dead code.

function fetchCatalogue(url as string) as object
    if url = "" then return invalid
    cap = ToInt(m.top.maxBytes)
    if cap <= 0 then cap = 4000000

    fsys = CreateObject("roFileSystem")
    path = "cachefs:/kwickwl_body_" + wlNowS().toStr() + ".json"

    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.enableEncodings(true)
    xfer.setUrl(url)
    xfer.addHeader("User-Agent", KwickUserAgent())
    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)

    if fsys <> invalid and fsys.Exists(path) then fsys.Delete(path)
    if not xfer.asyncGetToFile(path)
        wlDeleteQuietly(fsys, path)
        return invalid
    end if

    giveUpAt = wlNowS() + Int(ToInt(m.top.catalogueTimeoutMs) / 1000)
    code = 0
    while true
        msg = wait(250, port)
        if type(msg) = "roUrlEvent"
            ' getInt() = 2 is "transfer started", not the end of it. Where a
            ' firmware sends response headers with that event, it is the
            ' earliest the declared length is known.
            if msg.getInt() <> 2
                code = msg.getResponseCode()
                exit while
            end if
            early = wlHeaderBytes(msg.getResponseHeaders())
            if early > cap
                xfer.asyncCancel()
                wlDeleteQuietly(fsys, path)
                KLog("sync-addon", "catalogue refused by declared size - " + early.toStr() + "B over a " + cap.toStr() + "B ceiling")
                return invalid
            end if
        end if
        sofar = wlFileBytes(fsys, path)
        if sofar > cap
            xfer.asyncCancel()
            wlDeleteQuietly(fsys, path)
            KLog("sync-addon", "catalogue cancelled mid-flight at " + sofar.toStr() + "B, over a " + cap.toStr() + "B ceiling")
            return invalid
        end if
        if wlNowS() > giveUpAt
            xfer.asyncCancel()
            wlDeleteQuietly(fsys, path)
            return invalid
        end if
    end while

    if code < 200 or code >= 300
        wlDeleteQuietly(fsys, path)
        return invalid
    end if

    ' THE BACKSTOP, and the one check that cannot be dodged.
    sizeB = wlFileBytes(fsys, path)
    if sizeB <= 0 or sizeB > cap
        wlDeleteQuietly(fsys, path)
        return invalid
    end if

    ' Only NOW does the answer enter the app's memory. roByteArray rather than
    ' ReadAsciiFile, which refuses a file past a size of its own and answers
    ' invalid - that silently dropped the stick's 15 MB movies catalogue out of
    ' Search on 2026-09-16.
    ba = CreateObject("roByteArray")
    body = ""
    if ba.ReadFile(path) then body = ba.ToAsciiString()
    ba = invalid
    wlDeleteQuietly(fsys, path)
    if body = "" then return invalid
    parsed = ParseJson(body)
    body = ""
    if parsed = invalid then return invalid
    return ToArray(parsed)
end function

function wlHeaderBytes(headers as dynamic) as integer
    if headers = invalid then return 0
    for each k in headers
        if LCase(ToStr(k)) = "content-length" then return ToInt(headers[k])
    end for
    return 0
end function

function wlFileBytes(fsys as dynamic, path as string) as integer
    if fsys = invalid then return 0
    if not fsys.Exists(path) then return 0
    st = fsys.Stat(path)
    if st = invalid then return 0
    return ToInt(GetField(st, "size"))
end function

sub wlDeleteQuietly(fsys as dynamic, path as string)
    if fsys = invalid then return
    if fsys.Exists(path) then fsys.Delete(path)
end sub

' ---- One relay call -----------------------------------------------------------
'
' AddOnTask.brs's shape, inline. The member's token goes on exactly one header
' and nowhere else; the log line carries the tag, the status and the relay's
' own error code and NOTHING else - no url with a query on it, no body, no
' token.
'
' >>> AND THE ONE PLACE THIS RUN'S SIGN-IN IS PUT RIGHT. <<<
' A Trakt access token lasts about three months, after which the relay answers
' 401 and this pull - the thing that keeps the member's watchlist row on Home
' alive - is the caller most likely to meet it first, because it runs in the
' background every fifteen minutes whether anybody is watching or not. The
' decision (renew, or sign the member out) belongs to AddOnAuth.brs, which
' AddOnTask uses too, so both paths behave identically. Only the sending is
' duplicated here, which it already was.
'
' ONCE, NEVER TWICE, AND NEVER A LOOP. One renewal per RUN (m.wlRenewed), one
' retry per call, and the retry is a straight second send that cannot come back
' through here. A caller that passes no `svc` gets the old behaviour exactly.
'
' `out.token` IS THE TOKEN THE CALLER SHOULD USE FROM NOW ON. It is the one
' that was sent, unless this call renewed it. The caller MUST carry it forward:
' the rest of the run's calls need it, and wlCacheWrite compares it against
' what is stored to decide whether the member signed out mid-pull - so a run
' that renewed and did not carry it forward would throw its own answer away.
' It is never logged and never reaches `result`.

function relayGet(url as string, token as string, tag as string, svc = "" as string) as object
    out = relaySend(url, token, tag)
    out.token = token
    if svc = "" then return out
    if m.wlRenewed = true then return out
    if not AddOnSignInRefused(ToInt(out.status), ToStr(out.errorCode)) then return out

    m.wlRenewed = true
    tok = RenewAddOnSignIn(svc, token, ToInt(m.top.relayTimeoutMs))
    ' "" means there is nothing to try: the member has just been signed out
    ' here, or was never signed in. The refusal stands and the run records a
    ' failed pull, which writes nothing and redraws nothing.
    if tok = "" then return out

    out = relaySend(url, tok, tag)
    out.token = tok
    return out
end function

function relaySend(url as string, token as string, tag as string) as object
    out = { ok: false, status: 0, data: invalid, error: "", errorCode: "" }
    if url = ""
        out.error = "No address to ask."
        out.errorCode = "network"
        return out
    end if

    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    ' The body of a 401 or a 429 is where these relays SAY why.
    xfer.retainBodyOnError(true)
    xfer.enableEncodings(true)
    xfer.setUrl(url)
    xfer.addHeader("User-Agent", KwickUserAgent())
    xfer.addHeader("Accept", "application/json")
    if token <> "" then xfer.addHeader("Authorization", "Bearer " + token)

    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)
    if not xfer.asyncGetToString()
        out.error = "Couldn't reach kwickplayer.tv. Check this TV's internet connection."
        out.errorCode = "network"
        return out
    end if

    msg = wait(ToInt(m.top.relayTimeoutMs), port)
    if type(msg) <> "roUrlEvent"
        xfer.asyncCancel()
        out.error = "kwickplayer.tv did not answer in time. Try again in a moment."
        out.errorCode = "timeout"
        relayLogFail(tag, out)
        return out
    end if

    out.status = msg.getResponseCode()
    body = ToStr(msg.getString())
    if body.trim() = ""
        out.error = "kwickplayer.tv answered with nothing at all. Try again in a few minutes."
        out.errorCode = "http"
        relayLogFail(tag, out)
        return out
    end if

    parsed = ParseJson(body)
    body = ""
    if parsed = invalid
        ' Deliberately does NOT print the body.
        out.error = "kwickplayer.tv answered, but not with anything this app understands."
        out.errorCode = "badjson"
        relayLogFail(tag, out)
        return out
    end if

    ' The relay's own fault shape, checked BEFORE the status code is: a relay
    ' that answers 200 with an error in the body is still a relay saying no.
    code = ToStr(GetField(parsed, "error"))
    if code <> ""
        out.errorCode = code
        out.error = ToStr(GetField(parsed, "message"))
        out.data = parsed
        relayLogFail(tag, out)
        return out
    end if
    if out.status < 200 or out.status >= 300
        out.errorCode = "http"
        out.error = "That did not work. Try again in a moment."
        out.data = parsed
        relayLogFail(tag, out)
        return out
    end if

    out.ok = true
    out.data = parsed
    return out
end function

sub relayLogFail(tag as string, res as object)
    KLog("sync-addon", "request failed - tag '" + tag + "', status " + ToInt(res.status).toStr() + ", code '" + ToStr(res.errorCode) + "'")
end sub

' What the Settings row says after a failed pull: the service's own words when
' it gave any, our fallback otherwise.
function relayFailWords(res as object, service as string) as string
    msg = ToStr(GetField(res, "error")).trim()
    if msg <> "" then return msg
    return "Could not reach " + service + ". Check the connection and try again."
end function

' ---- The cache ----------------------------------------------------------------
'
' One file per service. The shape, and HomeScreen reads it by these exact
' spellings - ParseJson hands back a CASE-SENSITIVE map, so a key written as
' `it` and read as `It` would never match (four live bugs in this codebase have
' come from exactly that).
'
'   v    schema of this file
'   at   when the last completed ask finished, seconds. The 15-minute throttle.
'   st   Simkl's `all` activities stamp. Trakt leaves it "".
'   n    titles on the member's list at the service
'   m    how many of those this box can actually play
'   sm   the summary sentence Settings shows
'   w    the raw list, [{ k, t, y }] - kept so a Simkl delta can be merged
'   it   the tiles, [{ k, i, n, p, e, s }] - kind, id, name, poster, extension,
'        source token. This is the only key HomeScreen reads.

function wlCacheRead(svc as string) as object
    empty = { v: WLCACHESCHEMA(), at: 0, st: "", n: 0, m: 0, sm: "", w: [], it: [] }
    raw = wlCacheText(WLCachePath(svc))
    if raw = "" then return empty
    p = ParseJson(raw)
    if p = invalid then return empty
    if ToInt(GetField(p, "v")) <> WLCACHESCHEMA() then return empty
    return p
end function

' Rewrite only the "we asked just now" stamp, leaving the items alone. Simkl's
' unchanged path.
sub wlCacheTouch(svc as string, startToken as string, summary as string)
    cached = wlCacheRead(svc)
    st = wlCacheWrite(svc, startToken, ToArray(GetField(cached, "it")), ToArray(GetField(cached, "w")), ToStr(GetField(cached, "st")), summary)
    if st = "signedout" then KLog("sync-" + svc, "signed out while this was running - nothing recorded")
end sub

' "ok", "signedout" or "writefail". THREE answers rather than a boolean because
' the two failures mean opposite things to the caller: a sign-out means throw
' the whole run away and record nothing, while a refused write means the pull
' itself was fine and only the cache is missing.
function wlCacheWrite(svc as string, startToken as string, rows as object, wanted as object, stamp as string, summary as string) as string
    ' >>> SIGN-OUT MID-PULL. <<<
    ' Re-read the credential and compare it with the one this run belonged to.
    ' Cleared (signed out) or replaced (a different member) both fail here, and
    ' the answer is thrown away whole - no rows, no stamp, no summary. Without
    ' this the next member on the box inherits the last one's row.
    fresh = AddOnAccount(svc)
    if fresh.token <> startToken then return "signedout"

    rec = {}
    rec["v"] = WLCACHESCHEMA()
    rec["at"] = wlNowS()
    rec["st"] = ToStr(stamp)
    rec["n"] = wanted.count()
    rec["m"] = rows.count()
    rec["sm"] = ToStr(summary)
    rec["w"] = wanted
    rec["it"] = rows

    raw = FormatJson(rec)
    ' THE CEILING. Drop tiles off the END until it fits - never truncate the
    ' text, because half a JSON document reads back as no cache at all.
    keep = rows.count()
    while Len(raw) > WLCACHEMAXBYTES() and keep > 0
        keep = keep - 1
        trimmed = []
        for i = 0 to keep - 1
            trimmed.push(rows[i])
        end for
        rec["it"] = trimmed
        rec["m"] = keep
        raw = FormatJson(rec)
    end while
    if keep < rows.count()
        KLog("sync-" + svc, "watchlist cache trimmed to " + keep.toStr() + " title(s) to stay under " + WLCACHEMAXBYTES().toStr() + "B")
    end if

    wrote = WriteAsciiFile(WLCachePath(svc), raw)
    if not wrote
        ' cachefs: is scratch the firmware may clear or refuse. Losing it costs
        ' one refetch and nothing else, which is why the cache lives there — but
        ' say so, because the alternative is a row that silently never appears.
        KLog("sync-" + svc, "could not write the watchlist cache (" + Len(raw).toStr() + "B) - the row will be rebuilt on the next run")
        return "writefail"
    end if
    return "ok"
end function

' The contents of a cachefs: file, or "".
'
' >>> WHY Exists() IS NOT TRUSTED ON ITS OWN. <<<
' Measured on the office Streaming Stick 2026-09-17 and written up in
' [[Roku - Outside Subtitle Files Never Appear (Measured)]]: Exists() and
' GetDirectoryListing("cachefs:/") DISAGREED about a file that then read back
' 97,610 bytes. Exists() alone would make the whole watchlist row silently
' never appear on that firmware, which is the worst possible failure - nothing
' on screen, nothing in the log, nothing to chase.
'
' So Exists() is kept as the fast path (it costs one stat and is right almost
' always, and it is what keeps a fresh box from printing a BrightScript ERROR
' line on every Home rebuild), and the directory listing is the second opinion
' when it says no. That is the exact pattern PlayerScreen.subFileInCacheList
' settled on for the same measurement.
' >>> NOTHING IS ASKED ABOUT THE FILE. IT IS JUST READ. <<<
'
' This used to try Exists() and fall back to GetDirectoryListing("cachefs:/").
' Measured on the office stick 2026-09-18: BOTH of those answered "no" about a
' watchlist cache this very file had just written, and the Home row drew
' nothing for three sync runs while the log insisted the titles had arrived.
' The full measurement, and the 2026-09-17 one before it, are in
' [[Roku - Outside Subtitle Files Never Appear (Measured)]].
'
' The rule it settles: nothing that merely asks ABOUT a cachefs: file can be
' believed on this firmware, so a read is the only honest test. It is also
' enough on its own - ReadAsciiFile answers "" for a file that is not there,
' which is the same answer as a file that is there and empty, and both mean
' "no cache". Wrapped because reading a missing path is allowed to be noisy,
' and this runs on every sync.
'
' WHY IT MATTERED HERE AS WELL AS IN HomeScreen: this is the reader the Simkl
' delta depends on. A cache that reads back empty loses the stored activities
' stamp, so every run looks like a first run and refetches the lot - four
' calls instead of one, against an allowance the whole membership shares.
function wlCacheText(path as string) as string
    if path = "" then return ""
    try
        return ToStr(ReadAsciiFile(path))
    catch e
        return ""
    end try
end function

function wlNowS() as integer
    return CreateObject("roDateTime").asSeconds()
end function
