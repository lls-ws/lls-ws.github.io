' The TV half of kwickplayer.tv/link, in ONE place.
'
' The shape of it: ask the link service for a code (claim), hand the code
' and a QR of the same address to whoever is drawing, then ask every few
' seconds what the member has added (poll). Anything that comes back is
' saved through exactly the same call the Connect Your Provider screen uses,
' so a source added this way is indistinguishable from one typed in on the
' remote.
'
' This used to live inside SourceLinkScreen. It moved out here when the
' store edition's first screen started showing the code as well: two screens
' showing the same code must not be two copies of the same state machine,
' or one of them quietly rots.
'
' Nothing here loops on its own once the session is stopped: both timers are
' stopped and any request still in the air is stopped with them. A host that
' gets torn down without saying so is caught too — every timer step checks
' the node is still attached to a scene and shuts down if it isn't, so there
' is no such thing as an orphaned poll.
'
' THE PERMANENT KEY IS NOT PUBLISHED HERE, deliberately. The service issues
' every box a sixteen-character key alongside the pairing code, for a member
' coming back later to manage this TV's sources; it is cached (below) and
' drawn in Settings, because two codes side by side on the one screen — six
' characters that expire in fifteen minutes, sixteen that never do — is the
' shape of a support call.

sub init()
    m.stepTimer = m.top.findNode("stepTimer")
    m.stepTimer.observeField("fire", "onStepTimer")
    m.tickTimer = m.top.findNode("tickTimer")
    m.tickTimer.observeField("fire", "onTick")

    m.deviceId = ""
    m.secret = ""
    m.expiresAt = 0
    m.skew = 0          ' server clock minus this box's clock, in seconds
    m.since = 0
    m.fails = 0         ' failures since the last good answer
    m.idleStep = 0      ' how many times we've given up and gone quiet
    m.polls = 0         ' good polls this session — 1 is the first answer
    m.task = invalid
    m.nextAction = "poll"
    m.lines = []
    ' The link service's ids this session has been told to leave alone —
    ' see the skip note above handlePoll(). Empty on every ordinary session.
    m.skipIds = {}
    ' Made the first time a media server lands, then reused.
    m.msSignIn = invalid
end sub

' ---- Starting and stopping --------------------------------------------------

sub onActiveChanged()
    if m.top.active
        startSession()
    else
        linkShutdown()
    end if
end sub

sub startSession()
    m.deviceId = LinkDeviceId()
    m.since = LinkCursor()
    m.fails = 0
    m.idleStep = 0
    m.polls = 0
    m.lines = []
    m.skipIds = {}
    m.top.addedCount = 0
    m.top.addedLines = []
    if m.top.skipRestore then KLog("link", "this TV was just cleared - pairing as normal, but not taking its website playlists back on this screen")
    m.tickTimer.control = "start"
    startClaim()
end sub

' Leaving takes everything with it: no timer left ticking, no request left
' in the air, and nothing still polling the service in the background.
sub linkShutdown()
    m.stepTimer.control = "stop"
    m.tickTimer.control = "stop"
    if m.msSignIn <> invalid then m.msSignIn.active = false
    stopTask()
    m.top.state = "idle"
end sub

' The Try Again button, and nothing else — a host with no such button uses
' idleRetry instead.
sub onRetryNow()
    if not m.top.retryNow then return
    m.top.retryNow = false
    if not m.top.active then return
    m.fails = 0
    m.idleStep = 0
    startClaim()
end sub

' ---- Talking to the link service -------------------------------------------

sub startClaim()
    m.top.state = "claiming"
    m.top.code = ""
    m.top.codeText = ""
    m.top.qr = []
    m.top.expiresText = ""
    setStatus("claiming", "Getting your code...")
    startTask("claim")
end sub

sub startTask(action as string)
    stopTask()
    t = CreateObject("roSGNode", "SourceLinkTask")
    t.action = action
    t.device = m.deviceId
    if action = "claim"
        ' Claiming is also where we tell the service what this TV already
        ' has, so the website has a row to show somebody who hasn't added
        ' anything there yet. Worked out fresh each claim rather than once
        ' at init, so it is always the truth at the moment we say it.
        t.builtin = LinkBuiltinSource()
    end if
    if action = "poll"
        t.since = m.since
        ' Every poll carries the secret the code came with.
        t.secret = m.secret
    end if
    t.observeField("result", "onLinkResult")
    m.task = t
    t.control = "RUN"
end sub

sub stopTask()
    if m.task = invalid then return
    m.task.unobserveField("result")
    m.task.control = "STOP"
    m.task = invalid
end sub

' Both the next claim and the next poll go through the one timer, so there
' is never more than one request queued up.
sub schedule(action as string, secs as integer)
    m.nextAction = action
    m.stepTimer.control = "stop"
    m.stepTimer.duration = secs
    m.stepTimer.control = "start"
end sub

sub onStepTimer()
    ' Belt and braces: a host that was thrown away without clearing active
    ' takes the polling with it rather than leaving it running forever.
    if m.top.getScene() = invalid
        linkShutdown()
        return
    end if
    if m.nextAction = "claim"
        startClaim()
    else
        startTask("poll")
    end if
end sub

sub onLinkResult(event as object)
    if m.task = invalid then return
    action = ToStr(m.task.action)
    m.task = invalid
    ' An answer that lands after the session was stopped changes nothing.
    if not m.top.active then return
    res = event.getData()
    if action = "claim"
        handleClaim(res)
    else
        handlePoll(res)
    end if
end sub

sub handleClaim(res as object)
    if res = invalid or res.ok <> true
        handleFailure(res, "claim")
        return
    end if
    m.fails = 0
    m.idleStep = 0
    m.top.state = "waiting"
    m.secret = ToStr(GetField(res, "secret"))
    m.expiresAt = ToInt(GetField(res, "expires"))
    ' Every claim carries this box's permanent key and the secret that
    ' unlocks it, so pairing here is the one and only trip Settings needs:
    ' it draws the cached key the moment it opens, on this box, forever.
    ' Both calls no-op when the value hasn't changed, which after the first
    ' pairing is always.
    SetLinkSecret(m.secret)
    SetLinkDeviceKey(ToStr(GetField(res, "key_fmt")))
    m.top.qr = ToArray(GetField(res, "qr"))
    m.top.code = ToStr(GetField(res, "code"))
    m.top.codeText = spacedCode(m.top.code)
    showWaitingStatus()
    ' Straight into a poll: sources the member added before this screen was
    ' opened are sitting there already.
    schedule("poll", 1)
end sub

' THE ONE SESSION THAT DOESN'T TAKE ITS PLAYLISTS BACK (skipRestore).
'
' A box that has just been cleared in Settings looks EXACTLY like a box that
' has just been reinstalled: no sources, cursor back to zero, and the same
' device id it has always had. So the first screen pairs on its own, the
' service resends every playlist the member has on kwickplayer.tv, and a
' clean slate undoes itself a second after it was asked for.
'
' Telling the two apart is not something the service can do for us — nothing
' in a poll says whether a member is standing in front of the television — so
' the television says it instead: the clean slate sets a one-shot flag, the
' first screen consumes it and turns this on for that one visit.
'
' What it does, and just as importantly what it doesn't:
'
'   the FIRST answer is what this box already had. Every id in it is written
'   down and left alone — not applied, not counted, not announced — so
'   nothing lands, no "arrived" fires, and the member stays on the first
'   screen with the choice they asked for.
'
'   every LATER answer still lands. A playlist the member adds on the website
'   while sitting there is not in that list, so it is applied and announced
'   exactly as always. Pairing is not disabled by any of this: the code and
'   the QR are claimed and drawn the same way, and using them works.
'
'   the cursor stands still (below), so nothing is stranded on the website.
'
' It lasts for this session and dies with it. The next visit to the first
' screen restores silently again, which is what a reinstalled box needs.
sub handlePoll(res as object)
    if res = invalid or res.ok <> true
        answer = ""
        if res <> invalid then answer = ToStr(GetField(res, "code"))
        if answer = "forbidden" or answer = "bad_device"
            ' The code has lapsed or the secret no longer matches. Get a
            ' fresh one rather than leaving a dead code on the screen.
            startClaim()
            return
        end if
        handleFailure(res, "poll")
        return
    end if
    m.fails = 0
    m.idleStep = 0
    m.polls = m.polls + 1

    ' The service's clock is the one the expiry is measured against, so the
    ' countdown follows it rather than this box's clock.
    serverNow = ToInt(GetField(res, "now"))
    if serverNow > 0 then m.skew = serverNow - CreateObject("roDateTime").asSeconds()

    landed = 0
    for each entry in ToArray(GetField(res, "sources"))
        ' Everything is taken, in every ordinary session. The one exception
        ' is the entry this session was told to leave where it is — see the
        ' note above — and it has to be decided BEFORE applyEntry, because
        ' applying is what puts a playlist back on the television.
        take = true
        if m.top.skipRestore then take = not leaveEntryAlone(entry)
        if take and applyEntry(entry) then landed = landed + 1
    end for

    ' Moved on only after everything in this batch is saved, so an entry we
    ' failed to apply comes round again.
    '
    ' AND NOT MOVED ON AT ALL while skipRestore is on. "since" is this box
    ' saying "I have taken everything up to here", and in this one session it
    ' deliberately hasn't. Advanced past a playlist we left alone, the
    ' service would never offer that playlist again until the member edited
    ' it on the website — stranded on kwickplayer.tv, listed as being on this
    ' TV, and never coming back to it. That is the exact damage clearing a
    ' television promises not to do. Standing still costs one small answer
    ' re-read every four seconds for as long as this one screen is open, and
    ' costs nothing at all afterwards: ApplyLinkedSource compares revs, so an
    ' entry that DID land and comes round again does nothing.
    cursor = ToInt(GetField(res, "cursor"))
    if cursor > m.since and not m.top.skipRestore
        m.since = cursor
        SetLinkCursor(cursor)
    end if

    if m.top.state = "waiting" then showWaitingStatus()
    signInToMediaServers()
    if landed > 0
        ' "first" is what tells a host the difference between sources this
        ' box already had — they all come back on the very first answer,
        ' which is a reinstalled box quietly getting itself back — and one
        ' the member has just added while sitting there watching.
        wasFirst = (m.polls = 1)
        m.top.arrived = { count: landed, first: wasFirst }
    end if
    schedule("poll", 4)
end sub

' Is this one of the playlists this session was told to leave where it is?
'
' The first good answer defines the set — that answer IS "what this box
' already had" — and every id in it is written down as it goes past. After
' that the list only ever gets read, so a playlist the member adds while the
' screen is open is not in it and lands normally.
'
' Written down by id rather than counted, because the cursor stands still in
' this session and the same batch comes round every four seconds: counting
' would forget which ones they were the moment anything new arrived.
function leaveEntryAlone(entry as dynamic) as boolean
    id = ToStr(GetField(entry, "id"))
    if id = "" then return false
    if m.polls = 1 then m.skipIds[id] = true
    return m.skipIds.doesExist(id)
end function

function applyEntry(entry as dynamic) as boolean
    outcome = ApplyLinkedSource(entry)
    what = ToStr(GetField(outcome, "action"))
    label = ToStr(GetField(outcome, "name"))
    if what = "added"
        m.top.addedCount = m.top.addedCount + 1
        pushLine("Added " + label)
        return true
    else if what = "updated"
        pushLine("Updated " + label)
    else if what = "removed"
        pushLine("Removed " + label)
    end if
    return false
end function

' A Jellyfin or an Emby paired on the website arrives as an address and a
' sign-in and nothing else — kwickplayer.tv has never spoken to that server,
' so only the app can fetch the token, the user id and the server's own id.
' It is done HERE, while the member is still looking at the pairing screen,
' so "Added My Jellyfin" means a source that actually works and not one that
' fails the first time they open Movies & Series.
'
' Fire-and-forget on purpose. A server that is switched off right now is not
' a failed pairing: the source is stored either way, and the next attempt
' comes free the next time this screen opens or the app starts.
sub signInToMediaServers()
    if MediaServersNeedingSignIn().count() = 0 then return
    if m.msSignIn = invalid
        m.msSignIn = CreateObject("roSGNode", "MediaServerSignIn")
        m.msSignIn.observeField("signedIn", "onMediaServerSignedIn")
        m.top.appendChild(m.msSignIn)
    end if
    if m.msSignIn.state = "working" then return
    m.msSignIn.providerId = ""
    m.msSignIn.active = true
end sub

sub onMediaServerSignedIn(event as object)
    r = event.getData()
    if r = invalid then return
    nm = ToStr(GetField(r, "name"))
    if GetField(r, "ok") = true
        pushLine("Signed in to " + nm)
    else
        pushLine("Couldn't sign in to " + nm + " yet - it will try again later")
    end if
end sub

sub pushLine(text as string)
    KLog("link", text)
    m.lines.push(text)
    m.top.addedLines = m.lines
end sub

' Every failure that isn't the service telling us something useful ends up
' here: a couple of quiet retries, then a plain message. No machine codes
' are ever put in front of a member.
sub handleFailure(res as object, what as string)
    answer = ""
    if res <> invalid then answer = ToStr(GetField(res, "code"))

    if answer = "rate_limited" or answer = "busy"
        ' Not a fault — the service is asking us to slow down. Keep waiting,
        ' just less often, and don't count it against the retries.
        schedule(what, 20)
        return
    end if

    m.fails = m.fails + 1
    if m.fails >= 3
        m.top.state = "failed"
        m.stepTimer.control = "stop"
        setStatus("down", "Can't reach kwickplayer.tv right now. Check the Roku's internet connection, then try again.")
        if m.top.idleRetry
            ' A host with no Try Again button on it (the first screen, where
            ' the sign-in form is the thing that matters) gets one quiet
            ' attempt a minute, then slower, then every five minutes and no
            ' faster — so a router that comes back fixes the screen without
            ' anybody pressing anything, and a service that is genuinely
            ' down is not hammered by every TV sitting on its first screen.
            waits = [60, 120, 300]
            secs = waits[waits.count() - 1]
            if m.idleStep < waits.count() then secs = waits[m.idleStep]
            m.idleStep = m.idleStep + 1
            m.fails = 0
            schedule("claim", secs)
        end if
        return
    end if
    setStatus("retrying", "Having trouble reaching kwickplayer.tv - trying again...")
    schedule(what, 4 * m.fails)
end sub

' ---- The code's fifteen minutes ---------------------------------------------

sub onTick()
    if m.top.getScene() = invalid
        linkShutdown()
        return
    end if
    if m.top.state <> "waiting" then return
    if m.expiresAt <= 0 then return
    remaining = m.expiresAt - (CreateObject("roDateTime").asSeconds() + m.skew)
    if remaining <= 0
        ' Never leave somebody staring at a code that stopped working.
        setStatus("expired", "That code ran out - getting you a new one...")
        m.stepTimer.control = "stop"
        startClaim()
        return
    end if
    m.top.expiresText = "This code works for another " + mmss(remaining)
end sub

function mmss(secs as integer) as string
    mins = Int(secs / 60)
    rest = secs - mins * 60
    tail = rest.toStr()
    if rest < 10 then tail = "0" + tail
    return mins.toStr() + ":" + tail
end function

' ---- What to say ------------------------------------------------------------

' Spaced out, because six characters run together at this size are easy to
' misread across a room.
function spacedCode(theCode as string) as string
    out = ""
    for i = 0 to theCode.len() - 1
        if i > 0 then out = out + " "
        out = out + theCode.mid(i, 1)
    end for
    return out
end function

' statusText goes out before statusCode, so a host woken by the code can
' read the wording in the same breath.
sub setStatus(kind as string, text as string)
    m.top.statusText = text
    m.top.statusCode = kind
end sub

sub showWaitingStatus()
    if m.top.addedCount = 0
        setStatus("waiting", "Waiting for your sources... they'll appear here on their own.")
        return
    end if
    ' Word for word what the store edition's first screen says when a
    ' playlist lands there (OnboardScreen's showArrivedDialog), with this
    ' screen's own "and here's what to do next" on the end. Two pairing
    ' screens, one sentence.
    '
    ' Broken by hand at the full stop, the same way the first screen's
    ' sign-in blurb is: left to the wrap this runs 67 pixels past the end of
    ' a 1000-wide, two-line label and strands the word "Done." on a line of
    ' its own. Two sentences, two lines, and where the break falls can't
    ' wander the next time a word changes.
    appName = KwickBranding().appName
    tail = Chr(10) + "Add more on the website, or press Done."
    if m.top.addedCount = 1
        setStatus("waiting", "Your playlist has been added to " + appName + "." + tail)
        return
    end if
    setStatus("waiting", "Your " + m.top.addedCount.toStr() + " playlists have been added to " + appName + "." + tail)
end sub
