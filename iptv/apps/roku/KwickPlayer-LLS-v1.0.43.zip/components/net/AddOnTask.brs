' One request to an add-on relay. See the XML for why this is not ApiTask and
' for what every field of `result` means.
'
' Shaped on MediaServerTask.brs, which is itself shaped on the three tasks in
' this app that already hand-roll a POST — SourceLinkTask.brs:104-112,
' SyncTask.brs:2056-2061, ExportLogsTask.brs:9-28 — so the certificate setup
' and the message-port wait match what is proven on the box.

sub init()
    m.top.functionName = "fetchAddOn"
end sub

' >>> ONE REQUEST, AND AT MOST ONE SECOND GO AT IT. <<<
'
' A Trakt access token lasts about three months. When it runs out the relay
' answers 401, and this is where that is put right: renew the sign-in, send the
' SAME request again, hand back the second answer. It lives here rather than in
' the callers because two of the four callers — scrobbles from the player and
' checkmarks from the detail pages — deliberately never look at the answer, so
' a renewal written in a caller could not work for them.
'
' NEVER TWICE, AND NOT BECAUSE OF A COUNTER. There is no loop below: one send,
' one decision, one more send. RenewAddOnSignIn never calls back into here, so
' there is no path that can reach the renewal a second time inside one request.
'
' A MEMBER MID-FILM SEES NOTHING. The retry is silent, and so is its failure.
' The only thing this can ever make visible is the Settings row going back to
' "Not signed in" when the sign-in genuinely cannot be renewed — which is the
' honest thing to show, and better than a feature that quietly does nothing.
sub fetchAddOn()
    res = addOnSend(ToStr(m.top.bearer))

    if AddOnSignInRefused(ToInt(GetField(res, "status")), ToStr(GetField(res, "errorCode")))
        tok = RenewAddOnSignIn(ToStr(m.top.service), ToStr(m.top.bearer), ToInt(m.top.timeoutMs))
        if tok <> "" then res = addOnSend(tok)
    end if

    finishAddOn(res)
end sub

' The request itself. Takes the token to send rather than reading m.top.bearer,
' so the retry above goes out with the NEW one and there is no way to send the
' dead token twice.
function addOnSend(bearer as string) as object
    url = ToStr(m.top.url)
    if url = ""
        return addOnResult(false, 0, invalid, "No address to ask.", "network")
    end if

    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    ' The body of a 401, a 403 or a 406 is where these relays SAY why — it is
    ' the { error, message } pair the whole error path below is built on — so
    ' it has to survive the refusal.
    xfer.retainBodyOnError(true)
    xfer.enableEncodings(true)
    xfer.setUrl(url)
    xfer.addHeader("User-Agent", KwickUserAgent())
    xfer.addHeader("Accept", "application/json")
    ' The member's own token, and the only place it is ever put on a request.
    ' Not logged here or anywhere below.
    if bearer <> "" then xfer.addHeader("Authorization", "Bearer " + bearer)

    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)

    started = false
    if UCase(ToStr(m.top.method)) = "POST"
        xfer.addHeader("Content-Type", "application/json")
        started = xfer.asyncPostFromString(ToStr(m.top.bodyJson))
    else
        started = xfer.asyncGetToString()
    end if
    if not started
        return addOnResult(false, 0, invalid, "Couldn't reach kwickplayer.tv. Check this TV's internet connection.", "network")
    end if

    msg = wait(m.top.timeoutMs, port)
    if type(msg) <> "roUrlEvent"
        xfer.asyncCancel()
        return addOnResult(false, 0, invalid, "kwickplayer.tv did not answer in time. Try again in a moment.", "timeout")
    end if

    status = msg.getResponseCode()
    body = ToStr(msg.getString())

    ' A 2xx with nothing in it is a real answer for the calls that expect no
    ' body back (a sign-out is one).
    if body.trim() = ""
        if status >= 200 and status < 300
            return addOnResult(true, status, invalid, "", "")
        end if
        return addOnResult(false, status, invalid, addOnHttpText(status), "http")
    end if

    parsed = ParseJson(body)
    if parsed = invalid
        ' Deliberately does NOT print the body: a sign-in answer that failed to
        ' parse still has the member's token in it.
        return addOnResult(false, status, invalid, "kwickplayer.tv answered, but not with anything this app understands. Try again in a few minutes.", "badjson")
    end if

    ' THE RELAY'S OWN FAULT SHAPE, checked before the status code is. Every
    ' relay answers { error: <code>, message: <plain words> } when something
    ' goes wrong, and the message is already written for a member — pass it
    ' through rather than inventing a second wording. It is read whatever the
    ' status says, because a relay that answers 200 with an error in the body
    ' is still a relay saying no.
    relayCode = ToStr(GetField(parsed, "error"))
    if relayCode <> ""
        relayMsg = ToStr(GetField(parsed, "message"))
        return addOnResult(false, status, parsed, relayMsg, relayCode)
    end if

    if status < 200 or status >= 300
        return addOnResult(false, status, parsed, addOnHttpText(status), "http")
    end if

    return addOnResult(true, status, parsed, "", "")
end function

' All five fields, every time, so a caller can never read an errorCode left
' behind by the last call.
function addOnResult(ok as boolean, status as integer, data as dynamic, error as string, errorCode as string) as object
    return { ok: ok, status: status, data: data, error: error, errorCode: errorCode }
end function

' One way out. The log line carries the tag, the status and the code and
' NOTHING else — no url with a query on it, no body, no token. A request that
' was renewed and retried logs only its final answer, because the renewal path
' says what it did in its own words.
sub finishAddOn(res as object)
    if GetField(res, "ok") <> true
        KLog("addon", "request failed - tag '" + ToStr(m.top.tag) + "', status " + ToInt(GetField(res, "status")).toStr() + ", code '" + ToStr(GetField(res, "errorCode")) + "'")
    end if
    m.top.result = res
end sub

' What a member reads when the relay refused without saying why in its own
' words. Rare — the relays fill in { error, message } on every fault they know
' about — so these are the cases where something in front of the relay
' answered instead (the host, a proxy, a 404 on a relay that is not deployed).
function addOnHttpText(status as integer) as string
    if status = 401 or status = 403 then return "That sign-in was not accepted. Sign in again."
    if status = 404 then return "This add-on is not available yet. Try again after the next update."
    if status = 429 then return "Too many requests for the moment. Wait a little and try again."
    if status >= 500 then return "kwickplayer.tv is having trouble (" + status.toStr() + "). Try again shortly."
    ' NO BARE STATUS NUMBER. A member cannot act on "(400)" and this app's
    ' rule is that no machine code is ever put in front of one; the status is
    ' in the log line already, which is where it is useful.
    return "That did not work. Try again in a moment."
end function
