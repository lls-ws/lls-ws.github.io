' One authenticated request to a Jellyfin or Emby server. See the XML for why
' this is not ApiTask.
'
' Shaped on the three tasks in this app that already hand-roll a POST —
' SourceLinkTask.brs:104-112, SyncTask.brs:2056-2061, ExportLogsTask.brs:9-28 —
' so the certificate setup and the message-port wait match what is proven here.

sub init()
    m.top.functionName = "fetchMediaServer"
end sub

sub fetchMediaServer()
    url = ToStr(m.top.url)
    if url = ""
        m.top.result = { ok: false, status: 0, data: invalid, error: "No address to ask." }
        return
    end if

    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    ' The body of a 401 or a 404 is the only place these servers say WHY, and
    ' the member-facing sentence is chosen from the status code, so keep it.
    xfer.retainBodyOnError(true)
    xfer.enableEncodings(true)
    xfer.setUrl(url)
    xfer.addHeader("User-Agent", KwickUserAgent())
    xfer.addHeader("Accept", "application/json")
    for each h in ToArray(m.top.headers)
        line = ToStr(h)
        at = Instr(1, line, ":")
        if at > 1
            nm = Left(line, at - 1)
            vl = Mid(line, at + 1)
            ' A header value keeps its own spacing after the colon; only the
            ' one separator space is ours to drop.
            if Left(vl, 1) = " " then vl = Mid(vl, 2)
            xfer.addHeader(nm, vl)
        end if
    end for

    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)

    started = false
    if UCase(ToStr(m.top.method)) = "POST"
        xfer.addHeader("Content-Type", "application/json")
        started = xfer.asyncPostFromString(ToStr(m.top.bodyJson))
    else
        started = xfer.asyncGetToString()
    end if
    if not started
        m.top.result = { ok: false, status: 0, data: invalid, error: "Couldn't reach that address." }
        return
    end if

    msg = wait(m.top.timeoutMs, port)
    if type(msg) <> "roUrlEvent"
        xfer.asyncCancel()
        m.top.result = { ok: false, status: 0, data: invalid, error: "The server did not answer in time. If it is on your home network, check this device is on the same network." }
        return
    end if

    code = msg.getResponseCode()
    body = ToStr(msg.getString())

    if code < 200 or code >= 300
        m.top.result = { ok: false, status: code, data: invalid, error: MsHttpErrorText(code) }
        return
    end if

    ' A 2xx with nothing in it is a real answer for the calls that expect no
    ' body; only a body that IS there and will not parse is a failure.
    if body.trim() = ""
        m.top.result = { ok: true, status: code, data: invalid, error: "" }
        return
    end if
    parsed = ParseJson(body)
    if parsed = invalid
        m.top.result = { ok: false, status: code, data: invalid, error: "That address answered, but not with anything this app understands. Check it is the server's own address." }
        return
    end if
    m.top.result = { ok: true, status: code, data: parsed, error: "" }
end sub

' What the member reads for each way a server says no. Ported from the Flutter
' app's describeMediaServerError (media_server_client.dart:269-303) so the two
' apps explain the same failure the same way.
function MsHttpErrorText(code as integer) as string
    if code = 401 then return "That username or password was not accepted."
    if code = 403 then return "That account is not allowed to sign in from this device."
    if code = 404 then return "That address answered, but it is not a media server. Check the port — Jellyfin and Emby usually run on 8096."
    if code >= 500 then return "The server is having trouble (" + code.toStr() + "). Try again shortly."
    return "The server refused the request (" + code.toStr() + ")."
end function
