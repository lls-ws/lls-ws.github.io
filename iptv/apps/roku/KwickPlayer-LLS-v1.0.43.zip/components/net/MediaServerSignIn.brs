' Signing in to the member's own Jellyfin or Emby servers. See the XML.
'
' The conversation is the same one the Add a media server screen has, in the
' same order and with the same one retry, so a server paired from the website
' and a server typed in on a sideload end up stored identically:
'
'   1. GET  /System/Info/Public   — who are you, and what is your id
'      (an Emby published under /emby answers nothing at the bare address, so
'       that ONE alternative is tried before giving up)
'   2. POST /Users/AuthenticateByName {"Username":..,"Pw":..}
'   3. write the token, the user id and the server id against the source

sub init()
    m.queue = []
    m.current = invalid
    m.task = invalid
end sub

sub onActiveChanged()
    if not m.top.active
        stopEverything()
        return
    end if
    m.top.okCount = 0
    m.top.failCount = 0
    m.queue = buildQueue()
    if m.queue.count() = 0
        m.top.state = "done"
        m.top.active = false
        return
    end if
    m.top.state = "working"
    nextServer()
end sub

function buildQueue() as object
    wanted = ToStr(m.top.providerId)
    out = []
    for each p in MediaServersNeedingSignIn()
        if wanted = "" or ToStr(p.id) = wanted then out.push(p)
    end for
    return out
end function

sub stopEverything()
    if m.task <> invalid
        m.task.unobserveField("result")
        m.task.control = "STOP"
        m.task = invalid
    end if
    m.queue = []
    m.current = invalid
    if m.top.state = "working" then m.top.state = "idle"
end sub

sub nextServer()
    if not m.top.active then return
    if m.queue.count() = 0
        m.top.state = "done"
        m.top.active = false
        return
    end if
    p = m.queue.shift()
    m.current = {
        id: ToStr(p.id),
        name: ToStr(p.name),
        brand: ToStr(p.ptype),
        base: ToStr(p.server),
        username: ToStr(p.username),
        password: ToStr(p.password),
        serverId: "",
        serverName: "",
        triedEmbyPath: false
    }
    if m.current.base = "" or m.current.username = "" or m.current.password = ""
        ' Nothing to sign in WITH. Not an error worth retrying — the member
        ' has to fix the source on kwickplayer.tv.
        finishOne(false, "That source is missing its address or its sign-in.")
        return
    end if
    probe(m.current.base)
end sub

sub probe(base as string)
    ask(MsPublicInfoUrl(base), "GET", "", [], "onPublicInfo", 20000)
end sub

sub ask(url as string, method as string, body as string, headers as object, callback as string, timeoutMs as integer)
    t = CreateObject("roSGNode", "MediaServerTask")
    t.url = url
    t.method = method
    t.bodyJson = body
    t.headers = headers
    t.timeoutMs = timeoutMs
    t.observeField("result", callback)
    m.task = t
    t.control = "RUN"
end sub

sub onPublicInfo(event as object)
    if not m.top.active then return
    if m.current = invalid then return
    res = event.getData()
    if res = invalid then return

    if res.ok <> true
        if not m.current.triedEmbyPath and Right(LCase(m.current.base), 5) <> "/emby"
            m.current.triedEmbyPath = true
            m.current.base = m.current.base + "/emby"
            probe(m.current.base)
            return
        end if
        finishOne(false, ToStr(res.error))
        return
    end if

    d = res.data
    m.current.serverName = ToStr(GetField(d, "ServerName"))
    m.current.serverId = ToStr(GetField(d, "Id"))
    ' Jellyfin names itself here; Emby sends no ProductName at all. The
    ' website files every media server as "jellyfin" because it never speaks
    ' to the server, so this is where a wrong guess gets corrected.
    product = ToStr(GetField(d, "ProductName"))
    if Instr(1, LCase(product), "jellyfin") > 0
        m.current.brand = "jellyfin"
    else
        m.current.brand = "emby"
    end if
    if m.current.serverId = ""
        finishOne(false, "That address answered, but it did not say which server it is.")
        return
    end if
    signIn()
end sub

' The field is Pw, not Password — both servers ignore "Password" and answer
' 401, which reads as a wrong password when it is really a wrong field name.
sub signIn()
    stub = { ptype: m.current.brand, server: m.current.base, token: "", userId: "", serverId: m.current.serverId }
    body = FormatJson({ Username: m.current.username, Pw: m.current.password })
    ask(MsAuthUrl(m.current.base), "POST", body, MsHeaders(stub), "onSignIn", 25000)
end sub

sub onSignIn(event as object)
    if not m.top.active then return
    if m.current = invalid then return
    res = event.getData()
    if res = invalid then return
    if res.ok <> true
        finishOne(false, ToStr(res.error))
        return
    end if

    d = res.data
    token = ToStr(GetField(d, "AccessToken"))
    u = GetField(d, "User")
    uid = ""
    uname = ""
    if u <> invalid
        uid = ToStr(GetField(u, "Id"))
        uname = ToStr(GetField(u, "Name"))
    end if
    if token = "" or uid = ""
        finishOne(false, "The server accepted the sign-in but returned no session.")
        return
    end if
    if uname = "" then uname = m.current.username

    SaveMediaServerSession(m.current.id, {
        ptype: m.current.brand,
        server: m.current.base,
        token: token,
        userId: uid,
        userName: uname,
        serverId: m.current.serverId
    })
    finishOne(true, "")
end sub

sub finishOne(ok as boolean, errText as string)
    if m.task <> invalid
        m.task.unobserveField("result")
        m.task = invalid
    end if
    label = "Jellyfin"
    if m.current.brand = "emby" then label = "Emby"
    nm = ToStr(m.current.name)
    if nm = "" then nm = m.current.serverName
    if nm = "" then nm = label
    if ok
        m.top.okCount = m.top.okCount + 1
        KLog("mediaserver", "signed in to " + label + " '" + nm + "' at " + m.current.base)
    else
        m.top.failCount = m.top.failCount + 1
        KLog("mediaserver", "sign-in failed for '" + nm + "' at " + m.current.base + ": " + errText)
    end if
    m.top.signedIn = { id: m.current.id, name: nm, ok: ok, error: errText }
    m.current = invalid
    nextServer()
end sub
