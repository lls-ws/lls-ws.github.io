sub init()
    m.top.functionName = "fetch"
end sub

sub fetch()
    url = m.top.url
    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.retainBodyOnError(true)
    xfer.enableEncodings(true)
    xfer.addHeader("User-Agent", KwickUserAgent())
    xfer.setUrl(url)

    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)

    ' Two shapes of the same request. With no ceiling asked for (maxBytes = 0,
    ' the default) this is the request it has always been and nothing in the
    ' app behaves differently. With a ceiling, the body is never allowed into
    ' the app's memory until it has been measured — see fetchBounded.
    if m.top.maxBytes > 0
        fetchBounded(xfer, port, m.top.maxBytes)
    else
        fetchWhole(xfer, port)
    end if
end sub

' The unbounded request: the body comes straight back as one string.
sub fetchWhole(xfer as object, port as object)
    if not xfer.asyncGetToString()
        m.top.result = { ok: false, error: "request failed to start" }
        return
    end if

    ' Default 25s — long enough for big channel lists, short enough to fail
    ' fast; bulk requests raise timeoutMs.
    msg = wait(m.top.timeoutMs, port)
    if type(msg) <> "roUrlEvent"
        xfer.asyncCancel()
        ' Our own deadline ran out before curl's did. Indistinguishable from
        ' a timeout to the member, so report it as exactly that.
        failWith(-28)
        return
    end if

    code = msg.getResponseCode()
    body = msg.getString()
    if code < 200 or code >= 300
        failWith(code)
        return
    end if

    finishBody(body, 0)
end sub

' ---- The bounded request -----------------------------------------------------
'
' WHY THIS EXISTS. Two members on v1.0.36 opened Search on a perfectly healthy
' box — an AOC 43S5195 at 5% of the app's limit (key 9BB92E) and a TCL 43S433
' at 4% (key E1DFE0) — and were killed with EXIT_CHANNEL_MEM_LIMIT_FG within
' seconds, with nothing else in the log. Both were on a provider carrying tens
' of thousands of channels, and `get_live_streams` for one of those is a single
' JSON document. asyncGetToString() above pulls that whole document into the
' app as one string and ParseJson then builds the associative arrays beside it,
' so by the time anything could have looked at the size the app was already
' dead. No check on the render thread can save that: the damage is done on this
' thread, inside one call.
'
' So when a caller sets maxBytes the answer is REFUSED BY SIZE BEFORE IT IS
' PARSED, and the bytes never enter the app's memory to be refused in the first
' place. This is the same three-step shape XmltvTask.brs already uses for guide
' files, for the same reason and in the same order:
'
'   1. Content-Length off the response headers, read from the "transfer
'      started" event where the firmware sends one. That is the cheapest
'      possible refusal — not a byte of the body has been read. It costs NO
'      extra request: this is the GET's own headers, not a HEAD. (A HEAD is
'      deliberately not used here. Search's request count must not change —
'      the anti-share rules count requests.)
'   2. The body is written to cachefs:, not into a string, with
'      asyncGetToFile(). The loop below wakes every quarter second and stats
'      the part-file; the moment it passes the cap the transfer is cancelled
'      mid-flight and the part-file deleted. cachefs does NOT count towards the
'      app's memory allowance, which is the whole point — the bytes cannot get
'      us killed while we decide what to do about them.
'   3. The finished file is stat'd once more before a byte of it is read. That
'      is the backstop and it holds even if the ticks in step 2 never saw the
'      file grow on some firmware.
'
' ON CONTENT-LENGTH AND COMPRESSION. enableEncodings(true) is left on, so a
' server that gzips quotes the COMPRESSED length and step 1 under-reads. That
' can only ever let something through that steps 2 and 3 then catch — it can
' never refuse an answer that was actually small enough. What the file holds is
' the decompressed bytes (curl inflates before writing), which is the number
' that matters, so steps 2 and 3 measure the real thing. Turning encodings off
' to make the header honest would mean downloading several times as much over
' the wire on every catalogue, which is a worse trade.
'
' A refused answer comes back { ok: false, error: "too large", bytes: N }, so
' the caller can say which source and how big rather than just "failed".
sub fetchBounded(xfer as object, port as object, cap as integer)
    fs = CreateObject("roFileSystem")
    sweepOldBodies(fs)

    ' getIdentity() is unique per roUrlTransfer object, so several bounded
    ' requests in flight at once never write to the same file.
    path = APIBODYPREFIX() + xfer.getIdentity().toStr() + ".json"
    if fs.Exists(path) then fs.Delete(path)

    if not xfer.asyncGetToFile(path)
        apiDeleteQuietly(path)
        m.top.result = { ok: false, error: "request failed to start" }
        return
    end if

    giveUpAt = apiNowSeconds() + Int(m.top.timeoutMs / 1000)
    code = 0
    while true
        msg = wait(APIPOLLMS(), port)
        if type(msg) = "roUrlEvent"
            ' roUrlEvent carries a "transfer started" event (getInt() = 2) as
            ' well as the completion one. Treating the started event as the end
            ' would hand back an empty file, so only the other one ends the
            ' loop. Where a firmware sends response headers with the started
            ' event, that is the earliest the declared length is known.
            if msg.getInt() <> 2
                code = msg.getResponseCode()
                exit while
            end if
            early = apiHeaderBytes(msg.getResponseHeaders())
            if early > cap
                xfer.asyncCancel()
                apiDeleteQuietly(path)
                m.top.result = apiTooLarge(early)
                return
            end if
        end if

        ' The guards run every time round, whether that was a tick or an event,
        ' so a firmware that chatters events cannot starve them.
        sofar = apiFileBytes(fs, path)
        if sofar > cap
            xfer.asyncCancel()
            apiDeleteQuietly(path)
            m.top.result = apiTooLarge(sofar)
            return
        end if
        if apiNowSeconds() > giveUpAt
            xfer.asyncCancel()
            apiDeleteQuietly(path)
            ' Same as the unbounded path: our own deadline ran out, which is a
            ' timeout as far as the member is concerned.
            failWith(-28)
            return
        end if
    end while

    if code < 200 or code >= 300
        apiDeleteQuietly(path)
        failWith(code)
        return
    end if

    ' THE BACKSTOP, and the one check that cannot be dodged.
    size = apiFileBytes(fs, path)
    if size > cap
        apiDeleteQuietly(path)
        m.top.result = apiTooLarge(size)
        return
    end if
    if size = 0
        apiDeleteQuietly(path)
        m.top.result = { ok: false, error: "bad response from server" }
        return
    end if

    ' Only now, with the size known and inside the cap, does the answer enter
    ' the app's memory at all.
    ' roByteArray, NOT ReadAsciiFile. ReadAsciiFile refuses a file past a
    ' size of its own ("ReadAsciiFile: file is too big" on the office stick's
    ' 15 MB movies catalogue, 2026-09-16) and answers invalid, which silently
    ' dropped that catalogue from Search. A byte array reads whatever the
    ' cap above has already allowed, and the cap is the only limit meant to
    ' apply here.
    ba = CreateObject("roByteArray")
    body = ""
    if ba.ReadFile(path) then body = ba.ToAsciiString()
    ba = invalid
    apiDeleteQuietly(path)
    if body = invalid or body = ""
        ' cachefs is memory the OS may reclaim under pressure, so a file that
        ' became unreadable between the stat and the read means the device went
        ' short. Same verdict either way.
        m.top.result = { ok: false, error: "bad response from server" }
        return
    end if
    finishBody(body, size)
end sub

' Parse (or not) and publish. `size` is the measured byte count, or 0 when
' nothing measured it; callers that asked for a cap use it to log what an
' accepted answer actually cost.
sub finishBody(body as dynamic, size as integer)
    ' `dynamic`, not `string`, on purpose. roUrlEvent.getString() can hand back
    ' invalid on a response with no body at all, and a declared string
    ' parameter would fault on the type mismatch and take the task thread down
    ' with it — a silent dead request instead of a reported one.
    if body = invalid then body = ""
    if m.top.parseJson
        parsed = ParseJson(body)
        ' Let the raw copy go the moment the parse is done. The parsed
        ' associative arrays are several times the size of the text, and for
        ' the few milliseconds before this line BOTH are held — on a small box
        ' that overlap is the difference between answering and being killed.
        body = ""
        if parsed = invalid
            m.top.result = { ok: false, error: "bad response from server" }
            return
        end if
        m.top.result = { ok: true, data: parsed, bytes: size }
    else
        m.top.result = { ok: true, data: body, bytes: size }
    end if
end sub

function apiTooLarge(n as integer) as object
    return { ok: false, error: "too large", bytes: n }
end function

' Content-Length out of a response header set, or -1 if it isn't there. Header
' names aren't case-normalised by anything we can rely on, so match them
' folded. -1 is the common answer and is not a failure: a panel that builds its
' catalogue on the fly sends it chunked with no Content-Length at all, and the
' download loop enforces the cap without it.
function apiHeaderBytes(hdrs as object) as integer
    if hdrs = invalid then return -1
    if type(hdrs) <> "roAssociativeArray" then return -1
    for each k in hdrs
        if LCase(ToStr(k)) = "content-length"
            n = ToInt(hdrs[k])
            if n > 0 then return n
            return -1
        end if
    end for
    return -1
end function

' Size of a file, 0 if it isn't there. Safe to call on one still being written.
function apiFileBytes(fs as object, path as string) as integer
    if path = "" then return 0
    if not fs.Exists(path) then return 0
    st = fs.Stat(path)
    if st = invalid then return 0
    return ToInt(GetField(st, "size"))
end function

sub apiDeleteQuietly(path as string)
    if path = "" then return
    fs = CreateObject("roFileSystem")
    if fs.Exists(path) then fs.Delete(path)
end sub

' Clear out body files an earlier run left behind — the app being killed
' mid-download leaves one, and on a RAM-backed cachefs that is device memory
' held for nothing.
'
' ONLY OLD ONES. Several bounded requests can legitimately be in the air at the
' same time, and deleting a file another task is still writing would break it.
' Anything younger than twice the longest request is left alone, and where the
' firmware doesn't report a modification time nothing is deleted at all —
' Stat's "mtime" is a DATE OBJECT, not a number of seconds, and running it
' through ToInt() gives 0, which would read as "older than anything".
sub sweepOldBodies(fs as object)
    lst = fs.GetDirectoryListing("cachefs:/")
    if lst = invalid then return
    cutoff = apiNowSeconds() - (APIMAXSECONDS() * 2)
    marker = APIBODYNAME()
    for each nm in lst
        n = ToStr(nm)
        if n.len() > marker.len() and n.left(marker.len()) = marker
            full = "cachefs:/" + n
            mts = 0
            st = fs.Stat(full)
            if st <> invalid
                mt = st["mtime"]
                if type(mt) = "roDateTime"
                    mts = mt.asSeconds()
                else
                    mts = ToInt(mt)
                end if
            end if
            if mts > 0 and mts < cutoff then fs.Delete(full)
        end if
    end for
end sub

function apiNowSeconds() as integer
    return CreateObject("roDateTime").asSeconds()
end function

function APIBODYNAME() as string
    return "kwick_api_"
end function

function APIBODYPREFIX() as string
    return "cachefs:/" + APIBODYNAME()
end function

' How often the download loop wakes up to stat the part-file. Fast enough that
' the overshoot past the cap is small even on a quick connection, slow enough
' that the checks themselves cost nothing. Overshoot is harmless anyway — those
' bytes are on cachefs, outside the app's allowance.
function APIPOLLMS() as integer
    return 250
end function

' The longest any bounded request may take, used only to decide which
' abandoned part-files on cachefs are old enough to sweep. The request's real
' deadline is the caller's timeoutMs.
function APIMAXSECONDS() as integer
    return 120
end function

' Every failure leaves through here, so the real reason can't be dropped on
' the floor again — this used to render a DNS failure as the literal string
' "HTTP -6". `diag` is opt-in: the sign-in screen wants the extra probe, the
' twenty background fetches behind Live TV very much do not.
sub failWith(code as integer)
    res = { ok: false, error: NetErrLabel(code) }
    res["errCode"] = code
    if m.top.diagnose
        ' An HTTP status means the server answered — reachability was never
        ' the problem, so there is nothing for a probe to add.
        if NetErrKind(code) <> "http" then res["diag"] = buildDiag(code)
    end if
    m.top.result = res
end sub

' Gathered here, on the task thread: GetLinkStatus is instant but the control
' fetch is not, and the render thread must never wait on it.
function buildDiag(code as integer) as object
    linkUp = CreateObject("roDeviceInfo").GetLinkStatus()
    netUp = false
    if linkUp then netUp = probeInternet()
    return NetDiagnose(HostOf(m.top.url), NetErrKind(code), linkUp, netUp, Int(m.top.timeoutMs / 1000))
end function

' Can this Roku reach ANYTHING, or is it only the one host that's dead? Asks
' the KwickSync host — ours, already contacted by the app, and reachable even
' when the panel is blocked, which is the exact case worth telling apart.
' Short deadline so diagnosing never takes longer than the failure did, and
' ANY reply counts: even an error proves the internet works, which is the
' only question being asked.
function probeInternet() as boolean
    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.addHeader("User-Agent", KwickUserAgent())
    xfer.setUrl(KwickBranding().syncApiUrl)

    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)
    if not xfer.asyncGetToString() then return false

    msg = wait(8000, port)
    if type(msg) <> "roUrlEvent"
        xfer.asyncCancel()
        return false
    end if
    return msg.getResponseCode() >= 100
end function
