' The "there's a newer build" check. Members install this app by sideloading
' a release zip, so nothing on the box ever tells them a newer one exists —
' five Search-memory crash reports have arrived from people still running
' v1.0.25 with the fix already published. This asks kwickplayer.tv what the
' newest published build is; AppScene decides whether to mention it.
'
' DELIBERATELY SILENT about everything that can go wrong: no network, a
' server hiccup, a half-written manifest, a field that isn't there. A member
' who can't reach the check must never see an error about it, so every
' failure lands on the same answer — { ok: false }, say nothing, don't retry.

sub init()
    m.top.functionName = "runUpdateCheck"
end sub

' Where the published version lives. The same file the kwickplayer.tv Roku
' download page reads, so there is ONE number to update on release day.
function UpdateManifestUrl() as string
    return "https://kwickplayer.tv/app/roku/version.json"
end function

sub runUpdateCheck()
    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.enableEncodings(true)
    xfer.addHeader("User-Agent", KwickUserAgent())
    xfer.setUrl(UpdateManifestUrl())
    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)
    if not xfer.asyncGetToString()
        m.top.result = { ok: false }
        return
    end if
    ' A few seconds and no more. This runs while the member is walking into
    ' the app; an answer that isn't quick isn't wanted.
    msg = wait(6000, port)
    if type(msg) <> "roUrlEvent"
        xfer.asyncCancel()
        m.top.result = { ok: false }
        return
    end if
    status = msg.getResponseCode()
    if status < 200 or status >= 300
        KLog("update", "version check answered " + status.toStr() + " - saying nothing")
        m.top.result = { ok: false }
        return
    end if
    parsed = ParseJson(msg.getString())
    if parsed = invalid
        KLog("update", "version check didn't return JSON - saying nothing")
        m.top.result = { ok: false }
        return
    end if
    ' build is the integer that matches the manifest's build_version and is
    ' the ONLY thing compared; version/notes/url are what the member reads.
    ' A manifest missing either of the two that matter is treated exactly
    ' like an unreachable server.
    published = ToInt(GetField(parsed, "build"))
    label = ToStr(GetField(parsed, "version"))
    if published <= 0 or label = ""
        KLog("update", "version check has no usable build/version - saying nothing")
        m.top.result = { ok: false }
        return
    end if
    m.top.result = {
        ok: true
        build: published
        version: label
        notes: ToStr(GetField(parsed, "notes"))
        url: ToStr(GetField(parsed, "url"))
    }
end sub
