' One title's rating badges, fetched once per film page and cached on disk.
' The Roku half of GAP I1 — the Android app's MetadataService
' (lib/core/services/metadata_service.dart) enriches a title with IMDb /
' Rotten Tomatoes / Metacritic scores; Roku showed whatever the panel sent
' and nothing else.
'
' ONE REQUEST PER PAGE OPEN, NEVER PER TILE. The film page opens, asks once,
' and every reopen of the same title inside a week answers off the disk cache
' with no request at all. This is the same line HomeScreen.brs:6-19 draws for
' the media bar: "one request per tile on every Home rebuild ... is what got
' this house's address banned by the provider on 2026-08-14". That ban was
' the panel, not this service, but the shape of the mistake is the same and
' the rule is written as a design principle, not a panel-specific one.
'
' ---- WHY THIS ASKS kwickplayer.tv AND NOT TMDB ------------------------------
'
' It does not hold an API key, and it must never hold one. The house already
' settled this for the sports badges, and the reasoning is written down in
' Kwick Player Site/upload/kwicksync/sportsart.php:
'
'     "An APK unzips in seconds, so a key shipped inside one is a public key.
'      It lives in config.php here instead, beside the DB credentials."
'
' A Roku sideload zip unzips just as easily — easier, it is a plain .zip — so
' every word of that applies here. The Android app's keys are hardcoded in
' metadata_service.dart:12-13 and are shared with the KwickTV Jellyfin setup;
' copying them into this tree would put a shared credential into a second
' public package and make abuse from a Roku fleet somebody else's outage too.
' They have deliberately NOT been copied, and this tree still holds no key of
' any kind. The keys live in kwicksync/config.php on the server, beside the
' database credentials, and only titlemeta.php ever reads them.
'
' The other two reasons sportsart.php gives apply unchanged: one lookup serves
' every member (a film is resolved once, ever, not once per member), and a bad
' match is corrected centrally with one UPDATE instead of being stuck in the
' wild until the next app release.
'
' ---- WHAT IT COSTS ----------------------------------------------------------
'
' A badge list, a certificate, and TWO image PATHS — no pictures, no credits,
' no second request. Android's lookup appends credits+images+release_dates to
' the TMDB details call, which is 40-120 KB of JSON for a big film and several
' hundred KB of heap once parsed. NONE OF THAT HAPPENS ON THIS BOX: the whole
' of it happens once, on the server, for the life of that title's row, and what
' crosses the wire to a Roku is the finished answer. What comes back and is
' retained here is roughly 230 bytes a title.
'
' ---- `bd`, THE BACKDROP PATH (GAP I2) ---------------------------------------
'
' This used to say backdrop art was deliberately not here, and gave two
' reasons. Both were about DECODING one, and both still stand — they are just
' not this file's problem:
'
'   * "a w1280 backdrop is 1280 x 720 x 4 = 3.5 MB of texture RAM". True, and
'     which is why nothing in this app ever loads one at w1280. The Media Bar
'     decodes at loadWidth=360 for ~292 KB and fetches w500, and the arithmetic
'     for every source aspect is written out in MediaBar.xml. This file holds
'     no texture at all.
'   * "it needs the loadWidth/loadHeight treatment MediaBar.xml documents".
'     It has it. That treatment shipped with the detail-page backdrop, and the
'     Media Bar's `backdrop` Poster is the node this feeds.
'
' What actually arrives here is 32 BYTES OF TEXT — "/9xE7uEp....jpg", TMDB's
' own path fragment with no host and NO SIZE on it, exactly the shape Store.brs
' already keeps on a recents row. The size is the client's to choose, in
' BackdropUrl(), and choosing it here would bake a number into a server row
' that is cached for ever. A string is not a picture: the cost of this field is
' a few dozen bytes in the cache file and nothing else at all.
'
' WHY THE SERVER HAD IT ANYWAY: `backdrop_path` sits at the top level of the
' TMDB details response titlemeta.php already fetches for the certificate. It
' was being decoded and dropped. There is no extra upstream call.
'
' WHO ASKS. The film page asks for badges and ignores this; the Media Bar asks
' for this and ignores the badges. Same request, same cache row, one answer —
' so a title the member later opens costs nothing, and neither screen has to
' know the other exists. The Media Bar's request budget is its own business and
' is written out at the top of MediaBar.brs; this file just answers.
'
' ---- `lg`, THE TITLE LOGO ---------------------------------------------------
'
' The second path, and it rides in the SAME answer as the first — the whole
' point. TMDB publishes most titles' own lettering as a transparent PNG, and
' the Media Bar draws it where the title text would go, exactly as the phone
' does (continue_watching_spotlight.dart:852). Same 32 bytes of text, same
' cache row, same request. There is no second call and there must never be one.
'
' PNG ONLY, HERE AS WELL AS THERE, and this is not belt-and-braces for its own
' sake. TMDB serves logos as .png and .svg. A Roku cannot decode SVG AT ALL, so
' an .svg arriving here would be a permanently failed image on the Home screen
' rather than a wrong-looking one — the failure mode is worse than the one a
' bad backdrop has. A .jpg logo has no transparency and is an opaque rectangle
' sitting on somebody else's artwork. The server already refuses both, along
' with anything narrower than 2:1 (the Media Bar's texture ceiling depends on
' that number); this end refuses the extensions again for the same reason
' metaCleanBackdrop exists — what comes back goes into a file that outlives the
' app, and out of that file into a url a television fetches.

sub init()
    m.top.functionName = "run_meta"
end sub

' ---- The service address -----------------------------------------------------
'
' titlemeta.php, sitting beside sportsart.php and holding its keys in the same
' config.php. It belongs next to the other kwickplayer.tv addresses the app
' knows (SourceLinkTask.brs:52, UpdateCheckTask.brs:19).
'
' EMPTYING THIS STRING SWITCHES THE FEATURE OFF AGAIN, completely and with no
' other edit: the task then does no networking at all, the cache is still
' consulted, and the page still draws the panel's own rating and certificate.
' That is the kill switch if the service ever has to be taken down.
'
' The conversation, both directions:
'
'     GET titlemeta.php?kind=movie&tmdb=<id>
'     GET titlemeta.php?kind=movie&title=<name>&year=<yyyy>   ' no tmdb_id
'
'     { "ok": true, "badges": [ { "s": "IMDb", "v": "8.9" }, ... ],
'       "cert": "PG-13", "bd": "/9xE7uEpUZLuqIsyOroDJOAtOnaS.jpg",
'       "lg": "/mOTtuakUTb1qY6jG6lzMfjdhLwc.png" }
'
' "s" is the label drawn in grey and "v" the value drawn in white — THE SERVER
' DECIDES THE WORDING, so a new rating source, or a label that turned out too
' wide for a chip, is a server edit and never an app release. `cert` is
' optional and only used when the panel sent no certificate of its own. `bd` is
' TMDB's own path fragment for the landscape still and `lg` the same for the
' title's own lettering, both with no host and no size on them — see the blocks
' above — and "" is a real answer for either, meaning "the catalogue has none",
' which is filed like any other so it is never asked for twice.
'
' ALL FOUR ARE ALWAYS PRESENT, on every answer, including the failures. The
' server fills the missing ones in with empties on the way out, so no caller
' here ever has to test for a key.
'
' The status code carries one bit beyond the body, and the existing code below
' already acts on it correctly, which is why none of it changed. 200 is a
' DECIDED answer — a match, or a film the catalogue genuinely knows nothing
' more about — and gets cached for the week. Anything else (424 undecided: no
' key, no database, upstream slow or down; 429 throttled) leaves through
' metaFail and is NOT written to the cache, so a five-minute outage at the
' other end cannot bake a blank strip into this box for seven days. That is
' sportsart.php's own rule — "Never cache a transport failure as 'no badge'" —
' and it needed no change here, only the right code from the server. Every one
' of those bodies is still valid JSON with empty `badges`, so a build that
' ignored the status would read them as "nothing to add" rather than break.
function MetaEndpoint() as string
    return "https://kwickplayer.tv/kwicksync/titlemeta.php"
end function

' GUARDED, the same way XmltvTask is and for the same reason: a fault on a task
' thread kills the whole app and the crash report names nothing. This one reads
' and rewrites a cache file on disk and parses a server's JSON, so it has real
' places to fault.
'
' WHAT IT OWES ITS TWO CALLERS, AND WHY IT IS NOT "NOTHING". Neither the film
' page nor the Media Bar shows a spinner for this — it is decoration arriving
' behind a page that has already drawn. But both of them mark themselves BUSY
' while a lookup is out: the Media Bar sets m.metaBusy and clears it in
' onMetaResult, and the film page holds its poster back behind backdropPending
' until an answer lands. A task that dies without answering leaves the panel
' believing a request is still in the air and it never asks about another title
' for the rest of the launch, and the backdrop never appears. So the catch goes
' out through metaFail, the same door every other failure here uses, and both
' callers release as they already do for a timeout.
'
' An answer that is already there is never overwritten: the handlers at the
' other end are not written to run twice for one lookup.
sub run_meta()
    try
        runMetaInner()
    catch e
        GuardFailed("titlemeta/run", e)
        r = m.top.result
        hasAnswer = (type(r) = "roAssociativeArray" and r.count() > 0)
        if not hasAnswer then metaFail(0, "the artwork lookup could not be completed")
    end try
end sub

sub runMetaInner()
    key = ToStr(m.top.cacheKey)
    if key = ""
        ' Nothing to file an answer under means nothing may be cached, and an
        ' uncacheable lookup is exactly the per-open request this design
        ' exists to prevent. Refuse rather than fetch.
        metaFail(0, "no cache key")
        return
    end if

    ' 1. IS THE SERVICE EVEN SWITCHED ON? Asked before the cache is opened,
    '    not after: with no address nothing can ever have written that file,
    '    so reading it would be a guaranteed-empty disk read on every single
    '    film page. This is the shipped state, so it is the path worth
    '    keeping free. Not a failure either — the page has the panel's own
    '    rating and certificate and draws them either way.
    ep = MetaEndpoint()
    if ep = ""
        m.top.result = { ok: false, off: true, error: "metadata service not configured" }
        return
    end if

    ' 2. THE CACHE, AND ON THIS THREAD. The render thread never opens this
    '    file — a reopened film costs one Task node and a disk read, both off
    '    the thread that has 250 ms to draw the page (cert 3.5), and no
    '    request at all.
    hit = metaCacheRead(key)
    if hit <> invalid
        m.top.result = { ok: true, data: hit, cached: true }
        return
    end if

    url = ep + "?kind=" + UrlEncode(ToStr(m.top.kind))
    tmdb = ToStr(m.top.tmdbId)
    if tmdb <> "" and tmdb <> "0"
        ' The panel's own tmdb_id, when it sent one. This is the whole search
        ' request skipped — most panels carry it (Android reads the same field,
        ' xtream_models.dart:416), and a search that is never made cannot
        ' return the wrong film either.
        url = url + "&tmdb=" + UrlEncode(tmdb)
    else
        url = url + "&title=" + UrlEncode(ToStr(m.top.title))
        yr = ToStr(m.top.year)
        if yr <> "" then url = url + "&year=" + UrlEncode(yr)
    end if

    metaFetch(url, key)
end sub

sub metaFetch(url as string, key as string)
    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.retainBodyOnError(true)
    xfer.enableEncodings(true)
    xfer.addHeader("User-Agent", KwickUserAgent())
    xfer.setUrl(url)

    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)
    if not xfer.asyncGetToString()
        metaFail(0, "request failed to start")
        return
    end if

    msg = wait(m.top.timeoutMs, port)
    if type(msg) <> "roUrlEvent"
        xfer.asyncCancel()
        ' Our own deadline beat curl's. Same as a timeout from here.
        metaFail(-28, NetErrLabel(-28))
        return
    end if

    code = msg.getResponseCode()
    if code < 200 or code >= 300
        metaFail(code, NetErrLabel(code))
        return
    end if

    parsed = ParseJson(msg.getString())
    if parsed = invalid or type(parsed) <> "roAssociativeArray"
        metaFail(0, "bad response from server")
        return
    end if

    data = { badges: metaCleanBadges(parsed["badges"]), cert: ToStr(parsed["cert"]), bd: metaCleanBackdrop(parsed["bd"]), lg: metaCleanLogo(parsed["lg"]) }

    ' NEGATIVE ANSWERS ARE CACHED TOO. A film the service has never heard of
    ' is the case most worth remembering: without this, the one title with no
    ' match is the one that asks again on every single open, forever. Android
    ' does the same with an empty payload (metadata_service.dart:175).
    metaCacheWrite(key, data)
    m.top.result = { ok: true, data: data, cached: false }
end sub

' Every failure leaves through here, the way ApiTask.failWith does, so a
' reason can never be dropped on the floor. No diagnostic probe: this is
' decoration on a page that has already drawn, and nobody is sitting waiting
' on it the way they wait on the sign-in screen.
sub metaFail(code as integer, why as string)
    res = { ok: false, error: why }
    res["errCode"] = code
    m.top.result = res
end sub

' What the server sent, held to a shape the screen can draw. A badge with no
' value is not a badge, and the cap is what stops a server change from being
' able to push an unbounded list into the cache file.
function metaCleanBadges(raw as dynamic) as object
    out = []
    for each b in ToArray(raw)
        if type(b) = "roAssociativeArray"
            v = ToStr(b["v"]).trim()
            if v <> ""
                out.push({ s: ToStr(b["s"]).trim(), v: v })
                if out.count() >= MetaMaxBadges() then exit for
            end if
        end if
    end for
    return out
end function

' Six is what fits: the strip is drawn over the bottom of a 360-wide poster,
' three chips to a row, two rows. See rbDrawBadges in MovieDetailScreen.brs.
function MetaMaxBadges() as integer
    return 6
end function

' The backdrop path, held to a shape before it is written to disk.
'
' The server checks this too. It is checked AGAIN here for the reason every
' other boundary in this app is checked twice: what comes back goes into a file
' that survives the app, and out of that file into a url a television fetches.
' A leading slash is what the whole scheme rests on — BackdropUrl() in
' Store.brs reads it as "this is a TMDB file, put the host and the size back
' on" — so anything that is not that shape is not a backdrop and becomes "".
'
' 80 is BackdropMaxLen() in Store.brs, the same ceiling a stored backdrop has
' to clear to earn a registry slot. Using the same number means a path that
' would be refused there is refused here as well, rather than being cached for
' a week and then quietly dropped at the far end.
'
' NO SIZE AND NO HOST are expected, and one arriving is a refusal rather than
' something to strip: "://" anywhere means the server sent a full url, which it
' does not do, and guessing at what a stranger's url means is how a panel ends
' up pointing an app at somewhere nobody chose.
function metaCleanBackdrop(raw as dynamic) as string
    s = ToStr(raw).trim()
    if s = "" then return ""
    if Len(s) < 6 or Len(s) > 80 then return ""
    if Left(s, 1) <> "/" then return ""
    if Instr(1, s, "://") > 0 then return ""
    if Instr(1, s, " ") > 0 then return ""
    if Instr(1, s, "?") > 0 then return ""
    ' One slash, at the front. "/a/b.jpg" is not a TMDB file name.
    if Instr(2, s, "/") > 0 then return ""
    ' It has to be a picture. Everything TMDB serves under /t/p/ is one of
    ' these three, and a path with no extension at all is not a file.
    low = LCase(s)
    if Right(low, 4) = ".jpg" then return s
    if Right(low, 5) = ".jpeg" then return s
    if Right(low, 4) = ".png" then return s
    if Right(low, 5) = ".webp" then return s
    return ""
end function

' The title logo path, held to the same shape as the backdrop above and then to
' one more rule on top of it: IT HAS TO BE A .png.
'
' That is not tidiness. TMDB serves title logos as PNG and as SVG, and a Roku
' cannot decode SVG at all — an .svg reaching the Media Bar is not a logo that
' looks wrong, it is a Poster whose loadStatus is "failed" for ever. The
' occasional .jpg is worse in a different way: no transparency, so it draws as
' an opaque rectangle over the backdrop it is supposed to sit on. The server
' refuses both already (logo_path_of in titlemeta.php), along with anything
' narrower than 2:1, which is the ratio the Media Bar's texture arithmetic is
' built on. This end refuses the extensions again for the reason every other
' boundary in this app is checked twice — what lands here goes into a file that
' survives the app, and out of that file into a url a television fetches.
'
' The ASPECT gate is deliberately NOT repeated here: nothing on this side knows
' a picture's shape until it has been decoded, which is after the memory has
' been spent. That gate can only live at the server, which is why it is written
' down as load-bearing in both files.
function metaCleanLogo(raw as dynamic) as string
    s = metaCleanBackdrop(raw)
    if s = "" then return ""
    if Right(LCase(s), 4) <> ".png" then return ""
    return s
end function

' ---- The cache ---------------------------------------------------------------
'
' cachefs:, NOT THE REGISTRY, and the difference matters enough to spell out.
'
' The registry is 16-32 KB for the WHOLE app, shared with the providers, the
' favorites, the lists, the recents, the resume points and the sync mirror
' (Store.brs:285-292), and a write past the quota "fails silently and takes
' whatever else was mid-write with it" (Store.brs:2285-2287). A metadata cache
' is the wrong shape for that space in every way: it grows with browsing
' rather than with what a member has chosen to keep, and the thing it would
' damage on overflow is a member's actual favourites. Sixty films at ~150
' bytes is ~9 KB, which is between a third and half the app's entire
' persistent budget spent on decoration.
'
' cachefs: costs none of that. It is scratch space the OS may clear whenever
' it likes, which for a cache is not a bug but the correct behaviour — losing
' it costs one refetch and nothing else, where losing registry space costs a
' member their favourites. The app already writes ~30 KB there for the
' diagnostic tail (AppShell.brs:115), so the precedent and the read/write
' helpers both exist.
'
' STILL CAPPED, HARD, TWICE. cachefs is not unlimited and this must never be
' the reason something else on it gets evicted. 80 entries and 24 KB, oldest
' dropped first, whichever bites first. At ~190 bytes a title the entry cap is
' what normally bites; the byte cap is the backstop for a server that starts
' sending longer labels.
'
' NEITHER NUMBER HAS MOVED, THROUGH TWO ADDITIONS, and it was worth checking
' both times rather than assuming. An image path is 32 characters plus its key
' and quotes, so a row went from about 150 bytes to about 190 when `bd` arrived
' and to about 230 now `lg` has. A full 80 entries is roughly 18.4 KB against
' the 24 KB ceiling, where it was 15.2 and before that 12. The byte cap would
' not bite until about 105 entries, so the ENTRY cap is still the one that
' bites first and the byte cap is still the backstop it is supposed to be —
' but the slack is now a third of what it was, and a third addition of this
' size is the one that would need these numbers revisited rather than
' re-checked.
'
' A ROW WRITTEN BEFORE `bd` OR `lg` EXISTED has no key for it. It used to read
' back as "" — indistinguishable from "this title has neither" — for up to
' seven days, on the grounds that a version stamp invalidating the WHOLE file
' would throw away every badge on the box to fix a picture. That was the right
' objection to the wrong remedy.
'
' What happens instead is per ROW: a row that has no `lg` key AT ALL predates
' the field and is treated as stale, so it is asked again. `doesExist` and not
' `ToStr()`, because the two cases are different — an absent key means nobody
' ever asked, an empty string means the server answered and this title has
' none. Only the first is worth re-asking.
'
' Nothing is thrown away by this: the answer that carries the picture carries
' the badges too, in the same response. And it cannot stampede — refetches go
' through the same budget as everything else (one in flight, a dwell, once per
' title per launch, 24 a launch, the memory gate), so the worst case is the
' one the budget was sized for. Every future field can use the same rule.
'
' NOTE FOR THE RECORD: nothing in the vault has ruled on cachefs: as a cache
' location — the only prior mention is UsbListTask.brs:32 excluding it from
' the drive list. This is the first use of it for caching and wants Mason's
' nod.
function MetaCachePath() as string
    return "cachefs:/kwickmeta.json"
end function

' Seven days, the same age Android holds metadata for
' (metadata_service.dart:140). Scores move slowly and a stale one is a
' cosmetic error, not a wrong film.
function MetaCacheTtlS() as integer
    return 604800
end function

function MetaCacheMaxEntries() as integer
    return 80
end function

function MetaCacheMaxBytes() as integer
    return 24576
end function

' The whole file as a key -> row map. A missing, empty, truncated or
' hand-edited file all answer the same way: no cache, refetch. ReadAsciiFile
' returns "" for a file that is not there (AppScene.brs:892), so a first run
' needs no special case.
' What this build's rows look like. Bump it when an answer filed by an older
' build would now be WRONG rather than merely older.
'
'   1  badges + cert
'   2  + bd, + lg
'   3  answers filed while the server could not yet return logo art. Those
'      rows hold lg:"" for a title that genuinely has one - present, so the
'      per-row "is the key missing" test below cannot see them, and served as
'      "this title has no lettering" for a week.
'
' That is the trap worth writing down: a cache can be poisoned by a PEER that
' was older, not only by being old itself. The per-row test catches a field
' this build added; the file version catches a field the OTHER END added.
' Both layers need one, which is why titlemeta.php has the same thing.
function MetaCacheSchema() as integer
    return 3
end function

function metaCacheLoad() as object
    ' Ask whether it is there before reading it. ReadAsciiFile answers "" for
    ' a missing file, which is why this worked - but it also prints a
    ' BrightScript ERROR line to the console every single time, and on a fresh
    ' box that is one scary-looking error per lookup for something completely
    ' normal. A first run has no cache; that is not a fault.
    if not CreateObject("roFileSystem").Exists(MetaCachePath()) then return {}
    raw = ReadAsciiFile(MetaCachePath())
    if raw = "" then return {}
    parsed = ParseJson(raw)
    if parsed = invalid then return {}
    if type(parsed) <> "roAssociativeArray" then return {}
    ' Filed by a build whose answers this one cannot trust. Dropped whole -
    ' every row in it came from the same server that could not answer.
    if ToInt(parsed["v"]) < MetaCacheSchema() then return {}
    e = parsed["e"]
    if type(e) <> "roAssociativeArray" then return {}
    return e
end function

function metaCacheRead(key as string) as object
    all = metaCacheLoad()
    row = all[key]
    if type(row) <> "roAssociativeArray" then return invalid
    age = CreateObject("roDateTime").asSeconds() - ToInt(row["t"])
    ' A negative age means the clock moved backwards under us (a box that
    ' booted before it had NTP, then corrected). Treat it as stale rather
    ' than as valid until the end of time.
    if age < 0 or age > MetaCacheTtlS() then return invalid
    ' Predates a field this build knows about - ask again rather than serve a
    ' silently incomplete answer. See the note above metaCacheLoad.
    if not row.doesExist("lg") then return invalid
    if not row.doesExist("bd") then return invalid
    ' "bd" is absent on a row written before backdrops were kept and "lg" on any
    ' row written before logos were, and ToStr() answers "" for a missing key,
    ' so an old file needs no special case — see the note above. "" is exactly
    ' what "this title has none" looks like, so an old row degrades to a poster
    ' and a plain text title rather than to anything broken.
    return { badges: ToArray(row["b"]), cert: ToStr(row["c"]), bd: ToStr(row["bd"]), lg: ToStr(row["lg"]) }
end function

sub metaCacheWrite(key as string, data as object)
    all = metaCacheLoad()
    all[key] = { t: CreateObject("roDateTime").asSeconds(), b: data.badges, c: data.cert, bd: ToStr(GetField(data, "bd")), lg: ToStr(GetField(data, "lg")) }

    while all.count() > MetaCacheMaxEntries()
        if not metaDropOldest(all) then exit while
    end while

    body = FormatJson({ v: MetaCacheSchema(), e: all })
    while Len(body) > MetaCacheMaxBytes() and all.count() > 1
        if not metaDropOldest(all) then exit while
        body = FormatJson({ v: MetaCacheSchema(), e: all })
    end while

    ' Best-effort. A full or unwritable cachefs costs a refetch next time and
    ' nothing more, which is the entire reason the cache lives here.
    WriteAsciiFile(MetaCachePath(), body)
end sub

' Oldest entry out. Returns false when there was nothing to drop, so the
' callers' loops can never spin.
function metaDropOldest(all as object) as boolean
    oldestKey = ""
    oldestT = 0
    for each k in all
        t = ToInt(GetField(all[k], "t"))
        if oldestKey = "" or t < oldestT
            oldestKey = k
            oldestT = t
        end if
    end for
    if oldestKey = "" then return false
    all.delete(oldestKey)
    return true
end function
