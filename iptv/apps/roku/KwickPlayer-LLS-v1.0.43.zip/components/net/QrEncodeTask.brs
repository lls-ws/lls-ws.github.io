' One QR encode, on a thread of its own. See QrEncodeTask.xml for why this
' is a task and not four lines inside the screen that wants the square.

sub init()
    m.top.functionName = "encodeQr"
end sub

sub encodeQr()
    src = ToStr(m.top.text)
    if src = ""
        m.top.rows = []
        return
    end if

    ' The encoder answers invalid rather than guessing when the text is
    ' longer than a version 3-M symbol holds (42 bytes). Both add-on links
    ' come to about 30 — "https://trakt.tv/activate/" is 26 characters and
    ' "https://simkl.com/pin/" is 22, plus an eight-character code — so this
    ' branch is a guard, not an expected path. The ADDRESS IS NOT LOGGED:
    ' it carries the member's one-time sign-in code.
    rows = QrEncode(src)
    if rows = invalid
        KLog("addons", "sign-in link wouldn't fit a QR square - showing the code on its own")
        m.top.rows = []
        return
    end if
    m.top.rows = rows
end sub
