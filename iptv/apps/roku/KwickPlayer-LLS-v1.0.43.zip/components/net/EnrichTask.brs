' Catalog lookups for favorites that are missing art or names (typical for
' items synced from the phone — its channel payloads carry no logo, and some
' VOD rows lost their posters before the wire-format fix). Only fetches the
' catalogs it actually needs; saves back to the store, so the next KwickSync
' push carries the healed art to every other device too.

sub init()
    m.top.functionName = "run_enrich"
end sub

' GUARDED, the same way XmltvTask is and for the same reason: a fault on a task
' thread kills the whole app and the crash report that goes up names nothing.
' This one walks catalogue JSON off a provider panel and writes back to the
' store, so a malformed row is a real way to fault.
'
' WHAT IT OWES HOME. Nothing is spinning on this — the Home page has already
' drawn and this is artwork being healed behind it — but HomeScreen does watch
' `done` and refreshes the page when the answer says something changed. A task
' that dies without answering means the healed artwork sits in the store
' unseen until the next launch, and the screen keeps hold of a dead task node.
' So the catch answers.
'
' AND IT ANSWERS HONESTLY. m.enrichChanged is kept as the loop runs, so a fault
' half way through still reports the rows that were really healed before it and
' Home still refreshes to show them. Reporting a flat "nothing changed" would
' hide work that had already been written to the store.
sub run_enrich()
    m.enrichChanged = false
    try
        runEnrichInner()
    catch e
        GuardFailed("enrich/run", e)
        d = m.top.done
        hasAnswer = (type(d) = "roAssociativeArray" and d.count() > 0)
        ch = false
        if m.enrichChanged = true then ch = true
        if not hasAnswer then m.top.done = { changed: ch }
    end try
end sub

sub runEnrichInner()
    ' Every Xtream-type source heals its own rows against its own catalog
    ' (merged lineup) — a source's ids mean nothing on another's panel.
    '
    ' A MEDIA SERVER IS NOT AN XTREAM-TYPE SOURCE, and the test below used to
    ' say it was: the only thing it asked was "is this an M3U", so a member's
    ' own Jellyfin or Emby fell into the else and had player_api.php requests
    ' fired at it — with their Xtream username and password in the query
    ' string, at a server that answers 404. It is the same mistake that froze
    ' Movies & Series for ninety seconds, in a different file.
    '
    ' Nothing is lost by skipping them. Everything this task heals is art and
    ' names off an Xtream panel; a media server's rows carry a poster address
    ' rebuilt from the server itself (MediaSrcPosterUrl) and never needed a
    ' catalogue lookup.
    changed = false
    for each p in LoadProviders()
        if ToStr(p.ptype) <> "m3u" and not MsIsMediaServer(p)
            if enrichForSource(p)
                changed = true
                ' Mirrored onto the task's scope as each source finishes, so
                ' the guard above can report work that was really done if a
                ' later source faults. Nothing else reads it.
                m.enrichChanged = true
            end if
        end if
    end for
    m.top.done = { changed: changed }
end sub

function enrichForSource(p as object) as boolean
    changed = false
    token = SrcTokenFor(p)

    ' Channel favorites missing name or logo.
    favch = LoadFavoriteChannels()
    needCh = false
    for each c in favch
        if SrcMatches(c, token) and (ToStr(c.name) = "" or ToStr(c.logo) = "") then needCh = true
    end for
    if needCh
        data = fetchJson(XtreamApiUrl(p, "get_live_streams"))
        if data <> invalid
            byId = {}
            for each s in ToArray(data)
                byId[ToStr(GetField(s, "stream_id"))] = s
            end for
            for each c in favch
                s = invalid
                if SrcMatches(c, token) then s = byId[ToStr(c.streamId)]
                if s <> invalid
                    if ToStr(c.name) = ""
                        c.name = ToStr(GetField(s, "name"))
                        changed = true
                    end if
                    if ToStr(c.logo) = ""
                        c.logo = ToStr(GetField(s, "stream_icon"))
                        changed = true
                    end if
                end if
            end for
            RegWrite(FavChannelsKey(), FormatJson(favch))
        end if
    end if

    ' VOD favorites missing posters (store the panel's raw url — display
    ' code right-sizes it, and sync pushes it to the phones as-is).
    favvod = LoadFavoriteVod()
    needMovies = false
    needSeries = false
    for each v in favvod
        if SrcMatches(v, token) and ToStr(v.icon) = ""
            if ToStr(v.kind) = "series" then needSeries = true else needMovies = true
        end if
    end for
    if needMovies
        data = fetchJson(XtreamApiUrl(p, "get_vod_streams"))
        if data <> invalid
            byId = {}
            byName = {}
            for each s in ToArray(data)
                byId[ToStr(GetField(s, "stream_id"))] = s
                byName[LCase(ToStr(GetField(s, "name")).trim())] = s
            end for
            for each v in favvod
                if SrcMatches(v, token) and ToStr(v.kind) <> "series" and ToStr(v.icon) = ""
                    s = byId[ToStr(v.id)]
                    ' Panels replace encodes under NEW ids (cam -> proper
                    ' copy etc.) — if the id is gone, find the title by name
                    ' and adopt the current copy so it shows AND plays again.
                    if s = invalid then s = byName[LCase(ToStr(v.name).trim())]
                    if s <> invalid
                        v.id = ToStr(GetField(s, "stream_id"))
                        v.icon = ToStr(GetField(s, "stream_icon"))
                        if ToStr(v.name) = "" then v.name = ToStr(GetField(s, "name"))
                        v.ext = ToStr(GetField(s, "container_extension"))
                        changed = true
                    end if
                end if
            end for
        end if
    end if
    if needSeries
        data = fetchJson(XtreamApiUrl(p, "get_series"))
        if data <> invalid
            byId = {}
            byName = {}
            for each s in ToArray(data)
                byId[ToStr(GetField(s, "series_id"))] = s
                byName[LCase(ToStr(GetField(s, "name")).trim())] = s
            end for
            for each v in favvod
                if SrcMatches(v, token) and ToStr(v.kind) = "series" and ToStr(v.icon) = ""
                    s = byId[ToStr(v.id)]
                    if s = invalid then s = byName[LCase(ToStr(v.name).trim())]
                    if s <> invalid
                        v.id = ToStr(GetField(s, "series_id"))
                        v.icon = ToStr(GetField(s, "cover"))
                        if ToStr(v.name) = "" then v.name = ToStr(GetField(s, "name"))
                        changed = true
                    end if
                end if
            end for
        end if
    end if
    if needMovies or needSeries then RegWrite(FavVodKey(), FormatJson(favvod))

    return changed
end function

function fetchJson(url as string) as dynamic
    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.enableEncodings(true)
    xfer.addHeader("User-Agent", KwickUserAgent())
    xfer.setUrl(url)
    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)
    if not xfer.asyncGetToString() then return invalid
    msg = wait(90000, port)   ' full catalogs are big; give them room
    if type(msg) <> "roUrlEvent"
        xfer.asyncCancel()
        return invalid
    end if
    if msg.getResponseCode() < 200 or msg.getResponseCode() >= 300 then return invalid
    return ParseJson(msg.getString())
end function
