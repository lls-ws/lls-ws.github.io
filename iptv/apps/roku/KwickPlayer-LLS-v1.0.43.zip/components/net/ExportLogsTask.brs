sub init()
    m.top.functionName = "run_export"
end sub

sub run_export()
    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.addHeader("Content-Type", "application/json")
    xfer.addHeader("User-Agent", KwickUserAgent())
    xfer.setUrl(KwickBranding().logsApiUrl)
    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)
    ' Same payload the Android app sends (v2 flow): the server files logs
    ' per user+device and answers with a stable "Log Key" for support.
    fields = {
        u: m.top.username
        body: m.top.body
        device: m.top.device
        ver: m.top.ver
        plat: "roku"
        app: "Kwick Player (Roku)"
    }
    ' Crash uploads are filed server-side as their own timestamped file
    ' (never overwriting the member's regular export).
    if m.top.crash then fields.crash = true
    payload = FormatJson(fields)
    if not xfer.asyncPostFromString(payload)
        m.top.result = { ok: false, code: "post_failed" }
        return
    end if
    msg = wait(30000, port)
    if type(msg) <> "roUrlEvent"
        xfer.asyncCancel()
        m.top.result = { ok: false, code: "timeout" }
        return
    end if
    resp = ParseJson(msg.getString())
    if resp = invalid
        m.top.result = { ok: false, code: "bad_response" }
        return
    end if
    m.top.result = resp
end sub
