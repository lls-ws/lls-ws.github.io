sub init()
    ' NOTE: "run" is a reserved word in BrightScript — hence parsePlaylist.
    m.top.functionName = "parsePlaylist"
end sub

' A fault on a Task thread kills the whole app exactly as one on the render
' thread does, and leaves even less behind: the crash-on-next-launch report
' carries the render thread's last lines and nothing of the task's. The Guide
' starts one of these for every playlist whose parse is not already in hand,
' and nine crash reports (v1.0.34 and v1.0.36, September 2026) died seconds
' after opening the Guide with nothing logged from any guarded step. So the
' parse runs under a guard: a fault answers "not ok" with the file, line and
' function in the log, and arms the same next-launch report the sync cycle
' arms for a caught fault, so the culprit is finally named.
sub parsePlaylist()
    try
        parsePlaylistInner()
    catch e
        where = ToStr(GetField(e, "message"))
        bt = GetField(e, "backtrace")
        if bt <> invalid and type(bt) = "roArray" and bt.count() > 0
            top = bt[bt.count() - 1]
            where = where + " @ " + ToStr(GetField(top, "filename")) + ":" + ToStr(GetField(top, "line_number")) + " " + ToStr(GetField(top, "function"))
        end if
        KLog("m3u", "crash averted while reading a playlist: " + where)
        ArmCrashReport("CAUGHT m3u-parse: " + where)
        m.top.result = { ok: false, error: "playlist could not be read" }
    end try
end sub

sub parsePlaylistInner()
    src = m.top.url
    if IsLocalPath(src)
        ' A playlist off a USB drive. Same parser from here on — only where
        ' the text came from differs.
        body = ReadAsciiFile(src)
        if body = ""
            ' Almost always the drive having been unplugged since it was
            ' picked, so say that rather than "unreachable".
            m.top.result = { ok: false, error: "playlist file missing" }
            return
        end if
    else
        xfer = CreateObject("roUrlTransfer")
        xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
        xfer.enableEncodings(true)
        xfer.addHeader("User-Agent", KwickUserAgent())
        xfer.setUrl(src)
        body = xfer.getToString()
    end if
    if body = "" or body.instr(0, "#EXTINF") < 0
        m.top.result = { ok: false, error: "playlist empty or unreachable" }
        return
    end if

    channels = []
    m.m3uCapped = false
    tvgUrl = ""
    lines = body.split(Chr(10))
    pending = invalid
    digest = CreateObject("roEVPDigest")
    idSeen = {}
    for each rawLine in lines
        line = rawLine.trim()
        if line <> ""
            if Left(line, 7) = "#EXTM3U"
                ' Playlist header can carry the XMLTV guide address (T5).
                tvgUrl = extAttr(line, "url-tvg")
                if tvgUrl = "" then tvgUrl = extAttr(line, "x-tvg-url")
            else if Left(line, 8) = "#EXTINF:"
                pending = {
                    name: extAttr(line, "tvg-name")
                    logo: extAttr(line, "tvg-logo")
                    group: extAttr(line, "group-title")
                    tvgId: extAttr(line, "tvg-id")
                    url: ""
                    streamId: ""
                }
                ' Display name after the comma wins when tvg-name is absent
                ' — same as the Android M3U parser.
                comma = line.instr(0, ",")
                if comma > -1 and pending.name = ""
                    pending.name = Mid(line, comma + 2).trim()
                end if
            else if Left(line, 1) <> "#" and pending <> invalid
                if not m3uRoomForMore(channels.count())
                    pending = invalid
                    exit for
                end if
                pending.url = line
                pending.streamId = stableM3uId(digest, idSeen, line)
                channels.push(pending)
                pending = invalid
            end if
        end if
    end for

    ' Tag every channel with its source so merged screens know whose it is
    ' (playback, hidden checks, favorites all route by src). A playlist
    ' being validated before it's saved matches no provider and stays
    ' untagged — it never reaches a merged screen.
    prov = providerForPlaylist(src)
    if prov <> invalid
        token = SrcTokenFor(prov)
        pid = ToStr(prov.id)
        for each c in channels
            c.src = token
            c.provId = pid
        end for
    end if

    rekeySavedM3uIds(channels, prov)
    if m.m3uCapped = true
        ' THE BACKSTOP FIRED, SO THE BOX IS ALREADY AT LOW OR CRITICAL - and
        ' everything parsed so far is what put it there. Handing all of it
        ' back used to be the last thing this task did: a SEMP 32R6610
        ' (H000X, one of the smallest Rokus sold) stopped at 60,750 channels
        ' with the device saying critical, the render thread published them,
        ' Live TV built a grid for them, and the box died with
        ' EXIT_OUT_OF_MEMORY - the OS-level kill, past anything the app's own
        ' ceiling can see (log key F19AB6, 2026-09-12, twice in five minutes).
        '
        ' So a playlist the box could not finish is cut to a size it can
        ' certainly hold. Two thousand is a usable Live TV list; sixty
        ' thousand half-loaded is not a list at all, it is a crash with a
        ' delay on it. This is NOT the proportional ration v1.0.31 tried and
        ' threw away - that guessed on a healthy box; this acts only when the
        ' device itself has said it is out of room, and says so in the log.
        keep = m3uBackstopKeep()
        if channels.count() > keep
            KLog("m3u", "this playlist is too big for this device - keeping the first " + keep.toStr() + " of " + channels.count().toStr() + " channel(s) so the app can stay up")
            trimmed = []
            for i = 0 to keep - 1
                trimmed.push(channels[i])
            end for
            channels = trimmed
        end if
        KLog("m3u", "memory ceiling reached at " + channels.count().toStr() + " channel(s) - this playlist is only partly loaded")
    end if
    m.top.result = { ok: true, channels: channels, tvgUrl: tvgUrl, capped: (m.m3uCapped = true) }
end sub

' ---- The parse-time backstop -------------------------------------------------
'
' The REAL budget is enforced by PublishM3uParse on the render thread - read
' the comment there, it carries the measurements. This is only the backstop
' for the case that budget cannot help with: a single playlist so large that
' the box dies while it is still being parsed, before anything is published.
'
' It deliberately uses ONLY the coarse device reading. roAppMemoryMonitor is
' useless here: from a Task thread it reports that thread's own usage, not the
' app's. Measured on the office stick, a parse task read 14-17% while the app
' was really at 47-56%. Anything budgeting against it silently never fires -
' which is exactly what the first cut of this did.
'
' GetGeneralMemoryLevel is device-wide and honest from a task, so it works,
' but it is coarse: "low" arrives late. That is acceptable for a backstop and
' not acceptable as the main control, which is why the main control is
' elsewhere.
' How much of a playlist survives when the device itself called a halt.
function m3uBackstopKeep() as integer
    return 2000
end function

function m3uRoomForMore(held as integer) as boolean
    if m.m3uCapped = true then return false
    if held mod 250 <> 0 or held = 0 then return true
    lvl = LCase(ToStr(CreateObject("roDeviceInfo").GetGeneralMemoryLevel()))
    if lvl = "low" or lvl = "critical"
        m.m3uCapped = true
        KLog("m3u", "stopping at " + held.toStr() + " channel(s) - the device says memory is " + lvl)
        return false
    end if
    ' The app's OWN alarm, raised on the main thread at 80% of this app's
    ' limit (see main.brs). The device reading above is device-wide and
    ' arrives late; this one is about us and arrives at 80%, which is the
    ' difference between a trimmed playlist and a dead app on the boxes that
    ' died at launch this week (key EFD837 and the 67,000-channel onn, C65D36).
    if m.global <> invalid and m.global.hasField("memPressure")
        if m.global.memPressure = true
            m.m3uCapped = true
            KLog("m3u", "stopping at " + held.toStr() + " channel(s) - the app's own memory alarm has gone off")
            return false
        end if
    end if
    return true
end function

' Which stored source this playlist address belongs to, or invalid.
function providerForPlaylist(src as string) as dynamic
    for each p in LoadProviders()
        ' Dot access, not GetField: the stored key is dot-folded lowercase
        ' ("m3uurl") and only the dot operator matches it case-blind.
        if ToStr(p.ptype) = "m3u" and ToStr(p.m3uUrl) = src then return p
    end for
    return invalid
end function

' The id a channel keeps for life: a fingerprint of its stream address, not
' its position in the file. Positions move — a provider inserting one channel
' near the top used to silently rebind every saved favorite, hidden flag and
' recent below it to the wrong channel ("m3u<position>" ids). The url is the
' one thing that IS the channel. The "h" makes the format impossible to
' mistake for a legacy ordinal id. The same url listed twice (one channel
' filed under two groups) gets _2/_3 suffixes in file order.
function stableM3uId(digest as object, idSeen as object, url as string) as string
    digest.setup("md5")
    ba = CreateObject("roByteArray")
    ba.fromAsciiString(url)
    id = "m3uh" + digest.process(ba).left(10)
    if idSeen.doesExist(id)
        n = idSeen[id] + 1
        idSeen[id] = n
        return id + "_" + n.toStr()
    end if
    idSeen[id] = 1
    return id
end function

' ---- One-time rekey of saved ordinal ids -------------------------------------
' Anything saved before stable ids — favorites, recents, hidden channels,
' list items — still says "m3u<position>". The first parse of each source's
' playlist is the one moment both alphabets are in hand, so translate here:
' by saved url where one was stored (immune to reordering), by position
' otherwise (exactly as right as those ids ever were). Which source this
' playlist is is matched by address, so the six screens that run this task
' don't each have to say; a playlist being validated before it's saved
' (onboarding) matches nothing and skips.
sub rekeySavedM3uIds(channels as object, prov as dynamic)
    if channels.count() = 0 then return   ' don't burn the one-shot flag on a bad fetch
    if prov = invalid then return
    m3uCount = 0
    for each p in LoadProviders()
        if ToStr(p.ptype) = "m3u" then m3uCount = m3uCount + 1
    end for
    provId = ToStr(prov.id)
    if RegRead("m3u_rekey_" + provId) = "1" then return
    RegWrite("m3u_rekey_" + provId, "1")

    byUrl = {}
    for each c in channels
        u = ToStr(c.url)
        if u <> "" and not byUrl.doesExist(u) then byUrl[u] = ToStr(c.streamId)
    end for
    token = SrcTokenFor(prov)
    ' An ordinal only names a position in ONE file. With a single M3U source
    ' that file is known; with several it isn't, so position-based mapping
    ' is off and only url matches translate (a wrong guess would bind rows
    ' to another playlist's channels forever).
    positional = (m3uCount = 1)
    n = 0
    for each prof in EnsureDefaultProfile()
        suffix = ProfileSuffixFor(ToStr(prof.id))
        n = n + rekeyChannelEntries("fav_channels" + suffix, byUrl, channels, token, positional)
        n = n + rekeyChannelEntries("recent_channels" + suffix, byUrl, channels, token, positional)
        if positional
            n = n + rekeyIdList("chan_hidden_" + provId + suffix, channels)
            n = n + rekeyListItems("fav_lists_" + provId + suffix, channels)
        end if
    end for
    if n > 0 then KLog("m3u", "rekeyed " + n.toStr() + " saved ordinal id(s) to stable ids")
end sub

' Saved channel entries ({streamId, url, ...}): url match first, position
' fallback (single-source only). Only rows that are this source's (matching
' src, or untagged from before source tagging) are touched.
function rekeyChannelEntries(key as string, byUrl as object, channels as object, token as string, positional as boolean) as integer
    entries = LoadJsonArray(key)
    if entries.count() = 0 then return 0
    changed = 0
    for each e in entries
        sid = ToStr(GetField(e, "streamId"))
        if IsLegacyM3uId(sid)
            esrc = ToStr(GetField(e, "src"))
            if esrc = "" or esrc = token
                newId = ""
                u = ToStr(GetField(e, "url"))
                if u <> "" and byUrl.doesExist(u) then newId = ToStr(byUrl[u])
                if newId = "" and positional
                    i = ToInt(Mid(sid, 4))
                    if i >= 0 and i < channels.count() then newId = ToStr(channels[i].streamId)
                end if
                if newId <> ""
                    ' Brackets, not dot: dot-assignment folds the key to
                    ' lowercase and would leave the parsed entry with BOTH
                    ' "streamId" (old id) and "streamid" (new) — the same
                    ' case trap that hid the customEpgUrl save (Store.brs).
                    e["streamId"] = newId
                    if token <> "" then e.src = token
                    changed = changed + 1
                end if
            end if
        end if
    end for
    if changed > 0 then SaveJsonArray(key, entries)
    return changed
end function

' Bare id lists (hidden channels): position is all a saved id carries.
function rekeyIdList(key as string, channels as object) as integer
    ids = LoadJsonArray(key)
    if ids.count() = 0 then return 0
    changed = 0
    out = []
    for each idv in ids
        sid = ToStr(idv)
        if IsLegacyM3uId(sid)
            i = ToInt(Mid(sid, 4))
            if i >= 0 and i < channels.count()
                sid = ToStr(channels[i].streamId)
                changed = changed + 1
            end if
        end if
        out.push(sid)
    end for
    if changed > 0 then SaveJsonArray(key, out)
    return changed
end function

' Favorite-list channel items ({kind:"channel", id}): position fallback only
' (list items never stored a url).
function rekeyListItems(key as string, channels as object) as integer
    lists = LoadJsonArray(key)
    if lists.count() = 0 then return 0
    changed = 0
    for each l in lists
        for each it in ToArray(l.items)
            if ToStr(GetField(it, "kind")) = "channel" and IsLegacyM3uId(ToStr(GetField(it, "id")))
                i = ToInt(Mid(ToStr(it.id), 4))
                if i >= 0 and i < channels.count()
                    it.id = ToStr(channels[i].streamId)
                    changed = changed + 1
                end if
            end if
        end for
    end for
    if changed > 0 then SaveJsonArray(key, lists)
    return changed
end function

' Pulls attribute="value" out of an EXTINF line.
' (Local named foundAt because "pos" is reserved in BrightScript.)
function extAttr(line as string, attr as string) as string
    key = attr + "="
    foundAt = line.instr(0, key)
    if foundAt < 0 then return ""
    rest = Mid(line, foundAt + Len(key) + 1)
    if Left(rest, 1) = Chr(34)
        rest = Mid(rest, 2)
        endQ = rest.instr(0, Chr(34))
        if endQ > -1 then return Left(rest, endQ)
    end if
    return ""
end function
