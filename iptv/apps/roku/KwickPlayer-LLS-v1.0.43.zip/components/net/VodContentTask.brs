sub init()
    m.top.functionName = "fetchList"
end sub

' GUARDED, the same way XmltvTask is and for the same reason: a fault on a task
' thread kills the whole app and the crash report that goes up on the next
' launch names no file and no line.
'
' WHAT IT OWES Movies & Series. That screen asks for one source at a time,
' keeps the task in m.inflight and waits on `done`. If `done` never arrives the
' page sits on its spinner and the queue of remaining sources never moves, so
' the member's other sources never load either. The catch writes
' { ok: false, ... }, which VodScreen.onContentDone already handles — it drops
' the task from m.inflight and carries on to the next source.
'
' THE ANSWER GOES OUT FIRST AND THE TIDY-UP SECOND, so a failure while tidying
' cannot leave the screen waiting. The half-built catalogue tree is released
' second: on a big panel it is tens of thousands of nodes, and this screen
' already has five out-of-memory crash reports behind it.
sub fetchList()
    try
        fetchListInner()
    catch e
        GuardFailed("vod/fetchList", e)
        d = m.top.done
        hasAnswer = (type(d) = "roAssociativeArray" and d.count() > 0)
        if not hasAnswer
            ' asked / answered / raw are carried through even on a fault. They
            ' are how Movies & Series tells "your provider sent nothing" apart
            ' from "we dropped it all", and the sources already fetched before
            ' the fault really were asked — reporting zero there would blame
            ' the provider for our own crash. ToInt copes with them being unset
            ' if the fault landed before the first line of the build.
            m.top.done = { ok: false, count: 0, trimmed: false, asked: ToInt(m.askedCount), answered: ToInt(m.answeredCount), raw: ToInt(m.rawCount) }
        end if
        try
            m.top.content = CreateObject("roSGNode", "ContentNode")
        catch e2
            GuardFailed("vod/fetchList/release", e2)
        end try
    end try
end sub

' Fetches one or more sources' VOD catalogs and builds the grid/row content
' OFF the render thread. Multi-source (phase 2): sourcesJson lists every
' source to pull, results merge in that order — the Android VOD merge, which
' also means NO dedup: the same movie on two sources is two tiles, told
' apart by the source tag on the poster.
sub fetchListInner()
    ' Did the app's memory alarm stop this build before it ran out of titles?
    ' Reported back to the screen so Movies & Series can say so in words
    ' instead of looking like an empty library - see the note on the two
    ' guards below, and VodScreen.onContentDone.
    trimmed = false
    ' ---- WHAT THE PROVIDER ITSELF HANDED BACK (2026-10-15) ----------------
    ' Three counts, taken before this task drops, buckets or caps a single
    ' title, and reported to the screen alongside the ones it already gets.
    ' They exist for ONE question: when the page comes out blank, was that the
    ' provider's doing or ours? Those two look identical on a television and
    ' the app has been telling members the wrong one.
    '
    '   asked      sources this task sent a catalogue request to
    '   answered   how many of them came back with a readable list at all.
    '              A source that timed out or answered with rubbish is NOT
    '              counted - "couldn't be reached" is not "sent nothing".
    '   raw        titles in those lists, as the provider wrote them. This is
    '              the number that matters: a member who has hidden every one
    '              of their film categories gets a blank page with `raw` in
    '              the tens of thousands, and must never be told their
    '              provider is broken.
    m.askedCount = 0
    m.answeredCount = 0
    m.rawCount = 0
    isSeries = (m.top.kind = "series")
    showTags = m.top.showTags
    sources = ParseJson(m.top.sourcesJson)
    if sources = invalid then sources = []

    root = CreateObject("roSGNode", "ContentNode")
    total = 0

    ' Category names this build must not show at all (adult, in practice —
    ' see dropCatsJson). Empty for every ordinary fetch, so the loops below
    ' cost one associative-array lookup that always misses.
    drop = {}
    dropList = ParseJson(m.top.dropCatsJson)
    if dropList <> invalid
        for each nm in ToArray(dropList)
            drop[ToStr(nm)] = true
        end for
    end if

    if m.top.mode = "rows"
        ' One row per category NAME, in the merged display order, up to 15
        ' titles per row — the Android VOD landing. Every source's items
        ' bucket into the shared rows via that source's own id->name map.
        rowByName = {}
        cats = ParseJson(m.top.catsJson)
        if cats <> invalid
            for each c in cats
                rowNode = CreateObject("roSGNode", "ContentNode")
                rowNode.title = ToStr(c.name)
                rowByName[ToStr(c.name)] = rowNode
            end for
        end if
        for each src in sources
            items = fetchItems(ToStr(src.url), ToStr(GetField(src, "label")))
            if items <> invalid
                idToName = {}
                for each c in ToArray(GetField(src, "cats"))
                    idToName[ToStr(c.id)] = ToStr(c.name)
                end for
                for each s in items
                    catName = ToStr(idToName[ToStr(GetField(s, "category_id"))])
                    if catName <> "" and rowByName.doesExist(catName)
                        rowNode = rowByName[catName]
                        ' total > 0 - SEE THE LONG NOTE ON THE SAME TEST IN
                        ' THE FLAT BRANCH BELOW. Without it this fires on the
                        ' very first title and the member gets no rows at all.
                        if total > 0 and total mod 100 = 0 and vodMemPressure()
                            trimmed = true
                            exit for
                        end if
                        if rowNode.getChildCount() < 15
                            appendItem(rowNode, s, isSeries, src, showTags)
                            total = total + 1
                        end if
                    end if
                end for
            end if
        end for
        ' Keep display order, drop empty rows.
        if cats <> invalid
            for each c in cats
                rowNode = rowByName[ToStr(c.name)]
                if rowNode <> invalid and rowNode.getChildCount() > 0 then root.appendChild(rowNode)
            end for
        end if
    else if m.top.mode = "years"
        ' One row per RELEASE YEAR, newest first — the Android VOD Year tab.
        ' The year is read off the catalogue rows THIS FETCH ALREADY HAS
        ' (see CatalogYear below), so browsing by year costs the same one
        ' request per source that the All view costs and NOTHING per year:
        ' every year the member picks afterwards is already a built row.
        '
        ' Years cut across categories, so this is the whole catalog with no
        ' category filter — which means the dropped (adult) category names
        ' have to be applied here exactly as the All view applies them
        ' (certification 6.3), or those titles walk back in through Year.
        cap = m.top.maxPerYear
        if cap < 1 then cap = 300
        maxYear = CreateObject("roDateTime").GetYear() + 1
        rowByYear = {}
        for each src in sources
            items = fetchItems(ToStr(src.url), ToStr(GetField(src, "label")))
            if items <> invalid
                idToName = {}
                for each c in ToArray(GetField(src, "cats"))
                    idToName[ToStr(c.id)] = ToStr(c.name)
                end for
                for each s in items
                    if drop.doesExist(ToStr(idToName[ToStr(GetField(s, "category_id"))])) then continue for
                    y = CatalogYear(s, maxYear)
                    ' No year anywhere on the row and none in the title: the
                    ' title simply isn't in the Year view, same as Android
                    ' (it only ever keeps items whose year is non-empty).
                    if y = "" then continue for
                    rowNode = rowByYear[y]
                    if rowNode = invalid
                        rowNode = CreateObject("roSGNode", "ContentNode")
                        rowNode.title = y
                        rowByYear[y] = rowNode
                    end if
                    ' THE CAP. A busy year on a big library is thousands of
                    ' titles, and this box has ~90 MB of texture budget and
                    ' five out-of-memory reports behind it. 300 is 50 grid
                    ' rows deep — far more than anyone scrolls — and it
                    ' holds the whole year tree well under the size of the
                    ' All view, which builds the catalog uncapped.
                    if rowNode.getChildCount() < cap
                        appendItem(rowNode, s, isSeries, src, showTags)
                        total = total + 1
                    end if
                end for
            end if
        end for
        years = []
        for each y in rowByYear
            years.push(y)
        end for
        years.sort()    ' every key is 4 digits, so lexical order IS numeric
        for i = years.count() - 1 to 0 step -1
            root.appendChild(rowByYear[years[i]])
        end for
        KLog("vod", "year buckets: " + years.count().toStr() + " years, " + total.toStr() + " titles (cap " + cap.toStr() + "/year)")
    else
        ' Flat grid: each source's list in turn. A source that fails is
        ' skipped — one provider having a bad day must not blank the rest.
        for each src in sources
            items = fetchItems(ToStr(src.url), ToStr(GetField(src, "label")))
            if items <> invalid
                ' Only the All view carries cats, and only the All view can
                ' have anything to drop — a named category was already
                ' filtered before it was asked for.
                idToName = {}
                for each c in ToArray(GetField(src, "cats"))
                    idToName[ToStr(c.id)] = ToStr(c.name)
                end for
                ' NO MORE THAN 500 TITLES PER SOURCE ARE TURNED INTO NODES HERE.
                ' The screen keeps 500 per source on the flat grid already, but
                ' a cap on the render thread is too late for the box this came
                ' from: a Hisense 6Series-50 (key 5BB222, v1.0.36, one Xtream
                ' provider with tens of thousands of films) went from 16% to
                ' 80% and was killed within fifteen seconds of opening Movies &
                ' Series, four times in two hours - and every one of those
                ' nodes was built HERE, in this loop, before the screen saw a
                ' single one. 500 is the media-server path's number, chosen
                ' when it was added; the count that was really there goes in
                ' the log, the same sentence that path already prints.
                kept = 0
                for each s in items
                    if drop.doesExist(ToStr(idToName[ToStr(GetField(s, "category_id"))])) then continue for
                    if kept >= 500 then exit for
                    ' The app's own 80% alarm (main.brs -> m.global.memPressure)
                    ' is the one honest signal this thread can read; stop
                    ' building once it is up.
                    '
                    ' >>> `kept > 0` IS THE WHOLE POINT OF THIS LINE.
                    ' It used to read `if kept mod 100 = 0 and ...`, and
                    ' 0 mod 100 IS 0, so the test was true on the very first
                    ' title. That turned "build less" into "build nothing":
                    ' with the alarm already up as the loop started, the source
                    ' produced an empty page, not a short one.
                    '
                    ' WHAT THAT LOOKED LIKE ON A MEMBER'S TELEVISION. Log key
                    ' B6DA8F, a Westinghouse 70in, 1 October 2026. Their
                    ' television warned the app it was running out of room, and
                    ' from that moment Movies & Series showed nothing at all -
                    ' the log says "'Strong 8K' holds 37 titles; showing the
                    ' first 0" and "'Chibi' holds 50 titles; showing the first
                    ' 0". BOTH OF THOSE WOULD HAVE FITTED WHOLE: the first
                    ' check now happens at a hundred titles, so a library of 37
                    ' or 50 is never cut at all. Four minutes after staring at
                    ' the blank page that member went into Settings and deleted
                    ' their source.
                    '
                    ' NOT A v1.0.40 FAULT - carried in. The gate landed in
                    ' v1.0.38 and the arm that makes it fire on the small
                    ' sticks landed in v1.0.39; this release only inherited it.
                    '
                    ' A hundred titles is not a new number - it is the check
                    ' interval this line already used - and it is seventeen
                    ' rows of the six-wide grid. The costly part of a source,
                    ' the download and the JSON parse, has already happened by
                    ' the time this loop runs, so a hundred ContentNodes more
                    ' is a rounding error against it, and the posters cost
                    ' nothing extra because only the cards actually on screen
                    ' are ever decoded.
                    if kept > 0 and kept mod 100 = 0 and vodMemPressure()
                        trimmed = true
                        exit for
                    end if
                    appendItem(root, s, isSeries, src, showTags)
                    kept = kept + 1
                    total = total + 1
                end for
                if items.count() > kept then KLog("vod", "'" + ToStr(GetField(src, "label")) + "' holds " + items.count().toStr() + " titles; showing the first " + kept.toStr())
                ' The parsed catalogue is the other half of the peak - tens of
                ' thousands of associative arrays - and nothing below needs it.
                ' Let it go before the next source is asked, not at the end.
                items = invalid
            end if
        end for
    end if

    m.top.content = root
    ' `trimmed` is the screen's only way to tell a short page apart from an
    ' empty library: ok is true either way. VodScreen turns it into a line the
    ' member can read.
    '
    ' asked / answered / raw are the second half of that same job, added
    ' 2026-10-15 - see the block at the top of this sub. `count` is what this
    ' page is willing to show; `raw` is what the provider actually sent. Only
    ' the difference between them can say whose fault a blank page is.
    m.top.done = { ok: true, count: total, trimmed: trimmed, asked: m.askedCount, answered: m.answeredCount, raw: m.rawCount }
end sub

' One catalog request; invalid on any failure.
' Has the app's own memory alarm gone off? Raised on the main thread at 80%
' of this app's limit (main.brs), cleared on the render thread under 70%
' (PublishM3uParse). Read here because the memory monitor a Task can reach
' reports only this thread and lies about the app.
function vodMemPressure() as boolean
    if m.global = invalid or not m.global.hasField("memPressure") then return false
    if m.global.memPressure = true
        KLog("vod", "stopping the catalogue build - the app's own memory alarm has gone off")
        return true
    end if
    return false
end function

' COUNTED AND TIMED (2026-10-15), and the log line is one sentence per source:
' how many titles came back and how long the provider took. It NEVER prints
' the answer itself. A film catalogue is tens of thousands of entries, a
' member's log is uploaded to us when they ask for help, and the body would
' both drown the log and carry their library around with it.
'
' The timing is there because the fault this was added for is a FAST empty
' answer - a panel that hands back an empty list in under a second where it
' normally takes many seconds to send 44,000 films. "Empty in 0.4s" and
' "empty after 90s" are different problems and the log has to tell them
' apart.
function fetchItems(url as string, label as string) as dynamic
    if url = "" then return invalid
    m.askedCount = m.askedCount + 1
    clock = CreateObject("roTimespan")
    clock.mark()
    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.enableEncodings(true)
    xfer.addHeader("User-Agent", KwickUserAgent())
    xfer.setUrl(url)
    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)
    if not xfer.asyncGetToString() then return fetchFailed(label, clock, "the request could not be started")
    msg = wait(m.top.timeoutMs, port)
    if type(msg) <> "roUrlEvent"
        xfer.asyncCancel()
        return fetchFailed(label, clock, "no answer in time")
    end if
    if msg.getResponseCode() < 200 or msg.getResponseCode() >= 300
        return fetchFailed(label, clock, "answered " + ToStr(msg.getResponseCode()))
    end if
    parsed = ParseJson(msg.getString())
    if parsed = invalid then return fetchFailed(label, clock, "sent something this app could not read")
    out = ToArray(parsed)
    ' COUNTED HERE AND ONLY HERE. An empty list is a perfectly good answer and
    ' it counts as answered - that is the whole distinction this exists for.
    m.answeredCount = m.answeredCount + 1
    m.rawCount = m.rawCount + out.count()
    KLog("vod", "'" + label + "' sent " + out.count().toStr() + " title(s) in " + secsText(clock) + "s")
    return out
end function

' A catalogue request that did not come back with a list. Said in the same
' shape as a good one so the two read off a log side by side, and NOT counted
' as answered.
function fetchFailed(label as string, clock as object, why as string) as dynamic
    KLog("vod", "'" + label + "' gave no list after " + secsText(clock) + "s - " + why)
    return invalid
end function

' Seconds to one decimal place. Built from the whole milliseconds rather than
' divided into a float because BrightScript prints a float with a leading
' space and a long tail, which is not something to put in a member's log.
' Both halves go into named variables before .toStr() is called on them.
' Calling a method straight off a bracketed expression is the kind of thing
' that works on one box and raises a type mismatch on another, and this runs
' on every catalogue request.
function secsText(clock as object) as string
    ms = clock.totalMilliseconds()
    secs = Int(ms / 1000)
    tenth = Int((ms mod 1000) / 100)
    return secs.toStr() + "." + tenth.toStr()
end function

' ---- Release year -------------------------------------------------------------
'
' A straight port of Android's catalogYear()/yearInTitle()/plausibleYear()
' (lib/core/models/xtream_models.dart) so both apps bucket the SAME title
' under the same year. Nothing here fetches anything: every input is a field
' of a catalogue row this task already downloaded.

' The release year for one catalogue row, from whatever the panel gave us.
' Panels are wildly inconsistent — get_series usually carries releaseDate,
' get_vod_streams usually carries no date at all — so the title is not an
' optional fallback, it is where most film years actually come from.
function CatalogYear(s as object, maxYear as integer) as string
    for each k in ["releaseDate", "release_date", "releasedate", "year"]
        v = ToStr(GetField(s, k))
        if Len(v) >= 4
            y = PlausibleYear(Left(v, 4), maxYear)
            if y <> "" then return y
        end if
    end for
    return YearInTitle(ToStr(GetField(s, "name")), maxYear)
end function

' A year a film could actually have been released in. Next year is allowed
' (announced titles legitimately appear early), nothing beyond it. Without
' this, one junk date scatters titles across decades that cannot exist.
function PlausibleYear(y as string, maxYear as integer) as string
    if not IsYearDigits(y) then return ""
    n = ToInt(y)
    if n < 1900 or n > maxYear then return ""
    return y
end function

function IsYearDigits(y as string) as boolean
    if Len(y) <> 4 then return false
    p = Left(y, 2)
    if p <> "19" and p <> "20" then return false
    d = "0123456789"
    if Instr(1, d, Mid(y, 3, 1)) = 0 then return false
    if Instr(1, d, Mid(y, 4, 1)) = 0 then return false
    return true
end function

' A year written into a title. IPTV libraries mark it two ways and only two:
' bracketed anywhere — "Some Film (2024)" — or bare at the very END —
' "Landman 2024". Both are common enough that ignoring either loses most of
' the library. A bare number ANYWHERE ELSE is part of the name, which is
' what put "Blade Runner 2049" under 2049; a title that IS a year ("1917",
' "2012") is a name too, so something has to come before it.
function YearInTitle(name as string, maxYear as integer) as string
    t = name.trim()
    n = Len(t)
    if n < 4 then return ""
    ' Bracketed wins: it is the deliberate marking, so it beats any number
    ' that merely happens to sit in the name.
    scanAt = 1
    while scanAt <= n
        o = Instr(scanAt, t, "(")
        b = Instr(scanAt, t, "[")
        if o = 0 and b = 0 then exit while
        if o = 0 or (b > 0 and b < o) then o = b
        if o + 5 <= n
            cl = Mid(t, o + 5, 1)
            if cl = ")" or cl = "]"
                y = PlausibleYear(Mid(t, o + 1, 4), maxYear)
                if y <> "" then return y
            end if
        end if
        scanAt = o + 1
    end while
    ' Bare at the very end, with a real word in front of it.
    if n >= 6
        y = Right(t, 4)
        if IsYearDigits(y)
            j = n - 4
            gap = false
            while j >= 1 and Mid(t, j, 1) = " "
                gap = true
                j = j - 1
            end while
            if gap and j >= 1 then return PlausibleYear(y, maxYear)
        end if
    end if
    return ""
end function

sub appendItem(parent as object, s as object, isSeries as boolean, src as object, showTags as boolean)
    node = parent.createChild("ContentNode")
    node.title = ToStr(GetField(s, "name"))
    if isSeries
        node.id = ToStr(GetField(s, "series_id"))
        node.hdPosterUrl = PosterUrl(ToStr(GetField(s, "cover")))
    else
        node.id = ToStr(GetField(s, "stream_id"))
        node.hdPosterUrl = PosterUrl(ToStr(GetField(s, "stream_icon")))
        node.description = ToStr(GetField(s, "container_extension"))
    end if
    ' Precomputed key for the favorite heart, so the poster tile only has to
    ' do one associative-array hit while the grid recycles it. Must match
    ' the key RefreshFavVodIndex() builds: "<kind>:<id>", prefixed
    ' "<src>:" when the item's source isn't KwickTV.
    kind = "movie"
    if isSeries then kind = "series"
    key = ""
    token = ToStr(GetField(src, "src"))
    if node.id <> ""
        key = kind + ":" + node.id
        if token <> "" then key = token + ":" + key
    end if
    ' srcTok/srcLabel ride on the node: the detail screen routes playback
    ' and favorites by them, and the poster tile draws the label as the
    ' corner source tag when tags are on ("All" view, several sources).
    tag = ""
    if showTags then tag = ToStr(GetField(src, "label"))
    ' cardRound turns on PosterCard's 8px corners, its always-on frost frame
    ' and its own orange focus ring - the "home treatment", asked for on VOD
    ' by the owner 2026-08-26 ("them posters need the same home treatment with
    ' rounded edges and blue outline and orange highlight"). It is a field on
    ' the ITEM and not on the card because a MarkupGrid/RowList does not expose
    ' its item components, so a screen has no way to reach in and set one; the
    ' same route HomeScreen.brs:1647 already uses.
    '
    ' Unconditional, and safe to be: this task only ever feeds VodScreen (its
    ' one caller is VodScreen.brs:745). SearchScreen builds its own nodes and
    ' does not set this, so SEARCH IS UNCHANGED.
    '
    ' It costs no texture. card_round.9.png and card_edge.9.png are 42 x 42
    ' nine-patches already resident for Home's rounded posters and Live TV's
    ' channel tiles - 7,056 bytes each, ONCE for the whole app however many
    ' cards point at them.
    node.addFields({ favKey: key, srcTok: token, srcLabel: tag, cardRound: true })
end sub
