' One conversation with the link service at kwickplayer.tv, off the render
' thread. Three things to say:
'
'   claim  ask for a six-character code to show on the TV, and the secret
'          that goes with it. Asking again before the code runs out gives
'          back the same code, so reopening the screen doesn't confuse
'          anybody who is halfway through typing. The answer also carries
'          this box's permanent key, so pairing is the only trip Settings
'          ever needs. It also mentions the source this TV came with, so
'          the website has something to show a member who hasn't added
'          anything there yet.
'   poll   ask what has been added since change number <since>. Every poll
'          carries the secret from claim.
'   key    ask for this box's permanent key on its own — what Settings uses
'          to top up its cached copy without minting a pairing code nobody
'          asked for. Carries the secret too; the service will not answer
'          without it, whatever else is set.
'   reset  give this television a brand new key and cut everything else
'          loose: the old key stops working, every phone or browser that was
'          managing this TV is kicked off, every playlist on the website is
'          taken off this TV's list, and the secret is rotated. It is the
'          sold-the-Roku button. Carries the secret, and the answer carries
'          BOTH the new key and the NEW SECRET — storing that secret is not
'          optional, see Settings' resetLinkKey(). Somebody is waiting on
'          this one; it is the only action here that is neither a background
'          top-up nor fire-and-forget.
'   drop   tell the service a playlist has been removed HERE, so the
'          website's "On this TV" list stops claiming it is still on the
'          television. Carries the secret and the service's own id for the
'          source; the service tombstones it and answers { ok: true, id }.
'          Nobody waits for that answer — see the note in
'          SettingsCategoryScreen's dropSourceFromLinkService().
'
' The service always answers HTTP 200; a refusal comes back as
' { ok: false, code: "<machine code>", error: "<something readable>" }.
' Anything that stops us getting an answer at all — no network, a hiccup,
' junk instead of JSON — is turned into the same shape with code "network",
' so the screen has exactly one kind of failure to talk about.
'
' The screen creates one of these per request and stops it when it closes;
' nothing here loops or keeps going on its own.

sub init()
    m.top.functionName = "runLink"
end sub

' The link service. These two belong next to the other kwickplayer.tv
' addresses in KwickBranding() over in Theme.brs, but that file is being
' worked on for the store edition right now, so they sit here for the
' moment and should be folded in with the rest later.
function LinkApiUrl() as string
    return "https://kwickplayer.tv/kwicksync/link.php"
end function

' Where scanning the square lands: the page the member would otherwise type
' in, with the code already filled in for them.
function LinkPageUrl(code as string) as string
    return "https://kwickplayer.tv/link?code=" + code
end function

sub runLink()
    body = { action: m.top.action, device: m.top.device }
    if m.top.action = "poll" then body.since = m.top.since
    ' The secret from claim goes on EVERY poll, EVERY key request, EVERY
    ' reset and EVERY drop, no exceptions. Without it, anybody who learned
    ' this box's device id could read the member's provider username and
    ' password straight off the service, take the key that manages their
    ' playlists, delete the playlists themselves, or unlink the television.
    if m.top.action = "poll" or m.top.action = "key" or m.top.action = "reset" or m.top.action = "drop"
        body.secret = m.top.secret
    end if
    ' Which playlist to take off the website. The field is called sourceId
    ' and not id because every SceneGraph node already has an "id" of its
    ' own; on the wire it is plain "id", which is what the service reads.
    if m.top.action = "drop" then body.id = m.top.sourceId
    ' A TV with KwickTV signed in says so when it claims, so the website
    ' lists it alongside whatever the member adds there instead of telling
    ' them there is nothing on this television.
    '
    ' EVERY claim carries this key, both ways round. Leaving it off does not
    ' mean "nothing here" to the service — it means "no opinion", and the
    ' last thing we told it stands. A member who signs out of KwickTV on the
    ' TV would go on seeing a KwickTV row on the website forever. So when
    ' there is nothing to report we send something the service will refuse,
    ' which is how it is told to forget what it was told before.
    '
    ' The refusal is spelled out as { kind: "none" } rather than an empty
    ' {} on purpose: an empty one would have to survive both a SceneGraph
    ' field and FormatJson without being turned into nothing, and if it ever
    ' were, the key would silently vanish from the body and we would be back
    ' to the stale row. A key the service has a reason to reject cannot go
    ' quiet on us. An older service that has never heard of any of this
    ' ignores the whole field, exactly as before.
    if m.top.action = "claim"
        builtin = m.top.builtin
        if builtin = invalid or builtin.count() = 0 then builtin = { kind: "none" }
        body.builtin = builtin
    end if

    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.enableEncodings(true)
    xfer.addHeader("Content-Type", "application/json")
    xfer.addHeader("User-Agent", KwickUserAgent())
    xfer.setUrl(LinkApiUrl())
    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)
    if not xfer.asyncPostFromString(FormatJson(body))
        m.top.result = { ok: false, code: "network", error: "couldn't start the request" }
        return
    end if
    ' Somebody is sitting in front of the TV watching for this, and another
    ' one goes out a few seconds later anyway, so a slow answer is no answer.
    msg = wait(12000, port)
    if type(msg) <> "roUrlEvent"
        xfer.asyncCancel()
        m.top.result = { ok: false, code: "network", error: "no answer in time" }
        return
    end if
    status = msg.getResponseCode()
    if status < 200 or status >= 300
        KLog("link", "link service answered " + status.toStr())
        m.top.result = { ok: false, code: "network", error: "server answered " + status.toStr() }
        return
    end if
    resp = ParseJson(msg.getString())
    if resp = invalid
        KLog("link", "link service didn't return JSON")
        m.top.result = { ok: false, code: "network", error: "couldn't read the answer" }
        return
    end if

    ' A new code gets its QR drawn here rather than on the render thread —
    ' the encoder is a few hundred thousand small steps, which is nothing on
    ' a thread of its own and a visible stutter on the one drawing the
    ' screen. A code we can't encode simply travels without a QR; the screen
    ' leaves the square off and the typed code still works.
    if m.top.action = "claim" and resp.ok = true
        rows = QrEncode(LinkPageUrl(ToStr(GetField(resp, "code"))))
        if rows <> invalid
            resp.qr = rows
        else
            KLog("link", "code wouldn't fit a QR - showing the code on its own")
        end if
    end if
    m.top.result = resp
end sub
