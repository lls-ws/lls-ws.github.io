' "Kwick Picks" recommendations — the Roku port of Android's
' because_you_watched. Fetches the full VOD/series catalog, finds the seed
' title's category, and returns up to 15 other titles from that same category
' the viewer hasn't watched. Runs off the render thread (catalogs are big).

sub init()
    m.top.functionName = "compute"
end sub

sub compute()
    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.enableEncodings(true)
    xfer.addHeader("User-Agent", KwickUserAgent())
    xfer.setUrl(m.top.url)

    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)
    if not xfer.asyncGetToString()
        m.top.result = { ok: false, items: [] }
        return
    end if
    msg = wait(m.top.timeoutMs, port)
    if type(msg) <> "roUrlEvent"
        xfer.asyncCancel()
        m.top.result = { ok: false, items: [] }
        return
    end if
    if msg.getResponseCode() < 200 or msg.getResponseCode() >= 300
        m.top.result = { ok: false, items: [] }
        return
    end if

    parsed = ParseJson(msg.getString())
    if parsed = invalid
        m.top.result = { ok: false, items: [] }
        return
    end if
    items = ToArray(parsed)
    isSeries = (m.top.kind = "series")

    ' Exclusion set (recently watched) and hidden/locked category set.
    watched = {}
    w = ParseJson(m.top.watchedJson)
    if w <> invalid
        for each id in ToArray(w)
            watched[ToStr(id)] = true
        end for
    end if
    hiddenCats = {}
    h = ParseJson(m.top.hiddenCatsJson)
    if h <> invalid
        for each cid in ToArray(h)
            hiddenCats[ToStr(cid)] = true
        end for
    end if

    ' The seed's category.
    seedCat = ""
    for each s in items
        if idOf(s, isSeries) = m.top.seedId
            seedCat = ToStr(GetField(s, "category_id"))
            exit for
        end if
    end for
    ' No seed, or it lives in a hidden/locked category → recommend nothing.
    if seedCat = "" or hiddenCats.doesExist(seedCat)
        m.top.result = { ok: true, items: [] }
        return
    end if

    candidates = []
    for each s in items
        cat = ToStr(GetField(s, "category_id"))
        sid = idOf(s, isSeries)
        if cat = seedCat and sid <> m.top.seedId and not watched.doesExist(sid) and not hiddenCats.doesExist(cat)
            candidates.push(s)
        end if
    end for

    shuffle(candidates)

    out = []
    n = candidates.count()
    if n > 15 then n = 15
    for i = 0 to n - 1
        s = candidates[i]
        if isSeries
            out.push({ kind: "series", id: idOf(s, true), name: ToStr(GetField(s, "name")), icon: ToStr(GetField(s, "cover")), ext: "" })
        else
            out.push({ kind: "movie", id: idOf(s, false), name: ToStr(GetField(s, "name")), icon: ToStr(GetField(s, "stream_icon")), ext: ToStr(GetField(s, "container_extension")) })
        end if
    end for

    m.top.result = { ok: true, items: out }
end sub

function idOf(s as object, isSeries as boolean) as string
    if isSeries then return ToStr(GetField(s, "series_id"))
    return ToStr(GetField(s, "stream_id"))
end function

' In-place Fisher-Yates shuffle (Rnd works on a task thread).
sub shuffle(arr as object)
    for i = arr.count() - 1 to 1 step -1
        j = Rnd(i + 1) - 1  ' Rnd(n) returns 1..n
        tmp = arr[i]
        arr[i] = arr[j]
        arr[j] = tmp
    end for
end sub
