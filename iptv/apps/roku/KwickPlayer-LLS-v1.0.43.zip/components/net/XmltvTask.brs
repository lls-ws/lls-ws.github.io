' XMLTV fetch + parse, sized for a Roku: only programmes for tvg-ids the
' playlist references, only a 1h-back/18h-forward window, and a hard cap on
' the download size (a DOM parse of a huge file would take the box down).
' Gzipped .gz guide FILES aren't supported (Roku has no gunzip API) — the
' transport-level gzip most servers use works fine.
'
' THE DOWNLOAD IS BOUNDED NOW, AND IT WASN'T. This file used to pull the
' whole document back through roUrlTransfer.getToString() — one string, in
' the app's own memory — and only THEN compare its length with
' MAXGUIDEBYTES(). So the check could only ever fire after the damage was
' done: a 100 MB guide (an Xtream panel's own xmltv.php is routinely that
' big) was already 100 MB of app memory by the time we looked, and Roku had
' already shot the app with EXIT_CHANNEL_MEM_LIMIT_FG. "Too large for this
' device" was a message the app was rarely alive to show.
'
' Three things stand between a huge guide and the app now, in order:
'   1. A HEAD request first. If the server will say how big it is and the
'      answer is over the cap, nothing is downloaded at all. THIS IS THE
'      ONLY ONE OF THE THREE THAT STOPS A TRANSFER. It works, and B6DA8F's
'      first source was caught by it in 2026-10-01 without a byte moving.
'   2. The body is written to cachefs:, not into a string, with
'      asyncGetToFile(). cachefs does NOT count towards the app's memory
'      allowance, which is the whole point — the bytes can't get us killed
'      while we decide what to do about them. While it lands we tick every
'      quarter second and stat the file.
'      >>> THAT TICK IS BLIND. MEASURED 2026-10-02. <<< Roku does not expose
'      the part-file: the stat reads 0 for the entire transfer and the file
'      appears, at full size, only when it finishes. The size check inside
'      the loop has therefore never once stopped a download, and the whole
'      file lands every time. The proof is written out in full at that
'      check. Do not read step 2 as a bound; it is a place to put one if
'      Roku ever gives us the means.
'   3. The finished file is stat'd once more before a byte of it is read.
'      THIS IS WHAT ACTUALLY REFUSES OVERSIZED GUIDES TODAY — 40 MB to 93 MB
'      across the log archive, all of it downloaded before it was judged.
'
' WHAT IS STILL OPEN, and it is the biggest thing in this file: when a panel
' sends xmltv.php chunked with no Content-Length, step 1 has nothing to act
' on and nothing else can stop the transfer. roUrlTransfer on OS 15/16 gives
' an app no progress callback, no byte ceiling and no visible part-file, so
' there is no technique left — only policy about whether to ask at all. That
' decision is ledger work, not a patch, and it needs the new "the server will
' not say how big this guide is" line below to size it.
' Then the scan reads the file back in 256 KB pieces (roByteArray.readFile
' with an offset and a length), so the app never holds more than one piece
' plus the listings it has kept. Peak memory used to be the whole file plus
' the listings; it is now a quarter of a megabyte plus the listings.
'
' WHAT IS DELIBERATELY UNCHANGED: the 24 MB ceiling and its ">" comparison,
' the MemoryTight() bail-outs, the wanted-id filter, the -1h/+18h window and
' every field of the result. Three screens read m.global.xmltvById and none
' of them should be able to tell this rewrite happened.

sub init()
    m.top.functionName = "run_xmltv"
end sub

' ---- The guard -------------------------------------------------------------
'
' THIS FILE HAD NO try/catch IN IT AT ALL, AND THAT IS WHAT CRASH 1E24EB WAS.
'
' IN PLAIN WORDS, WHAT HAPPENED ON THAT TELEVISION. A member with a TCL 43S451
' on v1.0.42 was watching Live TV. Behind the screen the app was reading the
' third of their TV guides — a three-megabyte file. Something in that read went
' wrong and the whole app shut down to the Roku home screen with no warning.
' The report sent up on the next launch could not say what had gone wrong,
' because nothing in this file was watching for it: it named no file, no line
' and no function. The last thing the app wrote down, six seconds before it
' died, was the channel index line in finishAliases at the foot of this file.
' It was NOT the television running out of memory — the box was at 19% and
' raised no alarm.
'
' A TASK IS NOT A SCREEN, AND THE DANGER IS THE OPPOSITE ONE. On a screen the
' thing to get right was not swallowing the Back button. Here it is silence.
' Four places build one of these, set it going, watch the `result` field and
' then WAIT: Live TV, the TV Guide, a channel's own page, and the guide check
' in Settings. Nothing else ever tells them the task has died. So the catch
' owes them an answer, and it gives the same { ok: false, error: ... } every
' one of them already knows how to handle for a guide that would not read —
' the chain moves on to the member's next guide and the Settings check says
' "that guide didn't load", instead of a spinner that never stops.
'
' THE ANSWER GOES OUT BEFORE THE TIDY-UP, deliberately. If the clean-up below
' were ever to fault it would take the task down a second time with the caller
' still waiting, which is the exact fault this guard exists to remove.
'
' AND ONLY IF NOBODY ANSWERED ALREADY. `result` is written once, as the last
' act of every path through run_xmltv_inner. A second write would fire all four
' callers' handlers again and step the guide chain on twice, so an answer that
' is already there is left alone.
sub run_xmltv()
    m.guidePath = ""
    try
        run_xmltv_inner()
    catch e
        GuardFailed("xmltv/run", e)
        r = m.top.result
        hasAnswer = (type(r) = "roAssociativeArray" and r.count() > 0)
        if not hasAnswer
            m.top.result = { ok: false, error: "the guide could not be read" }
        end if
        ' WHAT A FAULT MID-DOWNLOAD LEAVES ON cachefs. cachefs is RAM on most
        ' Rokus, so a guide file nobody deletes is memory held for nothing.
        ' This deletes ours if it has landed. If the transfer was still in the
        ' air then it has NOT landed — Roku does not publish the part-file, as
        ' the long note over fetchGuideToCache sets out — so there is nothing
        ' to delete here and the finished file may appear after this returns.
        ' That orphan is already covered: sweepOldGuides deletes any
        ' kwick_xmltv_ file older than ten minutes at the start of the next
        ' guide fetch, so it is reclaimed on the member's next guide read and
        ' can never pile up.
        '
        ' Nested, so a failure in the clean-up cannot itself become the
        ' uncaught fault this guard exists to prevent.
        try
            deleteQuietly(m.guidePath)
        catch e2
            GuardFailed("xmltv/run/cleanup", e2)
        end try
        m.guidePath = ""
    end try
end sub

sub run_xmltv_inner()
    url = m.top.url
    if url = ""
        m.top.result = { ok: false, error: "no guide url" }
        return
    end if
    ' A .gz guide cannot be read on this platform - Roku has no gunzip - but
    ' that is not the same as the member having no guide. Providers that serve
    ' "epg.xml.gz" almost always serve "epg.xml" from the same address, so ASK
    ' FOR THAT BEFORE GIVING UP. Costs one HEAD request on a path that
    ' currently fails 100% of the time, and nothing at all for everyone else.
    '
    ' This is the fault behind "could not read your guide" for members whose
    ' playlist points at a compressed guide - the owner's own Roku among them,
    ' and member CFB272, who had no EPG at all for that reason.
    if LCase(url.right(3)) = ".gz"
        plain = Left(url, Len(url) - 3)
        if plainGuideExists(plain)
            KLog("xmltv", "guide is a .gz file - Roku cannot unpack one, but the same address serves an uncompressed copy, so that is being used instead")
            url = plain
        else
            KLog("xmltv", "guide is a .gz file - not supported, and no uncompressed copy is offered at the same address")
            m.top.result = { ok: false, error: "compressed guide (.gz) not supported" }
            return
        end if
    end if

    ' If the box is already short of memory before we've downloaded a thing,
    ' pulling in tens of megabytes is how the app gets killed rather than how
    ' it shows a guide. Say so instead.
    if MemoryTight()
        KLog("xmltv", "skipping guide fetch - device memory is already tight")
        m.top.result = { ok: false, error: "guide too large for this device" }
        return
    end if

    m.top.progress = "Downloading the guide…"

    ' ---- 1. ask before pulling ------------------------------------------
    ' Costs one round trip and can save a hundred megabytes of transfer.
    '
    ' THIS IS THE ONLY CHECK THAT ACTUALLY WORKS. Proved on the 2026-10-02
    ' logs -- see the long note over fetchGuideToCache. So whether the server
    ' answered it, and with what, is the most important fact in a guide
    ' fetch, and until now it was only ever written down when the answer was
    ' over the cap. A silent pre-check and an absent pre-check looked the
    ' same, which is how the hole below went unnoticed for a fortnight.
    ' ONE LINE PER GUIDE FETCH -- not per poll, not per channel.
    declared = declaredGuideBytes(url)
    if declared > MAXGUIDEBYTES()
        KLog("xmltv", "guide too large: server says " + declared.toStr() + " bytes, cap is " + MAXGUIDEBYTES().toStr())
        m.top.result = { ok: false, error: "guide too large for this device" }
        return
    end if
    if declared < 0
        KLog("xmltv", "the server will not say how big this guide is - so nothing can stop the download part way through, and the whole file has to land before it can be judged")
    else
        KLog("xmltv", "server says this guide is " + declared.toStr() + " bytes, inside the " + MAXGUIDEBYTES().toStr() + " byte cap")
    end if

    ' ---- 2. bounded download --------------------------------------------
    dl = fetchGuideToCache(url)
    path = ToStr(GetField(dl, "path"))
    if GetField(dl, "ok") <> true
        ' Every failure leaves the cache clean. cachefs is RAM on most
        ' Rokus, so an abandoned part-file is real memory held for nothing.
        deleteQuietly(path)
        m.top.result = { ok: false, error: ToStr(GetField(dl, "error")) }
        return
    end if

    res = scanGuideFile(path, ToInt(GetField(dl, "size")))
    deleteQuietly(path)
    m.top.result = res
end sub

' ---- The download ----------------------------------------------------------

' How big does the server SAY the guide is?
'
' Returns -1 for "wouldn't tell us", which is the common answer: an Xtream
' panel builds xmltv.php on the fly and sends it chunked, with no
' Content-Length at all, and some panels refuse HEAD outright. -1 is not a
' failure — it just means the cap has to be enforced during the download
' instead, which it is either way.
'
' NOTE the missing enableEncodings() here, which is on purpose. Without it
' Roku sends no Accept-Encoding, so the server has no reason to quote a
' gzipped length and the number that comes back is the size of the file we
' would actually have to hold. If a server gzips anyway the number is the
' compressed size — smaller than the real thing — so acting on it only ever
' rejects guides that were definitely too big. It can never wave one
' through that shouldn't be.
function declaredGuideBytes(url as string) as integer
    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.addHeader("User-Agent", KwickUserAgent())
    xfer.setUrl(url)

    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)
    if not xfer.asyncHead() then return -1

    ' roUrlEvent carries a "transfer started" event (getInt() = 2) as well as
    ' the completion one (1). Reading the started event as the answer would
    ' hand back no headers at all, so wait past it.
    deadline = nowSeconds() + Int(GUIDEHEADMS() / 1000) + 1
    while true
        msg = wait(GUIDEHEADMS(), port)
        if type(msg) <> "roUrlEvent"
            xfer.asyncCancel()
            return -1
        end if
        if msg.getInt() <> 2 then exit while
        if nowSeconds() > deadline
            xfer.asyncCancel()
            return -1
        end if
    end while

    code = msg.getResponseCode()
    if code < 200 or code >= 300 then return -1
    return headerBytes(msg.getResponseHeaders())
end function

' Content-Length out of a response header set, or -1 if it isn't there.
' Header names aren't case-normalised by anything we can rely on, so match
' them folded.
function headerBytes(hdrs as object) as integer
    if hdrs = invalid then return -1
    if type(hdrs) <> "roAssociativeArray" then return -1
    for each k in hdrs
        if LCase(ToStr(k)) = "content-length"
            n = ToInt(hdrs[k])
            if n > 0 then return n
            return -1
        end if
    end for
    return -1
end function

' Download the guide to cachefs, refusing to let it get bigger than the cap.
'
' WHY cachefs AND NOT tmp:. Both are RAM-backed on a standard Roku, but
' Roku's own file system notes are explicit that tmp: "increases app's
' memory usage" while cachefs "does not count towards app's total memory
' usage". Writing 24 MB to tmp: would be the same bug in a different shape.
' cachefs can be evicted by the OS under pressure, which is fine and is
' handled: a guide that vanishes mid-read fails the same graceful way a
' guide that was too big does.
'
' WHY THE SIZE IS POLLED RATHER THAN OBSERVED. Roku gives an app no progress
' callback and no byte ceiling on a transfer — verified against the OS 15.3
' ifUrlTransfer reference, which has no such method. What it does have is
' asyncGetToFile() writing the body to disk as it arrives (that is what
' enableResume() resumes) and asyncCancel() to stop it. So the loop waits on
' the message port in short ticks and stats the part-file between them. If
' the ticks never see the file grow on some firmware, nothing is lost: the
' stat after the transfer completes catches it, and the bytes were never in
' the app's memory to begin with.
'
' The size being measured is the DECOMPRESSED size, which is the one that
' matters — enableEncodings() has curl inflate transport gzip before the
' bytes are written, so what the file holds is what the scan would have to
' read.
function fetchGuideToCache(url as string) as object
    fs = CreateObject("roFileSystem")
    sweepOldGuides(fs)

    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.enableEncodings(true)
    xfer.addHeader("User-Agent", KwickUserAgent())
    xfer.setUrl(url)
    ' DELIBERATELY NO setMinimumTransferRate() here. It looks like the right
    ' way to drop a dead transfer, but a panel generating xmltv.php sends
    ' nothing at all for thirty or forty seconds while it builds the file,
    ' and a rate floor can't tell that apart from a hang. The loop below
    ' has its own deadline, which we can see in the logs and can reason
    ' about; the firmware's cannot.

    ' getIdentity() is unique per roUrlTransfer object, so two guide fetches
    ' running at once (the settings screen's guide check can overlap Live
    ' TV's background one) never write to the same file.
    path = GUIDECACHEPREFIX() + xfer.getIdentity().toStr() + ".xml"
    ' Kept on the task's own scope purely so the guard at the top of this file
    ' knows which cachefs file to clear up if a fault happens before
    ' run_xmltv_inner reaches its own deleteQuietly. Nothing reads it but the
    ' guard, and no behaviour here depends on it.
    m.guidePath = path
    if fs.Exists(path) then fs.Delete(path)

    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)
    if not xfer.asyncGetToFile(path)
        return { ok: false, error: "guide unreachable", path: "", size: 0 }
    end if

    cap = MAXGUIDEBYTES()
    giveUpAt = nowSeconds() + GUIDEMAXSECONDS()
    lastShownMb = -1
    code = 0
    while true
        msg = wait(GUIDEPOLLMS(), port)
        if type(msg) = "roUrlEvent"
            ' roUrlEvent carries a "transfer started" event (getInt() = 2) as
            ' well as the completion one. Treating the started event as the
            ' end would hand back an empty file, so only the other one ends
            ' the loop. Where a firmware sends response headers with the
            ' started event, that is the earliest the real length is known.
            if msg.getInt() <> 2
                code = msg.getResponseCode()
                exit while
            end if
            early = headerBytes(msg.getResponseHeaders())
            if early > cap
                xfer.asyncCancel()
                KLog("xmltv", "guide too large: headers say " + early.toStr() + " bytes, stopped before reading the body")
                return { ok: false, error: "guide too large for this device", path: path, size: 0 }
            end if
        end if

        ' The guards run every time round, whether that was a tick or an
        ' event, so a firmware that chatters events can't starve them.
        '
        ' >>> AND THIS SIZE GUARD DOES NOT WORK. MEASURED 2026-10-02, DO NOT
        '     TRUST IT AND DO NOT COUNT IT AS PROTECTION. <<<
        '
        ' sofar is 0 for the whole of the transfer, because Roku does not put
        ' the part-file where roFileSystem can see it -- the file appears at
        ' its full size, at the end, and not before. Three member logs prove
        ' it outright, because the MemoryTight() branch below prints the same
        ' sofar and printed "0 bytes" in all three:
        '
        '   8ff06fe2aa, an onn 100058007-CA, 2026-09-29: the download started
        '     at 01:36:06 and this loop stopped it at 01:36:23 reporting
        '     0 bytes -- SEVENTEEN SECONDS and sixty-eight ticks in, on a
        '     transfer that was eating the box's memory hard enough to set
        '     the low-memory flag.
        '   f8bb1b6b52ff (Streaming Stick 3800X) and s223i41tn7 (TCL 55S433)
        '     did exactly the same thing on their own sets.
        '
        ' And on 8f58p8lu28 (TCL 43S433) the line below DID print once -- at
        ' 72,886,364 bytes, which is the whole file. That is not this guard
        ' working; it is the tick landing in the gap between the file being
        ' finished and the completion event being read. Same backstop, later
        ' line number.
        '
        ' So a guide the app is going to refuse is downloaded IN FULL first,
        ' every time: 40 MB to 93 MB across the archive, 3 to 30 seconds of
        ' it. For member 164CD8 (onn 100012589) "guide too large: 65460902
        ' bytes" is the LAST LINE IN THE LOG before Roku killed the set.
        '
        ' WHY IT IS STILL HERE. It costs one stat per quarter second, it
        ' cannot do harm, and it starts working for nothing the day Roku
        ' exposes a part-file. What it must not do is be read as a reason to
        ' relax anything else. The real bound is the HEAD above, and when a
        ' panel will not answer that there is NOTHING in the Roku API that
        ' bounds the transfer -- see the note at the top of this file.
        sofar = fileBytes(fs, path)
        if sofar > cap
            xfer.asyncCancel()
            KLog("xmltv", "guide too large: passed the " + cap.toStr() + " byte cap at " + sofar.toStr() + " bytes, download stopped")
            return { ok: false, error: "guide too large for this device", path: path, size: sofar }
        end if
        ' The same safety net the scan below has, applied to the download.
        ' cachefs bytes don't count against the app, but they are still RAM
        ' on the device, and a box that goes short while this is landing is a
        ' box that will not survive the parse.
        if MemoryTight()
            xfer.asyncCancel()
            KLog("xmltv", "stopping the download at " + sofar.toStr() + " bytes - device memory is running out")
            return { ok: false, error: "guide too large for this device", path: path, size: sofar }
        end if
        if nowSeconds() > giveUpAt
            xfer.asyncCancel()
            KLog("xmltv", "guide download gave up after " + GUIDEMAXSECONDS().toStr() + "s with " + sofar.toStr() + " bytes")
            return { ok: false, error: "guide unreachable", path: path, size: sofar }
        end if
        mb = Int(sofar / 1048576)
        if mb <> lastShownMb
            lastShownMb = mb
            m.top.progress = "Downloading the guide… " + mb.toStr() + " MB"
        end if
    end while

    if code < 200 or code >= 300
        ' The reason matters here in a way it didn't before: getToString()
        ' just handed back "" and every failure looked the same. A cachefs
        ' write that couldn't finish shows up here rather than as a silently
        ' short guide.
        KLog("xmltv", "guide fetch failed: HTTP " + code.toStr() + " (" + ToStr(xfer.getFailureReason()) + ")")
        return { ok: false, error: "guide unreachable", path: path, size: 0 }
    end if

    size = fileBytes(fs, path)
    if size = 0
        return { ok: false, error: "guide unreachable", path: path, size: 0 }
    end if
    ' THE BACKSTOP, and the one check that cannot be dodged. Same ">" against
    ' the same number the old string-length test used, just made against a
    ' file that is sitting outside the app's memory instead of inside it.
    if size > cap
        KLog("xmltv", "guide too large: " + size.toStr() + " bytes")
        return { ok: false, error: "guide too large for this device", path: path, size: size }
    end if
    KLog("xmltv", "guide downloaded: " + size.toStr() + " bytes to " + path)
    return { ok: true, error: "", path: path, size: size }
end function

' Size of a file, 0 if it isn't there. Safe to call on one still being
' written.
function fileBytes(fs as object, path as string) as integer
    if path = "" then return 0
    if not fs.Exists(path) then return 0
    st = fs.Stat(path)
    if st = invalid then return 0
    return ToInt(GetField(st, "size"))
end function

sub deleteQuietly(path as string)
    if path = "" then return
    fs = CreateObject("roFileSystem")
    if fs.Exists(path) then fs.Delete(path)
end sub

' Clear out guide files an earlier run left behind — the app being killed
' mid-download leaves one, and on a RAM-backed cachefs that is memory held
' for nothing.
'
' ONLY OLD ONES. Two guide fetches can legitimately be in the air at the
' same time, and deleting a file another task is still writing would break
' it. Anything younger than the overall download deadline is left alone, and
' where the firmware doesn't report a modification time nothing is deleted
' at all.
sub sweepOldGuides(fs as object)
    lst = fs.GetDirectoryListing("cachefs:/")
    if lst = invalid then return
    cutoff = nowSeconds() - (GUIDEMAXSECONDS() * 2)
    for each nm in lst
        n = ToStr(nm)
        if n.len() > 12 and n.left(12) = "kwick_xmltv_"
            full = "cachefs:/" + n
            ' Stat's "mtime" is a DATE OBJECT, not a number of seconds —
            ' running it through ToInt() gives 0, which would read as "older
            ' than anything" and delete the file another task is writing
            ' right now. Anything we can't read a real time out of is left
            ' exactly where it is.
            mts = 0
            st = fs.Stat(full)
            if st <> invalid
                mt = st["mtime"]
                if type(mt) = "roDateTime"
                    mts = mt.asSeconds()
                else
                    mts = ToInt(mt)
                end if
            end if
            if mts > 0 and mts < cutoff then fs.Delete(full)
        end if
    end for
end sub

' ---- Reading it back -------------------------------------------------------

' One piece of the guide file as text, cut so it never ends halfway through a
' character.
'
' Returns { text, bytes }, where `bytes` is how much of the file was actually
' consumed — which can be a little less than asked for, see utf8Tail below —
' or invalid if the read failed. A failed read is not a theoretical case:
' cachefs can be evicted by the OS while we are working through it.
function readGuidePiece(path as string, offset as integer, take as integer) as object
    ba = CreateObject("roByteArray")
    if not ba.readFile(path, offset, take) then return invalid
    n = ba.count()
    if n <= 0 then return invalid
    keep = n - utf8Tail(ba, n)
    if keep <= 0 then keep = n
    if keep < n
        ' A fresh array rather than re-reading over the old one, so this
        ' can't depend on whether readFile replaces or appends.
        trimmed = CreateObject("roByteArray")
        if not trimmed.readFile(path, offset, keep) then return invalid
        return { text: trimmed.toAsciiString(), bytes: keep }
    end if
    return { text: ba.toAsciiString(), bytes: keep }
end function

' How many bytes at the end of this block belong to a character that isn't
' finished yet.
'
' Chopping a file into fixed-size pieces lands in the middle of an accented
' letter sooner or later — guides are full of them. Handing those loose bytes
' to toAsciiString() turns them into rubbish, and rubbish inside a
' <programme> can make the whole element fail to parse, silently losing a
' listing. Cutting just before the character instead means the next piece
' picks it up whole. UTF-8 characters are at most 4 bytes, so this never
' looks back further than that.
function utf8Tail(ba as object, n as integer) as integer
    i = n - 1
    steps = 0
    while i >= 0 and steps < 4
        b = ba[i]
        if b < 128 then return 0            ' plain ASCII: nothing is pending
        if b >= 192                          ' the first byte of a character
            need = 2
            if b >= 240
                need = 4
            else if b >= 224
                need = 3
            end if
            have = n - i
            if have < need then return have
            return 0
        end if
        i = i - 1                            ' a continuation byte; keep looking
        steps = steps + 1
    end while
    return 0
end function

' Read the downloaded guide and build the result the three screens consume.
' Same output as before, built without ever holding the file.
function scanGuideFile(path as string, fileBytesTotal as integer) as object
    totalBytes = fileBytesTotal
    if totalBytes < 1 then totalBytes = 1

    ' ---- the <channel> head ---------------------------------------------
    ' Build the callsign/name index from the file's <channel> declarations,
    ' so channels whose ids don't line up can still be matched. They sit
    ' ahead of the first programme in every XMLTV worth the name, and there
    ' are only ever a few hundred, so this reads just that head section.
    m.top.progress = "Reading the channel list…"
    claims = {}
    headFound = false
    offset = 0
    carry = ""
    while offset < totalBytes
        take = GUIDECHUNKBYTES()
        if offset + take > totalBytes then take = totalBytes - offset
        piece = readGuidePiece(path, offset, take)
        if piece = invalid then return guideVanished("reading the channel list")
        if piece.bytes <= 0 then return guideVanished("reading the channel list")
        offset = offset + piece.bytes
        chunk = carry + piece.text

        ' The head is everything before the FIRST <programme>, exactly as it
        ' was when the whole file was one string.
        pAt = chunk.instr(0, "<programme")
        if pAt > -1
            lastUsed = claimChannelsIn(claims, chunk.left(pAt))
            headFound = true
            exit while
        end if

        used = claimChannelsIn(claims, chunk)
        carry = carryTail(chunk, used, "<channel")
    end while

    if not headFound
        ' No <programme> anywhere in the file — the same verdict the old
        ' whole-string check gave.
        return { ok: false, error: "guide XML didn't parse" }
    end if
    aliases = finishAliases(claims)

    ' An EMPTY wanted list means "keep everything". A playlist knows all its
    ' tvg-ids up front, but an Xtream source's channels arrive category by
    ' category as you browse, so there's no list to filter by when the guide
    ' is first fetched — the match happens at render time instead.
    wanted = {}
    haveWanted = false
    wl = ParseJson(m.top.wantedJson)
    if wl <> invalid
        for each w in wl
            wanted[ToStr(w)] = true
            haveWanted = true
        end for
    end if

    ' Narrower than it was (-3h/+36h). The guide grid only ever draws a 12
    ' hour window from the previous half hour, so a day and a half of
    ' listings was being held to draw half a day of them — and holding it is
    ' what got the app killed on small devices.
    '
    ' Bounding the download did NOT change this number and shouldn't: what
    ' the window costs now is entirely the listings it keeps, and those are
    ' already capped by MAXKEPTPROGRAMMES(). Widening it would fill that cap
    ' sooner rather than show more, so later channels in the file would go
    ' blank instead. Written up in the report.
    now = CreateObject("roDateTime").asSeconds()
    winStart = now - 3600
    winEnd = now + 18 * 3600

    byId = {}
    kept = 0
    inWindow = 0
    matched = 0
    capped = false
    ' WINDOWED SCAN, and it has to be. Walking the whole file with
    ' body.instr(<position>, ...) looks like the obvious way to do this and is
    ' quadratic on Roku: each call re-scans from the given offset, so a 20 MB
    ' guide with ~100k programmes never finishes — it sat at "Checking your
    ' guide" for ten minutes on the test box before this was rewritten.
    '
    ' Instead the file is walked once in fixed windows, now read straight off
    ' cachefs a piece at a time rather than sliced out of a string that had
    ' to be held whole. Whatever is left after the last complete element is
    ' carried into the next piece, so an element straddling a boundary is
    ' still read whole. Linear, and peak memory is one window plus the
    ' listings kept — the file itself is never in the app at all.
    lastPct = -1
    m.top.progress = "Reading the guide… 0%"

    offset = 0
    carry = ""
    while offset < totalBytes
        take = GUIDECHUNKBYTES()
        if offset + take > totalBytes then take = totalBytes - offset
        piece = readGuidePiece(path, offset, take)
        if piece = invalid then return guideVanished("reading the guide")
        if piece.bytes <= 0 then return guideVanished("reading the guide")
        offset = offset + piece.bytes
        chunk = carry + piece.text

        at = 0
        while true
            s = chunk.instr(at, "<programme")
            if s < 0 then exit while
            e = chunk.instr(s, "</programme>")
            if e < 0 then exit while          ' incomplete — finish it next window
            blockEnd = e + 12                 ' len("</programme>")
            p = CreateObject("roXMLElement")
            if p.parse(chunk.mid(s, blockEnd - s))
                chId = ToStr(p@channel)
                startS = xmltvTime(ToStr(p@start))
                stopS = xmltvTime(ToStr(p@stop))
                if stopS > winStart and startS < winEnd and startS > 0
                    inWindow = inWindow + 1
                    isWanted = (not haveWanted) or wanted.doesExist(chId)
                    if haveWanted and wanted.doesExist(chId) then matched = matched + 1
                    ' Keeping every programme of a big unfiltered guide would
                    ' run the box out of memory, so there's a ceiling on how
                    ' many are held. Reported, not silent.
                    if isWanted and kept >= MAXKEPTPROGRAMMES()
                        capped = true
                    else if isWanted
                        if not byId.doesExist(chId) then byId[chId] = []
                        title = ""
                        tEl = p.GetNamedElements("title")
                        if tEl.count() > 0 then title = tEl[0].GetText()
                        desc = ""
                        dEl = p.GetNamedElements("desc")
                        if dEl.count() > 0 then desc = dEl[0].GetText()
                        byId[chId].push({ title: title, desc: desc, startS: startS, stopS: stopS })
                        kept = kept + 1
                    end if
                end if
            end if
            at = blockEnd
        end while

        ' Carry the tail from the last unconsumed opening tag, so a programme
        ' split across the boundary is read whole next time round.
        carry = carryTail(chunk, at, "<programme")

        ' Divide FIRST. "offset * 100" overflows a 32-bit integer somewhere
        ' past 21 MB and the percentage goes negative — the old code did that
        ' and the progress line counted backwards on the biggest guides.
        pct = Int((offset / totalBytes) * 100)
        if pct <> lastPct
            lastPct = pct
            m.top.progress = "Reading the guide… " + pct.toStr() + "%"
            ' THE SAFETY NET. Roku kills an app that goes over its memory
            ' allowance — EXIT_CHANNEL_MEM_LIMIT_FG, no warning, straight to
            ' the home screen — and that is exactly what a big guide did to
            ' members on smaller sets. Watching the level as we go means the
            ' app can give up on the guide and say so, instead of being shot.
            ' Checked once per percent, not per element: it isn't free.
            if MemoryTight()
                KLog("xmltv", "stopping at " + pct.toStr() + "% - device memory is running out")
                return { ok: false, error: "guide too large for this device" }
            end if
        end if
    end while
    msg = "parsed guide: " + kept.toStr() + " programmes for " + byId.count().toStr() + " channels"
    if haveWanted then msg = msg + " (" + matched.toStr() + " matched of " + inWindow.toStr() + " in window)"
    if capped then msg = msg + " — CAPPED at " + MAXKEPTPROGRAMMES().toStr()
    KLog("xmltv", msg)
    ' matched/inWindow drive the settings screen's "did this guide work?"
    ' answer. A guide for a different provider parses perfectly and matches
    ' nothing, so the file's own size proves nothing.
    return { ok: true, byId: byId, aliases: aliases, matched: matched, inWindow: inWindow, channels: byId.count(), capped: capped }
end function

' What to carry into the next window: everything from the last unconsumed
' opening tag onwards.
'
' When there ISN'T one, only the last GUIDEEDGEKEEP() bytes are kept — enough
' that an opening tag split across the boundary is still found whole next
' time round, and nothing else. Carrying the whole window instead (which is
' what the old code did whenever a window held no tags, i.e. all the way
' through the channel head) quietly rebuilt the very string this rewrite
' exists to avoid holding.
function carryTail(chunk as string, consumed as integer, opener as string) as string
    keepFrom = consumed
    nxt = chunk.instr(consumed, opener)
    if nxt > -1
        keepFrom = nxt
    else
        edge = chunk.len() - GUIDEEDGEKEEP()
        if edge > keepFrom then keepFrom = edge
    end if
    if keepFrom >= chunk.len() then return ""
    return chunk.mid(keepFrom, chunk.len() - keepFrom)
end function

' The cache file went away underneath us. cachefs is memory the OS is free to
' reclaim, so this means the device ran short — which is the same thing the
' member needs to be told as a guide that was too big, and it lands on the
' same "failed" path every other refusal here does.
function guideVanished(during as string) as object
    KLog("xmltv", "the cached guide became unreadable while " + during + " - the device reclaimed it")
    return { ok: false, error: "guide too large for this device" }
end function

' ---- Aliases ---------------------------------------------------------------

' alias -> guide channel id, from the file's <channel> declarations.
'
' An alias claimed by two different guide channels is dropped rather than
' guessed at: a wrong programme against a channel is worse than a blank one.
' Callsign aliases are only taken from the PRIMARY subchannel (the one whose
' display-name is "4.1" rather than "4.2"), because a provider carrying one
' "CBS 4 WBZ" channel means the main feed, not one of its sub-feeds.
'
' Fed one window of the head at a time, the same way the programmes are, so
' the head never has to be held whole either. Returns how much of `head` it
' consumed; the rest is carried into the next window.
function claimChannelsIn(claims as object, head as string) as integer
    at = 0
    while true
        s = head.instr(at, "<channel")
        if s < 0 then exit while
        e = head.instr(s, "</channel>")
        if e < 0 then exit while
        at = e + 10

        el = CreateObject("roXMLElement")
        if el.parse(head.mid(s, at - s))
            gid = ToStr(el@id)
            if gid <> ""
                names = []
                for each n in el.GetNamedElements("display-name")
                    names.push(n.GetText())
                end for
                ' Is this the primary subchannel? One of its names will be
                ' the bare "N.1".
                primary = false
                for each n in names
                    t = n.trim()
                    if t.len() >= 3 and t.right(2) = ".1" then primary = true
                end for
                for each n in names
                    full = EpgNormName(n)
                    if full.len() >= 4 then claimAlias(claims, full, gid)
                    if primary
                        cs = EpgCallsign(n)
                        if cs <> "" then claimAlias(claims, cs, gid)
                    end if
                end for
            end if
        end if
    end while
    return at
end function

' Turn the claims into the alias map, dropping the contested ones.
function finishAliases(claims as object) as object
    out = {}
    contested = 0
    for each k in claims
        if ToStr(claims[k]) = "?"
            contested = contested + 1
        else
            out[k] = claims[k]
        end if
    end for
    KLog("xmltv", "channel index: " + out.count().toStr() + " usable alias(es), " + contested.toStr() + " dropped as ambiguous")
    return out
end function

sub claimAlias(claims as object, alias as string, gid as string)
    if not claims.doesExist(alias)
        claims[alias] = gid
    else if ToStr(claims[alias]) <> gid
        claims[alias] = "?"
    end if
end sub

' Does the server offer this guide uncompressed at the same address?
'
' A HEAD, not a GET: the answer is only ever "is it there", and these files run
' to tens of megabytes. Short leash - a provider that will not answer a HEAD
' quickly is not worth stalling the guide chain for, and the caller falls back
' to the same "not supported" it would have given anyway.
function plainGuideExists(url as string) as boolean
    xfer = CreateObject("roUrlTransfer")
    xfer.setUrl(url)
    xfer.setRequest("HEAD")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.addHeader("User-Agent", KwickUserAgent())
    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)
    if not xfer.asyncHead() then return false
    msg = wait(8000, port)
    if type(msg) <> "roUrlEvent"
        xfer.asyncCancel()
        return false
    end if
    code = msg.getResponseCode()
    return code >= 200 and code < 300
end function

' ---- Limits ----------------------------------------------------------------

' Is the device running short of memory right now?
'
' The only figure Roku will give an app is a coarse level, not a limit or a
' usage number — GetGeneralMemoryLevel returns "normal", "low" or "critical".
' Coarse is fine for this: all we need to know is whether carrying on is
' about to get us killed.
function MemoryTight() as boolean
    lvl = LCase(ToStr(CreateObject("roDeviceInfo").GetGeneralMemoryLevel()))
    return lvl = "low" or lvl = "critical"
end function

' The most a guide file is allowed to be.
'
' HISTORY, because this number has now been wrong in both directions. It was
' 15 MB because the old parser built a tree of the whole document. Dropping
' that let it go to 48 MB — and 48 MB promptly got the app killed with
' EXIT_CHANNEL_MEM_LIMIT_FG, over and over, on a TCL 32S331. The dev box is a
' roomier model and never showed it.
'
' 24 MB covers the real guides people have sent in so far with a lot more
' head room than 48 did, and it is deliberately not "as big as we can get
' away with": the cheap 720p sets are the ones that fall over, and they're
' common.
'
' The sentence that used to sit here — "the file is still held as one string
' while it's scanned, so the download size IS the floor on memory" — is no
' longer true. The file lives on cachefs and is read a piece at a time, so
' the app's floor is one 256 KB piece. The number is unchanged anyway: it is
' now a ceiling on how much of the device's memory this app is willing to
' park in the cache, and on how long a member waits, rather than a ceiling on
' the app's own footprint. Raising it is a separate decision with separate
' evidence behind it, and nobody has gathered that yet.
function MAXGUIDEBYTES() as integer
    return 24000000   ' 24 MB
end function

' How many programmes are held once parsed. Was 40000, which on a small set
' is tens of megabytes of associative arrays on top of the file itself.
function MAXKEPTPROGRAMMES() as integer
    return 12000
end function

' How much of the file is read at a time. Big enough that a whole programme
' element always fits inside one piece with room to spare; small enough that
' holding one costs nothing worth counting.
function GUIDECHUNKBYTES() as integer
    return 262144   ' 256 KB
end function

' How much of the end of a window is carried forward when it holds no tag at
' all. It only has to beat the longest thing either scan searches for —
' "<programme" is ten bytes — so that a tag split across the boundary is
' still whole on the next pass. Sixteen, with room to spare.
function GUIDEEDGEKEEP() as integer
    return 16
end function

function GUIDECACHEPREFIX() as string
    return "cachefs:/kwick_xmltv_"
end function

' How often the download loop wakes up to check the part-file's size. Fast
' enough that the overshoot past the cap is small even on a quick
' connection, slow enough that the checks themselves cost nothing.
function GUIDEPOLLMS() as integer
    return 250
end function

' How long to wait for the HEAD that asks the size. Short: it is an optional
' optimisation, and the download's own cap works without it.
function GUIDEHEADMS() as integer
    return 8000
end function

' The longest the whole download may take. There was no limit at all before —
' a getToString() against a server that accepted the connection and then went
' quiet would sit there forever with the dialog up. 300 seconds is roughly
' 80 KB/s across a full 24 MB, well under anything that can stream video, and
' it leaves room for a panel that spends half a minute building the file
' before it sends a byte.
function GUIDEMAXSECONDS() as integer
    return 300
end function

function nowSeconds() as integer
    return CreateObject("roDateTime").asSeconds()
end function

' "20260720123000 +0000" (or without offset) -> epoch seconds.
function xmltvTime(s as string) as integer
    t = s.trim()
    if t.len() < 14 then return 0
    dt = CreateObject("roDateTime")
    iso = t.left(4) + "-" + t.mid(4, 2) + "-" + t.mid(6, 2) + "T" + t.mid(8, 2) + ":" + t.mid(10, 2) + ":" + t.mid(12, 2) + "Z"
    dt.fromISO8601String(iso)
    secs = dt.asSeconds()
    if secs = 0 then return 0
    ' Apply the timezone offset if present ("+0130" / "-0500").
    if t.len() >= 19
        offRaw = t.mid(15)
        sign = offRaw.left(1)
        if sign = "+" or sign = "-"
            oh = ToInt(offRaw.mid(1, 2))
            om = ToInt(offRaw.mid(3, 2))
            off = oh * 3600 + om * 60
            if sign = "+" then secs = secs - off else secs = secs + off
        end if
    end if
    return secs
end function
