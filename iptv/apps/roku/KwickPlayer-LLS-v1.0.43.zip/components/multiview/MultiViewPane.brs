' One Multi-View cell. See the note at the top of MultiViewPane.xml for what
' this is and why the no-artwork case is a design rather than a fallback.
'
' Everything sizes itself off cellW/cellH rather than off fixed numbers,
' because the same component is drawn at four sizes: 960x540 (two or four
' panes), 896x504 (three panes, with the add strip reserved), 1920x1080
' (expanded), and whatever the cover happens to need.

sub init()
    m.theme = KwickTheme()
    m.card = m.top.findNode("card")
    m.card.color = m.theme.surface
    m.monoBox = m.top.findNode("monoBox")
    m.monoBox.color = m.theme.surfaceElevated
    m.mono = m.top.findNode("mono")
    m.mono.color = m.theme.accent
    m.logo = m.top.findNode("logo")
    m.name = m.top.findNode("name")
    m.name.color = m.theme.textPrimary
    m.nowLabel = m.top.findNode("nowLabel")
    m.nowLabel.color = m.theme.textSecondary
    m.status = m.top.findNode("status")
    m.status.color = m.theme.textSecondary
    m.spin = m.top.findNode("spin")
    m.spin.poster.uri = "pkg:/images/spinner.png"

    m.slot = invalid
    m.laidOut = 0
    layout()
end sub

sub onSize()
    layout()
    onSlot()
end sub

' Font nodes are rebuilt here rather than in init because the same component
' is drawn at wildly different sizes and a 30px name on a full-screen pane
' looks like a bug. Cheap: this runs when the grid changes shape, not per
' frame.
sub layout()
    w = m.top.cellW
    h = m.top.cellH
    if w < 80 or h < 60 then return
    key = w * 10000 + h
    if m.laidOut = key then return
    m.laidOut = key

    m.card.width = w
    m.card.height = h

    ' The artwork box: a third of the cell's height, centred, sitting in the
    ' upper half so the name and the programme line have room under it.
    artH = Int(h * 0.34)
    artW = Int(artH * 16 / 9)
    if artW > Int(w * 0.6)
        artW = Int(w * 0.6)
        artH = Int(artW * 9 / 16)
    end if
    artY = Int(h * 0.14)
    m.logo.width = artW
    m.logo.height = artH
    ' Decode to the drawn box, not to whatever the provider uploaded.
    m.logo.loadWidth = artW
    m.logo.loadHeight = artH
    m.logo.translation = [Int((w - artW) / 2), artY]

    monoSide = Int(h * 0.30)
    m.monoBox.width = monoSide
    m.monoBox.height = monoSide
    m.monoBox.translation = [Int((w - monoSide) / 2), artY + Int((artH - monoSide) / 2)]
    m.mono.width = monoSide
    m.mono.height = monoSide
    m.mono.translation = m.monoBox.translation
    ' The monogram divisor is UNCHANGED. It is at most two CAPITALS
    ' (MvInitials returns two and stops), and capitals are the one place mono
    ' is not the wider face: two caps take 0.53 of the box in JetBrains Mono
    ' against roughly 0.57 in Roboto-Medium. It got narrower, not wider.
    m.mono.font = UiBoldFont(clampSize(Int(monoSide * 0.44), 22, 96))

    ' THE DIVISORS BELOW WERE 17 AND 24, AND THEY MOVED FOR THE SHELL TYPE.
    ' JetBrains Mono is a flat 0.6em against Roboto-Medium's ~0.5em average
    ' (Theme.brs:317-330), so the same divisor would fit ~17% fewer
    ' characters in boxes that are already sized off the cell. Dividing by
    ' 20 and 29 instead — 17/0.833 and 24/0.833 — puts the same number of
    ' characters per line as before at every one of the four cell sizes this
    ' component is drawn at, so nothing clips that did not clip before. The
    ' clamps moved by the same ratio.
    nameY = artY + artH + Int(h * 0.06)
    nameSize = clampSize(Int(h / 20), 18, 38)
    m.name.font = UiBoldFont(nameSize)
    m.name.width = w - 48
    m.name.height = Int(nameSize * 2.4)
    m.name.translation = [24, nameY]

    subSize = clampSize(Int(h / 29), 15, 27)
    m.nowLabel.font = UiFont(subSize)
    m.nowLabel.width = w - 60
    m.nowLabel.translation = [30, nameY + m.name.height + 6]

    ' Same slot as the programme line; only ever one of the two is showing.
    m.status.font = UiFont(subSize)
    m.status.width = w - 80
    m.status.translation = [40, nameY + m.name.height + 6]

    m.spin.translation = [Int(w / 2) - 30, Int(h * 0.14) + Int(artH / 2) - 30]
end sub

function clampSize(v as integer, lo as integer, hi as integer) as integer
    if v < lo then return lo
    if v > hi then return hi
    return v
end function

sub onSlot()
    raw = m.top.slotJson
    if raw = ""
        ' An EMPTY pane: closed, but its space kept. The member arranged
        ' these; emptying one must not silently rearrange the other three.
        ' (Android's _EmptySlot, multi_view_screen.dart:766-802.)
        m.slot = invalid
        m.card.color = m.theme.background
        m.logo.visible = false
        m.logo.uri = ""
        m.monoBox.visible = false
        m.mono.visible = false
        m.name.text = "Empty"
        m.name.color = m.theme.textSecondary
        m.nowLabel.text = "Press OK to put something here"
        onState()
        return
    end if
    slot = ParseJson(raw)
    if slot = invalid then return
    m.slot = slot
    m.card.color = m.theme.surface
    m.name.color = m.theme.textPrimary
    m.name.text = ToStr(GetField(slot, "title"))

    logoUrl = ToStr(GetField(slot, "logo"))
    ' On a device that is already short of memory, four posters is exactly the
    ' kind of avoidable spend that ends in EXIT_CHANNEL_MEM_LIMIT_FG. The
    ' initials tile is a real design, not a degraded one, so going without
    ' costs the member almost nothing.
    if logoUrl <> "" and MvMemoryTight()
        KLog("multiview", "memory is tight - drawing initials instead of artwork")
        logoUrl = ""
    end if
    if logoUrl <> ""
        m.logo.uri = logoUrl
        m.logo.visible = true
        m.monoBox.visible = false
        m.mono.visible = false
    else
        m.logo.uri = ""
        m.logo.visible = false
        letters = MvInitials(ToStr(GetField(slot, "title")))
        m.mono.text = letters
        m.monoBox.visible = true
        m.mono.visible = (letters <> "")
    end if
    onNow()
    onState()
end sub

' The line under the name: what is on now if the guide knows, otherwise
' whatever tells this pane apart from the others ("Ch 101", "Film - 2019",
' "S01E03"). A live channel with no guide data shows nothing rather than a
' placeholder — there is genuinely nothing to say.
sub onNow()
    if m.slot = invalid then return
    now = m.top.nowText
    if now <> ""
        m.nowLabel.text = now
        return
    end if
    m.nowLabel.text = ToStr(GetField(m.slot, "subLine"))
end sub

sub onState()
    st = m.top.state
    txt = m.top.statusText
    m.status.visible = (txt <> "")
    m.status.text = txt
    ' The programme line steps aside for a status. They share the same space,
    ' and "Now: Match of the Day" is not what a member needs to read when the
    ' pane is telling them why it could not open.
    m.nowLabel.visible = (txt = "")
    if st = "error"
        m.status.color = m.theme.errorColor
    else
        m.status.color = m.theme.textSecondary
    end if
    busy = m.top.busy
    m.spin.visible = busy
    if busy
        m.spin.control = "start"
    else
        m.spin.control = "stop"
    end if
end sub
