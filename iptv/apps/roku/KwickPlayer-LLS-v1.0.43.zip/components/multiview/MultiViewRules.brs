' The decisions Multi-View makes that have nothing to do with nodes.
'
' Port of MultiViewRules in the Android app
' (lib/ui/screens/multiview/multi_view_screen.dart:150-212). Pulled out for
' the same reason it was pulled out there: these are exactly the parts that
' go quietly wrong — an index that no longer points where it did, a grid that
' sizes its cells to the wrong box — and none of it is visible until somebody
' is sitting in front of it watching.
'
' Everything here is prefixed Mv because BrightScript has ONE global function
' namespace across every .brs a component includes.
'
' The pure half (MvIndexAfterClose / MvLayout / MvPickerWindow / MvInitials)
' has a self-test at the bottom, mirroring GuideMetaSelfTest — Android has
' real unit tests for indexAfterClose and this is the nearest thing Roku has.
' The slot builders at the end are NOT pure: they need Util.brs and Store.brs
' in scope, so any component that includes this file must include those two.

' ---- Limits -----------------------------------------------------------------

' Beyond four, nothing on screen is big enough to watch. On Android this was
' also a bandwidth number (four HD streams is roughly 30 Mbps); here it is
' purely about screen real estate, because Roku decodes exactly one.
function MvMaxPanes() as integer
    return 4
end function

' Two is the smallest thing that is actually multi-view; one is just the
' player, and that already exists.
function MvMinPanes() as integer
    return 2
end function

' How long focus has to sit still on a pane before the video is re-pointed at
' it.
'
' THIS NUMBER IS THE WHOLE FEATURE. Roku allows one playing video instance per
' channel, so moving focus means tearing down a stream and opening another —
' measured at 330-450 ms against a warm CDN test stream, but real IPTV live
' streams use 4-6 second HLS chunks, so 2-5 seconds is the honest figure.
' Re-pointing on every keypress would therefore do two bad things at once: it
' would make the grid feel broken, and it would fire a burst of connection
' attempts at the provider — the exact pattern that got the owner's own IP
' banned (see the note above StreamErrorKind in Util.brs).
'
' 0.9 seconds, for three reasons:
'   · the grid is at most 2x2, so crossing it takes at most two presses, and
'     two deliberate presses land well inside 900 ms of each other — the
'     intermediate pane is never committed to;
'   · once the member has actually stopped, under a second of nothing feels
'     like the picture is on its way, not like the app missed the press;
'   · it is already this feature's house number. Android starts its panes 900
'     ms apart for the same reason (multi_view_screen.dart:298) — it is how
'     long the app has always waited between opening two streams.
'
' The dwell applies to focus DRIFT only. Pressing OK -> "Watch here", Refresh,
' Full screen, or filling a pane commits immediately: the member has said what
' they want and making them wait for a timer would be nonsense.
function MvDwellSeconds() as float
    return 0.9
end function

' ---- Where an index lands after a pane is REMOVED ---------------------------
'
' Byte-for-byte port of MultiViewRules.indexAfterClose
' (multi_view_screen.dart:180-192), the one piece of Multi-View with dedicated
' unit tests behind it.
'
' Removing a pane shifts every pane after it down one. On Android, leaving the
' sound index alone therefore moved the sound to a different stream than the
' one the member was listening to — silently, because both were playing. On
' Roku it is louder than that: the index says which pane the single decoder is
' drawn in, so getting it wrong puts the picture in the wrong box.
'
' Returns -1 when nothing is left.
function MvIndexAfterClose(count as integer, index as integer, closed as integer) as integer
    remaining = count - 1
    if remaining <= 0 then return -1
    if index = closed
        ' The pane being watched is the one going away. Stay at the same
        ' position (which is now a different pane) unless that position no
        ' longer exists, in which case fall back to the new last one.
        if index >= remaining then return remaining - 1
        return index
    end if
    moved = index
    if index > closed then moved = index - 1
    if moved < 0 then moved = 0
    if moved > remaining - 1 then moved = remaining - 1
    return moved
end function

' ---- How the panes are arranged ---------------------------------------------
'
' Port of MultiViewRules.layout (multi_view_screen.dart:196-212). 16:9 cells,
' sized to fit BOTH the width and the height of the box they are given, so the
' bottom row never runs off the screen.
'
' Called with a height that has ALREADY had the "add another pane" strip taken
' out of it, for the same reason Android reserves it before sizing: adding the
' strip afterwards pushes the bottom row off screen.
function MvLayout(panes as integer, width as integer, height as integer) as object
    if panes < 1 then panes = 1
    wide = (width >= height)
    if panes <= 1
        columns = 1
    else if panes = 2
        if wide then columns = 2 else columns = 1
    else
        columns = 2
    end if
    rows = Int((panes + columns - 1) / columns)
    w = Int(width / columns)
    h = Int(w * 9 / 16)
    if h * rows > height
        h = Int(height / rows)
        w = Int(h * 16 / 9)
    end if
    return { columns: columns, rows: rows, cellW: w, cellH: h }
end function

' ---- The window the picker shows, when two lists compete for it -------------
'
' Port of pickerWindow (multi_view_picker_screen.dart:479-482 and the comment
' above it). The lists in the picker are WINDOWS, not libraries — sixty rows,
' because a remote cannot scroll four thousand and the member is expected to
' type into the search box directly above.
'
' Appending one list to the other and taking the first sixty is what a member
' with a big panel would experience as "my own playlist is not in here at
' all": the panel fills the window on its own and the second half never gets a
' row. So each side is guaranteed its half, and whichever side has room to
' spare gives it to the other.
'
' On Roku the two halves are the Xtream panels and the M3U playlists, which is
' the same shape of problem Android had between a panel and a media server.
' Films and Series have no second half here, so they pass an empty list and
' get the plain first-sixty behaviour through the same one code path.
function MvPickerWindow(first as object, second as object, limit as integer) as object
    out = []
    if limit <= 0 then return out
    a = first.count()
    b = second.count()
    if a + b > limit
        half = Int(limit / 2)
        if a > half and b > limit - half
            a = half
            b = limit - half
        else if a > half
            a = limit - b
        else
            b = limit - a
        end if
    end if
    for i = 0 to a - 1
        out.push(first[i])
    end for
    for i = 0 to b - 1
        out.push(second[i])
    end for
    return out
end function

' ---- The no-artwork tile ----------------------------------------------------
'
' Every channel has exactly ONE possible picture — stream_icon on Xtream,
' tvg-logo on an M3U — and it is allowed to be missing, with nothing anywhere
' to fill it in from. Plenty of channels simply have none, so a pane with no
' artwork is an ordinary state and has to look like one rather than like a
' tile that failed to load.
'
' What it gets instead is its initials, drawn large. Letters and digits only,
' from the first two words that have any: "BBC One" -> "BO", "Sky Sports Main
' Event" -> "SS", "4seven" -> "4". Empty for a nameless channel, which the
' pane draws as a plain card.
function MvInitials(name as string) as string
    up = UCase(name)
    out = ""
    prevBlank = true
    for i = 0 to up.len() - 1
        c = up.mid(i, 1)
        isChar = ((c >= "A" and c <= "Z") or (c >= "0" and c <= "9"))
        if isChar
            if prevBlank
                out = out + c
                if out.len() >= 2 then return out
            end if
            prevBlank = false
        else
            prevBlank = true
        end if
    end for
    return out
end function

' ---- Memory -----------------------------------------------------------------
'
' The same coarse check XmltvTask uses (MemoryTight, XmltvTask.brs:264-267),
' copied rather than shared because that one lives inside a Task component's
' own script scope and there is nowhere shared to put it without editing
' Util.brs, which this job does not own. Behaviour is identical; if the two
' ever need to differ, that is a bug in one of them.
'
' Multi-View asks this before it loads a pane's artwork. On a device that is
' already short, four posters is exactly the kind of avoidable spend that
' turns into EXIT_CHANNEL_MEM_LIMIT_FG, and the initials tile is a real
' design rather than a degraded one — so going without costs the member very
' little.
function MvMemoryTight() as boolean
    lvl = LCase(ToStr(CreateObject("roDeviceInfo").GetGeneralMemoryLevel()))
    return lvl = "low" or lvl = "critical"
end function

' ---- Slots ------------------------------------------------------------------
'
' One thing that can go in one pane. Deliberately says nothing about where it
' came from, exactly like Android's MultiViewSlot: a pane is "something
' playable with a name on it", so Multi-View never grows a special case per
' section.
'
'   id        stable identity, so a tick in the picker and the pane it makes
'             cannot disagree about what a thing is
'   title     what the pane says
'   sub       "Ch 101" / "Film - 2019" / "S01E03", or "" — whatever helps tell
'             two panes apart
'   url       what the Video node opens. Live urls have ALREADY been through
'             LivePlayUrl(); Roku has no TS demuxer (Util.brs:228-235)
'   fmt       Roku streamFormat
'   isLive    changes the Video node's buffering policy, not just the badge
'   logo      the one possible picture, or ""
'   streamId  for the guide lookup
'   src       source token, so playback and the guide route to the channel's
'             OWN source rather than whichever is active
'   provId    provider id, for the hidden-channel check
'
' NOTE, and it is a deliberate omission: there is no startAt. Android carries
' one so that opening Multi-View forty minutes into a film does not start the
' film again — but every one of Android's entry points that can supply a
' position is a PLAYER, and this job is not allowed near the Roku player. Once
' a player entry point is added, this is where the field goes.

' THE SOURCE THAT CAN ACTUALLY BUILD A PANEL ADDRESS, or invalid.
'
' The three slot builders below need Xtream credentials to make a url. All
' three used to take whatever ProviderForSrcToken handed back and, failing
' that, whatever source happened to be active — and neither answer was ever
' checked for being a PANEL. That is the exact shape of LOG KEY FCF117.
'
' WHAT HAPPENED ON THE MEMBER'S TELEVISION (Hisense 6Series-58, v1.0.39,
' 29 September 2026), in plain words: they removed their source in Settings,
' a different one arrived on its own from the website a few seconds later, and
' the next channel they pressed Play on froze the television with the spinner
' still turning and nothing on screen to say why. The channel was left over
' from the source they had just removed, so the app fell back to the one that
' had just arrived — an ordinary playlist, which has no panel address to build
' a stream from. Nothing was written down wrong; the wrong KIND of source was
' handed to a panel-only builder.
'
' THE TEST IS POSITIVE — "is it one of the two kinds that can do this" — and
' deliberately not a list of kinds to exclude. HomeScreen.resumeOrNext spells
' out why: the exclusion list there was `<> "m3u"`, which quietly let a
' Jellyfin through and stopped the app dead on 2026-09-19. A source kind added
' later is refused by this test by default, which is the safe way round.
'
' A playlist is not a broken source here, just a different one: its channels
' carry their own addresses, so MvLiveSlot only reaches this function when the
' row has none. Playlists have no films or episodes at all, which is why the
' picker never offers those tabs for one (MultiViewPicker.ensureTab).
function MvPanelProvider(src as string) as dynamic
    p = ProviderForSrcToken(src)
    if p = invalid then p = ActiveProvider()
    if p = invalid then return invalid
    pt = LCase(ToStr(GetField(p, "ptype")))
    if pt <> "xtream" and pt <> "kwicktv" then return invalid
    return p
end function

' A live channel row (from the Live TV grid, the channel hub, the picker, or a
' recents/favourites entry) as a slot. invalid when there is no way to build a
' playable address for it.
'
' THAT CONTRACT IS LOAD-BEARING and it is tested for by `= invalid`, nothing
' else. Every consumer — MultiViewPicker.take, MultiViewScreen.openPane,
' PlayerScreen.playChannelAt, and the two screens that seed the picker — reads
' invalid as "we cannot play this, say so". A slot handed back with an empty
' url instead sails past all of them: the picker ticks it into the grid, the
' pane sits on "Loading..." for ever, and PlayerScreen's "Couldn't open that
' channel." never gets said. So when the address comes back empty, these
' functions must return invalid rather than a slot that only looks complete.
function MvLiveSlot(ch as dynamic) as dynamic
    if ch = invalid then return invalid
    name = ToStr(GetField(ch, "name"))
    streamId = ToStr(GetField(ch, "streamId"))
    if streamId = "" then streamId = ToStr(GetField(ch, "stream_id"))
    src = ToStr(GetField(ch, "src"))
    rawUrl = ToStr(GetField(ch, "url"))
    ' Playback routes by the CHANNEL's source, not whatever is active — the
    ' same rule LiveTvScreen.onChannelSelected follows.
    url = LivePlayUrl(rawUrl)
    ' READ THIS AS "the playlist row did not bring an address of its own, so
    ' one has to be built from the source's credentials". It is a PRE-check of
    ' the M3U address, NOT a guard on what XtreamLiveUrl returns — the builder
    ' has not been called yet. Its result is checked separately below.
    if url = ""
        if streamId = "" then return invalid
        p = MvPanelProvider(src)
        if p = invalid then return invalid
        url = XtreamLiveUrl(p, streamId)
        ' The provider is a panel but still has no address to build from — a
        ' source record restored from the website link service before it was
        ' fully written, or an older one from before a field existed. FCF117
        ' again, and the member sees the same permanent spinner if this slot
        ' goes out looking complete, so it does not go out at all.
        if url = "" then return invalid
    end if
    id = streamId
    if id = "" then id = rawUrl
    return {
        id: "live:" + src + ":" + id
        title: name
        subLine: ""
        url: url
        ' The address as the PLAYLIST wrote it, before LivePlayUrl rewrote it
        ' for Roku. Kept because it is the only thing that joins an M3U
        ' channel back to its row in the session cache, which is where its
        ' tvg-id — and therefore its guide listings — lives. Matching on the
        ' rewritten url finds nothing.
        raw: rawUrl
        fmt: StreamFormatFor(url, "")
        isLive: true
        logo: ToStr(GetField(ch, "logo"))
        streamId: streamId
        src: src
        provId: ToStr(GetField(ch, "provId"))
    }
end function

' A film. Needs its source's credentials to build an address, which a channel
' row does not — a channel row already carries one. invalid when one cannot
' be built; see MvLiveSlot's note on why that contract matters.
'
' There is no pre-check here and there never was: unlike a channel, a film row
' carries no address of its own, so the builder is the only way to get one.
function MvMovieSlot(streamId as string, name as string, ext as string, icon as string, src as string, year as string) as dynamic
    if streamId = "" then return invalid
    p = MvPanelProvider(src)
    if p = invalid then return invalid
    url = XtreamVodUrl(p, streamId, ext)
    ' A panel with no address of its own (FCF117). A pane built on this would
    ' say "Loading..." until the member pressed Back.
    if url = "" then return invalid
    line = "Film"
    if year <> "" then line = "Film - " + year
    return {
        id: "vod:" + src + ":" + streamId
        title: name
        subLine: line
        url: url
        fmt: StreamFormatFor(url, ext)
        isLive: false
        logo: icon
        streamId: streamId
        src: src
        provId: ToStr(GetField(p, "id"))
    }
end function

' One episode. The SHOW's name is the title, not the episode's: on a pane a
' few centimetres wide "Breaking Bad" tells you what you are looking at and
' "Ozymandias" does not. Android makes the same call
' (multi_view_picker_screen.dart, _pickSeries). invalid when no address can be
' built; see MvLiveSlot's note on why that contract matters. Like a film and
' unlike a channel, an episode row carries no address of its own, so there is
' nothing to pre-check — the builder is the only way to get one.
function MvEpisodeSlot(episodeId as string, showName as string, code as string, ext as string, icon as string, src as string) as dynamic
    if episodeId = "" then return invalid
    p = MvPanelProvider(src)
    if p = invalid then return invalid
    url = XtreamSeriesEpisodeUrl(p, episodeId, ext)
    ' A panel with no address of its own (FCF117). A pane built on this would
    ' say "Loading..." until the member pressed Back.
    if url = "" then return invalid
    return {
        id: "episode:" + src + ":" + episodeId
        title: showName
        subLine: code
        url: url
        fmt: StreamFormatFor(url, ext)
        isLive: false
        logo: icon
        streamId: episodeId
        src: src
        provId: ToStr(GetField(p, "id"))
    }
end function

' "S01E03" from two numbers.
function MvEpisodeCode(season as integer, epNum as integer) as string
    s = season.toStr()
    if season < 10 then s = "0" + s
    e = epNum.toStr()
    if epNum < 10 then e = "0" + e
    return "S" + s + "E" + e
end function

' ---- Self-test ---------------------------------------------------------------
'
' Not called in normal running. Call it from anywhere and read the console —
' the same arrangement GuideMetaSelfTest uses. The indexAfterClose cases are
' the ones Android has real unit tests for, worked through by hand against the
' Dart, and they are the ones most likely to be got wrong in a port.
function MvRulesSelfTest() as boolean
    passed = 0
    total = 0

    idxCases = [
        ' Removing the pane you are watching, with panes after it: the index
        ' stays put and now names the pane that shifted down into the space.
        { count: 4, index: 2, closed: 2, want: 2 }
        { count: 4, index: 0, closed: 0, want: 0 }
        ' Removing the LAST pane while watching it: there is no "same
        ' position" any more, so fall back one.
        { count: 4, index: 3, closed: 3, want: 2 }
        { count: 3, index: 2, closed: 2, want: 1 }
        { count: 2, index: 1, closed: 1, want: 0 }
        ' Removing a pane BEFORE the one you are watching: everything after
        ' shifts down one, so the index has to as well or the picture lands
        ' in the wrong box.
        { count: 4, index: 3, closed: 1, want: 2 }
        { count: 4, index: 1, closed: 0, want: 0 }
        { count: 3, index: 2, closed: 0, want: 1 }
        ' Removing a pane AFTER the one you are watching: nothing moves.
        { count: 4, index: 0, closed: 2, want: 0 }
        { count: 4, index: 1, closed: 3, want: 1 }
        { count: 3, index: 1, closed: 1, want: 1 }
        ' Nothing left.
        { count: 1, index: 0, closed: 0, want: -1 }
    ]
    for each c in idxCases
        total = total + 1
        got = MvIndexAfterClose(c.count, c.index, c.closed)
        if got = c.want
            passed = passed + 1
        else
            KLog("mvtest", "FAIL indexAfterClose count=" + c.count.toStr() + " index=" + c.index.toStr() + " closed=" + c.closed.toStr() + " want=" + c.want.toStr() + " got=" + got.toStr())
        end if
    end for

    ' Layout on a 1080p screen. Two panes fill the width and letterbox; three
    ' and four go 2x2. The third case is the one that matters — reserving the
    ' add strip must SHRINK the cells, not push the bottom row off screen.
    layCases = [
        { panes: 1, w: 1920, h: 1080, cols: 1, rows: 1, cw: 1920, ch: 1080 }
        { panes: 2, w: 1920, h: 1080, cols: 2, rows: 1, cw: 960, ch: 540 }
        { panes: 4, w: 1920, h: 1080, cols: 2, rows: 2, cw: 960, ch: 540 }
        { panes: 3, w: 1920, h: 1008, cols: 2, rows: 2, cw: 896, ch: 504 }
    ]
    for each c in layCases
        total = total + 1
        l = MvLayout(c.panes, c.w, c.h)
        if l.columns = c.cols and l.rows = c.rows and l.cellW = c.cw and l.cellH = c.ch
            passed = passed + 1
        else
            KLog("mvtest", "FAIL layout panes=" + c.panes.toStr() + " got " + l.columns.toStr() + "x" + l.rows.toStr() + " cell " + l.cellW.toStr() + "x" + l.cellH.toStr())
        end if
    end for

    ' The window: a big panel must not squeeze a small playlist out entirely.
    total = total + 1
    big = []
    for i = 0 to 199
        big.push("x")
    end for
    small = []
    for i = 0 to 9
        small.push("y")
    end for
    win = MvPickerWindow(big, small, 60)
    ys = 0
    for each v in win
        if v = "y" then ys = ys + 1
    end for
    if win.count() = 60 and ys = 10
        passed = passed + 1
    else
        KLog("mvtest", "FAIL pickerWindow got " + win.count().toStr() + " rows, " + ys.toStr() + " from the second list")
    end if

    ' Both lists fit: nothing is dropped and the first stays at the head.
    total = total + 1
    win = MvPickerWindow(["a", "b"], ["c"], 60)
    if win.count() = 3 and win[0] = "a" and win[2] = "c"
        passed = passed + 1
    else
        KLog("mvtest", "FAIL pickerWindow short lists")
    end if

    initCases = [
        { name: "BBC One", want: "BO" }
        { name: "Sky Sports Main Event", want: "SS" }
        { name: "4seven", want: "4" }
        { name: "USA | ESPN HD", want: "UE" }
        { name: "", want: "" }
    ]
    for each c in initCases
        total = total + 1
        got = MvInitials(c.name)
        if got = c.want
            passed = passed + 1
        else
            KLog("mvtest", "FAIL initials " + c.name + " want=" + c.want + " got=" + got)
        end if
    end for

    KLog("mvtest", passed.toStr() + "/" + total.toStr() + " passed")
    return passed = total
end function
