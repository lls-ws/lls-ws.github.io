' One picker row. See MultiViewPickRow.xml for what the mark means.

sub init()
    m.theme = KwickTheme()
    m.rowBg = m.top.findNode("rowBg")
    m.rowBg.color = m.theme.surface
    m.ring = m.top.findNode("ring")
    m.ring.color = m.theme.focusHighlight
    m.inner = m.top.findNode("inner")
    m.inner.color = m.theme.surface
    m.logo = m.top.findNode("logo")
    m.mark = m.top.findNode("mark")
    ' Two fonts, because the mark is two different things. The tick is the
    ' Material glyph the rest of the app uses; the chevron is a plain ">" in
    ' the text font rather than an invented icon codepoint — Theme.brs is
    ' explicit that every codepoint in it was read out of the bundled font
    ' first, and a guessed one renders as an empty box.
    m.iconFont = IconFont(34)
    ' Held at 30: this only ever draws a single ">" in a 52px box.
    m.textFont = UiBoldFont(30)
    m.title = m.top.findNode("title")
    ' 28 -> 24 and 21 -> 18 for the shell type. Both are maxLines=1 in a
    ' 1300px box, so the mono width tax would cut a long title from ~92
    ' characters to ~77; at 24 it is ~90, i.e. where it was. The heights in
    ' the XML also mattered: mono's line box is taller than Roboto's, and 21
    ' would have put the sub label's descenders right on its 28px ceiling.
    m.title.font = UiBoldFont(24)
    m.subLabel = m.top.findNode("sub")
    m.subLabel.font = UiFont(18)
    m.laidOut = 0
end sub

' Size to the list's actual itemSize, the same way SettingRow does — a fixed
' width clips the focus ring's right edge the moment the list is narrower.
sub layout()
    w = m.top.width
    if w = invalid or w < 200 then w = 1500
    w = Int(w)
    if m.laidOut = w then return
    m.laidOut = w
    m.rowBg.width = w
    m.ring.width = w
    m.inner.width = w - 6
    m.title.width = w - 200
    m.subLabel.width = w - 200
end sub

sub onContent()
    c = m.top.itemContent
    if c = invalid then return
    layout()
    m.title.text = c.title
    m.subLabel.text = c.description
    if c.hdPosterUrl <> ""
        m.logo.uri = c.hdPosterUrl
        m.logo.visible = true
    else
        ' Rows recycle constantly, so this has to be set BOTH ways every time
        ' or the previous row's artwork smears down the list — the same rule
        ' the channel tiles and poster hearts follow.
        m.logo.uri = ""
        m.logo.visible = false
    end if
    chev = false
    if c.hasField("opens") then chev = c.opens
    ticked = false
    if c.hasField("ticked") then ticked = c.ticked
    if chev
        m.mark.font = m.textFont
        m.mark.text = ">"
        m.mark.color = m.theme.textSecondary
    else if ticked
        m.mark.font = m.iconFont
        m.mark.text = m.theme.iconCheck
        m.mark.color = m.theme.accent
    else
        m.mark.font = m.textFont
        m.mark.text = ""
        m.mark.color = m.theme.textSecondary
    end if
    redraw()
end sub

sub onFocus()
    layout()
    redraw()
end sub

sub redraw()
    focused = m.top.itemHasFocus
    m.ring.visible = focused
    m.inner.visible = focused
    if focused
        m.title.color = m.theme.textPrimary
    else
        m.title.color = m.theme.textSecondary
    end if
    m.subLabel.color = m.theme.textSecondary
end sub
