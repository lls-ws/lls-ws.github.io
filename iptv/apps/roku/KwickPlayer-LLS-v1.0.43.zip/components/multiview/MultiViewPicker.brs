' The Multi-View picker. See MultiViewPicker.xml for the shape of the screen.
'
' Where the lists come from, and why it is not the same as Android's:
'
'   Android searches channels out of the device's own database, so its picker
'   is instant and works with the provider offline. Roku has no channel
'   database — Live TV fetches a category at a time — so the only way to offer
'   "any channel" is the one Search already uses: ask each source for its whole
'   catalogue, once, and filter it in memory afterwards.
'
'   That is also this app's single worst memory path. Search has killed small
'   Rokus with EXIT_OUT_OF_MEMORY more than once (SearchScreen.brs:70-83). So
'   every guard Search grew is copied here, and one more is added on top:
'   a tab's catalogue is fetched only when the member actually opens that tab.
'   Somebody who only ever picks channels never pays for the film list at all.

sub init()
    m.theme = KwickTheme()
    m.top.findNode("bg").color = m.theme.background

    m.keySink = m.top.findNode("keySink")

    header = m.top.findNode("header")
    ' Held at 42. No width is set, so it cannot truncate, and its longest
    ' text ("Choose something to play here") is 731px of mono from x=60.
    header.font = UiBoldFont(42)
    header.color = m.theme.textPrimary
    header.text = "Multi-View"

    m.hint = m.top.findNode("hint")
    ' 24 -> 22. This is maxLines=1 in an 1800px box and the sentence that
    ' explains the whole feature is 115 characters. Mono 24 fits 125 — true,
    ' but the pane limit is interpolated into it, so 8% of headroom is not
    ' headroom. At 22 the box takes 136.
    m.hint.font = UiFont(22)
    m.hint.color = m.theme.textSecondary

    m.barRing = m.top.findNode("barRing")
    m.barRing.color = m.theme.focusHighlight
    m.barBg = m.top.findNode("barBg")
    m.barBg.color = m.theme.surface
    barIcon = m.top.findNode("barIcon")
    barIcon.font = IconFont(32)
    barIcon.text = m.theme.iconSearch
    barIcon.color = m.theme.textSecondary
    m.barText = m.top.findNode("barText")
    ' 26 -> 22. The member's own search text goes in here, maxLines=1 in a
    ' 530px box: Roboto 26 showed about 40 characters of a query and mono 26
    ' would show 34. At 22 it is 40 again.
    m.barText.font = UiFont(22)

    m.tabsGroup = m.top.findNode("tabs")
    m.watchBtn = m.top.findNode("watchBtn")
    m.watchRing = m.top.findNode("watchRing")
    m.watchRing.color = m.theme.focusHighlight
    m.watchBg = m.top.findNode("watchBg")
    m.watchLabel = m.top.findNode("watchLabel")
    ' Held at 28: "Watch 4 together" is 470px of mono in a 590px button.
    m.watchLabel.font = UiBoldFont(28)

    m.chosenLine = m.top.findNode("chosenLine")
    ' 22 -> 18. Up to four titles joined into one un-wrapped 1800px line:
    ' Roboto 22 got about 163 characters onto it, mono 22 gets 136, mono 18
    ' gets 166. Four long film titles already ran out of room here before
    ' this pass; this keeps the point they run out in the same place.
    m.chosenLine.font = UiFont(18)
    m.chosenLine.color = m.theme.accentAlt

    m.list = m.top.findNode("list")
    m.list.observeField("itemSelected", "onRowSelected")

    m.emptyLabel = m.top.findNode("emptyLabel")
    ' Held at 26: the longest of these is 73 characters and it wraps over
    ' three lines of a 1500px box, which mono 26 fills at 96 per line.
    m.emptyLabel.font = UiFont(26)
    m.emptyLabel.color = m.theme.textSecondary

    m.spinner = m.top.findNode("spinner")
    m.spinner.poster.uri = "pkg:/images/spinner.png"

    m.tabDefs = [
        { key: "live", label: "Live TV" }
        { key: "films", label: "Films" }
        { key: "series", label: "Series" }
    ]
    m.tabNodes = []
    buildTabs()

    ' Multi-View shows live channels only - see LiveProviders().
    m.sources = LiveProviders()
    m.tab = "live"
    m.query = ""
    m.q = ""             ' the query, lowercased once (see matches)
    m.chosen = []
    m.rows = []
    m.drill = invalid          ' invalid, or {name, icon, src, seasons}
    m.area = "top"             ' "top" | "list"
    m.topIdx = 0               ' 0 search, 1..3 tabs, 4 watch

    m.channelsX = []           ' panel channels, trimmed
    m.channelsM = []           ' playlist channels, by reference
    m.films = []
    m.seriesRows = []
    m.loaded = { live: false, films: false, series: false }
    m.pending = { live: 0, films: 0, series: 0 }
    m.inflight = {}
    m.failedSrc = {}

    ' Certification 6.3 and the parental locks. A category a member cannot
    ' browse to must not be pickable either, and a picker has nowhere sensible
    ' to put a PIN prompt — so a locked category is left out entirely rather
    ' than shown and then refused. Same call Android makes.
    m.adultOk = AdultCatsAllowed()
    m.parentalOk = ParentalUnlocked()
    m.blocked = {}             ' "<kind>|<provId>" -> { catId: true }
    m.hiddenBy = {}            ' provId -> { streamId: true }

    ' The ceiling, copied from Search. roAppMemoryMonitor measures usage
    ' against THIS device's limit, which is the only number that means
    ' anything from a 2017 Roku TV to a Streaming Stick 4K.
    m.memMon = CreateObject("roAppMemoryMonitor")
    m.rowsHeld = 0
    m.capped = false

    m.top.observeField("focusedChild", "onFocusIn")
end sub

sub onFocusIn()
    if not m.top.hasFocus() then return
    if m.area = "list" and m.rows.count() > 0
        m.list.setFocus(true)
    else
        m.keySink.setFocus(true)
    end if
end sub

sub onStart()
    if m.top.start <> true then return
    if m.top.seedJson <> ""
        seed = ParseJson(m.top.seedJson)
        if seed <> invalid and not m.top.single then m.chosen.push(seed)
    end if
    m.top.findNode("header").text = "Multi-View"
    if m.top.single then m.top.findNode("header").text = "Choose something to play here"
    m.watchBtn.visible = not m.top.single
    redrawTop()
    redrawChosen()
    ' Paint the empty state first so the screen says "loading" rather than
    ' sitting blank while the first catalogue is on its way.
    rebuildRows()
    ensureTab("live")
    m.keySink.setFocus(true)
end sub

' ---- Top strip ---------------------------------------------------------------

sub buildTabs()
    x = 0
    for i = 0 to m.tabDefs.count() - 1
        ring = m.tabsGroup.createChild("Rectangle")
        ring.width = 178
        ring.height = 68
        ring.translation = [x - 4, -4]
        ring.color = m.theme.focusHighlight
        ring.visible = false
        bg = m.tabsGroup.createChild("Rectangle")
        bg.width = 170
        bg.height = 60
        bg.translation = [x, 0]
        bg.color = m.theme.surface
        lbl = m.tabsGroup.createChild("Label")
        lbl.width = 170
        lbl.height = 60
        lbl.translation = [x, 0]
        lbl.horizAlign = "center"
        lbl.vertAlign = "center"
        ' Held at 26: "Live TV" is the longest tab, 118px of mono in 170.
        lbl.font = UiBoldFont(26)
        lbl.text = m.tabDefs[i].label
        m.tabNodes.push({ ring: ring, bg: bg, label: lbl })
        x = x + 182
    end for
end sub

' How many panes are on offer.
'
' DELIBERATELY DIFFERENT FROM ANDROID, and it matters. Android hides
' Multi-View entirely below two connections, because it opens one connection
' per pane: a member with a single-connection line who picked four would watch
' three of them fail for reasons that look exactly like the app being broken.
'
' Roku opens ONE. The whole feature is built around a single decoder, so the
' number of panes has nothing to do with the number of connections the line
' allows, and gating on it would take the feature away from precisely the
' members who cannot get multi-stream anywhere else. No gate, and no
' account_info request to find out — see the report.
function paneLimit() as integer
    return MvMaxPanes()
end function

sub redrawTop()
    limit = paneLimit()
    if m.top.single
        m.hint.text = "Pick one thing to play in this pane."
    else if m.chosen.count() = 0
        m.hint.text = "Choose what to watch side by side. Pick up to " + limit.toStr() + ". One of them plays at a time — move the highlight to change which."
    else
        line = m.chosen.count().toStr() + " of " + limit.toStr() + " chosen"
        if m.chosen.count() >= limit then line = line + " — that is the most that fits on screen"
        m.hint.text = line
    end if

    if m.query = ""
        m.barText.text = "Search"
        m.barText.color = m.theme.textSecondary
    else
        m.barText.text = m.query
        m.barText.color = m.theme.textPrimary
    end if
    m.barRing.visible = (m.area = "top" and m.topIdx = 0)

    for i = 0 to m.tabNodes.count() - 1
        t = m.tabNodes[i]
        t.ring.visible = (m.area = "top" and m.topIdx = i + 1)
        if m.tabDefs[i].key = m.tab
            t.bg.color = m.theme.accent
            ' DARK on the accent, not white — the same fix the Up Next card's
            ' Play Now button needed. The old accent was a mid blue that
            ' carried white at about 4.3:1; the Nord accent is a pale frost
            ' and white on it is under 2:1. The page colour on frost is ~9:1.
            t.label.color = m.theme.background
        else
            t.bg.color = m.theme.surface
            t.label.color = m.theme.textSecondary
        end if
    end for

    if not m.top.single
        ready = (m.chosen.count() >= MvMinPanes())
        if ready
            m.watchBg.color = m.theme.accent
            ' Dark on frost, same reason as the selected tab above.
            m.watchLabel.color = m.theme.background
            m.watchLabel.text = "Watch " + m.chosen.count().toStr() + " together"
        else
            m.watchBg.color = m.theme.surface
            m.watchLabel.color = m.theme.textSecondary
            ' Two is the smallest thing that is actually multi-view; one is
            ' just the player, and that already exists.
            m.watchLabel.text = "Pick at least " + MvMinPanes().toStr()
        end if
        m.watchRing.visible = (m.area = "top" and m.topIdx = 4)
    end if
end sub

sub redrawChosen()
    if m.chosen.count() = 0
        m.chosenLine.text = ""
        return
    end if
    line = "Chosen:  "
    for i = 0 to m.chosen.count() - 1
        if i > 0 then line = line + "   +   "
        line = line + ToStr(GetField(m.chosen[i], "title"))
    end for
    m.chosenLine.text = line
end sub

' The furthest right the top strip goes. No confirm button in single mode.
function topMax() as integer
    if m.top.single then return 3
    return 4
end function

' ---- Search ------------------------------------------------------------------

sub openKeyboard()
    kb = CreateObject("roSGNode", "StandardKeyboardDialog")
    kb.title = "Search"
    kb.text = m.query
    kb.buttons = ["Search", "Cancel"]
    kb.keyboardDomain = "generic"
    edit = kb.textEditBox
    edit.voiceEnabled = true
    edit.voiceEntryType = kb.keyboardDomain
    edit.maxTextLength = 255
    kb.observeField("buttonSelected", "onKeyboardDone")
    m.top.getScene().dialog = kb
end sub

sub onKeyboardDone()
    kb = m.top.getScene().dialog
    if kb.buttonSelected = 0 then m.query = StdKeyboardText(kb)
    kb.close = true
    redrawTop()
    rebuildRows()
    m.keySink.setFocus(true)
end sub

' ---- Fetching ----------------------------------------------------------------

' Only the tab the member is actually looking at is ever fetched.
sub ensureTab(tabKey as string)
    if m.loaded[tabKey] then return
    if m.pending[tabKey] > 0 then return
    started = 0
    for each p in m.sources
        pid = ToStr(p.id)
        token = SrcTokenFor(p)
        if ToStr(p.ptype) = "m3u"
            ' A playlist carries live channels and nothing else.
            if tabKey <> "live" then continue for
            slots = m.global.m3uByProv
            if slots.doesExist(pid)
                takeM3uChannels(slots[pid].channels)
            else
                started = started + 1
                m.pending[tabKey] = m.pending[tabKey] + 1
                task = CreateObject("roSGNode", "M3uTask")
                task.url = p.m3uUrl
                task.tag = pid
                task.observeField("result", "onM3u")
                m.inflight["m3u_" + pid] = task
                task.control = "RUN"
            end if
        else
            action = "get_live_streams"
            if tabKey = "films" then action = "get_vod_streams"
            if tabKey = "series" then action = "get_series"
            started = started + 1
            m.pending[tabKey] = m.pending[tabKey] + 1
            task = CreateObject("roSGNode", "ApiTask")
            task.tag = tabKey + "|" + token + "|" + pid
            task.url = XtreamApiUrl(p, action)
            ' A whole catalogue is a big answer; the same deadline Search
            ' gives it.
            task.timeoutMs = 90000
            task.observeField("result", "onCatalog")
            m.inflight[tabKey + "_" + pid] = task
            task.control = "RUN"
        end if
    end for
    if m.pending[tabKey] <= 0
        m.loaded[tabKey] = true
        rebuildRows()
    else
        setBusy(true)
    end if
end sub

' Playlist rows are pushed BY REFERENCE and deliberately not trimmed: the
' session cache holds them for the whole app run anyway, so a trimmed copy
' would only add memory. An M3U row carries its own group name, so the adult
' and lock tests are exact here — there is no id-to-name cache to consult.
sub takeM3uChannels(chans as object)
    for each c in chans
        g = ToStr(GetField(c, "group"))
        if not m.adultOk and IsAdultCatName(g) then continue for
        if not m.parentalOk and IsCatLocked("live", g) then continue for
        m.channelsM.push(c)
    end for
end sub

sub onM3u(event as object)
    res = event.getData()
    pid = ToStr(event.getRoSGNode().tag)
    m.inflight.delete("m3u_" + pid)
    if res <> invalid and res.ok = true
        chans = ToArray(res.channels)
        PublishM3uParse(pid, chans, ToStr(GetField(res, "tvgUrl")))
        takeM3uChannels(chans)
    end if
    m.pending["live"] = m.pending["live"] - 1
    finishIfDone("live")
end sub

sub onCatalog(event as object)
    res = event.getData()
    tag = ToStr(event.getRoSGNode().tag)
    parts = tag.split("|")
    if parts.count() < 3 then return
    tabKey = ToStr(parts[0])
    token = ToStr(parts[1])
    pid = ToStr(parts[2])
    m.inflight.delete(tabKey + "_" + pid)
    if res <> invalid and res.ok = true
        scope = "live"
        if tabKey = "films" then scope = "movies"
        if tabKey = "series" then scope = "series"
        drop = blockedCatIds(scope, pid)
        hidden = hiddenSetFor(pid)
        for each s in ToArray(res.data)
            ' Checked every 500 rows, not every row: GetMemoryLimitPercent is
            ' a syscall and a catalogue can run to tens of thousands.
            if m.rowsHeld mod 500 = 0
                if not m.capped and atMemoryCeiling()
                    m.capped = true
                    KLog("multiview", "memory ceiling reached at " + m.rowsHeld.toStr() + " rows - the picker's list will be partial")
                end if
            end if
            if m.capped then exit for
            ' Dropped BEFORE it is trimmed, so a blocked row is never held.
            if drop.doesExist(ToStr(GetField(s, "category_id"))) then continue for
            row = trimRow(s, tabKey, token, pid)
            if row = invalid then continue for
            if tabKey = "live"
                if hidden.doesExist(ToStr(row.streamId)) then continue for
                m.channelsX.push(row)
            else if tabKey = "films"
                m.films.push(row)
            else
                m.seriesRows.push(row)
            end if
            m.rowsHeld = m.rowsHeld + 1
        end for
    else
        m.failedSrc[ToStr(GetField(providerById(pid), "name"))] = true
    end if
    m.pending[tabKey] = m.pending[tabKey] - 1
    finishIfDone(tabKey)
end sub

sub finishIfDone(tabKey as string)
    if m.pending[tabKey] > 0 then return
    m.loaded[tabKey] = true
    setBusy(false)
    rebuildRows()
end sub

' Only the fields the rows and the slot builders actually read. The panel's
' raw rows carry a dozen nothing here ever looks at — plot, cast, director,
' genre, added, rating, direct_source — and a plot alone runs to hundreds of
' bytes, times tens of thousands of rows, times every source.
function trimRow(s as object, tabKey as string, token as string, pid as string) as dynamic
    name = ToStr(GetField(s, "name"))
    if name = "" then return invalid
    if tabKey = "series"
        sid = ToStr(GetField(s, "series_id"))
        if sid = "" then return invalid
        return { name: name, seriesId: sid, icon: ToStr(GetField(s, "cover")), src: token, provId: pid }
    end if
    if tabKey = "films"
        sid = ToStr(GetField(s, "stream_id"))
        if sid = "" then return invalid
        return {
            name: name
            streamId: sid
            icon: ToStr(GetField(s, "stream_icon"))
            ext: ToStr(GetField(s, "container_extension"))
            year: ToStr(GetField(s, "year"))
            src: token
            provId: pid
        }
    end if
    sid = ToStr(GetField(s, "stream_id"))
    if sid = "" then return invalid
    return {
        name: name
        streamId: sid
        logo: ToStr(GetField(s, "stream_icon"))
        url: ""
        src: token
        provId: pid
    }
end function

function providerById(pid as string) as dynamic
    for each p in m.sources
        if ToStr(p.id) = pid then return p
    end for
    return invalid
end function

' Category ids this source must not offer, for one scope: adult
' (certification 6.3) and anything the member has locked behind the parental
' PIN. The names come from the id-to-name cache the browsing screens keep
' warm; a member who opens this before browsing anything on a brand-new
' install has no cache yet, exactly as in Search.
function blockedCatIds(scope as string, pid as string) as object
    key = scope + "|" + pid
    if m.blocked.doesExist(key) then return m.blocked[key]
    ids = {}
    if not (m.adultOk and m.parentalOk)
        cache = loadCatNameCache(scope, pid)
        for each cid in cache
            nm = ToStr(cache[cid])
            if not m.adultOk and IsAdultCatName(nm)
                ids[ToStr(cid)] = true
            else if not m.parentalOk and IsCatLocked(scope, nm)
                ids[ToStr(cid)] = true
            end if
        end for
    end if
    m.blocked[key] = ids
    return ids
end function

' Channels the member has hidden in Settings, per source. Loaded once per
' provider rather than per channel — the same rule ApplyChannelPrefs follows.
' (ApplyChannelPrefs itself is not used here: it also sorts, and its insertion
' sort over a few thousand catalogue rows would stall the render thread.)
function hiddenSetFor(pid as string) as object
    if m.hiddenBy.doesExist(pid) then return m.hiddenBy[pid]
    hset = {}
    for each h in LoadJsonArray("chan_hidden_" + pid + ProfileScopeSuffix())
        hset[ToStr(h)] = true
    end for
    m.hiddenBy[pid] = hset
    return hset
end function

function atMemoryCeiling() as boolean
    if m.rowsHeld >= 150000 then return true
    if m.memMon = invalid then return false
    used = m.memMon.GetMemoryLimitPercent()
    if used = invalid then return false
    return ToInt(used) >= 70
end function

sub setBusy(b as boolean)
    m.spinner.visible = b
    if b
        m.spinner.control = "start"
    else
        m.spinner.control = "stop"
    end if
end sub

' ---- Rows --------------------------------------------------------------------

' How many rows a tab shows at once. A list is a window, not a library.
function windowSize() as integer
    return 60
end function

' m.q is the lowercased query, computed once when the query changes rather
' than once per row: this runs over every catalogue row a member owns, which
' on a big panel is tens of thousands, on the render thread.
function matches(title as string) as boolean
    if m.q = "" then return true
    return LCase(title).instr(0, m.q) > -1
end function

' Everything matching in one list, up to the window size.
'
' Stopping at the window is safe as well as fast: MvPickerWindow never takes
' more than `limit` from either half, so a half capped at `limit` produces the
' identical answer to a half that scanned four thousand rows to the end.
function collect(src as object, kind as string, field as string) as object
    out = []
    limit = windowSize()
    for each r in src
        if matches(ToStr(GetField(r, "name")))
            row = { kind: kind }
            row[field] = r
            out.push(row)
            if out.count() >= limit then exit for
        end if
    end for
    return out
end function

sub rebuildRows()
    if m.drill <> invalid
        buildEpisodeRows()
        return
    end if
    m.q = LCase(m.query)
    rows = []
    if m.tab = "live"
        ' Each half is guaranteed its share. Appending one list to the other
        ' and taking the first sixty is what a member with a big panel and a
        ' small playlist would experience as "my playlist is not in here at
        ' all" — the panel fills the window on its own.
        rows = MvPickerWindow(collect(m.channelsX, "live", "ch"), collect(m.channelsM, "live", "ch"), windowSize())
    else if m.tab = "films"
        rows = MvPickerWindow(collect(m.films, "film", "it"), [], windowSize())
    else
        rows = MvPickerWindow(collect(m.seriesRows, "series", "it"), [], windowSize())
    end if
    m.rows = rows
    fillList()
end sub

sub fillList()
    content = CreateObject("roSGNode", "ContentNode")
    for each r in m.rows
        node = content.createChild("ContentNode")
        opens = false
        ticked = false
        if r.kind = "live"
            ch = r.ch
            node.title = ToStr(GetField(ch, "name"))
            node.hdPosterUrl = ToStr(GetField(ch, "logo"))
            node.description = sourceLine(ToStr(GetField(ch, "src")), "Live channel")
            ticked = isChosenId(liveIdFor(ch))
        else if r.kind = "film"
            it = r.it
            node.title = ToStr(it.name)
            node.hdPosterUrl = PosterUrl(ToStr(it.icon))
            line = "Film"
            if ToStr(it.year) <> "" then line = "Film - " + ToStr(it.year)
            node.description = sourceLine(ToStr(it.src), line)
            ticked = isChosenId("vod:" + ToStr(it.src) + ":" + ToStr(it.streamId))
        else if r.kind = "series"
            it = r.it
            node.title = ToStr(it.name)
            node.hdPosterUrl = PosterUrl(ToStr(it.icon))
            node.description = sourceLine(ToStr(it.src), "Series — choose an episode")
            opens = true
        else if r.kind = "episode"
            ep = r.ep
            node.title = ToStr(ep.code) + "   " + ToStr(ep.title)
            node.description = ToStr(m.drill.name)
            ticked = isChosenId("episode:" + ToStr(m.drill.src) + ":" + ToStr(ep.id))
        end if
        node.addFields({ opens: opens, ticked: ticked })
    end for
    m.list.content = content
    empty = (m.rows.count() = 0)
    m.list.visible = not empty
    m.emptyLabel.visible = empty
    if empty then m.emptyLabel.text = emptyText()
    if empty and m.area = "list"
        m.area = "top"
        redrawTop()
        m.keySink.setFocus(true)
    end if
end sub

function emptyText() as string
    what = "channels"
    if m.tab = "films" then what = "films"
    if m.tab = "series" then what = "series"
    if not m.loaded[m.tab] then return "Loading your " + what + "..."
    if m.query <> "" then return "No " + what + " match """ + m.query + """."
    if m.failedSrc.count() > 0 then return "No " + what + " on your sources yet — and at least one source did not answer."
    return "No " + what + " on your sources yet."
end function

' With more than one source, say whose thing this is. One source needs no
' telling apart, and the line is better spent on what the thing IS.
function sourceLine(token as string, base as string) as string
    if m.sources.count() <= 1 then return base
    label = SourceLabelFor(token)
    if label = "" then return base
    return base + "  -  " + ShortSrcLabel(label)
end function

function liveIdFor(ch as object) as string
    sid = ToStr(GetField(ch, "streamId"))
    if sid = "" then sid = ToStr(GetField(ch, "url"))
    return "live:" + ToStr(GetField(ch, "src")) + ":" + sid
end function

function isChosenId(id as string) as boolean
    for each s in m.chosen
        if ToStr(GetField(s, "id")) = id then return true
    end for
    return false
end function

' ---- Choosing ----------------------------------------------------------------

sub onRowSelected()
    idx = m.list.itemSelected
    if idx < 0 or idx >= m.rows.count() then return
    r = m.rows[idx]
    if r.kind = "live"
        take(MvLiveSlot(r.ch))
    else if r.kind = "film"
        it = r.it
        take(MvMovieSlot(ToStr(it.streamId), ToStr(it.name), ToStr(it.ext), ToStr(it.icon), ToStr(it.src), ToStr(it.year)))
    else if r.kind = "series"
        openSeries(r.it)
    else if r.kind = "episode"
        ep = r.ep
        take(MvEpisodeSlot(ToStr(ep.id), ToStr(m.drill.name), ToStr(ep.code), ToStr(ep.ext), ToStr(m.drill.icon), ToStr(m.drill.src)))
    end if
end sub

' Add it, or take it back off if it is already on the list.
'
' One place, because "pick one thing and close" versus "tick up to four" is a
' decision about this screen and not about what was picked.
sub take(slot as dynamic)
    if slot = invalid
        KLog("multiview", "that row has no playable address - not adding it")
        return
    end if
    if m.top.single
        m.top.result = FormatJson([slot])
        m.top.closed = true
        return
    end if
    id = ToStr(GetField(slot, "id"))
    at = -1
    for i = 0 to m.chosen.count() - 1
        if ToStr(GetField(m.chosen[i], "id")) = id then at = i
    end for
    if at >= 0
        m.chosen.delete(at)
    else if m.chosen.count() < paneLimit()
        m.chosen.push(slot)
    else
        ' A full set must not look broken: the already-picked rows stay
        ' pressable so one can be swapped out, and only a NEW pick past the
        ' limit is refused.
        return
    end if
    redrawTop()
    redrawChosen()
    ' Repaint so the tick appears. Keeps the member's place in the list.
    focused = m.list.itemFocused
    fillList()
    if focused >= 0 and focused < m.rows.count() then m.list.jumpToItem = focused
end sub

' ---- Series -> episodes ------------------------------------------------------
'
' A series cannot be played, an episode can. Picking the show opens its
' episodes; picking an episode is what fills the pane. Android puts this in a
' sheet so there is no extra Back step between the show and the episode; here
' the same list is reused and Back walks back out of it, which is the Roku
' equivalent and costs the same one press.

sub openSeries(it as object)
    m.drill = { name: ToStr(it.name), icon: ToStr(it.icon), src: ToStr(it.src), seasons: [] }
    prov = ProviderForSrcToken(ToStr(it.src))
    if prov = invalid then prov = ActiveProvider()
    if prov = invalid
        m.drill = invalid
        return
    end if
    setBusy(true)
    task = CreateObject("roSGNode", "ApiTask")
    task.url = XtreamApiUrl(prov, "get_series_info") + "&series_id=" + UrlEncode(ToStr(it.seriesId))
    task.observeField("result", "onSeriesInfo")
    m.inflight["seriesinfo"] = task
    task.control = "RUN"
    m.rows = []
    fillList()
    m.emptyLabel.text = "Loading episodes..."
    m.emptyLabel.visible = true
end sub

sub onSeriesInfo(event as object)
    res = event.getData()
    m.inflight.delete("seriesinfo")
    setBusy(false)
    if m.drill = invalid then return
    eps = []
    if res <> invalid and res.ok = true
        bySeason = GetField(res.data, "episodes")
        if bySeason <> invalid and type(bySeason) = "roAssociativeArray"
            nums = []
            for each k in bySeason
                nums.push(ToInt(k))
            end for
            nums.sort()
            for each n in nums
                for each e in ToArray(bySeason[n.toStr()])
                    title = ToStr(GetField(e, "title"))
                    epNum = ToInt(GetField(e, "episode_num"))
                    if title = "" then title = "Episode " + epNum.toStr()
                    eps.push({
                        id: ToStr(GetField(e, "id"))
                        title: title
                        code: MvEpisodeCode(n, epNum)
                        ext: ToStr(GetField(e, "container_extension"))
                    })
                end for
            end for
        end if
    end if
    m.drill.seasons = eps
    buildEpisodeRows()
    if eps.count() > 0
        m.area = "list"
        m.list.jumpToItem = 0
        m.list.setFocus(true)
    end if
end sub

sub buildEpisodeRows()
    rows = []
    for each e in m.drill.seasons
        rows.push({ kind: "episode", ep: e })
    end for
    m.rows = rows
    fillList()
    if rows.count() = 0 then m.emptyLabel.text = "Your provider listed no episodes for this show."
end sub

sub leaveDrill()
    m.drill = invalid
    rebuildRows()
end sub

' ---- Done --------------------------------------------------------------------

sub confirm()
    if m.chosen.count() < MvMinPanes() then return
    m.top.result = FormatJson(m.chosen)
    m.top.closed = true
end sub

sub cancel()
    m.top.result = ""
    m.top.closed = true
end sub

' ---- Keys --------------------------------------------------------------------

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false

    if m.area = "list"
        if key = "back"
            if m.drill <> invalid
                leaveDrill()
                return true
            end if
            m.area = "top"
            redrawTop()
            m.keySink.setFocus(true)
            return true
        else if key = "up"
            if m.list.itemFocused <= 0
                m.area = "top"
                redrawTop()
                m.keySink.setFocus(true)
                return true
            end if
            return false
        else if key = "left"
            m.area = "top"
            redrawTop()
            m.keySink.setFocus(true)
            return true
        end if
        return false
    end if

    ' The top strip.
    if key = "back"
        if m.drill <> invalid
            leaveDrill()
            return true
        end if
        cancel()
        return true
    else if key = "left"
        if m.topIdx > 0
            m.topIdx = m.topIdx - 1
            redrawTop()
        end if
        return true
    else if key = "right"
        if m.topIdx < topMax()
            m.topIdx = m.topIdx + 1
            redrawTop()
        end if
        return true
    else if key = "down"
        if m.rows.count() > 0
            m.area = "list"
            redrawTop()
            m.list.setFocus(true)
        end if
        return true
    else if key = "OK"
        if m.topIdx = 0
            openKeyboard()
        else if m.topIdx >= 1 and m.topIdx <= 3
            newTab = m.tabDefs[m.topIdx - 1].key
            if newTab <> m.tab or m.drill <> invalid
                m.tab = newTab
                m.drill = invalid
                redrawTop()
                rebuildRows()
                ensureTab(newTab)
                if not m.loaded[newTab]
                    m.emptyLabel.text = emptyText()
                    m.emptyLabel.visible = true
                end if
            end if
        else
            confirm()
        end if
        return true
    end if
    return false
end function
