' Multi-View. See the header of MultiViewScreen.xml for the platform wall
' this is built around: one playing video instance per channel, so the grid is
' up to four panes with the picture in whichever one has focus.
'
' Port of lib/ui/screens/multiview/multi_view_screen.dart.

sub init()
    m.theme = KwickTheme()

    m.keySink = m.top.findNode("keySink")
    m.panesGroup = m.top.findNode("panes")
    m.video = m.top.findNode("video")
    m.cover = m.top.findNode("cover")

    m.ringT = m.top.findNode("ringT")
    m.ringB = m.top.findNode("ringB")
    m.ringL = m.top.findNode("ringL")
    m.ringR = m.top.findNode("ringR")
    for each r in [m.ringT, m.ringB, m.ringL, m.ringR]
        r.color = m.theme.focusHighlight
    end for

    m.plateBg = m.top.findNode("plateBg")
    m.plateText = m.top.findNode("plateText")
    ' 26 -> 24. This one is not just legibility: plateSize is ALSO the
    ' divisor redrawPlate trims the line with, so the number and the width
    ' factor beside it have to move together for the shell type.
    m.plateSize = 24
    m.plateText.font = UiBoldFont(m.plateSize)
    m.plateText.color = m.theme.textPrimary

    m.addStrip = m.top.findNode("addStrip")
    m.addRing = m.top.findNode("addRing")
    m.addRing.color = m.theme.focusHighlight
    m.addBg = m.top.findNode("addBg")
    m.addBg.color = m.theme.surfaceElevated
    m.addLabel = m.top.findNode("addLabel")
    ' Held at 28: "Add another pane  (2 of 4)" is 26 characters, 437px of
    ' mono in a 520px button.
    m.addLabel.font = UiBoldFont(28)
    m.addLabel.color = m.theme.textPrimary

    m.menuGroup = m.top.findNode("menuGroup")
    m.menuScrim = m.top.findNode("menuScrim")
    ' Left off the palette on purpose, like the player's scrims: this dims a
    ' LIVE PICTURE behind the pane menu, and a scrim tinted with the theme's
    ' slate reads as a haze over the video rather than as a dimming.
    m.menuScrim.color = "0x000000D0"
    m.menuCol = m.top.findNode("menuCol")
    ' Held at 27: the longest menu line is "Change channel", 14 characters,
    ' 227px of mono in a 460px button.
    m.menuFont = UiBoldFont(27)

    m.dwellTimer = m.top.findNode("dwellTimer")
    m.dwellTimer.duration = MvDwellSeconds()
    m.dwellTimer.observeField("fire", "onDwell")
    m.spinTimer = m.top.findNode("spinTimer")
    m.spinTimer.observeField("fire", "onSpinTimer")
    m.slowTimer = m.top.findNode("slowTimer")
    m.slowTimer.observeField("fire", "onSlowTimer")
    m.tickTimer = m.top.findNode("tickTimer")
    m.tickTimer.observeField("fire", "onTick")

    ' What each pane holds. An `invalid` entry is an EMPTY pane that is still
    ' on screen — see clearPane.
    m.slots = []
    m.panes = []
    m.cells = []
    m.layout = { columns: 1, rows: 1, cellW: 1920, cellH: 1080 }
    m.gridBottom = 1080

    m.focus = 0          ' the highlighted pane
    m.live = -1          ' the pane the one decoder is drawn in
    m.expanded = -1
    m.menu = -1
    m.menuBtns = []
    m.menuIdx = 0
    m.area = "grid"      ' "grid" | "add" | "menu"
    m.paused = false
    m.videoErr = false
    m.picker = invalid
    m.pickTarget = -1

    m.listings = {}      ' slot id -> [{title, startS, stopS}]
    m.epgAsked = {}      ' slot id -> true (asked once, whatever came back)
    m.epgTasks = {}      ' slot id -> the in-flight ApiTask

    m.video.observeField("state", "onVideoState")
    m.top.observeField("focusedChild", "onFocusIn")
end sub

sub onFocusIn()
    ' Every key on this screen is handled by hand, so real focus lives on the
    ' invisible sink for the whole session — the same idiom SearchScreen uses
    ' to stop a list eating arrow presses.
    if m.top.hasFocus() then m.keySink.setFocus(true)
end sub

' ---- Opening ----------------------------------------------------------------

sub onStart()
    if m.top.start <> true then return
    parsed = ParseJson(m.top.slotsJson)
    m.slots = []
    for each s in ToArray(parsed)
        if s <> invalid then m.slots.push(s)
    end for
    ' Beyond four nothing is big enough to watch. Trimmed here rather than
    ' trusted from the picker: this field is an interface and anything may
    ' set it.
    while m.slots.count() > MvMaxPanes()
        m.slots.pop()
    end while
    if m.slots.count() = 0
        KLog("multiview", "opened with no panes - closing again")
        closeScreen()
        return
    end if
    if MvMemoryTight()
        KLog("multiview", "device memory is already low at open - artwork will be skipped")
    end if
    KLog("multiview", "opening with " + m.slots.count().toStr() + " pane(s)")

    m.focus = 0
    m.live = -1
    relayout()
    redrawRing()
    redrawAddStrip()
    m.tickTimer.control = "start"
    for i = 0 to m.slots.count() - 1
        loadNow(i)
    end for
    ' The first pane starts at once. The dwell exists to stop focus DRIFT
    ' re-pointing the decoder; the member has just pressed "Watch together"
    ' and there is nothing to wait for (certification 3.6 wants playback
    ' inside eight seconds and a 0.9s pause here would be spending it for
    ' nothing).
    commitTo(0, true)
    m.keySink.setFocus(true)
end sub

' ---- Geometry ---------------------------------------------------------------

' The cell a pane occupies, edges included.
function outerRect(i as integer) as object
    if i >= 0 and i = m.expanded then return { x: 0, y: 0, w: 1920, h: 1080 }
    if i < 0 or i >= m.cells.count() then return { x: 0, y: 0, w: 1920, h: 1080 }
    return m.cells[i]
end function

' The box the pane actually draws in — the cell less the gutter the focus
' frame is painted into.
function innerRect(i as integer) as object
    if i >= 0 and i = m.expanded then return { x: 0, y: 0, w: 1920, h: 1080 }
    r = outerRect(i)
    return { x: r.x + 4, y: r.y + 4, w: r.w - 8, h: r.h - 8 }
end function

' Work out the grid for the current number of panes, make the pane nodes match
' it, and fill them in.
sub relayout()
    n = m.slots.count()
    if n <= 0 then return
    ' Reserve the add strip BEFORE sizing the panes, exactly as Android does:
    ' adding it afterwards pushes the bottom row off the screen.
    stripH = 0
    if n < MvMaxPanes() then stripH = 88
    availH = 1080 - stripH
    l = MvLayout(n, 1920, availH)
    m.layout = l

    gridW = l.columns * l.cellW
    gridH = l.rows * l.cellH
    ox = Int((1920 - gridW) / 2)
    oy = Int((availH - gridH) / 2)
    m.cells = []
    for i = 0 to n - 1
        col = i mod l.columns
        row = Int(i / l.columns)
        m.cells.push({ x: ox + col * l.cellW, y: oy + row * l.cellH, w: l.cellW, h: l.cellH })
    end for
    m.gridBottom = oy + gridH

    while m.panesGroup.getChildCount() > n
        m.panesGroup.removeChildIndex(m.panesGroup.getChildCount() - 1)
    end while
    while m.panesGroup.getChildCount() < n
        m.panesGroup.createChild("MultiViewPane")
    end while
    m.panes = []
    for i = 0 to n - 1
        m.panes.push(m.panesGroup.getChild(i))
    end for
    for i = 0 to n - 1
        r = innerRect(i)
        p = m.panes[i]
        p.translation = [r.x, r.y]
        p.cellW = r.w
        p.cellH = r.h
        p.visible = (m.expanded < 0 or m.expanded = i)
        refreshPane(i)
    end for
    if m.focus >= n then m.focus = n - 1
    if m.focus < 0 then m.focus = 0
end sub

sub refreshPane(i as integer)
    if i < 0 or i >= m.panes.count() then return
    s = m.slots[i]
    if s = invalid
        m.panes[i].slotJson = ""
    else
        m.panes[i].slotJson = FormatJson(s)
    end if
    m.panes[i].nowText = nowTextFor(i)
end sub

' Move the picture to a cell WITHOUT reopening the stream. Used when the
' arrangement changes under a pane that never stopped playing — reopening
' would cost the member seconds and the provider another connection for
' nothing.
sub placeVideo(i as integer)
    if i < 0 or i >= m.slots.count() then return
    r = innerRect(i)
    m.video.translation = [r.x, r.y]
    m.video.width = r.w
    m.video.height = r.h
end sub

' ---- The one decoder --------------------------------------------------------

' Point the video at pane i.
'
' `force` is for the cases where the pane is already the live one and we mean
' it anyway: Refresh, and a rearrangement that left the index pointing at a
' different stream than the one playing.
sub commitTo(i as integer, force = false as boolean)
    m.dwellTimer.control = "stop"
    if i < 0 or i >= m.slots.count() then return
    slot = m.slots[i]
    if slot = invalid then return
    if i = m.live and not force and not m.videoErr then return

    ' Cover first, video second: the cell must never be a black rectangle,
    ' which is what a Video node draws while it is opening a stream. The cover
    ' is the same pane tile the member was already looking at, so a switch
    ' reads as "this is loading", never as "this is broken".
    showCover(i, "loading", "Loading " + ToStr(GetField(slot, "title")) + Chr(8230))

    ' Stop before re-pointing. One playing instance per channel is the whole
    ' constraint; handing a playing Video node new content is asking for the
    ' failure this design exists to avoid.
    m.video.control = "stop"
    r = innerRect(i)
    m.video.translation = [r.x, r.y]
    m.video.width = r.w
    m.video.height = r.h
    m.live = i
    m.paused = false
    m.videoErr = false

    content = CreateObject("roSGNode", "ContentNode")
    content.url = ToStr(GetField(slot, "url"))
    content.title = ToStr(GetField(slot, "title"))
    content.streamFormat = ToStr(GetField(slot, "fmt"))
    if GetField(slot, "isLive") = true then content.live = true
    ' Identify the app to the provider's panel. THIS is the request that shows
    ' up in their active-connections list — the same rule PlayerScreen follows,
    ' so a Multi-View stream is attributed to Kwick Player like any other.
    content.HttpHeaders = ["User-Agent: " + KwickUserAgent()]
    m.video.content = content
    m.video.control = "play"

    m.spinTimer.control = "stop"
    m.spinTimer.control = "start"
    m.slowTimer.control = "stop"
    m.slowTimer.control = "start"
    KLog("multiview", "pane " + i.toStr() + ": opening " + ToStr(GetField(slot, "title")))
    redrawPlate()
end sub

sub onVideoState()
    st = m.video.state
    if st = "playing"
        m.spinTimer.control = "stop"
        m.slowTimer.control = "stop"
        m.videoErr = false
        hideCover()
        redrawPlate()
    else if st = "error"
        m.spinTimer.control = "stop"
        m.slowTimer.control = "stop"
        m.videoErr = true
        msg = m.video.errorMsg
        KLog("multiview", "pane " + m.live.toStr() + " error: " + msg)
        ' NOTHING is retried automatically, and that is deliberate on two
        ' counts. A deterministic failure (no decoder for this stream's audio
        ' or video) fails identically every time — the rule the single player
        ' already follows, PlayerScreen.brs:271-275. And an automatic retry
        ' loop across a grid of panes is precisely the burst of connection
        ' attempts a provider's anti-share system bans for; the owner's own IP
        ' was banned that way. Refresh is one press away in the pane menu.
        kind = StreamErrorKind(msg)
        showCover(m.live, "error", StreamErrorText(kind) + Chr(10) + "Press OK, then Refresh, to try again.")
        m.cover.busy = false
    end if
end sub

' Certification 3.4: past three seconds a wait needs a busy indicator. Held
' off until then so an ordinary switch never flashes one.
sub onSpinTimer()
    if m.cover.visible and m.cover.state = "loading" then m.cover.busy = true
end sub

' Past ten seconds, say so in words rather than spinning silently. There is no
' retry behind this — it is an admission, not an action.
sub onSlowTimer()
    if m.cover.visible and m.cover.state = "loading"
        m.cover.statusText = "Still connecting. This stream is slow to start."
    end if
end sub

sub showCover(i as integer, state as string, text as string)
    if i < 0 or i >= m.slots.count() then return
    r = innerRect(i)
    m.cover.translation = [r.x, r.y]
    m.cover.cellW = r.w
    m.cover.cellH = r.h
    s = m.slots[i]
    if s = invalid
        m.cover.slotJson = ""
    else
        m.cover.slotJson = FormatJson(s)
    end if
    m.cover.nowText = nowTextFor(i)
    m.cover.state = state
    m.cover.statusText = text
    ' Cleared every time: the spinner is armed fresh by spinTimer, and a
    ' leftover one from the previous switch would appear instantly on this one.
    m.cover.busy = false
    m.cover.visible = true
end sub

sub hideCover()
    m.cover.busy = false
    m.cover.visible = false
end sub

sub togglePause()
    if m.live < 0 then return
    if m.paused
        m.video.control = "resume"
        m.paused = false
    else
        m.video.control = "pause"
        m.paused = true
    end if
end sub

' ---- Focus ------------------------------------------------------------------

' Moving focus is instant and says nothing to the decoder. The frame moves on
' this frame (certification 3.5 gives the UI 250 ms to answer a press); the
' picture follows once focus has settled — see MvDwellSeconds().
sub focusPane(ni as integer)
    if ni < 0 or ni >= m.slots.count() then return
    if ni = m.focus and m.area = "grid" then return
    m.focus = ni
    m.area = "grid"
    redrawRing()
    redrawAddStrip()
    m.dwellTimer.control = "stop"
    ' Nothing to commit to on an empty pane, and nothing to do when the
    ' picture is already here.
    if m.slots[ni] <> invalid and ni <> m.live then m.dwellTimer.control = "start"
end sub

sub onDwell()
    if m.area <> "grid" then return
    commitTo(m.focus)
end sub

' Android's grid wraps: Right off the last pane lands on the first
' (multi_view_screen.dart:509-525). This does NOT, and the difference is
' deliberate — on a remote, spatial navigation is what a member expects, and a
' wrap that teleports the highlight across the screen is disorienting when the
' thing it moves is the picture. Down off the bottom row leaves the grid for
' the "add another pane" strip, which Android reaches by touch.
sub moveFocus(dir as string)
    if m.expanded >= 0 then return
    n = m.slots.count()
    if n <= 0 then return
    cols = m.layout.columns
    rows = m.layout.rows
    row = Int(m.focus / cols)
    col = m.focus mod cols
    if dir = "left"
        if col = 0 then return
        col = col - 1
    else if dir = "right"
        if col >= cols - 1 then return
        col = col + 1
    else if dir = "up"
        if row = 0 then return
        row = row - 1
    else if dir = "down"
        if row >= rows - 1
            if n < MvMaxPanes()
                m.area = "add"
                m.dwellTimer.control = "stop"
                redrawRing()
                redrawAddStrip()
            end if
            return
        end if
        row = row + 1
    end if
    ni = row * cols + col
    ' The last row can be short — three panes in a 2x2 leaves one gap. Land on
    ' the nearest real pane rather than nowhere.
    if ni >= n then ni = n - 1
    focusPane(ni)
end sub

sub redrawRing()
    showRing = (m.area = "grid" and m.expanded < 0 and m.slots.count() > 0)
    if not showRing
        m.ringT.visible = false
        m.ringB.visible = false
        m.ringL.visible = false
        m.ringR.visible = false
        return
    end if
    r = outerRect(m.focus)
    t = 4
    m.ringT.translation = [r.x, r.y]
    m.ringT.width = r.w
    m.ringT.height = t
    m.ringB.translation = [r.x, r.y + r.h - t]
    m.ringB.width = r.w
    m.ringB.height = t
    m.ringL.translation = [r.x, r.y]
    m.ringL.width = t
    m.ringL.height = r.h
    m.ringR.translation = [r.x + r.w - t, r.y]
    m.ringR.width = t
    m.ringR.height = r.h
    m.ringT.visible = true
    m.ringB.visible = true
    m.ringL.visible = true
    m.ringR.visible = true
end sub

' The name plate over the live cell — Android's _Plate, but only one of them.
' Every other pane is showing its own name and programme in the tile itself;
' the live one has a picture over its tile, so it needs telling.
sub redrawPlate()
    if m.live < 0 or m.live >= m.slots.count()
        m.plateBg.visible = false
        m.plateText.visible = false
        return
    end if
    s = m.slots[m.live]
    if s = invalid
        m.plateBg.visible = false
        m.plateText.visible = false
        return
    end if
    r = innerRect(m.live)
    txt = ToStr(GetField(s, "title"))
    line = nowTextFor(m.live)
    if line = "" then line = ToStr(GetField(s, "subLine"))
    if line <> "" then txt = txt + "   -   " + line
    ' Trimmed by character count rather than by asking the Label to bound
    ' itself: boundingRect on a width-constrained Label reports the width it
    ' was given, not the width of the text, and the plate is sized from it.
    ' 0.55 was Roboto-Medium's average advance. JetBrains Mono's is a flat
    ' 0.6em, so leaving it would have let this trim to MORE characters than
    ' fit and pushed the line out past the plate. The floor around the
    ' divisor is gone with it: flooring 24*0.6 to 14 makes the estimate
    ' optimistic by exactly the amount that overruns.
    maxChars = Int((r.w - 72) / (m.plateSize * 0.6))
    if maxChars < 8 then maxChars = 8
    if Len(txt) > maxChars then txt = Left(txt, maxChars - 1) + Chr(8230)
    m.plateText.text = txt
    w = Int(m.plateText.boundingRect().width) + 28
    if w > r.w - 32 then w = r.w - 32
    m.plateBg.width = w
    m.plateBg.translation = [r.x + 16, r.y + 16]
    m.plateText.translation = [r.x + 30, r.y + 16]
    m.plateBg.visible = true
    m.plateText.visible = true
end sub

sub redrawAddStrip()
    canAdd = (m.slots.count() < MvMaxPanes() and m.expanded < 0)
    m.addStrip.visible = canAdd
    if not canAdd then return
    m.addLabel.text = "Add another pane  (" + m.slots.count().toStr() + " of " + MvMaxPanes().toStr() + ")"
    m.addRing.visible = (m.area = "add")
    m.addStrip.translation = [Int((1920 - 528) / 2), m.gridBottom + 10]
end sub

' ---- The pane menu ----------------------------------------------------------

sub openMenu(i as integer)
    if i < 0 or i >= m.slots.count() then return
    m.menu = i
    m.area = "menu"
    m.menuIdx = 0
    m.dwellTimer.control = "stop"
    buildMenu(i)
    m.menuGroup.visible = true
    redrawRing()
end sub

sub closeMenu()
    m.menuGroup.visible = false
    m.menu = -1
    m.area = "grid"
    redrawRing()
end sub

' Android's seven buttons (multi_view_screen.dart:815-902), adapted.
'
'   Play sound   -> "Watch here". Sound follows the picture now, so moving the
'                   sound to a pane and moving the picture to it are the same
'                   act. Still first and still the default selection, so the
'                   commonest thing is still OK, OK.
'   Pause        -> kept. Only offered on the pane that actually has the
'                   decoder; the others are not playing to be paused.
'   Refresh      -> kept, and it is the ONLY way a failed pane is retried.
'   Audio        -> DROPPED. This app has no audio-track selection anywhere,
'                   deliberately: Roku never reports a track's codec, and on a
'                   codec failure it may not have parsed any tracks at all, so
'                   switching blind is just another doomed connection
'                   (PlayerScreen.brs, logAudioTracks). A button that cannot
'                   work is worse than no button.
'   Change channel -> kept.
'   Full screen  -> kept, and it makes the pane live: expanding a pane you are
'                   not watching to fill the screen and leaving it a still
'                   picture would be absurd.
'   Empty pane   -> kept. NOT the same as Remove — see clearPane/removePane.
'
' Laid out as a vertical column rather than Android's wrapped icon strip. That
' is the house pattern for a button stack on this app (ChannelDetailScreen)
' and it is unambiguous on a D-pad, where a two-dimensional wrap is not.
sub buildMenu(i as integer)
    r = innerRect(i)
    m.menuGroup.translation = [r.x, r.y]
    m.menuScrim.width = r.w
    m.menuScrim.height = r.h
    while m.menuCol.getChildCount() > 0
        m.menuCol.removeChildIndex(0)
    end while
    m.menuBtns = []

    slot = m.slots[i]
    specs = []
    if slot = invalid
        ' An empty pane offers the two things Android's _EmptySlot offers, and
        ' Remove disappears on the last pane because removing it would leave
        ' nothing at all.
        specs.push({ key: "change", text: "Add channel", enabled: true })
        specs.push({ key: "remove", text: "Remove pane", enabled: (m.slots.count() > 1) })
    else
        here = (i = m.live)
        if here
            specs.push({ key: "watch", text: "Watching here", enabled: false })
            if m.paused
                specs.push({ key: "playpause", text: "Resume", enabled: true })
            else
                specs.push({ key: "playpause", text: "Pause", enabled: true })
            end if
        else
            specs.push({ key: "watch", text: "Watch here", enabled: true })
            specs.push({ key: "playpause", text: "Pause", enabled: false })
        end if
        specs.push({ key: "refresh", text: "Refresh", enabled: true })
        specs.push({ key: "change", text: "Change channel", enabled: true })
        if m.expanded = i
            specs.push({ key: "expand", text: "Shrink", enabled: true })
        else
            specs.push({ key: "expand", text: "Full screen", enabled: true })
        end if
        specs.push({ key: "empty", text: "Empty pane", enabled: true })
    end if

    bw = 460
    if bw > r.w - 120 then bw = r.w - 120
    bh = 62
    gap = 10
    total = specs.count() * bh + (specs.count() - 1) * gap
    x = Int((r.w - bw) / 2)
    y = Int((r.h - total) / 2)
    if y < 12 then y = 12
    for each spec in specs
        ring = m.menuCol.createChild("Rectangle")
        ring.width = bw + 8
        ring.height = bh + 8
        ring.translation = [x - 4, y - 4]
        ring.color = m.theme.focusHighlight
        ring.visible = false
        bg = m.menuCol.createChild("Rectangle")
        bg.width = bw
        bg.height = bh
        bg.translation = [x, y]
        bg.color = m.theme.surfaceElevated
        lbl = m.menuCol.createChild("Label")
        lbl.width = bw
        lbl.height = bh
        lbl.translation = [x, y]
        lbl.horizAlign = "center"
        lbl.vertAlign = "center"
        lbl.font = m.menuFont
        if spec.enabled
            lbl.color = m.theme.textPrimary
        else
            lbl.color = m.theme.textSecondary
        end if
        lbl.text = spec.text
        m.menuBtns.push({ key: spec.key, enabled: spec.enabled, ring: ring })
        y = y + bh + gap
    end for

    ' Land on the first thing that can actually be pressed, so "Watching here"
    ' never eats the first OK.
    m.menuIdx = 0
    for j = 0 to m.menuBtns.count() - 1
        if m.menuBtns[j].enabled
            m.menuIdx = j
            exit for
        end if
    end for
    redrawMenu()
end sub

sub redrawMenu()
    for j = 0 to m.menuBtns.count() - 1
        m.menuBtns[j].ring.visible = (j = m.menuIdx)
    end for
end sub

sub moveMenu(delta as integer)
    n = m.menuBtns.count()
    if n = 0 then return
    j = m.menuIdx + delta
    while j >= 0 and j < n
        if m.menuBtns[j].enabled
            m.menuIdx = j
            redrawMenu()
            return
        end if
        j = j + delta
    end while
end sub

sub fireMenu()
    if m.menuBtns.count() = 0 then return
    b = m.menuBtns[m.menuIdx]
    if not b.enabled then return
    i = m.menu
    k = b.key
    if k = "watch"
        closeMenu()
        m.focus = i
        redrawRing()
        ' Immediate: the member said so. The dwell is for focus drift.
        commitTo(i, true)
    else if k = "playpause"
        closeMenu()
        togglePause()
    else if k = "refresh"
        closeMenu()
        m.focus = i
        redrawRing()
        commitTo(i, true)
    else if k = "change"
        openPicker(i)
    else if k = "expand"
        closeMenu()
        toggleExpand(i)
    else if k = "empty"
        closeMenu()
        clearPane(i)
    else if k = "remove"
        closeMenu()
        removePane(i)
    end if
end sub

' ---- Expand / shrink --------------------------------------------------------

sub toggleExpand(i as integer)
    if m.expanded = i then m.expanded = -1 else m.expanded = i
    relayout()
    if m.expanded >= 0
        m.focus = m.expanded
        if m.live <> i
            commitTo(i, true)
        else
            placeVideo(i)
        end if
    else
        placeVideo(m.live)
    end if
    if m.cover.visible then showCover(m.live, m.cover.state, m.cover.statusText)
    redrawRing()
    redrawPlate()
    redrawAddStrip()
end sub

' ---- Empty, Remove, Add, Change ---------------------------------------------

' Empty a pane but KEEP its space.
'
' Empty and Remove are two different operations and the split is deliberate
' (multi_view_screen.dart:413-414). The member arranged these panes; emptying
' one must not silently rearrange the other three behind their back. The space
' stays and says what can be done with it.
sub clearPane(i as integer)
    if i < 0 or i >= m.slots.count() then return
    m.slots[i] = invalid
    refreshPane(i)
    if i = m.live
        ' The picture cannot stay on an empty pane.
        n = firstFilled()
        if n < 0
            ' Every pane is empty now. There is nothing left to be here for.
            closeScreen()
            return
        end if
        commitTo(n, true)
    end if
    redrawPlate()
end sub

' Drop the pane altogether so the others expand into the space.
sub removePane(i as integer)
    n = m.slots.count()
    if i < 0 or i >= n then return
    if n <= 1
        closeScreen()
        return
    end if
    wasLive = (i = m.live)
    ' Removing a pane shifts every pane after it down one. Both indexes have
    ' to move with it or the picture ends up in the wrong box — see
    ' MvIndexAfterClose, which is the piece of this feature Android has
    ' dedicated unit tests for.
    newLive = MvIndexAfterClose(n, m.live, i)
    newFocus = MvIndexAfterClose(n, m.focus, i)
    m.slots.delete(i)
    if newLive < 0 then newLive = 0
    if newFocus < 0 then newFocus = 0
    m.live = newLive
    m.focus = newFocus
    ' The arrangement it was expanded out of no longer exists.
    m.expanded = -1
    relayout()
    if wasLive or m.slots[m.live] = invalid
        t = m.live
        if m.slots[t] = invalid then t = firstFilled()
        if t < 0
            closeScreen()
            return
        end if
        commitTo(t, true)
    else
        ' Same stream, new cell. Move the picture; do not reopen it.
        placeVideo(m.live)
    end if
    redrawRing()
    redrawPlate()
    redrawAddStrip()
end sub

function firstFilled() as integer
    for i = 0 to m.slots.count() - 1
        if m.slots[i] <> invalid then return i
    end for
    return -1
end function

' Add a WHOLE new pane, rather than filling one that already exists. Two side
' by side is where most people start, and wanting a third from there is the
' obvious next thought.
sub addPane()
    if m.slots.count() >= MvMaxPanes() then return
    openPicker(-1)
end sub

sub openPicker(target as integer)
    m.pickTarget = target
    closeMenu()
    m.picker = m.top.getScene().createChild("MultiViewPicker")
    m.picker.single = true
    m.picker.observeField("closed", "onPickerClosed")
    m.picker.setFocus(true)
    m.picker.start = true
end sub

sub onPickerClosed()
    res = ""
    if m.picker <> invalid
        res = m.picker.result
        m.top.getScene().removeChild(m.picker)
        m.picker = invalid
    end if
    m.keySink.setFocus(true)
    m.area = "grid"
    if res = "" then return
    arr = ParseJson(res)
    if arr = invalid then return
    picked = ToArray(arr)
    if picked.count() = 0 then return
    slot = picked[0]
    t = m.pickTarget
    if t < 0
        if m.slots.count() >= MvMaxPanes() then return
        m.slots.push(slot)
        relayout()
        m.focus = m.slots.count() - 1
    else
        if t >= m.slots.count() then return
        m.slots[t] = slot
        refreshPane(t)
        m.focus = t
    end if
    loadNow(m.focus)
    redrawRing()
    redrawAddStrip()
    commitTo(m.focus, true)
end sub

' ---- What is on now ---------------------------------------------------------
'
' Asked ONCE per pane and never again — a four-programme short EPG is a tiny
' answer and it is a data call, not a stream, so it costs the member's line
' nothing. The 60-second ticker rolls the line over from listings already
' held; it asks the provider nothing.

sub loadNow(i as integer)
    if i < 0 or i >= m.slots.count() then return
    slot = m.slots[i]
    if slot = invalid then return
    if GetField(slot, "isLive") <> true then return
    id = ToStr(GetField(slot, "id"))
    if m.epgAsked.doesExist(id)
        applyNow()
        return
    end if
    m.epgAsked[id] = true
    prov = ProviderForSrcToken(ToStr(GetField(slot, "src")))
    if prov = invalid then prov = ActiveProvider()
    if prov = invalid then return
    if ToStr(prov.ptype) = "m3u"
        ' An M3U source has no panel to ask; XMLTV is all there is, and it is
        ' already in memory if anything has loaded it this session. Nothing is
        ' downloaded from here — a guide file runs to tens of megabytes and
        ' Multi-View is not the screen to find that out on.
        m.listings[id] = xmltvListingsFor(slot)
        applyNow()
        return
    end if
    sid = ToStr(GetField(slot, "streamId"))
    if sid = "" then return
    task = CreateObject("roSGNode", "ApiTask")
    ' Tagged with the SLOT's id rather than the pane index: a pane can be
    ' removed while its request is in flight, and every index after it shifts.
    task.tag = id
    task.url = XtreamApiUrl(prov, "get_short_epg") + "&stream_id=" + UrlEncode(sid) + "&limit=4"
    task.observeField("result", "onNowEpg")
    m.epgTasks[id] = task
    task.control = "RUN"
end sub

sub onNowEpg(event as object)
    res = event.getData()
    id = ToStr(event.getRoSGNode().tag)
    m.epgTasks.delete(id)
    out = []
    if res <> invalid and res.ok = true
        for each e in ToArray(GetField(res.data, "epg_listings"))
            out.push({
                title: B64Decode(ToStr(GetField(e, "title")))
                startS: ToInt(GetField(e, "start_timestamp"))
                stopS: ToInt(GetField(e, "stop_timestamp"))
            })
        end for
    end if
    m.listings[id] = out
    applyNow()
end sub

' This channel's listings out of the session XMLTV cache. Joined by the
' playlist address, which is why a slot keeps the raw one: LivePlayUrl has
' rewritten the playable copy and it will not match anything.
function xmltvListingsFor(slot as object) as object
    if m.global.xmltvState <> "ready" then return []
    raw = ToStr(GetField(slot, "raw"))
    sid = ToStr(GetField(slot, "streamId"))
    tid = ""
    for each c in m.global.m3uChannels
        if (raw <> "" and ToStr(c.url) = raw) or (raw = "" and sid <> "" and ToStr(c.streamId) = sid)
            tid = ToStr(GetField(c, "tvgId"))
            exit for
        end if
    end for
    if tid = "" then return []
    if not m.global.xmltvById.doesExist(tid) then return []
    return m.global.xmltvById[tid]
end function

function nowTextFor(i as integer) as string
    if i < 0 or i >= m.slots.count() then return ""
    s = m.slots[i]
    if s = invalid then return ""
    id = ToStr(GetField(s, "id"))
    if not m.listings.doesExist(id) then return ""
    now = CreateObject("roDateTime").asSeconds()
    for each p in m.listings[id]
        if p.startS <= now and p.stopS > now then return "Now: " + ToStr(p.title)
    end for
    return ""
end function

sub applyNow()
    for i = 0 to m.panes.count() - 1
        m.panes[i].nowText = nowTextFor(i)
    end for
    if m.cover.visible and m.live >= 0 then m.cover.nowText = nowTextFor(m.live)
    redrawPlate()
end sub

sub onTick()
    applyNow()
end sub

' ---- Leaving ----------------------------------------------------------------

sub closeScreen()
    m.dwellTimer.control = "stop"
    m.spinTimer.control = "stop"
    m.slowTimer.control = "stop"
    m.tickTimer.control = "stop"
    ' A stream left running is a connection the member's provider still counts
    ' against their line.
    m.video.control = "stop"
    KLog("multiview", "closed")
    m.top.closed = true
end sub

' ---- Keys -------------------------------------------------------------------

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false

    ' Back is staged, exactly as Android stages it
    ' (multi_view_screen.dart:557-574): close the menu, then shrink what is
    ' expanded, and only then leave. A member pressing Back with the controls
    ' open means "close these", not "get me out of here".
    if m.area = "menu"
        if key = "back"
            closeMenu()
            return true
        else if key = "up"
            moveMenu(-1)
            return true
        else if key = "down"
            moveMenu(1)
            return true
        else if key = "OK"
            fireMenu()
            return true
        end if
        ' Swallow everything else: the menu is modal over its pane.
        return true
    end if

    if m.area = "add"
        if key = "up"
            m.area = "grid"
            redrawRing()
            redrawAddStrip()
            return true
        else if key = "OK"
            addPane()
            return true
        else if key = "back"
            closeScreen()
            return true
        end if
        return true
    end if

    ' The grid.
    if key = "back"
        if m.expanded >= 0
            toggleExpand(m.expanded)
            return true
        end if
        closeScreen()
        return true
    else if key = "OK"
        openMenu(m.focus)
        return true
    else if key = "play"
        togglePause()
        return true
    else if key = "up" or key = "down" or key = "left" or key = "right"
        moveFocus(key)
        return true
    end if
    return false
end function
