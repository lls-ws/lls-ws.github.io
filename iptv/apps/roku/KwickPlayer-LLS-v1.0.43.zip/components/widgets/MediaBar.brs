' Media Bar — the "pick up where you left off" panel across the top of Home.
' A port of Android's ContinueWatchingSpotlight; read that file
' (lib/ui/widgets/continue_watching_spotlight.dart) before changing the
' rules below, because every one of them came from there.
'
' Rotates through what you have not finished, one title at a time, and HOLDS
' STILL whenever the member is actually in it. Home owns what a press does;
' this panel only says which title it was.
'
' The artwork, the fades and the button row are all explained at the top of
' MediaBar.xml. Read that first — the geometry lives there.

sub init()
    m.theme = KwickTheme()

    m.keySink = m.top.findNode("keySink")
    m.dots = m.top.findNode("dots")

    ' ---- Artwork ------------------------------------------------------------
    ' Two modes, one of which is live per title — see the block at the top of
    ' MediaBar.xml. `backdrop` is the real landscape still when the title has
    ' one; `wash` + `hero` are the poster fallback for when it does not.
    m.backdrop = m.top.findNode("backdrop")
    m.wash = m.top.findNode("wash")
    m.washDim = m.top.findNode("washDim")
    m.hero = m.top.findNode("hero")

    ' How far back the dim holds the artwork, and it is NOT the same number
    ' for the two modes.
    '
    '   poster    about a third of the brightness left showing. Any more and
    '             the smear starts competing with the title; any less and the
    '             panel is a black box again, which is what it was reported
    '             for.
    '   backdrop  lighter, because a real still is already a wide low-contrast
    '             landscape rather than every colour in a poster smeared over
    '             each other. Held back as hard as the wash it would be a grey
    '             rectangle with a title on it, which is the whole complaint
    '             this change exists to answer. The readability scrim still
    '             does the actual work under the text.
    m.dimPoster = withAlpha(m.theme.background, 168)
    m.dimBackdrop = withAlpha(m.theme.background, 122)
    m.washDim.color = m.dimPoster

    ' Every ramp is a white alpha gradient tinted at draw time. See the
    ' blendColor note in the XML: white x background IS background, so one
    ' asset serves every colour and the alpha byte sets the strength.
    '
    ' Kept BOTH ways: the array is what the empty state sweeps, and the named
    ' handles are what the two modes switch between — washOut and heroIn are
    ' the join between the wash and the hero and there is no join to hide when
    ' a single backdrop spans the bar.
    m.artLayers = []
    for each pair in [["washOut", 255], ["heroIn", 255], ["readScrim", 255], ["edgeTop", 255], ["edgeBottom", 255], ["edgeRight", 198]]
        n = m.top.findNode(pair[0])
        n.blendColor = withAlpha(m.theme.background, pair[1])
        m.artLayers.push(n)
    end for
    m.washOut = m.top.findNode("washOut")
    m.heroIn = m.top.findNode("heroIn")
    ' The four that are up in BOTH modes. Held as a list so applyArtwork does
    ' not do four findNode lookups every ten seconds for the life of the app.
    m.sharedLayers = []
    for each name in ["readScrim", "edgeTop", "edgeBottom", "edgeRight"]
        m.sharedLayers.push(m.top.findNode(name))
    end for
    m.artNodes = [m.backdrop, m.wash, m.washDim, m.hero]
    for each n in m.artLayers
        m.artNodes.push(n)
    end for

    ' A stored backdrop url can go stale — a panel moves its images, a TMDB
    ' file is withdrawn — and a panel that draws nothing at all is worse than
    ' one drawing a poster. So a failed load is remembered for the rest of the
    ' session and that title falls back the way a title with no backdrop does.
    ' Nothing is written to the registry about it: the url may well work again
    ' tomorrow, and this is not worth a write.
    m.badArt = {}
    ' Case-SENSITIVE, which a BrightScript associative array is not by
    ' default. These keys are urls and a TMDB file name is mixed-case base62,
    ' so folding the case would let two different pictures share a slot.
    m.badArt.SetModeCaseSensitive()
    m.backdrop.observeField("loadStatus", "onBackdropLoad")

    ' The title's own lettering, drawn where the title text would go. Shares
    ' m.badArt with the backdrop above: a logo url that will not load is
    ' remembered for the session and that title goes back to plain text. The
    ' two can never collide in that map even for the same title, because a
    ' backdrop url carries w500 and a logo url carries w300.
    m.logo = m.top.findNode("titleLogo")
    m.logo.observeField("loadStatus", "onLogoLoad")
    ' Whether the logo is UP — the picture loaded and the text label has been
    ' taken down. Distinct from "this title has a logo path", which is what
    ' m.logoPath holds and what decides the subtext position; the gap between
    ' the two is the moment the image is still loading and the text is still
    ' the thing on screen.
    m.logoOn = false
    m.logoPath = ""
    ' What applyArtwork decided, read by applyTitle: the logo is drawn in
    ' backdrop mode and nowhere else (MediaBar.xml says why).
    m.hasBd = false

    ' ---- The second source of backdrops -------------------------------------
    ' Everything the lookup below needs to hold. Read the long block above
    ' armMetaDwell before touching any of it — the numbers are the whole
    ' argument. All of this is per LAUNCH and none of it is written anywhere.
    '
    ' Both maps are keyed by entryKey(), which ends in a panel's stream id.
    ' Case-sensitive for the same reason m.badArt is: two ids that differ only
    ' in case are two different titles, and a default BrightScript map would
    ' hand them the same slot.
    m.metaBd = {}          ' entry key -> "/xxxx.jpg", or "" for "asked, none"
    m.metaBd.SetModeCaseSensitive()
    m.metaLg = {}          ' entry key -> "/xxxx.png", or "" for "asked, none"
    m.metaLg.SetModeCaseSensitive()
    m.metaAsked = {}       ' entry key -> true, set when the request GOES OUT
    m.metaAsked.SetModeCaseSensitive()
    ' The most recent lookup, held rather than dropped — the same thing
    ' MovieDetailScreen does with its own. A reference to a Task released the
    ' instant it publishes its answer is a reference released while its thread
    ' is still unwinding, and there is exactly one of these at a time, so
    ' keeping it costs one node and settles the question.
    m.metaTask = invalid
    ' Whether one is out. Separate from the node above BECAUSE the node is
    ' kept: "is there a task object" and "is a request in flight" stopped being
    ' the same question the moment the answer was not to throw the node away.
    m.metaBusy = false
    ' WHICH title is in flight, not just whether one is. applyArtwork needs to
    ' tell "this title's backdrop may still be coming" from "this title has
    ' been asked about and the answer is in" - see backdropPending().
    m.metaBusyKey = ""
    m.metaCount = 0        ' how many have left this box since it launched
    m.metaOff = false      ' the service has no address; stop building tasks
    m.metaCapLogged = false
    m.metaDwell = invalid

    ' ---- Text ---------------------------------------------------------------
    m.eyebrow = m.top.findNode("eyebrow")
    ' NOT "CONTINUE WATCHING": the row of tiles directly under this panel is
    ' already called that, and two things on one screen with the same name
    ' reads as a mistake. This is the phone's own description of the widget
    ' ("the 'pick up where you left off' panel across the top of Home",
    ' continue_watching_spotlight.dart:165).
    m.eyebrow.text = "PICK UP WHERE YOU LEFT OFF"
    m.eyebrow.font = fontAt(20, true)
    m.eyebrow.color = m.theme.accent

    ' Regular, not bold, and 40 rather than 46 — the reported complaint was
    ' that the title read as heavy, and a 46px medium weight over a 24px
    ' secondary line was the biggest weight jump anywhere on Home. 40 stays:
    ' the box is 1020 wide over two wrapped lines, which in mono at 40 is
    ' still 42 characters a line, and applyTitle() MEASURES this label rather
    ' than assuming an advance, so the one-line/two-line decision follows the
    ' font automatically.
    m.titleFont = fontAt(40, false)
    m.titleLabel = m.top.findNode("titleLabel")
    m.titleLabel.font = m.titleFont
    m.titleLabel.color = m.theme.textPrimary
    m.titleLabel.wrap = true
    m.titleLabel.maxLines = 2
    m.titleLabel.lineSpacing = 4
    m.titleLabel.vertAlign = "top"

    m.descLabel = m.top.findNode("descLabel")
    ' 22, where this was 24. The box is 1020 wide and it is the ONE-LINE case
    ' that forces this, not the two-line one: when the title needs both its
    ' lines (or a logo is up) this label drops to maxLines 1, and the longest
    ' sentence describeEntry() can build — "You finished S01E12 - The Long
    ' Goodbye, so the next episode is ready to play." at 76 characters — is
    ' 1094px in mono at 24 and would have been cut off mid-sentence. At 22 it
    ' is 1003px and fits. Roboto at 24 measured about 912. Two lines at 22
    ' hold about 154 characters, which is more than the sentence plus its
    ' "Last watched ..." tail ever runs to.
    m.descLabel.font = fontAt(22, false)
    m.descLabel.color = m.theme.textSecondary
    m.descLabel.wrap = true
    m.descLabel.lineSpacing = 6
    ' CENTRED in its box, not top-aligned. The box is a fixed slot between the
    ' title and the meta line and the sentence in it is one line or two; top
    ' aligning put the whole of the slack in one gap underneath, which is the
    ' same "blank space" that was reported in the first place. Centring splits
    ' it, and half a gap above and below a line of text reads as spacing
    ' rather than as a hole.
    m.descLabel.vertAlign = "center"

    m.metaLabel = m.top.findNode("metaLabel")
    m.metaLabel.font = fontAt(22, true)
    m.metaLabel.color = m.theme.textSecondary
    m.metaLabel.maxLines = 1

    ' A Label that is never put on screen, used only to ask the font how wide
    ' a string is. It has to be UNCONSTRAINED: boundingRect on a Label that
    ' has been given a width reports the width it was given, not the width of
    ' the text — the trap MultiViewScreen.brs:471-473 already documents.
    m.measure = CreateObject("roSGNode", "Label")

    m.progTrack = m.top.findNode("progTrack")
    m.progFill = m.top.findNode("progFill")
    m.progLabel = m.top.findNode("progLabel")
    ' 20, where this was 22, and it is the only size in this panel the shell
    ' type moved. The caption is "54% watched  (S01E05 - Episode Title)" in a
    ' 700px box with maxLines 1, so it truncates rather than wraps: mono at
    ' 22 is 13.2px a character and fits 53, at 20 it is 12px and fits 58.
    ' Roboto at 22 fitted about 63. A long episode name still ellipsizes a
    ' few characters sooner than it did — UNVERIFIED on the television, and
    ' harmless when it happens because the same episode code is spelled out
    ' in the sentence directly above.
    m.progLabel.font = fontAt(20, false)
    m.progLabel.color = m.theme.textSecondary
    m.progLabel.maxLines = 1
    ' The unfilled part of the bar is the secondary text colour held back to
    ' about a third, exactly as the phone draws it.
    m.progTrack.color = withAlpha(m.theme.textSecondary, 76)
    m.progFill.color = m.theme.accent

    buildButtons()

    m.entries = []
    m.index = 0
    m.stops = ["resume", "info", "fav"]
    m.stop = 0
    m.currentKey = ""
    m.dotCount = -1
    m.engaged = false
    m.artKey = ""
    m.isFav = false

    m.timer = m.top.findNode("rotateTimer")
    m.timer.observeField("fire", "onTick")
    m.top.observeField("focusedChild", "onFocusChanged")
    render()
end sub

' The panel's type, now JetBrains Mono (Theme.brs UiFont/UiBoldFont). The
' `medium` flag used to pick Roboto-Medium over Roboto-Regular and now picks
' the bold face over the regular one, so every call site below keeps meaning
' what it meant: true = the loud half of a pair, false = the quiet half.
'
' THE WIDTH TAX, once, for the whole file. Mono's advance is a flat 0.6em
' where Roboto averaged about 0.5em, so every string got ~20% longer at the
' same point size. Each label was re-checked against its own box; only the
' progress caption needed a size change, and the reasons are written where it
' is built. The two labels that measure themselves at runtime — the Resume
' button (textWidth against m.btnFont) and the title's one-line/two-line test
' in applyTitle — need nothing, because they ask the font in hand rather than
' assuming an advance.
function fontAt(size as integer, medium as boolean) as object
    if medium then return UiBoldFont(size)
    return UiFont(size)
end function

' "0xRRGGBBAA" with the alpha replaced. Every colour in Theme.brs carries
' its own alpha byte, so it is swapped rather than appended.
function withAlpha(color as string, alpha as integer) as string
    h = "0123456789ABCDEF"
    a = alpha
    if a < 0 then a = 0
    if a > 255 then a = 255
    hi = Mid(h, Int(a / 16) + 1, 1)
    lo = Mid(h, (a mod 16) + 1, 1)
    return Left(color, 8) + hi + lo
end function

' How wide `text` is in `font`, in pixels. One detached node, reused.
function textWidth(text as string, font as object) as integer
    m.measure.font = font
    m.measure.text = text
    return Int(m.measure.boundingRect().width)
end function

' ---- The button row ---------------------------------------------------------
'
' Built once, here, rather than in the XML: there are five near-identical
' buttons of four nodes each and the Resume button is sized to its own label,
' which changes with the title. Positions and colours are set on every render;
' nothing is created or destroyed as the panel rotates.
'
' Each button is a rounded nine-patch PLATE, an optional hairline EDGE for the
' secondary ones, a focus RING drawn outside the plate, and its label or icon.
' The plates come from tools/make_mediabar_art.py. A flat Rectangle was what
' was reported as looking cheap and it is not used for a button anywhere in
' here now.
sub buildButtons()
    m.buttons = m.top.findNode("buttons")
    m.btnFont = fontAt(25, true)
    m.iconFont = IconFont(30)
    m.btn = {}

    for each name in ["resume", "info", "fav", "prev", "next"]
        b = {}
        ' The ring is created FIRST so it sits behind the plate: it is 5px
        ' proud on every side and would otherwise draw a bar across the label.
        b.ring = m.buttons.createChild("Poster")
        b.ring.uri = "pkg:/images/btn_focus.9.png"
        b.fill = m.buttons.createChild("Poster")
        b.fill.uri = "pkg:/images/btn_fill.9.png"
        b.edge = m.buttons.createChild("Poster")
        b.edge.uri = "pkg:/images/btn_edge.9.png"
        m.btn[name] = b
    end for

    ' Resume carries a play glyph as well as its words, which is what makes it
    ' read as the primary action from ten feet without relying on colour
    ' alone. The two are placed as one centred pair - see layoutButtons().
    b = m.btn.resume
    b.icon = m.buttons.createChild("Label")
    b.icon.font = m.iconFont
    b.icon.text = m.theme.iconPlay
    b.icon.height = 58
    b.icon.width = 34
    b.icon.horizAlign = "center"
    b.icon.vertAlign = "center"
    b.label = m.buttons.createChild("Label")
    b.label.font = m.btnFont
    b.label.height = 58
    b.label.horizAlign = "left"
    b.label.vertAlign = "center"

    b = m.btn.info
    b.label = m.buttons.createChild("Label")
    b.label.font = m.btnFont
    b.label.text = "More info"
    b.label.height = 58
    b.label.horizAlign = "center"
    b.label.vertAlign = "center"

    ' images/heart.png is white on transparent so blendColor tints it. It is
    ' an asset rather than a "heart" character because neither Roboto nor
    ' JetBrains Mono has U+2665
    ' and the device draws that as a missing-character box.
    b = m.btn.fav
    b.icon = m.buttons.createChild("Poster")
    b.icon.uri = "pkg:/images/heart.png"
    b.icon.width = 28
    b.icon.height = 28

    ' chevron_left / chevron_right. Both codepoints were read out of the
    ' bundled MaterialIcons-Regular.ttf character map before being used
    ' here, so neither can come out as an empty box.
    for each pair in [["prev", &hE5CB], ["next", &hE5CC]]
        b = m.btn[pair[0]]
        b.icon = m.buttons.createChild("Label")
        b.icon.font = m.iconFont
        b.icon.text = Chr(pair[1])
        b.icon.width = 58
        b.icon.height = 58
        b.icon.horizAlign = "center"
        b.icon.vertAlign = "center"
    end for
end sub

' Where the five buttons sit, left to right, in one run. Recomputed on every
' render because the Resume label changes length with the title.
sub layoutButtons()
    y = 256
    h = 58

    ' Resume, sized to its own words: the glyph, a gap, the text, and equal
    ' padding either side. Floored so a short label ("Resume") still looks
    ' like the primary button, capped so a long one ("Play next episode")
    ' cannot push the chevrons under the artwork.
    tw = textWidth(m.btn.resume.label.text, m.btnFont)
    w = tw + 34 + 8 + 44
    if w < 230 then w = 230
    if w > 400 then w = 400
    placeButton("resume", 0, y, w, h)
    inner = 34 + 8 + tw
    if inner > w - 20 then inner = w - 20
    ix = Int((w - inner) / 2)
    m.btn.resume.icon.translation = [ix, y]
    m.btn.resume.label.translation = [ix + 42, y]
    m.btn.resume.label.width = w - ix - 42

    x = w + 14
    placeButton("info", x, y, 196, h)
    m.btn.info.label.translation = [x, y]
    m.btn.info.label.width = 196

    x = x + 196 + 14
    placeButton("fav", x, y, h, h)
    m.btn.fav.icon.translation = [x + 15, y + 15]

    ' A 34px gap, then the pager pair 10px apart. The gap is what says "these
    ' two are a different kind of thing"; it is deliberately not big enough to
    ' feel like a journey, which is what the old far-edge chevrons were.
    x = x + h + 34
    placeButton("prev", x, y, h, h)
    ' Bracket access, not m.btn.next: `next` is how a BrightScript for loop can
    ' be closed, and a keyword after a dot is not worth finding out about on a
    ' device. "prev" is written the same way so the pair reads as a pair.
    m.btn["prev"].icon.translation = [x, y]
    x = x + h + 10
    placeButton("next", x, y, h, h)
    m.btn["next"].icon.translation = [x, y]
end sub

sub placeButton(name as string, x as integer, y as integer, w as integer, h as integer)
    b = m.btn[name]
    b.fill.translation = [x, y]
    b.fill.width = w
    b.fill.height = h
    b.edge.translation = [x, y]
    b.edge.width = w
    b.edge.height = h
    b.ring.translation = [x - 5, y - 5]
    b.ring.width = w + 10
    b.ring.height = h + 10
end sub

' The whole focus language of this panel, in one place.
'
' FOCUSED means the plate itself fills with the app's focus colour and the
' words on it go to the page colour — nord0 on nord yellow, about 11:1, which
' is the highest-contrast pairing the theme has and needs no ring to be
' found. The
' ring is still drawn, softly, just outside the plate, because on a poster
' background a filled shape alone can be lost against bright artwork.
'
' UNFOCUSED, Resume is the app accent (Android's FilledButton) and everything
' else is the elevated surface with a hairline edge (Android's OutlinedButton).
' Both take DARK ink on the accent fill — see the note in the branch below.
sub paintButton(name as string, focused as boolean, isFav as boolean)
    b = m.btn[name]
    b.ring.visible = focused
    b.ring.blendColor = withAlpha(m.theme.focusHighlight, 120)

    if focused
        b.fill.blendColor = m.theme.focusHighlight
        b.edge.visible = false
        ink = m.theme.background
    else if name = "resume"
        b.fill.blendColor = m.theme.accent
        b.edge.visible = false
        ' THE PAGE COLOUR, NOT WHITE, and this is fallout from the Nord port
        ' rather than a preference. The old accent was a mid blue (0x2086FF)
        ' that carried white text at about 4.3:1. Nord's accent is frost
        ' (0x88C0D0), a LIGHT colour: white on it is under 2:1, which is not
        ' readable at any distance, let alone across a room. nord0 on frost
        ' is about 6:1, and it is what the focused branch above already uses
        ' on the (lighter still) yellow fill — so the two states now differ
        ' by the PLATE colour alone, which is the cue that has to carry.
        ink = m.theme.background
    else
        b.fill.blendColor = m.theme.surfaceElevated
        b.edge.visible = true
        b.edge.blendColor = withAlpha(m.theme.textSecondary, 92)
        ink = m.theme.textPrimary
    end if

    if name = "fav"
        ' The heart has to say two things at once — where focus is, and
        ' whether the title is a favourite. Favourite red on the orange
        ' focus fill is unreadable, so while focused the state is carried by
        ' the heart being solid or ghosted instead of by its colour.
        if focused
            if isFav then b.icon.blendColor = m.theme.background else b.icon.blendColor = withAlpha(m.theme.background, 110)
        else
            if isFav then b.icon.blendColor = m.theme.favorite else b.icon.blendColor = m.theme.textSecondary
        end if
        return
    end if

    if b.icon <> invalid then b.icon.color = ink
    if b.label <> invalid then b.label.color = ink
end sub

sub showButton(name as string, shown as boolean)
    b = m.btn[name]
    b.fill.visible = shown
    if not shown
        b.edge.visible = false
        b.ring.visible = false
    end if
    if b.icon <> invalid then b.icon.visible = shown
    if b.label <> invalid then b.label.visible = shown
end sub

' ---- Entries ----------------------------------------------------------------

' ---- Guarded handlers (v1.0.41) ---------------------------------------------
'
' Every entry point the render thread can call on this panel now runs under
' try/catch and reports through GuardFailed (Util.brs), the same way the TV
' Guide and the channel page already do. A fault now leaves one line in the
' log - "crash averted in mediabar/<handler>", with the file, the line and the
' function - and arms the next-launch crash report, instead of the app dying
' with no stack at all.
'
' WHY THIS PANEL, IN PLAIN WORDS. Log key EB3CEB, an ATVIO 40-inch set on
' v1.0.40: the app stopped dead while the member was on Home. The last thing
' in their log was this file's "media bar backdrop would not load, falling back
' to the poster" line - the THIRD time in forty seconds that a title's picture
' had failed to download, on a panel rotating five titles. So: that television
' could not fetch the artwork for the titles in the panel, the panel fell back
' to the poster each time exactly as it is meant to, and on one of those falls
' the app died. The crash report could not say which line, because not one
' handler in this file was guarded. Now it can.
'
' GuardFailed IS REACHABLE HERE because MediaBar.xml names
' pkg:/source/utils/Util.brs (MediaBar.xml:258). A component only sees the
' scripts its own XML names, and that line is what makes these calls legal.
'
' init() IS DELIBERATELY NOT GUARDED, here or on Home or VOD. A fault in init
' leaves a panel with half its fields missing, and a guard there would turn
' one honest crash into every handler below faulting for the rest of the
' session. A crash in init is a crash that should be found and fixed.
sub onEntries()
    try
        onEntriesInner()
    catch e
        GuardFailed("mediabar/onEntries", e)
    end try
end sub

sub onEntriesInner()
    e = m.top.entries
    if e = invalid then e = []
    m.entries = e

    if m.entries.count() = 0
        m.index = 0
        m.currentKey = ""
        render()
        restartTimer()
        return
    end if

    ' Home rebuilds itself on reloadFromSync after every background sync.
    ' Hold the member's place through it: find the title that was on screen
    ' and stay on it, rather than snapping back to the first one under
    ' somebody's thumb.
    at = -1
    if m.currentKey <> ""
        for i = 0 to m.entries.count() - 1
            if entryKey(m.entries[i]) = m.currentKey then at = i
        end for
    end if
    if at >= 0
        m.index = at
    else if m.index >= m.entries.count()
        m.index = 0
    end if

    buildStops()
    render()
    restartTimer()
end sub

sub onRotateSeconds()
    try
        onRotateSecondsInner()
    catch e
        GuardFailed("mediabar/onRotateSeconds", e)
    end try
end sub

sub onRotateSecondsInner()
    restartTimer()
end sub

function entryKey(e as dynamic) as string
    if e = invalid then return ""
    return ToStr(e.kind) + "|" + ToStr(GetField(e, "src")) + "|" + ToStr(e.id)
end function

function current() as dynamic
    if m.entries.count() = 0 then return invalid
    if m.index < 0 or m.index >= m.entries.count() then return invalid
    return m.entries[m.index]
end function

' The focus stops, left to right, and they are the drawing order too — this
' panel has no directional traversal to fall back on, so the run on screen and
' the run under the D-pad have to be the same run.
'
' The chevrons only exist when there is somewhere to go, exactly as Android
' only draws them for more than one.
sub buildStops()
    many = (m.entries.count() > 1)
    stops = ["resume", "info", "fav"]
    if many
        stops.push("prev")
        stops.push("next")
    end if
    ' Keep the member on the same BUTTON across a rebuild where possible,
    ' rather than on the same index — the chevrons appearing or disappearing
    ' would otherwise shift what OK does under their thumb.
    was = ""
    if m.stops <> invalid and m.stop >= 0 and m.stop < m.stops.count() then was = m.stops[m.stop]
    m.stops = stops
    m.stop = 0
    for i = 0 to stops.count() - 1
        if stops[i] = was then m.stop = i
    end for
    ' Opens on Resume, like Android's autofocused detail button. It is also
    ' the first stop now, so Left out of the panel to the sidebar is one press
    ' from where focus lands.
    if was = "" then m.stop = 0
end sub

' ---- Rotation ---------------------------------------------------------------

' Rotating under the remote is worse than not rotating at all: focus stays
' on Resume while the title behind it changes, so OK launches something the
' viewer never chose. Whenever they are actually in the panel, it holds
' still.
sub restartTimer()
    m.timer.control = "stop"
    if m.entries.count() < 2 or m.engaged then return
    secs = m.top.rotateSeconds
    if secs < 1 then secs = 10
    m.timer.duration = secs
    m.timer.control = "start"
end sub

' Pause on real interaction only. Keying off focus alone would mean the
' panel is marked "engaged" the moment Home hands it focus on the very first
' frame, so the timer would never start and it would never rotate at all —
' the exact bug the Android comment records.
sub setEngaged(v as boolean)
    if m.engaged = v then return
    m.engaged = v
    restartTimer()
end sub

sub onFocusChanged()
    try
        onFocusChangedInner()
    catch e
        GuardFailed("mediabar/onFocusChanged", e)
        ' LOGGED AND NOTHING ELSE, on purpose. This is the focusedChild
        ' observer, so moving focus from in here fires it again - a handler
        ' that faults every time would then recurse until the stack gave out,
        ' which is a worse crash than the one being guarded. Leaving it alone
        ' is safe: focus stays on this panel's own node, so onKeyEvent still
        ' fires and Down, Up and Back still reach Home.
    end try
end sub

sub onFocusChangedInner()
    if m.top.isInFocusChain()
        ' Home hands focus to the panel node; the key sink is what actually
        ' holds it, so the arrow keys have somewhere to land.
        if m.top.hasFocus() then m.keySink.setFocus(true)
    else
        setEngaged(false)   ' moved away: free to rotate again
    end if
    redrawFocus()
end sub

sub onTick()
    try
        onTickInner()
    catch e
        GuardFailed("mediabar/onTick", e)
        ' STOP THE ROTATION after a caught fault, and this is the one guard in
        ' this file that changes what the member sees.
        '
        ' This timer fires every ten seconds and GuardFailed writes to the
        ' registry on every catch. A panel that faults on every tick would
        ' spend the rest of the session writing to flash and would bury the
        ' one line naming the fault under a hundred identical copies of it -
        ' which is the opposite of why these guards exist. The panel instead
        ' holds on the title it is on, a state it already has (it holds still
        ' whenever the member is standing in it), and all the member loses is
        ' the rotation until they reopen the app.
        m.timer.control = "stop"
    end try
end sub

sub onTickInner()
    if m.entries.count() < 2 then return
    m.index = (m.index + 1) mod m.entries.count()
    render()
end sub

sub go(delta as integer)
    if m.entries.count() < 2 then return
    n = m.entries.count()
    m.index = (m.index + delta) mod n
    if m.index < 0 then m.index = m.index + n
    render()
    restartTimer()   ' a manual move restarts the dwell, never cuts it short
end sub

' ---- Drawing ----------------------------------------------------------------

sub render()
    e = current()
    have = (e <> invalid)

    if not have
        ' Nothing to continue: the panel draws NOTHING AT ALL, no frame, no
        ' placeholder. Home does not even build it in that case; this is the
        ' path where the last title was removed under a member standing in it.
        for each n in m.artNodes
            n.visible = false
        end for
        m.eyebrow.visible = false
        m.titleLabel.visible = false
        m.descLabel.visible = false
        m.metaLabel.visible = false
        m.progTrack.visible = false
        m.progFill.visible = false
        m.progLabel.visible = false
        m.buttons.visible = false
        m.dots.visible = false
        ' The uri, not just the visibility: blanking it is what actually
        ' releases the texture on this box.
        m.backdrop.uri = ""
        m.wash.uri = ""
        m.hero.uri = ""
        ' The logo is not in m.artNodes — that list is the artwork LAYERS and
        ' the sweep above is about them — so it is taken down by name, both
        ' ways, like every other picture here.
        m.logo.visible = false
        m.logo.uri = ""
        m.logoOn = false
        m.logoPath = ""
        m.hasBd = false
        m.artKey = ""
        return
    end if

    m.eyebrow.visible = true
    ' titleLabel is NOT turned on here. applyTitle below owns it, because
    ' whether the title is text or lettering is its decision and turning the
    ' text on first would only mean turning it off again a few lines later.
    m.descLabel.visible = true
    m.metaLabel.visible = true
    m.progLabel.visible = true
    m.buttons.visible = true

    m.currentKey = entryKey(e)
    series = (ToStr(e.kind) = "series")
    ' Read ONCE per title, not once per focus redraw. redrawFocus() runs on
    ' every arrow press and this is a registry read; a member holding Right
    ' down would otherwise be opening the favourites section five times a
    ' second against a 250 ms response budget (certification 3.5).
    m.isFav = IsFavoriteVod(ToStr(e.kind), ToStr(e.id), ToStr(GetField(e, "src")))

    applyArtwork(e)
    applyTitle(e)

    posS = ToInt(e.pos)
    dur = ToInt(e.dur)
    pct = MediaBarPercent(posS, dur)
    m.descLabel.text = describeEntry(e, series, pct)

    ' "Series · KwickTV". Android's line also carries a star rating, the
    ' year, the certificate and up to three genres; none of those exist on
    ' this device without asking the panel about the title, per tile, on
    ' every render — see the note in HomeScreen.brs. Type is always there,
    ' so the line never collapses to nothing.
    parts = []
    if series then parts.push("Series") else parts.push("Movie")
    if SourceCount() > 1
        label = SourceLabelFor(ToStr(GetField(e, "src")))
        if label <> "" then parts.push(label)
    end if
    line = ""
    for each p in parts
        if line = "" then line = p else line = line + "  " + Chr(&hB7) + "  " + p
    end for
    m.metaLabel.text = line

    ' PROGRESS. The row keeps its space either way.
    '
    ' With no percentage there is nothing to caption. The label sits at x=278,
    ' which is the space to the RIGHT of the progress bar - so on a title with
    ' no stored position it drew the bare episode number floating in the middle
    ' of the panel beside nothing, and said it twice, because the subtext line
    ' above already reads "You are partway through S01E01."
    if pct >= 0
        m.progLabel.text = MediaBarProgressLabel(pct, ToStr(GetField(e, "sub")))
    else
        m.progLabel.text = ""
    end if
    if pct >= 0
        m.progTrack.visible = true
        m.progFill.visible = true
        m.progFill.width = Int(260 * pct / 100)
    else
        m.progTrack.visible = false
        m.progFill.visible = false
        m.progFill.width = 0
    end if

    m.btn.resume.label.text = resumeText(e, series)
    layoutButtons()

    buildDots()
    redrawFocus()

    ' A different title is on screen. START A COUNTDOWN, not a request — see
    ' the block above armMetaDwell. This is the ONLY place the lookup is armed
    ' from, and render() is the only thing that changes which title is showing,
    ' so the two cannot drift apart.
    armMetaDwell()
end sub

' ---- The artwork ------------------------------------------------------------
'
' Picks ONE of the two arrangements described at the top of MediaBar.xml and
' takes the other one's urls away.
'
' THE ONE RULE THAT MATTERS: `visible = false` does not free a texture on this
' box; blanking the uri does. So the mode that is not in use is left holding
' the empty string, and the two never cost memory at the same time. That is
' what lets the backdrop REPLACE the wash-and-hero pair's 376,704 bytes rather
' than be added to them.
'
' NOTHING HERE ASKS ANYONE FOR ANYTHING, and that has not changed. This sub
' draws with what is in hand: `e.bd` off the recents row, or an answer the
' lookup below already brought back and put in m.metaBd. It never starts one.
' The request is armed by a timer at the end of render() and nowhere else, so
' a redraw, a focus move or a failed image load cannot become a fetch.
'
' TWO SOURCES, IN THIS ORDER:
'
'   e.bd       the panel's own still, captured by MovieDetailScreen.applyInfo /
'              SeriesDetailScreen.onInfo when the member OPENED that title, and
'              stored on the recents row. Free, already read, and describes
'              this exact copy of the title on this exact panel — so it wins.
'   m.metaBd   what titlemeta.php answered for a title nobody has opened, which
'              is most of them and was the whole complaint. Session only: the
'              durable copy is the seven-day cachefs row behind it.
sub applyArtwork(e as object)
    try
        applyArtworkInner(e)
    catch ex
        GuardFailed("mediabar/applyArtwork", ex)
        ' EB3CEB's path. Put the artwork into the one state that is always
        ' safe AND always complete: no picture at all, which is exactly what
        ' this panel draws for a title it has no artwork for.
        '
        ' Set BOTH ways, every node, because the fault can land halfway
        ' through the real sub - a node left merely hidden keeps the previous
        ' title's size and colour and flashes it on the next rotation. The
        ' uris are blanked as well as hidden because on this box blanking the
        ' uri is what actually frees the texture.
        '
        ' Nothing in here can be the next uncaught fault: every node it
        ' touches is found in init() and written to in init(), so if any of
        ' them were invalid init would have died long before this.
        m.artKey = ""
        m.hasBd = false
        m.backdrop.uri = ""
        m.wash.uri = ""
        m.hero.uri = ""
        m.backdrop.visible = false
        m.wash.visible = false
        m.hero.visible = false
        m.washOut.visible = false
        m.heroIn.visible = false
        m.washDim.visible = false
        m.washDim.color = m.dimPoster
        for each n in m.sharedLayers
            n.visible = false
        end for
    end try
end sub

sub applyArtworkInner(e as object)
    bd = ""
    poster = ""
    if not MediaBarMemoryTight()
        ' BackdropUrl puts the host and the size back on the short form the
        ' registry holds (Store.brs). The looked-up one is the SAME short form
        ' — TMDB's own path fragment — so one call serves both and the width
        ' this app decodes at stays one constant in one place.
        ' RecentBackdropUrl rather than BackdropUrl for the row's own picture:
        ' a title off a member's Jellyfin or Emby stores the marker "ms" and
        ' the address is rebuilt from the row's server and id (Store.brs). The
        ' looked-up one is still TMDB's short form and goes the old way.
        bd = RecentBackdropUrl(e)
        if bd = "" then bd = BackdropUrl(ToStr(m.metaBd[entryKey(e)]))
        ' A url this session has already watched fail is treated as absent, so
        ' that title falls back for good rather than flashing an empty strip
        ' every time it comes round again.
        if bd <> "" and m.badArt[bd] <> invalid then bd = ""
        ' The poster is loaded ONLY as the fallback. Loading both so the
        ' backdrop could "fade in over" the poster would mean paying for both
        ' at once on every rotation, which is the one thing this panel may not
        ' do.
        '
        ' >>> AND NOT EVEN AS A FALLBACK WHILE THE ANSWER IS STILL COMING.
        '     Fixed 2026-08-26. <<< THE OWNER'S WORDS: "the mediabar is pulling
        '     the poser and then immediatly changing the image to the correct
        '     one, it shouldnt pull the damn poster it looks broken when it
        '     does that behavior".
        '
        ' He is describing this sub running TWICE for one title. On the
        ' rotation there is no backdrop in hand yet, so it fell straight to the
        ' poster and drew it; ~600ms later the dwell timer's lookup answered,
        ' onMetaResult forced a re-assign, and the poster was replaced by the
        ' backdrop in front of him. Nothing was broken - it was two correct
        ' draws, and the first one should never have happened.
        '
        ' So the poster is only reached once a backdrop can no longer arrive
        ' for this title. While one might, the panel draws NO artwork at all
        ' and comes up on the still - blank to the right picture, rather than
        ' the wrong picture to the right picture.
        if bd = "" and not backdropPending(e)
            ' The same TMDB rewrite the detail pages use, so a 600x900 source
            ' comes down as a 500-wide one. Both Posters are given the same
            ' string, so the download is shared even though the decodes are not.
            poster = DetailPosterUrl(ToStr(e.icon))
        end if
    end if

    ' Re-assigned only when it actually changed. A rotation back onto the same
    ' title, or a redraw, must not make the device fetch and decode the picture
    ' again.
    key = bd + "|" + poster
    if key <> m.artKey
        m.artKey = key
        m.backdrop.uri = bd
        m.wash.uri = poster
        m.hero.uri = poster
    end if

    hasBd = (bd <> "")
    hasPoster = (poster <> "")
    hasArt = (hasBd or hasPoster)
    ' Read by applyTitle, which draws the logo in backdrop mode and nowhere
    ' else. Set here rather than worked out again there so the two can never
    ' disagree about which mode the panel is in.
    m.hasBd = hasBd

    m.backdrop.visible = hasBd
    m.wash.visible = hasPoster
    m.hero.visible = hasPoster
    ' washOut and heroIn exist to hide the SEAM between the wash and the hero.
    ' A backdrop has no seam — it is one picture across the whole bar — and
    ' leaving them up would paint two soft vertical bands of page colour down
    ' the middle of it for no reason.
    m.washOut.visible = hasPoster
    m.heroIn.visible = hasPoster

    ' Everything below here is shared and behaves the same in both modes.
    m.washDim.visible = hasArt
    if hasBd then m.washDim.color = m.dimBackdrop else m.washDim.color = m.dimPoster
    for each n in m.sharedLayers
        n.visible = hasArt
    end for
end sub

' Might a backdrop still turn up for this title in this session?
'
' TRUE only while there is something left to wait for. Every answer here is
' already sitting in memory - no request is started, nothing is read from the
' registry, and it runs on the render thread inside applyArtwork.
'
' It has to be bounded on BOTH sides. Answer TRUE too readily and a title with
' no backdrop shows an empty bar for ever; answer FALSE too readily and the
' poster flashes up again, which is the whole bug. So it waits for exactly two
' states and nothing else: "not asked yet" and "asked, and this is the one in
' flight". Once the request has come back - with a backdrop, with "" for "the
' catalogue has none", or with an outright failure - there is nothing more
' coming and the poster is the right answer.
'
' The paths that can never produce a backdrop say so immediately, so they fall
' straight to the poster with no blank frame at all: no address configured, a
' box already short of memory, this launch's lookup budget spent, or a row with
' no key or no name to look anything up by. Those are the same four gates
' onMetaDwell applies before it will ask.
function backdropPending(e as object) as boolean
    if m.metaOff then return false
    if MediaBarMemoryTight() then return false
    if m.metaCount >= MediaBarMetaMaxPerLaunch() then return false
    key = entryKey(e)
    if key = "" then return false
    if ToStr(e.name).trim() = "" then return false
    ' Asked and answered - m.metaBd holds the answer, "" included, and
    ' applyArtwork has already preferred it if there was one.
    if m.metaBd[key] <> invalid then return false
    ' Asked, and the reply for THIS title has not landed yet.
    if m.metaBusy and m.metaBusyKey = key then return true
    ' Never asked. The dwell timer is re-armed on every rotation and every
    ' render, so this resolves on its own.
    if m.metaAsked[key] = invalid then return true
    ' Asked, not in flight, and no answer was filed - the request failed. It is
    ' marked asked for good (once per launch, not once per rotation), so
    ' nothing further is coming.
    return false
end function

' ---- The title, as lettering or as text --------------------------------------
'
' Android draws the show's own wordmark where the title would go and falls back
' to plain text when there is none (continue_watching_spotlight.dart:852). This
' is that, with two differences that come from the platform rather than from
' taste.
'
' IT IS DRAWN IN BACKDROP MODE ONLY. A logo is a second texture on a screen this
' app has five out-of-memory crash reports against, and poster mode already
' spends the whole budget. The other half of the reason is that poster mode
' already shows the title — it is written across the hero poster at the
' right-hand end — so a wordmark on the left would be the same name twice. Both
' arguments are set out in full in MediaBar.xml.
'
' THE LAYOUT IS DECIDED BY THE PATH, NOT BY THE PICTURE. The subtext sits at
' y=150 the moment a logo path is in hand, which is before the image has
' loaded and possibly before it ever does. Waiting for the bitmap would mean
' the subtext, the meta line and the progress row all jumping down the instant
' the lettering appeared, on every rotation — the same class of complaint the
' fixed-height slot on the phone exists to prevent. So the space is committed
' first and the text label simply stops being visible when the logo is ready.
'
' WHICH MEANS THE FALLBACK IS FREE. m.titleLabel always holds the title, in the
' right font, at the right size, whether or not a logo is coming. Nothing has to
' be rebuilt if the picture never arrives — it is already there underneath.
sub applyTitle(e as object)
    try
        applyTitleInner(e)
    catch ex
        GuardFailed("mediabar/applyTitle", ex)
        ' The title in plain text, which is the state this panel is designed
        ' to fall back to and the one that always reads correctly. Lettering
        ' off and its uri blanked (that is what frees the texture), the text
        ' label on, and the subtext put back in its one-line-title position so
        ' nothing below it moves. 86 is 182 - 96, the same arithmetic the real
        ' sub uses.
        '
        ' The name is re-read through GetField rather than left alone: if the
        ' fault landed on the very first statement the label would still be
        ' holding the PREVIOUS title's name, and a panel naming the wrong film
        ' is worse than one naming none. GetField answers invalid for anything
        ' it cannot read and ToStr turns that into "", so this cannot fault.
        m.titleLabel.text = ToStr(GetField(e, "name"))
        m.logo.visible = false
        m.logo.uri = ""
        m.logoOn = false
        m.logoPath = ""
        m.titleLabel.visible = true
        m.descLabel.maxLines = 2
        m.descLabel.translation = [0, 96]
        m.descLabel.height = 86
    end try
end sub

sub applyTitleInner(e as object)
    title = ToStr(e.name)
    m.titleLabel.text = title

    ' The path, not the picture. "" covers every "no": no logo for this title,
    ' no answer yet, poster mode, memory tight, or a url this session has
    ' already watched fail.
    path = ""
    if m.hasBd then path = ToStr(m.metaLg[entryKey(e)])
    url = mediaBarLogoUrl(path)
    if url <> "" and m.badArt[url] <> invalid then url = ""

    if url = "" and m.logoPath <> ""
        ' Coming off a logo. The uri, not just the visibility — that is what
        ' releases the texture on this box.
        m.logo.visible = false
        m.logo.uri = ""
        m.logoOn = false
    else if url <> "" and url <> ToStr(m.logo.uri)
        ' A different logo. Hidden until its own load says it is ready, so the
        ' node is never on screen at the previous title's size.
        m.logoOn = false
        m.logo.visible = false
        m.logo.uri = url
    end if
    m.logoPath = url

    ' Whichever is up, the title label is visible only while the logo is not.
    m.titleLabel.visible = not m.logoOn

    ' The subtext starts directly under whichever line the title ended on.
    ' Reserving two lines and always starting the subtext below both of them is
    ' what left the hole that was reported; measuring instead closes it. A logo
    ' takes the two-line position — it is the tallest thing that can sit there
    ' and committing to it up front is what stops the panel reflowing when the
    ' lettering lands. Nothing BELOW the subtext moves in any of the three
    ' cases: the box always ends at y=182.
    if url <> "" or textWidth(title, m.titleFont) > 1020
        descY = 150
        m.descLabel.maxLines = 1
    else
        descY = 96
        m.descLabel.maxLines = 2
    end if
    m.descLabel.translation = [0, descY]
    m.descLabel.height = 182 - descY
end sub

' The stored form -> something a Poster can load, the logo's own version of
' BackdropUrl(). It is here rather than beside that one because the size is this
' screen's choice and this is the only screen that draws a logo.
'
' w300 AND NOT w500, and the two numbers are not independent. The Poster below
' decodes at loadWidth=200, so w300 is the smallest TMDB size that still feeds
' that decode without the decoder inventing detail — and, like the backdrop,
' this is re-fetched every time the panel rotates back onto the title, so the
' bytes off the wire are not a one-off.
'
' Anything that is not a leading-slash TMDB fragment is refused rather than
' guessed at. Both ends already hold this field to that shape; this is the last
' place it could still be wrong, and the cost of being wrong is a television
' fetching somewhere nobody chose.
function mediaBarLogoUrl(stored as string) as string
    s = stored.trim()
    if s = "" then return ""
    if Left(s, 1) <> "/" then return ""
    if Instr(1, s, "://") > 0 then return ""
    return "https://" + TmdbImageHost() + "w300" + s
end function

' A stored backdrop that will not load. Remember the url, and redraw the
' current title so it falls back to its poster.
'
' loadStatus fires on EVERY state change, including the blanking this sub
' itself causes — so the already-known check is what stops it re-entering on
' its own write. A blank url leaves immediately.
'
' "ready" IS ALSO HANDLED NOW, and that is the framing. See
' mediaBarFrameBackdrop below.
sub onBackdropLoad()
    try
        onBackdropLoadInner()
    catch e
        GuardFailed("mediabar/onBackdropLoad", e)
        ' EB3CEB died with this sub's own log line as the last thing in the
        ' file, so whatever it was happened in the four statements after that
        ' line: current(), the forced re-assign, applyArtwork and applyTitle.
        ' Those last two carry their own guards and their own safe states, so
        ' there is nothing left for this one to put right - it names the
        ' statement and leaves the panel as it was a moment before.
    end try
end sub

sub onBackdropLoadInner()
    status = ToStr(m.backdrop.loadStatus)
    if status = "ready"
        mediaBarFrameBackdrop()
        return
    end if
    if status <> "failed" then return
    url = ToStr(m.backdrop.uri)
    if url = "" then return
    if m.badArt[url] <> invalid then return
    m.badArt[url] = true
    KLog("home", "media bar backdrop would not load, falling back to the poster")
    e = current()
    if e = invalid then return
    ' Force the re-assign: the key still describes the backdrop that failed.
    m.artKey = ""
    applyArtwork(e)
    ' Backdrop mode has just ended, and the logo only exists inside it.
    applyTitle(e)
end sub

' ---- WHICH BAND OF THE STILL IS KEPT ----------------------------------------
'
' THE COMPLAINT. "i wish shows had a banner we could use for the media bar so
' the images would fit better". The bar is 1690 x 330, which is 5:1. A TMDB
' backdrop is 16:9. Fitted across the full width the still is 950 tall, so 620
' rows of it — 65% — have to go, and there is no banner-shaped artwork anywhere
' in the catalogue to avoid that with. What CAN be chosen is which 35% stays,
' and until now it was not chosen at all: scaleToZoom crops from the centre and
' a Roku Poster has no alignment property to say otherwise.
'
' WHAT THE PHONE DOES, AND WHY IT IS NOT COPIED. Android draws this with
' BoxFit.cover and Alignment.topCenter (continue_watching_spotlight.dart:803) —
' top aligned. That reads as the obvious answer and it is the wrong one here,
' because the two are not keeping the same amount of picture. The phone's card
' is roughly 3:1, so covering it keeps about 56% of a 16:9 frame, and 56% taken
' from the top still reaches well past the eye line. This bar keeps 35%. Taken
' from the top, 35% of a film still is sky, ceiling, the tops of people's heads,
' and faces cut off at the mouth. Top-aligning a strip this thin is worse than
' the centre crop it would replace, and copying the phone's property without
' copying the phone's proportions is how that mistake gets made.
'
' WHAT IS DONE INSTEAD: the band is centred at 42% of the frame's height rather
' than at 50%.
'
' 42% comes from where things actually are in a photograph. Subjects sit above
' the middle — the rule-of-thirds eye line is at 33% and a standing figure's
' head and shoulders occupy roughly 25% to 55%. A band centred on 50% runs from
' 32.6% to 67.4%, which puts the eye line exactly on its top edge and spends its
' bottom third on floor. Centred on 42% it runs from 24.6% to 59.4%: the eye
' line is comfortably inside it, the whole head-and-shoulders region is inside
' it, and it still stops short of both the empty top of the frame and the empty
' bottom. On a 950-tall fit that is the window moved up 76 pixels — about 8% of
' the frame. It is a nudge, deliberately, and not a lurch: a big shift would
' start decapitating the wide establishing shots that centre crops handle fine.
'
' HOW, given a Poster with no alignment property. The Poster is no longer asked
' to crop anything. It is given the still's OWN full height, so scaleToFill fits
' a box of exactly the source's aspect and nothing is squashed, and the
' backdropWindow Group around it clips that down to the 330-tall strip. Its
' translation inside the Group is then the alignment control the Poster does not
' have. This costs no texture at all — loadWidth decides what is decoded, and
' stretching that bitmap across a taller node and clipping it is the GPU's work.
'
' THE SHAPE IS READ FROM THE BITMAP, not assumed, because "backdrop" fields in
' the wild hold 3:2 stills and the occasional 4:3 one. Only the RATIO of
' bitmapWidth to bitmapHeight is used, and that is deliberate: whether those
' report the source size or the decoded one, the ratio is the same number, so
' this cannot be wrong about which of the two it is being handed.
'
' IF THEY COME BACK AS NOTHING this leaves without touching anything, and what
' stays is the 16:9 default already in the XML — the same framing this would
' have chosen for a 16:9 still anyway. There is no bad outcome to fall into.
'
' The clamp at the end is what stops a source SHORTER than the strip (there is
' no such thing among real backdrops, but a panel can put anything in that
' field) from being pulled off the top of its own window and showing a band of
' nothing.
sub mediaBarFrameBackdrop()
    bw = ToInt(m.backdrop.bitmapWidth)
    bh = ToInt(m.backdrop.bitmapHeight)
    if bw <= 0 or bh <= 0 then return

    ' The height this still has when it is fitted across the whole bar.
    h = Int(1690 * bh / bw)
    if h < 330 then h = 330

    ' Put the middle of the window on 42% of the picture, then keep the window
    ' inside the picture.
    y = Int(h * 42 / 100) - 165
    if y > h - 330 then y = h - 330
    if y < 0 then y = 0

    m.backdrop.height = h
    m.backdrop.translation = [0, -y]
end sub

' The lettering has loaded, or it has not.
'
' READY is where the node finally gets its real size. A logo can be anything
' from 2:1 to 10:1 and nothing on this box knows which until the bitmap is in
' hand, so the box it is drawn in is worked out here rather than written into
' the XML: the largest that fits inside 420 x 96 at the picture's own aspect,
' flush left, centred in the 96-tall band so a very wide short logo does not
' hang from the top of a gap.
'
' scaleToFill into a box of exactly the right aspect is what keeps the lettering
' undistorted. scaleToFit would do the aspect work itself and was not used
' because it CENTRES what it fits — the logo has to line up flush left with the
' eyebrow above it and the subtext below it, and a 420-wide box with a 190-wide
' logo floating in the middle of it does not.
'
' FAILED is the same contract the backdrop has: remember the url for the
' session, take the picture down, and let the text label come back. A logo is
' decoration on a panel that already reads correctly without one.
sub onLogoLoad()
    try
        onLogoLoadInner()
    catch e
        GuardFailed("mediabar/onLogoLoad", e)
    end try
end sub

sub onLogoLoadInner()
    status = ToStr(m.logo.loadStatus)
    url = ToStr(m.logo.uri)
    if url = "" then return

    if status = "ready"
        if not mediaBarFitLogo()
            ' Ready, and yet nothing to measure. Nothing should be able to
            ' produce this, which is exactly why the texture is handed back
            ' rather than left held by an invisible node — an unexplained
            ' picture quietly costing memory on this screen is the one thing
            ' this panel cannot afford to have lying around.
            m.logo.uri = ""
            m.logoPath = ""
            return
        end if
        m.logoOn = true
        m.logo.visible = true
        m.titleLabel.visible = false
        return
    end if

    if status <> "failed" then return
    if m.badArt[url] <> invalid then return
    m.badArt[url] = true
    KLog("home", "media bar title logo would not load, falling back to the title in text")
    e = current()
    if e = invalid then return
    applyTitle(e)
end sub

' The logo's box, from the bitmap's own shape. Returns false when there is
' nothing usable to size, which the caller treats as "leave the text up".
function mediaBarFitLogo() as boolean
    bw = ToInt(m.logo.bitmapWidth)
    bh = ToInt(m.logo.bitmapHeight)
    if bw <= 0 or bh <= 0 then return false

    maxW = 420
    maxH = 96
    w = maxW
    h = Int(maxW * bh / bw)
    if h > maxH
        h = maxH
        w = Int(maxH * bw / bh)
    end if
    if w < 1 or h < 1 then return false

    m.logo.width = w
    m.logo.height = h
    ' Flush left, centred in the band the title text would have occupied.
    m.logo.translation = [0, 42 + Int((maxH - h) / 2)]
    return true
end function

' ---- Backdrops for titles nobody has opened ---------------------------------
'
' THE COMPLAINT THIS ANSWERS. The panel prefers a landscape still over a
' stretched portrait poster, and it was right to. But the only still it had
' came off the recents row, and a recents row only learns one when the member
' OPENS that title's detail page — so on a television that has been running for
' months, every row predates the feature and the panel drew a poster for every
' single title. It read as not done, because from the sofa it was.
'
' WHERE THE SECOND ONE COMES FROM. titlemeta.php, the same endpoint the film
' page asks for its rating badges, through the same TitleMetaTask and into the
' same seven-day cachefs row. It answers with `bd` — TMDB's own path fragment,
' no host and no size on it — and BackdropUrl() turns that into a url exactly
' as it does for a stored one. No second cache was built and none was needed.
'
' AND WITH `lg`, IN THE SAME ANSWER. The title's own lettering, added later and
' deliberately given no machinery of its own: same request, same ledger, same
' maps, same 600 ms dwell, same ceilings. There is no such thing as a lookup for
' a logo in this file — there is one lookup per title, and it comes back with
' both pictures or with neither. Everything counted below is unchanged by it.
'
' ==== THE RULE, AND WHY THIS IS NOT A BREACH OF IT ===========================
'
' NEVER A REQUEST PER ROTATING TILE. That is the rule this whole panel is built
' around; the loop it forbids is what got this house's provider access banned on
' 2026-08-14 (HomeScreen.brs:11-19, home_screen.dart:71-74), and describeEntry
' below refuses a plot synopsis on exactly these grounds.
'
' THE BAN WAS THE MEMBER'S IPTV PANEL. A get_vod_info per tile is a stranger's
' server, one member's credentials, no cache anywhere, and a fresh hit every
' time Home rebuilt. Every one of those four things is different here:
'
'     the panel                        titlemeta.php
'     ------------------------------   ------------------------------
'     somebody else's box              ours
'     re-answered from scratch, always cached in MySQL FOR EVER, one
'                                      lookup serving every member
'     nothing kept on the box          kept seven days on cachefs:
'     one member's login can be cut    the house's own rate limits,
'       off for the whole household      which we set
'
' So asking it is genuinely not the same act. That is a reason to allow this,
' and it is NOT a reason to be relaxed about it — a bounded thing that runs
' away is still a thing that ran away. Every number below is a ceiling, and
' none of them is one this panel can talk its way past.
'
' ==== THE FIVE THINGS THAT BOUND IT ==========================================
'
'  1. A DWELL, 600 ms, and it is Live TV's own (EPGDWELLSECONDS, LiveTvScreen:
'     "every key press restarts a 600 ms timer, and only when that timer
'     actually fires ... is a single request sent"). Every render() restarts
'     it, and render() is the only thing that changes which title is showing —
'     so a member holding Right through twenty titles fires ZERO requests,
'     because the count never reaches its end while the presses are arriving.
'     They stop; 600 ms later ONE goes out, for the title they stopped on.
'     On an idle rotation the timer does reach its end, 600 ms into a dwell
'     that is five seconds at its shortest — which is the case this feature
'     exists for, a member who never touches the panel at all.
'
'  2. ONE IN FLIGHT, EVER. A dwell that fires while a request is out is
'     DROPPED, not queued — Live TV's reasoning word for word: "a queued
'     request fires later and is no longer tied to where the member is
'     looking". So the rate can never exceed one per rotation however the
'     settings are turned.
'
'  3. ASKED ONCE PER TITLE PER LAUNCH, and the ledger is stamped when the
'     request LEAVES, not when it lands. That means a match, a no-match, a
'     timeout and a 429 all settle the title for the rest of the launch. Two
'     of those are answers and two are not, and it is written this way on
'     purpose: an unmatched title asked on every rotation for as long as Home
'     is open is the exact runaway this whole block exists to prevent, and a
'     failed one costs a member one poster until they reopen the app. The
'     server holds the same line from the other side — it files a decided
'     no-match for ever, and refuses to file a transport failure at all.
'
'  4. NOTHING IS ASKED FOR A TITLE THAT ALREADY HAS ARTWORK. A row the member
'     has opened carries e.bd and is skipped outright, which is the case that
'     grows over time — every title anybody opens takes itself out of this
'     budget permanently.
'
'     DROPPED 2026-08-25 - see the note at the line itself. The rest of this
'     point is kept because it is the argument that was weighed.
'
'     THIS RULE HAD A VISIBLE PRICE, and that is what settled it. The
'     same answer that carries the backdrop carries the title's lettering, so
'     a title skipped here gets neither — it draws its panel's own still with
'     the title in plain text, while a title nobody has opened draws a TMDB
'     still with the show's own wordmark on it. Which of the two a member
'     sees therefore depends on invisible history, and that is not a nice
'     thing to be able to say about a screen.
'
'     Dropping the rule would put every title on the same footing and would
'     not breach a single ceiling on this list: the launch budget of 24 was
'     sized for "twenty titles, none of them ever opened" in the first place,
'     so asking about all twenty is the case it was BUILT for, not an
'     overrun. What it would do is make that worst case the normal case
'     instead of the rare one, and this panel's whole history is of being
'     careful about exactly that. It is one line — the e.bd test in
'     onMetaDwell — and it wants a deliberate decision and a look at the real
'     numbers, not a quiet removal in a change about pictures.
'
'  5. A HARD CEILING PER LAUNCH, like Live TV's 200. See
'     MediaBarMetaMaxPerLaunch below for the arithmetic behind the number.
'
' AND THE MEMORY GATE ON TOP. MediaBarMemoryTight() is the same "low"/
' "critical" reading applyArtwork already drops the backdrop on and the film
' page already skips its badges on. On a box that close to the edge there is
' no point fetching a picture it will refuse to draw, so nothing is fetched.
' Checked when the dwell fires rather than once at startup, because memory
' pressure arrives and passes while Home sits there.
'
' ==== WHAT IT ACTUALLY COSTS =================================================
'
' FIRST LAUNCH, the worst case the panel can produce: twenty titles (the most
' MediaBarCount() offers), none of them ever opened, service up, box healthy,
' cache empty. TWENTY requests — one per title, none repeated — spread over at
' least twenty rotations, so 200 seconds at the default ten and 100 seconds at
' the shortest five. One at a time. The launch ceiling of 24 is never reached.
' Against titlemeta.php's own limits (40 per five minutes, 150 per hour, per
' address) that is inside both with the film page's own use to spare.
'
' SECOND LAUNCH, inside the week: ZERO requests. Every one of those answers is
' on cachefs:, and TitleMetaTask consults the cache before it builds a url. It
' still creates a Task node per title and still reads the file — off the render
' thread, which is the entire point of the task — but nothing goes near the
' wire.
'
' A WEEK LATER the disk rows age out and the twenty go again, and TMDB is still
' not touched: titlemeta.php answers all twenty out of MySQL, because its rows
' never expire.
'
' ==== WHAT IS DELIBERATELY NOT DONE ==========================================
'
' NOT PREFETCHED. The next title in the rotation is not asked about, and nor is
' the previous one. It would treble the cost of the commonest movement there is
' for artwork the member may never see — Live TV settled the same question the
' same way ("WHY ONLY THE FOCUSED TILE").
'
' NOT WRITTEN TO THE REGISTRY. AttachRecentBackdrop() exists and would make
' this survive a reboot, and it is not called: the registry is 16-32 KB for the
' whole app with a silent-failure overflow, the backdrops in it are already
' held to a 1200-byte ceiling, and a picture is not worth spending a member's
' favourites on. The detail-page path still writes there, unchanged, because
' opening a title is a member's own act rather than a rotation.
sub armMetaDwell()
    ' No address configured means nothing here can ever work. Found out once,
    ' from the first answer, and then never again.
    if m.metaOff then return
    if m.metaDwell = invalid
        ' Built exactly the way Live TV builds its own (armEpgDwell).
        m.metaDwell = CreateObject("roSGNode", "Timer")
        m.metaDwell.duration = MediaBarMetaDwellSeconds()
        m.metaDwell.repeat = false
        m.metaDwell.observeField("fire", "onMetaDwell")
    end if
    ' Restarted, not started: this is what makes holding an arrow down free.
    m.metaDwell.control = "stop"
    m.metaDwell.control = "start"
end sub

' The title on screen has been the title on screen for the whole dwell. Ask
' about THAT one and nothing else — or, far more often, decide there is nothing
' to ask and leave.
sub onMetaDwell()
    try
        onMetaDwellInner()
    catch e
        GuardFailed("mediabar/onMetaDwell", e)
        ' NOTHING IS UNWOUND HERE, and that is the safe direction. If the
        ' fault landed after m.metaAsked[key] was set, this title is marked
        ' asked and will never be asked about again this launch - which is one
        ' missing picture. Clearing the mark instead would let the same title
        ' ask again on every rotation, and a request per rotation is the
        ' pattern that got this house's provider access banned.
    end try
end sub

sub onMetaDwellInner()
    if m.metaOff then return
    ' One in flight. Dropped rather than queued, on purpose: by the time a
    ' queued one left, the panel would have rotated past what it was for.
    if m.metaBusy then return
    ' A box already short of memory is not spending anything on decoration —
    ' the same gate applyArtwork uses to drop the backdrop it already has.
    if MediaBarMemoryTight() then return

    if m.metaCount >= MediaBarMetaMaxPerLaunch()
        if not m.metaCapLogged
            m.metaCapLogged = true
            KLog("home", "media bar: reached this launch's limit of " + MediaBarMetaMaxPerLaunch().toStr() + " artwork lookups - the pictures already loaded stay, no more will be fetched until you reopen the app")
        end if
        return
    end if

    e = current()
    if e = invalid then return
    ' RULE 4, DECIDED 2026-08-25: a stored still no longer skips the lookup.
    '
    ' It used to. The reasoning was sound while the answer only carried a
    ' backdrop - a title with one had nothing left to gain. But the same
    ' answer now carries the title's own lettering, and a title the member
    ' had opened would never get it. Which titles showed a wordmark and which
    ' showed plain text would depend on which pages that member happened to
    ' have visited, which is not a defensible thing for a screen to do.
    '
    ' It breaches no ceiling. The launch budget of 24 was sized for "twenty
    ' titles, none of them ever opened" - asking about all twenty is the case
    ' it was built for, not an overrun. Every other bound is untouched: one
    ' in flight, 600 ms dwell, once per title per launch, memory gate.
    '
    ' A title that already has its OWN still keeps it - applyArtwork still
    ' prefers e.bd, because that picture describes this exact copy on this
    ' exact panel. The lookup is now only ever asked for the lettering.
    key = entryKey(e)
    if key = "" then return
    ' Asked once, whatever came back. See point 3 in the block above.
    if m.metaAsked[key] <> invalid then return

    ' The name is the only handle there is — a recents row carries no tmdb_id
    ' and no year. With no name there is nothing to look a title up by and
    ' nothing to file the answer under, so there is nothing to do.
    name = ToStr(e.name).trim()
    if name = "" then return

    kind = "movie"
    if ToStr(e.kind) = "series" then kind = "series"

    m.metaAsked[key] = true
    m.metaCount = m.metaCount + 1

    t = CreateObject("roSGNode", "TitleMetaTask")
    t.kind = kind
    t.title = name
    ' Blank, and it cannot be anything else: a recents row has no release year
    ' on it. The server searches without one and still applies its name gate
    ' letter for letter, so a wrong film is refused rather than guessed at —
    ' the year only ever narrows, it is not what makes the match safe.
    t.year = ""
    ' The same key MovieDetailScreen files a name-and-year answer under
    ' ("movie:" + lowercased name + "|" + year), with the year empty. A film
    ' page that had no tmdb_id and no year therefore SHARES this row outright.
    ' Where it did have one the two rows differ and the second lookup costs the
    ' server no upstream call anyway: it resolves to the same TMDB id and finds
    ' the by-id row already filed (titlemeta.php, "the search cost us a call").
    t.cacheKey = kind + ":" + LCase(name) + "|"
    ' Which title asked. entryKey and not a stream id, because that is what
    ' this panel matches on everywhere else and what m.metaBd is filed under.
    t.tag = key
    t.observeField("result", "onMetaResult")
    ' Replaces the previous one, which is what releases it — by then its thread
    ' has long finished. Never more than one of these exists.
    m.metaTask = t
    m.metaBusy = true
    m.metaBusyKey = key
    t.control = "RUN"
end sub

sub onMetaResult(event as object)
    try
        onMetaResultInner(event)
    catch e
        GuardFailed("mediabar/onMetaResult", e)
        ' Nothing to put right: the real handler clears m.metaBusy and
        ' m.metaBusyKey on its first two statements, unconditionally and
        ' before anything that can fault, precisely so that no early exit can
        ' leave the panel believing a request is still out. A caught fault
        ' inherits that, so the next title can still be looked up.
    end try
end sub

sub onMetaResultInner(event as object)
    ' Cleared FIRST and unconditionally. Anything that returns early below
    ' would otherwise leave the panel believing a request is still out and
    ' never ask about anything again for the rest of the launch.
    m.metaBusy = false
    m.metaBusyKey = ""

    res = event.getData()
    if res = invalid then return
    node = event.getRoSGNode()
    key = ""
    if node <> invalid then key = ToStr(node.tag)

    if res.ok <> true
        if res.doesExist("off") and res.off = true
            ' The kill switch at the other end: MetaEndpoint() is empty, so the
            ' task did no networking at all and never will. Stop building them.
            m.metaOff = true
            ' It never reached the wire, so it is given back — neither the
            ' launch budget nor the title's one attempt was really spent. This
            ' matters only if the address is ever put back at runtime, which it
            ' is not, but a ledger that counts things that did not happen is
            ' a ledger nobody can reason about later.
            m.metaCount = m.metaCount - 1
            if key <> "" then m.metaAsked.delete(key)
            KLog("home", "media bar: the artwork service has no address, so no more will be asked for")
        else
            ' A real failure. The title stays marked as asked — see point 3
            ' above — so this is once per launch, not once per rotation.
            KLog("home", "media bar: artwork lookup failed - " + ToStr(res.error))
        end if
        ' RELEASE THE POSTER. applyArtwork is holding it back for as long as an
        ' answer might still be coming (backdropPending), and a failure is an
        ' answer — so without this the title on screen keeps an empty bar until
        ' it rotates away. Only when the panel is still on the title that
        ' asked; a late failure for something else draws nothing.
        cur = current()
        if cur <> invalid and key <> "" and entryKey(cur) = key
            m.artKey = ""
            applyArtwork(cur)
        end if
        return
    end if

    if key = "" then return
    ' Remembered either way, and BOTH fields come out of the one answer — that
    ' is the whole reason the logo was made to ride along in this request
    ' instead of getting one of its own. "" is the answer "the catalogue has
    ' none of this for this title", which is worth keeping for exactly as long
    ' as the fact that it was asked — and m.metaAsked already keeps that.
    bd = ToStr(GetField(res.data, "bd"))
    lg = ToStr(GetField(res.data, "lg"))
    m.metaBd[key] = bd
    m.metaLg[key] = lg
    ' >>> AN EMPTY ANSWER NOW HAS TO REDRAW TOO, and this is the other half of
    '     the poster-flash fix. <<< It used to return here, correctly, because
    '     nothing had arrived to draw. But applyArtwork is now HOLDING BACK the
    '     poster for exactly as long as an answer might still come, so "the
    '     catalogue has nothing" is the event that releases it. Return here and
    '     a title with no backdrop keeps an empty bar until the next rotation.
    '     Falling through costs one applyArtwork on a title that has just been
    '     answered about - it is not a per-rotation cost.

    ' Still on the title that asked? A ten-second dwell is far longer than the
    ' lookup, but a member on the chevrons can move out from under it, and a
    ' rebuild can reorder the panel while it is in flight. Late answers for
    ' other titles are kept, not drawn — they draw when the rotation reaches
    ' them.
    e = current()
    if e = invalid then return
    if entryKey(e) <> key then return

    ' Force the re-assign: m.artKey still describes the poster that is up.
    m.artKey = ""
    applyArtwork(e)
    ' The logo lives or dies with backdrop mode, so this has to follow the
    ' artwork rather than stand beside it — and it is applyTitle rather than a
    ' full render() on purpose: render() re-arms the dwell timer and re-reads
    ' the favourites out of the registry, neither of which a picture arriving
    ' has any business doing.
    applyTitle(e)
end sub

' Live TV's dwell, to the millisecond (EPGDWELLSECONDS in LiveTvScreen.brs).
' It is the same shape of problem — a member moving through a list, and one
' lookup owed to wherever they stop — and a second number for the same idea
' would only be a second number to keep in step.
function MediaBarMetaDwellSeconds() as float
    return 0.6
end function

' The most this panel will ask for between one launch of the app and the next.
'
' TWENTY-FOUR, and the twenty is where it comes from: MediaBarCount() offers at
' most 20 titles, every one of them is asked about at most once, so a panel
' that has to work for everything it shows costs 20. The other four are for the
' set genuinely CHANGING under a member — Home rebuilds on every background
' sync, and a show finished on the phone drops out of Continue Watching while
' something else comes in. Four such swaps in one sitting is generous.
'
' It is a backstop and not a budget. Points 3 and 4 in the block above are what
' actually holds the number down; this is what catches the case nobody thought
' of. Live TV's equivalent is 200 per launch for the same reason, and the TV
' Guide sends 150 of its own on a single visit — against those, this is small.
function MediaBarMetaMaxPerLaunch() as integer
    return 24
end function

' What the big button is actually about to do, said plainly. Android's says
' "Resume" whatever happens; a finished episode plays the NEXT one here, which
' is worth saying before it happens rather than after.
'
' HOW MUCH IS LEFT used to be tacked on to this label ("Resume - 54m left").
' It now lives one line up, in the subtext, where there is room to say it in
' words instead of an abbreviation — and where it stops the button being 380px
' wide and shoving the chevrons sideways every time the panel rotated. The
' branches themselves are untouched: Home still reads "resume" and still does
' the finished-episode hop.
function resumeText(e as object, series as boolean) as string
    if series
        if ToStr(e.epId) = "" then return "Open show"
        ' doesExist FIRST, here and in describeEntry below. A row without
        ' the field reads as invalid, and `invalid = true` is a Type Mismatch
        ' that kills the render thread. HomeScreen.applySeenToBarEntries
        ' stamps it on every series entry today; this no longer depends on it.
        if e.doesExist("finished") and e.finished = true then return "Play next episode"
    end if
    return "Resume"
end function

' ---- The subtext line -------------------------------------------------------
'
' WHAT THIS IS NOT: a plot synopsis. It was asked for as one and it cannot be
' one, and the reason is worth writing down so nobody spends an afternoon on
' it again.
'
' The rows this panel draws come from MediaBarEntries() (Store.brs), which is
' built out of the watch history in the registry. Those rows carry a title, a
' poster, an episode code, a position and a duration. THERE IS NO PLOT IN
' THEM, and there is nowhere on the device to find one:
'
'   * The plot comes from the panel's get_vod_info, one request per title
'     (MovieDetailScreen / SeriesDetailScreen both call it on open). This
'     panel rotates through up to twenty titles, so a plot per title is a
'     request every ten seconds for as long as Home is on screen. That is the
'     exact loop that got this house's provider access banned on 2026-08-14
'     (HomeScreen.brs:6-19, and continue_watching_spotlight.dart:26-33 on the
'     phone). It is not a cost to be weighed, it is a thing that must not
'     happen.
'   * The only metadata cache on the box is cachefs:/kwickmeta.json
'     (TitleMetaTask.brs). It holds rating badges, a certificate and one
'     backdrop path — about 190 bytes a title — and NOT ONE WORD OF PROSE.
'     Adding a plot to it would be adding hundreds of bytes per title to a
'     24 KB file for a sentence nobody asked for, and titlemeta.php does not
'     fetch one either: its whole design is that what it stores is tiny.
'   * The VOD list rows that DO carry a plot are trimmed of it on the way in,
'     on purpose, everywhere they are read (MultiViewPicker.brs:409-412,
'     SearchScreen.brs:207-209) — "a plot alone runs to hundreds of bytes,
'     times tens of thousands of rows, times every source". Nothing keeps
'     them, and no VOD list is cached to disk.
'
' So the honest answer is that there is no description available without a
' fetch. What goes in the space instead is the thing this panel actually
' knows and the member actually wants: where they are in it, in a sentence.
' Every word of it is worked out from registry values already in hand and
' costs not one packet.
function describeEntry(e as object, series as boolean, pct as integer) as string
    subText = ToStr(GetField(e, "sub")).trim()
    posS = ToInt(e.pos)
    dur = ToInt(e.dur)
    ' Not named "left": Left() is a BrightScript string function and a local
    ' of that name shadows it for the rest of the scope.
    togo = ""
    if dur > 0 and posS > 0 and (dur - posS) >= 60 then togo = spellDuration(dur - posS)

    if series
        if ToStr(e.epId) = ""
            first = "You have not started an episode of this yet."
        else if e.doesExist("finished") and e.finished = true    ' see resumeText
            if subText <> ""
                first = "You finished " + subText + ", so the next episode is ready to play."
            else
                first = "You finished the last episode you watched, so the next one is ready to play."
            end if
        else if subText <> "" and togo <> ""
            first = "About " + togo + " left of " + subText + "."
        else if subText <> ""
            first = "You are partway through " + subText + "."
        else if togo <> ""
            first = "About " + togo + " left of the episode you are on."
        else
            first = "Pick this show up where you left off."
        end if
    else
        if togo <> "" and pct >= 0
            first = "You are " + pct.toStr() + "% in, with about " + togo + " still to watch."
        else if togo <> ""
            first = "About " + togo + " still to watch."
        else
            first = "Pick this film up where you left off."
        end if
    end if

    ' A second sentence when the subtext has room for a second line (i.e.
    ' whenever the title fitted on one). It is dropped rather than truncated
    ' when it does not fit, because maxLines is 1 in that case and the Label
    ' ellipsizes on a word boundary.
    when = lastWatchedText(GetField(e, "d"))
    if when = "" then return first
    return first + "  " + when
end function

' "54 minutes" / "1 hour 24 minutes". Spelled out rather than abbreviated
' because this is prose in a sentence, not a badge on a button.
function spellDuration(secs as integer) as string
    mins = Int(secs / 60)
    if mins < 1 then mins = 1
    if mins < 60
        if mins = 1 then return "a minute"
        return mins.toStr() + " minutes"
    end if
    hrs = Int(mins / 60)
    ' NOT named "rem": REM starts a comment in BrightScript, so `rem = ...`
    ' would silently become one and take the rest of the line with it.
    over = mins mod 60
    out = hrs.toStr() + " hour"
    if hrs > 1 then out = out + "s"
    if over = 0 then return out
    if over = 1 then return out + " 1 minute"
    return out + " " + over.toStr() + " minutes"
end function

' "Last watched 3 days ago", from the day stamp PushRecentVod already writes
' on every recents row (Store.brs:3524, days since 1970). HomeScreen copies it
' onto the entry — MediaBarEntries does not carry it and Store.brs is not ours
' to change. Anything missing or nonsensical returns "" and the sentence is
' simply not said.
function lastWatchedText(day as dynamic) as string
    if day = invalid then return ""
    d = ToInt(day)
    if d <= 0 then return ""
    ago = TodayDayNumber() - d
    ' A clock that moved backwards (a box that booted before it had NTP) can
    ' make this negative. Say nothing rather than something wrong.
    if ago < 0 then return ""
    if ago = 0 then return "You were watching it earlier today."
    if ago = 1 then return "You were watching it yesterday."
    if ago < 7 then return "Last watched " + ago.toStr() + " days ago."
    if ago < 14 then return "Last watched about a week ago."
    if ago < 60 then return "Last watched about " + Int(ago / 7).toStr() + " weeks ago."
    return "It has been a while since you watched it."
end function

sub buildDots()
    n = m.entries.count()
    if n <> m.dotCount
        while m.dots.getChildCount() > 0
            m.dots.removeChildIndex(0)
        end while
        m.dotCount = n
        if n > 1
            for i = 0 to n - 1
                d = m.dots.createChild("Poster")
                d.uri = "pkg:/images/circle.png"
                d.width = 10
                d.height = 10
                d.translation = [i * 18, 0]
            end for
            ' Centred, and BELOW the bar rather than inside it. They were
            ' pinned to the right edge, on top of the artwork - hard to read
            ' against a bright still and easy to mistake for part of it.
            ' Centring alone still left them over the picture, so they now sit
            ' in the gap underneath: the bar is 330 tall from y=112, so its
            ' last pixel is 442, and the rows start at 470 (HomeScreen
            ' m.rowsTop). Group-relative y=338 puts them at 450-460 absolute,
            ' clear of both. Overall width is (n-1)*18 + 10.
            span = (n - 1) * 18 + 10
            m.dots.translation = [Int((1690 - span) / 2), 338]
        end if
    end if
    m.dots.visible = (n > 1)
    if n < 2 then return
    ' Set BOTH ways every time — the dots are re-used across rotations and
    ' anything left alone leaves two of them looking current.
    for i = 0 to m.dots.getChildCount() - 1
        d = m.dots.getChild(i)
        if i = m.index
            d.blendColor = m.theme.textPrimary
        else
            d.blendColor = withAlpha(m.theme.textSecondary, 115)
        end if
    end for
end sub

sub redrawFocus()
    ' Nothing is focused unless the panel itself is in the focus chain —
    ' otherwise a ring is left glowing on Home while the member is three
    ' rows further down.
    ' The empty panel draws nothing, and that has to hold here too: this is
    ' reached from the focusedChild observer as well as from render(), so
    ' focus arriving on a panel with nothing left in it would otherwise paint
    ' a row of buttons back onto a blank strip.
    if m.entries.count() = 0
        m.buttons.visible = false
        return
    end if
    m.buttons.visible = true

    live = m.top.isInFocusChain()
    at = ""
    if live and m.stop >= 0 and m.stop < m.stops.count() then at = m.stops[m.stop]

    isFav = (m.isFav = true)
    many = (m.entries.count() > 1)
    for each name in ["resume", "info", "fav", "prev", "next"]
        shown = true
        if name = "prev" or name = "next" then shown = many
        showButton(name, shown)
        if shown
            focused = (name = at)
            paintButton(name, focused, isFav)
        end if
    end for
end sub

' ---- Input ------------------------------------------------------------------

function onKeyEvent(key as string, press as boolean) as boolean
    try
        return onKeyEventInner(key, press)
    catch e
        GuardFailed("mediabar/onKeyEvent", e)
    end try
    ' FALSE, NOT TRUE, ON A CAUGHT FAULT - and here it matters more than it
    ' does on the TV Guide. This panel's own `return false` branches are the
    ' ONLY way Home ever sees Down, Up and Back: swallowing the key would
    ' leave the member sealed inside a faulting panel on the top of Home with
    ' no route out except pulling the power. Letting it bubble costs one
    ' ignored press. This is deliberately not what ChannelDetailScreen does.
    return false
end function

function onKeyEventInner(key as string, press as boolean) as boolean
    if not press then return false
    if m.entries.count() = 0 then return false

    ' Any key at all inside the panel means the member is in here, so it
    ' stops moving until they leave. Same rule as the phone.
    setEngaged(true)

    if key = "right"
        if m.stop < m.stops.count() - 1
            m.stop = m.stop + 1
            redrawFocus()
        end if
        return true
    else if key = "left"
        if m.stop > 0
            m.stop = m.stop - 1
            redrawFocus()
            return true
        end if
        ' Already at the far left — let Home have it, which is how Left
        ' gets back to the sidebar from every other screen in this app.
        return false
    else if key = "OK"
        at = m.stops[m.stop]
        if at = "prev"
            go(-1)
        else if at = "next"
            go(1)
        else if at = "resume"
            m.top.action = { what: "resume", index: m.index }
        else if at = "info"
            m.top.action = { what: "info", index: m.index }
        else if at = "fav"
            toggleFav()
        end if
        return true
    else if key = "up"
        ' Let Home decide. The panel used to swallow this because nothing sat
        ' above it - but Home now has a profile button in its header, and a
        ' swallowed key means there is no D-pad route to it from in here.
        return false
    end if
    ' "down" and "back" belong to Home.
    return false
end function

sub toggleFav()
    e = current()
    if e = invalid then return
    fav = { kind: ToStr(e.kind), id: ToStr(e.id), name: ToStr(e.name), icon: ToStr(e.icon), ext: ToStr(e.ext) }
    ' Always set, including the empty string, which is what a KwickTV item's
    ' source token IS — leaving the field off would make ItemSrcToken fall
    ' back to whatever source happens to be active.
    fav.src = ToStr(GetField(e, "src"))
    ToggleFavoriteVod(fav)
    KLog("home", "media bar favorite toggled - " + ToStr(e.name))
    ' Re-read rather than flip the cached flag: the store is the truth, and a
    ' toggle that failed for any reason must not leave a red heart lying about
    ' it. Only redrawFocus() is needed — nothing else on the panel changed, and
    ' a full render() would re-assign the artwork url.
    m.isFav = IsFavoriteVod(ToStr(e.kind), ToStr(e.id), ToStr(GetField(e, "src")))
    redrawFocus()
end sub
