sub init()
    m.theme = KwickTheme()
    m.ring = m.top.findNode("ring")
    m.bg = m.top.findNode("bg")
    m.title = m.top.findNode("title")
    m.text = m.top.findNode("text")

    ' JetBrains Mono, the shell theme's face. Sizes unchanged, and that is a
    ' decision rather than an oversight: NEITHER Label in FormField.xml is
    ' given a width, so a Roku Label auto-sizes and nothing here truncates.
    ' Mono's ~20% wider advance therefore cannot clip a value; what it can do
    ' is let a long one (a server address) run further past the 620px plate
    ' than it already did. That overrun is pre-existing, it belongs to the
    ' screens that place this field, and capping the width here would turn an
    ' overrun into a silently cut-off URL — the worse of the two. Flagged for
    ' the television rather than fixed blind.
    m.title.font = UiFont(20)
    m.text.font = UiFont(26)

    redraw()
end sub

sub redraw()
    if m.bg = invalid then return
    w = m.top.fieldWidth
    m.bg.width = w
    m.ring.width = w + 8
    m.bg.color = m.theme.surface
    m.title.color = m.theme.textSecondary
    m.text.color = m.theme.textPrimary
    m.title.text = m.top.label

    shown = m.top.value
    if m.top.secure and shown <> ""
        masked = ""
        for i = 1 to Len(shown)
            masked = masked + Chr(8226) ' bullet
        end for
        shown = masked
    end if
    m.text.text = shown

    if m.top.focused
        m.ring.color = m.theme.focusHighlight
        m.ring.visible = true
    else
        m.ring.visible = false
    end if
end sub
