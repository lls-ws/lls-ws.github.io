sub init()
    m.theme = KwickTheme()
    ' ---- The home treatment: rounded plate, frost frame, orange ring --------
    ' A Poster now, not a Rectangle, so blendColor is what changes on focus.
    m.cardBg = m.top.findNode("cardBg")
    ' surfaceLift, NOT surfaceElevated, and this is a real fix rather than a
    ' rename. Theme.brs says it in as many words: surfaceElevated "is only a
    ' hair off surface, which is invisible at ten feet", where surfaceLift is
    ' about 2.8x its luminance - a step you can see from a sofa. This card's
    ' focus lift was the quieter of the two and nobody could tell.
    m.plateRest = m.theme.surface
    m.plateLift = m.theme.surfaceLift
    m.cardBg.blendColor = m.plateRest
    m.ring = m.top.findNode("ring")
    ' ON AT REST TOO. The frame is not the focus cue - the focus cue is the
    ' frame CHANGING COLOUR, plus the plate lifting. Android's terminal skins
    ' give an idle card a thin slate border where a normal theme gives it none
    ' (media_card.dart:97-101), and PosterCard does the same on Home. Held at
    ' 60% on purpose: at full strength an always-on frame competes with the
    ' focus ring, and the ring has to win from ten feet.
    m.ringIdle = m.theme.cardIdleBorder
    m.ringFocus = m.theme.focusHighlight
    m.ring.blendColor = m.ringIdle
    m.badgeHome = m.top.findNode("badgeHome")
    m.badgeAway = m.top.findNode("badgeAway")
    m.fallbackCircle = m.top.findNode("fallbackCircle")
    m.fallbackCircle.blendColor = m.theme.surfaceElevated
    m.fallbackLetters = m.top.findNode("fallbackLetters")
    m.titleLabel = m.top.findNode("titleLabel")
    m.subLabel = m.top.findNode("subLabel")

    ' JetBrains Mono. Both sizes drop for the wider advance (0.6em flat
    ' against Roboto-Medium's ~0.5em average).
    '
    ' Title 22, where this was 24. The box is 368 wide over two wrapped
    ' lines: mono at 24 is 14.4px a character and fits 25 per line (50
    ' total), at 22 it is 13.2px and fits 27 (54). Roboto at 24 fitted about
    ' 30 per line, so a long fixture name wraps a word earlier than it did.
    m.titleLabel.font = UiBoldFont(22)
    m.titleLabel.color = m.theme.textPrimary
    ' Sub 18, where this was 19. The box is 368 wide and does NOT wrap, so
    ' this one truncates rather than reflows: mono at 19 fits 32 characters,
    ' at 18 it fits 34, Roboto at 19 fitted about 38. UNVERIFIED.
    sf = UiFont(18)
    m.subLabel.font = sf
    m.subLabel.color = m.theme.textSecondary
    m.fallbackLetters.font = sf
    m.fallbackLetters.color = m.theme.textSecondary
end sub

sub onContent()
    c = m.top.itemContent
    if c = invalid
        ' The "nothing to bind" branch has to clear what it can, not just
        ' return: this card is recycled, and a card handed invalid keeps
        ' whatever the previous fixture left on it - two crests and a team
        ' name belonging to a game that is no longer in the row.
        m.titleLabel.text = ""
        m.subLabel.text = ""
        m.badgeHome.visible = false
        m.badgeAway.visible = false
        m.fallbackCircle.visible = false
        m.fallbackLetters.visible = false
        onFocus()
        return
    end if
    m.titleLabel.text = c.title
    m.subLabel.text = c.description
    pair = (c.badgeHome <> "" and c.badgeAway <> "")
    m.badgeHome.visible = pair
    m.badgeAway.visible = pair
    if pair
        m.badgeHome.uri = c.badgeHome
        m.badgeAway.uri = c.badgeAway
        m.fallbackCircle.visible = false
        m.fallbackLetters.visible = false
    else if c.badgeSingle <> ""
        m.badgeAway.visible = true
        m.badgeAway.uri = c.badgeSingle
        m.fallbackCircle.visible = false
        m.fallbackLetters.visible = false
    else
        m.fallbackCircle.visible = true
        m.fallbackLetters.visible = true
        m.fallbackLetters.text = c.sportLetters
    end if
    onFocus()
end sub

' EVERY VISUAL SET BOTH WAYS, EVERY TIME. This card is recycled as the Live Now
' row scrolls, so a plate or a ring left on its "focused" branch would carry
' the orange onto the next fixture.
sub onFocus()
    focused = (m.top.itemHasFocus or (m.top.focusPercent >= 0.5 and m.top.rowFocusPercent >= 0.5))
    live = (focused and m.top.rowListHasFocus)
    if live
        m.cardBg.blendColor = m.plateLift
        m.ring.blendColor = m.ringFocus
    else
        m.cardBg.blendColor = m.plateRest
        m.ring.blendColor = m.ringIdle
    end if
end sub
