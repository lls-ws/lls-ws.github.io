sub init()
    m.theme = KwickTheme()
    m.rowBg = m.top.findNode("rowBg")
    m.ring = m.top.findNode("ring")
    m.ring.color = m.theme.focusHighlight
    m.inner = m.top.findNode("inner")
    m.inner.color = m.theme.surface
    m.title = m.top.findNode("title")
    m.value = m.top.findNode("value")
    ' JetBrains Mono, and both sizes come down for it. Mono's advance is a
    ' flat 0.6em against Roboto-Medium's ~0.5em average, and NEITHER Label
    ' here wraps, so 20% wider text is 20% less of the setting's name before
    ' it is cut off.
    '
    ' Title 25, where this was 27. In Settings the row is 1200 wide so the
    ' title box is 852: mono at 27 is 16.2px a character and fits 52, at 25
    ' it is 15px and fits 56. Roboto at 27 fitted about 63. THE TIGHT CASE IS
    ' NOT SETTINGS — it is the 680-wide overlays, where the box is only 332:
    ' 22 characters at 25 against Roboto's 24. Long setting names in an
    ' overlay will truncate a word or two sooner. UNVERIFIED on the
    ' television.
    m.title.font = UiFont(25)
    ' Value 23, where this was 25. The box is 276 and right-aligned; the
    ' values are short words ("ON", "Added", a language name), 12 characters
    ' at 23 being 276px exactly. Nothing in the app's own set gets near that.
    m.value.font = UiFont(23)
    m.kind = ""
    m.laidOut = 0
end sub

' Size everything to the list's ACTUAL itemSize — this row is used at 1200
' wide in Settings and 680 wide in the overlays; fixed widths clipped the
' focus ring's right edge and pushed the value ("Added"/"ON") off-screen.
sub layout()
    w = m.top.width
    if w = invalid or w < 100 then w = 1200
    w = Int(w)
    if m.laidOut = w then return
    m.laidOut = w
    m.rowBg.width = w
    m.ring.width = w
    m.inner.width = w - 6
    m.title.width = w - 348
    m.value.width = 276
    m.value.translation = [w - 300, 0]
end sub

sub onContent()
    c = m.top.itemContent
    if c = invalid then return
    layout()
    m.title.text = c.title
    m.value.text = c.description
    redraw()
end sub

sub onFocus()
    layout()
    redraw()
end sub

sub redraw()
    m.rowBg.visible = true
    m.rowBg.color = m.theme.surface
    focused = m.top.itemHasFocus
    m.ring.visible = focused
    m.inner.visible = focused
    m.title.color = m.theme.textPrimary
    v = m.value.text
    if v = "ON" or v = "Active" or v = "Added"
        m.value.color = m.theme.accentAlt
    else
        m.value.color = m.theme.textSecondary
    end if
end sub
