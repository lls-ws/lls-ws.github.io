' A 4-digit PIN entry overlay on Roku's own voice pin pad. Fires "accepted"
' with .value on the 4th digit, or "cancelled" on Back — the same two
' signals the hand-rolled keypad gave, so nothing that gates on a PIN had to
' change.
'
' Certification 4.12 ("Apps must use Roku voice keyboards for email, PIN, and
' password entry") is why this is StandardPinPadDialog and not a grid of our
' own rectangles: the platform pad brings the microphone with it. Masking and
' the digit boxes come from the platform too, so there is nothing left here
' to draw.

sub init()
    ' Set once, on the 4th digit or on Back, so an accepted pad closing
    ' doesn't also report itself cancelled on the way out.
    m.settled = false

    m.top.title = "Enter PIN"
    m.top.message = ["Press Back to cancel"]

    ' No buttons: four digits IS the confirmation, exactly as the old keypad
    ' worked. Adding an OK would put a second step in front of a PIN people
    ' type twenty times a week.
    pad = m.top.textEditBox
    pad.maxTextLength = 4
    ' Masked on screen — each digit shows for a moment and then turns into a
    ' star. Same cover the old dot boxes gave.
    pad.secureMode = true
    ' The half of 4.12 that actually matters: the mic works here. "numeric"
    ' keeps dictation to digits, so "one two three four" arrives as 1234.
    pad.voiceEnabled = true
    pad.voiceEntryType = "numeric"

    m.top.observeField("pin", "onPinTyped")
    m.top.observeField("wasClosed", "onPinPadClosed")
end sub

' The pad reports every keystroke. Anything shorter than four digits is
' someone still typing.
sub onPinTyped()
    if m.settled then return
    entered = m.top.pin
    if Len(entered) < 4 then return
    m.settled = true
    m.top.value = entered
    m.top.accepted = true
end sub

' Back, Home, or another dialog taking the screen. Only a cancel if nothing
' was accepted first — closing an accepted pad lands here too.
sub onPinPadClosed()
    if m.settled then return
    m.settled = true
    m.top.cancelled = true
end sub
