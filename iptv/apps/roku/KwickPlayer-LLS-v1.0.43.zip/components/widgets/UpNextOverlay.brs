' The "Up next" card. See UpNextOverlay.xml for where it sits and why.

sub init()
    m.theme = KwickTheme()

    m.top.findNode("cardEdge").color = m.theme.accent
    ' The card body. Was a hand-mixed near-black at 95% alpha, on the reasoning
    ' that a card you can read the credits through is not a card. That still
    ' holds — it is just the theme's own page colour now, and FULLY OPAQUE, so
    ' nothing shows through at all. Deliberately background and not surface:
    ' the two buttons below are surfaceElevated, and a card painted surface
    ' would leave the unfocused Back button almost invisible against it.
    m.top.findNode("card").color = m.theme.background

    m.kicker = m.top.findNode("kicker")
    m.kicker.font = UiBoldFont(20)
    m.kicker.color = m.theme.textSecondary
    m.kicker.text = "UP NEXT"

    m.epName = m.top.findNode("epName")
    ' 28 -> 24 for the shell type. The box is 500 wide over two wrapped
    ' lines: Roboto-Medium 28 fitted roughly 70 characters of episode title
    ' into it, JetBrains Mono 28 fits 58, mono 24 fits 69. Long episode
    ' titles therefore clip where they always did.
    m.epName.font = UiBoldFont(24)
    m.epName.color = m.theme.textPrimary
    m.epName.lineSpacing = 4

    m.countLabel = m.top.findNode("countLabel")
    m.countLabel.font = UiFont(22)
    m.countLabel.color = m.theme.textSecondary

    ' 24 -> 22, and this one is the tightest box in the card. "Back to
    ' Episodes" is 16 characters; at mono 24 that is 230px inside a 250px
    ' button, which is close enough to the edge to clip on a rounding. At 22
    ' it is 211px and clears.
    bf = UiBoldFont(22)
    m.nowRing = m.top.findNode("nowRing")
    m.nowRing.color = m.theme.focusHighlight
    m.top.findNode("nowBg").color = m.theme.accent
    m.nowLabel = m.top.findNode("nowLabel")
    m.nowLabel.font = bf
    ' DARK text on the accent button, not white. The old accent was a mid
    ' blue (0x2086FF) that carried white at about 4.3:1; Nord's accent is a
    ' pale frost (0x88C0D0) and white on it is under 2:1 — unreadable from a
    ' sofa. The page colour on frost is about 9:1, and is what Nord itself
    ' puts on a frost fill.
    m.nowLabel.color = m.theme.background
    m.nowLabel.text = "Play Now"

    m.backRing = m.top.findNode("backRing")
    m.backRing.color = m.theme.focusHighlight
    m.top.findNode("backBg").color = m.theme.surfaceElevated
    m.backLabel = m.top.findNode("backLabel")
    m.backLabel.font = bf
    m.backLabel.color = m.theme.textPrimary
    m.backLabel.text = "Back to Episodes"

    m.tick = m.top.findNode("tick")
    m.tick.observeField("fire", "onTick")

    m.keySink = m.top.findNode("keySink")
    m.btn = 0            ' 0 = Play Now (focused on open, like Android), 1 = Back
    m.left = 5
    m.done = false       ' answered once and once only
    m.top.observeField("focusedChild", "onFocusIn")
    redraw()
end sub

sub onFocusIn()
    if m.top.hasFocus() then m.keySink.setFocus(true)
end sub

sub onStart()
    if not m.top.start then return
    m.epName.text = m.top.epLabel
    m.left = m.top.seconds
    if m.left < 1 then m.left = 5
    m.done = false
    m.btn = 0
    redraw()
    m.keySink.setFocus(true)
    m.tick.control = "start"
end sub

sub onTick()
    if m.done then return
    m.left = m.left - 1
    if m.left <= 0
        answer("play")
        return
    end if
    redraw()
end sub

sub redraw()
    m.countLabel.text = "Starting in " + m.left.toStr() + "..."
    m.nowRing.visible = (m.btn = 0)
    m.backRing.visible = (m.btn = 1)
end sub

' Answer once. The timer is stopped FIRST so a tick that lands in the same
' frame as a button press cannot answer a second time — the parent removes
' this node on the first answer, and a write to a removed node's field is the
' kind of thing that only shows up on somebody else's box.
sub answer(what as string)
    if m.done then return
    m.done = true
    m.tick.control = "stop"
    m.top.result = what
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "right"
        if m.btn = 0
            m.btn = 1
            redraw()
        end if
        return true
    else if key = "left"
        if m.btn = 1
            m.btn = 0
            redraw()
        end if
        return true
    else if key = "OK"
        if m.btn = 0 then answer("play") else answer("cancel")
        return true
    else if key = "back"
        answer("cancel")
        return true
    else if key = "up" or key = "down"
        ' Swallow them. There is nothing above or below this card, and
        ' letting them through would move focus somewhere invisible behind
        ' the finished player.
        return true
    end if
    return false
end function
