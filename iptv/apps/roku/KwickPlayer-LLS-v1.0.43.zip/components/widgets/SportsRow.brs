sub init()
    m.theme = KwickTheme()
    ' ---- The home treatment: rounded plate, frost frame, orange ring --------
    ' All three are Posters now, not Rectangles, so the colour that changes on
    ' focus is a blendColor write and Roku can give them an 8px corner. See
    ' SportsRow.xml.
    m.rowBg = m.top.findNode("rowBg")
    ' surfaceLift on focus, NOT surfaceElevated: Theme.brs says surfaceElevated
    ' "is only a hair off surface, which is invisible at ten feet".
    m.plateRest = m.theme.surface
    m.plateLift = m.theme.surfaceLift
    m.rowBg.blendColor = m.plateRest
    m.liveTint = m.top.findNode("liveTint")
    m.liveTint.blendColor = m.theme.accent
    m.liveTint.opacity = 0.10
    m.liveBar = m.top.findNode("liveBar")
    m.liveBar.color = m.theme.accent
    ' The frame, on at rest as well: frost at 60% idle, the highlight colour on
    ' focus. One node re-tinted, where this used to be a filled Rectangle with
    ' a second Rectangle laid over it to fake a 3px square outline.
    m.ring = m.top.findNode("ring")
    m.ringIdle = m.theme.cardIdleBorder
    m.ringFocus = m.theme.focusHighlight
    m.ring.blendColor = m.ringIdle

    m.badgeHome = m.top.findNode("badgeHome")
    m.badgeAway = m.top.findNode("badgeAway")
    m.vsLabel = m.top.findNode("vsLabel")
    m.fallbackCircle = m.top.findNode("fallbackCircle")
    m.fallbackCircle.blendColor = m.theme.surfaceElevated
    m.fallbackLetters = m.top.findNode("fallbackLetters")
    m.livePill = m.top.findNode("livePill")
    m.timeLabel = m.top.findNode("timeLabel")
    m.flagLabel = m.top.findNode("flagLabel")
    m.titleLabel = m.top.findNode("titleLabel")
    m.subLabel = m.top.findNode("subLabel")
    m.chev = m.top.findNode("chev")

    ' JetBrains Mono. This row is 1660 wide and its two long labels get 1160
    ' each, which at mono's flat 0.6em is still 69 characters at 28 and 55 at
    ' 21 — far more than a fixture name or a league line ever is — so the
    ' title and subtitle keep their sizes.
    m.titleLabel.font = UiBoldFont(28)
    sf = UiFont(21)
    m.subLabel.font = sf
    m.subLabel.color = m.theme.textSecondary
    m.timeLabel.font = sf
    m.timeLabel.color = m.theme.textSecondary
    ' 18, where this was 19, and this is the one box on the row that mono
    ' could actually break. The country code sits in 44px: mono at 19 is
    ' 11.4px a character, so a FOUR-letter code is 45.6px and would be cut
    ' off; at 18 it is 10.8px and 43.2px, which fits. Roboto at 19 fitted
    ' four comfortably. Same font is shared by the crest fallback letters
    ' and the "v", both of which are 1-3 characters in a 30-48px box.
    ff = UiFont(18)
    m.flagLabel.font = ff
    m.flagLabel.color = m.theme.textSecondary
    m.fallbackLetters.font = ff
    m.fallbackLetters.color = m.theme.textSecondary
    m.vsLabel.font = ff
    m.vsLabel.color = m.theme.textSecondary
    m.vsLabel.text = "v"
    m.chev.font = UiFont(30)
    m.chev.color = m.theme.textSecondary
    m.chev.text = ">"
end sub

sub onContent()
    c = m.top.itemContent
    if c = invalid
        ' Recycled rows must clear on the "nothing to bind" branch too, or a
        ' row handed invalid keeps the previous fixture's crests, name and
        ' LIVE chip.
        m.titleLabel.text = ""
        m.subLabel.text = ""
        m.flagLabel.text = ""
        m.timeLabel.text = ""
        m.liveTint.visible = false
        m.liveBar.visible = false
        m.livePill.visible = false
        m.badgeHome.visible = false
        m.badgeAway.visible = false
        m.vsLabel.visible = false
        m.fallbackCircle.visible = false
        m.fallbackLetters.visible = false
        onFocus()
        return
    end if
    isLive = (c.liveFlag = "1")

    m.titleLabel.text = c.title
    m.subLabel.text = c.description
    m.flagLabel.text = c.flagCode

    m.liveTint.visible = isLive
    m.liveBar.visible = isLive
    m.livePill.visible = isLive
    m.timeLabel.visible = not isLive
    if not isLive then m.timeLabel.text = c.timeText
    if isLive
        m.titleLabel.color = m.theme.accent
    else
        m.titleLabel.color = m.theme.textPrimary
    end if

    ' Crest pair ONLY when both resolved — two placeholders around a "v"
    ' looks broken. Otherwise one honest circle with the sport's letters,
    ' or the league's own artwork when there is one.
    pair = (c.badgeHome <> "" and c.badgeAway <> "")
    m.badgeHome.visible = pair
    m.badgeAway.visible = pair
    m.vsLabel.visible = pair
    if pair
        m.badgeHome.uri = c.badgeHome
        m.badgeAway.uri = c.badgeAway
        m.fallbackCircle.visible = false
        m.fallbackLetters.visible = false
    else if c.badgeSingle <> ""
        ' League artwork in the home slot, centred.
        m.badgeHome.visible = true
        m.badgeHome.uri = c.badgeSingle
        m.badgeHome.translation = [58, 21]
        m.fallbackCircle.visible = false
        m.fallbackLetters.visible = false
    else
        m.badgeHome.translation = [26, 21]
        m.fallbackCircle.visible = true
        m.fallbackLetters.visible = true
        m.fallbackLetters.text = c.sportLetters
    end if
    if pair then m.badgeHome.translation = [26, 21]
    ' The plate and the frame are focus-driven and this row is recycled, so a
    ' bind has to re-assert them: the row the member is on is the first one a
    ' scrolling list re-uses.
    onFocus()
end sub

' BOTH WAYS, EVERY TIME. This row is recycled as the day list scrolls, so a
' plate or a frame left on its "focused" branch would carry the orange down
' onto the next fixture. The old version wrote m.inner.color only inside the
' `if focused` arm, which was the same trap one node further in.
sub onFocus()
    focused = m.top.itemHasFocus
    if focused
        m.rowBg.blendColor = m.plateLift
        m.ring.blendColor = m.ringFocus
    else
        m.rowBg.blendColor = m.plateRest
        m.ring.blendColor = m.ringIdle
    end if
end sub
