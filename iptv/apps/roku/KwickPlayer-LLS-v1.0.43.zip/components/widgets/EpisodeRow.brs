' One episode row. See EpisodeRow.xml for what the three markers mean.

sub init()
    m.theme = KwickTheme()

    m.ring = m.top.findNode("ring")
    m.ring.color = m.theme.focusHighlight
    m.inner = m.top.findNode("inner")
    ' The page's own background, not "surface" — this list sits straight on
    ' the detail screen's backdrop, so anything else draws a grey slab under
    ' the focused row that no other row has.
    m.inner.color = m.theme.background

    ' ---- The mono tax on this row -------------------------------------------
    ' JetBrains Mono's advance is a flat 0.6em where Roboto-Medium averaged
    ' about 0.5em, so every string here got ~20% longer at the same point
    ' size and BOTH labels had to be re-fitted. See layout() for the widths.
    '
    ' 24, where this was 26. The title box is 906 wide and ONE line: mono at
    ' 26 is 15.6px a character and fits 58, at 24 it is 14.4px and fits 62.
    ' Roboto at 26 fitted about 71. So a long episode title truncates a few
    ' characters sooner than it did — UNVERIFIED on the television.
    m.title = m.top.findNode("title")
    m.title.font = UiFont(24)

    ' Says which button, in words. See the note in the XML: "..." was
    ' decoration that nobody read as "there is a menu here", and * is what
    ' Roku calls the Options button on every remote it ships.
    '
    ' 22, where this was 26, and this one was NOT optional. "Press * for
    ' Options" is 19 characters; mono at 26 is 15.6px each, i.e. 296px, and
    ' the box was 260 — the sentence would have been cut off mid-word, which
    ' is the exact failure the label exists to avoid. At 22 it is 13.2px and
    ' 251px, inside a box widened to 280. The sentence is not shortened: it
    ' names the button and the sentence is the whole point.
    m.menuHint = m.top.findNode("menuHint")
    m.menuHint.font = UiFont(22)
    m.menuHint.color = m.theme.textSecondary
    m.menuHint.text = "Press * for Options"

    ' The tick is the Material glyph Theme.brs already publishes — every
    ' codepoint in there was read out of the bundled font before it was used,
    ' which is why this does not invent one.
    m.tick = m.top.findNode("tick")
    m.tick.font = IconFont(30)
    m.tick.color = m.theme.accent
    m.tick.text = m.theme.iconCheck

    m.barWrap = m.top.findNode("barWrap")
    m.barTrack = m.top.findNode("barTrack")
    m.barTrack.color = m.theme.surfaceElevated
    m.barFill = m.top.findNode("barFill")
    m.barFill.color = m.theme.accent

    m.dot = m.top.findNode("dot")
    m.dot.color = m.theme.accent

    m.barW = 100
    m.laidOut = 0
end sub

' Size to the list's ACTUAL itemSize, the way SettingRow and MultiViewPickRow
' do — a fixed width clips the focus ring's right edge the moment the list is
' narrower than the number written in the XML.
sub layout()
    w = m.top.width
    ' Anything narrower than the marker column plus the hint column plus a
    ' title worth reading is not a width this row can honour, so it falls back
    ' to the one it was drawn for rather than handing NEGATIVE widths to the
    ' labels. Was 200 when the hint was three characters wide.
    if w = invalid or w < 700 then w = 1340
    w = Int(w)
    if m.laidOut = w then return
    m.laidOut = w
    m.ring.width = w
    m.inner.width = w - 6
    ' Right-hand furniture first, then whatever is left goes to the title.
    ' The hint column is a sentence rather than three dots, and it is
    ' right-aligned inside its box, so over-reserving costs a gap and never
    ' an overlap.
    '
    ' 280, where this was 260: JetBrains Mono at 22 measures the sentence at
    ' about 251px and a box that is only nine pixels wider than its contents
    ' is not a box, it is a coin toss. The 20px comes out of the title.
    markX = w - 114
    hintW = 280
    hintX = markX - 20 - hintW
    m.tick.translation = [markX, 0]
    m.barWrap.translation = [markX, 26]
    m.dot.translation = [markX + 44, 23]
    m.menuHint.translation = [hintX, 0]
    m.menuHint.width = hintW
    m.title.width = hintX - 20
end sub

sub onContent()
    c = m.top.itemContent
    if c = invalid then return
    layout()
    m.title.text = c.title

    ' Rows recycle, so BOTH of these are read every time and all four markers
    ' are set every time. Reading a field that the filler somehow did not add
    ' must not throw, hence hasField rather than a bare read.
    st = "none"
    if c.hasField("wstate") then st = ToStr(c.wstate)
    pct = 0
    if c.hasField("wpct") then pct = Int(c.wpct)

    if st = "done"
        m.tick.visible = true
        m.barWrap.visible = false
        m.dot.visible = false
    else if st = "part" and pct >= 0
        m.tick.visible = false
        m.barWrap.visible = true
        m.dot.visible = false
        p = pct
        if p < 2 then p = 2
        if p > 100 then p = 100
        m.barFill.width = Int(m.barW * p / 100)
    else if st = "part"
        ' Started, length unknown — see the note in the XML. Something,
        ' rather than a bar of a made-up length.
        m.tick.visible = false
        m.barWrap.visible = false
        m.dot.visible = true
    else
        m.tick.visible = false
        m.barWrap.visible = false
        m.dot.visible = false
    end if
    redraw()
end sub

sub onFocus()
    layout()
    redraw()
end sub

sub redraw()
    focused = m.top.itemHasFocus
    m.ring.visible = focused
    m.inner.visible = focused
    m.menuHint.visible = focused
    if focused
        m.title.color = m.theme.textPrimary
    else
        m.title.color = m.theme.textSecondary
    end if
end sub
