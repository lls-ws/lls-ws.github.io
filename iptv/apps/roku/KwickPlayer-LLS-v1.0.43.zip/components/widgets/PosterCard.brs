sub init()
    m.theme = KwickTheme()
    m.top.findNode("cardBg").color = m.theme.surface
    ' Held rather than found per bind: onContent runs on every recycled card
    ' while the grid scrolls, and it now writes two fields on this node.
    m.art = m.top.findNode("art")
    ' What the artwork Poster is currently fitted with, mirroring the value
    ' in the XML. Tracked so a recycled card only writes the field when the
    ' fit actually has to change - see onContent().
    m.artFit = "scaleToZoom"
    ' The title and the dark foot it sits on. All three are shown only on the
    ' card the member is actually on (see onFocus), so their COLOURS never
    ' change and are set once, here - the only thing that moves per card is
    ' visibility, which is one less thing that can strand itself on a recycled
    ' tile.
    m.name = m.top.findNode("name")
    ' JetBrains Mono, the shell theme's face (Theme.brs UiBoldFont). Bold
    ' rather than regular because this sits on artwork behind a dark foot and
    ' Roboto-MEDIUM is what it replaces - mono regular at 21 reads thinner
    ' than what was here.
    '
    ' SIZE DROPPED 21 -> 19, and this is the mono tax, not a preference. The
    ' box is 204 wide over two lines. JetBrains Mono's advance is a flat
    ' 0.6em, so 21 gives 12.6px a character and fits 16 per line; Roboto
    ' averaged about 10.5px and fitted 19. At 19 the mono figure is 11.4px
    ' and 17 characters, which puts the two-line budget back to 34 against
    ' Roboto's 38 instead of 32. Long titles will still wrap one word
    ' earlier than they did - UNVERIFIED on the television.
    m.name.font = UiBoldFont(19)
    m.name.color = m.theme.textPrimary
    ' The ramp is white with an alpha gradient; blendColor makes it black and
    ' scales that alpha, so its last row lands on exactly the plate's 0xD9 and
    ' the two read as one band. See PosterCard.xml for the contrast working.
    m.footFade = m.top.findNode("footFade")
    m.footFade.blendColor = "0x000000D9"
    m.footPlate = m.top.findNode("footPlate")
    m.footPlate.color = "0x000000D9"

    ' The heart takes the theme accent so it belongs to whatever skin is on.
    ' The disc stays dark whatever the theme, because it sits on the artwork
    ' rather than on the page and so has no theme surface to match.
    '
    ' 0xE6, NOT the 0xB8 this shipped with. The heart is the one thing on this
    ' card that is on show at all times, over artwork nobody controls, and at
    ' 72% black the disc washed out badly on a pale poster: the accent blue
    ' (relative luminance 0.243) against a 0xB8 disc composited over a white
    ' cover (0.061) is only about 2.6:1, which is not a mark you can pick out
    ' from the sofa. At 0xE6 the disc sits at 0.010 whatever is behind it, so
    ' the heart holds about 4.9:1 on the worst poster and 5.9:1 on a dark one
    ' - near enough the same reading everywhere, which is the point. The disc
    ' is what does this work, not the glyph colour: tinting the heart itself
    ' brighter would fix the pale poster and ruin the dark one.
    m.favDisc = m.top.findNode("favDisc")
    m.favDisc.blendColor = "0x000000E6"
    ' images/heart.png is white on transparent so blendColor tints it to the
    ' active theme. It's an asset rather than a "♥" Label because
    ' Roboto-Medium has no U+2665 — on the device that draws as a missing-
    ' character box, which is what the first cut of this actually shipped as.
    m.favMark = m.top.findNode("favMark")
    m.favMark.blendColor = m.theme.accent

    ' Source tag (top-left) for merged multi-source views: a fixed dark plate,
    ' a coloured DOT, and the plain source name. Android's rule, ported
    ' verbatim - see the long note in PosterCard.xml.
    m.srcTagBg = m.top.findNode("srcTagBg")
    m.srcDot = m.top.findNode("srcDot")
    m.srcTag = m.top.findNode("srcTag")
    ' 16, not the 18 this was: the tag is auto-width and its plate is sized
    ' from it, so mono at 18 would simply make the corner tag ~20% wider over
    ' the artwork rather than truncate. 16 keeps it the size it looks now.
    m.srcTag.font = UiBoldFont(16)
    ' THE LABEL IS ALWAYS WHITE ON AN ALWAYS-DARK PLATE. That is the whole
    ' benefit of moving the colour into a dot: there is exactly one legibility
    ' answer for the tag text instead of one per source, so this is set once
    ' here and nothing per-bind can ever change it. 17.6:1 over the worst
    ' (white) poster.
    m.srcTag.color = "0xFFFFFFFF"
    ' The DOT is tinted with its source's colour so the member can tell two
    ' playlists apart across a room. Palette is grabbed once — never per
    ' bind — and the token->slot answer is memoised, so a recycling card
    ' does one associative-array hit and nothing else. See SrcPalette().
    m.srcPalette = SrcPalette()
    m.srcSlot = {}
    ' The plate is now a CONSTANT: it no longer carries the source colour, so
    ' there is nothing per-source left on it to smear across a recycled card.
    ' Written once, here, and never again.
    m.srcTagBg.color = "0x000000E6"
    ' ---- Where the label and the plate sit, with a dot and without one -------
    ' Named rather than inlined because showSrcTag has to write BOTH cases on
    ' every bind and the two must stay in step.
    '
    ' Plate x=8; 6px pad, 14px dot, 6px gap, label, 6px pad. SIX, not the eight
    ' the bare tag uses, and the 6px is bought rather than chosen: the dot adds
    ' 20px to a plate that has to stay clear of the FAVOURITE HEART's disc at
    ' x=178. The longest label the app can produce is ShortSrcLabel's 14
    ' characters (Util.brs:70), which at UiBoldFont(16) in JetBrains Mono's
    ' flat 0.6 em is 134px, so the plate runs 8..174 and clears the disc by
    ' 4px. At 8px padding it would have run to 180 and collided. The pair only
    ' ever meet on a favourited title in a merged multi-source view, and 4px is
    ' thin - >>> worth an eye on the television with a long source name. <<<
    '
    ' The bare (no dot) case is left at exactly the 8px it always had, so a
    ' single-source library's tag is byte-for-byte what it was.
    m.tagTextX = 34      ' label x with a dot
    m.tagTextXBare = 16  ' label x with no dot (exactly where it always sat)
    m.tagPadDot = 32     ' plate width = label width + this, with a dot
    m.tagPadBare = 16    ' plate width = label width + this, with none
    ' The colours the member painted their sources with on their phone, which
    ' beat the hashed guess above wherever there is one. A plain map of
    ' "t<token>" -> { bg, mark }, built once per sync cycle in Store.brs and
    ' left on the global node so a recycling card can have it for one
    ' associative-array hit — the card must never read the registry itself
    ' (that is "a visible stutter on a stick", Store.brs RefreshFavVodIndex).
    ' Held in m rather than read off the node per bind, because a node field
    ' read is not free either.
    m.srcSynced = {}

    ' Resume bar along the bottom of the artwork.
    m.progTrack = m.top.findNode("progTrack")
    ' Android's bar sits on Colors.black45; the fill takes the theme accent
    ' so it reskins with everything else.
    m.progTrack.color = "0x00000073"
    m.progFill = m.top.findNode("progFill")
    m.progFill.color = m.theme.accent
    ' How far in, last worked out. Held because the bar's GEOMETRY now changes
    ' on focus as well as on bind, and the fill's width has to be re-derived
    ' from the percentage against whichever track width is current.
    m.resumePct = 0
    ' Whether this card is currently wearing the ring. Same flag the ring
    ' itself uses, kept so applyResumeGeom can be called from either side.
    m.ringLive = false

    ' ---- Rounded corners ----------------------------------------------------
    ' A white nine-patch, so its colour is one blendColor write and it never
    ' has to be re-exported - the same arrangement ChannelCard uses for its
    ' plate and edge. Set ONCE here, because the colour does not depend on the
    ' item: the corners are always the page background, which is the whole
    ' trick (see PosterCard.xml). The only thing that moves per card is
    ' visibility.
    m.corners = m.top.findNode("corners")
    m.corners.blendColor = m.theme.background
    ' The focus ring, tinted exactly as ChannelCard tints its own edge - same
    ' theme key, same file. A Poster takes blendColor; a list's focusBitmapUri
    ' does not, which is why the ring lives here and not on the list.
    m.ring = m.top.findNode("ring")
    ' ==== THE FRAME IS NOW ON AT REST TOO (Nord Shell) ======================
    ' Android's terminal skins give an IDLE poster a thin slate frame where a
    ' normal theme gives it none - media_card.dart:97-101, idleBorderColor =
    ' surfaceBorderColor and idleBorderWidth 1.5 instead of 3.0. That bordered
    ' card is most of what makes the skin read as a terminal rather than as a
    ' wall of floating photographs.
    '
    ' Ported as ONE node, not two: the same card_edge.9.png that already draws
    ' the focus ring, left visible on rounded cards and re-TINTED on focus.
    ' Two nodes at the same 8px radius would sit exactly on top of each other
    ' and cost a second draw for nothing.
    '
    ' 1.5 ON ANDROID IS 3px HERE, so the file's own stroke is already right:
    ' an Android poster is about 110dp wide and 1.5/110 is 1.4%, which on this
    ' 232px card is 3.2px. card_edge.9.png is stroke 3. No new asset, no
    ' re-export, no texture: the file is already resident.
    '
    ' >>> THE COST, AND IT IS THE ONE THING TO LOOK AT ON THE TELEVISION.
    ' Until now the ring APPEARING was the focus cue. Now the frame is always
    ' there and focus is a colour change on it - frost at 60% to full-strength
    ' orange - plus the title foot appearing, which is unchanged and is the
    ' louder half. The idle tint is deliberately held at 0x99 so the ring
    ' still wins from ten feet; if it does not, the answer is to take the idle
    ' alpha down (0x66) rather than to drop the frame. <<<
    m.ringIdle = m.theme.cardIdleBorder
    m.ringFocus = m.theme.focusHighlight
    m.ring.blendColor = m.ringIdle
    ' Whether THIS card is a rounded one. Held rather than read off the item
    ' in onFocus, which runs far more often than onContent. Initialised false
    ' so a card that gets a focus event before its first bind - the list sets
    ' focusPercent whenever it likes - reads a real answer rather than invalid.
    m.cardRound = false

    ' Favoriting from a detail page has to show up on the poster when you
    ' back out. Rather than the screens re-assigning content (which would
    ' throw away the scroll position), every live card watches the index and
    ' repaints itself — so the heart appears the instant it's toggled.
    '
    ' >>> observeFieldScoped, NOT observeField, AND THAT IS THE WHOLE POINT <<<
    '
    ' m.global lives for the life of the app. A plain observeField puts THIS
    ' CARD in the global node's observer list and leaves it there, and the
    ' global's list is a hard reference — so every card the app ever builds is
    ' held alive by it, with its decoded artwork, long after the screen that
    ' built it was thrown away. The grid pool is not small: this card's `art`
    ' Poster decodes at 232 x 348 x 4 = 322,944 bytes, the VOD page builds two
    ' pools (the 6 x 2 grid and the rows view) of roughly forty cards between
    ' them, and that is about 12 MB of a ~90 MB device — per visit, never
    ' returned. It matched the member trace exactly (key 2EDDC4, Streaming
    ' Stick 4K, two EXIT_OUT_OF_MEMORY on 2026-09-13): VOD opened at 26%, and
    ' Settings — with VOD, the film page and the player all gone — still read
    ' 70%. Search is the fastest way to mint a lot of these, which is why the
    ' second report on the same box went Search -> "low" -> Home at 68%.
    '
    ' The scoped form registers the same callback but ties the registration to
    ' this card's own lifetime, so the observer goes when the card goes. There
    ' is no destructor on a SceneGraph component and a recycled card is not
    ' reliably handed `invalid` on the way out, so there is nowhere an explicit
    ' unobserveField could be called from — scoped is the mechanism, not a
    ' shortcut past one. Three screens already pair observeField on the global
    ' with an unobserveField on close (GuideScreen, LiveTvScreen,
    ' ChannelDetailScreen); those are screens, which have a close path. Cards
    ' do not.
    if m.global <> invalid
        m.global.observeFieldScoped("favVodIndex", "onFavIndexChanged")
        ' The resume bar follows the identical arrangement, and for a
        ' stronger reason: you come back to this grid straight from having
        ' watched something, and the tile you left is still on screen. The
        ' field is created here if nobody has yet — the other session
        ' globals are declared in AppScene.brs, which belongs to another
        ' lane; it is one map for the whole app, so first card in makes it.
        if not m.global.hasField("resumeVodIndex") then m.global.addFields({ resumeVodIndex: {} })
        m.global.observeFieldScoped("resumeVodIndex", "onResumeIndexChanged")
        ' Same arrangement again for the synced source colours, and the same
        ' reason for it living here: the other session globals are declared in
        ' AppScene.brs, which belongs to another lane, so whichever card gets
        ' here first makes the field. Store.brs only ever SETS it — creating
        ' fields on the global is the render thread's job and that publisher
        ' also runs on the sync task's thread.
        '
        ' Watched, not just read once, because a colour can arrive while a
        ' grid is already on screen: the sync cycle that fetches it finishes
        ' seconds after launch, and re-assigning the row's content to repaint
        ' would throw the member back to the first tile.
        if not m.global.hasField("srcColorIdx") then m.global.addFields({ srcColorIdx: {} })
        m.global.observeFieldScoped("srcColorIdx", "onSrcColorsChanged")
        m.srcSynced = m.global.srcColorIdx
    end if
end sub

sub onFavIndexChanged()
    showFavMark(m.top.itemContent)
end sub

sub onResumeIndexChanged()
    showResumeBar(m.top.itemContent)
end sub

sub onSrcColorsChanged()
    m.srcSynced = m.global.srcColorIdx
    showSrcTag(m.top.itemContent)
end sub

sub onContent()
    c = m.top.itemContent
    if c = invalid
        ' The "nothing to bind" branch still has to clear the two nodes this
        ' pass added. A recycled card that is handed invalid keeps whatever it
        ' was last showing, and four page-coloured corner notches left behind
        ' on a card that is about to be re-used square is exactly the smear
        ' this card's other setters are all written to avoid.
        m.cardRound = false
        m.corners.visible = false
        m.ring.visible = false
        return
    end if
    ' HOW THE ARTWORK IS FITTED, and like everything else on this card it is
    ' set BOTH ways on every bind - a card that has just drawn a channel
    ' logo is handed a film next, and a stale scaleToFit would letterbox it.
    '
    ' A poster gets Android's BoxFit.cover: fill the card, centre-crop the
    ' overflow (media_card.dart:74). Search's Channels row uses this same
    ' card for landscape station logos, and cropping one of those to a 2:3
    ' portrait leaves a sliver of the middle of the logo; those items ask for
    ' "fit" instead and sit whole on the surface plate, which is what
    ' ChannelCard does on Live TV and what the member already likes there.
    '
    ' Written before the uri, because it governs the decode as well as the
    ' draw, and only when it actually changes - a needless write to a Poster
    ' field costs a reload.
    ' Nested, not "hasField(...) and ..." on one line: BrightScript's AND
    ' evaluates both sides, so the one-liner would read a field that is not
    ' there on every VOD poster in the app.
    fit = "scaleToZoom"
    if c.hasField("artFit")
        if c.artFit = "fit" then fit = "scaleToFit"
    end if
    if m.artFit <> fit
        m.art.loadDisplayMode = fit
        m.artFit = fit
    end if
    m.art.uri = c.hdPosterUrl
    m.name.text = c.title
    ' ROUNDED OR NOT, SET BOTH WAYS, EVERY BIND. This card is recycled: a
    ' rounded Home poster and a square VOD one can share one component within
    ' a session, and leaving the corner overlay alone on the square branch
    ' would stamp four page-coloured notches on a card that is meant to be
    ' square.
    '
    ' Nested rather than "hasField(...) and c.cardRound" on one line: as with
    ' hideFav and artFit above, BrightScript's AND evaluates both sides, so
    ' the one-liner would read a field that is not there on any VOD or Search
    ' item in the app.
    m.cardRound = false
    if c.hasField("cardRound")
        if c.cardRound = true then m.cardRound = true
    end if
    m.corners.visible = m.cardRound
    showFavMark(c)
    showResumeBar(c)
    showSrcTag(c)
    onFocus()
end sub

' The source tag, top-left: a coloured dot and the plain source name.
'
' Recycled cards must set it BOTH ways, like the heart — and that means all
' FOUR things that move, not just the visibility: the dot's colour, the dot's
' visibility, the LABEL'S X and the plate's WIDTH. A tag that goes from
' "dot + name" to "name" and only has its dot hidden would leave the label
' stranded 22px to the right with a plate the wrong length, and the next
' poster down the grid would wear it.
'
' Its own sub rather than a block inside onContent because the colour can now
' change without the content changing (see onSrcColorsChanged).
sub showSrcTag(c as dynamic)
    tag = ""
    if c <> invalid and c.hasField("srcLabel") then tag = c.srcLabel
    if tag = ""
        m.srcDot.visible = false
        m.srcTag.visible = false
        m.srcTagBg.visible = false
        return
    end if
    m.srcTag.text = tag
    ' srcTok is written by VodContentTask alongside srcLabel, so it is already
    ' sitting on the node — no lookup, no I/O. A tagged item that somehow
    ' arrived without one gets NO DOT, which is Android's answer for a source
    ' with no colour: better no dot than a grey one that reads as a tenth
    ' source colour, or a colour that disagrees with the chip for the same
    ' source.
    dot = srcDotColor(c)
    if dot <> ""
        m.srcDot.blendColor = dot
        m.srcDot.visible = true
        m.srcTag.translation = [m.tagTextX, 10]
        m.srcTagBg.width = Int(m.srcTag.boundingRect().width) + m.tagPadDot
    else
        m.srcDot.visible = false
        m.srcTag.translation = [m.tagTextXBare, 10]
        m.srcTagBg.width = Int(m.srcTag.boundingRect().width) + m.tagPadBare
    end if
    m.srcTag.visible = true
    m.srcTagBg.visible = true
end sub

' The DOT colour for this item's source, or "" for no dot at all.
'
' The member's own choice first, this app's guess second. A colour painted on
' the phone arrives over KwickSync and is resolved once per cycle in
' Store.brs; anything with no choice against it falls back to the hashed
' palette, which is what every source looked like before and what a box with
' no sync still looks like. `mark` rather than `bg`: bg is the deep, slightly
' transparent plate tint this tag used to wear, and a dot wants the solid
' full-strength colour — which is also exactly what the VOD chip row draws
' (chipDotColor in VodScreen.brs), so a source's dot on the chip and its dot
' on every poster are the same pixel value.
'
' Cheap by construction: one associative-array hit for the synced answer, and
' for the fallback the palette was built at init and each token is hashed once
' per card and then remembered (the memo can only ever hold as many entries as
' the member has sources). "t" prefixes both keys so the KwickTV token — which
' is the empty string — is a normal associative-array key like any other; that
' is the same string Store.brs builds with SrcColorMemoKey, and the two must
' agree.
function srcDotColor(c as object) as string
    if not c.hasField("srcTok") then return ""
    tok = c.srcTok
    k = "t" + tok
    painted = m.srcSynced[k]
    if painted <> invalid then return painted.mark
    if not m.srcSlot.doesExist(k) then m.srcSlot[k] = SrcColorIndex(tok)
    return m.srcPalette[m.srcSlot[k]].mark
end function

' Cards are recycled constantly while scrolling, so this must SET the mark
' both ways every time — leaving it alone on a non-favorite would smear the
' previous tile's heart across the grid.
'
' TURNING THE HEART OFF FOR A WHOLE ROW: an item may carry hideFav = true and
' this card will draw no heart for it while keeping everything else, the
' resume bar included. Home needs that and cannot get it any other way — its
' "Favorite Movies & Series" row is ENTIRELY favourites, so a heart on every
' poster in it is noise that repeats what the row title already says (which is
' exactly why ChannelCard has no heart at all), and the heart and the bar are
' driven by the SAME favKey, so dropping favKey to hide one would take the
' other with it.
'
' It is a field on the ITEM, not on the card, and that is not a style choice:
' a MarkupGrid/RowList does not expose its item components, so a screen has no
' way to reach in and set a field on this component. That is why gridHasFocus
' and rowListHasFocus have sat here since they were written without a single
' caller ever setting them. artFit above is passed the same way, by
' SearchScreen, and this follows it.
'
' Absent or false = a heart exactly as before, so VodScreen and SearchScreen
' need no change.
sub showFavMark(c as dynamic)
    ' Read favKey straight off the node — this component doesn't include
    ' Util.brs, and the field is always written as a string by the screens.
    on = false
    if c = invalid
        m.favDisc.visible = false
        m.favMark.visible = false
        return
    end if
    ' Nested rather than "hasField(...) and c.hideFav" on one line: as in
    ' onContent, BrightScript's AND evaluates both sides, so the one-liner
    ' would read a field that is not there on any of today's items.
    hide = false
    if c.hasField("hideFav")
        if c.hideFav = true then hide = true
    end if
    if not hide and c.hasField("favKey")
        key = c.favKey
        if key <> "" and m.global <> invalid and m.global.favVodIndex <> invalid
            on = (m.global.favVodIndex[key] = true)
        end if
    end if
    m.favDisc.visible = on
    m.favMark.visible = on
end sub

' How far into this title the profile is, drawn along the bottom of the
' artwork. Same recycling rule as the heart above and the source tag: SET
' both ways, every bind. A poster with nothing to resume has to actively
' clear the bar, because otherwise the tile it was recycled from leaves its
' progress behind and the grid fills with bars belonging to other films.
'
' The width is set both ways too, not just the visibility — a hidden node
' keeps whatever width it had, and the next tile to use this card would
' flash the previous one's length for the frame before its own is worked
' out.
'
' WHERE THE NUMBER COMES FROM: one associative-array hit on the app-wide
' index, keyed by the poster's own favKey — the SAME string the heart uses
' ("<src>:<kind>:<id>", bare for KwickTV), already sitting on the node
' because VodContentTask/SearchScreen put it there. Nothing here reads the
' registry (per-tile registry reads are "a visible stutter on a stick",
' Store.brs RefreshFavVodIndex) and nothing here asks a provider anything
' (per-tile requests are what got this house's address banned on
' 2026-08-14). The index is built once per screen build; see
' refreshResumeVodIndex() in VodScreen.brs.
'
' The number itself is the same fraction Android draws: position over
' duration (home_screen.dart:520, handed to MediaCard at :546, drawn at
' media_card.dart:95). Here it arrives pre-rounded to 1..99 by
' MediaBarPercent, which already refuses 0% and 100% — a "continue
' watching" bar at either end is a contradiction.
sub showResumeBar(c as dynamic)
    pct = 0
    if c <> invalid and c.hasField("favKey")
        key = c.favKey
        if key <> "" and m.global <> invalid and m.global.hasField("resumeVodIndex")
            v = m.global.resumeVodIndex[key]
            if v <> invalid then pct = Int(v)
        end if
    end if
    m.resumePct = pct
    ' The SHAPE is applied both ways whatever the answer, not just when there
    ' is a bar to draw: a hidden node keeps its width, height and translation,
    ' and the next tile to use this card would flash the previous one's bar in
    ' the previous one's position for the frame before its own is worked out.
    applyResumeGeom()
    m.progFill.visible = (pct > 0)
    m.progTrack.visible = (pct > 0)
end sub

' ---- The resume bar's two shapes: under the ring, and inside it -------------
'
' ANDROID DOES THIS AND IT DOES IT FOR OUR EXACT REASON. media_card.dart
' ResumeBar.build(): at rest the bar is flush along the bottom, and on focus it
' insets by TvFocus.contentInset (its ring width + 3) on all four sides, grows
' taller and darkens its track. The comment at media_card.dart:106 says why -
' the focus ring used to draw straight over it, so "the tile you were actually
' pointing at was the one tile whose 'you're 40 minutes in' bar you could not
' see". That is precisely what a 3px ring at y 345..348 would do to a 6px bar
' at y 342..348 here.
'
' THE INSET IS DERIVED, NOT COPIED. Android insets by its own ring width plus
' 3; this ring is card_edge.9.png at stroke 3, so the inset is 3 + 3 = 6. If
' the ring's file ever changes weight, this number follows it - that is the
' whole point of writing it as the principle rather than as Android's 8.
'
' NO ANIMATION. Android runs an AnimatedPadding on it. This jumps, deliberately
' - certification 3.5 gives a remote press 250ms and a tween on a recycled grid
' item is the kind of thing that arrives late on the card that has already been
' scrolled past.
'
' NO ROUNDED ENDS. Android rounds the focused bar to radius 3. A Roku Rectangle
' cannot be rounded and a 220 x 8 nine-patch to round two 3px ends is not worth
' a file. This is the one part of Android's treatment not reproduced.
'
' Called from BOTH sides - showResumeBar on every bind, onFocus on every focus
' change - and it writes every field both ways each time, because this card is
' recycled and a bar left lifted would sit halfway up the next poster.
sub applyResumeGeom()
    ' m.cardRound ALONE, where this was "m.cardRound and m.ringLive". The
    ' frame is drawn on a rounded card whether or not it is focused now (see
    ' init), so a bar flush along the bottom edge would spend its whole life
    ' with the frame's bottom stroke across it instead of only while focused.
    '
    ' The consequence, and it is worth the owner knowing: on Home's rounded
    ' posters the resume bar no longer MOVES when focus lands on it. It sits
    ' inside the frame at all times - 220 wide, 8 tall, solid track - which is
    ' exactly what the focused bar already looked like. The focused state is
    ' byte-for-byte what he signed off; it is the resting one that changed,
    ' and a bar that stays put is the better answer anyway. VOD and Search
    ' posters are not rounded and are untouched.
    ' m.ringLive is still tracked because onFocus writes it and a future
    ' caller may want it; nothing here reads it any more.
    lifted = m.cardRound
    if lifted
        ' Inside the ring: in 6 from each edge, 8 tall, and a solid track
        ' because at this size it is reading against the artwork rather than
        ' against the dark foot. Clears the 8px corner arc as well as the
        ' stroke - at y=342 the card's own edge is at x=3.5, and this starts
        ' at 6.
        barX = 6
        barY = 334
        barW = 220
        barH = 8
        m.progTrack.color = "0x000000FF"
    else
        ' Flush along the bottom of the artwork, exactly where it has always
        ' been and where Android puts its own idle bar.
        barX = 0
        barY = 342
        barW = 232
        barH = 6
        m.progTrack.color = "0x00000073"
    end if
    m.progTrack.translation = [barX, barY]
    m.progTrack.width = barW
    m.progTrack.height = barH
    m.progFill.translation = [barX, barY]
    m.progFill.height = barH
    fillW = Int(barW * m.resumePct / 100.0)
    if fillW < 4 then fillW = 4   ' 1% of 220px is a smudge, not a bar
    m.progFill.width = fillW
end sub

' ---- THE NAME, and only on the card you are on ------------------------------
'
' THE OWNER ASKED FOR THIS and it is his call: no permanent title, the name on
' the focused card only. Three things follow from it that are worth writing
' down, because they are what would make it feel wrong on a television.
'
' 1. THE FOCUSED NAME HAS TO BE PROPERLY READABLE, because it is now the only
'    one on the screen. It gets two lines instead of the caption's one, 21px
'    on an 85%-black foot (about 14:1 even over a white poster), and it is
'    left-aligned on the same margin as the source tag so the eye knows where
'    to find it. See PosterCard.xml.
'
' 2. ONE NAME PER SCREEN, NOT ONE PER ROW. Home has five or more grids on a
'    page where VOD has one, and every grid keeps a current item. The gate
'    below is the same one ChannelCard uses for its focus treatment -
'    itemHasFocus, which a grid raises for its focused item and drops when the
'    grid itself is not the focused one - plus the RowList form of the same
'    question for Search and the VOD rows view. So a row that is merely
'    scrolled to, on a screen whose focus is elsewhere, shows no name.
'
'    >>> UNCERTAIN, AND THE FIRST THING TO LOOK AT ON THE TV: if a Home page
'    shows a name on several rows at once, then itemHasFocus is NOT being
'    dropped when a grid loses focus, and the fix is for the screen to set
'    gridHasFocus false on the rows it is not on. That field already exists on
'    this card and on ChannelCard and no caller has ever set it - and if that
'    is what is happening, ChannelCard's orange focus edge has the identical
'    problem on the identical page, so it will be obvious. <<<
'
' 3. WHEN FOCUS LEAVES THE GRID ENTIRELY - the member goes up to the VOD
'    category strip, or out to the sidebar - the grid shows NO titles at all.
'    That is the honest consequence of what was asked for, and it is what
'    Android does with its own focus-driven labels. If it turns out to be
'    disorienting on the real screen, the one-line change is to drive
'    visibility from `focused` alone rather than `live` below, which leaves
'    the remembered card named while focus is away. It is left as-is because
'    on Home that same change is what would put a name on all five rows.
'
' EVERYTHING IS SET BOTH WAYS. onContent() calls this on every bind, which is
' what stops the name stranding: the focused tile is the first one a scrolling
' grid recycles, and a name left visible on it would follow the wrong poster
' down the grid. m.name.text is written in onContent BEFORE this runs, so a
' card that becomes focused in the same pass can never flash the previous
' title.
' >>> gridHasFocus IS NOT ASKED ANY MORE, AND THAT WAS A REAL BUG. Fixed
'     2026-08-26 after a device build showed no title foot and no ring on any
'     Home poster. <<<
'
' gridHasFocus and rowListHasFocus are not two opinions about the same thing.
' They belong to two DIFFERENT container types and each container sets its own:
' an ArrayGrid/MarkupGrid drives gridHasFocus, a RowList drives
' rowListHasFocus. Whichever container a card is actually in, the other field
' is the one nobody drives - and a RowList does not leave gridHasFocus at the
' `value="true"` this component declares, it sets it false.
'
' So ANDing the two could only ever be true in a MarkupGrid. In a RowList -
' which is every Home poster row, VodScreen's rows view and Search - `live`
' was false forever, the name foot never appeared on the card the member was
' on, and nobody noticed because the list's own orange ring was doing the
' highlighting. The moment the ring was moved onto this card (it has since been
' moved back), the screen had no focus indicator at all.
'
' SportsCard.brs:53-60 is the same card pattern in the same app inside a
' RowList, it gates on rowListHasFocus ALONE, and its focus treatment works on
' the television. This now matches it.
'
' Dropping gridHasFocus costs nothing in a MarkupGrid either: itemHasFocus is
' raised by a grid for its focused item and dropped when the grid itself is not
' the focused one, so the grid case is still gated - by the field that actually
' answers the question rather than by a second one that agrees with it.
'
' Set BOTH ways every time, like everything else on this card - a card that
' scrolls out of focus and is recycled onto the next poster would otherwise
' carry the previous item's name with it.
sub onFocus()
    ' Grid signals via itemHasFocus; rows via focusPercent/rowFocusPercent.
    focused = (m.top.itemHasFocus or (m.top.focusPercent >= 0.5 and m.top.rowFocusPercent >= 0.5))
    live = (focused and m.top.rowListHasFocus)
    m.name.visible = live
    m.footFade.visible = live
    m.footPlate.visible = live
    ' The ring rides on the SAME `live` as the name foot, so the card wearing
    ' the highlight and the card showing its title can never disagree. Set both
    ' ways every time - a card recycled out of focus would otherwise carry the
    ' previous poster's ring with it.
    ' The frame is on for the whole life of a rounded card now; what focus
    ' changes is its COLOUR. Both branches are written every time - a recycled
    ' card that only ever had the "focused" branch run would carry the orange
    ' onto the next poster.
    if live
        m.ring.blendColor = m.ringFocus
    else
        m.ring.blendColor = m.ringIdle
    end if
    m.ring.visible = m.cardRound
    m.ringLive = live
    applyResumeGeom()
end sub
