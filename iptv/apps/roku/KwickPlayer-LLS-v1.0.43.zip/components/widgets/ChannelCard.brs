sub init()
    m.theme = KwickTheme()

    ' ---- The card itself ----------------------------------------------------
    ' Held rather than found per bind: onFocus runs on every focus move AND on
    ' every recycled bind while a grid scrolls, and it writes three of these.
    m.card = m.top.findNode("card")
    m.plate = m.top.findNode("plate")
    m.edge = m.top.findNode("edge")
    m.logo = m.top.findNode("logo")
    m.name = m.top.findNode("name")

    ' The plate and the edge are WHITE nine-patches (tools/make_card_art.py),
    ' so their colour is a blendColor and changing it is one property write
    ' with no reload - certification 3.5 wants the remote answered in 250ms
    ' and a focus move must never rebuild anything.
    '
    ' THE TWO PLATE COLOURS. The resting one is the theme surface, the same
    ' grey this tile has always been. The lifted one is NOT surfaceElevated
    ' (0x25272B): that token is a one-step lift meant for a panel sitting on
    ' the page, and at ten feet, against this page background, the step from
    ' 0x1A1C1F to 0x25272B is not a state change - you cannot see it from the
    ' sofa, which is exactly the complaint this rebuild is answering. 0x3E434B
    ' is about four times the resting plate in linear luminance and reads as
    ' a lit card rather than a slightly different grey.
    ' >>> RE-DERIVED FOR NORD SHELL, and it HAD to be. <<<
    ' The old lift was 0x3E434B, four times the OLD resting plate (0x1A1C1F)
    ' in linear luminance. Nord's surface is 0x3B4252, which is almost
    ' exactly 0x3E434B's own luminance - 0.054 against 0.055 - so leaving
    ' that number in place would have made the focused tile IDENTICAL to the
    ' resting one and deleted the cue this whole rebuild was about.
    ' 0x616E88 is Nord's own bright slate (the "nord3 bright" every Nord
    ' port carries): luminance 0.152 against the plate's 0.054, so about
    ' 2.8x, which is the same kind of step the old pair had. It is still not
    ' the only cue - the card also grows 4% and its name goes from
    ' textSecondary to textPrimary.
    ' Both now come off the palette — the lift moved into Theme.brs as
    ' `surfaceLift` so it is one line to reskin with everything else, and so
    ' the next person looking for the app's colours finds all of them in one
    ' file. The value and the reasoning above are unchanged.
    m.plateRest = m.theme.surface
    m.plateLift = m.theme.surfaceLift
    m.plate.blendColor = m.plateRest
    ' The tile wears its frame at REST as well now - the same port of
    ' Android's terminal-skin idle border that PosterCard does, and the long
    ' argument for it is written out there. Frost at 60% resting, full-
    ' strength focus colour on focus. Both written in onFocus, every time.
    m.edgeIdle = m.theme.cardIdleBorder
    m.edgeFocus = m.theme.focusHighlight
    m.edge.blendColor = m.edgeIdle
    m.edge.visible = true

    ' THE LIFT. Roku has no drop shadow and no blur, so "the card comes
    ' forward" has to be size. The card is drawn 6px/5px inside its grid cell
    ' and grows to fill the cell on focus - a grid item is CLIPPED to its
    ' exact cell, so the growth has to be headroom the resting card gave up,
    ' never headroom taken from outside. 1.04 on 272 x 196 is 282.9 x 203.8
    ' against a 284 x 206 cell: about 11px wider and 8px taller, which is a
    ' visible step at ten feet without being a jolt as focus runs along a row.
    '
    ' One field, one write, no relayout of the card contents - the whole Group
    ' is transformed. Set BOTH ways in onFocus like everything else here.
    m.scaleRest = [1.0, 1.0]
    m.scaleLift = [1.04, 1.04]
    m.card.scale = m.scaleRest

    ' JetBrains Mono at 19, where this was Roboto-Medium at 21. The name box
    ' is 252 wide, ONE line, centred. Mono's flat 0.6em advance is 12.6px at
    ' 21 (20 characters) against Roboto's ~10.5px (24); at 19 it is 11.4px
    ' and 22, so the tile loses two characters of channel name rather than
    ' four. Long names already truncated here - this makes it happen a little
    ' sooner and that is UNVERIFIED on the television.
    m.name.font = UiBoldFont(19)
    m.name.color = m.theme.textSecondary

    ' Source tag (top-left): a fixed dark plate, a coloured DOT, and the plain
    ' source name. Android's rule, ported verbatim in the same pass that gave
    ' PosterCard the same tag — see the long note in ChannelCard.xml.
    m.srcTagBg = m.top.findNode("srcTagBg")
    m.srcDot = m.top.findNode("srcDot")
    m.srcTag = m.top.findNode("srcTag")
    ' 15, not 17: the tag is auto-width, so mono at 17 would just make the
    ' corner plate ~20% wider over the logo rather than truncate anything.
    m.srcTag.font = UiBoldFont(15)
    ' THE LABEL IS ALWAYS WHITE ON AN ALWAYS-DARK PLATE. That is the whole
    ' benefit of moving the colour into a dot: one legibility answer for the
    ' tag text instead of one per source, set once here, and nothing per-bind
    ' can ever change it.
    m.srcTag.color = "0xFFFFFFFF"
    ' Source colour, same scheme the VOD posters and the VOD chips use — one
    ' colour per playlist so a merged channel folder isn't a wall of grey
    ' tags. Palette read once at init; never per bind. See SrcPalette().
    m.srcPalette = SrcPalette()
    m.srcSlot = {}
    ' The plate is a CONSTANT now: it no longer carries the source colour, so
    ' there is nothing per-source left on it to smear across a recycled card.
    ' Written once, here, and never again.
    m.srcTagBg.color = "0x000000E6"
    ' ---- Where the label and the plate sit, with a dot and without one -------
    ' Named rather than inlined because showSrcTag has to write BOTH cases on
    ' every bind and the two must stay in step. Plate x=8; 5px pad, 12px dot,
    ' 5px gap, label, 5px pad. The bare (no dot) case is left at exactly the
    ' 6px it always had, so a single-source box's tag is byte-for-byte what it
    ' was.
    m.tagTextX = 30      ' label x with a dot
    m.tagTextXBare = 14  ' label x with no dot (exactly where it always sat)
    m.tagPadDot = 27     ' plate width = label width + this, with a dot
    m.tagPadBare = 12    ' plate width = label width + this, with none
    ' The colours the member painted their sources with on their phone, which
    ' beat the hashed guess above wherever there is one. A plain map of
    ' "t<token>" -> { bg, mark }, built once per sync cycle in Store.brs and
    ' left on the global node so a recycling card can have it for one
    ' associative-array hit — the card must never read the registry itself
    ' (that is "a visible stutter on a stick", Store.brs RefreshFavVodIndex).
    ' Held in m rather than read off the node per bind, because a node field
    ' read is not free either.
    m.srcSynced = {}

    ' ---- The band over the foot of the artwork (see ChannelCard.xml) --------
    m.nowPlate = m.top.findNode("nowPlate")
    m.nowPlate.color = "0x000000CC"
    m.nowText = m.top.findNode("nowText")
    ' 15, where this was Roboto-Medium at 17. The what's-on line is 240 wide
    ' and one line, and programme titles are the longest strings on this
    ' tile. Roboto at 17 averaged ~8.5px a character and fitted about 28;
    ' mono at 17 is a flat 10.2px and fits 23. At 15 it is 9px and 26, so
    ' the line loses two characters instead of five. Regular rather than
    ' bold - this is the quiet line under the logo, not the tile's name.
    m.nowText.font = UiFont(15)
    m.nowText.color = m.theme.textPrimary

    m.progTrack = m.top.findNode("progTrack")
    ' Android's LinearProgressIndicator sits on Colors.black45 here, and the
    ' fill takes the theme accent so the bar reskins with everything else.
    m.progTrack.color = "0x00000073"
    m.progFill = m.top.findNode("progFill")
    m.progFill.color = m.theme.accent
    m.progW = 252      ' the track's width; the fill is a fraction of it

    ' Watching somewhere else in the app must show up here when you come
    ' back — finish half a film and the tile you left should have a bar on
    ' it. Same arrangement the poster hearts use (PosterCard): the card
    ' watches the index rather than the screens re-assigning content, which
    ' would throw away the row's scroll position.
    '
    ' The field is created here if nobody has yet, rather than in
    ' AppScene.brs where the other session globals are declared — that file
    ' belongs to another lane. It is one map for the whole app, so whoever
    ' gets there first makes it.
    '
    ' >>> observeFieldScoped, NOT observeField. See the long note at the same
    ' spot in PosterCard.brs — it is the same defect and the same fix. m.global
    ' outlives every screen, and a plain observeField leaves THIS CARD in the
    ' global's observer list for the life of the app, holding its decoded
    ' artwork. This card's logo decodes at loadHeight=140 in a 1.8:1 box, about
    ' 141 KB, and the Live TV grid builds sixteen of them per visit; Home
    ' builds more. The scoped form ties the registration to the card's own
    ' lifetime, so the observer goes when the card goes.
    if m.global <> invalid
        if not m.global.hasField("resumeVodIndex") then m.global.addFields({ resumeVodIndex: {} })
        m.global.observeFieldScoped("resumeVodIndex", "onResumeIndexChanged")
        ' The same arrangement, for the other half of the band. An Xtream
        ' channel's "what's on now" is not known when the grid is built —
        ' there is no guide file to read it out of — so LiveTvScreen looks it
        ' up one channel at a time as the member stops on each and drops the
        ' answer into this map. Watching the map is what lets the caption
        ' appear on a tile that is already on screen: re-assigning the grid's
        ' content would repaint it but would also throw the member back to the
        ' first channel in the folder.
        if not m.global.hasField("liveNowById") then m.global.addFields({ liveNowById: {} })
        m.global.observeFieldScoped("liveNowById", "onLiveNowChanged")
        ' Same arrangement once more, for the source colours the member picked
        ' on their phone. The field is made here if nobody has yet for the
        ' reason above; Store.brs only ever SETS it, because creating fields on
        ' the global is the render thread's job and that publisher also runs on
        ' the sync task's thread.
        '
        ' Watched, not just read once, because a colour can arrive while a grid
        ' is already on screen — the sync cycle that fetches it finishes
        ' seconds after launch, and re-assigning the grid's content to repaint
        ' would throw the member back to the first channel in the folder.
        if not m.global.hasField("srcColorIdx") then m.global.addFields({ srcColorIdx: {} })
        m.global.observeFieldScoped("srcColorIdx", "onSrcColorsChanged")
        m.srcSynced = m.global.srcColorIdx
    end if
end sub

sub onResumeIndexChanged()
    showBand(m.top.itemContent)
end sub

sub onLiveNowChanged()
    showBand(m.top.itemContent)
end sub

sub onSrcColorsChanged()
    m.srcSynced = m.global.srcColorIdx
    showSrcTag(m.top.itemContent)
end sub

sub onContent()
    c = m.top.itemContent
    if c = invalid
        ' A recycled card handed nothing keeps whatever it was last showing.
        ' Clearing the source tag here is narrow on purpose — it is the part
        ' this pass rebuilt, and without it the previous channel's dot and
        ' source name ride along onto a tile that has no source of its own.
        ' (The logo, name and band have always taken the bare return; that is
        ' older than this change and is left for whoever owns it.)
        showSrcTag(invalid)
        return
    end if
    if c.hdPosterUrl <> ""
        m.logo.uri = c.hdPosterUrl
    else
        m.logo.uri = ""
    end if
    m.name.text = c.title
    showSrcTag(c)
    showBand(c)
    ' Recycled card: recompute the whole focus treatment from current state.
    ' A card that had focus a moment ago is handed a different channel while
    ' it is still scaled up, and without this it would stay lifted and lit on
    ' the wrong tile.
    onFocus()
end sub

' The strip across the foot of the artwork, and which of the two things that
' want it gets it.
'
' A Live TV tile shows WHAT IS ON NOW; a Home tile shows HOW FAR IN you are.
' Nothing is ever both — a channel has no resume point and a film has no
' listing — but this decides rather than assuming, because the two draw over
' each other and a single odd item would look like a rendering fault.
' What's on now wins: it is the more perishable of the two.
'
' EVERY node is set BOTH ways on EVERY bind. This card recycles constantly
' (the same rule the source tag below follows, for the same reason): a tile
' with no bar has to actively clear the bar, or the last title's progress
' and the last channel's programme smear down the grid as soon as anything
' scrolls.
sub showBand(c as dynamic)
    now = ""
    if c <> invalid and c.hasField("nowTitle") then now = c.nowTitle
    ' Nothing from the guide file: this may be an Xtream channel whose
    ' listing was looked up after the grid was built. ONE associative-array
    ' hit on a key that is already on the item — no provider lookup, no
    ' registry read, no clock read and above all no request. The title in the
    ' map was already resolved to "what is on right now" by LiveTvScreen when
    ' the answer landed. A tile from any other screen has no epgKey and skips
    ' this entirely.
    if now = "" then now = liveNowFor(c)
    pct = 0
    if now = "" then pct = resumePct(c)

    if now <> ""
        m.nowText.text = now
        m.nowText.visible = true
        m.nowPlate.visible = true
    else
        m.nowText.text = ""
        m.nowText.visible = false
        m.nowPlate.visible = false
    end if

    if pct > 0
        w = Int(m.progW * pct / 100.0)
        if w < 4 then w = 4      ' 1% of 252px is a smudge, not a bar
        m.progFill.width = w
        m.progFill.visible = true
        m.progTrack.visible = true
    else
        m.progFill.width = 4
        m.progFill.visible = false
        m.progTrack.visible = false
    end if
end sub

' What is on this channel now, from the session map LiveTvScreen fills in —
' or "" for a tile that has no key, a channel nobody has asked about yet, or
' one the panel had no listing for. Blank is the ordinary answer and draws no
' band, which is why nothing here distinguishes the three cases.
function liveNowFor(c as dynamic) as string
    if c = invalid then return ""
    if not c.hasField("epgKey") then return ""
    key = c.epgKey
    if key = "" then return ""
    if m.global = invalid or not m.global.hasField("liveNowById") then return ""
    v = m.global.liveNowById[key]
    ' Typed check rather than ToStr(): this file only pulls in Theme.brs, and
    ' a caption is not worth dragging Util.brs into every card in the app.
    if type(v) = "roString" or type(v) = "String" then return v
    return ""
end function

' How far into this title the profile is, 1..99, or 0 for "draw no bar".
'
' ONE associative-array hit and nothing else. The map was built once by
' whichever screen filled this grid — never here, and never per tile: a
' registry read per card while a grid recycles is "a visible stutter on a
' stick" (Store.brs, RefreshFavVodIndex), and asking a provider where you
' are in something, per tile, is the loop that got this house's address
' banned on 2026-08-14.
'
' The key is the SAME string the favorite hearts use (FavVodKeyFor:
' "<src>:<kind>:<id>", bare for KwickTV), so a title half-watched on one
' source never puts a bar on the same-numbered title of another.
'
' The number is the same fraction Android draws — position over duration
' (home_screen.dart:520, handed to MediaCard at :546, drawn at
' media_card.dart:95) — pre-rounded here to 1..99 by MediaBarPercent, which
' refuses both 0% and 100%: a "continue watching" bar at either end is a
' contradiction. HomeScreen.refreshResumeVodIndex() builds the map.
function resumePct(c as dynamic) as integer
    if c = invalid then return 0
    if not c.hasField("favKey") then return 0
    key = c.favKey
    if key = "" then return 0
    if m.global = invalid or not m.global.hasField("resumeVodIndex") then return 0
    v = m.global.resumeVodIndex[key]
    if v = invalid then return 0
    return Int(v)
end function

' The source tag, top-left of the card.
'
' Cards recycle constantly, so this must be SET both ways every time — leaving
' it alone would smear the previous tile's source across the grid (the same
' rule the poster hearts follow). That means all FOUR things that move, not
' just the visibility: the dot's colour, the dot's visibility, the LABEL'S X
' and the plate's WIDTH. A tag that goes from "dot + name" to "name" and only
' has its dot hidden would leave the label stranded 16px to the right with a
' plate the wrong length, and the next tile would wear it.
'
' Its own sub rather than a block inside onContent because the colour can now
' change without the content changing (see onSrcColorsChanged).
sub showSrcTag(c as dynamic)
    tag = ""
    if c <> invalid and c.hasField("srcLabel") then tag = c.srcLabel
    if tag = ""
        m.srcDot.visible = false
        m.srcTag.visible = false
        m.srcTagBg.visible = false
        return
    end if
    m.srcTag.text = tag
    dot = srcDotColor(c)
    if dot <> ""
        m.srcDot.blendColor = dot
        m.srcDot.visible = true
        m.srcTag.translation = [m.tagTextX, 6]
        m.srcTagBg.width = Int(m.srcTag.boundingRect().width) + m.tagPadDot
    else
        m.srcDot.visible = false
        m.srcTag.translation = [m.tagTextXBare, 6]
        m.srcTagBg.width = Int(m.srcTag.boundingRect().width) + m.tagPadBare
    end if
    m.srcTag.visible = true
    m.srcTagBg.visible = true
end sub

' The DOT colour for this channel's source, or "" for no dot at all.
'
' The member's own choice first, this app's guess second. A colour painted on
' the phone arrives over KwickSync and is resolved once per cycle in
' Store.brs; anything with no choice against it falls back to the hashed
' palette, which is what every source looked like before and what a box with
' no sync still looks like. `mark` rather than `bg`: bg is the deep, slightly
' transparent plate tint this tag used to wear, and a dot wants the solid
' full-strength colour — which is what PosterCard's dot and the VOD chip row
' both draw, so a source is the same pixel value everywhere it appears.
'
' LiveTvScreen writes srcTok onto the item next to srcLabel, so the token is
' already on the node — no provider lookup and no registry read while the grid
' recycles. One associative-array hit for the synced answer; for the fallback
' each token is hashed once per card and remembered after that. "t" prefixes
' both keys so KwickTV's empty-string token is an ordinary key — the same
' string Store.brs builds with SrcColorMemoKey, and the two must agree. An
' item with no token gets NO DOT rather than a guessed colour, which is
' Android's answer for a source with no colour set.
function srcDotColor(c as object) as string
    if not c.hasField("srcTok") then return ""
    tok = c.srcTok
    k = "t" + tok
    painted = m.srcSynced[k]
    if painted <> invalid then return painted.mark
    if not m.srcSlot.doesExist(k) then m.srcSlot[k] = SrcColorIndex(tok)
    return m.srcPalette[m.srcSlot[k]].mark
end function

' ---- Focus: LIFT, BRIGHTEN, then an edge ------------------------------------
'
' THE OWNER ASKED FOR the card to lift and brighten rather than only gaining
' an outline. Roku gives you no drop shadow and no blur, so the three things
' actually available are size, colour and a border, and this uses all three
' in that order of importance:
'
'   1. SIZE. The card grows 4% to fill its grid cell (see init). This is the
'      one that reads from the sofa, because it is the only cue that does not
'      depend on the television's contrast setting or on the artwork behind
'      it - a card that is physically bigger than its neighbours is bigger
'      whatever the picture on it.
'   2. COLOUR. The plate goes from the page surface to a clearly lit grey.
'      This is what makes it look like a card rather than a hole, and it is
'      the cue that still works when the focused card is at the edge of the
'      screen with no neighbour to be compared against.
'   3. THE EDGE. A 3px rounded orange outline, the app's focus colour. Least
'      important of the three and deliberately thinner than the old 6px
'      double frame, but it is the only cue that is unambiguous on a wall of
'      similar tiles, and it is what a member who has used this app before
'      already looks for.
'
' EVERY ONE OF THESE IS SET BOTH WAYS, every time, and onContent() calls this
' on every bind. That matters more here than for anything else on the card:
' the tile that was focused is the tile a scrolling grid is most likely to
' recycle first, and a scale or a lit plate left behind on it would strand a
' second "focused" card in the middle of the grid.
sub onFocus()
    focused = (m.top.itemHasFocus and m.top.gridHasFocus)
    if focused
        m.card.scale = m.scaleLift
        m.plate.blendColor = m.plateLift
        m.edge.blendColor = m.edgeFocus
        m.name.color = m.theme.textPrimary
    else
        m.card.scale = m.scaleRest
        m.plate.blendColor = m.plateRest
        m.edge.blendColor = m.edgeIdle
        m.name.color = m.theme.textSecondary
    end if
end sub
