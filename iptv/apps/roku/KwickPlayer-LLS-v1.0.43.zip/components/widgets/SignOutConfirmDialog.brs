' The "are you sure?" in front of every add-on sign-out.
'
' Two things this has to do that Roku's own Dialog cannot, both from Mason's
' ruling on JB-7 after he signed out of Simkl by accident:
'
'   CANCEL IS FOCUSED FIRST, so the button under the OK key is the safe one.
'   A HELD OK CANNOT ANSWER IT — see arming, below.

sub init()
    m.theme = KwickTheme()

    m.top.findNode("scrim").color = ColorWithAlpha(m.theme.background, 232)
    m.top.findNode("frame").color = m.theme.accent
    m.top.findNode("plate").color = m.theme.surfaceElevated

    m.title = m.top.findNode("titleLabel")
    m.title.font = UiBoldFont(38)
    m.title.color = m.theme.textPrimary

    m.message = m.top.findNode("messageLabel")
    ' 1000px at 26 JetBrains Mono (a flat 0.6em advance) is 64 characters a
    ' line, six lines being 384. The longest wording this dialog carries is
    ' Simkl's, at about 250, so it fits with room to spare.
    m.message.font = UiFont(26)
    m.message.color = m.theme.textSecondary

    m.buttons = [
        { wrap: m.top.findNode("btnConfirm"), ring: m.top.findNode("confirmRing"), bg: m.top.findNode("confirmBg"), lbl: m.top.findNode("confirmLabel") },
        { wrap: m.top.findNode("btnCancel"), ring: m.top.findNode("cancelRing"), bg: m.top.findNode("cancelBg"), lbl: m.top.findNode("cancelLabel") }
    ]
    for each b in m.buttons
        b.lbl.font = UiBoldFont(28)
        b.ring.color = m.theme.focusHighlight
    end for

    ' CANCEL, not the primary action. The whole point of the dialog.
    m.focus = 1

    ' ---- Arming -------------------------------------------------------------
    ' A held OK on the Sign out row auto-repeats: Roku sends press=true over
    ' and over and sends press=false ONCE, when the finger comes off. So a
    ' release is proof the member has let go, and it is the only thing that
    ' normally unlocks the buttons here.
    '
    ' The belt to that braces: if the release of the press that opened this
    ' dialog were ever delivered to the screen underneath instead of to us,
    ' arming would never happen and the dialog would be unanswerable. So a
    ' fresh OK also gets through when the dialog has been up for 600 ms AND
    ' no other OK has been seen in the last 600 ms. Roku's auto-repeat is far
    ' faster than that, so a finger that is still down can never satisfy it,
    ' while somebody pressing OK deliberately a second later always can.
    m.armed = false
    m.span = CreateObject("roTimespan")
    m.span.mark()
    m.lastOkMs = -1

    redraw()
end sub

sub redraw()
    if m.title = invalid then return
    m.title.text = m.top.title
    m.message.text = m.top.message

    ' Both buttons, both ways, every time — including the colours, not just
    ' the ring. A button whose fill is only ever set in its "focused" branch
    ' keeps the last one's fill when focus moves off it.
    paintButton(0, m.top.confirmText)
    paintButton(1, m.top.cancelText)
end sub

sub paintButton(idx as integer, text as string)
    b = m.buttons[idx]
    b.lbl.text = text
    focused = (m.focus = idx)
    b.ring.visible = focused
    if idx = 0
        ' The destructive one never wears the accent: the accent fill is what
        ' this app uses for "press this", and this is not the button anybody
        ' should press by reflex. It gets surfaceLift rather than surface or
        ' surfaceElevated, because the PLATE under it is already
        ' surfaceElevated and a one-step lift on top of that is invisible
        ' from a sofa — the member still has to be able to see that there is
        ' a second button there.
        b.bg.color = m.theme.surfaceLift
        b.lbl.color = m.theme.textPrimary
    else
        b.bg.color = m.theme.accent
        ' The palette accent is a light frost blue, so the ink on it is the
        ' page colour rather than white - 6:1 instead of 1.9:1.
        b.lbl.color = m.theme.background
    end if
end sub

sub moveFocus(by as integer)
    ' Any arrow key is proof the member is no longer holding OK down.
    m.armed = true
    idx = m.focus + by
    if idx < 0 then idx = 0
    if idx > 1 then idx = 1
    if idx = m.focus then return
    m.focus = idx
    redraw()
end sub

sub answerWith(kind as string)
    m.top.choice = kind
end sub

' Every key is swallowed while this is up, answered or not, so nothing
' reaches the page underneath — a Back that closed the screen out from under
' an open dialog would be the same accident in a different coat.
function onKeyEvent(key as string, press as boolean) as boolean
    if not press
        if key = "OK" then m.armed = true
        return true
    end if

    if key = "back"
        answerWith("cancel")
        return true
    else if key = "left"
        moveFocus(-1)
        return true
    else if key = "right"
        moveFocus(1)
        return true
    else if key = "up" or key = "down"
        m.armed = true
        return true
    else if key = "OK"
        ms = m.span.totalMilliseconds()
        letThrough = m.armed
        if not letThrough
            if ms >= 600 and (m.lastOkMs < 0 or (ms - m.lastOkMs) >= 600) then letThrough = true
        end if
        m.lastOkMs = ms
        if not letThrough then return true
        if m.focus = 0
            answerWith("confirm")
        else
            answerWith("cancel")
        end if
        return true
    end if
    return true
end function
