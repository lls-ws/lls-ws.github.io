' The subtitle search picker. See SubsSearchScreen.xml for the shape, for why
' it is attached to the scene, and for the request budget it keeps to.

sub init()
    m.theme = KwickTheme()
    m.top.findNode("panel").color = m.theme.surface

    m.title = m.top.findNode("title")
    ' 34, the same as SubtitlePickerScreen's heading. The longest thing this
    ' ever says is "Search OpenSubtitles" — 20 characters, 408px of
    ' JetBrains Mono in a 1440px box.
    m.title.font = UiBoldFont(34)
    m.title.color = m.theme.textPrimary

    m.matchLine = m.top.findNode("matchLine")
    m.matchLine.font = UiFont(23)
    m.matchLine.color = m.theme.textSecondary

    m.note = m.top.findNode("note")
    m.note.font = UiFont(23)
    m.note.color = m.theme.textSecondary

    m.hint = m.top.findNode("hint")
    m.hint.font = UiFont(21)
    m.hint.color = m.theme.textSecondary
    m.hint.text = "Press OK to use a subtitle, Back to leave."

    m.spinner = m.top.findNode("spinner")
    m.list = m.top.findNode("list")
    m.list.observeField("itemSelected", "onRowSelected")
    m.top.observeField("focusedChild", "onFocusIn")

    ' ONE job at a time. Every request on this screen is gated on this flag:
    ' a second press while something is in flight is DROPPED, not queued.
    ' Queueing would turn a member leaning on the OK button into a burst of
    ' identical requests, which is the shape that gets an account cut off.
    m.busy = false
    m.rows = []
    m.searchTask = invalid
    m.linkTask = invalid
    m.fileTask = invalid
    ' Which subtitles are already on this box, filled in once when the
    ' results arrive — one directory listing, not one question per row.
    m.onDisk = {}
    m.done = false
    ' The row and the path a fetch in flight belongs to, and the member's
    ' own OpenSubtitles allowance from the link answer. Set here so the
    ' Subdl path, which never sees an allowance, still reads empties rather
    ' than a missing member.
    m.pendingRow = invalid
    m.pendingPath = ""
    m.remaining = ""
    m.resetUtc = ""
end sub

function serviceName() as string
    if m.top.source = "subdl" then return AddOnLabel("subdl")
    return AddOnLabel("opensubtitles")
end function

sub onFocusIn()
    if m.top.hasFocus() and m.list.visible then m.list.setFocus(true)
end sub

sub onStart()
    if m.top.start <> true then return
    m.title.text = "Search " + serviceName()
    who = ToStr(m.top.matchText)
    lang = LangName(ToStr(m.top.prefLang))
    if who = ""
        m.matchLine.text = lang + " first"
    else
        m.matchLine.text = who + "   " + Chr(&hB7) + "   " + lang + " first"
    end if
    doSearch()
end sub

' ---- The search -------------------------------------------------------------

sub doSearch()
    if m.busy then return
    if ToStr(m.top.searchUrl) = ""
        ' The player could not build an address, which means it has neither a
        ' TMDB id nor a name for what is playing. Say the true thing rather
        ' than searching for nothing.
        setNote("There isn't enough information about this title to search for subtitles.")
        return
    end if
    t = CreateObject("roSGNode", "AddOnTask")
    if t = invalid
        ' AddOnTask lands in this same dev build. A missing component answers
        ' invalid rather than throwing, so this is a sentence on screen and
        ' not a dead screen with a spinner on it.
        setNote("The part of the app that talks to " + serviceName() + " isn't in this build yet.")
        return
    end if
    setBusy(true)
    setNote("Looking for subtitles...")
    ' The address, which never carries a token — see the comment on bearer
    ' below. It is the other half of the answer the result line gives.
    KLog("subs", "asking " + serviceName() + ": " + ToStr(m.top.searchUrl))
    t.url = m.top.searchUrl
    t.method = "GET"
    t.timeoutMs = 20000
    t.tag = "subs-search"
    ' OpenSubtitles only, and only when the member is signed in. It rides in
    ' the Authorization header AddOnTask builds; it is never put in the URL,
    ' because a URL ends up in the diagnostic log and a token in a log is a
    ' token in a member's support email.
    if ToStr(m.top.bearer) <> "" then t.bearer = m.top.bearer
    t.observeField("result", "onSearchResult")
    m.searchTask = t
    t.control = "RUN"
end sub

sub onSearchResult(event as object)
    m.searchTask = invalid
    setBusy(false)
    res = event.getData()
    if res = invalid or GetField(res, "ok") <> true
        ' WHAT THE RELAY ACTUALLY SAID, once per search. Added 2026-09-19
        ' after an OpenSubtitles search drew "No subtitles for this title"
        ' for a film the same relay answered with fifty-nine of from a
        ' desk — with nothing in the log, there was no way to tell a real
        ' empty answer from a refusal. The code and the status, never the
        ' token: the URL carries no token by design and this line carries
        ' no URL.
        KLog("subs", serviceName() + " search refused - code '" + ToStr(GetField(res, "code")) + "', http " + ToStr(GetField(res, "status")))
        setNote(faultText(res))
        return
    end if
    rows = readRows(GetField(res, "data"))
    if rows.count() = 0
        KLog("subs", serviceName() + " search came back with nothing to show - the relay said total " + ToStr(GetField(GetField(res, "data"), "total")))
        setNote("No subtitles for this title on " + serviceName() + " right now.")
        return
    end if
    KLog("subs", serviceName() + " search: " + rows.count().toStr() + " row(s)")
    m.rows = orderByLanguage(rows)
    readWhatIsOnDisk()
    drawRows()
end sub

' The relay answers a list of rows. It has been described as a bare array and
' as an object with the list inside it, so all the shapes it could reasonably
' take are accepted here rather than only the one that happened to be true on
' the day — a screen that draws "no subtitles" because a wrapper key changed
' name is the worst of both worlds.
function readRows(payload as dynamic) as object
    out = []
    list = payload
    if list <> invalid and type(list) = "roAssociativeArray"
        ' "items" FIRST, because that is what the relay actually answers with:
        ' { ok, total, items:[...] }. Measured against the live relay on
        ' 2026-09-17 - the list was missing it, so a Subdl search for a film
        ' the relay had eighteen subtitles for drew an empty picker. The rest
        ' stay as tolerated spellings in case a future relay differs.
        for each k in ["items", "data", "rows", "results", "subtitles"]
            v = GetField(list, k)
            if v <> invalid and type(v) = "roArray"
                list = v
                exit for
            end if
        end for
    end if
    if list = invalid or type(list) <> "roArray" then return out
    for each it in list
        row = SubsMapRow(it)
        if row <> invalid then out.push(row)
    end for
    return out
end function

' The member's own language at the top, everything else after it in the order
' the service sent. A stable partition, not a sort: the service already ranks
' its own results usefully and re-sorting them would throw that away.
function orderByLanguage(rows as object) as object
    pref = LangName(ToStr(m.top.prefLang))
    head = []
    tail = []
    for each r in rows
        if LangName(ToStr(GetField(r, "language"))) = pref
            head.push(r)
        else
            tail.push(r)
        end if
    end for
    for each r in tail
        head.push(r)
    end for
    return head
end function

' ONE directory listing for the whole result set. Never a question per row:
' the rule in this house is that a list does not do per-item work, and a
' stat() per row on a list of fifty is exactly that shape even when the work
' is local.
sub readWhatIsOnDisk()
    m.onDisk = {}
    fs = CreateObject("roFileSystem")
    if fs = invalid then return
    lst = fs.GetDirectoryListing("cachefs:/")
    if lst = invalid then return
    for each nm in lst
        m.onDisk[ToStr(nm)] = true
    end for
end sub

function haveOnDisk(row as dynamic) as boolean
    nm = cacheFileName(row)
    if nm = "" then return false
    return m.onDisk.doesExist(nm)
end function

sub drawRows()
    content = CreateObject("roSGNode", "ContentNode")
    have = 0
    for each r in m.rows
        item = content.createChild("ContentNode")
        ' Line 1: the language in words and the release name. Language name
        ' rather than the bare ISO code, the same way the track picker
        ' already says "Spanish 2" and not "spa".
        item.title = LangName(ToStr(GetField(r, "language"))) + "   " + releaseOf(r)
        ' Line 2: the badges, from the shared reader so this screen and
        ' Android describe the same subtitle the same way.
        item.description = badgeLine(r)
        if haveOnDisk(r)
            item.shortDescriptionLine2 = "On this device"
            have = have + 1
        else
            ' BOTH WAYS, always. Rows are recycled, and a mark left over
            ' from the previous item would tell a member they already have a
            ' subtitle they have never fetched.
            item.shortDescriptionLine2 = ""
        end if
    end for
    m.list.content = content
    m.list.jumpToItem = 0
    m.list.visible = true
    m.list.setFocus(true)
    ' Both counts read as English at one. "18 subtitles found. 1 of them are
    ' already on this device" is the kind of line that makes an app look
    ' unfinished, and one match is the ordinary case for a member who has
    ' been here before.
    if m.rows.count() = 1
        txt = "1 subtitle found."
    else
        txt = m.rows.count().toStr() + " subtitles found."
    end if
    if have > 0
        if m.rows.count() = 1
            txt = txt + " You already have it on this device, so it costs nothing to use again."
        else if have = 1
            txt = txt + " One of them is already on this device and costs nothing to use again."
        else
            txt = txt + " " + have.toStr() + " of them are already on this device and cost nothing to use again."
        end if
    end if
    setNote(txt)
end sub

function releaseOf(row as dynamic) as string
    rel = ToStr(GetField(row, "release")).trim()
    if rel = "" then return "(no release name)"
    return rel
end function

' The badge half of SubsRowLabel, on its own line. SubsRowLabel builds one
' string with the badges in brackets at the end, which is right for a
' one-line list; this screen has two lines, so the same facts are split
' across them rather than described differently.
function badgeLine(row as dynamic) as string
    full = SubsRowLabel(row)
    at = Instr(1, full, "  (")
    if at <= 0 then return ""
    out = Mid(full, at + 3)
    if Right(out, 1) = ")" then out = Left(out, Len(out) - 1)
    return out
end function

' ---- Fetching the one the member picked -------------------------------------

sub onRowSelected()
    if m.busy then return
    i = m.list.itemSelected
    if i < 0 or i >= m.rows.count() then return
    row = m.rows[i]

    path = cachePath(row)
    if path = ""
        setNote("That subtitle has nothing to identify it, so it can't be fetched.")
        return
    end if

    ' ALREADY IN HAND — no request of any kind. This is the whole reason the
    ' cache exists: every download comes out of the member's own daily
    ' allowance (OpenSubtitles counts it against their account, a Subdl file
    ' spends their own anonymous 300-a-day), so coming back to a film they
    ' have already fetched a subtitle for must be free.
    if haveOnDisk(row)
        finishWith(row, path, "", "")
        return
    end if

    if ToStr(GetField(row, "source")) = "subdl"
        ' Subdl NEVER touches the relay for a download. The row carries the
        ' address and the box fetches it straight from dl.subdl.com with no
        ' key at all — which is what keeps Kwick Player's own shared key off
        ' every member's device.
        fetchFile(row, ToStr(GetField(row, "url")), path)
        return
    end if

    ' OpenSubtitles: ask the relay for a short-lived link, with the member's
    ' own token. The answer also carries what is left of their allowance.
    fid = ToStr(GetField(row, "fileId"))
    if fid = ""
        setNote("That subtitle is missing its file number, so it can't be fetched.")
        return
    end if
    if ToStr(m.top.bearer) = ""
        setNote("Sign in to OpenSubtitles first, in Settings, then Add-ons.")
        return
    end if
    t = CreateObject("roSGNode", "AddOnTask")
    if t = invalid
        setNote("The part of the app that talks to " + serviceName() + " isn't in this build yet.")
        return
    end if
    setBusy(true)
    setNote("Fetching that subtitle...")
    m.pendingRow = row
    m.pendingPath = path
    t.url = SubsDownloadUrl()
    t.method = "POST"
    t.bodyJson = FormatJson({ file_id: fid })
    t.bearer = m.top.bearer
    t.timeoutMs = 20000
    t.tag = "subs-download"
    t.observeField("result", "onLinkResult")
    m.linkTask = t
    t.control = "RUN"
end sub

sub onLinkResult(event as object)
    m.linkTask = invalid
    res = event.getData()
    if res = invalid or GetField(res, "ok") <> true
        setBusy(false)
        ' AN OPENSUBTITLES SIGN-IN THAT HAS RUN OUT, which is not the same
        ' thing as a password typed wrong — and until 2026-09-19 the member
        ' got the sign-in box's words for it: "That sign-in was not accepted.
        ' Check the username and password and try again." They had typed
        ' nothing. Seen on the office stick that day: search answered fifty
        ' results and the download came back refused, while the Add-ons page
        ' still read "Signed in as kwickflix - VIP Member".
        '
        ' OpenSubtitles tokens last about a day and there is NO refresh — the
        ' only way back is the member's own username and password, which this
        ' app deliberately does not keep. So the honest thing is the same
        ' thing a dead Trakt sign-in does: sign the service out on this box,
        ' so the page says "Not signed in" and the words on screen say what
        ' to do. Nothing is touched on their OpenSubtitles account.
        if LCase(faultCode(res)) = "auth" and m.top.source <> "subdl"
            SignOutAddOnAccount("opensubtitles", "Your OpenSubtitles sign-in ran out, so this TV signed out of it. Sign in again in Settings, then Playback.")
            m.top.bearer = ""
            setNote("Your OpenSubtitles sign-in has run out. Sign in again in Settings, then Playback, and this search will work.")
            return
        end if
        setNote(faultText(res))
        return
    end if
    data = GetField(res, "data")
    link = ToStr(GetField(data, "link"))
    if link = ""
        setBusy(false)
        setNote("OpenSubtitles didn't send a link for that subtitle. Try another one.")
        return
    end if
    ' The member's own allowance, kept for the player to word — it owns the
    ' box's 12/24-hour clock rule and there must not be a second copy of it.
    m.remaining = ToStr(GetField(data, "remaining"))
    m.resetUtc = ToStr(GetField(data, "reset_utc"))
    fetchFile(m.pendingRow, link, m.pendingPath)
end sub

sub fetchFile(row as dynamic, url as string, path as string)
    if url = ""
        setBusy(false)
        setNote("That subtitle has no address to fetch from.")
        return
    end if
    t = CreateObject("roSGNode", "SubFileTask")
    if t = invalid
        setBusy(false)
        setNote("That subtitle couldn't be fetched on this build.")
        return
    end if
    setBusy(true)
    setNote("Fetching that subtitle...")
    m.pendingRow = row
    m.pendingPath = path
    t.url = url
    t.savePath = path
    t.timeoutMs = 25000
    t.tag = "subs-file"
    t.observeField("result", "onFileResult")
    m.fileTask = t
    t.control = "RUN"
end sub

sub onFileResult(event as object)
    m.fileTask = invalid
    setBusy(false)
    res = event.getData()
    if res = invalid or GetField(res, "ok") <> true
        why = ToStr(GetField(res, "error"))
        if why = "" then why = "That subtitle couldn't be downloaded."
        setNote(why)
        return
    end if
    finishWith(m.pendingRow, ToStr(GetField(res, "path")), ToStr(m.remaining), ToStr(m.resetUtc))
end sub

sub finishWith(row as dynamic, path as string, remaining as string, resetUtc as string)
    if m.done then return
    m.done = true
    m.top.pickedJson = FormatJson({
        path: path
        lang: ToStr(GetField(row, "language"))
        label: LangName(ToStr(GetField(row, "language"))) + "   " + releaseOf(row)
        fileId: ToStr(GetField(row, "fileId"))
        source: ToStr(GetField(row, "source"))
        ' The address the file came from, carried through so the player can
        ' hand Roku the ADDRESS rather than the downloaded copy. Measured on
        ' the office stick 2026-09-17: a local path on content.SubtitleUrl is
        ' ignored, cachefs: and tmp: alike. Empty on an OpenSubtitles row
        ' whose link is one-use, and the local copy is the fallback.
        url: ToStr(GetField(row, "url"))
        remaining: remaining
        resetUtc: resetUtc
    })
    m.top.closed = true
end sub

' ---- Where a fetched subtitle lives ------------------------------------------
'
' cachefs, beside every other cache in this app, and named so the existing
' sweeps cannot touch it: ApiTask only ever deletes "kwick_api_" files and
' XmltvTask only "kwick_xmltv_".
'
' The name has to be STABLE for the same subtitle and DIFFERENT for any other,
' because it is both the cache key and the "On this device" test. A file id is
' exactly that where there is one. Subdl rows sometimes carry only an address,
' and its addresses are dl.subdl.com/subtitle/<n_id>/<file_n_id> — two ids,
' which is the same thing by another name, so the address's own digits are
' used. Everything that is not a letter or a digit is dropped, so nothing that
' comes off a service can ever build a path.

function cacheFileName(row as dynamic) as string
    key = safeKey(ToStr(GetField(row, "fileId")))
    tag = "os"
    if ToStr(GetField(row, "source")) = "subdl" then tag = "sd"
    if key = "" then key = safeKey(tailOfUrl(ToStr(GetField(row, "url"))))
    if key = "" then return ""
    if Len(key) > 40 then key = Right(key, 40)
    return "kwicksub_" + tag + "_" + key + ".srt"
end function

function cachePath(row as dynamic) as string
    nm = cacheFileName(row)
    if nm = "" then return ""
    return "cachefs:/" + nm
end function

' The last two path segments of a URL, which for dl.subdl.com is the pair of
' ids that names the file. Query strings are cut off first: a link that
' carried a one-time token would otherwise make a different file name on
' every search for the same subtitle, and the cache would never hit.
function tailOfUrl(url as string) as string
    if url = "" then return ""
    q = Instr(1, url, "?")
    if q > 0 then url = Left(url, q - 1)
    parts = url.split("/")
    out = ""
    n = parts.count()
    if n >= 2 then out = parts[n - 2] + "_" + parts[n - 1] else out = url
    return out
end function

function safeKey(s as string) as string
    out = ""
    for i = 1 to Len(s)
        c = Mid(s, i, 1)
        u = UCase(c)
        if (c >= "0" and c <= "9") or (u >= "A" and u <= "Z")
            out = out + c
        else if c = "_"
            out = out + "_"
        end if
    end for
    return out
end function

' ---- Saying what went wrong --------------------------------------------------
'
' The relay writes its faults for a member already, and AddOnErrorText turns
' the code into a sentence. The HTTP status is mapped onto the same four codes
' first, because the two carry the same news by different routes and a member
' must never see a number: 406 is "your downloads for today are gone", 429 is
' "slow down", 401/403 is "that sign-in was not accepted".
' The one code faultText settles on, on its own, so a caller can act on the
' fault as well as word it. ONE set of rules, read twice — a second copy of
' "401 means auth" is exactly how the two would drift.
function faultCode(res as dynamic) as string
    code = ToStr(GetField(res, "errorCode"))
    if isRelayCode(code) then return LCase(code)
    status = ToInt(GetField(res, "status"))
    if status = 406 then return "quota"
    if status = 429 then return "rate"
    if status = 401 or status = 403 then return "auth"
    if status >= 500 then return "server"
    return LCase(code)
end function

function faultText(res as dynamic) as string
    code = ToStr(GetField(res, "errorCode"))
    msg = ToStr(GetField(res, "error"))
    status = ToInt(GetField(res, "status"))
    ' THE RELAY'S OWN WORD WINS whenever it gave one — those four are what
    ' AddOnErrorText is written against and they carry more than a status
    ' code does. AddOnTask's own codes ("http", "network", "timeout",
    ' "badjson") mean something in FRONT of the relay answered, and for
    ' three statuses that still carries real news a member should get in
    ' words rather than as a number.
    if not isRelayCode(code)
        if status = 406
            ' The one that matters most: the relay stops here when the daily
            ' downloads are gone. Without this remap a member reads "The
            ' request was refused (406)", which is a machine code.
            code = "quota"
        else if status = 429
            code = "rate"
        else if status = 401 or status = 403
            code = "auth"
        else if status >= 500
            ' NOT "upstream" — that wording blames the subtitle service, and
            ' a 5xx here is our own server. Said plainly instead, with no
            ' number in it.
            return "kwickplayer.tv isn't answering right now. Try again in a few minutes."
        end if
    end if
    return AddOnErrorText(code, msg, serviceName())
end function

function isRelayCode(s as string) as boolean
    c = LCase(s)
    return c = "auth" or c = "quota" or c = "rate" or c = "upstream"
end function

' ---- Screen state -----------------------------------------------------------

sub setNote(txt as string)
    m.note.text = txt
end sub

sub setBusy(working as boolean)
    m.busy = working
    m.spinner.visible = working
    ' The list keeps focus while something is in flight so Back still works;
    ' it is onRowSelected that refuses to start a second job, not the remote.
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back"
        ' Back from partway down jumps to the top first, the same two-stage
        ' Back the track picker uses, so a long result list is not a long
        ' scroll back before you can leave.
        if m.list.visible and m.list.itemFocused > 0
            m.list.jumpToItem = 0
            return true
        end if
        ' Nothing is cancelled on the way out: a fetch already in the air is
        ' already spent, and the file it writes is cached, so the member gets
        ' it for free the next time they look. The screen simply goes.
        m.top.closed = true
        return true
    end if
    return false
end function
