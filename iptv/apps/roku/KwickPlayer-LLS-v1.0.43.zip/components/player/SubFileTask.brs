' One subtitle file, onto the disk, off the render thread. See SubFileTask.xml
' for why this is its own task and not AddOnTask.

sub init()
    m.top.functionName = "runFetch"
end sub

sub runFetch()
    path = ToStr(m.top.savePath)
    if path = ""
        m.top.result = { ok: false, error: "There was nowhere to put that subtitle." }
        return
    end if

    ' ALREADY IN HAND. Checked before anything else, because this is the
    ' whole point of the cache: a member coming back to a film they have
    ' already fetched a subtitle for must not spend another download out of
    ' their daily allowance. GetFileList on the folder rather than a read,
    ' so a 100 KB file is not pulled into memory just to prove it exists.
    if subFileExists(path)
        m.top.result = { ok: true, path: path, bytes: 0, cached: true }
        return
    end if

    url = ToStr(m.top.url)
    if url = ""
        m.top.result = { ok: false, error: "That subtitle has no address to fetch from." }
        return
    end if

    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    xfer.retainBodyOnError(true)
    ' NO compression. The answer goes straight to a file and the encoding
    ' guess below counts raw bytes; a gzipped body would make both wrong.
    ' Identifies us the way every other request in this app does.
    xfer.addHeader("User-Agent", KwickUserAgent())
    xfer.setUrl(url)

    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)
    if not xfer.asyncGetToFile(path)
        m.top.result = { ok: false, error: "That subtitle could not be fetched." }
        return
    end if

    msg = wait(m.top.timeoutMs, port)
    if type(msg) <> "roUrlEvent"
        xfer.asyncCancel()
        subFileRemove(path)
        m.top.result = { ok: false, error: "That subtitle took too long to arrive. Try again in a moment." }
        return
    end if

    code = msg.getResponseCode()
    if code < 200 or code >= 300
        subFileRemove(path)
        ' Deliberately plain. The relay's own faults are worded for a member
        ' by AddOnErrorText; this is the raw file fetch, where the only
        ' honest thing to say is that it did not arrive.
        m.top.result = { ok: false, error: "That subtitle could not be downloaded right now.", errCode: code }
        return
    end if

    bytes = subFileSize(path)
    if bytes <= 0
        subFileRemove(path)
        m.top.result = { ok: false, error: "That subtitle arrived empty." }
        return
    end if
    if bytes > m.top.maxBytes
        ' Refused rather than kept. An oversized file here is a mislabelled
        ' something-else, and this app has already killed members' boxes
        ' once by pulling an unmeasured answer into memory.
        subFileRemove(path)
        m.top.result = { ok: false, error: "That subtitle file is far bigger than a subtitle should be, so it was not kept." }
        return
    end if

    subMakeUtf8(path, bytes)
    subSweepOld(path)
    m.top.result = { ok: true, path: path, bytes: bytes, cached: false }
end sub

' ---- Keeping the cache bounded ----------------------------------------------
'
' cachefs is small and SHARED — the guide slices and the bounded API bodies
' live there too — so a subtitle cache that only ever grew would eventually
' be the reason a guide download had nowhere to land. Twenty files at the
' tens-of-kilobytes a subtitle runs to is well under two megabytes, and
' twenty titles is far more than a member returns to.
'
' ONLY OUR OWN FILES, by prefix, exactly the way ApiTask and XmltvTask sweep
' theirs — and never the one just written. Oldest go first, and a firmware
' that does not report a modification time has nothing deleted at all: Stat's
' "mtime" is a DATE OBJECT, and running it through ToInt() gives 0, which
' would read as older than everything.
sub subSweepOld(keep as string)
    try
        fs = CreateObject("roFileSystem")
        if fs = invalid then return
        lst = fs.GetDirectoryListing("cachefs:/")
        if lst = invalid then return
        mine = []
        for each nm in lst
            n = ToStr(nm)
            if n.len() > 9 and n.left(9) = "kwicksub_"
                full = "cachefs:/" + n
                if full <> keep
                    st = fs.Stat(full)
                    mts = 0
                    if st <> invalid
                        mt = st["mtime"]
                        if type(mt) = "roDateTime" then mts = mt.asSeconds() else mts = ToInt(mt)
                    end if
                    if mts > 0 then mine.push({ p: full, t: mts })
                end if
            end if
        end for
        ' The one just written counts toward the cap even though it is never
        ' a candidate for deletion, so the cap is a real ceiling.
        if mine.count() < 20 then return
        mine.sortBy("t")
        over = mine.count() - 19
        for i = 0 to over - 1
            fs.Delete(mine[i].p)
        end for
        KLog("subs", "subtitle cache trimmed by " + over.toStr() + " file(s)")
    catch e
        KLog("subs", "subtitle cache sweep skipped: " + ToStr(GetField(e, "message")))
    end try
end sub

' ---- Text encoding ----------------------------------------------------------
'
' ROKU DRAWS UTF-8 AND NOTHING ELSE. A great many subtitle files on both
' services are still Windows-1252 or Latin-1, and on those every accented
' letter draws as a box or vanishes — Spanish, French, German and Portuguese
' subtitles are the ones that suffer, which is most of what a member who is
' searching for subtitles at all is likely to want. Android hit exactly this
' and fixed it the same way (JB-8 lists it as the "UTF-8 re-encode" commit).
'
' The test is the cheap half: valid UTF-8 has a shape, and a file that breaks
' that shape is not UTF-8. A file that already IS UTF-8 (most of them now) is
' left completely untouched and costs one pass of a scan that stops at the
' first proof either way.
'
' EVERYTHING IS INSIDE try/catch, and that is what makes this safe to ship
' unverified: if any of it faults, the file stays exactly as it was
' downloaded and the member gets whatever Roku makes of it — which is
' precisely what they would have got if this function did not exist. It can
' improve the result and it cannot make it worse.
sub subMakeUtf8(path as string, bytes as integer)
    ' A ceiling on the byte walk below. BrightScript is slow at this and a
    ' subtitle is tens of kilobytes; anything past a quarter of a megabyte is
    ' not worth making a member wait for, and is left alone.
    if bytes > 262144 then return
    try
        ba = CreateObject("roByteArray")
        if not ba.readFile(path) then return
        if subLooksUtf8(ba) then return
        out = CreateObject("roByteArray")
        n = ba.count() - 1
        for i = 0 to n
            b = ba[i]
            if b < 128
                out.push(b)
            else
                ' Widen one Latin-1 byte into its two-byte UTF-8 form. This
                ' is the whole of the conversion: code points 0x80-0xFF map
                ' to 0xC2/0xC3 followed by the low six bits.
                out.push(192 + Int(b / 64))
                out.push(128 + (b mod 64))
            end if
        end for
        out.writeFile(path)
    catch e
        KLog("subs", "left a subtitle file in its original encoding: " + ToStr(GetField(e, "message")))
    end try
end sub

' Does this look like UTF-8 already? Any byte over 127 must be the start of a
' well-formed sequence with the right number of continuation bytes after it.
' The first counter-example proves it is not, and a file with no high bytes at
' all is plain ASCII, which is valid UTF-8 and needs nothing done to it.
function subLooksUtf8(ba as object) as boolean
    n = ba.count()
    i = 0
    while i < n
        b = ba[i]
        if b < 128
            i = i + 1
        else if b >= 194 and b <= 223
            if not subIsCont(ba, i + 1, n) then return false
            i = i + 2
        else if b >= 224 and b <= 239
            if not subIsCont(ba, i + 1, n) then return false
            if not subIsCont(ba, i + 2, n) then return false
            i = i + 3
        else if b >= 240 and b <= 244
            if not subIsCont(ba, i + 1, n) then return false
            if not subIsCont(ba, i + 2, n) then return false
            if not subIsCont(ba, i + 3, n) then return false
            i = i + 4
        else
            ' 0x80-0xC1 and 0xF5-0xFF never start a sequence.
            return false
        end if
    end while
    return true
end function

function subIsCont(ba as object, at as integer, n as integer) as boolean
    if at >= n then return false
    b = ba[at]
    return b >= 128 and b <= 191
end function

' ---- Disk ------------------------------------------------------------------
'
' roFileSystem rather than ReadAsciiFile: asking whether a file is there must
' never mean pulling its contents into memory.

function subFileExists(path as string) as boolean
    fs = CreateObject("roFileSystem")
    if fs = invalid then return false
    return fs.exists(path)
end function

function subFileSize(path as string) as integer
    fs = CreateObject("roFileSystem")
    if fs = invalid then return 0
    info = fs.stat(path)
    if info = invalid then return 0
    return ToInt(GetField(info, "size"))
end function

sub subFileRemove(path as string)
    ' A half-written or refused file must not be left behind: the "already in
    ' hand" check above would answer it forever, and the member would get a
    ' broken subtitle every time with no way to ask again.
    fs = CreateObject("roFileSystem")
    if fs = invalid then return
    if fs.exists(path) then fs.delete(path)
end sub
