' Player -> Multi-View hand-off. See PlayerMultiView.xml for why this is a
' component and not three subs inside PlayerScreen.
'
' The picker/grid chain below is deliberately the SAME chain as
' ChannelDetailScreen.openMultiView and LiveTvScreen.openMultiView — create on
' the scene, observe `closed`, read `result`, remove, open the next thing. If
' that chain ever changes, all three change together.

sub init()
    m.scene = invalid
    m.picker = invalid
    m.grid = invalid
    m.restoreTo = invalid
    m.started = false
    m.done = false
    m.focusTimer = m.top.findNode("focusTimer")
    m.focusTimer.observeField("fire", "onFocusCheck")
end sub

sub onStart()
    if m.top.start <> true then return
    if m.started then return
    m.started = true
    scene = m.top.getScene()
    if scene = invalid
        KLog("player", "multiview handoff: no scene — giving up")
        return
    end if
    m.scene = scene
    ' Whatever holds focus at this moment is the screen the player was opened
    ' from (its parent has already taken focus back, because the player set
    ' `closed` before setting our `start`). That is where Back should land
    ' once Multi-View is done — never a player, which would start a stream
    ' playing again, exactly the rule Android writes down in
    ' multi_view_entry.dart.
    m.restoreTo = deepestFocused(scene)
    m.picker = scene.createChild("MultiViewPicker")
    if m.top.seedJson <> "" then m.picker.seedJson = m.top.seedJson
    m.picker.observeField("closed", "onPickerClosed")
    m.picker.setFocus(true)
    m.picker.start = true
    m.focusTimer.control = "start"
    KLog("player", "multiview handoff: picker open")
end sub

' The deepest node in the scene's focus chain. `focusedChild` answers with the
' node itself once it is the one actually holding focus, which is the stop.
function deepestFocused(root as object) as dynamic
    n = root
    for i = 0 to 24
        c = n.focusedChild
        if c = invalid then return n
        if c.isSameNode(n) then return n
        n = c
    end for
    return n
end function

' isInFocusChain, NOT hasFocus. The picker hands real focus down to its own
' keySink child the moment it starts, so hasFocus() on the picker itself is
' false even when everything is fine — and "fixing" that would take focus away
' from the keySink and leave the picker unable to read the remote at all.
sub onFocusCheck()
    if m.picker <> invalid and not m.picker.isInFocusChain()
        KLog("player", "multiview handoff: re-taking focus for the picker")
        m.picker.setFocus(true)
    end if
end sub

sub onPickerClosed()
    res = ""
    if m.picker <> invalid
        res = m.picker.result
        m.scene.removeChild(m.picker)
        m.picker = invalid
    end if
    if res = ""
        ' Backed out of the picker. The player is already gone, so this lands
        ' on the screen it was opened from — which is what backing out of
        ' Multi-View is supposed to do.
        finish()
        return
    end if
    m.grid = m.scene.createChild("MultiViewScreen")
    m.grid.slotsJson = res
    m.grid.observeField("closed", "onGridClosed")
    m.grid.setFocus(true)
    m.grid.start = true
end sub

sub onGridClosed()
    if m.grid <> invalid
        m.scene.removeChild(m.grid)
        m.grid = invalid
    end if
    finish()
end sub

sub finish()
    if m.done then return
    m.done = true
    m.focusTimer.control = "stop"
    scene = m.scene
    ' Focus back where it was. A node that has since been torn down answers
    ' invalid for getScene(), and the player itself must never be refocused
    ' even in the impossible case that it is still there.
    landed = false
    if m.restoreTo <> invalid and scene <> invalid and not m.restoreTo.isSameNode(scene)
        if m.restoreTo.getScene() <> invalid and m.restoreTo.subtype() <> "PlayerScreen"
            m.restoreTo.setFocus(true)
            landed = true
        end if
    end if
    if not landed and scene <> invalid
        ' Last resort: the app shell, which routes focus to its sidebar. The
        ' shell is created without an id, so it is found by type.
        for i = 0 to scene.getChildCount() - 1
            ch = scene.getChild(i)
            if ch <> invalid and ch.subtype() = "AppShell"
                ch.setFocus(true)
                landed = true
                exit for
            end if
        end for
    end if
    if not landed then KLog("player", "multiview handoff: nothing left to focus")
    m.restoreTo = invalid
    m.scene = invalid
    ' Nothing references this node but the scene, so this is the end of it.
    ' Must be the LAST thing done here — m is released with it.
    if scene <> invalid then scene.removeChild(m.top)
end sub
