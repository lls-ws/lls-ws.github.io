' One subtitle in the search results. See SubResultRow.xml for the shape and
' for why this is not SettingRow.

sub init()
    m.theme = KwickTheme()
    m.rowBg = m.top.findNode("rowBg")
    m.ring = m.top.findNode("ring")
    m.ring.color = m.theme.focusHighlight
    m.inner = m.top.findNode("inner")
    m.inner.color = m.theme.surface
    m.line1 = m.top.findNode("line1")
    m.line2 = m.top.findNode("line2")
    m.mark = m.top.findNode("mark")
    ' JetBrains Mono's advance is a flat 0.6em, so these are sized against
    ' the boxes in the XML rather than against Roboto's averages:
    '   line1 at 26 is 15.6px a character, so 1100px holds 70 — enough for a
    '   language name, two spaces and a long release name before it cuts.
    '   line2 at 21 is 12.6px, 87 characters, and the longest badge line the
    '   app can build ("hearing impaired, trusted, machine translated,
    '   999999 downloads") is 63.
    '   mark at 22 is 13.2px and "On this device" is 14 characters = 185px in
    '   a 266px box.
    m.line1.font = UiFont(26)
    m.line2.font = UiFont(21)
    m.mark.font = UiFont(22)
    m.laidOut = 0
end sub

' Size to the list's ACTUAL itemSize rather than the XML's, the way
' SettingRow does — a fixed width clipped the focus ring's right edge when
' the same row was reused at another width.
sub layout()
    w = m.top.width
    if w = invalid or w < 100 then w = 1440
    w = Int(w)
    if m.laidOut = w then return
    m.laidOut = w
    m.rowBg.width = w
    m.ring.width = w
    m.inner.width = w - 6
    m.line1.width = w - 340
    m.line2.width = w - 340
    m.mark.width = 266
    m.mark.translation = [w - 290, 0]
end sub

' EVERY visual, BOTH ways, on EVERY bind. The empty branches are not
' defensive padding — they are the whole reason this sub is written this way.
sub onContent()
    c = m.top.itemContent
    layout()
    if c = invalid
        m.line1.text = ""
        m.line2.text = ""
        m.mark.text = ""
        redraw()
        return
    end if
    m.line1.text = c.title
    ' A subtitle with no badges at all is common and perfectly fine. The
    ' label is emptied rather than left holding the last row's badges.
    m.line2.text = c.description
    ' "On this device", or nothing. Never the previous row's answer.
    m.mark.text = c.shortDescriptionLine2
    redraw()
end sub

sub onFocus()
    layout()
    redraw()
end sub

sub redraw()
    m.rowBg.visible = true
    m.rowBg.color = m.theme.surface
    focused = m.top.itemHasFocus
    m.ring.visible = focused
    m.inner.visible = focused
    m.line1.color = m.theme.textPrimary
    m.line2.color = m.theme.textSecondary
    ' The mark is the app's "you already have this" colour, the same one
    ' SettingRow gives ON / Active / Added — but set both ways, because an
    ' empty mark on a recycled row must not keep the bright colour and then
    ' be handed a value again on the next bind.
    if m.mark.text <> ""
        m.mark.color = m.theme.accentAlt
    else
        m.mark.color = m.theme.textSecondary
    end if
end sub
