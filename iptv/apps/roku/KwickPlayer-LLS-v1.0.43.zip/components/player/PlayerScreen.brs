' Fullscreen player. The controls are a port of the ANDROID player's controls
' (exo_vod_player_screen.dart:1404+, exo_live_player_screen.dart:1558+,
' PlayerIconButton in lib/ui/widgets/player_icon_button.dart), rebuilt to
' Android's LAYOUT rather than recoloured — see the block above buildButtons
' for the measurements and the three places Roku cannot follow.
'
' The shape of it, which is Android's shape:
'
'   ONE rounded dark card at the bottom holds everything. On VOD it is pinned
'   left and right (Android's Positioned left:24 right:24 bottom:28) and holds
'   two rows; on live it shrink-wraps its buttons and centres (Android's live
'   bar is an Align+Padding around a Wrap, so it is only as wide as the row).
'
'     row 1 (VOD only)  "6:30 / 15:24"   [======o--------]   "Ends at 8:42 PM"
'     row 2             flat icon glyphs, centred, abutting
'
'   A button is a bare glyph until it is focused and then a ring in the theme
'   highlight with the glyph tinted to match — never a filled disc. Play/pause
'   is drawn LARGER than its neighbours, which is Android's one piece of
'   hierarchy inside the row (size 30 against 22).
'
' Keys: controls hidden -> any press reveals them; visible -> Left/Right
' pick a button, OK fires it, Back exits, then the member's own auto-hide of
' 5/10/15 seconds (JB-10, see controlsHideSeconds; never while paused).

sub init()
    m.theme = KwickTheme()
    m.video = m.top.findNode("video")
    m.controls = m.top.findNode("controls")

    m.status = m.top.findNode("statusLabel")
    ' 26 -> 22 for the SHELL TYPE. JetBrains Mono's advance is a flat 0.6em
    ' against Roboto-Medium's ~0.5em average (Theme.brs:317-330), and the
    ' longest thing this label ever says is the 232-character codec message
    ' in StreamErrorText (Util.brs:325). In a 1740px box over two lines that
    ' needs 111 characters per line at 26 and only fits 111 — i.e. it would
    ' have started truncating. At 22 the box takes ~131 per line and the
    ' message clears with room. maxLines stays 2 deliberately: a third line
    ' would run down to y~881 and the progress track is at 886.
    m.status.font = UiFont(22)
    m.status.color = m.theme.textPrimary

    m.chTitle = m.top.findNode("chTitle")
    ' 40 -> 34, and the drop is NOT cosmetic. This Label has no width, so it
    ' does not truncate — it runs off the right edge of the screen. 34 in
    ' mono is the same on-screen line length 40 in Roboto-Medium was, so a
    ' long film title reaches exactly as far as it always did.
    m.chTitle.font = UiBoldFont(34)
    m.chTitle.color = m.theme.textPrimary

    m.top.findNode("livePill").visible = false

    ' What's on now, under the LIVE pill (GAP A1). White at 70% rather than
    ' the theme's grey secondary: this sits over moving picture behind a
    ' scrim, and Android's line is white70 for the same reason.
    m.nowLabel = m.top.findNode("nowLabel")
    ' 28 -> 24 for the mono width tax. The box is 1200 wide at maxLines=1:
    ' Roboto-Medium 28 got ~85 characters into it, mono 28 gets 71, mono 24
    ' gets 83. So a long programme title clips at the same place it used to.
    m.nowLabel.font = UiFont(24)
    ' NOT swept to a palette key on purpose. This one line is drawn over
    ' MOVING PICTURE behind a scrim, where a slate grey disappears against a
    ' bright frame; Android's live overlay uses white70 here for the same
    ' reason (live_player_screen.dart:1443). Left as white at 70%.
    m.nowLabel.color = "0xFFFFFFB3"
    m.nowLabel.visible = false
    ' Now-playing state — see the block near the bottom of this file.
    m.epgTimer = m.top.findNode("epgTimer")
    m.epgTimer.observeField("fire", "onEpgTick")
    m.epgListings = []
    m.epgKey = ""
    m.epgSrcType = ""
    m.epgTvgId = invalid
    m.epgFetchedAt = 0
    m.epgHadData = false
    m.epgTask = invalid
    ' The start time of the programme currently drawn. -1 = nothing drawn yet;
    ' 0 = "looked, and nothing is on" (a real answer, so it can't be -1).
    m.epgNowKey = -1

    ' ---- The seek row (VOD only) ------------------------------------------
    ' THERE IS NO CARD ANY MORE. The bar floats on the picture, above the
    ' button line and not sharing anything with it — Android's shape, and the
    ' owner's call on 2026-08-27 after seeing the two side by side.
    '
    '   "Ends at 8:42 PM"                                    1376..1656
    '   elapsed 96..232 | track 264..1656 | total 1688..1824
    '
    ' WHY THE TRACK IS 1392 AND NOT ANDROID'S ~1700. Android's bar runs
    ' 5.7%..94.3% of its screen with the readings sitting out at 2.7%. Two
    ' things stop Roku copying those percentages, and both are real:
    '
    '  1. TITLE-SAFE. Android has no equivalent constraint; Roku's usable box
    '     is 96..1824. Android's 2.7% would put a reading at x=52, off the
    '     safe area and into the part of the picture a television can crop.
    '  2. ANDROID'S TRACK IS `Expanded`, so it takes whatever the two
    '     readings leave and SHRINKS as they grow. The screenshot this was
    '     measured off had a short elapsed reading, so its bar looks wider
    '     than it would on the same film an hour in. A Roku track that
    '     changed length mid-film every time the reading gained a digit
    '     (59:59 -> 1:00:00) would be worse than a fixed one, so the fixed
    '     one is sized for the worst case instead.
    '
    ' What IS copied is the thing that actually reads as Android: the labels
    ' HUG THE BAR. The elapsed reading is right-aligned in its box and the
    ' total is left-aligned in its, so both sit hard against the track ends
    ' at any length and grow outward toward the safe edges. 16px of daylight
    ' either side, which is Android's own gap.
    '
    ' The numbers, worst-case measured rather than guessed:
    '   · longest reading either side is "10:15:30" — clockDuration emits
    '     h:mm:ss and a ten-hour file (an audiobook, say) makes it 8
    '     characters. 8 x 28 x 0.600 = 134.4px of JetBrains Mono, so the
    '     boxes are 136 and the elapsed one exactly fills 96..232.
    '   · the grabbed knob is 32 wide and centres on the fill, so it hangs
    '     16px past each end of the track: back to 248 at the left (16 clear
    '     of the reading at 232) and out to 1672 at the right (16 clear of
    '     the reading at 1688). That is why the gap is 32 and not 16.
    '   · "Ends at 12:42 PM" is 16 x 22 x 0.600 = 212px in a 280px box.
    ' Track height 8 is Android's trackHeight 4, doubled like the rest of the
    ' layout. These four numbers are measured once HERE rather than repeated
    ' as literals in drawSeek — which is how the old bar's knob and fill
    ' drifted apart the last time it moved. They must agree with the
    ' translations in the XML.
    m.trackX = 264
    m.trackY = 884
    m.trackW = 1392
    m.trackH = 8
    m.progressWrap = m.top.findNode("progressWrap")
    m.progTrack = m.top.findNode("progTrack")
    m.progBuffer = m.top.findNode("progBuffer")
    m.progFill = m.top.findNode("progFill")
    m.progKnob = m.top.findNode("progKnob")
    ' The unwatched part of the track. Was the hand-mixed 0x3B3F45; the Nord
    ' surface it is now (0x3B4252) is the same lightness, so it stays held
    ' back the way the old value was chosen to be — with the bar running the
    ' whole width, anything brighter reads as a light band across the screen.
    m.progTrack.color = m.theme.surface
    ' Buffered-ahead, between the track and the fill. Only ever drawn when
    ' the stream reports a real number — see drawBuffer. Needs to sit BETWEEN
    ' the track and the fill in lightness; textSecondary is the palette's
    ' one slate that does, and its hue is plainly not the frost of the fill.
    m.progBuffer.color = m.theme.textSecondary
    m.progFill.color = m.theme.accent
    m.progKnob.blendColor = m.theme.textPrimary
    ' Elapsed (far left of the bar) and total (far right). TWO SEPARATE
    ' READINGS, which is Android's Row of [elapsed][slider][duration] and is
    ' what the owner picked on 2026-08-27 having seen it against the combined
    ' "6:30 / 15:24" form he asked for earlier. That combined form is gone.
    ' 28 in JetBrains Mono is 16.8px per character and the longest either box
    ' holds is "10:15:30" = 135px, well inside 200. Bold carries the same
    ' 0.600em advance as the regular cut, so the weight is free.
    m.timeLabel = m.top.findNode("timeLabel")
    m.timeLabel.font = UiBoldFont(28)
    m.timeLabel.color = m.theme.textPrimary
    m.durLabel = m.top.findNode("durLabel")
    m.durLabel.font = UiBoldFont(28)
    ' The total is the quieter half of the pair — it never changes while a
    ' film plays, where the elapsed reading is the live one.
    m.durLabel.color = m.theme.textSecondary
    m.durLabel.visible = false
    ' "Ends at 8:42 PM" — SECONDARY and SMALL, deliberately, sitting above the
    ' right end of the bar. It is the one reading here that is a convenience
    ' rather than a fact about the film. 22 x 0.600 = 13.2px per character;
    ' the longest string is "Ends at 12:42 PM" at 16 characters = 212px in a
    ' 280px box. 24-hour is shorter.
    m.endLabel = m.top.findNode("endLabel")
    m.endLabel.font = UiFont(22)
    m.endLabel.color = m.theme.textSecondary
    m.endLabel.visible = false
    m.endTimer = m.top.findNode("endTimer")
    m.endTimer.observeField("fire", "refreshEndTime")
    m.speedLabel = m.top.findNode("speedLabel")
    ' Held at 30 too — ">>  32x" is seven characters, 126px in a 300px box.
    m.speedLabel.font = UiBoldFont(30)
    m.speedLabel.color = m.theme.focusHighlight
    m.video.observeField("position", "onPosition")
    m.subTracks = []
    ' Caption selection: 0 = off, 1 = embedded CC (the closed captions that
    ' ride inside the video signal, decoded by the Roku OS), 2+ = text track.
    m.ccSel = 0
    m.ccAutoApplied = false
    m.subPicker = invalid
    m.sleepSel = 0
    m.sleepTimer = invalid
    m.sleepPicker = invalid
    m.mutedApplied = false

    ' Seek state:
    '   focusArea "buttons" | "seekbar"
    '   scrubbing  — manual D-pad scrub on the bar (constant pace while held)
    '   tricking   — << / >> continuous fast-forward/rewind mode with tiers
    m.focusArea = "buttons"
    m.scrubbing = false
    m.scrubPos = 0
    m.tricking = false
    m.trickDir = 1
    m.trickTier = 1
    m.seekCommitTimer = m.top.findNode("seekCommitTimer")
    m.seekCommitTimer.observeField("fire", "commitScrub")
    m.trickTimer = m.top.findNode("trickTimer")
    m.trickTimer.observeField("fire", "onTrickTick")
    m.scrubHoldDir = 0
    m.scrubHoldTimer = m.top.findNode("scrubHoldTimer")
    m.scrubHoldTimer.observeField("fire", "onScrubHoldTick")

    ' Buttons are built at start-time (not init) so the row can adapt: the
    ' favorite star needs to know whether there is anything to favorite, and
    ' on VOD that answer comes out of parentId.
    m.buttons = []
    m.favTarget = invalid
    m.favOn = false
    m.audioTracks = []
    m.audioPicker = invalid

    ' Last position/duration the player reported — see onPosition and
    ' markFinished. 0 means "never reported one", which counts as not
    ' finished.
    m.lastPosS = 0
    m.lastDurS = 0
    ' Seconds left when "Ends at" was last worked out. -1 = never, which is
    ' what makes the first position report recompute it.
    m.endRemain = -1

    ' ---- Next / previous episode (GAP A5) — see that section for the whole
    ' argument. Everything here is off until an episode actually opens.
    m.epNav = false            ' this player is showing a series episode
    m.epOrder = invalid        ' the flat episode list, once it has been asked for
    m.epIdx = -1               ' where in it we are
    m.epSeriesId = ""
    m.epSrc = ""
    m.epBaseTitle = ""         ' the show's name, without the episode code
    m.epTask = invalid
    m.epNavUsed = false        ' a change has happened, so this player owns the end
    m.upNext = invalid

    ' ---- Channel zapping (GAP A2) — see that section for the whole
    ' argument. Off until a live channel opens AND a lineup has been
    ' published for it to walk.
    m.chNav = false            ' this player has a lineup it can step through
    ' The last "not in the lineup" line this player printed, so it is said
    ' once per channel rather than once per remote press. See bindChannelNav.
    m.chNavQuiet = ""
    m.chOrder = invalid        ' that lineup, in the order it is displayed
    m.chIdx = -1               ' where in it we are

    ' ---- The ONE step dwell, shared by episode stepping and channel
    ' zapping. They are mutually exclusive (m.epNav is VOD-only, m.chNav is
    ' live-only), so one timer and one collected count serves both — a second
    ' dwell machine is a second way to get the reconnect budget wrong.
    m.stepPending = 0          ' presses collected but not yet spent
    m.stepSwitching = false    ' a change is in flight — no second one on top of it
    m.stepWaits = 0            ' how many dwells that change has been given
    m.stepDwellTimer = m.top.findNode("stepDwellTimer")
    m.stepDwellTimer.observeField("fire", "commitStep")

    ' ---- Reconnect ladder and watchdogs (GAP A4) --------------------------
    m.retries = 0
    ' "malformed data" gets ONE retry (transient bad response) before it is
    ' treated as an undecodable stream — this counts those. Reset when a
    ' stream actually plays.
    m.malformedTries = 0
    m.retryTimer = m.top.findNode("retryTimer")
    m.retryTimer.observeField("fire", "startPlayback")
    ' Live health. lastPos/stalledFor catch a stream that reports "playing"
    ' while nothing moves; healthyFor is what forgives the ladder.
    m.openTimer = m.top.findNode("openTimer")
    m.openTimer.observeField("fire", "onOpenTimeout")
    m.healthTimer = m.top.findNode("healthTimer")
    m.healthTimer.observeField("fire", "onHealthTick")
    m.livePos = -1
    m.stalledFor = 0
    m.healthyFor = 0
    m.sawPlaying = false
    m.posEverMoved = false
    ' Has this player already asked the panel WHY a live stream gave up? One
    ' question per player, and this flag is the only thing enforcing it.
    ' DELIBERATELY NOT CLEARED when the task is released — that is the entire
    ' reason it exists separately from m.diagTask. The guard used to be the node
    ' reference itself, so letting the reference go (which is what stops an
    ' orphan task node holding this whole screen alive — see releaseDiagTask)
    ' would have re-armed the question and a second give-up would have spent a
    ' second request. True here means "asked, for the life of this player",
    ' whatever state the node is in. See diagnoseLiveFailure.
    m.diagAsked = false
    m.diagTask = invalid
    m.hideTimer = m.top.findNode("hideTimer")
    ' JB-10. The member's own choice of how long the control bar stays up.
    ' Read ONCE, here, because Settings cannot be reached while a stream is
    ' playing — there is no way for this to change under us — and because
    ' showControls() runs on every remote press, which certification 3.5
    ' gives 250ms to answer. A registry read on that path would be a disk
    ' read per keypress for a value that cannot have moved.
    m.hideTimer.duration = controlsHideSeconds()
    m.hideTimer.observeField("fire", "hideControls")
    ' Save VOD progress every 10s so a power-off still remembers the spot.
    m.saveTimer = m.top.findNode("saveTimer")
    m.saveTimer.observeField("fire", "saveProgress")

    ' ---- Subtitle search (JB-7) -------------------------------------------
    ' A subtitle fetched from OpenSubtitles or Subdl, once one is in play:
    ' the file on disk, the language it is in, and what to call it in the
    ' track list. Empty is the ordinary state and every branch below is
    ' written for it.
    m.extSubPath = ""
    m.extSubLang = ""
    m.extSubLabel = ""
    ' Where the file came from — the https address, offered to the Video node
    ' ahead of the local copy. Subdl rows only, and never remembered across
    ' launches. See extSubAddress.
    m.extSubUrl = ""
    ' THE FETCHED SUBTITLE IS STILL MODELLED AS ITS OWN THING, not as a Roku
    ' track, and that is now provisional rather than measured: it is declared
    ' on the content node as a real caption track (see the block above
    ' attachExternalSub), so it MAY start appearing in the track list, at
    ' which point this flag and its own menu row can be reconsidered. Left
    ' exactly as it was until the stick says so.
    ' m.extSubOn is the only answer to "is the downloaded file the one on the
    ' picture". m.ccSel still means exactly what it always meant and now
    ' covers the stream's OWN tracks only: the two are mutually exclusive, so
    ' m.extSubOn = true always goes with m.ccSel = 0.
    m.extSubOn = false
    ' Did the stream that is playing RIGHT NOW open with the file hung on its
    ' content node? That is the only state in which the decoder is known to
    ' have the file, and therefore the only state in which turning the
    ' subtitle back on is free. False means a reopen — one connection, and
    ' only because the member asked for one.
    m.extSubLoaded = false
    ' True once logSubTracks has had its say for this reopen. See there.
    m.extSubLogged = true
    ' One of the STREAM'S OWN tracks the member asked for while a fetched
    ' subtitle was on, held by name across the reopen that takes the fetched
    ' one off. Empty is the ordinary state. See restartForOwnTrack.
    m.wantOwnTrack = ""
    m.subsSearch = invalid
    ' Whether the Subtitles list currently on screen carries the two search
    ' rows. Live never does, so the index shift in onSubPickerClosed is
    ' gated on this rather than on isLive — one flag, set where the list is
    ' actually built.
    m.subPickerHasSearch = false
    ' Which title the remembered subtitle below was read for. NOT loaded
    ' here: init runs when the node is created, before the opener has set
    ' resumeKey, so there would be nothing to look it up by. startPlayback
    ' is the funnel that runs once every field is filled in, and it runs
    ' again for the next episode — which is a different title and a
    ' different remembered choice.
    m.extSubKey = invalid
    ' Is the line on the status label a one-off note rather than something
    ' the member has to act on? See hideControls.
    m.statusTransient = false

    ' ---- Scrobbling to Trakt and Simkl ------------------------------------
    ' Four flags and a clock, all of them off until a title with a TMDB id
    ' actually starts playing. The whole argument is at the bottom of this
    ' file; the short version is that these exist so the reconnect ladder, a
    ' rebuffer, a Refresh press and a subtitle reopen cannot each turn into
    ' another request at somebody else's service.
    m.scrobKey = ""        ' which title the other four belong to
    m.scrobWatching = false ' the services currently believe this is playing
    m.scrobEver = false     ' a start has gone out for this title
    m.scrobStopped = false  ' the stop has gone out for this title
    m.scrobLastAt = 0       ' when the last one went, for the play/pause floor
    ' Said once per player if ScrobbleOn() is not in the tree yet.
    m.scrobPrefWarned = false

    m.top.observeField("start", "startPlayback")
    m.video.observeField("state", "onVideoState")
end sub

' ---- Control bar ------------------------------------------------------------

' The row, in Android's order. Every glyph below was checked against the cmap
' of fonts/MaterialIcons-Regular.ttf before being used — this repo has already
' shipped a missing-glyph box once (PosterCard.brs:16-19).
'
'   LIVE : [prev channel] · play/pause · [next channel] · [favorite] ·
'          sleep · audio · captions · mute · refresh · multi-view
'   VOD  : skip back · play/pause · skip forward · audio · captions · sleep ·
'          mute · refresh · [favorite] · multi-view
'   VOD (a series EPISODE) adds prev-episode at the head of the row and
'          next-episode after skip forward, which is exactly where Android
'          puts them (vod_player_screen.dart:993 — `if (showEpisodeNav) 0`
'          then 1,2,3 then `if (showEpisodeNav) 4`).
'
' THE LIVE ROW IS ANDROID'S ORDER, ITEM FOR ITEM. Android's live Wrap
' (exo_live_player_screen.dart:1579-1676) reads:
'
'   skip_previous · play/pause · skip_next · star · record · bedtime ·
'   graphic_eq · closed_caption · volume · refresh · aspect · fullscreen ·
'   lock · grid_view
'
' The order used to be different here (play/pause · audio · cc · sleep ·
' mute · refresh · favorite · multi-view), which is why the owner said the
' live controls "look nothing like" the phone's — the row was a different
' SHAPE, not a different colour. It is Android's order now. Four of
' Android's fourteen are not drawn, each for a stated reason:
'
'   · record   — Roku cannot save video to disk (K1). Nothing to put behind
'                the button, so there is no button.
'   · aspect   — LOOKED AT PROPERLY 2026-08-27 after the owner pointed out it
'                is in all three of his screenshots. The answer is NO, and it
'                is a platform limit, not a shortcut.
'
'                Android's button cycles Fit -> Fill -> Stretch (_cycleAspect).
'                Roku's Video node has no aspect, zoom or scaling-mode field
'                of any kind: the decoder letterboxes the source into the
'                node's rect and always preserves the source's own ratio.
'                Multi-View proves the rect is honoured (its Video is 960x540
'                and works on the stick), so "Fit" is what this player already
'                does — but there is no field, and no rect, that makes the
'                picture IGNORE its ratio. STRETCH IS NOT POSSIBLE AT ALL.
'
'                Fill/zoom could in principle be faked by making the Video
'                node larger than the screen and translating it negatively so
'                the picture is cropped. That is unmeasured on this hardware,
'                it resizes the one decoder Roku gives us mid-stream, and a
'                two-of-three cycle that silently drops the third mode is
'                worse than no button. So: no button, rather than half a
'                feature. If it is ever wanted, it needs measuring on a real
'                box first, not building first.
'   · fullscreen — Roku playback is always fullscreen. Meaningless.
'   · lock     — Android's is a TOUCH lock and it is built only on a touch
'                device (`onLock: _isTouchDevice ? _lockTouches : null`,
'                :1242). A remote cannot brush the screen, so there is
'                nothing to lock out.
'
' And ONE deliberate difference kept: the favourite mark is a HEART, not
' Android's star. A favourite is a heart everywhere else in this app,
' including the poster the channel was opened from, and the app's own
' language wins over the reference on that one.
'
' Sleep and mute stay where Android puts them: they are Roku-ahead features
' the changelog brags about, and the owner asked for buttons to be ADDED.
'
' THE CHANNEL BUTTONS (GAP A2). Android's live skip_previous/skip_next are
' PREVIOUS and NEXT CHANNEL, not seek — `_step(-1)` / `_step(1)` walking
' `_channels`. This player used to have neither, because it is handed one
' url and one channel and never the list it came from. It now walks
' `m.global.liveLineup`, the display-ordered lineup published by the screen
' the member was just looking at. NO lineup, a lineup of one, or a lineup
' that does not contain the channel playing => the two buttons are simply
' NOT BUILT. Never a button that is drawn and does nothing.
'
' WHAT THE PLAYER STILL WILL NOT DO, and it is the same refusal as before:
' it will not download a lineup of its own. A get_live_streams at the moment
' a stream has just started is the exact request pattern the now-playing
' block below refuses to make, for the exact reason given there.
sub buildButtons()
    ' Which button the member was standing on, BEFORE the row is thrown away.
    ' The row is rebuilt on every start, and an episode change is a start —
    ' snapping focus back to play/pause every time would make stepping
    ' through a series a fight with the remote.
    prevKey = ""
    if m.buttons <> invalid and m.focusedBtn <> invalid
        if m.focusedBtn >= 0 and m.focusedBtn < m.buttons.count() then prevKey = m.buttons[m.focusedBtn].key
    end if

    ' The VOD favorite needs to know what it would favorite before the row can
    ' be built, exactly like the live star needs a streamId.
    m.favTarget = invalid
    if not m.top.isLive then m.favTarget = favTarget()

    if m.top.isLive
        m.epNav = false
        m.buttons = []
        ' Prev/next CHANNEL, and only when there is a lineup to walk — see
        ' the block above. Hidden, never disabled.
        if m.chNav then m.buttons.push({ key: "prevch", icon: Chr(&hE045) })   ' skip_previous
        m.buttons.push({ key: "playpause", icon: Chr(&hE034) })
        if m.chNav then m.buttons.push({ key: "nextch", icon: Chr(&hE044) })   ' skip_next
        ' Android's star slot, wearing this app's heart.
        if m.top.channel <> invalid and ToStr(m.top.channel.streamId) <> ""
            m.buttons.push({ key: "favorite", icon: Chr(&hE87E) })
        end if
        m.buttons.append([
            { key: "sleep", icon: Chr(&hE425) },      ' timer (sleep timer) — Android's bedtime slot
            { key: "audio", icon: Chr(&hE1B8) },      ' graphic_eq (E1A8 is bluetooth_audio - wrong icon, seen on device)
            { key: "cc", icon: Chr(&hE01C) },         ' closed_caption
            { key: "mute", icon: Chr(&hE050) },
            { key: "refresh", icon: m.theme.iconRefresh }
        ])
    else
        ' Episode stepping only for a series episode, the same gate Android
        ' applies (vod_player_screen.dart:990: kind is an episode AND the
        ' parent reference is a series). A film and a USB file get the row
        ' they always got.
        m.epNav = episodeNavOk()
        m.buttons = []
        if m.epNav then m.buttons.push({ key: "prevep", icon: Chr(&hE045) })   ' skip_previous
        m.buttons.append([
            { key: "rewind", icon: Chr(&hE020) },     ' fast_rewind
            { key: "playpause", icon: Chr(&hE034) },
            { key: "forward", icon: Chr(&hE01F) }     ' fast_forward
        ])
        if m.epNav then m.buttons.push({ key: "nextep", icon: Chr(&hE044) })   ' skip_next
        m.buttons.append([
            { key: "audio", icon: Chr(&hE1B8) },      ' graphic_eq (E1A8 is bluetooth_audio - wrong icon, seen on device)
            { key: "cc", icon: Chr(&hE01C) },         ' closed_caption
            { key: "sleep", icon: Chr(&hE425) },      ' timer (sleep timer)
            { key: "mute", icon: Chr(&hE050) },
            { key: "refresh", icon: m.theme.iconRefresh }
        ])
        ' Same rule as Android: the star only appears when there is something
        ' to favorite, which for VOD means the opener set parentId.
        if m.favTarget <> invalid
            m.buttons.push({ key: "favorite", icon: Chr(&hE87E) })
        end if
    end if
    m.buttons.push({ key: "multiview", icon: Chr(&hE9B0) })   ' grid_view

    refreshFavState()

    ' Focus the play/pause button by default (center of the VOD bar), or the
    ' one the member was already on if it survived the rebuild.
    m.focusedBtn = 0
    for i = 0 to m.buttons.count() - 1
        if m.buttons[i].key = "playpause" then m.focusedBtn = i
    end for
    if prevKey <> ""
        for i = 0 to m.buttons.count() - 1
            if m.buttons[i].key = prevKey then m.focusedBtn = i
        end for
    end if

    layoutControls()
    redrawButtons()
end sub

' ---- The button row, to Android's measurements -----------------------------
'
' WHAT CHANGED AND WHY, 2026-08-27. This row used to be bare circular glyphs
' inside ONE rounded dark card. The owner put the phone next to the telly and
' said the two "are a completely different style, android is better" — and he
' is right, because the difference is structural, not plating. Android draws
' NO container. Each button is its own small bordered box, they pack tightly
' together, and the row sits straight on the picture.
'
' The Android widget is PlayerIconButton (lib/ui/widgets/player_icon_button
' .dart) and the branch the owner is looking at is the TERMINAL-CHROME one —
' the same branch this app's mono type and card frames already come from, so
' porting it keeps Roku and the phone in one design language rather than two:
'
'   padding      6 all round            -> 12
'   margin       1 horizontal each side -> 2  (a 4px gap between neighbours)
'   radius       3                      -> 6  (see the corner note below)
'   border       1.5                    -> 3
'   idle fill    black 35%              -> the page colour at 35%
'   idle border  white 65%              -> cardIdleBorder, the app's own frame
'   idle glyph   white                  -> textPrimary
'   focus fill   white                  -> focusHighlight
'   focus border accent                 -> focusHighlight
'   focus glyph  slate (dark ink)       -> background (dark ink)
'   icon size    22, play/pause 30      -> 44, play/pause 60
'
' The palette is deliberately NOT Android's. Owner's standing instruction is
' Android's design LANGUAGE with the Nord palette applied, so the teal
' becomes the nord yellow every detail page already focuses with, and the
' favourited heart keeps the app's own favourite colour.
'
' A focused button is therefore a filled highlight KEY with dark ink on it —
' the same thing the member sees on every other focusable surface in this
' app, and the same read Android's white-on-accent gives.
'
' FOUR PLACES ROKU CANNOT FOLLOW ANDROID, stated rather than approximated:
'
'  1. CORNER RADIUS. Roku cannot round a Rectangle, so a rounded shape is a
'     nine-patch whose corner is baked into the file. The app's plate is
'     card_fill.9.png at radius 8 and its frame is card_edge.9.png; Android
'     asks for 6. Those two files are used by every card on Home, so they
'     cost NO package size and — Roku caches one texture per URI — no extra
'     texture memory however many buttons share them. 8 against 6 is not
'     worth a fourth corner radius and a new asset. Deliberate.
'  2. BORDER WEIGHT. The frame is a nine-patch, so its stroke is whatever
'     was drawn into the file; it cannot be made heavier on focus the way
'     Android thickens its border. The focus read is carried by the FILL
'     instead, which is the louder half of Android's cue anyway.
'  3. THE DROP SHADOW Android's terminal branch puts behind a focused key
'     (BoxShadow offset 2,2). Roku has no shadow primitive, and faking it
'     would be a fourth node on every button for a 2px offset.
'  4. THE 300ms CROSS-FADE Android runs on the whole overlay
'     (AnimatedOpacity). Not attempted: an Animation node on a group shown
'     and hidden several times a minute is work the Stick does not need.
'
' NODE COUNT IS UNCHANGED at three per button — a fill, a frame and the
' glyph, where it used to be a ring, an inner disc and the glyph. Two nodes
' were REMOVED with the card. Everything is built once here and only ever
' toggled by redrawButtons, never created on show: certification 3.5 gives
' the UI 250ms to answer a press and this bar shows and hides several times a
' minute.
'
' The widest row is TWELVE — a series episode with a favourite heart and the
' two episode buttons — which is 11 x (68 + 4) + 84 = 876px and centres on
' 522..1398. The trickplay chip is right-aligned into 1824, so they never
' meet.
sub layoutControls()
    row = m.top.findNode("buttonRow")
    while row.getChildCount() > 0
        row.removeChildIndex(0)
    end while

    count = m.buttons.count()
    size = 68        ' Android's 22 glyph + 6 padding each side, doubled
    bigSize = 84     ' play/pause: Android's 30 + 6 each side, doubled
    gap = 4          ' Android's 1px horizontal margin each side, doubled
    rowH = bigSize   ' the row is as tall as its tallest button

    ' Android's Wrap plus that 1px margin each side: the boxes do NOT abut
    ' any more, they sit a hair apart, which is what makes a row of outlined
    ' squares read as separate keys instead of one striped bar.
    rowW = 0
    for i = 0 to count - 1
        if m.buttons[i].key = "playpause"
            rowW = rowW + bigSize + gap
        else
            rowW = rowW + size + gap
        end if
    end for
    rowW = rowW - gap        ' no trailing gap after the last key

    ' The row sits low on the picture, on the SAME line live and VOD, so the
    ' play button never jumps when one opens after the other. 1024 is
    ' 1080 - 56, Android's bottom:28 doubled, and is where the bottom of the
    ' old card sat — so nothing moved vertically, only the card left.
    rowBottom = 1024
    rowTop = rowBottom - rowH
    x = Int((1920 - rowW) / 2)
    for i = 0 to count - 1
        b = m.buttons[i]
        dia = size
        glyph = 44
        if b.key = "playpause"
            dia = bigSize
            glyph = 60
        end if
        y = rowTop + Int((rowH - dia) / 2)

        ' THE PLATE. Visible ALWAYS — a faint dark fill behind the glyph, the
        ' way Android's terminal key is a dark box over the video rather than
        ' a bare icon. It is the plate that gets recoloured on focus, not
        ' shown and hidden, so there is no state where a button has no
        ' background at all.
        fill = row.createChild("Poster")
        fill.uri = "pkg:/images/card_fill.9.png"
        fill.width = dia
        fill.height = dia
        fill.translation = [x, y]

        ' THE FRAME. Also always visible. This is the whole of what the owner
        ' was asking for — every button individually outlined, no container
        ' around the set of them.
        edge = row.createChild("Poster")
        edge.uri = "pkg:/images/card_edge.9.png"
        edge.width = dia
        edge.height = dia
        edge.translation = [x, y]

        icon = row.createChild("Label")
        icon.font = IconFont(glyph)
        icon.width = dia
        icon.height = dia
        icon.horizAlign = "center"
        icon.vertAlign = "center"
        icon.translation = [x, y]

        b.fill = fill
        b.edge = edge
        b.iconNode = icon
        x = x + dia + gap
    end for
end sub

sub redrawButtons()
    for i = 0 to m.buttons.count() - 1
        b = m.buttons[i]

        ' Current icon per state
        glyph = b.icon
        if b.key = "playpause"
            if m.video.state = "playing" then glyph = Chr(&hE034) else glyph = m.theme.iconPlay
        else if b.key = "mute"
            if m.video.mute then glyph = Chr(&hE04F) else glyph = Chr(&hE050)
        else if b.key = "favorite"
            ' Heart, filled when favourited. Deliberately NOT m.theme.iconStar:
            ' that token is a star used by rating rows elsewhere, and a
            ' favourite in this app has always been a heart.
            if m.favOn then glyph = Chr(&hE87D) else glyph = Chr(&hE87E)
        end if
        b.iconNode.text = glyph

        ' EVERY ONE OF THE THREE NODES IS WRITTEN ON BOTH BRANCHES. These
        ' button objects are rebuilt per row but the row is redrawn on every
        ' reveal, every play/pause and every favourite toggle, so a colour
        ' set only inside the "focused" branch would leave the last focused
        ' button wearing the highlight after focus moved off it. Both ways,
        ' always.
        '
        ' Focused = a filled highlight key with dark ink, which is Android's
        ' terminal branch (white fill, accent border, slate glyph) in the
        ' Nord palette — and the same focus read as every other surface in
        ' this app. Idle = a faint dark plate behind the glyph with the
        ' house frame around it. No button glows while the seek bar holds
        ' focus.
        focused = (i = m.focusedBtn and m.focusArea = "buttons")
        if focused
            b.fill.blendColor = m.theme.focusHighlight
            b.edge.blendColor = m.theme.focusHighlight
            ' Dark ink on the highlight, exactly as the palette note in
            ' Theme.brs prescribes for a focusHighlight plate. This wins over
            ' every state tint below on purpose — Android does the same
            ' ("overriding any base color, e.g. the pink favorite star").
            b.iconNode.color = m.theme.background
        else
            ' Android's terminal key is `black 35%` over the video. The page
            ' colour stands in for the black, same job and same lightness
            ' family, and 0x59 is 89/255 = 35% exactly.
            b.fill.blendColor = Left(m.theme.background, 8) + "59"
            b.edge.blendColor = m.theme.cardIdleBorder
            if b.key = "favorite" and m.favOn
                b.iconNode.color = m.theme.favorite
                ' Lit for a fetched subtitle too. m.ccSel only ever covers
                ' the stream's own tracks, so on its own it would go dark
                ' while the member is reading the file they downloaded.
            else if b.key = "cc" and (m.ccSel > 0 or m.extSubOn)
                b.iconNode.color = m.theme.accent
            else if b.key = "sleep" and m.sleepSel > 0
                ' Android colors an armed sleep timer and a live mute the
                ' same warm orange, so you can see the state without opening
                ' anything.
                b.iconNode.color = m.theme.focusHighlight
            else if b.key = "mute" and m.video.mute
                b.iconNode.color = m.theme.focusHighlight
            else
                b.iconNode.color = m.theme.textPrimary
            end if
        end if
    end for
end sub

' ---- Favorites --------------------------------------------------------------

' Cached, because redrawButtons runs on every reveal and every state change
' and both favorite lookups are a registry read plus a JSON parse. Nothing
' else can change a favorite while a fullscreen player is up, so the only
' thing that has to refresh it is this player's own star.
sub refreshFavState()
    if m.top.isLive
        m.favOn = isChannelFavorite()
    else if m.favTarget <> invalid
        m.favOn = IsFavoriteVod(m.favTarget.kind, m.favTarget.id, m.favTarget.src)
    else
        m.favOn = false
    end if
end sub

function isChannelFavorite() as boolean
    ch = m.top.channel
    if ch = invalid then return false
    ' Match against the channel's own source when the opener set one.
    tok = invalid
    if type(ch) = "roAssociativeArray" and ch.doesExist("src") then tok = ToStr(ch.src)
    return IsFavoriteChannel(ToStr(ch.streamId), tok)
end function

' What a VOD favorite applies to, derived the same way Android derives it
' (vod_player_screen.dart:878) — out of parentId, which every VOD opener
' already sets for the KwickSync history push:
'
'     "movie:<src>~<id>"   /   "series:<src>~<id>"
'
' An episode therefore favorites its SERIES, which is both what Android does
' and what SeriesDetailScreen's own star does. invalid means no parent, which
' means no star — a deep link or a USB file has nothing to add to a list.
'
' Split at the FIRST colon only. Android can use a plain split(':') because
' its source ids have no colon; Roku's source tokens are "xt:12" / "m3u:3"
' and carry one, so "movie:xt:12~340" is three pieces there and two here.
function favTarget() as dynamic
    pid = m.top.parentId
    if pid = "" then return invalid
    at = Instr(1, pid, ":")
    if at <= 0 then return invalid
    kind = Left(pid, at - 1)
    if kind <> "movie" and kind <> "series" then return invalid
    parts = SplitSrcQualifiedId(Mid(pid, at + 1))
    if parts.id = "" then return invalid
    name = m.top.histTitle
    if name = "" then name = m.top.titleText
    ' The detail pages store the container extension so the favorites row can
    ' build a play url later. This player is handed a finished address rather
    ' than the extension, so read it back off the address. Series carry "",
    ' same as SeriesDetailScreen writes.
    ext = ""
    if kind = "movie" then ext = urlExtension(m.top.streamUrl)
    return { kind: kind, id: parts.id, name: name, icon: m.top.posterUrl, ext: ext, src: parts.src }
end function

' "…/movie/user/pass/1234.mkv" -> "mkv". "" when the address has no extension
' worth the name (a bare id, a query-only url, a folder).
function urlExtension(url as string) as string
    q = Instr(1, url, "?")
    if q > 0 then url = Left(url, q - 1)
    dot = 0
    for i = Len(url) to 1 step -1
        c = Mid(url, i, 1)
        if c = "."
            dot = i
            exit for
        end if
        if c = "/" then exit for
    end for
    if dot = 0 then return ""
    e = LCase(Mid(url, dot + 1))
    if Len(e) < 2 or Len(e) > 5 then return ""
    return e
end function

' ---- Playback ---------------------------------------------------------------

sub startPlayback()
    ' A PLAYER THAT HAS LEFT NEVER OPENS A STREAM. Both teardown paths now stop
    ' m.retryTimer, but stopping a Timer cannot recall a `fire` that has ALREADY
    ' been posted to the render thread's queue — if the timer expires in the
    ' same pass as the member's Back press, closePlayer runs and this sub is
    ' still called afterwards, and the connection is spent. This line shuts that
    ' window for every caller at once. Inference, not a measurement: the window
    ' is a single dispatch and nobody has caught it on a box.
    '
    ' Safe to test because no opener ever reuses a player node — all of them
    ' createChild a fresh one and drop the reference on `closed`
    ' (LiveTvScreen.brs:1932, AppScene.brs:346 and the rest), so `closed` can
    ' only ever be true for a player nothing is going to show again.
    if m.top.closed then return
    if m.top.streamUrl = "" then return
    ' Forget the last title's position. This node is REUSED — a retry after a
    ' stream hiccup comes back through here, and so does the next episode
    ' when Shuffle Episodes queues one. Left standing, the finished mark
    ' below would judge the new title on how far through the previous one
    ' the member got, and mark something they have not watched at all.
    m.lastPosS = 0
    m.lastDurS = 0
    content = CreateObject("roSGNode", "ContentNode")
    content.url = m.top.streamUrl
    content.title = m.top.titleText
    content.streamFormat = m.top.streamFormat
    if m.top.isLive then content.live = true
    ' VOD resume: start where we left off.
    if not m.top.isLive and m.top.resumeFrom > 0
        content.playStart = m.top.resumeFrom
    end if
    armResumeVerification()
    ' Identify the app to the provider's panel. THIS is the request that
    ' shows up in the panel's active-connections list — the data calls below
    ' never appear there — so if this one is missed, streams show as the
    ' player engine's default and can't be attributed to us.
    hdrs = ["User-Agent: " + KwickUserAgent()]
    ' Anything the opener needed to add — today that is only the media-server
    ' "Authorization: MediaBrowser ..." line, and on Emby the X-Emby-Token
    ' beside it. Appended rather than assigned, so the User-Agent above always
    ' survives: it is the line the panel counts, and a source that needs no
    ' extra headers leaves this array empty and nothing changes for it.
    for each h in ToArray(m.top.streamHeaders)
        line = ToStr(h)
        if line <> "" then hdrs.push(line)
    end for
    content.HttpHeaders = hdrs
    ' ---- The member's own subtitle file, if there is one (JB-7) -----------
    ' Read the remembered choice for whatever is playing NOW — this sub runs
    ' again for the next episode, which is a different title with a
    ' different answer — and hang the file on the content node BEFORE it
    ' reaches the Video node.
    '
    ' THIS IS THE FREE PATH, and it is why the choice is remembered at all.
    ' A subtitle attached here costs no request, no download out of the
    ' member's daily allowance, and no extra connection to the provider:
    ' it rides along with the one stream open this player was always going
    ' to make. Picking a subtitle mid-film is the expensive path, and
    ' attachExternalSub is where that is spent.
    loadRememberedSub()
    ' Always cleared, then set — this node is REUSED for a retry, a Refresh,
    ' an episode step and a channel zap, and a flag left standing from the
    ' last title would say the decoder is holding a file it has never seen.
    m.extSubLoaded = false
    if m.extSubPath <> "" and m.extSubOn
        ' SubtitleTracks + SubtitleConfig, which are the two fields SceneGraph
        ' actually takes — SubtitleUrl is roVideoScreen only and was never
        ' going to work here. The whole argument is above attachExternalSub.
        if applyExtSubToContent(content)
            ' Roku needs BOTH — the track declared on the content node and
            ' the caption renderer switched on. The track alone draws
            ' nothing, which is the same trap the live embedded captions
            ' fell into.
            m.video.globalCaptionMode = "On"
            m.extSubLoaded = true
        end if
        ' NOT selected off m.video.subtitleTrack here. SubtitleConfig is what
        ' selects a sideloaded track, and it is set on the content node above,
        ' before the node ever reaches the player. Whether the track then
        ' shows up in availableSubtitleTracks is the open question logSubTracks
        ' exists to answer.
    end if
    ' Start-muted preference (Settings → Playback), applied once per launch.
    if m.mutedApplied <> true
        m.mutedApplied = true
        if GetPrefBool("pref_start_muted", false) then m.video.mute = true
    end if
    ' Captions auto-on (Settings → Playback) — same as Android: captions
    ' switch on from the start of every stream, live and VOD. Applied once
    ' per player so a manual Off (then Refresh) isn't overridden.
    if m.ccAutoApplied <> true
        m.ccAutoApplied = true
        if GetPrefBool("pref_captions_auto", false)
            ' Live engages immediately; VOD waits for the track list to
            ' arrive so it can pick the preferred language (see onPosition).
            if m.top.isLive then m.ccSel = 1
            m.video.globalCaptionMode = "On"
        end if
    end if
    ' The captions mode is a device-wide Roku setting that outlives this
    ' player. On live, if it's already On, reflect that in the CC button so
    ' choosing Off actually turns captions off. (The embedded track itself
    ' is applied once the stream reaches "playing" — see onVideoState.)
    if m.top.isLive and m.ccSel = 0 and m.video.globalCaptionMode = "On" then m.ccSel = 1
    m.video.content = content
    m.video.control = "play"
    ' Take the terminal grid wash down while a picture is on. Android gates
    ' the same overlay on !playing (main.dart:178); AppScene owns the mesh
    ' and observes this flag, and this is the one line that sets it (the
    ' pairing is written out at AppScene.brs:52-70). Here rather than in
    ' onVideoState on purpose: this sub is the single funnel every play
    ' attempt goes through — first open, retry, Refresh and episode change —
    ' and writing it inline is synchronous, where a state observer is not
    ' guaranteed to run before this node is torn down.
    '
    ' NOT a correctness fix. The player is a child of the scene created after
    ' the effects, so it already covers them; this is the compositing work a
    ' Stick does not have to do. Cleared in closePlayer and in the Multi-View
    ' hand-over, which are the only two places `closed` is set.
    m.global.fxPaused = true
    ' The open watchdog and the progress sampler (GAP A4). Started here, on
    ' every attempt including a retry and a Refresh, so each attempt gets its
    ' own twenty seconds to produce a picture. No-op on VOD.
    startLiveHealth()
    if not m.top.isLive and m.top.resumeKey <> "" then m.saveTimer.control = "start"
    m.status.visible = false
    m.chTitle.text = m.top.titleText
    m.top.findNode("livePill").visible = m.top.isLive
    m.progressWrap.visible = not m.top.isLive
    ' "Ends at 8:42 PM". Forget the last title's answer, hide the label until
    ' there is a duration to work from, and start the minute tick — VOD only,
    ' and it keeps ticking through a pause on purpose (see refreshEndTime).
    ' This adds NO request and touches nothing about how the stream is fetched.
    m.endRemain = -1
    m.endLabel.visible = false
    ' The total reading goes with it. This node is REUSED — a retry, a
    ' Refresh, an episode change and a channel zap all come back through
    ' here — so the last title's running time must not sit at the end of the
    ' bar while the next one is still working out whether it has a duration
    ' at all. drawSeek shows it again the moment there is one.
    m.durLabel.visible = false
    m.timeLabel.text = ""
    m.durLabel.text = ""
    m.endTimer.control = "stop"
    if not m.top.isLive then m.endTimer.control = "start"
    startNowPlaying()
    ' Before buildButtons, because it is what decides whether the two channel
    ' buttons exist at all. Costs nothing on VOD and nothing on a repeat pass.
    bindChannelNav()
    buildButtons()
    showControls()
end sub

sub onVideoState()
    state = m.video.state
    if state = "error"
        m.stepSwitching = false
        errInfo = m.video.errorMsg
        KLog("player", "error: " + errInfo)
        KLog("player", "url: " + m.top.streamUrl + " format: " + m.top.streamFormat)
        kind = StreamErrorKind(errInfo)
        if kind = "malformed"
            ' Roku says "malformed data" both for a stream it cannot decode
            ' (AAC Main audio is the common one — plays on phones, not on Roku)
            ' and for the occasional non-media reply from a busy panel. Give it
            ' ONE retry to clear a transient reply; a second identical failure
            ' is the decoder, so stop and explain rather than storm the panel
            ' with the full ladder (which also trips a connection-capped
            ' account). See StreamErrorKind/StreamErrorText.
            if m.malformedTries < 1 and armRetry("malformed data")
                m.malformedTries = m.malformedTries + 1
            else
                KLog("player", "fatal (malformed) — not retrying")
                stopLiveHealth()
                logAudioTracks()
                m.status.text = StreamErrorText("malformed")
                m.status.visible = true
            end if
        else if kind <> "retry"
            ' Deterministic — this Roku has no decoder for it, so reconnecting
            ' can only fail again while burning the member's time and another
            ' connection against their provider.
            KLog("player", "fatal (" + kind + ") — not retrying")
            stopLiveHealth()
            logAudioTracks()
            m.status.text = StreamErrorText(kind)
            m.status.visible = true
        else if armRetry("stream error")
            ' The ladder took it. Nothing else to do.
        else
            liveGiveUp("Couldn't play this stream.")
        end if
    else if state = "playing"
        m.stepSwitching = false
        m.sawPlaying = true
        m.malformedTries = 0
        m.openTimer.control = "stop"
        m.stalledFor = 0
        m.status.visible = false
        ' (Re)apply live captions now the stream is actually up — the
        ' embedded eia608 track can't be selected before the player has
        ' opened the stream, which is why setting the mode alone at start
        ' never rendered anything.
        if m.top.isLive and m.ccSel > 0
            m.video.globalCaptionMode = "On"
            m.video.subtitleTrack = embeddedCcTrack()
        end if
        ' Tell Trakt and Simkl this is playing — HERE and not in startPlayback,
        ' because startPlayback runs again for every rung of the reconnect
        ' ladder, every Refresh press and every subtitle reopen, and a stream
        ' that rebuffers arrives here again each time it recovers. Held down to
        ' one request by m.scrobWatching. No-op on live and on any title whose
        ' panel sent no TMDB id.
        scrobbleStarted()
    else if state = "paused"
        ' A real pause, which is the only kind that reaches this state with
        ' m.tricking false — the << / >> scan freezes the picture the same way
        ' but sets that flag first. Nothing else in this branch: pausing
        ' changes no button and no label that redrawButtons below doesn't
        ' already handle.
        scrobblePause()
    else if state = "finished"
        ' Reached the end — write the finished mark, THEN clear the resume
        ' point so it starts fresh. Order matters only for readability (they
        ' are different registry sections), but the mark has to happen here
        ' at all: clearing the resume point is the only trace finishing used
        ' to leave, and "no resume point" reads identically to "never
        ' started" (see MediaBarEntries).
        '
        ' Judged on the last position the player REPORTED, not on the state
        ' itself. A stream that dies halfway also arrives here — the Roku
        ' ends a truncated download by saying "finished" — and taking that
        ' at face value would mark a title the member is only half way
        ' through, then hide it from them. m.video.position is not read
        ' directly because it is not dependable once playback has stopped.
        '
        ' THE TWO LINES BELOW STAND OR FALL TOGETHER, and the whole of the
        ' resume bug Mason reported on 2026-08-26 was that they did not. The
        ' test above was written for markFinished and applied ONLY to it;
        ' ClearResume sat on the next line unguarded, so a stream that died
        ' halfway escaped the false "watched" mark and then destroyed the
        ' member's resume point anyway. They came back to it and it started
        ' from the beginning. Mason's rule is "do not reset an existing
        ' playback position unless the user intentionally chooses to start
        ' from the beginning", and a truncated download is not the member
        ' choosing anything.
        '
        ' So the answer is computed ONCE, here, and both lines read it. Do
        ' not split this back into two tests: a second 95% check written out
        ' again is how they drifted apart the first time.
        '
        ' Both ways, as always. A title genuinely watched to the end still
        ' clears, or it would offer Resume at 99% forever.
        '
        ' WHERE THE REAL CLEARING HAPPENS, so nobody mistakes this for the
        ' mechanism. When a duration IS reported, SaveResume's own 95% rule
        ' throws the resume point away on EVERY tick of the save timer, not
        ' just at the end of the stream — so on a film watched to the end the
        ' point is already gone long before this handler runs. The guard
        ' below is belt-and-braces over that, and that is all it is.
        '
        ' A TITLE WITH NO REPORTED DURATION CANNOT BE FIXED, HERE OR ANYWHERE.
        ' m.lastDurS only moves while duration is greater than zero
        ' (onPosition), and SaveResume is handed the same zero. There is no
        ' known end to take 95% of, and a last position of 47:12 looks
        ' identical whether the film ran out there or the stream died there.
        ' There is no information to act on, so no rule in Store.brs and no
        ' rule in here can tell the two apart. Do not go looking for one.
        '
        ' So the resume point is KEPT, deliberately. That is the safe side of
        ' Mason's "do not reset an existing playback position unless the user
        ' intentionally chooses to start from the beginning", and it is also
        ' exactly what the phone does — lib/data/viewmodels/watch_state.dart
        ' :32-72, where progressOf returns null on an unknown duration,
        ' isFinished therefore stays false, and shouldResume therefore stays
        ' true. Android offers Resume forever on a duration-less title too.
        ' Roku already matches the reference platform; "fixing" this would
        ' break parity rather than close a gap. Check the file, do not take
        ' it on trust.
        '
        ' ONE PLACE THE TWO RULES GENUINELY RUB, pre-existing and NOT being
        ' changed tonight: past 95% there is no resume point at all while the
        ' last 5% plays, because SaveResume has already dropped it. So a
        ' stream that dies at 96% starts from the beginning next time. Android
        ' does the same — it calls 96% finished and offers Play, not Resume —
        ' so it is parity, not a Roku fault. Written down here so the next
        ' person rediscovers it from the file instead of from a member.
        reachedEnd = (m.lastDurS > 0 and m.lastPosS > Int(m.lastDurS * 0.95))
        if reachedEnd then markFinished()
        if reachedEnd and m.top.resumeKey <> "" then ClearResume(m.top.resumeKey)
        ' The final scrobble, and the one that matters: both services turn a
        ' `stop` at 80% or more into a watched mark themselves. Sent on the
        ' measured progress WHATEVER reachedEnd says — a stream that died
        ' halfway reports "finished" too, and the honest number is what stops
        ' that being marked watched on the member's own account. Sent once;
        ' the ways out below and closePlayer all call the same guarded sub.
        scrobbleStop()
        stopLiveHealth()
        ' Tell the parent screen, so Shuffle Episodes can queue the next one
        ' — UNLESS the episode buttons have been used, in which case the
        ' parent's idea of which episode is playing is out of date and this
        ' player runs the end itself. The whole argument is written out above
        ' playerOwnsEnd().
        if playerOwnsEnd()
            armOwnAutoNext()
        else
            m.top.ended = true
        end if
    end if
    redrawButtons()
end sub

' ---- The reconnect ladder and the watchdogs (GAP A4) -------------------------
'
' What was here before: three attempts, four seconds apart, on a live stream
' whose error looked transient. Three things were wrong with it, and none of
' them is "not enough retries" — the retry BUDGET is the one number that must
' not grow, because four rapid connections against a one-stream account is the
' exact pattern a provider's anti-share system bans for, and the owner's own
' IP was banned that way (Util.brs:305-310).
'
'   1. THE LADDER RESET ON THE FIRST FRAME. `m.retries = 0` ran the moment the
'      state reached "playing", so a channel that played for two seconds and
'      dropped again got another three attempts, forever. A flapping stream
'      could therefore reconnect without limit at a steady four seconds — the
'      banned pattern, sustained. Android hit this exact bug and says so in
'      live_player_screen.dart:308-312. The ladder now only clears after
'      playback has genuinely HELD, ten seconds of real progress, which is
'      Android's _noteHealthy rule. This makes the app ask for FEWER
'      connections than it used to, not more.
'   2. FLAT SPACING. A panel that is struggling is not helped by being asked
'      again at the same rate. The three attempts are now 4s, 8s, 12s — the
'      same three connections spread over 24 seconds instead of 12. Android
'      doubles from 1.5s; these start where this player already started and
'      end at the same 12s ceiling.
'   3. TWO FAILURES RAISED NOTHING AT ALL. A stream that opens and never
'      decodes a frame, and a stream that says "playing" while the picture
'      stands still, both leave the Video node reporting no error whatever —
'      so nothing ever retried and nothing was ever said. Those are the two
'      watchdogs below. Both spend the SAME three attempts; neither can add a
'      fourth.
'
' UNCHANGED, because it is load-bearing: only a retry-class error is ever
' retried. A deterministic codec failure is never reconnected, and the
' watchdogs cannot resurrect one — StreamErrorKind decides first, and a fatal
' verdict stops the health timers dead.
'
' LIVE ONLY, also unchanged. A VOD stream that fails is a file that failed;
' re-opening it costs a connection and produces the same result.

' Three, and that is the number the whole argument above rests on.
function maxReconnects() as integer
    return 3
end function

' A stall is ten seconds of no progress. Long enough that an ordinary
' rebuffer on a home connection never reaches it.
function stallSeconds() as integer
    return 10
end function

' Take the next rung, if there is one. Returns false when the ladder is spent
' (or this isn't live), which is the caller's cue to give up in words.
function armRetry(reason as string) as boolean
    if not m.top.isLive then return false
    if m.retries >= maxReconnects() then return false
    m.retries = m.retries + 1
    m.healthyFor = 0
    m.stalledFor = 0
    ' 4s, 8s, 12s. The open watchdog is stood down for the pause — the next
    ' attempt starts it again.
    secs = 4 * m.retries
    m.openTimer.control = "stop"
    m.retryTimer.control = "stop"
    m.retryTimer.duration = secs
    m.retryTimer.control = "start"
    m.status.text = "Stream hiccup — reconnecting (" + m.retries.toStr() + "/" + maxReconnects().toStr() + ")..."
    m.status.visible = true
    KLog("player", "reconnect " + m.retries.toStr() + "/" + maxReconnects().toStr() + " in " + secs.toStr() + "s (" + reason + ")")
    return true
end function

sub liveGiveUp(text as string)
    stopLiveHealth()
    m.status.text = text
    m.status.visible = true
    ' Only worth asking the panel about the ACCOUNT when the failure could
    ' plausibly be the account. A codec failure never is.
    if m.top.isLive then diagnoseLiveFailure()
end sub

sub startLiveHealth()
    stopLiveHealth()
    m.sawPlaying = false
    m.posEverMoved = false
    m.livePos = -1
    m.stalledFor = 0
    if not m.top.isLive then return
    m.openTimer.control = "start"
    m.healthTimer.control = "start"
end sub

sub stopLiveHealth()
    m.openTimer.control = "stop"
    m.healthTimer.control = "stop"
end sub

' Twenty seconds and not one frame. The stream answered — there is no error to
' report — it simply never played. Android calls this the green-screen case
' (live_player_screen.dart:508) and gives it eighteen seconds; twenty here
' because a Roku Express opening a big HLS stream on a slow line is genuinely
' slower than the phones that number was measured on.
sub onOpenTimeout()
    if not m.top.isLive then return
    if m.sawPlaying then return
    KLog("player", "no picture within 20s — the stream opened but never played")
    m.video.control = "stop"
    if armRetry("opened but never played") then return
    liveGiveUp("This channel opened but never started playing. The stream may be broken right now — try another channel, or come back a little later.")
end sub

' Every two seconds while a live stream is up: has playback actually moved?
'
' The two things it decides:
'   · a stall — ten seconds of no progress, which the Video node never
'     reports as an error;
'   · a recovery — ten seconds of real progress forgives the ladder.
'
' THE FALSE-STALL GUARD, which matters more than the feature. Killing a
' HEALTHY stream would spend a connection for nothing, which is the one thing
' this whole area is trying not to do. Not every device reports a moving
' position on every live stream, and a position stuck at zero on a picture
' that is playing perfectly would look exactly like a stall. So a frozen
' position only counts once this stream has been SEEN to move at least once
' (posEverMoved) — on a box that never reports movement the position test
' simply never arms, and only sustained buffering can raise a stall.
sub onHealthTick()
    if not m.top.isLive
        stopLiveHealth()
        return
    end if
    st = m.video.state
    if st = "playing"
        posS = m.video.position
        if posS > m.livePos
            ' The FIRST sample is only a baseline, never proof of movement:
            ' m.livePos starts at -1, so a position of zero would clear that
            ' bar and arm the test on a stream that has not moved at all.
            ' Proof needs two samples that differ.
            if m.livePos >= 0 then m.posEverMoved = true
            m.livePos = posS
            m.stalledFor = 0
            if m.retries > 0
                m.healthyFor = m.healthyFor + 2
                if m.healthyFor >= 10
                    KLog("player", "playback healthy again — reconnect ladder reset")
                    m.retries = 0
                    m.healthyFor = 0
                end if
            end if
            return
        end if
        m.healthyFor = 0
        if not m.posEverMoved then return    ' can't tell on this stream — say nothing
        m.stalledFor = m.stalledFor + 2
    else if st = "buffering"
        ' Only after the picture has been up once. Before that the open
        ' watchdog owns the wait, and a slow first connection must not be
        ' mistaken for a stream that died.
        m.healthyFor = 0
        if not m.sawPlaying then return
        m.stalledFor = m.stalledFor + 2
    else
        ' paused, stopped, finished, or waiting out a reconnect pause.
        return
    end if
    if m.stalledFor < stallSeconds() then return
    KLog("player", "live stall: no progress for " + m.stalledFor.toStr() + "s (state " + st + ")")
    m.stalledFor = 0
    m.video.control = "stop"
    if armRetry("stall") then return
    liveGiveUp("This channel keeps dropping. It may be temporarily down — try another channel, or come back a little later.")
end sub

' Persist the current VOD position (no-op for live), plus the history
' metadata KwickSync pushes to the phone's Continue Watching (T7).
' When a live stream gives up, ask the panel WHY before leaving the member
' at "Couldn't play this stream." Two account-level causes produce exactly
' this failure and look identical to a broken channel, because the panel
' answers with an error page and the player reports it as malformed data:
' every connection already in use, or a lapsed subscription. Member log
' E794B4 was three different channels failing back to back — which is
' almost never three dead channels.
sub diagnoseLiveFailure()
    ' ONCE PER PLAYER, and the flag is what enforces it now rather than the
    ' node reference. The guard used to read `m.diagTask <> invalid`, which
    ' meant the reference could never be let go without re-opening the door to
    ' a second question at the panel on a second give-up. One extra request is
    ' not a ban on its own, but it is a request the member did not ask for and
    ' this whole file is written to avoid those.
    if m.diagAsked = true then return
    p = ActiveProvider()
    if p = invalid or ToStr(p.ptype) = "m3u" then return
    ' Never at a member's own Jellyfin or Emby. This reads the ACTIVE source,
    ' which is not necessarily the one the failing channel came from — so a
    ' member browsing their Jellyfin while a live channel from another source
    ' drops would otherwise send XtreamApiUrl, username and password in the
    ' query string, to their media server. It has no user_info to give back
    ' either, so there is nothing lost by not asking.
    if MsIsMediaServer(p) then return
    m.diagAsked = true
    m.diagTask = CreateObject("roSGNode", "ApiTask")
    m.diagTask.url = XtreamApiUrl(p, "")
    m.diagTask.observeField("result", "onLiveFailureDiagnosis")
    m.diagTask.control = "RUN"
end sub

' Let the diagnosis task go. The OBSERVER is the point, not the memory the task
' itself holds: m.diagTask is an orphan node — created here, never added to the
' scene, held by nothing but this reference — and a plain observeField on it is
' a hard reference from that node back to this screen. So a player that had
' once run out of retries could not be freed, Video node and all, for as long
' as the app ran. Exactly the defect and exactly the shape measured and fixed
' for the m.global observers on 2026-09-14 (see armResumeVerification, and
' PosterCard.brs before it). observeFieldScoped is not the answer here the way
' it was there — this node is ours to destroy, so destroying it is.
'
' Safe to call at any time and from anywhere, including from inside the
' observer it is removing: by then the event has already been delivered.
sub releaseDiagTask()
    if m.diagTask = invalid then return
    m.diagTask.unobserveField("result")
    ' Usually a no-op — the answer has landed and the task has already ended.
    ' On the teardown path it may still be in flight, and a request whose reply
    ' nobody will read is not one worth leaving open at the panel.
    m.diagTask.control = "stop"
    m.diagTask = invalid
end sub

sub onLiveFailureDiagnosis(event as object)
    ' FIRST, ahead of every early return below. The answer is in hand either
    ' way and the reference has to go on all of these paths, not only the one
    ' that has something to tell the member.
    releaseDiagTask()
    res = event.getData()
    if res = invalid or res.ok <> true then return
    ui = GetField(res.data, "user_info")
    if ui = invalid then return
    status = LCase(ToStr(GetField(ui, "status")))
    maxConn = ToInt(GetField(ui, "max_connections"))
    active = ToInt(GetField(ui, "active_cons"))
    msg = ""
    if status <> "" and status <> "active"
        msg = "Your subscription is " + status + " — streams won't play until it's renewed."
    else if maxConn > 0 and active >= maxConn
        ' Careful with the wording: a connection the member themselves just
        ' dropped can still show as active for a short while, so don't state
        ' outright that another device is to blame.
        if maxConn = 1
            msg = "Your plan allows 1 stream at a time and it's currently in use — if you're watching on another device, stop there and try again."
        else
            msg = "All " + maxConn.toStr() + " of your streams are in use — stop one on another device and try again."
        end if
    end if
    if msg = "" then return
    KLog("player", "live failure diagnosis: " + msg)
    ' This can no longer land after the member has left — closePlayer and the
    ' Multi-View hand-over both release the task, so the observer is gone
    ' before the screen is. It used to be reachable after teardown and wrote to
    ' the label anyway, which was harmless (the node outlives the teardown) but
    ' was the visible half of the reference that kept the whole player alive.
    m.status.text = msg
    m.status.visible = true
end sub

' Groundwork, not a fix. When a stream's audio can't be decoded, the useful
' question is whether it carried ANOTHER audio track worth switching to —
' plenty of IPTV feeds ship MP2 alongside AAC, and picking the AAC one would
' play fine. But Roku never tells us a track's codec, and on a codec failure
' it may not have parsed any tracks at all, so switching blind would just be
' another doomed connection. Record what it did know instead: if reports show
' a second track is usually present, an automatic switch becomes a real fix
' rather than a guess.
sub logAudioTracks()
    tracks = m.video.availableAudioTracks
    if tracks = invalid
        KLog("player", "audio tracks: none reported")
        return
    end if
    KLog("player", "audio tracks: " + tracks.count().toStr() + " reported")
    for each tr in tracks
        KLog("player", "  track " + ToStr(GetField(tr, "Track")) + " lang=" + ToStr(GetField(tr, "Language")) + " name=" + ToStr(GetField(tr, "Name")))
    end for
end sub

sub saveProgress()
    if m.top.isLive or m.top.resumeKey = "" then return
    ' Started from zero before this box had heard from the locker, and the
    ' question "were you already partway through this on your phone?" has not
    ' been answered yet. Writing now is the thing that destroys the answer —
    ' see armResumeVerification().
    if resumeStillUnverified() then return
    posS = m.video.position
    dur = m.video.duration
    if posS > 0
        ' BEFORE SaveResume, which is where the evidence goes: past 95% it
        ' throws the resume point away (and the kwick_hist row with it), and
        ' until now that was the end of the matter — nothing recorded that
        ' the title had been finished rather than abandoned. Same rule,
        ' character for character, so the mark and the deletion can never
        ' disagree about what "finished" means.
        if dur > 0 and posS > Int(dur * 0.95) then markFinished()
        SaveResume(m.top.resumeKey, posS, dur)
        ' THE SOURCE OF THE WRONG KIND, fixed 2026-09-18 on Mason's word.
        ' This line used to read `m.top.resumeKey.left(3) = "ep:"` directly,
        ' which is only true on the DEFAULT profile — everyone else's keys
        ' start "pf17559990|", the test never fired, and every episode they
        ' watched was written down as a film. It reached their phone that way
        ' too, filed on the wrong side of their watch history. Three other
        ' places had already worked around it where they found it
        ' (markFinished below, MediaBarEpisodeIndex, and the media-server
        ' watch collector in SyncTask); this is the one that was producing it.
        ' ResumeKeyKind takes the profile prefix off first and is now the only
        ' rule in the app.
        kind = ResumeKeyKind(m.top.resumeKey)
        title = m.top.histTitle
        if title = "" then title = m.top.titleText
        meta = { kind: kind, title: title, url: m.top.streamUrl, at: CreateObject("roDateTime").asSeconds() * 1000& }
        if m.top.subText <> "" then meta.sub = m.top.subText
        if m.top.posterUrl <> "" then meta.poster = m.top.posterUrl
        if m.top.parentId <> "" then meta.parent = m.top.parentId
        SaveHistMeta(m.top.resumeKey, meta)
    end if
end sub

' Write down that this title was watched to the end (GAP D0).
'
' The two callers decide WHETHER something was finished; this only writes it.
' Both of them apply the same 95% rule SaveResume applies when it throws the
' resume point away, so the mark and the deletion can never disagree.
'
' MarkSeen keeps the first date if the title is already marked, so calling
' this on every tick of the save timer through the last 5% of a film costs
' one registry read a time and changes nothing.
sub markFinished()
    key = m.top.resumeKey
    if m.top.isLive or key = "" then return

    ' The kind is read off the BARE key, with the profile prefix taken off
    ' first, because a mark that thinks an episode is a film loses the series
    ' it belongs to and the series is the whole point of the panel that reads
    ' these. This used to strip the prefix inline and explain why saveProgress
    ' above got it wrong; saveProgress is fixed now and both call the same
    ' helper, so the explanation lives with the helper instead.
    parent = ""
    if ResumeKeyIsEpisode(key)
        ' Only a SERIES ref is worth keeping. parentId is "series:<src>~<id>"
        ' for an episode and "movie:<src>~<id>" for a film, where it merely
        ' names the film again — see favTarget, which reads the same field.
        if m.top.parentId.left(7) = "series:" then parent = m.top.parentId
    end if

    MarkSeen(key, parent)
end sub

' ---- What's on now (live only, GAP A1) --------------------------------------
'
' Android draws the current programme's title under the channel name on the
' live overlay (live_player_screen.dart:440 resolves it, :1443 draws it). This
' is that line.
'
' WHY THIS IS A SECOND COPY OF LOGIC THAT ALREADY EXISTS. ChannelDetailScreen
' resolves the same thing (loadEpg/applyXmltv/refreshNowBlock). It is copied
' here rather than pulled out into a shared helper ON PURPOSE: that file is
' being worked on, and a shared file both screens include is a merge collision
' waiting to happen. If the two ever have to agree about more than this, THAT
' is the moment to extract one — not before. What is copied is the SHAPE of
' the answer ({title, startS, stopS}), so an extraction later is mechanical.
'
' WHAT IS DELIBERATELY NOT COPIED:
'   · the synopsis, the progress bar, up-next, the day's listings. One line.
'   · the parental lock check. ChannelDetailScreen holds its listings back for
'     a locked category because that page can be browsed without playing
'     anything. Here the stream is ALREADY PLAYING, which means the opener's
'     gate (playChannel -> parentalOkToPlay, and the same in GuideScreen and
'     LiveTvScreen) already said yes. A title on top of a picture the member
'     is watching leaks nothing the picture doesn't.
'   · GuideScreen's name-alias fallback (EpgAliasLookup). ChannelDetailScreen
'     doesn't use it either, and it lives in GuideMeta.brs, which this
'     component does not include.
'
' THE COST RULE. Resolve ONCE when playback starts; after that the 30-second
' ticker only re-reads the listings already in hand. No request per tick, and
' a retry (three of them, four seconds apart) asks for nothing at all, because
' the key below is unchanged — rapid repeat calls at a provider's panel read
' as credential sharing, and that applies to the API as much as the stream.

' Which channel these listings belong to. A retry or a Refresh press comes back
' through startPlayback with the same key and therefore asks for nothing.
function nowPlayingKey() as string
    ch = m.top.channel
    if ch = invalid or type(ch) <> "roAssociativeArray" then return ""
    sid = ToStr(GetField(ch, "streamId"))
    url = ToStr(GetField(ch, "url"))
    if sid = "" and url = "" then return ""
    return ToStr(GetField(ch, "src")) + "|" + sid + "|" + url
end function

' The channel's own source wins over the active one, the same rule
' ChannelDetailScreen.onChannel applies — a favorite from a second playlist
' must not be looked up against the playlist that happens to be selected.
function nowPlayingProvider() as dynamic
    ch = m.top.channel
    if ch <> invalid and type(ch) = "roAssociativeArray" and ch.doesExist("src")
        p = ProviderForSrcToken(ToStr(ch.src))
        if p <> invalid then return p
    end if
    return ActiveProvider()
end function

sub startNowPlaying()
    if not m.top.isLive
        ' VOD has no programme. Nothing is drawn and nothing moves — the line
        ' is its own node, so the title and the pill above it are untouched.
        stopNowPlaying()
        return
    end if
    key = nowPlayingKey()
    if key <> m.epgKey
        m.epgKey = key
        m.epgListings = []
        m.epgTvgId = invalid
        m.epgFetchedAt = 0
        m.epgHadData = false
        m.epgNowKey = -1
        m.nowLabel.text = ""
        m.nowLabel.visible = false
        m.epgSrcType = ""
        p = nowPlayingProvider()
        if p <> invalid
            if ToStr(p.ptype) = "m3u" then m.epgSrcType = "m3u" else m.epgSrcType = "xt"
        end if
    end if
    ' A deep link or an event feed hands this player a url and nothing else.
    ' There is no channel to look up, so there is no line — and no request.
    if key = "" or m.epgSrcType = ""
        stopNowPlaying()
        return
    end if
    m.epgTimer.control = "start"
    if m.epgFetchedAt = 0 and m.epgTask = invalid then loadNowPlaying()
    drawNowPlaying()
end sub

sub stopNowPlaying()
    m.epgTimer.control = "stop"
    m.nowLabel.text = ""
    m.nowLabel.visible = false
    m.epgNowKey = -1
end sub

' Where the listings come from — the split ChannelDetailScreen makes:
'
'   · M3U    — FREE, and nothing is downloaded from here. The XMLTV guide is
'              already parsed into m.global.xmltvById by whichever screen
'              loaded it (Live TV, the guide grid, the channel page); this
'              finds the channel's tvg-id by url, exactly as applyXmltv does,
'              and reads the cache. If the cache isn't there, there is no
'              line. A player is the WRONG place to start a multi-megabyte
'              guide download: it would be competing with the stream that just
'              started for the same connection.
'   · Xtream — one get_short_epg call, once per channel, the same call the
'              channel page makes. limit=24 rather than its 60: this needs the
'              programme on now and enough after it that the ticker can roll
'              over for hours without asking again, not a day of rows to draw.
sub loadNowPlaying()
    if m.epgSrcType = "m3u"
        readXmltvNow()
        return
    end if
    if m.epgTask <> invalid then return
    p = nowPlayingProvider()
    if p = invalid then return
    ch = m.top.channel
    sid = ""
    if ch <> invalid then sid = ToStr(GetField(ch, "streamId"))
    if sid = "" then return
    ' Stamped BEFORE the answer lands, so a request in flight is never a
    ' reason to start a second one.
    m.epgFetchedAt = CreateObject("roDateTime").asSeconds()
    t = CreateObject("roSGNode", "ApiTask")
    t.url = XtreamApiUrl(p, "get_short_epg") + "&stream_id=" + UrlEncode(sid) + "&limit=24"
    t.observeField("result", "onNowEpg")
    m.epgTask = t
    t.control = "RUN"
end sub

sub onNowEpg(event as object)
    res = event.getData()
    m.epgTask = invalid
    out = []
    if res <> invalid and res.ok = true
        for each e in ToArray(GetField(res.data, "epg_listings"))
            ' Only the three fields this line needs. The channel page also
            ' decodes the synopsis; there is nowhere to put one here, and a
            ' base64 decode per programme is not free.
            out.push({
                title: B64Decode(ToStr(GetField(e, "title")))
                startS: ToInt(GetField(e, "start_timestamp"))
                stopS: ToInt(GetField(e, "stop_timestamp"))
            })
        end for
    end if
    setNowListings(out)
end sub

' The M3U side. The tvg-id is resolved ONCE and remembered: m.global
' .m3uChannels is the merged all-sources playlist and can be thousands of
' rows, so walking it every thirty seconds would be the expensive thing in
' this whole feature. "" means "looked, and this channel carries no tvg-id" —
' also remembered, so it is not looked for again either.
sub readXmltvNow()
    if m.global.xmltvState <> "ready" then return
    if m.epgTvgId = invalid
        ch = m.top.channel
        if ch = invalid then return
        if m.global.m3uChannels.count() = 0 then return
        url = ToStr(GetField(ch, "url"))
        sid = ToStr(GetField(ch, "streamId"))
        tid = ""
        for each c in m.global.m3uChannels
            if (url <> "" and ToStr(c.url) = url) or (url = "" and sid <> "" and ToStr(c.streamId) = sid)
                tid = ToStr(GetField(c, "tvgId"))
                exit for
            end if
        end for
        m.epgTvgId = tid
    end if
    if m.epgTvgId = "" then return
    if not m.global.xmltvById.doesExist(m.epgTvgId) then return
    setNowListings(m.global.xmltvById[m.epgTvgId])
    m.epgFetchedAt = CreateObject("roDateTime").asSeconds()
end sub

' Sort into time order and drop anything undated — and do it on a COPY.
' m.global.xmltvById is shared with the guide grid and the channel page; this
' builds a fresh list of pointers to the same programme objects rather than
' reordering theirs underneath them. Same discipline as normalizeListings.
sub setNowListings(list as object)
    out = []
    for each pgm in list
        if pgm <> invalid and ToInt(GetField(pgm, "startS")) > 0 then out.push(pgm)
    end for
    out.sortBy("startS")
    m.epgListings = out
    ' Remembering that this channel HAS guide data is what stops the refetch
    ' below from running forever on a channel that has none.
    if out.count() > 0 then m.epgHadData = true
    drawNowPlaying()
end sub

' Every 30 seconds: roll the line over. No request unless the window we were
' given has actually run out.
sub onEpgTick()
    if not m.top.isLive then return
    ' M3U only: a re-read of the in-memory cache costs nothing and picks up a
    ' guide that finished downloading after this player opened.
    if m.epgSrcType = "m3u" and m.epgFetchedAt = 0 then readXmltvNow()
    drawNowPlaying()

    ' The one case that may ask again: an Xtream channel whose listings we
    ' HAVE, that we have now watched past the end of. Capped at one request
    ' every fifteen minutes, and never asked at all for a channel that came
    ' back empty the first time.
    if m.epgSrcType <> "xt" then return
    if not m.epgHadData or m.epgTask <> invalid then return
    now = CreateObject("roDateTime").asSeconds()
    n = m.epgListings.count()
    if n > 0 and ToInt(m.epgListings[n - 1].stopS) > now then return
    if now - m.epgFetchedAt < 900 then return
    KLog("player", "now playing: listings ran out — asking the panel again")
    loadNowPlaying()
end sub

' Draw whatever is on air. Nothing on air (or no guide data at all) means no
' line: the label is hidden, and the channel name and LIVE pill above it never
' move, so the overlay looks exactly as it did before this existed.
sub drawNowPlaying()
    if not m.top.isLive
        m.nowLabel.visible = false
        return
    end if
    now = CreateObject("roDateTime").asSeconds()
    title = ""
    startS = 0
    for each pgm in m.epgListings
        if ToInt(pgm.startS) <= now and ToInt(pgm.stopS) > now
            title = ToStr(pgm.title)
            startS = ToInt(pgm.startS)
            exit for
        end if
    end for
    ' Only touch the node when the answer actually changed — this runs twice a
    ' minute for as long as the channel is on, and a Label assignment is a
    ' render-thread job even when the text is identical.
    if startS = m.epgNowKey then return
    m.epgNowKey = startS
    if title = ""
        m.nowLabel.text = ""
        m.nowLabel.visible = false
        return
    end if
    m.nowLabel.text = title
    m.nowLabel.visible = true
    KLog("player", "now playing: " + title)
end sub

' ---- Progress bar (VOD) -----------------------------------------------------

sub onPosition()
    if m.top.isLive then return
    ' While scrubbing, the preview owns the bar — don't fight it with the
    ' real position (which hasn't jumped yet).
    if not m.scrubbing then drawSeek(m.video.position)
    ' Remember the last position the player actually reported. The "finished"
    ' state below cannot be trusted on its own — a stream that is cut short
    ' reports "finished" too, and marking THAT as watched would hide a title
    ' the member never got to the end of. This is what it checks instead.
    if m.video.duration > 0
        m.lastPosS = m.video.position
        m.lastDurS = m.video.duration
    end if
    ' The record of what this box did with the fetched file, once per reopen.
    ' Nothing is chosen here any more — Roku renders the file off the content
    ' node and never lists it as a track, so there is nothing to pick up. This
    ' is purely the measurement, armed by restartForSubtitle and printed the
    ' first time the reopened stream has a track list to show.
    if m.extSubLogged <> true and m.video.availableSubtitleTracks <> invalid
        if m.video.availableSubtitleTracks.count() > 0
            logSubTracks("the reopened stream's own tracks, with the fetched subtitle hung on the content node")
        end if
    end if
    ' The member swapped a fetched subtitle for one of the stream's own and
    ' the reopen has just handed its track list back. Selected by NAME, and
    ' the list is retaken at the same moment so the Subtitles menu and
    ' m.ccSel agree with what the player is actually holding.
    if m.wantOwnTrack <> "" and m.video.availableSubtitleTracks <> invalid
        if m.video.availableSubtitleTracks.count() > 0
            m.subTracks = m.video.availableSubtitleTracks
            m.ccSel = 0
            for i = 0 to m.subTracks.count() - 1
                if ToStr(m.subTracks[i].TrackName) = m.wantOwnTrack
                    m.ccSel = i + 1
                    exit for
                end if
            end for
            m.video.globalCaptionMode = "On"
            m.video.subtitleTrack = m.wantOwnTrack
            KLog("subs", "the stream reopened without the downloaded file and its own track '" + m.wantOwnTrack + "' is on")
            m.wantOwnTrack = ""
            m.status.visible = false
            redrawButtons()
        end if
    end if
    ' First time captions become available, remember the tracks — and if
    ' Captions/Subtitles auto-on is set, pick the preferred-language track
    ' (VOD tracks only show up once playback is under way).
    if m.subTracks.count() = 0 and m.video.availableSubtitleTracks <> invalid
        m.subTracks = m.video.availableSubtitleTracks
        ' NOT over the top of a subtitle the member fetched themselves. They
        ' picked that one on purpose; auto-on choosing one of the stream's
        ' own tracks a second later would put two sets of words on the
        ' picture and read as the app changing its mind.
        if m.extSubOn then return
        if m.subTracks.count() > 0 and m.ccSel = 0 and GetPrefBool("pref_captions_auto", false)
            pick = 0
            pref = LCase(PreferredCaptionLang())
            for i = 0 to m.subTracks.count() - 1
                lang = LCase(ToStr(m.subTracks[i].Language))
                if lang = pref or LangName(lang) = LangName(pref)
                    pick = i
                    exit for
                end if
            end for
            m.ccSel = pick + 1
            m.video.globalCaptionMode = "On"
            m.video.subtitleTrack = m.subTracks[pick].TrackName
            redrawButtons()
        end if
    end if
end sub

' Paint the seek bar for an arbitrary position (real or preview).
sub drawSeek(posS as integer)
    dur = m.video.duration
    if dur <= 0 then return
    if posS < 0 then posS = 0
    if posS > dur then posS = dur
    frac = posS / dur
    fillW = Int(m.trackW * frac)
    m.progFill.width = fillW
    drawBuffer(posS, dur)
    ' TWO readings flanking the bar — elapsed at its far left, total at its
    ' far right. Android's [elapsed][slider][duration] Row. This replaced the
    ' combined "6:30 / 15:24" the owner originally asked for; he has now seen
    ' both on a television and picked this one (2026-08-27). Both are written
    ' on every draw, and the total is shown here rather than left to a
    ' visible="false" in the XML — a duration only becomes known once the
    ' stream reports one, and drawSeek has already returned above when it has
    ' not.
    m.timeLabel.text = clockDuration(posS)
    m.durLabel.text = clockDuration(dur)
    m.durLabel.visible = true
    ' "Ends at 8:42 PM" only has to move when the answer moves. A minute timer
    ' does the ordinary drift; this catches the one thing a minute timer would
    ' be a minute late on — a SEEK, which changes what is left instantly. Two
    ' seconds of slack, because ordinary playback only ever walks it down by
    ' one per position report and must not trigger this.
    remainNow = dur - posS
    if remainNow < 0 then remainNow = 0
    if Abs(remainNow - m.endRemain) > 2 then refreshEndTime()
    ' Focused/scrubbing dot is bigger + orange, like a grabbed scrubber.
    cy = m.trackY + Int(m.trackH / 2)
    if m.focusArea = "seekbar" or m.scrubbing
        m.progKnob.width = 32
        m.progKnob.height = 32
        m.progKnob.translation = [m.trackX + fillW - 16, cy - 16]
        m.progKnob.blendColor = m.theme.focusHighlight
    else
        m.progKnob.width = 22
        m.progKnob.height = 22
        m.progKnob.translation = [m.trackX + fillW - 11, cy - 11]
        m.progKnob.blendColor = m.theme.textPrimary
    end if
end sub

' The buffered-ahead segment, and the honest limits of it.
'
' Roku's Video node has NO "buffered position" field. What it has is:
'   · bufferingStatus — an assocarray that only carries anything WHILE the
'     player is buffering, and what it carries is a percentage of the
'     prebuffer, not a point on the timeline. Useless for this.
'   · streamingSegment / downloadedSegment — the segment being fetched and the
'     one most recently fetched, each with a segStartTime in milliseconds.
'
' downloadedSegment.segStartTime IS a real buffered-ahead mark, for a real
' segmented stream: it is a point past the playhead that the player already
' has. So the grey is drawn from that and from nothing else. On a progressive
' file — a plain .mkv or .mp4, which most Xtream VOD is — there are no
' segments, the field stays empty, and the grey never appears at all. That is
' the correct outcome: no number, no bar. Nothing here invents a buffer.
sub drawBuffer(posS as integer, dur as integer)
    aheadS = -1
    if m.video.hasField("downloadedSegment")
        seg = m.video.downloadedSegment
        if seg <> invalid and type(seg) = "roAssociativeArray"
            st = GetField(seg, "segStartTime")
            if st <> invalid then aheadS = Int(ToInt(st) / 1000)
        end if
    end if
    ' Anything behind the playhead, past the end, or absent is not a buffer.
    if aheadS <= posS or aheadS > dur
        m.progBuffer.width = 0
        return
    end if
    m.progBuffer.width = Int(m.trackW * (aheadS / dur))
end sub

function clockDuration(secs as integer) as string
    if secs < 0 then secs = 0
    hrs = Int(secs / 3600)
    mins = Int((secs mod 3600) / 60)
    s = secs mod 60
    mm = mins.toStr()
    if mins < 10 and hrs > 0 then mm = "0" + mm
    ss = s.toStr()
    if s < 10 then ss = "0" + ss
    if hrs > 0 then return hrs.toStr() + ":" + mm + ":" + ss
    return mins.toStr() + ":" + ss
end function

' ---- "Ends at 8:42 PM" ------------------------------------------------------
'
' The wall-clock time this film will finish at, drawn at the end of the seek
' bar. The rule is a CROSS-PLATFORM CONTRACT, not a local choice — Android is
' building the same label the same night and the two have to agree to the
' minute. It is written down in
'
'     Wiki/Sync/Sync - End Time Contract (Android + Roku).md
'
' and the five points it fixes are each implemented below, marked (1)..(5).
' If any of this is changed, change the note too or the platforms drift.
sub refreshEndTime()
    ' (5, second half) LIVE NEVER GETS THIS. A live channel has no end of its
    ' own; the programme's end time comes from the guide and is a different
    ' thing (it is already on nowLabel).
    if m.top.isLive
        m.endLabel.visible = false
        return
    end if
    dur = m.video.duration
    ' Nothing to show: hide it completely rather than print a placeholder. A
    ' duration of 0 is common on provider VOD and the answer is genuinely
    ' unknowable, so the label goes away.
    if dur <= 0
        m.endLabel.visible = false
        m.endRemain = -1
        return
    end if
    ' (2) Recomputed from the LIVE position every time, never cached and never
    ' derived from where playback started. While the member is dragging the
    ' scrubber the preview position is the one they mean.
    posS = m.video.position
    if m.scrubbing then posS = m.scrubPos
    remain = dur - posS
    if remain < 0 then remain = 0
    m.endRemain = remain

    ' (5) The DEVICE'S OWN LOCAL CLOCK. roDateTime marks UTC; ToLocalTime
    ' shifts it to whatever the box is set to, including the daylight-saving
    ' offset in force today.
    dt = CreateObject("roDateTime")
    dt.Mark()
    dt.ToLocalTime()
    ' (1) NEAREST minute, not down. The +30 is the whole of that rule: 8:41:40
    ' has to read 8:42, and a platform that floors here disagrees with one that
    ' rounds on about half of all films. Worked in seconds-since-local-midnight
    ' so the `mod 1440` wraps a film that finishes after midnight, and so no
    ' epoch arithmetic is involved.
    ' (3) NOTHING FREEZES THIS WHILE PAUSED. "now" moves whether or not the
    ' picture does, so a film paused for ten minutes ends ten minutes later —
    ' which is correct, and is why the minute timer keeps running through a
    ' pause instead of being stopped with playback.
    daySecs = dt.GetHours() * 3600 + dt.GetMinutes() * 60 + dt.GetSeconds()
    endMins = Int((daySecs + remain + 30) / 60) mod 1440
    hh = Int(endMins / 60)
    mm = endMins mod 60
    mmTxt = mm.toStr()
    if mm < 10 then mmTxt = "0" + mmTxt

    ' (4) FOLLOW THE BOX'S OWN 12/24-HOUR SETTING. Neither is hard-coded.
    if ClockIs24Hour()
        hhTxt = hh.toStr()
        if hh < 10 then hhTxt = "0" + hhTxt
        m.endLabel.text = "Ends at " + hhTxt + ":" + mmTxt
    else
        ampm = " AM"
        h12 = hh
        if h12 >= 12
            ampm = " PM"
            h12 = h12 - 12
        end if
        if h12 = 0 then h12 = 12
        ' Mason's own example is 12-hour with a space: "Ends at 8:42 PM".
        m.endLabel.text = "Ends at " + h12.toStr() + ":" + mmTxt + ampm
    end if
    m.endLabel.visible = true
end sub

' Is this box set to a 24-hour clock? roDeviceInfo.GetClockFormat answers "12h"
' or "24h" and has done since Roku OS 8.1 (2018) — older than the analytics
' component library this app's manifest already requires, so every box that can
' run the app at all has it. Anything other than "24h", including a blank
' answer, falls back to 12-hour, which is the format Mason asked for by name.
' NOT VERIFIED ON HARDWARE — this is the one call in here that has never been
' run on a television.
function ClockIs24Hour() as boolean
    di = CreateObject("roDeviceInfo")
    if di = invalid then return false
    return LCase(ToStr(di.GetClockFormat())) = "24h"
end function

' ---- Manual scrub (D-pad Left/Right on the seek bar) ------------------------
' Constant step per press. The remote auto-repeats while held, so holding
' keeps the dot sliding steadily; releasing settles and commits the jump.
sub manualScrub(dir as integer)
    if m.top.isLive then return
    stopTrick()
    dur = m.video.duration
    if dur <= 0 then return
    if not m.scrubbing
        m.scrubbing = true
        m.scrubPos = m.video.position
    end if
    m.scrubPos = m.scrubPos + dir * 8   ' steady 8s per repeat
    if m.scrubPos < 0 then m.scrubPos = 0
    if m.scrubPos > dur - 2 then m.scrubPos = dur - 2
    drawSeek(m.scrubPos)
    showControls()
    m.seekCommitTimer.control = "stop"
    m.seekCommitTimer.control = "start"
end sub

sub commitScrub()
    if not m.scrubbing then return
    m.video.seek = m.scrubPos
    m.scrubbing = false
    drawSeek(m.scrubPos)
end sub

' Held-key repeat for the scrubber.
sub onScrubHoldTick()
    if m.scrubHoldDir <> 0 and m.focusArea = "seekbar" then manualScrub(m.scrubHoldDir)
end sub

sub startScrubHold(dir as integer)
    if m.scrubHoldDir = dir then return ' already holding this way (OS repeat)
    m.scrubHoldDir = dir
    manualScrub(dir)
    m.scrubHoldTimer.control = "start"
end sub

sub stopScrubHold()
    if m.scrubHoldDir = 0 then return
    m.scrubHoldDir = 0
    m.scrubHoldTimer.control = "stop"
    commitScrub()
end sub

' ---- << / >> trickplay mode -------------------------------------------------
' Pressing >> starts continuous fast-forward; the position keeps advancing on
' its own. Press >> again to go 2x, again 3x (<< reverses). Press Play/OK to
' land there and resume. Mirrors the Roku system players.
sub startTrick(dir as integer)
    if m.top.isLive then return
    dur = m.video.duration
    if dur <= 0 then return
    if not m.tricking
        m.tricking = true
        m.trickDir = dir
        m.trickTier = 1
        m.scrubPos = m.video.position
        m.video.control = "pause"   ' freeze real playback while scanning
        m.trickTimer.control = "start"
    else if m.trickDir = dir
        if m.trickTier < 3 then m.trickTier = m.trickTier + 1
    else
        m.trickDir = dir            ' flipped direction — back to 1x
        m.trickTier = 1
    end if
    updateSpeedChip()
    showControls()
end sub

' Each tick advances the preview at the current tier.
sub onTrickTick()
    if not m.tricking then return
    dur = m.video.duration
    ' 8 / 22 / 40s every 0.25s tick — 2x and 3x noticeably quicker.
    perTick = 8
    if m.trickTier = 2 then perTick = 22
    if m.trickTier = 3 then perTick = 40
    m.scrubPos = m.scrubPos + m.trickDir * perTick
    if m.scrubPos < 0
        m.scrubPos = 0
        commitTrick()
        return
    end if
    if m.scrubPos > dur - 2
        m.scrubPos = dur - 2
        commitTrick()
        return
    end if
    drawSeek(m.scrubPos)
    updateSpeedChip()
    showControls()
end sub

sub updateSpeedChip()
    if not m.tricking
        m.speedLabel.visible = false
        return
    end if
    ' Fixed direction marker + tier — no stacking arrows.
    if m.trickDir < 0 then marks = "<<" else marks = ">>"
    m.speedLabel.text = marks + "  " + m.trickTier.toStr() + "x"
    m.speedLabel.visible = true
end sub

' Land at the scanned spot and resume.
sub commitTrick()
    if not m.tricking then return
    m.tricking = false
    m.trickTimer.control = "stop"
    m.speedLabel.visible = false
    m.video.seek = m.scrubPos
    m.video.control = "resume"
    drawSeek(m.scrubPos)
    redrawButtons()
    showControls()
end sub

sub stopTrick()
    if not m.tricking then return
    commitTrick()
end sub

' Instant-replay button: hop back 15s and keep playing.
sub seekToStart()
    if m.top.isLive then return
    stopTrick()
    target = m.video.position - 15
    if target < 0 then target = 0
    m.video.seek = target
    showControls()
end sub

' ---- Captions picker --------------------------------------------------------

' Live: captions are the embedded 608/708 kind riding inside the video
' signal (same fix as Android) — a simple On/Off. Turning them on needs
' TWO things on Roku: the caption renderer (globalCaptionMode) AND the
' embedded caption track selected (eia608/1) — the mode alone renders
' nothing, which is why the first cut didn't work.
' VOD: Off plus the title's real subtitle tracks (mkv etc.).
' Both the live CC menu and the VOD subtitle menu use the same scrollable
' picker overlay; the current selection carries an "Active" tag (a plain
' Dialog's bullet buttons gave no clue which one was on).
sub openCaptions()
    if m.top.isLive
        ' No search rows on live — a channel has no title to look one up by,
        ' and the captions riding inside the picture are the only ones there
        ' can be. Written here rather than left standing so the index shift
        ' in onSubPickerClosed cannot be applied to this list.
        m.subPickerHasSearch = false
        labels = ["Off", "On"]
        marks = ["", ""]
        cur = 0
        if m.ccSel > 0 then cur = 1
        marks[cur] = "Active"
        pk = m.top.getScene().createChild("SubtitlePickerScreen")
        pk.titleText = "Closed Captions"
        ' labels LAST — setting it builds the list, so marks/startIndex
        ' must already be there.
        pk.marks = marks
        pk.startIndex = cur
        pk.labels = labels
        pk.observeField("closed", "onSubPickerClosed")
        m.subPicker = pk
        pk.setFocus(true)
        return
    end if
    ' VOD: big titles carry 20+ tracks — the list scrolls. Labels are real
    ' language names ("Spanish 2"), not bare ISO codes.
    tracks = m.video.availableSubtitleTracks
    if tracks = invalid then tracks = []
    m.subTracks = tracks
    labels = ["Off"]
    ' ---- THE FETCHED SUBTITLE'S OWN ROW -----------------------------------
    ' It is NOT one of the stream's tracks and never appears in the list
    ' above (measured — see the block above attachExternalSub), so if this
    ' row were not drawn here there would be no way to see that it is on and
    ' no way to turn it off. Directly under Off, which makes on/off one press
    ' apart, and above the stream's own tracks because it is the row the
    ' member just chose.
    extRows = subsExtRowCount()
    if extRows > 0 then labels.push(subsExtRowLabel())
    seen = {}
    for each t in tracks
        raw = t.Language
        if raw = invalid or raw = "" then raw = t.Name
        if raw = invalid or raw = "" then raw = "Track"
        nameNow = LangName(ToStr(raw))
        if seen.doesExist(nameNow)
            seen[nameNow] = seen[nameNow] + 1
            nameNow = nameNow + " " + seen[nameNow].toStr()
        else
            seen[nameNow] = 1
        end if
        ' Every track gets its own language name, including one that somehow
        ' IS the fetched file — the fetched file has a row of its own now, so
        ' borrowing its label down here would only draw the same thing twice.
        labels.push(nameNow)
    end for
    ' ---- The two search rows, at the top (JB-7) ---------------------------
    ' Order is Mason's: OpenSubtitles first, Subdl under it. The member's
    ' current track keeps the highlight, so the search rows are there to be
    ' arrowed UP to rather than sitting under the cursor.
    m.subPickerHasSearch = subsSearchOk()
    if m.subPickerHasSearch
        head = ["Search " + AddOnLabel("opensubtitles"), "Search " + AddOnLabel("subdl")]
        for each l in labels
            head.push(l)
        end for
        labels = head
    end if
    marks = []
    for i = 0 to labels.count() - 1
        marks.push("")
    end for
    ' WHICH ROW IS ACTIVE. Written BOTH ways rather than only in the branch
    ' that has something on: this list is rebuilt on every open and a stale
    ' mark is how "Off — Active" ended up beside a subtitle the member was
    ' reading at the time.
    if m.extSubOn and extRows > 0
        ccRow = 1
    else if m.ccSel > 0
        ccRow = m.ccSel + extRows
    else
        ccRow = 0
    end if
    if m.subPickerHasSearch
        ccRow = ccRow + subsSearchRowCount()
        ' The OpenSubtitles row says plainly when there is nothing behind
        ' it. Set BOTH ways — an empty string when they ARE signed in —
        ' because this list is rebuilt on every open and a stale "Not signed
        ' in" beside a working account is worse than no line at all.
        if subsAccountToken() = ""
            marks[0] = "Not signed in"
        else
            marks[0] = ""
        end if
        marks[1] = ""
    end if
    if ccRow >= 0 and ccRow < marks.count() then marks[ccRow] = "Active"
    pk = m.top.getScene().createChild("SubtitlePickerScreen")
    pk.titleText = "Subtitles"
    ' A title with no tracks used to get a fake extra row saying so, which a
    ' row cannot actually fit — the row title is one un-wrapped line and the
    ' sentence was clipped on the device. It is a note now.
    '
    ' COUNTED OFF THE TRACKS, not off labels. labels now carries two search
    ' rows on top, so "labels.count() = 1" stopped being the test for "this
    ' title has nothing of its own" the moment those rows landed.
    if tracks.count() = 0
        if extRows > 0
            pk.noteText = "This title doesn't carry any subtitle tracks of its own — the one listed here is the file you downloaded."
        else if m.subPickerHasSearch
            pk.noteText = "This title doesn't carry any subtitle tracks of its own. The two rows above look for one online."
        else
            pk.noteText = "This title doesn't carry any subtitle tracks. Live channels use the captions that ride inside the picture instead."
        end if
    end if
    ' labels LAST — setting it builds the list.
    pk.marks = marks
    if ccRow >= 0 and ccRow < labels.count() then pk.startIndex = ccRow else pk.startIndex = 0
    pk.labels = labels
    pk.observeField("closed", "onSubPickerClosed")
    m.subPicker = pk
    pk.setFocus(true)
end sub

sub onSubPickerClosed()
    if m.subPicker = invalid then return
    wanted = ""
    if m.subPicker.picked = true
        idx = m.subPicker.chosen
        ' THE ROWS ABOVE THE STREAM'S OWN TRACKS SHIFT THE PICK, and they are
        ' taken back off here and in openCaptions and nowhere else: the two
        ' search rows on top, then the fetched subtitle's own row under Off.
        ' m.ccSel still means exactly what it always meant (0 = Off, n = the
        ' stream's own track n-1), which is what keeps this change out of the
        ' rest of the file.
        if m.subPickerHasSearch = true
            if idx = 0
                wanted = ""             ' Search OpenSubtitles
            else if idx = 1
                wanted = "subdl"        ' Search Subdl
            end if
            if idx <= 1
                ' Opened AFTER this picker is torn down and focus is back —
                ' two screens claiming focus at once leaves a dead remote.
                m.subPicker.unobserveField("closed")
                m.top.getScene().removeChild(m.subPicker)
                m.subPicker = invalid
                m.top.setFocus(true)
                openSubsSearch(wanted)
                return
            end if
            idx = idx - subsSearchRowCount()
        end if
        extRows = subsExtRowCount()
        if idx = 0
            m.ccSel = 0
            ' The file stays hung on the content node — see clearExternalSub.
            ' The renderer going off hides it, and leaving it there is what
            ' makes turning it back on free.
            clearExternalSub()
            m.video.globalCaptionMode = "Off"
            m.video.subtitleTrack = ""
            ' Off IS a choice, so it replaces the remembered one. The file
            ' stays in the cache — turning subtitles off must never cost a
            ' member another download if they change their mind, and its row
            ' stays in this list so they can.
            forgetSubPick()
        else if m.top.isLive
            captionsOnLive()
        else if extRows > 0 and idx = 1
            ' The fetched subtitle's own row.
            chooseExternalSub()
        else if idx - 1 - extRows >= 0 and idx - 1 - extRows < m.subTracks.count()
            trackAt = idx - 1 - extRows
            wantName = ToStr(m.subTracks[trackAt].TrackName)
            ' One of the stream's OWN tracks, which is not the fetched file —
            ' so the fetched file comes off the picture and stops being what
            ' comes back next time.
            '
            ' MEASURED ON THE STICK, 2026-09-19, and it is why this branch is
            ' two branches. Taking the two fields back off a node the Video
            ' is PLAYING does not take the subtitle off: it ends the stream.
            ' The picture went black, the log said "took the downloaded
            ' subtitle off the content node without reopening the stream",
            ' and query/media-player answered state="close". The same run
            ' showed why picking the track on its own cannot work either —
            ' while a sideloaded track is declared, availableSubtitleTracks
            ' holds ONLY that track (`<dev_4_0>https://dl.subdl.com/...`),
            ' so the stream's own mkv/3..mkv/10 are not there to select.
            ' A reopen is the only path, and it costs the one connection.
            if m.extSubOn
                m.ccSel = trackAt + 1
                forgetSubPick()
                restartForOwnTrack(wantName)
            else
                m.ccSel = trackAt + 1
                m.video.globalCaptionMode = "On"
                m.video.subtitleTrack = wantName
                forgetSubPick()
            end if
        end if
    end if
    m.top.getScene().removeChild(m.subPicker)
    m.subPicker = invalid
    redrawButtons()
    m.top.setFocus(true)
    showControls()
end sub

' The embedded-CC track name: prefer whatever eia608 track the stream
' reports, else the platform's conventional "eia608/1".
function embeddedCcTrack() as string
    tracks = m.video.availableSubtitleTracks
    if tracks <> invalid
        for each t in tracks
            tn = ToStr(t.TrackName)
            if Instr(1, LCase(tn), "eia608") > 0 then return tn
        end for
    end if
    return "eia608/1"
end function

sub captionsOnLive()
    m.ccSel = 1
    m.video.globalCaptionMode = "On"
    m.video.subtitleTrack = embeddedCcTrack()
end sub

' ---- Subtitle search (JB-7) --------------------------------------------------
'
' Two rows at the top of the Subtitles menu on a film or an episode:
'
'     Search OpenSubtitles
'     Search Subdl
'     Off
'     <the tracks that ride inside the file>
'
' Both open the same picker and differ only in which source the relay is
' asked for. They are NOT offered on live: a live channel has no title to
' search for, and the captions that ride inside the picture are the only
' ones there can be.
'
' SUBDL IS NOT AN ADD-ON AND HAS NO SIGN-IN, so its row is always there.
' Mason, 2026-09-16: "do not make people sign in with an api key", and then
' "if people aren't logging into their own subdl account, it should be baked
' in and not actually listed in Add-ons." OpenSubtitles is the opposite — it
' is the member's own account — so when they have not signed in, the row says
' so and points at Settings rather than putting a password box in front of a
' television.
'
' WHAT THIS COSTS, because that is the question this house asks first:
'   · one search per press of one row, never a request per result;
'   · nothing at all for a subtitle already on the box, which is why the
'     choice is remembered and the file is cached;
'   · ONE extra connection to the provider, at most, and only when Roku
'     turns out not to accept a subtitle file attached to a stream that is
'     already playing — see attachExternalSub. Every other path adds none.

' How many rows the search adds to the top of the VOD list. The list index a
' member picks is shifted by this, and m.ccSel is NOT: keeping m.ccSel
' meaning exactly what it always meant (0 = Off, n = track n-1) is what
' stops this change reaching the rest of the file.
function subsSearchRowCount() as integer
    return 2
end function

' Is the search worth offering at all? Films and episodes only.
function subsSearchOk() as boolean
    return not m.top.isLive
end function

' The member's own OpenSubtitles token, which is THEIRS: never drawn, never
' logged, never put in a URL. It goes into the picker's `bearer` field and
' from there into an Authorization header, and nowhere else.
'
' Guarded, for the same reason controlsHideSeconds is: AddOnAccount is in
' Store.brs, which this component's XML names, but a component calling a
' function it has not been given does not fail politely — it kills the
' render thread and leaves the member looking at a stopped picture. "Not
' signed in" is a state this screen already draws properly, so that is what
' any fault here looks like.
function subsAccountToken() as string
    tok = ""
    try
        acct = AddOnAccount("opensubtitles")
        if acct <> invalid then tok = ToStr(GetField(acct, "token"))
    catch e
        tok = ""
    end try
    return tok
end function

' The languages to ask for, the member's own preference first. A second entry
' of English is added behind it because a single-language search on a small
' title comes back empty far more often than it comes back wrong, and a
' member who set Spanish still gets Spanish at the top of the list — the
' picker sorts on the same preference.
' THE RELAY PASSES `languages` STRAIGHT THROUGH TO OPENSUBTITLES, AND
' OPENSUBTITLES ONLY SPEAKS ISO 639-1 — two letters. This app stores the
' member's preferred caption language as a THREE-letter code (Roku's own
' track lists are 639.2B, which is why subLang3 exists), and until
' 2026-09-19 that code went out as it was.
'
' Measured that day on the office stick, and it means the OpenSubtitles half
' of this feature had never worked on Roku:
'     ...&query=2%20Fast%202%20Furious&year=2003&languages=eng  ->  total 0
'     the same address with languages=en                        ->  total 650
' Every OpenSubtitles search a member ever ran answered "No subtitles for
' this title on OpenSubtitles right now", which reads like the service has
' none rather than like a bug. **Subdl hid it**: the relay upper-cases the
' list for Subdl and Subdl matched "ENG" anyway, so the half of the feature
' that was tested worked and the half that was not looked empty.
function subsLangs() as string
    pref = subsLang2(PreferredCaptionLang())
    if pref = "" then pref = "en"
    if pref = "en" then return "en"
    return pref + ",en"
end function

' 639.2B (or 639-2/T, or something already two letters) down to 639-1, which
' is what both services want on the wire. The reverse of subLang3 and built
' from the same list, so the two cannot drift apart silently: anything not in
' it falls back to English rather than sending a code the service will answer
' nothing for.
function subsLang2(code as string) as string
    c = LCase(ToStr(code)).trim()
    if c = "" then return "en"
    ' "pt-br" is a real OpenSubtitles language and stays whole; a three-letter
    ' code with a region on it is not, so only the region-less part is mapped.
    at = Instr(1, c, "_")
    if at > 1 then c = Left(c, at - 1) + "-" + Mid(c, at + 1)
    if Len(c) = 2 then return c
    if Len(c) > 3 and Mid(c, 3, 1) = "-" then return c
    two = {
        eng: "en", spa: "es", fre: "fr", fra: "fr", ger: "de", deu: "de"
        ita: "it", por: "pt", dut: "nl", nld: "nl", nor: "no", swe: "sv"
        dan: "da", fin: "fi", pol: "pl", rus: "ru", ukr: "uk", rum: "ro"
        ron: "ro", hun: "hu", cze: "cs", ces: "cs", slo: "sk", slk: "sk"
        slv: "sl", gre: "el", ell: "el", tur: "tr", ara: "ar", heb: "he"
        hin: "hi", tha: "th", vie: "vi", chi: "zh", zho: "zh", jpn: "ja"
        kor: "ko", ind: "id", may: "ms", msa: "ms", bul: "bg", hrv: "hr"
        srp: "sr", est: "et", lav: "lv", lit: "lt", cat: "ca", glg: "gl"
        baq: "eu", eus: "eu", per: "fa", fas: "fa", urd: "ur", ben: "bn"
        tam: "ta", tel: "te"
    }
    if two.doesExist(c) then return two[c]
    return "en"
end function

' The title's name, with an episode code taken back off it. playEpisodeAt
' rewrites titleText to "<show> - S01E03", so the raw field is the wrong
' thing to search for; histTitle is the show's own name on both openers that
' set it.
function subsTitleName() as string
    nm = ToStr(m.top.histTitle)
    if nm = "" then nm = ToStr(m.top.titleText)
    nm = nm.trim()
    code = ToStr(m.top.subText).trim()
    if code <> "" and Len(nm) > Len(code) and Right(nm, Len(code)) = code
        nm = Left(nm, Len(nm) - Len(code)).trim()
        if Right(nm, 1) = "-" then nm = Left(nm, Len(nm) - 1).trim()
    end if
    return nm
end function

' Season and episode out of the "S01E03" this player is already holding.
' READ, NOT FETCHED: the episode list behind the prev/next buttons costs a
' get_series_info, and firing one just to label a subtitle search would be a
' request nobody asked for on a stream that has only just started.
function subsEpisodeNumbers() as dynamic
    code = UCase(ToStr(m.top.subText).trim())
    if Len(code) < 4 then return invalid
    if Left(code, 1) <> "S" then return invalid
    at = Instr(2, code, "E")
    if at <= 2 then return invalid
    sn = ToInt(Mid(code, 2, at - 2))
    en = ToInt(Mid(code, at + 1))
    if sn <= 0 or en <= 0 then return invalid
    return { season: sn, episode: en }
end function

' What the member is told we are searching for, so they can see whether the
' match is the right title before they pick anything.
function subsMatchText() as string
    nm = subsTitleName()
    code = ToStr(m.top.subText).trim()
    if code <> "" then return nm + " " + code
    yr = ToStr(m.top.titleYear).trim()
    ' NOT TWICE. Plenty of panels put the year in the title already, and the
    ' office stick drew "The Odyssey (2026) (2026)" across the top of the
    ' picker on 2026-09-17. If the name already ends in that year, it is
    ' saying it for both of us.
    if yr <> "" and Instr(1, nm, "(" + yr + ")") = 0 then return nm + " (" + yr + ")"
    return nm
end function

' THE ID FIRST, THE NAME ONLY AS A FALLBACK. An id is an exact answer; a name
' is a guess, and the relay's own note records a film's id once coming back
' with ten Dexter episodes. The type is never left off either — films and
' episodes are numbered separately upstream.
'
' THE ID BRANCH IS LIVE. This comment used to say the opposite — that no
' opener set tmdbId or parentTmdbId and the name branch was always taken — and
' it was stale: MovieDetailScreen sets tmdbId and titleYear, SeriesDetailScreen
' sets parentTmdbId and titleYear, both including media-server titles. The name
' branch is still reached, and still has to work, for a panel that sends no id.
function buildSubsSearchUrl(src as string) as string
    langs = subsLangs()
    nm = subsTitleName()
    nums = subsEpisodeNumbers()
    if nums <> invalid
        parent = ToStr(m.top.parentTmdbId).trim()
        if parent <> "" and parent <> "0"
            return SubsSearchUrlEpisode(parent, nums.season, nums.episode, langs, src)
        end if
        if nm = "" then return ""
        ' No id for the show, so the episode code goes into the query. It is
        ' the only way a name search can name one episode rather than the
        ' whole series; if the relay's name gate turns out to refuse it, the
        ' member sees "no subtitles" and this is the line to change.
        return SubsSearchUrlQuery(nm + " " + ToStr(m.top.subText).trim(), "", langs, src)
    end if
    tmdb = ToStr(m.top.tmdbId).trim()
    if tmdb <> "" and tmdb <> "0" then return SubsSearchUrlMovie(tmdb, langs, src)
    if nm = "" then return ""
    return SubsSearchUrlQuery(nm, ToStr(m.top.titleYear).trim(), langs, src)
end function

sub openSubsSearch(src as string)
    if not subsSearchOk() then return
    ' ---- THE MEMORY GATE --------------------------------------------------
    ' The device's OWN reading, the same one the media bar drops its artwork
    ' on. Texture memory is what kills this app — five crash reports — and a
    ' search opens a panel, a scrolling list and a file download on top of a
    ' stream that is already playing. On a box that is genuinely close to
    ' the edge that is not worth risking the film for, so nothing new is
    ' fetched and the member is told, in words, what they have got instead.
    if MediaBarMemoryTight()
        ' Only the FREE one is offered here. Putting a subtitle back on a
        ' stream that did not open with it means reopening the stream, and a
        ' box this close to the edge is the last place to spend a connection
        ' and a fresh decoder on something the member did not ask for twice.
        if m.extSubPath <> "" and m.extSubLoaded
            chooseExternalSub()
            m.status.text = "This box is low on memory, so nothing new was fetched. The subtitle you already had is back on."
        else
            m.status.text = "This box is low on memory right now, so searching for subtitles could stop the film. Go back and open it again to try."
        end if
        m.status.visible = true
        m.statusTransient = true
        showControls()
        return
    end if
    tok = ""
    if src <> "subdl"
        tok = subsAccountToken()
        if tok = ""
            ' Never a sign-in box here. Mason's rule is that members use
            ' their own logins, and the place to do that is the add-on's own
            ' page — putting a second password box inside the player would
            ' be a second thing to keep in step with it.
            m.status.text = "Sign in to OpenSubtitles first: go to Settings, then Add-ons."
            m.status.visible = true
            showControls()
            return
        end if
    end if
    url = buildSubsSearchUrl(src)
    pk = m.top.getScene().createChild("SubsSearchScreen")
    if pk = invalid
        m.status.text = "Subtitle search isn't available on this build."
        m.status.visible = true
        showControls()
        return
    end if
    pk.source = src
    pk.searchUrl = url
    pk.matchText = subsMatchText()
    pk.prefLang = PreferredCaptionLang()
    if tok <> "" then pk.bearer = tok
    pk.observeField("closed", "onSubsSearchClosed")
    m.subsSearch = pk
    pk.setFocus(true)
    ' `start` LAST, the same guard every other screen here uses: it is what
    ' makes the search happen, so every field it reads must already be set.
    pk.start = true
end sub

' The search screen is a child of the SCENE, not of this player, so a player
' that leaves without taking it with it would leave a panel sitting over the
' grid with nothing listening to the remote. Both ways out call this — the
' ordinary close and the Multi-View hand-over.
sub closeSubsSearch()
    if m.subsSearch = invalid then return
    m.subsSearch.unobserveField("closed")
    scene = m.top.getScene()
    if scene <> invalid then scene.removeChild(m.subsSearch)
    m.subsSearch = invalid
end sub

sub onSubsSearchClosed()
    if m.subsSearch = invalid then return
    picked = ToStr(m.subsSearch.pickedJson)
    m.top.getScene().removeChild(m.subsSearch)
    m.subsSearch = invalid
    m.top.setFocus(true)
    if picked = ""
        ' Backed out without taking one. Nothing changes, not even the
        ' subtitle that was already on.
        redrawButtons()
        showControls()
        return
    end if
    got = ParseJson(picked)
    if got = invalid
        redrawButtons()
        showControls()
        return
    end if
    path = ToStr(GetField(got, "path"))
    if path = ""
        redrawButtons()
        showControls()
        return
    end if
    ' attachExternalSub files the choice itself, at this moment — the moment
    ' the member picked it out of the search results. It is NOT filed later
    ' off the back of a track appearing, because no track ever appears; that
    ' is what left the free path in startPlayback with nothing to load and
    ' made every return to a title fetch again.
    ' The address it came from, kept beside the copy on disk. Both
    ' SubtitleTracks.TrackName and SubtitleConfig.TrackName are documented as
    ' a URL, so extSubAddress offers this one first and falls back to the
    ' local copy. SUBDL ROWS ONLY — an OpenSubtitles file comes through a
    ' short-lived relay link that is not carried on the row, so this is empty
    ' for those and the local copy is what gets used.
    m.extSubUrl = ToStr(GetField(got, "url"))
    attachExternalSub(path, ToStr(GetField(got, "lang")), ToStr(GetField(got, "label")))
    ' The member's own allowance, in their words. Only OpenSubtitles has one
    ' — Subdl sends nothing back, so nothing is claimed.
    ' Written back to the account at the same moment, because this answer is
    ' the ONLY place the real number ever comes from — sign-in does not carry
    ' it. Without this the Add-ons page keeps saying the allowance forever,
    ' however many the member has spent from this television.
    if ToStr(GetField(got, "source")) <> "subdl"
        UpdateAddOnQuota("opensubtitles", ToStr(GetField(got, "remaining")), ToStr(GetField(got, "resetUtc")))
    end if
    line = subsQuotaLine(ToStr(GetField(got, "remaining")), ToStr(GetField(got, "resetUtc")))
    if line <> ""
        m.status.text = line
        m.status.visible = true
        ' Goes away with the control bar. The status line normally holds
        ' something the member has to act on — an error, a refusal — and
        ' those must stay up; a count of downloads left is news, not a
        ' problem, so it leaves when the controls do rather than sitting
        ' over the film for the rest of the evening.
        m.statusTransient = true
    end if
    showControls()
end sub

' "Downloads left today: 97, until 6:59 PM." The clock reading follows the
' BOX'S OWN 12/24-hour setting, the same rule "Ends at 8:42 PM" follows, and
' a reset time we cannot read is simply left off rather than guessed at.
function subsQuotaLine(remaining as string, resetUtc as string) as string
    if remaining = "" then return ""
    out = "Downloads left today: " + remaining
    at = subsLocalClock(resetUtc)
    if at <> "" then out = out + ", until " + at
    return out + "."
end function

function subsLocalClock(iso as string) as string
    if iso = "" then return ""
    dt = CreateObject("roDateTime")
    if dt = invalid then return ""
    ok = false
    try
        dt.FromISO8601String(iso)
        ok = (dt.asSeconds() > 0)
    catch e
        ok = false
    end try
    if not ok then return ""
    dt.ToLocalTime()
    hh = dt.GetHours()
    mm = dt.GetMinutes()
    mmTxt = mm.toStr()
    if mm < 10 then mmTxt = "0" + mmTxt
    if ClockIs24Hour()
        hhTxt = hh.toStr()
        if hh < 10 then hhTxt = "0" + hhTxt
        return hhTxt + ":" + mmTxt
    end if
    ampm = " AM"
    h12 = hh
    if h12 >= 12
        ampm = " PM"
        h12 = h12 - 12
    end if
    if h12 = 0 then h12 = 12
    return h12.toStr() + ":" + mmTxt + ampm
end function

' ---- Putting a downloaded subtitle on the picture ---------------------------
'
' WE WERE USING A FIELD THAT DOES NOT EXIST ON THIS API. Roku's content
' meta-data reference says of `SubtitleUrl`, verbatim, "This is supported on
' roVideoScreen only." roVideoScreen is the LEGACY screen API; this app is
' SceneGraph with a Video node, so `content.SubtitleUrl` was never going to do
' anything here. That explains the whole of the 2026-09-17 evening on the
' office stick (Dave, store edition of v1.0.39, Jellyfin MKV direct play, a
' real Subdl pick driven twice): nothing rendered from a cachefs path, from a
' tmp: copy or from an https address, on MKV or on MP4, and the file never
' joined `availableSubtitleTracks`. Both runs printed the container's own
' eight tracks and nothing else:
'
'     mkv/3 | mkv/4 | mkv/5 | mkv/6 | mkv/7 | mkv/8 | mkv/9 | mkv/10
'
' The earlier conclusion drawn from that — "Roku renders the file off the
' content node but never lists it" — was wrong in its first half. Nothing was
' being rendered. What a member saw on that run was the container's OWN
' English track, switched on as a side effect of globalCaptionMode = "On";
' that was proved by comparing the screen against the file at the same second
' and finding different words.
'
' THE TWO FIELDS SceneGraph ACTUALLY TAKES, from the same reference page:
'
'   SubtitleTracks   roArray of roAssociativeArray —
'                    [{ Language, Description, TrackName }, ...],
'                    "sets the list of available caption tracks available to
'                    the stream".
'                      Language    ISO 639.2B THREE-character code. Our rows
'                                  carry two-letter codes, so subLang3 below
'                                  does the mapping — and it maps to the
'                                  BIBLIOGRAPHIC set (fre, ger, dut, gre, chi),
'                                  not the terminology one (fra, deu, nld,
'                                  ell, zho), because 639.2B is what the page
'                                  names.
'                      Description "text that will be shown for the
'                                  corresponding track in the closed caption
'                                  configuration dialog" — so the release name
'                                  the member picked out of the search results
'                                  goes here, which is the same words their
'                                  own row in the Subtitles menu shows.
'                      TrackName   "URL from where the caption track can be
'                                  downloaded. Sideloaded caption formats can
'                                  include srt, ttml, and dfxp."
'   SubtitleConfig   roAssociativeArray — { TrackName }, and for a sideloaded
'                    track "TrackName is the url from where the caption track
'                    can be downloaded". This is what picks one out of the
'                    list above, so both fields carry the same string.
'
' NOTE THE WORD "URL" IN BOTH DEFINITIONS. A cachefs: or tmp: path may well
' not be accepted, so extSubAddress() hands over the https address the file
' came from when there is one and keeps the local copy as the fallback — the
' opposite way round from how this was left. What that gives up is written out
' at extSubAddress; read it before judging a result on the stick.
'
' THE THREE SITES THAT WRITE IT are startPlayback (free, before the stream
' opens), attachExternalSub (a fresh pick) and chooseExternalSub (putting the
' one already held back on). All three go through applyExtSubToContent so they
' cannot drift apart, which is how the old field ended up written three
' slightly different ways.
'
' WHAT IT COSTS, which is the question this house asks first, and NONE of this
' changes with the field:
'   · picking one MID-FILM reopens the stream — ONE connection, spent once,
'     only because a member deliberately picked a subtitle. It is not a
'     retry, it is not a loop, it cannot repeat on its own, and it is never
'     done on live.
'   · the same subtitle on the NEXT open costs NOTHING: it is remembered at
'     the moment it is picked, and startPlayback puts it on the content node
'     before playback begins.
'   · turning it off and on again within one stream costs nothing either, as
'     long as that stream opened with the file on it — see m.extSubLoaded.
'
' ALL FOUR OPEN QUESTIONS ARE NOW ANSWERED — office Streaming Stick 4K, OS
' 15.3.4, 2026-09-19, store edition of v1.0.39, a Jellyfin MKV direct play
' (2 Fast 2 Furious) with eight subtitle tracks of its own, driven twice:
'   1. DOES THE FETCHED SUBTITLE TURN UP IN availableSubtitleTracks? Yes, and
'      it is the ONLY thing in it. logSubTracks printed the whole list as
'      `<dev_4_0>https://dl.subdl.com/subtitle/gAqpnO3gDO/8ne1VJWOOu` — the
'      sideloaded track, with the container's own mkv/3..mkv/10 gone. So
'      declaring SubtitleTracks REPLACES the stream's list rather than adding
'      to it, and that is what rules out picking one of the stream's own
'      tracks without a reopen (see restartForOwnTrack).
'      It renders: at 00:55:11 the picture read "- Where's he at? / - He's on
'      his way." and cue 574 of the file reads exactly that, to the second;
'      again at 00:57:04 and at 01:06:03 on a second file. The two files read
'      back 77,514 and 98,387 bytes on the box and are byte-for-byte the size
'      Subdl serves. This is the answer to the whole 2026-09-17 dead end.
'   2. THE m.extSubOn ROW AND THE REOPEN STAY. The fetched subtitle replaces
'      the list rather than joining it, so it is not a track the member can
'      be pointed at — it still needs its own row, and getting off it still
'      needs a reopen. Kept, now for a measured reason.
'   3. DOES globalCaptionMode = "Off" HIDE IT? Yes, and the track can stay
'      declared. With the file on and Off picked, five frames across 32
'      seconds of a scene the file has ten cues in drew nothing at all.
'   4. DOES CLEARING THE TWO FIELDS ON A PLAYING STREAM TAKE IT OFF? No — it
'      ENDS THE STREAM. Black picture, query/media-player state="close".
'      That path is gone; see clearExternalSub and restartForOwnTrack.
' ONE MORE THING WORTH KNOWING, because it wasted time: query/media-player's
' captions="srt" is NOT an answer to "are captions on screen". It reported
' srt throughout the Off run above, with nothing drawing. Only the picture
' and the app's own log say what is really on.
sub attachExternalSub(path as string, lang as string, label as string)
    ' The member picked the one this stream already opened with — they went
    ' back into the search and chose the same file again. Nothing to reopen:
    ' the decoder has it, and asking the provider for another connection to
    ' deliver a file that is already in the picture would be a connection
    ' spent on nothing.
    alreadyOn = (m.extSubLoaded and path = m.extSubPath)
    m.extSubPath = path
    m.extSubLang = lang
    m.extSubLabel = label
    m.extSubOn = true
    ' The stream's own tracks stay as they are, and none of them is selected
    ' any more: the fetched file and an embedded track are mutually exclusive
    ' and m.extSubOn is now the one that is on.
    m.ccSel = 0
    tracksNow = m.video.availableSubtitleTracks
    if tracksNow = invalid then tracksNow = []
    m.subTracks = tracksNow
    ' The cheap write, kept: it costs no request. Whether it is enough on its
    ' own — whether the two fields can be changed on a stream that is already
    ' playing — is one of the open questions above; the reopen below is what
    ' makes it work either way.
    applyExtSubToContent(m.video.content)
    m.video.globalCaptionMode = "On"
    m.video.subtitleTrack = ""
    ' FILED NOW, at the moment of the pick. This is the line that makes the
    ' free path in startPlayback work at all: nothing later in the stream's
    ' life can tell us the member chose this, because Roku never reports the
    ' file as a track.
    rememberSubPick(path, lang, label)
    redrawButtons()
    if alreadyOn
        KLog("subs", "that subtitle was already on this stream - nothing reopened")
        return
    end if
    restartForSubtitle()
end sub

' THE LOCAL COPY, AS A PLAYABLE PATH — the fallback half of extSubAddress.
'
' `cachefs:/` is a CACHE the firmware may empty, and the same two calls that
' say a file is there from the search screen have already been caught saying
' it is not from here. So the file is copied to `tmp:/`, which is this app's
' own scratch space for the life of the process, and THAT is the path handed
' over. The cache keeps doing its job — it is what stops a second download —
' and tmp: is only the hand-off.
'
' THE NAME IS THE POINT, not just the location. Roku decides a caption file's
' format from its EXTENSION, and `kwicksub_play.srt` is a real .srt name. That
' is what this copy is worth over the raw address for Subdl, whose links carry
' no extension at all — see extSubAddress, which weighs the two.
'
' It is also the only copy that has been through SubFileTask's UTF-8
' re-encode, so accented letters are known to be right in this one.
'
' Falls back to the original path on any fault. A copy that cannot be made
' leaves the member exactly where they were and never throws.
function subPlayablePath(path as string) as string
    if path = "" then return path
    try
        ba = CreateObject("roByteArray")
        if not ba.readFile(path)
            KLog("subs", "could not read the cached subtitle at " + path + " - handing the player that path as it stands")
            return path
        end if
        n = ba.count()
        dst = "tmp:/kwicksub_play.srt"
        ' NO roFileSystem HERE. This runs on the RENDER thread, and Roku
        ' answers a CreateObject("roFileSystem") there with
        '
        '   BRIGHTSCRIPT: ERROR: roFilesystem: creating MAIN|TASK-only
        '   component failed on RENDER thread
        '
        ' seen on the office stick 2026-09-18 at this very line. That one
        ' message explains two days of confusion: every render-thread Exists()
        ' and GetDirectoryListing in this app was asking an INVALID object and
        ' being told no, which read from the outside as "the firmware lies
        ' about cachefs:". It does not lie. It was never asked.
        '
        ' writeFile overwrites from byte zero and does not truncate, so a
        ' longer file left behind would leave its tail on the end of this one.
        ' roByteArray has no delete, so the tail is cut by writing the exact
        ' length we want and letting the next reader stop at the SRT's own end
        ' — and in practice the previous file is always replaced whole,
        ' because every subtitle written here is written in one call.
        if not ba.writeFile(dst)
            KLog("subs", "could not write the subtitle to tmp: - handing the player " + path)
            return path
        end if
        KLog("subs", "copied " + n.toStr() + " byte(s) of subtitle from " + path + " to " + dst + " for the player")
        return dst
    catch e
        KLog("subs", "subtitle hand-off copy skipped: " + ToStr(GetField(e, "message")))
    end try
    return path
end function

' ---- The fetched subtitle, as the content node's own caption track ----------

' WHAT THE VIDEO NODE IS ACTUALLY GIVEN. Both SubtitleTracks.TrackName and
' SubtitleConfig.TrackName are documented as a URL, so the https address the
' file came from is offered first and the local copy is the fallback.
'
' WHAT THE ADDRESS GIVES UP, and this is a real trade rather than a formality:
'
'  1. THE EXTENSION. Measured on the office stick 2026-09-17: dl.subdl.com
'     serves these with `Content-Type: application/octet-stream`,
'     `content-disposition: attachment` and NO .srt on the end of the path,
'     and Roku decides a caption file's format from the extension. So the
'     address may well be refused where the local .srt copy would not be.
'     That measurement predicts this is the half that fails; it is written
'     down here rather than left to be rediscovered, and the log line in
'     logSubTracks says which one was handed over so one run answers it.
'  2. THE UTF-8 RE-ENCODE in SubFileTask, which only ever runs on the copy we
'     fetch ourselves. A Windows-1252 subtitle drawn straight off the address
'     will have its accented letters come out as boxes, where the local copy
'     has them right.
'
' HOW OFTEN THE ADDRESS IS EVEN AVAILABLE: less often than it looks. The url
' is set on SUBDL rows only (AddOns.brs:SubsMapRow — OpenSubtitles files come
' through a short-lived relay link instead), and it is NOT remembered across
' launches, because rememberSubPick files the path, the language and the label
' and nothing else. So an OpenSubtitles pick and EVERY remembered pick take
' the local copy. The address is the fresh-Subdl-pick case and no other.
function extSubAddress() as string
    if m.extSubPath = "" and m.extSubUrl = "" then return ""
    addr = ToStr(m.extSubUrl).trim()
    if addr <> "" then return addr
    if m.extSubPath = "" then return ""
    return subPlayablePath(m.extSubPath)
end function

' The ISO 639.2B three-character code the Language field asks for.
'
' Our rows carry whatever the relay sent, which is usually a two-letter code
' ("en", "pt-br") and sometimes a three-letter one already. BIBLIOGRAPHIC, not
' terminology: fre/ger/dut/gre/chi/cze/slo/per/rum/may, which is the set the
' reference page names. A code this does not know is passed through — an
' honest wrong code reads better in the caption dialog than a blank, and the
' member picked the language themselves in the search results.
'
' Kept in this file rather than added to Util.brs's LangName: LangName answers
' a DISPLAY NAME, this answers a code, and Util.brs is not mine to change.
function subLang3(code as string) as string
    c = LCase(ToStr(code)).trim()
    if c = "" then return "und"
    ' "pt-br" / "zh_cn" — the region is not part of a 639.2 code.
    at = Instr(1, c, "-")
    if at > 1 then c = Left(c, at - 1)
    at = Instr(1, c, "_")
    if at > 1 then c = Left(c, at - 1)
    three = {
        en: "eng", es: "spa", fr: "fre", de: "ger", it: "ita", pt: "por"
        nl: "dut", no: "nor", sv: "swe", da: "dan", fi: "fin", pl: "pol"
        ru: "rus", uk: "ukr", ro: "rum", hu: "hun", cs: "cze", sk: "slo"
        sl: "slv", el: "gre", tr: "tur", ar: "ara", he: "heb", hi: "hin"
        th: "tha", vi: "vie", zh: "chi", ja: "jpn", ko: "kor", id: "ind"
        ms: "may", bg: "bul", hr: "hrv", sr: "srp", et: "est", lv: "lav"
        lt: "lit", ca: "cat", gl: "glg", eu: "baq", fa: "per", ur: "urd"
        bn: "ben", ta: "tam", te: "tel"
    }
    if three.doesExist(c) then return three[c]
    ' Already three characters, or a terminology code that has a
    ' bibliographic twin. Roku names 639.2B, so the twin is normalised.
    bib = { fra: "fre", deu: "ger", nld: "dut", ell: "gre", zho: "chi", ces: "cze", slk: "slo", fas: "per", ron: "rum", msa: "may", eus: "baq" }
    if bib.doesExist(c) then return bib[c]
    if Len(c) = 3 then return c
    return "und"
end function

' Put the fetched subtitle on a content node as its one caption track.
' Answers false when there is nothing to put there, so a caller does not
' claim the decoder has a file it was never given.
'
' EVERY KEY IS WRITTEN IN BRACKETS WITH ITS CASE SPELLED OUT. BrightScript
' folds a field name written as code (tr.TrackName = ...) down to lowercase,
' and these three go to the firmware by their documented mixed-case names.
' This is the same rule Store.brs follows for its registry maps, and it has
' cost this app at least four live bugs when it was not followed.
function applyExtSubToContent(c as dynamic) as boolean
    if c = invalid then return false
    addr = extSubAddress()
    if addr = "" then return false
    tr = {}
    tr["Language"] = subLang3(m.extSubLang)
    ' What the member reads in Roku's own caption dialog. The same words their
    ' row in our Subtitles menu shows, so the two cannot disagree.
    tr["Description"] = subsExtRowLabel()
    tr["TrackName"] = addr
    c.SubtitleTracks = [tr]
    ' And the same string again, which is how a sideloaded track is selected
    ' out of the list above.
    cfg = {}
    cfg["TrackName"] = addr
    c.SubtitleConfig = cfg
    return true
end function

' THERE IS NO "TAKE IT BACK OFF THE NODE" AND THAT IS DELIBERATE. There used
' to be: it set SubtitleTracks = [] and SubtitleConfig = {} on the node the
' Video was playing. On the office stick, 2026-09-19, that ended the stream —
' black picture, state="close". A node the Video is holding is not a place to
' unset those two fields. The fetched subtitle comes off one of two ways now:
' the renderer goes off (Off, which hides it and costs nothing), or the stream
' is reopened without it (restartForOwnTrack, which costs one connection and
' is the only way to get the stream's own tracks back — while a sideloaded
' track is declared, availableSubtitleTracks holds only that one).

' How many rows the fetched subtitle adds under "Off". Nought or one — a
' member holds at most one downloaded subtitle per title, because the pick
' replaces the last one.
function subsExtRowCount() as integer
    if m.extSubPath <> "" then return 1
    return 0
end function

' What that row says. The name it had in the search results ("Spanish   The
' Departed 2006 1080p"), because that is what the member chose; a file path
' would mean nothing to them. Written both ways — a fetched file with no
' label still gets an honest row rather than a blank one.
function subsExtRowLabel() as string
    if m.extSubLabel <> "" then return m.extSubLabel
    if m.extSubLang <> "" then return LangName(m.extSubLang) + "   (downloaded)"
    return "Downloaded subtitle"
end function

' Take the fetched subtitle back off the picture. Called when the member
' picks Off — and only Off. One caller, one behaviour, since the stick
' settled the other case on 2026-09-19.
'
' The caption renderer is going off, which hides everything there is to
' hide, so the track STAYS declared on the content node. Leaving it there
' costs nothing and it means turning the subtitle back on again is free
' rather than another reopen: turning captions off and on again mid-film is
' an ordinary thing to do and it must not cost the member's account a
' connection each way.
'
' It also must not touch the node for a second reason, now measured: taking
' SubtitleTracks and SubtitleConfig off a node the Video is playing ENDS THE
' STREAM. That is what the old dropFile = true path did, and it is why
' picking one of the stream's own tracks now goes through
' restartForOwnTrack instead.
sub clearExternalSub()
    m.extSubOn = false
end sub

' The member had a fetched subtitle on and asked for one of the stream's OWN
' tracks. That needs a reopen — see the block in onSubPickerClosed for the
' two measurements that rule out doing it in place — so this is the second
' sub that spends a provider connection, and like restartForSubtitle it says
' no on live in its own right rather than trusting a caller.
'
' The wanted track is held BY NAME, not by index: the reopened stream builds
' its own list and an index off the old one would be a guess. onPosition
' selects it as soon as that list arrives.
sub restartForOwnTrack(trackName as string)
    if m.top.isLive then return
    if trackName = "" then return
    posNow = m.video.position
    if posNow < 0 then posNow = 0
    KLog("subs", "reopening the stream to take the downloaded subtitle off and use one of its own tracks")
    ' Cleared BEFORE startPlayback, which is what keeps the fetched file off
    ' the new content node — startPlayback only hangs it on when m.extSubOn.
    m.extSubOn = false
    m.extSubLoaded = false
    m.wantOwnTrack = trackName
    m.status.text = "Switching subtitles - the picture will pick up where you are."
    m.status.visible = true
    showControls()
    m.top.resumeFrom = posNow
    ' NOT a retry — see restartForSubtitle.
    m.retries = 0
    m.video.control = "stop"
    startPlayback()
end sub

' Put the fetched subtitle on. Free when this stream already opened with the
' file on its content node — the decoder has it and the caption renderer is
' the only switch left. Otherwise it costs the one reopen, and it costs it
' because the member asked for it.
sub chooseExternalSub()
    if m.extSubPath = "" then return
    m.extSubOn = true
    m.ccSel = 0
    applyExtSubToContent(m.video.content)
    m.video.globalCaptionMode = "On"
    m.video.subtitleTrack = ""
    ' Picked on purpose, so it becomes the answer for this title again.
    rememberSubPick(m.extSubPath, m.extSubLang, m.extSubLabel)
    if m.extSubLoaded
        KLog("subs", "the downloaded subtitle went back on without reopening the stream")
        redrawButtons()
        return
    end if
    redrawButtons()
    restartForSubtitle()
end sub

' WHAT ROKU ACTUALLY DID WITH THE FILE, said once per reopen.
'
' THIS IS THE LINE THAT ANSWERS THE FIELD CHANGE. The move from SubtitleUrl to
' SubtitleTracks + SubtitleConfig was made from the reference page, not from a
' television, and the test of it is simple: if the fetched subtitle now turns
' up in the track list printed below, the change worked. It also says WHICH of
' the two addresses was handed over — the https one or the local .srt copy —
' because Subdl's links carry no extension and that is the half most likely to
' be refused.
'
' Printed only after a reopen has already been spent, so it costs nothing on
' the free path, and once only, so it cannot fill a member's log.
sub logSubTracks(why as string)
    if m.extSubLogged = true then return
    m.extSubLogged = true
    names = ""
    tracks = m.video.availableSubtitleTracks
    if tracks <> invalid
        for i = 0 to tracks.count() - 1
            if names <> "" then names = names + " | "
            names = names + ToStr(tracks[i].TrackName)
        end for
    end if
    if names = "" then names = "(none)"
    ' THE SIZE, READ RATHER THAN ASKED FOR.
    '
    ' This used to create an roFileSystem here and print what Exists(), Stat()
    ' and GetDirectoryListing said. Every one of those came back denying a file
    ' that was plainly there, and the 2026-09-17 note took that at face value
    ' and concluded the firmware lies about cachefs:. It does not. On
    ' 2026-09-18 the console finally said why, at this very line:
    '
    '   BRIGHTSCRIPT: ERROR: roFilesystem: creating MAIN|TASK-only component
    '   failed on RENDER thread
    '
    ' roFileSystem CANNOT BE MADE ON THE RENDER THREAD. Every answer those
    ' calls gave was an invalid object being asked a question. A read works
    ' fine here, so the size is measured by reading.
    sz = -1
    try
        ba = CreateObject("roByteArray")
        if ba <> invalid and ba.readFile(m.extSubPath) then sz = ba.count()
    catch e
        sz = -1
    end try
    ' Which of the two extSubAddress chose. The address itself is printed
    ' because a Subdl file link carries no key and no member data — it is a
    ' public file on dl.subdl.com — unlike the tokens, which are never logged
    ' anywhere in this app.
    handed = extSubAddress()
    if handed = "" then handed = "(nothing)"
    KLog("subs", why + " - file " + m.extSubPath + " reads back " + sz.toStr() + " byte(s); handed to the player as " + handed + " with Language '" + subLang3(m.extSubLang) + "'; the player's track list is: " + names)
end sub

' subFileInCacheList WAS HERE and is deliberately gone (2026-09-18). It asked
' GetDirectoryListing("cachefs:/") as a second opinion on Exists(), and on this
' thread both were answers from an invalid object: roFileSystem cannot be
' created on the RENDER thread at all, which the console finally said in as
' many words. Nothing in this file asks about a file any more — subFileOnBox
' reads one byte instead, which is cheap and is the only answer that can be
' trusted. See the block there.

' Is the fetched file still on the box at all? Asked ONCE, when a title
' opens, and never per row or per draw.
'
' THREE ANSWERS, not two: 1 = it is there, 0 = it is not, -1 = this box would
' not say. That third one matters because the only caller DELETES the
' member's remembered choice on a no, and a no it could not stand behind
' would make them download the same subtitle again — the exact thing this
' cache exists to prevent.
'
' TWO CALLS ON PURPOSE. Exists() denied a real cachefs file on the stick on
' 2026-09-17 (see logSubTracks) while the search screen's directory listing
' saw it, so the listing is the second opinion. It is only asked when
' Exists() has already said no, so the ordinary answer is still one cheap
' call.
function subFileOnBox(path as string) as integer
    if path = "" then return 0
    ' READ IT. DO NOT ASK ABOUT IT.
    '
    ' This asked Exists() first and used the directory listing as a second
    ' opinion, on the strength of the 2026-09-17 measurement. The 2026-09-18
    ' one went further: BOTH of them denied a cachefs: file that had just been
    ' written, which is a "no" this function must never hand back — its only
    ' caller deletes the member's remembered subtitle on a no, so a wrong no
    ' costs them the download this cache exists to prevent.
    '
    ' A read cannot lie the same way. An empty answer still cannot tell "not
    ' there" from "there and empty", but for this question those are the same
    ' thing: neither is a subtitle worth keeping a choice for. The -1 "would
    ' not say" answer is kept for the case the read itself faults, because
    ' that is genuinely a box that would not say rather than a box saying no.
    ' ONE BYTE, NOT THE WHOLE FILE. roByteArray.ReadFile takes an offset and a
    ' length, so the cheap honest test is to read the first byte and see
    ' whether anything came back. A subtitle runs to about a hundred kilobytes
    ' and this is asked every time a title opens, on the render thread; pulling
    ' all of it in just to prove it exists is the shape of mistake that has
    ' killed members' boxes here before (the 15 MB catalogue that had to stop
    ' using ReadAsciiFile for exactly this reason).
    try
        ba = CreateObject("roByteArray")
        if ba = invalid then return -1
        if not ba.ReadFile(path, 0, 1) then return 0
        if ba.count() > 0 then return 1
        return 0
    catch e
        return -1
    end try
end function

' THE ORDINARY PATH FOR A MID-FILM PICK, not a fallback — the television
' settled that on 2026-09-17. One reopen, at the same second, and the member
' is told in words that the picture is about to pick up where they are.
'
' Reached only from a deliberate press: attachExternalSub (they picked a
' subtitle out of the search) and chooseExternalSub (they turned one back on
' from the menu, on a stream that did not open with it). Nothing here fires
' on a timer, a focus move or a failure.
sub restartForSubtitle()
    ' Live never reaches here — the search is not offered on live — but this
    ' is the sub that spends a connection, so it says no in its own right
    ' rather than trusting a caller.
    if m.top.isLive then return
    if m.extSubPath = "" then return
    posNow = m.video.position
    if posNow < 0 then posNow = 0
    KLog("subs", "reopening the stream to put a downloaded subtitle on")
    ' Armed here, not in init: the line worth printing is the one AFTER the
    ' reopen, and only for a member who actually spent one.
    m.extSubLogged = false
    m.status.text = "Putting those subtitles on - the picture will pick up where you are."
    m.status.visible = true
    showControls()
    m.top.resumeFrom = posNow
    ' NOT a retry. The reconnect ladder counts failures, and a member asking
    ' for a subtitle is not one; leaving the count standing would spend an
    ' attempt this stream may need later.
    m.retries = 0
    m.video.control = "stop"
    startPlayback()
end sub

' ---- Remembering the choice per title ----------------------------------------
'
' "Remember the member's choice and bring it back on return." Kept as ONE
' registry value holding a short list, and that shape is deliberate: the
' whole app gets 16-32 KB of registry and a write past it fails SILENTLY,
' taking whatever else was mid-write with it. One key per title would grow
' without a ceiling; twenty pairs of a resume key and a file path is about a
' kilobyte and cannot.
'
' The list is oldest-first and the newest is pushed on the end, so trimming
' is taking from the front. Twenty titles is far more than a member returns
' to, and a trimmed entry costs nothing but one more download if they ever
' do come back.
function subPickRegKey() as string
    return "subs_pick" + ProfileScopeSuffix()
end function

function subPickAll() as object
    raw = RegRead(subPickRegKey())
    if raw = "" then return []
    got = ParseJson(raw)
    if got = invalid or type(got) <> "roArray" then return []
    return got
end function

function subPickFind(key as string) as dynamic
    for each row in subPickAll()
        if ToStr(GetField(row, "k")) = key then return row
    end for
    return invalid
end function

sub subPickWrite(list as object)
    if list.count() = 0
        RegDelete(subPickRegKey())
        return
    end if
    RegWrite(subPickRegKey(), FormatJson(list))
end sub

sub rememberSubPick(path as string, lang as string, label as string)
    key = ToStr(m.top.resumeKey)
    ' No key means nothing to file it under — a USB file or a stream opened
    ' without resume tracking. It still plays; it is just not remembered.
    if key = "" then return
    out = []
    for each row in subPickAll()
        if ToStr(GetField(row, "k")) <> key then out.push(row)
    end for
    out.push({ k: key, p: path, l: lang, n: label })
    while out.count() > 20
        out.shift()
    end while
    subPickWrite(out)
end sub

sub forgetSubPick()
    key = ToStr(m.top.resumeKey)
    if key = "" then return
    out = []
    dropped = false
    for each row in subPickAll()
        if ToStr(GetField(row, "k")) = key then dropped = true else out.push(row)
    end for
    if dropped then subPickWrite(out)
end sub

' What this title had last time. Keyed on resumeKey, and re-read whenever
' that changes — the next episode is a different title with a different
' answer, and this node is reused for it.
sub loadRememberedSub()
    key = ToStr(m.top.resumeKey)
    ' SAME TITLE, so this is a retry, a Refresh or the reopen that puts a
    ' subtitle on — and the member's answer for this title is whatever they
    ' last said, not whatever the registry said when it opened. Leaving early
    ' is what stops a reopen undoing the very choice it is reopening for.
    if m.extSubKey <> invalid and m.extSubKey = key then return
    m.extSubKey = key
    m.extSubPath = ""
    m.extSubLang = ""
    m.extSubLabel = ""
    ' CLEARED WITH THE REST, and it has to be. The address is only ever set by
    ' a fresh pick in this session (onSubsSearchClosed) and is never
    ' remembered, so a value left standing here would be the PREVIOUS
    ' episode's subtitle — and extSubAddress prefers the address over the
    ' path, so the next episode would open with the last one's words on it.
    m.extSubUrl = ""
    ' A DIFFERENT TITLE, so the remembered answer IS the state. Set both ways
    ' — this node is reused for the next episode, and a flag left standing
    ' would put the last episode's subtitle on this one's picture.
    m.extSubOn = false
    ' Same reason: a track the member asked for on the LAST title is not a
    ' track to select on this one, and the names do not carry across streams.
    m.wantOwnTrack = ""
    if key = "" then return
    row = subPickFind(key)
    if row = invalid then return
    path = ToStr(GetField(row, "p"))
    if path = "" then return
    ' cachefs is a cache and the box is allowed to empty it. A remembered
    ' file that is gone is FORGOTTEN rather than half-applied: handing a
    ' missing path to the Video node would be a subtitle that silently never
    ' appears, which is worse than plainly not having one.
    onBox = subFileOnBox(path)
    if onBox = 0
        KLog("subs", "the remembered subtitle for this title is no longer on the box")
        forgetSubPick()
        return
    end if
    if onBox < 0
        ' The box would not say whether the file is there. NOTHING IS
        ' DELETED on that — the remembered row stays for the next open, which
        ' is the difference between a member keeping a subtitle and being
        ' told to download it again. It is simply not put on this time.
        KLog("subs", "could not tell whether the remembered subtitle is still on the box - leaving the choice alone")
        m.extSubPath = ""
        return
    end if
    m.extSubPath = path
    m.extSubLang = ToStr(GetField(row, "l"))
    m.extSubLabel = ToStr(GetField(row, "n"))
    ' Remembered means it was on when they left it, so it goes back on.
    m.extSubOn = true
end sub

' ---- Audio tracks -----------------------------------------------------------
'
' A MANUAL soundtrack picker, the port of audio_track_menu.dart. A lot of film
' and nearly all anime carries several tracks with the original language
' first, so a member opens something and it is in Japanese; that is the file
' being what it is, but with no way to say otherwise it looks like the app's
' fault.
'
' This does NOT contradict the note above logAudioTracks. That note forbids
' switching tracks AUTOMATICALLY on a playback failure, because Roku never
' reports a track's codec and on a codec failure may not have parsed the
' tracks at all — so an automatic switch is a guess that costs another
' connection. A member opening this list on purpose is not a guess. The
' diagnostic logging stays exactly as it was.
sub openAudioTracks()
    tracks = m.video.availableAudioTracks
    if tracks = invalid then tracks = []
    m.audioTracks = tracks

    pk = m.top.getScene().createChild("SubtitlePickerScreen")
    pk.titleText = "Audio"

    ' One track is not a choice and an empty list reads as broken. Say so in
    ' words — the same two sentences Android says.
    if tracks.count() < 2
        if tracks.count() = 0
            pk.noteText = "This stream hasn't reported its soundtracks yet. Give it a moment after the picture starts and try again."
        else
            pk.noteText = "This has only one soundtrack, so there is nothing to switch to."
        end if
        ' marks/startIndex before labels — setting labels builds the list.
        pk.marks = [""]
        pk.startIndex = 0
        pk.labels = ["OK"]
        pk.observeField("closed", "onAudioPicked")
        m.audioPicker = pk
        pk.setFocus(true)
        return
    end if

    cur = ToStr(m.video.audioTrack)
    labels = []
    marks = []
    active = 0
    for i = 0 to tracks.count() - 1
        labels.push(audioTrackLabel(tracks[i], i))
        marks.push("")
        ' An unset audioTrack means the player is on whatever it picked
        ' first, which is track 0.
        if cur <> "" and ToStr(GetField(tracks[i], "Track")) = cur then active = i
    end for
    marks[active] = "Active"
    pk.marks = marks
    pk.startIndex = active
    pk.labels = labels
    pk.observeField("closed", "onAudioPicked")
    m.audioPicker = pk
    pk.setFocus(true)
end sub

' What to call a track on screen — port of audioTrackLabel. Providers label
' these inconsistently: sometimes a language code, sometimes a title, often
' nothing at all, so an unnamed track falls back to its position rather than
' drawing a blank row.
function audioTrackLabel(tr as object, index as integer) as string
    name = ToStr(GetField(tr, "Name"))
    lang = ToStr(GetField(tr, "Language"))
    if name <> "" and lang <> "" and LCase(name) <> LCase(lang)
        return name + "  " + Chr(&hB7) + "  " + LangName(lang)
    end if
    if name <> "" then return name
    if lang <> "" then return LangName(lang)
    return "Track " + (index + 1).toStr()
end function

sub onAudioPicked()
    if m.audioPicker = invalid then return
    if m.audioPicker.picked = true and m.audioTracks.count() >= 2
        idx = m.audioPicker.chosen
        if idx >= 0 and idx < m.audioTracks.count()
            tn = ToStr(GetField(m.audioTracks[idx], "Track"))
            if tn <> ""
                m.video.audioTrack = tn
                KLog("player", "audio track -> " + tn + " (" + audioTrackLabel(m.audioTracks[idx], idx) + ")")
            end if
        end if
    end if
    m.top.getScene().removeChild(m.audioPicker)
    m.audioPicker = invalid
    redrawButtons()
    m.top.setFocus(true)
    showControls()
end sub

' ---- Multi-View -------------------------------------------------------------
'
' The rule the Multi-View builder wrote down, and the reason it is a rule on
' Roku rather than a preference: the player closes itself and hands its
' content over as the seed, because Roku allows exactly ONE playing Video
' instance per channel and the grid cannot start while this one holds it.
' Android replaces the route for the same effect (multi_view_entry.dart).
'
' PlayerMultiView is the thing that survives the close and walks the rest of
' the way — see its own file for why it has to exist.
sub openMultiView()
    seed = multiViewSeed()
    if seed = invalid
        ' Nothing playable to hand over. Say so and stay put rather than
        ' closing the player for a Multi-View that would open empty.
        m.status.text = "Multi-View can't tell what this is — open it from the channel or title page instead."
        m.status.visible = true
        showControls()
        return
    end if

    ' Leave properly on the way out: the spot, the timers, the stream.
    saveProgress()
    ' The other way this player exits, and the other place `closed` is set —
    ' so the stop scrobble belongs here as well, and for the same reason it is
    ' before the teardown rather than after it. What happens in Multi-View is
    ' Multi-View's business: it is a different component with its own files and
    ' it does not scrobble, so as far as Trakt and Simkl are concerned this
    ' viewing stopped here, at the position it stopped at.
    scrobbleStop()
    m.saveTimer.control = "stop"
    if m.sleepTimer <> invalid
        m.sleepTimer.control = "stop"
        m.sleepTimer = invalid
    end if
    m.trickTimer.control = "stop"
    m.scrubHoldTimer.control = "stop"
    m.hideTimer.control = "stop"
    m.stepDwellTimer.control = "stop"
    m.endTimer.control = "stop"
    closeSubsSearch()
    stopLiveHealth()
    ' Same omission as closePlayer had, and worse on this path: Multi-View is
    ' about to open a Video of its own, and Roku allows exactly ONE playing
    ' instance per channel. A retry armed for the channel being handed over
    ' would fire four to twelve seconds later, call startPlayback on a player
    ' that is no longer on screen, and ask for a second decoder the box will
    ' refuse (`only one playing instance supported, code=-5`) — after having
    ' already spent the connection at the provider. See closePlayer for the
    ' full argument; this is the same one line.
    m.retryTimer.control = "stop"
    releaseDiagTask()
    stopNowPlaying()
    closeUpNext()
    m.video.control = "stop"
    ' Cleared on this path too — it is the second and last place `closed` is
    ' set. The Multi-View grid that opens next plays video of its own and
    ' could reasonably re-pause the effects, but MultiViewScreen is not this
    ' lane and its own full-screen opaque background already covers them,
    ' so leaving the flag set here would only risk stranding it.
    m.global.fxPaused = false

    ' The scene has to be taken BEFORE closing. Setting `closed` hands this
    ' node to its parent to remove, and a node that has been removed answers
    ' invalid to getScene() — so asking afterwards is asking too late.
    scene = m.top.getScene()
    if scene = invalid then return
    launcher = scene.createChild("PlayerMultiView")
    launcher.seedJson = FormatJson(seed)
    KLog("player", "multiview: handing over " + ToStr(seed.title))

    ' The teardown contract, unchanged and still the only way out of here:
    ' every one of the nine openers observes `closed`, removes this node from
    ' the scene and puts focus back on itself.
    m.top.closed = true

    ' Started AFTER the close so the picker takes focus last, whichever order
    ' the parent's teardown ran in. `launcher` is a local reference to a node
    ' the SCENE owns, so it is untouched by this player going away.
    launcher.start = true
end sub

' What was playing, as a Multi-View slot.
'
' Live goes through MvLiveSlot so a channel handed over from here is built by
' exactly the same rules as one handed over from the channel hub — source
' routing, the pre-rewrite raw url for the guide lookup, provider id.
'
' VOD is built here because MvMovieSlot/MvEpisodeSlot rebuild the address from
' provider credentials, and this player already HAS the finished address it is
' playing. Note what the slot cannot carry: MultiViewRules records, on purpose,
' that there is no startAt field, so a film handed to Multi-View starts from
' the beginning. Adding one means editing MultiViewRules, which is not this
' job's to edit.
function multiViewSeed() as dynamic
    if m.top.isLive
        s = MvLiveSlot(m.top.channel)
        if s <> invalid then return s
        ' A channel row that cannot be rebuilt (a deep link, an event feed)
        ' still has the address this player was handed.
        if m.top.streamUrl = "" then return invalid
        return {
            id: "live::" + m.top.streamUrl
            title: m.top.titleText
            subLine: ""
            url: m.top.streamUrl
            raw: m.top.streamUrl
            fmt: m.top.streamFormat
            isLive: true
            logo: ""
            streamId: ""
            src: ""
            provId: ""
        }
    end if

    if m.top.streamUrl = "" then return invalid
    kind = "vod"
    id = ""
    src = ""
    idn = vodIdentity()
    if idn <> invalid
        id = idn.id
        src = idn.src
        if idn.kind = "ep" then kind = "episode"
    end if
    title = m.top.histTitle
    if title = "" then title = m.top.titleText
    line = m.top.subText
    if line = "" then line = "Film"
    slotId = kind + ":" + src + ":" + id
    if id = "" then slotId = kind + ":" + m.top.streamUrl
    provId = ""
    p = ProviderForSrcToken(src)
    if p = invalid then p = ActiveProvider()
    if p <> invalid then provId = ToStr(GetField(p, "id"))
    return {
        id: slotId
        title: title
        subLine: line
        url: m.top.streamUrl
        raw: m.top.streamUrl
        fmt: m.top.streamFormat
        isLive: false
        logo: m.top.posterUrl
        streamId: id
        src: src
        provId: provId
    }
end function

' The source and id of the VOD being played, read back out of resumeKey —
' the one field that names the EPISODE rather than its series (parentId names
' the series, which is right for a favorite and wrong for a pane).
'
'     "<profile>|ep:<src>~<id>"   /   "movie:<src>~<id>"
'
' Split at the first "|" then the first ":", for the same reason favTarget
' does: a source token ("xt:12") carries a colon of its own.
function vodIdentity() as dynamic
    key = m.top.resumeKey
    if key = "" then return invalid
    bar = Instr(1, key, "|")
    if bar > 0 then key = Mid(key, bar + 1)
    at = Instr(1, key, ":")
    if at <= 0 then return invalid
    kind = Left(key, at - 1)
    parts = SplitSrcQualifiedId(Mid(key, at + 1))
    if parts.id = "" then return invalid
    return { kind: kind, id: parts.id, src: parts.src }
end function

' ---- Next / previous episode (GAP A5) ---------------------------------------
'
' Android's two buttons (vod_player_screen.dart:1101-1102 -> _playAdjacentEpisode
' -> adjacentEpisodeArgs in data/viewmodels/episode_navigation.dart). That
' function is worth reading before this one, because this is the same design:
' re-resolve the SERIES from the episode's parent reference, flatten every
' season into one list in watch order, find where we are, step, and re-open
' the player on the new address. Android does it in the player for the same
' reason it is done here — the player is reached from a detail page, from
' Continue Watching and from watch history, and only one of those three knows
' anything about a season list.
'
' THE ORDERING IS SeriesDetailScreen's ORDERING, DELIBERATELY. That screen
' owns it (onInfo builds m.seasons: season numbers sorted NUMERICALLY, seasons
' with no episodes dropped, episodes left in the order the panel sent them),
' and nextEpisodeAfter defines "next" as the next row of this season, else the
' first of the season after. Flattening the same seasons in the same order
' gives exactly that rule with one index step, which is also how Android
' expresses it. That file is read-only here, so the shape is copied — the same
' bargain, and for the same reason, as the now-playing block copies the
' channel page's EPG resolve.
'
' WHAT IT COSTS THE PANEL. One get_series_info, and only if the member
' actually presses one of these buttons. It is NOT fetched at start: the
' overwhelming majority of viewings never touch these, and the series page
' the member just came from made this very call seconds ago — a second copy
' fired automatically, per episode, is exactly the repeat-request pattern
' Util.brs:305-310 says gets an IP banned. Asked for once, on demand, and
' kept for the life of the player.
'
' THE DWELL. Every step is a real re-tune (2-5s, Wiki/Roku/Roku - One Video
' Limit (Measured).md). Presses are added up and spent 0.9s after the last
' one, and a step is never started while the previous one is still opening —
' so hammering the button five times is ONE new connection, not five.

' Does this player have episode buttons at all? Android's gate exactly
' (vod_player_screen.dart:990): the thing playing is an episode and its
' parent reference names a series.
function episodeNavOk() as boolean
    if m.top.isLive then return false
    if m.top.parentId.left(7) <> "series:" then return false
    idn = vodIdentity()
    if idn = invalid then return false
    return idn.kind = "ep"
end function

' The provider this series belongs to — its OWN source first, the active one
' only as a fallback, the same rule nowPlayingProvider and favTarget follow.
function episodeProvider() as dynamic
    p = ProviderForSrcToken(m.epSrc)
    if p = invalid then p = ActiveProvider()
    return p
end function

' A button press — EPISODE or CHANNEL, one collector for both. Collected,
' never acted on here. m.epNav (VOD) and m.chNav (live) can never both be
' true, so there is no ambiguity about what a press means.
sub stepStream(delta as integer)
    if not m.epNav and not m.chNav then return
    ' A scan or a held scrubber belongs to the thing being left behind.
    stopTrick()
    stopScrubHold()
    m.stepPending = m.stepPending + delta
    if m.stepPending = 0
        ' Pressed both ways before the dwell ran out — the member changed
        ' their mind, so nothing is spent.
        m.stepDwellTimer.control = "stop"
        m.status.visible = false
        showControls()
        return
    end if
    if m.chNav
        ' Name where they will land, so arrowing along the lineup reads like
        ' a channel list and not like a loading message. This walks nothing —
        ' it is one index into a list already in hand.
        m.status.text = ToStr(GetField(m.chOrder[chStepTarget()], "name"))
    else if m.stepPending > 0
        m.status.text = "Next episode..."
    else
        m.status.text = "Previous episode..."
    end if
    m.status.visible = true
    m.stepDwellTimer.control = "stop"
    m.stepDwellTimer.control = "start"
    showControls()
end sub

' The dwell fired. One timer, so one handler that routes.
sub commitStep()
    if m.chNav
        commitChannelStep()
    else
        commitEpisodeStep()
    end if
end sub

' The presses have stopped. Spend them — once.
sub commitEpisodeStep()
    if m.stepPending = 0 then return
    ' Still opening the last one. Wait for it rather than stacking a second
    ' connection on top of the first; the dwell simply goes round again.
    ' Bounded, because a stream that hangs in "buffering" forever never
    ' reports either "playing" or an error — and a wait with no end would
    ' leave this timer going round for as long as the player is up.
    if m.stepSwitching and m.stepWaits < 12
        m.stepWaits = m.stepWaits + 1
        m.stepDwellTimer.control = "start"
        return
    end if
    m.stepSwitching = false
    m.stepWaits = 0
    if m.epOrder = invalid
        ' First press of the session: we need the season list before we can
        ' say what "next" is. Say so — this is the one slow press.
        m.status.text = "Finding the next episode..."
        m.status.visible = true
        loadEpisodeOrder()
        return
    end if
    if m.epOrder.count() = 0
        episodeNavUnavailable("Couldn't get this series' episode list.")
        return
    end if
    if m.epIdx < 0
        ' The list came back, but the episode playing is not in it — the panel
        ' has changed the show since it was opened, or this was a deep link
        ' into an episode the series no longer lists.
        episodeNavUnavailable("Couldn't find this episode in the series.")
        return
    end if
    target = m.epIdx + m.stepPending
    over = (target >= m.epOrder.count())
    under = (target < 0)
    ' Clamped, not refused. Presses were added up while the dwell ran, so
    ' asking for five when three remain still means "go as far as you can" —
    ' one press per step, which is what Android would have done with the same
    ' five presses. Only a step that goes NOWHERE says so.
    if over then target = m.epOrder.count() - 1
    if under then target = 0
    m.stepPending = 0
    if target = m.epIdx
        ' Android says exactly this, in a snackbar (vod_player_screen.dart:622).
        if under then m.status.text = "No previous episode" else m.status.text = "No next episode"
        m.status.visible = true
        showControls()
        return
    end if
    playEpisodeAt(target)
end sub

' Ask the panel for the season list. One task at a time, one per player.
sub loadEpisodeOrder()
    if m.epTask <> invalid then return   ' already asking; onEpisodeOrder finishes the job
    ' "series:<src>~<id>" — split off the leading "series:" and then the
    ' source token, the same two-step favTarget does (a source token carries
    ' a colon of its own, so a plain split would give three pieces).
    parts = SplitSrcQualifiedId(Mid(m.top.parentId, 8))
    if parts.id = ""
        episodeNavUnavailable("Couldn't work out which series this is.")
        return
    end if
    m.epSeriesId = parts.id
    m.epSrc = parts.src
    p = episodeProvider()
    if p = invalid or ToStr(p.ptype) = "m3u"
        ' A playlist has no series API to ask. Nothing to step through.
        episodeNavUnavailable("This source doesn't list episodes.")
        return
    end if
    ' A member's own Jellyfin or Emby server. It CAN list a show's episodes —
    ' one request, MsEpisodesUrl — but not through the two lines below, and
    ' getting this wrong is worse than not doing it: XtreamApiUrl puts the
    ' username and password in the query string, so firing it at a media
    ' server would write the member's Jellyfin password into their own
    ' server's access log for an address that answers 404 anyway.
    '
    ' The series page still plays the next episode when one finishes (it owns
    ' auto-play-next off `ended` and has the whole show in hand); what is
    ' missing is only the prev/next EPISODE buttons inside the player. Left as
    ' a follow-up rather than half-built here.
    if MsIsMediaServer(p)
        episodeNavUnavailable("Stepping between episodes isn't available for this server yet. Go back to the show to pick another episode.")
        return
    end if
    t = CreateObject("roSGNode", "ApiTask")
    t.url = XtreamApiUrl(p, "get_series_info") + "&series_id=" + UrlEncode(m.epSeriesId)
    t.observeField("result", "onEpisodeOrder")
    m.epTask = t
    t.control = "RUN"
    KLog("player", "episode nav: asking for the season list of series " + m.epSeriesId)
end sub

' There is no list to step through, and there never will be for this player.
' An EMPTY list rather than invalid, so nothing asks the panel again — and the
' waiting press is dropped, because it can never be spent.
sub episodeNavUnavailable(why as string)
    m.epOrder = []
    m.epIdx = -1
    m.stepPending = 0
    m.status.text = why
    m.status.visible = true
    KLog("player", "episode nav: " + why)
    showControls()
end sub

' Flatten the answer into watch order. Same reading as SeriesDetailScreen
' .onInfo, and it must stay that way: the two disagreeing about what follows
' what would show up as the player and the Up Next card naming different
' episodes.
sub onEpisodeOrder(event as object)
    res = event.getData()
    m.epTask = invalid
    out = []
    if res <> invalid and res.ok = true
        epsBySeason = GetField(res.data, "episodes")
        if epsBySeason <> invalid and type(epsBySeason) = "roAssociativeArray"
            nums = []
            for each k in epsBySeason
                nums.push(ToInt(k))
            end for
            nums.sort()
            for each n in nums
                for each e in ToArray(epsBySeason[n.toStr()])
                    epTitle = ToStr(GetField(e, "title"))
                    if epTitle = "" then epTitle = "Episode " + ToStr(GetField(e, "episode_num"))
                    out.push({
                        id: ToStr(GetField(e, "id"))
                        title: epTitle
                        season: n
                        epNum: ToInt(GetField(e, "episode_num"))
                        ext: ToStr(GetField(e, "container_extension"))
                    })
                end for
            end for
        end if
    end if
    m.epOrder = out

    ' Where we are. The episode id comes out of resumeKey, which is the one
    ' field that names the EPISODE (parentId names its series).
    m.epIdx = -1
    idn = vodIdentity()
    if idn <> invalid
        for i = 0 to out.count() - 1
            if out[i].id = idn.id
                m.epIdx = i
                exit for
            end if
        end for
    end if
    KLog("player", "episode nav: " + out.count().toStr() + " episode(s), currently at index " + m.epIdx.toStr())

    if m.stepPending <> 0
        ' The press that triggered the fetch is still waiting to be spent.
        commitEpisodeStep()
    else
        m.status.visible = false
    end if
end sub

' Open the episode at a given index in the SAME player node.
'
' Re-pointing this node rather than opening a new one is deliberate and is
' already how Refresh works (activateButton, "refresh"): startPlayback builds
' a fresh ContentNode from the interface fields and explicitly forgets the
' last title's position, which its own comment says is there for exactly this
' — "so does the next episode when Shuffle Episodes queues one".
sub playEpisodeAt(i as integer)
    if m.epOrder = invalid or i < 0 or i >= m.epOrder.count() then return
    p = episodeProvider()
    if p = invalid then return
    e = m.epOrder[i]
    if ToStr(e.id) = "" then return

    ' ---- THE ADDRESS IS BUILT BEFORE ANYTHING IS TORN DOWN ------------------
    '
    ' It used to be built two thirds of the way down this sub, AFTER the
    ' episode being left had already had its position saved, its scrobble
    ' stopped and the video node stopped. XtreamSeriesEpisodeUrl answers ""
    ' rather than halting the app when the source has no panel address (see
    ' Util.brs, LOG KEY FCF117), and "" walked straight through: startPlayback
    ' refuses an empty url and returns before the video node is given anything
    ' at all, so no "playing" and no "error" ever came back.
    '
    ' WHAT THE MEMBER WOULD HAVE SEEN: they press Next Episode, whatever they
    ' were watching stops, the next episode's name appears across the bottom
    ' of the screen — and nothing ever starts. Pressing Next again looks dead
    ' for about ten seconds before the player will accept it (commitEpisodeStep
    ' waits up to twelve dwells for a change that is never going to land), and
    ' the episode they were happily watching is gone.
    '
    ' So: ask for the address first, and if there isn't one, leave the member
    ' exactly where they are and say so. Nothing below this point runs, which
    ' also keeps the Continue Watching list honest — m.epIdx and the resume key
    ' are not moved onto an episode that never played.
    url = XtreamSeriesEpisodeUrl(p, ToStr(e.id), ToStr(e.ext))
    if url = ""
        ' Provider-level, never episode-level: the builder only comes back
        ' empty when the source itself has no panel address, so no episode of
        ' this show can be stepped to. episodeNavUnavailable says it once and
        ' stops offering — and asks the panel for nothing, which is the point.
        episodeNavUnavailable("Couldn't open that episode.")
        return
    end if

    ' The spot in the episode being LEFT, before anything is torn down —
    ' Android saves progress on this path too (_playAdjacentEpisode:626).
    ' Never after it FINISHED, though: onVideoState has already marked it
    ' watched and thrown its resume point away, and m.video.position is not
    ' dependable once playback has stopped — writing one back here would put
    ' a finished episode into Continue Watching at whatever number the
    ' stopped player happened to be holding.
    if m.video.state <> "finished" then saveProgress()

    ' And the same for Trakt and Simkl: the episode being LEFT gets its stop
    ' before the fields underneath it change, then the flags are cleared so
    ' the next episode is a fresh playback with its own single start. Guarded,
    ' so an episode that ran to "finished" and queued the next one from the Up
    ' Next card does not report a second stop here.
    scrobbleStop()
    scrobbleReset()

    m.epIdx = i
    m.epNavUsed = true
    m.stepSwitching = true
    m.stepWaits = 0
    m.retries = 0
    m.video.control = "stop"

    key = ResumeKeyEpisode(ToStr(e.id), m.epSrc)
    startAt = 0
    ' Episodes auto-resume where you left off — the same rule the series page
    ' applies for an ordinary (non-shuffled) pick.
    r = LoadResume(key)
    if r <> invalid then startAt = r.positionS

    code = "S" + epPad2(e.season) + "E" + epPad2(e.epNum)
    ' The show's name, remembered the FIRST time it is needed. titleText is
    ' rewritten below to "<show> - S01E04", so reading the fallback off it
    ' again on the next step would build "<show> - S01E04 - S01E05" and keep
    ' growing. histTitle is the show's name on both openers that set parentId,
    ' so the fallback is only ever reached by a caller that sets one and not
    ' the other — and now it is reached at most once.
    if m.epBaseTitle = invalid or m.epBaseTitle = ""
        m.epBaseTitle = m.top.histTitle
        if m.epBaseTitle = "" then m.epBaseTitle = m.top.titleText
    end if

    m.top.resumeKey = key
    m.top.resumeFrom = startAt
    m.top.subText = code
    m.top.titleText = m.epBaseTitle + " - " + code
    m.top.streamUrl = url
    m.top.streamFormat = StreamFormatFor(url, ToStr(e.ext))

    ' A new file is a new set of tracks. Captions and soundtracks are read
    ' off the stream, so their indices mean nothing across a change — and
    ' the auto-captions preference gets to apply again, exactly as it would
    ' if the series page had opened a brand new player for this episode.
    ' The fetched subtitle goes off with them: startPlayback reads this
    ' episode's own remembered answer, and the last episode's file must not
    ' still be flagged on while it does.
    m.subTracks = []
    m.audioTracks = []
    m.ccSel = 0
    m.extSubOn = false
    m.ccAutoApplied = false

    KLog("player", "episode nav: " + code + " " + ToStr(e.title))
    startPlayback()
    m.status.text = code + "  " + ToStr(e.title)
    m.status.visible = true
end sub

function epPad2(n as integer) as string
    if n < 10 then return "0" + n.toStr()
    return n.toStr()
end function

' ---- Channel zapping (GAP A2) ----------------------------------------------
'
' WHAT IT IS. Android's live prev/next CHANNEL buttons (`_step(-1)` /
' `_step(1)`, exo_live_player_screen.dart:692). The queue held this open for
' months for one reason: this player is handed a url and a channel and never
' the list they came from, and the only other way to a list is a
' get_live_streams download at the moment a stream has just started — the
' banned request pattern. It is open now because the LIST COMES TO US:
' whichever screen the member was looking at publishes its display-ordered
' lineup on `m.global.liveLineup`, and this walks that. Nothing here
' downloads anything, ever.
'
' WHAT A LINEUP ROW LOOKS LIKE. The same shape LiveTvScreen already hands
' this player as `channel` — streamId, name, logo, url, src. Rows are read
' through GetField, so a row carrying extra fields or missing a logo is fine.
'
' NO LINEUP, NO BUTTONS. A missing field, an empty list, a list of one, or a
' list that does not contain the channel playing all end the same way:
' m.chNav stays false and buildButtons does not draw the two buttons at all.
' A button the member presses that does nothing is worse than no button.
'
' THE DWELL IS THE WHOLE SAFETY ARGUMENT and it is the SAME dwell episode
' stepping uses — one timer, one collected count (see stepStream). A channel
' change is a real 2-5s re-tune plus a fresh connection against the member's
' provider account, and firing one per press while somebody arrows along a
' lineup is precisely the burst an anti-share system bans for
' (Wiki/Roku/Roku - Anti-Share Bans.md). So presses are ADDED UP, the target
' moves with each one, and exactly ONE tune happens 0.9s after the last
' press. Twenty presses is one connection.
'
' ONE TUNE IN FLIGHT. commitChannelStep refuses to start a second change
' while the last one is still opening, and goes round the dwell again
' instead — Roku allows exactly one playing video instance
' (Wiki/Roku/Roku - One Video Limit (Measured).md) and `pause` does not
' release the decoder, only `stop` does. playChannelAt stops the video before
' it re-points this node.
'
' A DELIBERATE CHANGE IS NOT A RETRY. The reconnect ladder's three attempts
' belong to the stream being left behind. playChannelAt clears the counter
' and cancels any pending retry, so the new channel starts with its own
' budget and a stream the member zapped away from can never fire a reconnect
' at a channel they are no longer on. This asks the provider for FEWER
' connections than leaving the player and picking a channel again would.
'
' IT WRAPS, because Android wraps — `(index + delta + length) % length`
' (:696). Past the last channel is the first one.

' The identity a lineup row and the playing channel are matched on. It is
' never stored and never leaves this file, so it only has to be consistent
' with itself: source token plus stream id, falling back to the address for a
' playlist row that carries no id. Deliberately NOT MvLiveSlot's `id` — that
' one builds a play url, and building thousands of them to find one index
' would blow certification 3.5's 250ms.
function chKey(ch as dynamic) as string
    if ch = invalid then return ""
    sid = ToStr(GetField(ch, "streamId"))
    if sid = "" then sid = ToStr(GetField(ch, "stream_id"))
    if sid = "" then sid = ToStr(GetField(ch, "url"))
    if sid = "" then return ""
    return ToStr(GetField(ch, "src")) + "|" + sid
end function

' Find the lineup and our place in it. Called from startPlayback, so it runs
' on the first open, on a Refresh, on a reconnect and on a zap — but the walk
' itself happens ONCE per player: after that we already know the index, and
' a lineup can be thousands of rows.
sub bindChannelNav()
    if not m.top.isLive
        m.chNav = false
        m.chOrder = invalid
        m.chIdx = -1
        return
    end if
    ' Already bound and still standing on the row we think we are. Nothing to
    ' re-walk.
    if m.chNav and m.chOrder <> invalid and m.chIdx >= 0 and m.chIdx < m.chOrder.count()
        if chKey(m.chOrder[m.chIdx]) = chKey(m.top.channel) then return
    end if

    m.chNav = false
    m.chOrder = invalid
    m.chIdx = -1

    lineup = m.global.liveLineup
    if lineup = invalid then return
    if lineup.count() < 2 then return   ' a list of one is nowhere to step
    cur = chKey(m.top.channel)
    if cur = "" then return             ' a deep link with no channel behind it
    at = -1
    for i = 0 to lineup.count() - 1
        if chKey(lineup[i]) = cur
            at = i
            exit for
        end if
    end for
    if at < 0
        ' The lineup on m.global belongs to a different list from the one
        ' this channel came from (or it has been rebuilt since). Stepping
        ' from a position we cannot find would jump somewhere arbitrary, so
        ' there are no buttons.
        ' SAID ONCE PER CHANNEL, NOT ONCE PER PRESS. bindChannelNav runs on
        ' every remote press while a stream is up, so a member watching
        ' something that is not in the current folder's list — anything opened
        ' from Search, from favourites, or from a folder they have since left —
        ' printed this line over and over. Log duty 2026-09-18, key B888C3:
        ' fifteen copies of it in one crash tail. The tail only keeps the last
        ' few hundred bytes, so those fifteen copies pushed out the lines that
        ' would have said what the box was actually doing when it died. The
        ' condition is worth knowing once; repeating it costs us the evidence.
        say = cur + "|" + lineup.count().toStr()
        if m.chNavQuiet <> say
            m.chNavQuiet = say
            KLog("player", "channel nav: channel not in the published lineup (" + lineup.count().toStr() + " rows) — no zap buttons")
        end if
        return
    end if
    m.chOrder = lineup
    m.chIdx = at
    m.chNav = true
    KLog("player", "channel nav: lineup of " + lineup.count().toStr() + ", at index " + at.toStr())
end sub

' Where the presses collected so far would land. Wrapping, like Android's
' `_step`. BrightScript's MOD takes the sign of the dividend, so a run of
' Previous presses off the front needs the + n to come back round.
function chStepTarget() as integer
    if not m.chNav then return -1
    n = m.chOrder.count()
    t = (m.chIdx + m.stepPending) MOD n
    if t < 0 then t = t + n
    return t
end function

' The presses have stopped. Spend them — once.
sub commitChannelStep()
    if m.stepPending = 0 then return
    ' Still opening the last one. Wait for it rather than stacking a second
    ' connection on top of the first — Roku plays exactly one video at a
    ' time. Bounded, because a stream that hangs in "buffering" forever
    ' reports neither "playing" nor an error, and an unbounded wait would
    ' leave this timer going round for as long as the player is up.
    if m.stepSwitching and m.stepWaits < 12
        m.stepWaits = m.stepWaits + 1
        m.stepDwellTimer.control = "start"
        return
    end if
    m.stepSwitching = false
    m.stepWaits = 0
    target = chStepTarget()
    m.stepPending = 0
    if target < 0 or target = m.chIdx
        ' It wraps, so this only happens on a run of presses that comes back
        ' to where it started. Nothing to say and nothing to tune.
        m.status.visible = false
        showControls()
        return
    end if
    playChannelAt(target)
end sub

' Tune the channel at a given index in the SAME player node. Re-pointing this
' node rather than opening a new one is how Refresh and episode stepping both
' already work — startPlayback is the single funnel every play attempt goes
' through.
sub playChannelAt(i as integer)
    if m.chOrder = invalid or i < 0 or i >= m.chOrder.count() then return
    ' MvLiveSlot is the app's ONE rule for turning a channel row into a
    ' playable address — same source-before-active credential routing
    ' LiveTvScreen.onChannelSelected follows. Reused rather than copied so a
    ' channel zapped to is built exactly like one picked from the grid.
    slot = MvLiveSlot(m.chOrder[i])
    if slot = invalid
        ' A row with no address and no stream id. Refuse this one step
        ' rather than guessing at a neighbour.
        m.status.text = "Couldn't open that channel."
        m.status.visible = true
        showControls()
        return
    end if

    m.chIdx = i
    m.stepSwitching = true
    m.stepWaits = 0
    ' The ladder's budget belongs to the channel being left. See the block
    ' above: a deliberate change is not a retry, and a retry armed for the
    ' old channel must not fire at the new one.
    m.retries = 0
    m.retryTimer.control = "stop"
    ' `stop`, not `pause` — pause does NOT release the decoder.
    m.video.control = "stop"

    ' The same shape LiveTvScreen builds and hands over, built from the same
    ' fields, so a channel reached by zapping is indistinguishable from one
    ' opened off the grid — that matters for the favourite heart, for the
    ' now-playing line and for the Multi-View hand-over, all of which read
    ' m.top.channel. PushRecentChannel first, exactly as that screen does
    ' (it stamps `src` and the day onto the map it is given), and because
    ' Android records the channel change in history too (_playChannel:652).
    chAA = { streamId: slot.streamId, name: slot.title, logo: slot.logo, url: slot.raw, src: slot.src }
    PushRecentChannel(chAA)
    m.top.channel = chAA
    m.top.titleText = slot.title
    m.top.streamUrl = slot.url
    m.top.streamFormat = slot.fmt

    ' A new stream is a new set of tracks. Captions and soundtracks are read
    ' off the stream, so their indices mean nothing across a change, and the
    ' auto-captions preference gets to apply again — exactly as it would if
    ' the member had backed out and opened this channel from the grid. A live
    ' channel can never have a fetched subtitle, so that flag comes off here
    ' too rather than being left over from whatever was playing before.
    m.subTracks = []
    m.audioTracks = []
    m.ccSel = 0
    m.extSubOn = false
    m.ccAutoApplied = false

    KLog("player", "channel nav: tuning " + slot.title)
    startPlayback()
    m.status.text = slot.title
    m.status.visible = true
end sub

' ---- End of an episode, once these buttons have been used -------------------
'
' THE ONE PLACE THIS FEATURE TOUCHES ANOTHER SCREEN'S BEHAVIOUR, so it is
' written down in full.
'
' SeriesDetailScreen owns auto-play-next. It works off `ended`, which this
' player publishes when a title runs out, and off ITS OWN record of which
' episode it started (m.playingS / m.playingE, set in playEpisode). Those two
' numbers are the problem: if the member steps forward in here, that screen
' still believes the episode it launched is the one playing, so an `ended`
' from three episodes later would make it offer the episode after the FIRST
' one — an episode already watched. There is no way to correct it from here;
' that file is read-only for this job.
'
' So once a step has actually happened, this player stops publishing `ended`
' and runs the end of the episode itself, off the season list it already has.
' The card is the same card (UpNextOverlay), the countdown is the same five
' seconds, the "next" is the same next, and the preference switch is the same
' preference switch — the member cannot tell which one they are looking at.
' Nothing changes for a player that never had a button pressed: it publishes
' `ended` exactly as before, and Shuffle Episodes and auto-play-next carry on
' untouched. That is the common case by a wide margin.
'
' KNOWN AND ACCEPTED: pressing next or previous DURING a Shuffle Episodes run
' turns the rest of that run into ordinary sequential play, because this
' player is never told it is shuffling (the series page passes shuffle by
' starting each pick at zero, not by a field). Android keeps shuffle across
' these buttons because its player is handed a shuffle flag in its arguments
' (episode_navigation.dart:37) — matching that needs a field the openers set,
' which is a caller change. Backing out still stops the run exactly as it
' always did.
function playerOwnsEnd() as boolean
    return m.epNavUsed
end function

' Put the card up, if there is a next episode and the member wants one. Does
' nothing at the end of the show, which is exactly what SeriesDetailScreen's
' armAutoNext does there too — the player is left sitting on the finished
' stream until Back is pressed.
sub armOwnAutoNext()
    if m.upNext <> invalid then return
    if not GetPrefBool("pref_auto_play_next", true) then return
    if m.epOrder = invalid or m.epIdx < 0 then return
    nxt = m.epIdx + 1
    if nxt >= m.epOrder.count()
        KLog("player", "episode nav: that was the last episode - stopping")
        return
    end if
    e = m.epOrder[nxt]
    scene = m.top.getScene()
    if scene = invalid then return
    ov = scene.createChild("UpNextOverlay")
    ov.epLabel = "S" + epPad2(e.season) + "E" + epPad2(e.epNum) + "  " + ToStr(e.title)
    ov.observeField("result", "onOwnUpNext")
    m.upNext = ov
    ov.setFocus(true)
    ov.start = true
    KLog("player", "episode nav: up next is S" + epPad2(e.season) + "E" + epPad2(e.epNum))
end sub

sub onOwnUpNext()
    res = ""
    if m.upNext <> invalid
        res = ToStr(m.upNext.result)
        closeUpNext()
    end if
    if res = "play"
        playEpisodeAt(m.epIdx + 1)
        m.top.setFocus(true)
        return
    end if
    ' "Back to Episodes" — the card's second button says what it does, so do
    ' it: leave the player the ordinary way and let whoever opened it tidy up
    ' and take focus back.
    closePlayer()
end sub

sub closeUpNext()
    if m.upNext = invalid then return
    scene = m.top.getScene()
    if scene <> invalid then scene.removeChild(m.upNext)
    m.upNext = invalid
end sub

' ---- Sleep timer (T2) -------------------------------------------------------
' Same picker overlay as subtitles: Off + minute choices, current choice
' tagged Active. When it fires: save the spot, stop the stream, close the
' player — the TV goes quiet instead of playing all night.

sub openSleepTimer()
    m.sleepChoices = [0, 15, 30, 45, 60, 90, 120]
    labels = ["Off"]
    for i = 1 to m.sleepChoices.count() - 1
        labels.push(m.sleepChoices[i].toStr() + " minutes")
    end for
    cur = 0
    if m.sleepSel <> invalid then cur = m.sleepSel
    marks = []
    for i = 0 to labels.count() - 1
        if i = cur then marks.push("Active") else marks.push("")
    end for
    pk = m.top.getScene().createChild("SubtitlePickerScreen")
    pk.titleText = "Sleep Timer"
    pk.marks = marks
    pk.startIndex = cur
    pk.labels = labels
    pk.observeField("closed", "onSleepPicked")
    m.sleepPicker = pk
    pk.setFocus(true)
end sub

sub onSleepPicked()
    if m.sleepPicker = invalid then return
    if m.sleepPicker.picked = true
        idx = m.sleepPicker.chosen
        m.sleepSel = idx
        if m.sleepTimer <> invalid
            m.sleepTimer.control = "stop"
            m.sleepTimer = invalid
        end if
        if idx > 0
            mins = m.sleepChoices[idx]
            t = createObject("roSGNode", "Timer")
            t.duration = mins * 60
            t.repeat = false
            t.observeField("fire", "onSleepFire")
            t.control = "start"
            m.sleepTimer = t
            m.status.text = "Sleep timer: stopping in " + mins.toStr() + " minutes"
            m.status.visible = true
        else
            m.status.visible = false
        end if
    end if
    m.top.getScene().removeChild(m.sleepPicker)
    m.sleepPicker = invalid
    ' The timer button goes orange while one is armed (Android's bedtime vs
    ' bedtime_outlined), so the row has to be repainted after a choice.
    redrawButtons()
    m.top.setFocus(true)
    showControls()
end sub

sub onSleepFire()
    KLog("player", "sleep timer fired — stopping playback")
    closePlayer()
end sub

' ---- Leaving -----------------------------------------------------------------

' The ordinary way out, in one place. Three things reach it — the second Back
' press, the sleep timer, and "Back to Episodes" on the Up Next card — and
' they were drifting apart: each new timer added to this player had to be
' remembered in every one of them, and the health timers of GAP A4 would have
' made that three more chances to leave one running behind a dead screen.
'
' The teardown contract itself is UNCHANGED and still the only way out:
' `closed` goes true, and every one of the nine openers removes this node from
' the scene and puts focus back on itself.
sub closePlayer()
    saveProgress()
    ' Trakt and Simkl, before anything is torn down and well before `closed`
    ' hands this node to its parent to be removed — getScene() answers invalid
    ' after that, and the task this fires needs the scene to hang on to. Once
    ' only: the guard is in scrobbleStop, so a film that already reported
    ' "finished" does not report a second stop on the Back press.
    scrobbleStop()
    m.saveTimer.control = "stop"
    m.stepDwellTimer.control = "stop"
    m.trickTimer.control = "stop"
    m.scrubHoldTimer.control = "stop"
    m.hideTimer.control = "stop"
    m.endTimer.control = "stop"
    closeSubsSearch()
    stopLiveHealth()
    ' AND THE RECONNECT TIMER, which is the one that costs a connection.
    ' stopLiveHealth above only covers the two watchdogs; m.retryTimer is armed
    ' separately by armRetry and is wired straight to startPlayback (init:264),
    ' so it was the one timer this sub left running. A member who pressed Back
    ' while "Stream hiccup — reconnecting" was on screen got the stream opened
    ' again four, eight or twelve seconds later on a player already removed
    ' from the scene: a connection taken against their provider that nobody is
    ' watching, which is precisely the traffic shape that got this house's own
    ' access banned (Util.brs:305-310). It also put m.global.fxPaused back to
    ' true (startPlayback:938) after the line below had cleared it, so Home's
    ' background effects stayed off for the rest of the session with nothing
    ' left running to turn them back on. Traced from crash report R3; reasoned
    ' from the source and not yet watched on a box.
    m.retryTimer.control = "stop"
    ' The panel diagnosis, if one is outstanding. The observer on it is a hard
    ' reference from an orphan node back to this screen — see releaseDiagTask.
    releaseDiagTask()
    stopNowPlaying()
    closeUpNext()
    if m.sleepTimer <> invalid
        m.sleepTimer.control = "stop"
        m.sleepTimer = invalid
    end if
    m.video.control = "stop"
    ' The grid comes back. Cleared HERE rather than off the video state,
    ' because a state observer is not guaranteed to run before `closed`
    ' hands this node to its parent to remove — and a player that exits
    ' without clearing this leaves the member with no wash until relaunch.
    ' This sub is the funnel for Back, an error, the sleep timer, the end of
    ' an episode and "Back to Episodes"; the Multi-View hand-over is the only
    ' other place `closed` is set and it clears the flag too.
    m.global.fxPaused = false
    m.top.closed = true
end sub

' ---- Visibility -------------------------------------------------------------

' How long the control bar stays on screen, in seconds — JB-10.
'
' Mason, 2026-09-17: "add a option in settings -> playback -> add a option to
' choose how long the player controls show before they fade out - 5s, 10s,
' 15s." Three choices, no "never", and the value itself lives in Store.brs
' (ControlsTimeoutSecs, Nia's) because Settings owns it.
'
' TWO GUARDS, and both are here because this runs before any picture is on:
'
'  1. The try/catch. ControlsTimeoutSecs() is in Store.brs, which this
'     component's XML names, so it resolves today — but a component only
'     ever sees the scripts its own XML names, and the day somebody trims
'     that list the call would not fail politely: it would kill the render
'     thread and leave the member looking at a spinner that never stops
'     (PosterCard shipped exactly that once). A player that opens with the
'     default is a far smaller problem than a player that does not open.
'  2. The clamp. Store already holds the value to the three choices, so this
'     is belt and braces rather than the only check — but the number here
'     arms a timer, and a zero would hide the bar on the same frame it
'     appeared while a huge one would leave it over the picture for good.
'     Neither is recoverable with the remote, so the player refuses to arm
'     anything that is not one of Mason's three.
function controlsHideSeconds() as integer
    secs = 0
    try
        secs = ControlsTimeoutSecs()
    catch e
        ' Not a crash worth filing — it is the expected state until the
        ' Settings half lands, and the player carries on perfectly well.
        KLog("player", "controls timeout setting not available yet - using 5 seconds")
        secs = 0
    end try
    if secs = 5 or secs = 10 or secs = 15 then return secs
    return 5
end function

sub showControls()
    m.controls.visible = true
    redrawButtons()
    m.hideTimer.control = "stop"
    m.hideTimer.control = "start"
end sub

sub hideControls()
    if m.video.state = "paused" then return
    if m.scrubbing or m.tricking then return ' don't hide mid-seek
    m.controls.visible = false
    ' A one-off note that came up with the controls goes down with them.
    ' Only ever set for news the member does not have to act on — today
    ' that is the "downloads left today" line after a subtitle is fetched.
    if m.statusTransient = true
        m.statusTransient = false
        m.status.visible = false
    end if
    ' Next reveal starts on the button row.
    m.focusArea = "buttons"
    if not m.top.isLive then drawSeek(m.video.position)
end sub

' ---- Actions ----------------------------------------------------------------

sub activateButton()
    b = m.buttons[m.focusedBtn]
    ' In trickplay, OK on Play (or the play/pause button) lands the scan.
    if m.tricking and b.key = "playpause"
        commitTrick()
        return
    end if
    if b.key = "playpause"
        if m.video.state = "playing"
            m.video.control = "pause"
        else if m.video.state = "paused"
            m.video.control = "resume"
        end if
    else if b.key = "mute"
        m.video.mute = not m.video.mute
    else if b.key = "refresh"
        ' The ladder's budget belongs to the attempt being ABANDONED — the same
        ' rule as the channel zap (playChannelAt:4206-4210) and the same two
        ' lines. Clearing the count without stopping the timer was only half of
        ' it: a Refresh pressed two seconds into a reconnect wait re-tuned
        ' immediately AND let the armed retry fire at the new attempt a moment
        ' later, so the member asked for one connection at their panel and it
        ' took two. Three sites now say this one rule — here, playChannelAt,
        ' and the teardowns in closePlayer and openMultiView.
        m.retries = 0
        m.retryTimer.control = "stop"
        ' VOD: re-tune at the current spot (fixes post-seek stutter without
        ' losing your place). Live: just re-tune.
        if not m.top.isLive then m.top.resumeFrom = m.video.position
        m.video.control = "stop"
        startPlayback()
    else if b.key = "favorite"
        if m.top.isLive
            ch = m.top.channel
            if ch <> invalid then ToggleFavoriteChannel(ch)
        else if m.favTarget <> invalid
            ' The SAME store helper the movie and series pages call, with the
            ' same item shape — favorites written from the player have to be
            ' indistinguishable from favorites written from a detail page, or
            ' the poster hearts and the Home row disagree with each other.
            ToggleFavoriteVod({ kind: m.favTarget.kind, id: m.favTarget.id, name: m.favTarget.name, icon: m.favTarget.icon, ext: m.favTarget.ext, src: m.favTarget.src })
        end if
        refreshFavState()
    else if b.key = "rewind"
        startTrick(-1)
    else if b.key = "forward"
        startTrick(1)
    else if b.key = "prevep" or b.key = "prevch"
        stepStream(-1)
    else if b.key = "nextep" or b.key = "nextch"
        stepStream(1)
    else if b.key = "cc"
        openCaptions()
    else if b.key = "audio"
        openAudioTracks()
    else if b.key = "sleep"
        openSleepTimer()
    else if b.key = "multiview"
        openMultiView()
        return  ' this player is on its way out — don't touch it again
    end if
    redrawButtons()
    showControls()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    ' Key RELEASE: stop the held scrubber (only thing that cares).
    if not press
        if (key = "left" or key = "right") and m.scrubHoldDir <> 0
            stopScrubHold()
            return true
        end if
        return false
    end if

    if key = "back"
        ' Trickplay active: Back lands the scan instead of exiting.
        if m.tricking
            commitTrick()
            return true
        end if
        ' Two-stage Back: dismiss the control bar first; a second press
        ' (controls hidden) leaves the stream.
        if m.controls.visible
            m.hideTimer.control = "stop"
            m.controls.visible = false
            return true
        end if
        closePlayer()
        return true
    end if

    ' Play/pause remote button: lands a trickplay scan, else toggles pause.
    if key = "play"
        if m.tricking
            commitTrick()
        else if m.video.state = "playing"
            m.video.control = "pause"
        else if m.video.state = "paused"
            m.video.control = "resume"
        end if
        showControls()
        return true
    end if

    ' Dedicated transport keys on the remote (VOD only) drive trickplay,
    ' whether or not the control bar is showing.
    if not m.top.isLive
        if key = "rewind"
            startTrick(-1)
            return true
        else if key = "fastforward"
            startTrick(1)
            return true
        else if key = "instantreplay"
            seekToStart()
            return true
        end if
    end if

    if not m.controls.visible
        ' Bar hidden: reveal on any press (VOD Left/Right could also scrub,
        ' but revealing the bar first is clearer).
        if key = "OK" or key = "up" or key = "down" or key = "left" or key = "right"
            showControls()
            return true
        end if
        return false
    end if

    ' Seek bar has focus (VOD): hold Left/Right to scrub steadily, Down
    ' returns to the buttons.
    if m.focusArea = "seekbar"
        if key = "left"
            startScrubHold(-1)
            return true
        else if key = "right"
            startScrubHold(1)
            return true
        else if key = "down" or key = "OK"
            stopScrubHold()
            m.focusArea = "buttons"
            drawSeek(m.video.position)
            showControls()
            return true
        else if key = "up"
            return true
        end if
        return false
    end if

    ' Button row focus.
    if key = "left"
        if m.focusedBtn > 0 then m.focusedBtn = m.focusedBtn - 1
        showControls()
        return true
    else if key = "right"
        if m.focusedBtn < m.buttons.count() - 1 then m.focusedBtn = m.focusedBtn + 1
        showControls()
        return true
    else if key = "OK"
        activateButton()
        return true
    else if key = "up"
        ' Up jumps to the seek bar (VOD only) so you can scrub directly.
        if not m.top.isLive
            m.focusArea = "seekbar"
            drawSeek(m.video.position)
            showControls()
        end if
        return true
    else if key = "down"
        showControls()
        return true
    end if
    return false
end function

' ---- "Were you already partway through this somewhere else?" ----------------
'
' THE BUG THIS EXISTS FOR. Home draws about two seconds before the first sync
' cycle of the launch finishes. A film the member watched to 42:10 on their
' phone has no resume point on THIS box yet, so the box offers to play it from
' the beginning. If they take that offer, the position they were really at is
' overwritten by one that is honest, newer, and wrong — and their phone loses
' 42 minutes for good.
'
' WHY IT IS NOT FIXED ON THE WIRE. Android settled it and the merge rule is
' not changing: "most recently updated wins" is correct, because a member who
' deliberately rewinds to five minutes and a member who was SHOWN five minutes
' because the box had not synced yet produce byte-identical rows — same
' position, same honest timestamp, same device. Any rule strong enough to
' reject the second also refuses a genuine rewind. So the fix belongs on the
' device that is about to offer a starting point it has reason to doubt.
'
' WHY IT IS NOT FIXED BY DISABLING THE BUTTON. That was the obvious reading of
' "do not present a start point before the first cycle lands", and it makes
' every member on every launch wait on a dead Play button for a case that
' almost never applies to them. The film starts instantly, as it always did.
'
' WHAT HAPPENS INSTEAD. For the seconds between pressing Play and the cycle
' landing, this box does not WRITE. Nothing is destroyed while the answer is
' still outstanding. When the cycle lands one of two things is true:
'
'   - nothing came back for this title, which is the overwhelmingly common
'     case: the hold lifts, writing resumes, the member never knew.
'   - a real position came back: the film is already playing, so it asks —
'     "Resume from 42:10?" — and only then does anything get written.
'
' A member who answers "Start from the beginning" has now INTENTIONALLY chosen
' zero, which is exactly the case Mason's rule allows ("do not reset an
' existing playback position unless the user intentionally chooses to start
' from the beginning"). Their choice is written and it wins, correctly.
'
' ONLY ARMED WHEN IT CAN MATTER: VOD, started at zero, with a resume key, and
' only while the box has not yet heard from the locker this launch. Resuming
' from a stored point does not arm it — that point either came from here or
' came from the locker, and either way it is not the guess this guards.
sub armResumeVerification()
    m.resumeUnverified = false
    if m.top.isLive then return
    if m.top.resumeKey = "" then return
    if m.top.resumeFrom > 0 then return
    if m.global = invalid then return
    if m.global.syncPrimed = true then return
    m.resumeUnverified = true
    m.resumeHoldStartedAt = CreateObject("roDateTime").asSeconds()
    ' Observed on the node, not polled. Registered ONCE per player: this sub
    ' runs again for every retry and every episode step, and Roku will happily
    ' stack duplicate observers that then all fire.
    if m.resumeObserved <> true
        m.resumeObserved = true
        ' SCOPED, not plain. m.global lives for the life of the app and a plain
        ' observeField on it is a hard reference from the global node back to
        ' this screen - so a player that armed this and was then closed stayed
        ' alive, Video node and all, until the app exited. observeFieldScoped
        ' ties the registration to this node's own lifetime instead. Same
        ' defect as the poster and channel cards (see PosterCard.brs), found
        ' on the same sweep, 2026-09-14.
        m.global.observeFieldScoped("syncPrimed", "onSyncPrimedForResume")
    end if
end sub

' Is the hold still on? This is also where the hold EXPIRES.
'
' The expiry is the safety net and it is not decoration: markSyncPrimed covers
' a box with sync switched off, but a cycle that hangs rather than answering
' would leave the flag false for the rest of the session, and a hold that
' never lifts is a member whose resume points silently stop being saved. That
' is a worse bug than the one this fixes. Twenty seconds is far longer than
' the two the cycle really takes and far shorter than anything a member would
' notice, since the only thing riding on it is a write they cannot see.
function resumeStillUnverified() as boolean
    ' THE QUESTION IS ON SCREEN. Hold, with no expiry: the member is being
    ' asked whether they were already partway through this, and writing the
    ' answer's own subject out from under them while they read it is the exact
    ' data loss this whole mechanism exists to stop. They are looking at it, so
    ' nothing here is stuck.
    if m.resumePicker <> invalid then return true
    if m.resumeUnverified <> true then return false
    started = m.resumeHoldStartedAt
    if started = invalid then started = 0
    if CreateObject("roDateTime").asSeconds() - started >= 20
        m.resumeUnverified = false
        KLog("player", "gave up waiting for sync before saving this position - saving it now")
        return false
    end if
    return true
end function

' The cycle landed. Ask the resume store again — it may have gained a position
' for this very title in the last few seconds.
sub onSyncPrimedForResume()
    if m.resumeUnverified <> true then return
    if m.global = invalid or m.global.syncPrimed <> true then return
    ' Every path out of here from this point LIFTS the hold, except the one
    ' that puts the question on screen — that one hands the hold to the picker
    ' and onResumeOfferClosed lifts it. Nothing may return without doing one
    ' or the other, or this member's resume points stop being saved.
    m.resumeUnverified = false
    if m.top.isLive or m.top.resumeKey = "" then return

    r = LoadResume(m.top.resumeKey)
    if r = invalid then return
    landed = ToInt(r.positionS)
    if landed < 15 then return
    ' Where the member is NOW. They have been watching for a couple of seconds
    ' at most, but a title that opened on a stored point would not have armed
    ' this at all, so `here` is small by construction. The comparison is still
    ' made rather than assumed: offering to jump BACKWARDS to a point they are
    ' already past is worse than saying nothing.
    here = ToInt(m.video.position)
    if landed <= here + 30 then return
    ' Past 95% is a title the other device FINISHED. Nothing to offer.
    dur = ToInt(r.durationS)
    if dur > 0 and landed > Int(dur * 0.95) then return

    m.resumeOfferAt = landed
    pk = m.top.getScene().createChild("SubtitlePickerScreen")
    pk.titleText = "Carry on where you left off?"
    pk.noteText = "You were " + clockDuration(landed) + " into this on another device."
    pk.startIndex = 0
    ' labels LAST — setting it builds the list, so noteText and startIndex
    ' must already be there. Same rule the captions picker follows.
    ' Kept SHORT on purpose. A picker row is one un-wrapped line 332px wide and
    ' anything longer is clipped — "Start from the beginning" came back on the
    ' device as "Start from the begi...".
    pk.labels = ["Resume from " + clockDuration(landed), "Start over"]
    pk.observeField("closed", "onResumeOfferClosed")
    m.resumePicker = pk
    pk.setFocus(true)
    KLog("player", "another device had this " + clockDuration(landed) + " in - asked the member")
end sub

sub onResumeOfferClosed()
    if m.resumePicker = invalid then return
    ' Dismissed with Back rather than answered. Treat that as "leave it alone":
    ' the film carries on from where it is, and the next saveProgress writes
    ' that position — which is the same outcome as choosing to start over, and
    ' the member made the film play from zero themselves.
    if m.resumePicker.picked = true and m.resumePicker.chosen = 0
        target = ToInt(m.resumeOfferAt)
        if target > 0 then m.video.seek = target
    end if
    m.top.getScene().removeChild(m.resumePicker)
    m.resumePicker = invalid
    ' The hold is over either way. Whichever they chose is now the truth, and
    ' the next saveProgress is free to write it.
    m.resumeUnverified = false
    m.top.setFocus(true)
    showControls()
end sub

' ---- Scrobbling to Trakt and Simkl ------------------------------------------
'
' WHY THIS EXISTS. The Add-ons page already tells a signed-in member "What you
' watch here is now marked on Trakt as you watch it". Until this section, that
' sentence was not true on Roku — Trakt and Simkl were sign-in and nothing
' else, and the word "scrobble" did not appear anywhere in the app. This is the
' engine that makes the sentence true. The Settings rows that switch it on and
' the Home rows that show the result are other people's files; NOTHING below
' draws anything or stores anything.
'
' THE CONTRACTS ARE FIXED AND WRITTEN DOWN. Do not invent a shape here:
'   Wiki/Site/Site - Trakt Relay (trakt.php).md
'   Wiki/Site/Site - Simkl Relay (simkl.php).md
' POST to TraktUrl("scrobble") / SimklUrl("scrobble") with the MEMBER's own
' bearer token and the body
'   { action: "start"|"pause"|"stop", progress: 0-100,
'     movie: { tmdb } | episode: { show_tmdb, season, number }, app_version }
' Simkl takes the same body and ALSO accepts title/year on a movie and
' show_title on an episode, which is worth sending because a great deal of what
' our panels carry has a thin TMDB match at Simkl's end and the name is what
' rescues it. Both relays answer a repeat as a SUCCESS (duplicate:true), so a
' repeat is never an error and never something to tell a member about.
'
' NOTHING HERE EVER CALLS history_add. Both services mark the item watched
' THEMSELVES when a `stop` arrives at 80% or more — the Trakt note says so in
' as many words — so a history_add on top of it would mark the same film twice
' on the member's own account. The only thing history_add is for is a member
' ticking a checkmark by hand, which is not this file.
'
' THE FOUR RULES THIS SECTION IS BUILT ON.
'
'  1. LIVE NEVER SCROBBLES. A live channel has no TMDB id to key on, and
'     scrobbleTarget() refuses live IN ITS OWN RIGHT rather than trusting the
'     caller — the same way restartForSubtitle does, and for the same reason:
'     every one of these entry points is reached from more than one place.
'  2. NO ID, NO SCROBBLE, AND NOT A WORD ABOUT IT. Both services key on the
'     TMDB id. A name is a guess, and a guess here does not produce a poor
'     search result the member can ignore — it marks the WRONG FILM as watched
'     on their real account on a service we do not own, and they would have to
'     go and unpick it. So a title whose panel sent no id does nothing at all
'     and says nothing at all. m.top.tmdbId (film) and m.top.parentTmdbId (the
'     SHOW's id for an episode) are set by MovieDetailScreen and
'     SeriesDetailScreen, for media-server titles as well as panel ones.
'  3. NEVER ON THE RENDER THREAD. Every call goes out through AddOnTask, which
'     is the one node in this app that speaks to these relays.
'  4. A FAILURE IS SILENT. The member is watching a film. There is nothing they
'     can do about a refused scrobble and nothing here worth taking the picture
'     away for. AddOnTask logs the tag, the HTTP status and the relay's own
'     code on its own thread — that is the whole of the error handling, and it
'     is why nothing below observes a result.
'
' HOW OFTEN THIS TALKS TO THE SERVICES, which is the part that has to be right.
' ONE `start` per playback, ONE `pause` per real pause, ONE `stop`. A whole film
' is three requests per signed-in service. Specifically NOT once per attempt:
' the reconnect ladder re-enters startPlayback up to three times, a stream that
' rebuffers passes through "playing" again every time it recovers, and a
' Refresh press and a subtitle reopen both come back through startPlayback as
' well. So `start` is fired off the STATE CHANGE and then held down by
' m.scrobWatching, never fired from startPlayback. Simkl's whole-app allowance
' is 1,000 requests a day until they approve us; three per film per member is
' the budget this has to live inside.

' Is this service switched on for scrobbling?
'
' ScrobbleOn(service) is Nia's and lands in Store.brs beside the other
' per-profile preferences. Contract agreed with Dave: ONE argument, the
' service id as the lowercase string "trakt" or "simkl" — the same ids
' AddOnIds() uses — reading the registry key "pref_trakt_scrobble" /
' "pref_simkl_scrobble", DEFAULT TRUE. All lowercase, and that is not a style
' choice: BrightScript folds a field name written as code to lowercase while
' the same map read back out of storage is case-sensitive, and this app has
' had at least four live bugs from exactly that mismatch.
'
' HistoryOn(service) IS A DIFFERENT SWITCH and is deliberately not read here.
' It belongs to the checkmarks on the detail screens, and a member is allowed
' to have scrobbling on with checkmark filing off. Neither one implies the
' other; do not collapse them.
'
' UNTIL ScrobbleOn LANDS, signed in counts as on, which is what the Add-ons
' page already promises the member. The fallback comes out the day the real
' function is in the tree. The try/catch is the same guard
' controlsHideSeconds() uses for the same reason: a component only ever sees
' the scripts its own XML names, and calling a function it was not given does
' not fail politely — it kills the render thread and leaves the member looking
' at a stopped picture. A scrobble that quietly does not happen is a far
' smaller problem than a player that stops.
function scrobbleEnabled(svc as string) as boolean
    signedIn = false
    try
        signedIn = AddOnSignedIn(svc)
    catch e
        return false
    end try
    if not signedIn then return false
    try
        return ScrobbleOn(svc) = true
    catch e
        ' Expected until the Settings half lands. Said ONCE per player, not
        ' once per scrobble of every film — but said, because "is ScrobbleOn
        ' in the tree yet?" is a question the log should answer on the stick
        ' rather than one anybody has to reason about.
        if m.scrobPrefWarned <> true
            m.scrobPrefWarned = true
            KLog("addon", "ScrobbleOn() is not in this build - scrobbling follows the sign-in instead")
        end if
        return true
    end try
end function

' The member's own token, which is THEIRS: never drawn, never logged, never
' put in a URL and never on the KwickSync wire. It goes into AddOnTask's
' `bearer` field, from there into one Authorization header, and nowhere else.
function scrobbleToken(svc as string) as string
    tok = ""
    try
        acct = AddOnAccount(svc)
        if acct <> invalid then tok = ToStr(GetField(acct, "token"))
    catch e
        tok = ""
    end try
    return tok
end function

' What is playing, in the shape both relays take — or invalid, which means
' "do not scrobble this, and do not mention it".
'
' The episode branch is chosen off subText ("S01E03") exactly as the subtitle
' search chooses it, and it NEVER falls through to the movie branch when the
' show has no id. Falling through would take whatever happened to be in
' tmdbId and mark a film the member is not watching.
function scrobbleTarget() as dynamic
    if m.top.isLive then return invalid
    yr = ToStr(m.top.titleYear).trim()
    nums = subsEpisodeNumbers()
    if nums <> invalid
        showId = ToInt(ToStr(m.top.parentTmdbId).trim())
        if showId <= 0 then return invalid
        return { kind: "episode", id: showId, season: nums.season, number: nums.episode, name: subsTitleName(), year: yr }
    end if
    filmId = ToInt(ToStr(m.top.tmdbId).trim())
    if filmId <= 0 then return invalid
    return { kind: "movie", id: filmId, season: 0, number: 0, name: subsTitleName(), year: yr }
end function

' Which title the flags below belong to. This player node is REUSED for the
' next episode, so the flags have to be able to tell that the thing being
' scrobbled has changed underneath them.
function scrobbleKey(tgt as dynamic) as string
    if tgt = invalid then return ""
    return tgt.kind + ":" + tgt.id.toStr() + ":" + tgt.season.toStr() + ":" + tgt.number.toStr()
end function

' How far through, 0-100.
'
' Read off the last pair the player actually REPORTED, not off the live node.
' m.video.position is not dependable once playback has stopped (the "finished"
' handler says so in full), and `stop` is the one scrobble that matters most —
' it is the one both services turn into a watched mark at 80%.
'
' A title with no reported duration answers 0, deliberately. There is no known
' end to take a percentage of, and 0 tells both services "stopped at the
' start", which leaves no mark. That matches what this app does with the same
' title internally: markFinished also refuses to act without a duration.
function scrobbleProgress() as integer
    dur = m.lastDurS
    posS = m.lastPosS
    if dur <= 0
        dur = m.video.duration
        posS = m.video.position
    end if
    if dur <= 0 then return 0
    if posS < 0 then posS = 0
    if posS > dur then posS = dur
    pct = Int((posS * 100) / dur)
    if pct < 0 then pct = 0
    if pct > 100 then pct = 100
    return pct
end function

' A floor under the play/pause pair, and under nothing else.
'
' Mashing the play/pause button is the one way a member can generate requests
' as fast as they can press, and two services x one request a press is exactly
' the traffic shape neither service wants. `stop` is never held back: it is the
' scrobble that carries the final position, and the member is leaving.
'
' Held back means NOT SENT AND THE FLAG NOT MOVED, so what this app believes
' the services were told stays true. The consequence is written out where the
' flags are set.
function scrobbleTooSoon() as boolean
    if not m.scrobEver then return false
    if m.scrobLastAt <= 0 then return false
    nowS = CreateObject("roDateTime").asSeconds()
    return (nowS - m.scrobLastAt) < 2
end function

' ---- The three things that happen ---------------------------------------

' The picture is up. Fired from the "playing" state and NOT from startPlayback,
' because startPlayback runs again for every retry, every Refresh press and
' every subtitle reopen.
sub scrobbleStarted()
    if m.top.isLive then return
    tgt = scrobbleTarget()
    if tgt = invalid then return
    key = scrobbleKey(tgt)
    if key <> m.scrobKey
        ' A different title in the same player node — the next episode. Whoever
        ' changed it has already sent the stop for the old one.
        scrobbleReset()
        m.scrobKey = key
    end if
    ' The services already believe this member is watching. A rebuffer, a
    ' reconnect and a landed trickplay scan all come back through here.
    if m.scrobWatching then return
    ' This is a resume after a real pause rather than a first start. Still one
    ' request, still off one deliberate remote press — and without it the
    ' member's profile sits at "paused" for the rest of the film.
    if m.scrobEver and scrobbleTooSoon() then return
    m.scrobWatching = true
    m.scrobEver = true
    ' A film restarted after it finished is a new playback, so the stop that
    ' ends it has to be allowed to fire again.
    m.scrobStopped = false
    scrobbleSend("start")
end sub

' A REAL pause. Fired off the "paused" state, which is the one funnel the
' button, the remote's Play key and anything added later all pass through.
'
' Trickplay is NOT a pause. startTrick freezes the picture with control="pause"
' while the member scans, and m.tricking is set before it does — so a scan
' costs no requests, and the resume at the end of it costs none either, because
' the flag was never moved.
sub scrobblePause()
    if m.top.isLive then return
    if m.tricking then return
    if not m.scrobWatching then return
    if scrobbleTooSoon() then return
    m.scrobWatching = false
    scrobbleSend("pause")
end sub

' Playback ended, was left, or ran out. Once, whichever of the four callers
' gets here first.
sub scrobbleStop()
    if m.top.isLive then return
    ' Nothing was ever started, so there is nothing to stop and no reason to
    ' spend a request saying so.
    if not m.scrobEver then return
    if m.scrobStopped then return
    ' NOTHING WATCHED, NOTHING TO REPORT. A member who opens a film and leaves
    ' again within a few seconds is at 0%, and Trakt refuses that outright:
    ' measured on the office stick 2026-09-18, `scrobble-trakt-stop` came back
    ' 422 bad_request on a stop at 0%. It is also the right answer on its own
    ' terms — "they started it and stopped at the very beginning" is not news
    ' either service wants, and the `start` already told them the film was
    ' opened. The flag still moves, so nothing tries again later.
    if scrobbleProgress() <= 0
        m.scrobStopped = true
        m.scrobWatching = false
        return
    end if
    m.scrobStopped = true
    m.scrobWatching = false
    scrobbleSend("stop")
end sub

sub scrobbleReset()
    m.scrobKey = ""
    m.scrobWatching = false
    m.scrobEver = false
    m.scrobStopped = false
    m.scrobLastAt = 0
end sub

' ---- Sending ------------------------------------------------------------

sub scrobbleSend(act as string)
    ' Live says no here as well, rather than trusting the three subs above to
    ' have said it. This is the sub that spends a request.
    if m.top.isLive then return
    tgt = scrobbleTarget()
    if tgt = invalid then return
    pct = scrobbleProgress()
    ver = ""
    try
        ver = KwickAppVersion()
    catch e
        ver = ""
    end try
    sent = false
    for each svc in ["trakt", "simkl"]
        if scrobbleEnabled(svc)
            tok = scrobbleToken(svc)
            if tok <> ""
                ' EVERY KEY HERE IS ALREADY LOWERCASE, and it has to stay that
                ' way. A key written as code (body.episode) is folded to
                ' lowercase by BrightScript, while the relay reads the JSON
                ' case-sensitively — a field spelled showTmdb in this file
                ' would arrive as showtmdb and be silently ignored.
                reqBody = { action: act, progress: pct, app_version: ver }
                if tgt.kind = "episode"
                    epBody = { show_tmdb: tgt.id, season: tgt.season, number: tgt.number }
                    ' Simkl only. Trakt's relay takes the three fields above
                    ' and nothing else on an episode.
                    if svc = "simkl" and tgt.name <> "" then epBody.show_title = tgt.name
                    reqBody.episode = epBody
                else
                    mvBody = { tmdb: tgt.id }
                    if svc = "simkl"
                        if tgt.name <> "" then mvBody.title = tgt.name
                        if tgt.year <> "" then mvBody.year = ToInt(tgt.year)
                    end if
                    reqBody.movie = mvBody
                end if
                addr = SimklUrl("scrobble")
                if svc = "trakt" then addr = TraktUrl("scrobble")
                scrobbleFire(svc, act, addr, reqBody, tok)
                sent = true
            end if
        end if
    end for
    if sent then m.scrobLastAt = CreateObject("roDateTime").asSeconds()
end sub

' One request, fired and forgotten.
'
' TWO THINGS HERE ARE NOT ORDINARY AND BOTH ARE DELIBERATE.
'
'  1. THE TASK IS HUNG ON THE SCENE, not just held in this component's `m`.
'     The most important scrobble of the three is the `stop`, and the stop
'     fires on the way out — closePlayer sets `closed` immediately afterwards
'     and every one of the openers removes this node from the scene on that
'     field. A Task whose only reference lived in a destroyed component's `m`
'     would go with it, mid-request, and the member's film would never be
'     marked watched. The scene outlives the player, so the scene holds it.
'     Appended BEFORE control = "RUN", so the reference exists before the
'     thread does. NOT VERIFIED ON A TELEVISION — see the report.
'  2. THE RESULT IS NOT OBSERVED. An observer registered by this component
'     points back into a component that may be gone by the time the answer
'     lands. There is also nothing for it to do: a failure is silent by rule,
'     a duplicate is a success by contract, and AddOnTask already logs the
'     tag, the status and the relay's code from its own thread. The tag below
'     is what makes that line readable.
sub scrobbleFire(svc as string, act as string, addr as string, reqBody as object, tok as string)
    t = CreateObject("roSGNode", "AddOnTask")
    if t = invalid
        ' Only reachable in a build missing the task component.
        KLog("addon", "scrobble: AddOnTask is missing - " + svc + " " + act + " not sent")
        return
    end if
    scrobbleSweep()
    t.id = "kscrob"
    t.url = addr
    t.method = "POST"
    t.bodyJson = FormatJson(reqBody)
    t.bearer = tok
    ' Shorter than AddOnTask's 20s default. Nothing waits on this and nothing
    ' is retried, so a relay having a bad minute should let go of the thread
    ' rather than sit on it while the member watches the film.
    t.timeoutMs = 12000
    t.tag = "scrobble-" + svc + "-" + act
    ' Which service this belongs to, said outright. AddOnTask needs it to know
    ' whether a refused sign-in can be renewed (Trakt) or means signed out
    ' (Simkl); it must not read that off the tag above, which is wording.
    t.service = svc
    scene = m.top.getScene()
    if scene <> invalid then scene.appendChild(t)
    t.control = "RUN"
    ' SAID OUT LOUD, and it earns the line. A scrobble that works is silent
    ' everywhere else: nothing observes the answer, AddOnTask only speaks up
    ' on a failure, and the member's own Trakt page is the only other place
    ' the truth is written down. On the office stick 2026-09-18 that left no
    ' way to tell "it worked" from "it never fired" — which is exactly the
    ' question anyone reading a member's log will be asking. Three lines per
    ' film per service is not noise. NO TOKEN, NO URL: the service, what was
    ' said and how far through, and nothing else.
    KLog("addon", "scrobble " + svc + " " + act + " at " + scrobbleProgress().toStr() + "%")
end sub

' Take the finished ones back off the scene.
'
' The pairing for the appendChild above: without this, every scrobble of every
' film would leave a dead Task node hanging on the scene for the rest of the
' launch. Run on the way IN rather than on the way out, because the way out is
' the one moment this component is about to stop existing. Steady state is the
' handful still in flight, plus whatever the previous player left behind, which
' this clears. Only ever touches nodes this file made: nothing else in the app
' gives a node the id "kscrob".
sub scrobbleSweep()
    scene = m.top.getScene()
    if scene = invalid then return
    i = scene.getChildCount() - 1
    while i >= 0
        ch = scene.getChild(i)
        if ch <> invalid and ToStr(ch.id) = "kscrob"
            if LCase(ToStr(ch.state)) = "done" then scene.removeChild(ch)
        end if
        i = i - 1
    end while
end sub
