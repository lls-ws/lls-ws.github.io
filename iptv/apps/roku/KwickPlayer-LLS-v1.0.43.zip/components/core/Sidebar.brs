sub init()
    m.theme = KwickTheme()
    m.top.findNode("rail").color = m.theme.surface

    ' Nav items — same order as the Android public build's shell
    ' (nav_items.dart), minus Recordings (Roku OS has no local DVR).
    ' "Get KwickTV" sits last, below Settings, exactly like Android.
    m.items = [
        { label: "Home", icon: m.theme.iconHome },
        { label: "Search", icon: m.theme.iconSearch },
        { label: "Live TV", icon: m.theme.iconLiveTv },
        { label: "TV Guide", icon: m.theme.iconGuide },
        { label: "VOD", icon: m.theme.iconVod }
    ]
    ' Sports is in BOTH editions. The storefront is sideload only
    ' (certification 5.3) and it sits LAST, so a store build simply ends one
    ' item early — nothing above it moves. AppShell builds its screen list
    ' the same way and off the same guard, so the indexes stay in step.
    m.items.push({ label: "Sports", icon: m.theme.iconSports })
    m.items.push({ label: "Settings", icon: m.theme.iconSettings })
    if ShowStorefront() then m.items.push({ label: "Get KwickTV", icon: m.theme.iconStore })

    m.iconNodes = []
    m.labelNodes = []
    itemH = 120
    ' Centre the whole rail vertically instead of pinning it to a fixed top
    ' margin. With a fixed 140 the menu was balanced at seven items and
    ' top-heavy the moment Sports made it eight — 149px of space above and
    ' 31px below, with the last label almost touching the bottom edge.
    ' itemVisualH is one item's ink (44px icon box + its label), which is
    ' shorter than the 120px slot pitch.
    '
    ' 98, where this was 76 — the ONE layout number the shell type moved in
    ' this file. The label below is allowed two lines now (see the block at
    ' its font for why it had to be), so an item's ink is the 52px down to the
    ' label plus two lines of 19 at the default spacing, about 46. Getting
    ' this wrong does not clip anything; it just centres the rail off by half
    ' the error. Checked at both lengths the rail comes in: eight items give
    ' blockH 938 and topPad 71, so the last label ends at y=1009, inside the
    ' 1026 title-safe edge; the store edition's seven end at 949.
    itemVisualH = 98
    blockH = (m.items.count() - 1) * itemH + itemVisualH
    topPad = Int((1080 - blockH) / 2)
    if topPad < 20 then topPad = 20
    for i = 0 to m.items.count() - 1
        icon = m.top.createChild("Label")
        icon.font = IconFont(44)
        icon.text = m.items[i].icon
        icon.width = 110
        icon.height = 52
        icon.horizAlign = "center"
        icon.vertAlign = "center"
        icon.translation = [0, topPad + i * itemH]
        m.iconNodes.push(icon)

        lbl = m.top.createChild("Label")
        lbl.text = m.items[i].label
        lbl.width = 110
        lbl.horizAlign = "center"
        lbl.translation = [0, topPad + i * itemH + 52]
        ' ---- The rail label, and the one thing mono broke here ---------------
        ' JetBrains Mono at the SAME 19 this has always been. Keeping the size
        ' was the point: this rail is on every screen in the app and its label
        ' is already the smallest type anywhere in it — dropping to the 16 that
        ' would have made the longest word fit on one line would have put a
        ' nav label well under what is readable from a sofa.
        '
        ' WHAT HAD TO GIVE INSTEAD. Mono's advance is a flat 0.6em, so at 19
        ' every character is 11.4px and the rail is 110px wide — nine
        ' characters. "Get KwickTV" is ELEVEN, i.e. 125px, and would have been
        ' cut off on the storefront entry. Roboto-Medium averaged about 9.5px
        ' and squeezed it in at 105.
        '
        ' So the labels wrap now, to at most two lines. "Get KwickTV" becomes
        ' "Get" over "KwickTV" (77px, comfortable); every other item in the
        ' rail is eight characters or fewer, fits on one line, and is drawn at
        ' exactly the pixel it was drawn at before. Set on ALL of them rather
        ' than on the long one alone so the rail cannot grow two behaviours.
        lbl.wrap = true
        lbl.maxLines = 2
        lbl.font = UiFont(19)
        m.labelNodes.push(lbl)
    end for

    m.focused = 0
    m.top.observeField("selectedIndex", "refresh")
    m.top.observeField("focusedChild", "onFocusChanged")
    ' focusedIndex is written OUT of here on every up/down, but it is also
    ' written IN by AppShell when the app opens on a screen other than Home
    ' (the per-profile startup screen). Without this the rail's cursor would
    ' still be sitting on Home while a different screen is showing. Observed
    ' rather than read in init because XML children are built before
    ' AppShell's init has had a chance to set it.
    m.top.observeField("focusedIndex", "onFocusIndexSet")
    refresh()
end sub

sub onFocusIndexSet()
    idx = m.top.focusedIndex
    if idx < 0 or idx >= m.items.count() then return
    if idx = m.focused then return
    m.focused = idx
    refresh()
end sub

sub onFocusChanged()
    refresh()
end sub

sub refresh()
    hasFocus = m.top.hasFocus()
    for i = 0 to m.iconNodes.count() - 1
        color = m.theme.textSecondary
        if hasFocus and i = m.focused
            ' Focus wins, in the theme's focus colour — nord yellow now, and
            ' it is drawn as TEXT on the page background (8.0:1), never as a
            ' fill with text on it, so the Nord change costs this rail
            ' nothing.
            color = m.theme.focusHighlight
        else if i = m.top.selectedIndex
            ' The section you're in holds the accent — nord frost, again as
            ' text on the page rather than as a fill.
            color = m.theme.accent
        end if
        m.iconNodes[i].color = color
        m.labelNodes[i].color = color
    end for
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "down"
        if m.focused < m.items.count() - 1
            m.focused = m.focused + 1
            m.top.focusedIndex = m.focused
            refresh()
        end if
        return true
    else if key = "up"
        if m.focused > 0
            m.focused = m.focused - 1
            m.top.focusedIndex = m.focused
            refresh()
        end if
        return true
    else if key = "OK"
        m.top.itemSelected = m.focused
        return true
    end if
    return false
end function
