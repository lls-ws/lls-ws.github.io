sub init()
    ' ---- WHAT THIS SESSION IS CALLED -----------------------------------------
    ' One short name for this run of the app. AppShell writes it on the first
    ' line of the crash log it saves, and the NEXT launch compares the two to
    ' decide whether that saved log really belongs to the session it is about
    ' to report a crash for. The whole argument is at uploadCrashLog below.
    '
    ' THE FIRST THING init() DOES, DELIBERATELY. Everything under here can
    ' fall over, and a session that died without having been given a name
    ' cannot be told apart from the one before it — which is the exact fault
    ' being fixed. Only main.brs now runs ahead of this.
    '
    ' ITS OWN REGISTRY KEY, AND A TINY ONE. `diag_sess` holds about 17
    ' characters and is overwritten every launch, so it costs roughly 26
    ' bytes once and never grows. The whole registry is 16-32 KB for the
    ' entire app and a write past that fails silently, which is why this
    ' states a size instead of calling itself small.
    m.prevSessId = RegRead("diag_sess")
    m.global.addFields({ sessId: nextDiagSessionId(m.prevSessId) })
    RegWrite("diag_sess", m.global.sessId)

    ' Diagnostic log buffer — KLog appends here from every thread so
    ' Settings -> About -> Export Logs has something to upload (T6) —
    ' plus the session XMLTV guide cache for M3U sources (T5).
    ' favVodIndex: "movie:123"/"series:45" -> true, so a poster tile can tell
    ' it's a favorite without a registry read per tile (see Store.brs).
    ' m3uByProv: providerId -> { channels, tvgUrl } — one slot per M3U
    ' source; m3uChannels is the merged all-sources list rebuilt from the
    ' slots (PublishM3uParse in Store.brs). One playlist parsing never
    ' clobbers another's channels.
    ' syncRunning/syncClaimedAt: the single-flight slot for KwickSync. Several
    ' places start a SyncTask (background timer, "Sync now", the profile fetch,
    ' the sign-out push) and every one of them loads, rewrites and saves the
    ' SAME registry mirror and cursor. Two overlapping cycles meant last-writer-
    ' wins: one cycle's applied rows were thrown away while the other's cursor
    ' advance survived, so those changes were acknowledged and then never asked
    ' for again — a favorite that silently never arrived. runSync claims this
    ' slot before it touches the mirror (SyncClaimSlot in Store.brs).
    ' SESSION-SCOPED ON PURPOSE, not the registry: a crash mid-cycle leaves the
    ' flag set, and on m.global that costs one relaunch. Written to the registry
    ' it would lock sync out of the box forever.
    ' syncClaimedAt is epoch SECONDS (32-bit safe, same convention as
    ' sync_last_at) and does two jobs: the staleness clock for the steal, and
    ' the stamp a cycle checks before it releases.
    ' linkJustCleared: "the member has just cleared this television, and the
    ' first screen they are about to land on must not hand it all straight
    ' back". Settings > Account & help sets it as the last thing the clean
    ' slate does; OnboardScreen reads it once and puts it straight back to
    ' false, so it covers exactly ONE arrival at the first screen and nothing
    ' after that. See clearEverySource() in SettingsCategoryScreen.brs and the
    ' skipRestore note in OnboardScreen.brs.
    ' SESSION-SCOPED ON PURPOSE, for the same reason as syncRunning above and
    ' more so: the clean slate routes to onboarding inside this same run, so
    ' m.global always reaches it, and a registry flag that ever failed to
    ' clear would turn the silent restore off on that box FOREVER — the one
    ' failure that would be invisible and permanent. Lost to a crash it costs
    ' nothing: the box is back to the behaviour it had before this existed.
    ' profilesUnknown: "this device has not been told the account's profiles
    ' yet", which is true for the few seconds between a first sign-in and the
    ' locker answering. While it is set, every sync cycle listens and does not
    ' speak — see SyncProfilesUnknown/SyncPullOnly in Store.brs for the whole
    ' argument. SESSION-SCOPED ON PURPOSE, for the third time on this line and
    ' the strongest case of the three: written to the registry and ever left
    ' set, it would stop this television uploading anything the member does,
    ' forever, with nothing on screen to say so.
    ' fxPaused: "a video is playing, take the background effects down". Was
    ' gridPaused until the CRT scanlines arrived and it had two things to
    ' govern instead of one; Android suspends both overlays on the same flag
    ' (main.dart:220-236) and so does this. Session scoped like everything
    ' else on this line, and false is the safe value — a box that somehow
    ' never cleared it would show no wash, which is the app as it looked
    ' yesterday rather than a fault.
    ' bgfxKey / bgFxGrid / bgFxCrt: the member's Background Effect. bgfxKey is
    ' the stored string (Android's five, verbatim); the two booleans are what
    ' it resolves to, and they are what every painter in the app actually
    ' reads. SEEDED FROM THE REGISTRY HERE, ONCE, and this is the only place
    ' in the app that reads registry key `bgfx` — see the long note at
    ' BgFxGridOn() in Theme.brs for why a painter may not do its own RegRead
    ' (AvatarPickerScreen does not include Store.brs and would die on it).
    '
    ' DEVICE-LEVEL AND NOT SYNCED, matching Android's own comment: `bgfx` is a
    ' plain registry key and must never be put through psetScalarMap. A member
    ' choosing scanlines on the television is not choosing them on their
    ' phone.
    '
    ' liveLineup: the live channels the member is CURRENTLY looking at, in the
    ' order the tiles are drawn — this folder or tab, after their hidden/reorder
    ' prefs and after their search. It is what lets the player answer channel up
    ' and channel down (A2) without ever asking the provider for a lineup
    ' mid-stream, which is the request shape that got this house banned.
    ' Published by LiveTvScreen and GuideScreen, and by nobody else; the shape
    ' is the five keys PlayerScreen.channel already takes
    ' ({ streamId, name, logo, url, src }). Empty is a real answer and is always
    ' written — a stale lineup would zap the member onto a channel that is no
    ' longer on their screen. SESSION-SCOPED, like everything else on this line.
    m.global.addFields({ diagLog: "", diagRepLine: "", diagRepN: 0, xmltvState: "", xmltvClaimedAt: 0, xmltvById: {}, m3uTvgUrl: "", m3uChannels: [], m3uByProv: {}, favVodIndex: {}, srcColorIdx: {}, xmltvAliases: {}, xmltvShed: false, liveLineup: [], syncRunning: false, syncClaimedAt: 0, syncPrimed: false, appMemPct: 0, memWarning: "", memPressure: false, linkJustCleared: false, profilesUnknown: false, fxPaused: false, bgfxKey: RegRead("bgfx"), bgFxGrid: true, bgFxCrt: false })

    ' ---- The member's Background Effect --------------------------------------
    ' Android's GridOverlay and CrtOverlay, both ported. The arithmetic behind
    ' the mesh cell and the scanline band, and why these are 45 + 135
    ' Rectangles rather than the full-screen textures an earlier note in
    ' Theme.brs wrongly assumed they had to be, are written out at
    ' BuildGridOverlay() and BuildCrtOverlay().
    '
    ' BOTH ARE BUILT HERE UNCONDITIONALLY, whatever the member chose, and only
    ' their `visible` is switched. That is the opposite of what AddPageGrid()
    ' does and the difference is on purpose. This runs at LAUNCH, where the
    ' clock is certification 3.6's eight seconds to first frame and 180
    ' Rectangles are nothing. A Background Effect change, by contrast, arrives
    ' as a remote press with certification 3.5's 250 ms on it — and two
    ' boolean writes fit in that where rebuilding 180 nodes might not. Same
    ' argument as the pause gate below, which was written for the same reason.
    ' Neither depends on the profile, the providers or anything a screen does,
    ' so neither is ever rebuilt.
    '
    ' THE OVERLAY SCREENS KEEP THEIR OWN COPY and it is repainted from the same
    ' handler — see onBgFxChanged below, which is where the "you have to back
    ' out for it to change" bug actually was.
    '
    ' THEY MUST NOT DRAW OVER VIDEO. Android suspends both overlays while
    ' fullscreen playback is up (main.dart:220-236) and so does this, through
    ' m.global.fxPaused, which PlayerScreen sets on play and clears on BOTH
    ' teardown paths. Both branches are written on every change, here and
    ' there — an effect stranded off after a stream ends would leave the
    ' member with a plain page until relaunch.
    m.crtWash = BuildCrtOverlay(m.top.findNode("bgFxHost"))
    m.gridWash = BuildGridOverlay(m.top.findNode("bgFxHost"))
    ' Roku's memory alarm, raised in main.brs (the only place that can hold
    ' an roAppMemoryMonitor port) and written here into the log the crash
    ' report carries. See main.brs for why this exists.
    m.global.observeField("memWarning", "onMemWarning")
    m.global.observeField("fxPaused", "onBgFxChanged")
    m.global.observeField("bgfxKey", "onBgFxChanged")
    onBgFxChanged()
    di = CreateObject("roDeviceInfo")
    ai = CreateObject("roAppInfo")
    KLog("app", "KwickPlayer " + ai.getValue("major_version") + "." + ai.getValue("minor_version") + "." + ai.getValue("build_version") + " on " + di.getModel() + " (" + di.getModelDisplayName() + ") OS " + di.getOSVersion().major + "." + di.getOSVersion().minor)
    ' Straight after the model line, because the two belong together: this is
    ' how much memory THAT box will let this app have. See logMemoryCeiling
    ' below. Once per launch, nothing repeats.
    logMemoryCeiling()

    ' Crash detection (Android-parity, next-launch style, since Build 13):
    ' main.brs arms crash_pending when the OS says the previous session
    ' ended in a crash (lastExitOrTerminationReason, Roku OS 13+) ->
    ' upload its persisted log tail as a crash report (once per launch;
    ' the server throttles and files crash logs separately).
    if RegRead("last_exit_reason") <> ""
        KLog("app", "previous session exit: " + RegRead("last_exit_reason"))
    end if
    exitReason = RegRead("crash_pending")
    if exitReason <> ""
        RegDelete("crash_pending")
        ' m.prevSessId is the name of the session that just ended — read at
        ' the top of init(), before this launch overwrote it. That is the
        ' session this report is about.
        uploadCrashLog(exitReason, m.prevSessId)
    end if
    RegDelete("session_alive")   ' retired sentinel from an earlier design

    ' Parental unlock lasts one session only — clear it at every launch.
    ClearParentalSession()

    ' One-time: rows saved before multi-source keying learn which source
    ' they belong to (see Store.brs). Must run before any screen reads a
    ' store, which is exactly here.
    RunSrcKeyMigration()

    ' A source whose address was edited on the website has everything saved
    ' against it moved across to its new name. That move is written down
    ' before it starts, so one cut short by a power cut is finished here —
    ' one registry read when there is nothing to finish (see Store.brs).
    RunPendingSrcTokenMove()

    ' Merged lineup: "active" no longer picks what's on screen — it anchors
    ' the account header, sync, and lists. Pin it to the KwickTV login when
    ' one exists so those always mean the primary account.
    kp = KwickTvProvider()
    if kp <> invalid and ActiveProviderId() <> ToStr(kp.id) then SetActiveProviderId(ToStr(kp.id))
    m.theme = KwickTheme()
    m.top.backgroundColor = m.theme.background
    m.top.backgroundUri = ""
    m.top.findNode("bg").color = m.theme.background

    m.shell = invalid
    m.onboard = invalid
    ' Made on the first launch that finds a media server waiting to sign in.
    m.msSignIn = invalid
    m.picker = invalid
    ' True while the picker is floating OVER an existing shell rather than
    ' standing in for one — see showPickerOverlay().
    m.pickerOverlay = false
    ' True while that overlay was raised by Home's profile button rather than
    ' by the late-profile catch-up. The difference only matters on the way
    ' out: see onPickerCancelled().
    m.pickerFromHome = false
    m.pickerFromId = ""

    ' Performance beacon state (certification 3.2) — see the beacon section at
    ' the bottom of this file. Set BEFORE anything can put a screen up, because
    ' the very next thing init() does is show onboarding or the profile picker.
    m.launchDone = false
    m.dialogBeaconOpen = false
    ' Empty until the launch's ONE dialog pair has been spent, then the name of
    ' the screen that got it. A box only accepts one pair per launch — see the
    ' beacon section for what the device did when we tried for a second.
    m.dialogBeaconSpentOn = ""

    ' Roku Event Dispatcher state (certification 4.3) — see that section too.
    m.redAuthSent = false
    m.redTimer = invalid

    ' A screen can ask to switch profiles by setting this field.
    m.top.observeField("switchProfile", "onSwitchProfileRequested")
    ' ...or this one, for the version that floats over the shell (H7).
    m.top.observeField("switchProfileOverlay", "onSwitchProfileOverlayRequested")

    ' Deep links arrive here from main.brs (launch args, or ECP while running).
    m.pendingDeepLink = invalid
    m.dlPlayer = invalid
    m.profileFetchTried = false
    ' "The home screen went up before the profile fetch came back." Set by the
    ' cap timer, read by onProfileFetchDone to decide whether it is finishing a
    ' launch or catching up with one that already finished.
    m.profileFetchLate = false
    m.profileFetchTimer = invalid
    m.top.observeField("deepLink", "onDeepLink")

    ' "There's a newer build" check — fired here so the network round trip
    ' overlaps the rest of startup and nothing on screen ever waits for it.
    ' The answer is held until the member reaches Home (see below).
    startUpdateCheck()

    if ActiveProvider() = invalid
        showOnboarding()
    else
        startProfiles()
    end if
end sub

' A video started or stopped, OR the member changed their Background Effect.
' One handler for both because the answer is the same product either way:
' an effect is on screen when the member asked for it AND nothing is playing.
'
' BOTH BRANCHES ARE WRITTEN FOR BOTH EFFECTS, every time. A field set only in
' its "on" branch is the mistake this codebase keeps making, and here it would
' strand the mesh or the scanlines off after a stream ended — a plain page
' until relaunch, with nothing on screen to explain it.
'
' VISIBILITY ONLY. The 45 + 135 Rectangles are kept rather than torn down and
' rebuilt, because they cost nothing to keep (solid fills, no texture memory)
' and rebuilding them on every play/stop or every Settings press would be work
' done inside the 250 ms the remote has to be answered in (certification 3.5).
'
' HOW A SETTINGS CHANGE REACHES HERE: whoever writes registry key `bgfx` also
' writes the same string to m.global.bgfxKey, and this fires. Writing the
' registry alone changes nothing until the next launch. Setting bgfxKey to the
' value it already holds does not notify, which is correct — nothing changed.
'
' >>> AND IT MUST REACH THE OVERLAY SCREENS TOO. <<< The two washes below are
' the SCENE's copy, behind the shell. Eleven overlay screens paint a
' full-screen backdrop of their own and carry their own copy, placed by
' AddPageGrid(). Settings is one of them — so until 2026-08-27 changing the
' effect from inside Settings repainted the scene the member could not see and
' left the copy in front of them alone. It only looked fixed after backing out.
' RepaintPageGrids() walks the scene's own children and repaints every such
' copy that is currently up. It is a no-op when the shell alone is on screen.
sub onBgFxChanged()
    fx = BgFxResolve(m.global.bgfxKey)
    m.global.bgFxGrid = fx.grid
    m.global.bgFxCrt = fx.crt
    playing = (m.global.fxPaused = true)
    if m.gridWash <> invalid then m.gridWash.visible = fx.grid and (not playing)
    if m.crtWash <> invalid then m.crtWash.visible = fx.crt and (not playing)
    RepaintPageGrids(m.top)
end sub

' ---- Deep linking (Roku certification 5.1 / 5.2) ----------------------------
' Roku hands the app a contentId + mediaType, either as launch arguments or,
' for Direct to Play, while it's already running. We publish no catalogue to
' Roku, so in practice only Roku's own test tools generate these — but the
' app must still handle them, and per Roku's guidance an id it can't resolve
' MUST fall back to the home screen rather than erroring.
'
' The contentId scheme is ours to define (Roku only passes the string
' through). It reuses the portable ids KwickSync already speaks:
'   xt:<host>:<streamId>       a live channel
'   movie:<streamId>:<ext>     a movie
'   episode:<episodeId>:<ext>  an episode
'   series:<seriesId>          a series (opens its page)
'
' NOTE for whoever hands Roku sample deep links at submission: the colons
' MUST be percent-encoded in the ECP URL or the request is rejected with a
' 404 before the app ever sees it, e.g.
'   contentId=xt%3Akwick.cc%3A1038&mediaType=liveFeed
' Roku's docs say as much — contentId is "a URL-encoded ASCII string".
sub onDeepLink()
    dl = m.top.deepLink
    ' THE LINK ARRIVES AFTER THE PICKER. main.brs hands over launch arguments
    ' only after screen.show(), by which time startProfiles() has already
    ' put "Who's watching?" up, so the gate in startProfiles never sees a
    ' cold-launch link. Roku's deep-linking policy forbids a profile screen
    ' between the link and playback, and App Behavior Analysis (2026-09-03)
    ' failed every deep-link test on exactly that. So the picker comes down
    ' here, the last profile is used, and the shell (which plays the pending
    ' link) goes up.
    if m.picker <> invalid and m.pickerOverlay <> true and m.shell = invalid
        if ToStr(GetField(dl, "contentId")) <> ""
            KLog("deeplink", "deep link arrived while Who's watching? was up - closing it and using the last profile")
            removePicker()
            SetActiveProfileId(deepLinkProfileId(EnsureDefaultProfile()))
            m.pendingDeepLink = dl
            showShell()
            return
        end if
    end if
    if dl = invalid then return
    if ToStr(GetField(dl, "contentId")) = "" then return
    KLog("deeplink", "received " + ToStr(GetField(dl, "contentId")) + " (" + ToStr(GetField(dl, "mediaType")) + ")")
    m.pendingDeepLink = dl
    tryPendingDeepLink()
end sub

' Held until there's a provider AND a profile — Roku's own guidance is to
' route an unauthenticated user through sign-in first, then process the link.
' startProfiles()/showShell() call back in once that's done.
sub tryPendingDeepLink()
    if m.pendingDeepLink = invalid then return
    if ActiveProvider() = invalid then return   ' still onboarding
    if m.shell = invalid then return            ' still on "Who's watching?"
    dl = m.pendingDeepLink
    m.pendingDeepLink = invalid
    playDeepLink(ToStr(GetField(dl, "contentId")), LCase(ToStr(GetField(dl, "mediaType"))))
end sub

sub playDeepLink(contentId as string, mediaType as string)
    ' mediaType is validated by Roku before it reaches us and the contentId
    ' scheme already says what the thing is, so it's logged rather than
    ' branched on — kept in the signature because cert 5.1 sends it.
    KLog("deeplink", "mediaType=" + mediaType)
    p = ActiveProvider()
    if p = invalid then return
    url = ""
    title = "Kwick Player"
    isLive = false
    ext = ""

    parts = contentId.split(":")
    kind = ""
    if parts.count() > 0 then kind = LCase(ToStr(parts[0]))

    if kind = "xt" and parts.count() >= 3
        ' xt:<host>:<streamId> — the host is informational; the stream plays
        ' from whichever provider is signed in on THIS device.
        url = XtreamLiveUrl(p, ToStr(parts[2]))
        isLive = true
    else if kind = "movie" and parts.count() >= 2
        if parts.count() >= 3 then ext = ToStr(parts[2])
        url = XtreamVodUrl(p, ToStr(parts[1]), ext)
    else if kind = "episode" and parts.count() >= 2
        if parts.count() >= 3 then ext = ToStr(parts[2])
        url = XtreamSeriesEpisodeUrl(p, ToStr(parts[1]), ext)
    end if

    if url = ""
        ' Unresolvable (unknown scheme, a series link, or a bare test id):
        ' land on the home screen, which is exactly what Roku asks for.
        KLog("deeplink", "not resolvable - opening the home screen instead")
        return
    end if

    KLog("deeplink", "playing " + kind)
    m.dlPlayer = m.top.createChild("PlayerScreen")
    m.dlPlayer.titleText = title
    m.dlPlayer.streamUrl = url
    m.dlPlayer.streamFormat = StreamFormatFor(url, ext)
    m.dlPlayer.isLive = isLive
    m.dlPlayer.observeField("closed", "onDeepLinkPlayerClosed")
    m.dlPlayer.setFocus(true)
    m.dlPlayer.start = true
end sub

sub onDeepLinkPlayerClosed()
    if m.dlPlayer <> invalid
        m.top.removeChild(m.dlPlayer)
        m.dlPlayer = invalid
    end if
    if m.shell <> invalid then m.shell.setFocus(true)
end sub

' Show "Who's watching?" when more than one profile exists; otherwise drop
' straight into the shell for the single (default) profile.
'
' FETCH BEFORE CREATE. Straight after a sign-in the local profile store can
' be empty while the locker still holds the member's profiles. Creating a
' "Default" here doesn't just show the wrong thing — the next sync sees it
' as a brand-new local profile and PUSHES it, overwriting the server's
' default profile row on every device. That's how a profile named "kwick"
' came back as "Default". So when there's nothing local and sync can reach
' the locker, ask the locker first (the Android app's "Fetching your
' profiles…" step) and only fall back to creating one if that turns up
' nothing.
'
' WHAT THIS NO LONGER DOES IS SIT HERE UNTIL THE LOCKER ANSWERS. The wait is
' capped at five seconds and then the home screen goes up regardless, with the
' fetch still running and still observed — see startProfileFetchTimer() below
' for the certification argument, and adoptLateProfiles() for what happens when
' the answer arrives after the fact. The fetch-before-create rule above is not
' softened by any of that: going to Home early means going there pointing at NO
' profile, never at a fabricated one.
sub startProfiles()
    ' "No profiles yet" also covers a box holding nothing but the blank
    ' auto-created Default and no sync history: that is a device which has
    ' never been told about the account's real profiles, so it must still
    ' ask. Without this, anyone who signed in while KwickSync defaulted OFF
    ' is stuck — a default profile already exists locally, so the old
    ' count = 0 test never fires again and the picker never appears.
    needsProfiles = LoadProfiles().count() = 0
    if not needsProfiles then needsProfiles = HasOnlyPristineDefaultProfile() and SyncCursor() = 0
    if needsProfiles and SyncEnabled() and SyncEligible() and m.profileFetchTried <> true
        m.profileFetchTried = true
        KLog("app", "signed in with no local profiles - fetching them before creating one")
        lbl = m.top.findNode("fetchingLabel")
        ' 34 unchanged: the Label is the full 1920 wide and centred, and
        ' "Fetching your profiles…" is 23 characters, i.e. 470px in mono at
        ' 34. It cannot come close to clipping.
        lbl.font = UiFont(34)
        lbl.color = m.theme.textPrimary
        lbl.text = "Fetching your profiles…"
        lbl.visible = true
        ' Clear the single-flight slot before asking. This is the ONE place in
        ' the app where a refused sync cycle would do damage: refused, the task
        ' answers immediately, onProfileFetchDone comes back here with
        ' profileFetchTried already set, and we fall through to
        ' EnsureDefaultProfile() — the exact create-before-fetch that overwrites
        ' the account's real profiles on every other device (see above).
        '
        ' Safe to force, and the reason is narrower than it used to be written.
        ' All three routes into startProfiles() run with no AppShell (init
        ' before it is built, onOnboardDone after showOnboarding() removed it)
        ' and no Settings screen, so NOTHING CAN START A NEW CYCLE at this line
        ' — removeShell() stops the shell's 90-second timer before the shell
        ' goes, so there is no second shell left ticking behind this one.
        '
        ' CORRECTED 2026-09-19 (RK-006). This used to say "no other SyncTask can
        ' be alive", which was never quite true and is still not: a cycle that
        ' STARTED a second before sign-out is running on its own thread, and
        ' removeShell deliberately lets it finish rather than killing it
        ' mid-write. So a claim standing here belongs either to a collected
        ' cycle or to one that is about to release the slot itself. Forcing is
        ' still right — the cost of a refused cycle here is the create-before-
        ' fetch data loss described above, and the cost of forcing is at worst
        ' one duplicated cycle — but it is a judgement, not an impossibility.
        SyncReleaseSlot()
        ' Say out loud, for the whole session and every thread in it, that this
        ' device does not yet know the account's profiles. Until it is cleared,
        ' any sync cycle that starts — this one, AppShell's background timer,
        ' anything — pulls and projects but takes no snapshot and reconciles
        ' nothing, so it cannot push a profile and cannot tombstone one
        ' (SyncPullOnly in Store.brs). Set BEFORE the task starts, because the
        ' cycle reads it in its first few lines.
        SetSyncProfilesUnknown(true)
        m.profileFetchTask = CreateObject("roSGNode", "SyncTask")
        m.profileFetchTask.observeField("result", "onProfileFetchDone")
        m.profileFetchTask.control = "RUN"
        startProfileFetchTimer()
        return
    end if
    m.top.findNode("fetchingLabel").visible = false
    profiles = EnsureDefaultProfile()
    if profiles.count() > 1 and m.pendingDeepLink = invalid
        showPicker(false)
    else if profiles.count() > 1
        ' A DEEP LINK SKIPS "WHO'S WATCHING?". Roku's deep-linking policy,
        ' verbatim: "An app may not display a profile selection screen, or any
        ' other screen other than one for purchases or authentication, between
        ' the selection and playback of a movie or episode." App Behavior
        ' Analysis (2026-09-03) failed every deep-link test on exactly this:
        ' the link was held until a profile was chosen and nobody was there to
        ' choose one. The member asked for THIS title; they get it on whichever
        ' profile they used last, and can switch afterwards from Home.
        SetActiveProfileId(deepLinkProfileId(profiles))
        KLog("deeplink", "profile picker skipped for the deep link - using the last profile")
        showShell()
    else
        SetActiveProfileId(profiles[0].id)
        showShell()
    end if
end sub

' The profile a deep link plays on when there is more than one: the one used
' last, if it still exists, else the first.
function deepLinkProfileId(profiles as object) as string
    last = ActiveProfileId()
    for each p in profiles
        if ToStr(p.id) = last and last <> "" then return last
    end for
    return ToStr(profiles[0].id)
end function

' ---- Capping the wait for the locker (Roku certification 3.2) --------------
' 3.2, verbatim: "Apps must launch to a fully rendered home screen within 15
' seconds", measured on mid-tier reference hardware. Roku's automated review
' runs our own sign-in script on a clean box and then measures, so the
' reviewer's launch is ALWAYS the fresh-sign-in one — the slowest path we have.
'
' "Fetching your profiles…" sits on a SyncTask cycle whose HTTP wait alone is
' capped at 25 seconds (httpPost in SyncTask.brs), and nobody is being asked
' anything while it does. That makes it a loading step, not a dialog, so the
' beacon rules forbid subtracting it — every second of it counts against the
' 15. On a slow line it eats the budget on its own.
'
' The wait is therefore capped at five seconds, and the fix is to render Home
' first rather than to hurry the fetch:
'   * task first — much the common case — nothing below runs at all and the
'     launch behaves exactly as it always has;
'   * timer first — the home screen goes up, the fetch keeps running and stays
'     observed, and whatever it brings back is settled onto the member from
'     where they are (adoptLateProfiles).
'
' Three things this deliberately does NOT do, each of which would be easier:
' it does not shorten the 25s HTTP wait (that ceiling is shared by every sync
' cycle, and lowering it would make a heavy member's first full pull
' unrecoverable); it does not fabricate a Default profile to get to Home
' faster (that is the data-loss bug this whole path exists to prevent); and it
' does not stretch a dialog beacon across the fetch to hide it from the launch
' clock. Roku only ever sees two timestamps and could not catch us at the last
' one, which is exactly why we do not do it.
sub startProfileFetchTimer()
    m.profileFetchLate = false
    if m.profileFetchTimer = invalid
        m.profileFetchTimer = CreateObject("roSGNode", "Timer")
        m.profileFetchTimer.duration = 5
        m.profileFetchTimer.repeat = false
        m.profileFetchTimer.observeField("fire", "onProfileFetchTimeout")
    end if
    m.profileFetchTimer.control = "start"
end sub

sub stopProfileFetchTimer()
    if m.profileFetchTimer <> invalid then m.profileFetchTimer.control = "stop"
end sub

' Five seconds are up and the locker still hasn't answered. Go to Home without
' it, and let it finish behind.
sub onProfileFetchTimeout()
    ' The fetch beat us to it after all and has already put something on
    ' screen — stopProfileFetchTimer() should have caught this, and this is the
    ' belt for it.
    if m.shell <> invalid then return
    if m.picker <> invalid then return
    m.profileFetchLate = true
    KLog("app", "profile fetch is taking too long - opening the home screen and letting it finish behind")
    m.top.findNode("fetchingLabel").visible = false
    ' >>> DELIBERATELY NOT EnsureDefaultProfile(). READ THIS BEFORE "FIXING" IT.
    ' The profile store is left EMPTY and Home is opened over the top of it.
    ' Fabricating a blank "Default" here to have something to point at is the
    ' documented data-loss bug: "default" is a SHARED cross-device identity, so
    ' a blank one pushed up overwrites the member's real profile name, colour,
    ' avatar and PIN on every device they own, and takes their per-profile
    ' settings blob with it. That is precisely what we still do not know yet —
    ' the fetch is still in flight. So we point at nothing, which is the honest
    ' answer, and adoptLateProfiles() settles it the moment we do know.
    showShell()
end sub

' The locker has answered (or failed). Either way carry on — if it brought
' profiles down we now use them; if it couldn't, EnsureDefaultProfile()
' creates one as before, which is the right call when there's genuinely
' nothing to restore.
sub onProfileFetchDone()
    stopProfileFetchTimer()
    KLog("app", "profile fetch finished - " + LoadProfiles().count().toStr() + " profile(s) available")
    ' Asked and answered: several profiles, one, or none, this device now knows
    ' which. Ordinary two-way sync resumes from here — including on the offline
    ' path, where the answer was "couldn't reach it" and buildSnapshot's
    ' hideBlankDefault goes back to being the only thing standing between a
    ' blank Default and the wire. That guard has not moved.
    SetSyncProfilesUnknown(false)
    if m.profileFetchLate <> true
        ' The task won the race, which is the ordinary case and was the only
        ' case before the cap existed: nothing is on screen yet, so carry
        ' straight on into the profile stage exactly as before.
        startProfiles()
        return
    end if
    adoptLateProfiles()
end sub

' Home went up without profiles and they have turned up since. The member is
' already looking at the home screen, so this must not throw that away and
' start the launch over — it has to settle onto the right profile from where
' they are.
sub adoptLateProfiles()
    profiles = LoadProfiles()
    if profiles.count() = 0
        ' The locker had nothing for us — a brand new account, or it could not
        ' be reached at all. NOW the blank Default is the right answer, and it
        ' is safe for the exact reason it wasn't five seconds ago: we asked
        ' first, and either there is nothing to overwrite or we are offline and
        ' pushing nothing anyway. hideBlankDefault still keeps it off the wire
        ' until the locker's own copy has been seen.
        profiles = EnsureDefaultProfile()
        SetActiveProfileId(ToStr(profiles[0].id))
        refreshForProfileChange()
        return
    end if
    if profiles.count() = 1 and ToStr(profiles[0].pin) = ""
        ' One profile, no lock on it: there is nothing to ask. Slide onto it
        ' silently rather than shoving a one-tile "Who's watching?" in the
        ' member's face over a choice that has already been made for them.
        KLog("app", "late profiles: adopted the only one")
        SetActiveProfileId(ToStr(profiles[0].id))
        refreshForProfileChange()
        return
    end if
    ' Several profiles, or a single PIN-locked one. Either way the member has
    ' to choose and the lock has to be honoured, so the picker comes up — over
    ' the top of the home screen they are already on, not instead of it.
    if m.pendingDeepLink <> invalid
        ' Same policy as onDeepLink: a member who deep-linked in does not get
        ' a profile screen before their title. Last profile, then the link.
        KLog("deeplink", "late profiles arrived with a deep link pending - using the last profile, no picker")
        SetActiveProfileId(deepLinkProfileId(profiles))
        refreshForProfileChange()
        tryPendingDeepLink()
        return
    end if
    KLog("app", "late profiles: asking who's watching")
    ' No way back out: the app is currently sitting on nobody's profile, so
    ' "never mind" would leave it there.
    showPickerOverlay(false)
end sub

' "Who's watching?" WITHOUT tearing the home screen down. The picker's own
' background is opaque and covers the full 1920x1080, so it hides the shell
' completely while it is up and the shell is still there underneath when it
' goes away — which is the whole point: the member reached Home, and getting
' the profile right afterwards must not look like the app restarting.
'
' No beacon pair, and not by accident. The launch clock was stopped when the
' home screen rendered, so there is nothing left to pause; beaconDialogOpen()
' would refuse this anyway (m.launchDone), but not calling it says so out loud.
' Nothing on this path can lengthen a launch (certification 3.2), whoever
' raises it.
'
' allowBack says whether "never mind" makes sense, and the two callers differ
' for a real reason: the late-profile catch-up passes false because the app is
' sitting on nobody's profile and backing out would leave it there, while
' Home's profile button (H7) passes true because there is a perfectly good
' profile already in use to go back to.
sub showPickerOverlay(allowBack as boolean)
    if m.picker <> invalid then return
    m.pickerOverlay = true
    m.picker = m.top.createChild("ProfilePickerScreen")
    m.picker.allowBack = allowBack
    m.picker.observeField("done", "onPickerDone")
    m.picker.observeField("cancelled", "onPickerCancelled")
    m.picker.setFocus(true)
end sub

' Everything a profile switch normally refreshes, minus the part that rebuilds
' the world. The usual route is showShell(), which seeds the poster index and
' then builds a fresh AppShell — from here the shell already exists, and a
' second one built on top of the first would leave two sidebars stacked and the
' member's screen underneath one of them. So: seed the index the same way, then
' tell the shell the profile beneath it has changed and let it reload.
sub refreshForProfileChange()
    RefreshFavVodIndex()
    ' Synced per-source colours, seeded alongside the favourites index so a
    ' card paints the member's own colour on the FIRST frame rather than
    ' showing the local hash colour until the first sync cycle publishes.
    RefreshSrcColorIndex()
    if m.shell = invalid then return
    m.shell.reloadProfile = true
    m.shell.setFocus(true)
end sub

' Nothing changed — put the member back where they were. Focusing the shell
' itself would hand focus to the sidebar (onShellFocus), which is not where
' they were standing when they opened the picker.
sub focusShellContent()
    if m.shell = invalid then return
    m.shell.focusContent = true
end sub

' ---- Taking the shell down --------------------------------------------------
'
' The ONE place an AppShell is removed. Both callers used to do it inline with a
' bare removeChild, and a bare removeChild is not enough: the shell creates four
' Timers and two Task nodes with CreateObject, so they are not its children and
' removing it does not reach them. It also plants an observer on m.global, which
' is never collected and therefore holds the shell back from the other side.
' Read the long note above onTearDown in AppShell.brs — including the part
' saying the retention is inferred from the source, not measured on a box.
'
' `reason` is not decoration. It goes in the log line the shell prints on its
' way out, so a crash tail can say which of the two paths rebuilt the world.
sub removeShell(reason as string)
    if m.shell = invalid then return
    ' Synchronous: a field write from this thread to a node this thread owns
    ' comes straight back through the observer before this line returns (the
    ' same behaviour the alwaysNotify guards in AppShell.brs rely on). So the
    ' timers are stopped before the removeChild below, not after it.
    m.shell.tearDown = reason
    ' Our own observer on the way out too — otherwise a shell that somehow
    ' survives could still drive onSignedOut from outside the tree.
    m.shell.unobserveField("signedOut")
    m.top.removeChild(m.shell)
    m.shell = invalid
end sub

sub showPicker(allowBack as boolean)
    m.pickerOverlay = false
    removeShell("profile switch")
    m.picker = m.top.createChild("ProfilePickerScreen")
    m.picker.allowBack = allowBack
    m.picker.observeField("done", "onPickerDone")
    m.picker.observeField("cancelled", "onPickerCancelled")
    m.picker.setFocus(true)
    ' "Who's watching?" is a user selection in front of the home page, so it
    ' asks for the launch clock to pause here and resume in removePicker(). A
    ' PIN prompt on a locked profile happens inside this stage, so it's covered
    ' by the same pair rather than needing one of its own.
    '
    ' It only GETS the pair on a launch where nobody had to sign in: a box that
    ' already holds an account comes straight here, so the picker is the first
    ' and only thing between the launch and Home. Straight after a fresh
    ' sign-in the launch's one pair is already spent on the far longer job of
    ' typing a username and password, and this call quietly does nothing.
    beaconDialogOpen("profile picker")
end sub

sub onPickerDone()
    ' Read BEFORE removePicker(), which clears it.
    overlay = (m.pickerOverlay = true)
    removePicker()
    if overlay
        ' The shell was never taken down, so there is nothing to build — just
        ' point it at the profile the member has now chosen.
        refreshForProfileChange()
        return
    end if
    showShell()
end sub

sub onPickerCancelled()
    ' Both read BEFORE removePicker(), which clears them.
    overlay = (m.pickerOverlay = true)
    fromHome = (m.pickerFromHome = true)
    removePicker()
    if overlay
        if fromHome and ActiveProfileId() = ToStr(m.pickerFromId)
            ' Backed out of Home's profile button, still on the profile they
            ' started on. Nothing to refresh, and rebuilding the screen under
            ' them — possibly onto a different one, since a profile change is
            ' what reloadProfile means — would be a change they explicitly
            ' declined. Home re-reads its own button when focus lands back on
            ' it, so a rename or a new avatar picked in the editor still
            ' shows without any of that.
            focusShellContent()
            return
        end if
        ' Cancelled, but the profile underneath moved anyway: "Manage
        ' Profiles" lives inside this screen, and deleting the active one
        ' hands the app to a different profile whose favorites, lists and
        ' resume points are not the ones currently on screen.
        refreshForProfileChange()
        return
    end if
    showShell()
end sub

' The one and only place the picker goes away — both onPickerDone and
' onPickerCancelled come through here, so closing the beacon pair here is what
' keeps it balanced whichever way the member left the screen. (After a late
' arrival there is no pair open and no launch clock running, so that call is a
' no-op, which is correct: those seconds are not launch time.)
sub removePicker()
    if m.picker <> invalid
        m.top.removeChild(m.picker)
        m.picker = invalid
    end if
    m.pickerOverlay = false
    m.pickerFromHome = false
    beaconDialogClose("profile picker")
end sub

' Settings → Switch Profile sets m.top.switchProfile = true.
sub onSwitchProfileRequested()
    if m.top.switchProfile <> true then return
    m.top.switchProfile = false
    showPicker(true)
end sub

' ---- Switching profiles from Home (H7) --------------------------------------
' The phone puts the active profile's avatar in Home's app bar and a press
' opens the profile list (home_screen.dart:405). On this device switching
' lived in two places only — Settings (SettingsScreen.brs:99) and the launch
' picker — so from Home it was three key presses and a screen away.
'
' Home's button raises THE SAME "Who's watching?" the late-profile catch-up
' raises: showPickerOverlay(), which floats over the shell rather than tearing
' it down. No second picker was built, nothing new draws, and the PIN gate,
' the avatars, Add Profile and Manage Profiles all come along because it is
' the same screen.
'
' Deliberately NOT showPicker() — that removes the AppShell and builds a new
' one when it is done, which for a member who is standing on Home and simply
' wants to swap profile reads as the app restarting. The overlay leaves their
' screen underneath, and AppShell reloads the CURRENT screen for the new
' profile (onReloadProfile) instead of the world being rebuilt.
sub onSwitchProfileOverlayRequested()
    if m.top.switchProfileOverlay <> true then return
    m.top.switchProfileOverlay = false
    if m.shell = invalid then return   ' nothing to float over
    if m.picker <> invalid then return ' already up
    m.pickerFromHome = true
    ' Which profile they were on when they opened it, so a cancel can tell
    ' "changed my mind" from "deleted the profile I was using" — see
    ' onPickerCancelled.
    m.pickerFromId = ActiveProfileId()
    showPickerOverlay(true)
end sub

sub showOnboarding()
    removeShell("sign-out")
    m.onboard = m.top.createChild("OnboardScreen")
    m.onboard.observeField("done", "onOnboardDone")
    m.onboard.setFocus(true)
    ' Signing in is a login in front of the home page, so the launch clock
    ' pauses for as long as the member is typing. It stays paused across a
    ' failed sign-in and a retry, because they're still on this screen — and
    ' across the sign-in request itself, which is the screen checking the
    ' credentials it was just handed, not a loading step of our own.
    '
    ' On a fresh sign-in this is where the launch's one pair goes. That is the
    ' deliberate choice: typing a username and a password is far and away the
    ' longest thing a member is ever asked to do before Home.
    beaconDialogOpen("sign-in")
end sub

sub onOnboardDone()
    m.top.removeChild(m.onboard)
    m.onboard = invalid
    ' Closed HERE, before startProfiles(), and the ordering is the honest part:
    ' startProfiles() can sit on "Fetching your profiles…" waiting for SyncTask,
    ' and nobody is being asked anything while it does. Those seconds are ours
    ' and they must count against the 15.
    beaconDialogClose("sign-in")
    startProfiles()
end sub

sub showShell()
    ' Favorites are per profile, and every route into the shell (startup,
    ' profile picked, profile switched) comes through here — so this is the
    ' one place the poster index has to be seeded.
    RefreshFavVodIndex()
    ' Synced per-source colours, seeded alongside the favourites index so a
    ' card paints the member's own colour on the FIRST frame rather than
    ' showing the local hash colour until the first sync cycle publishes.
    RefreshSrcColorIndex()
    m.shell = m.top.createChild("AppShell")
    m.shell.observeField("signedOut", "onSignedOut")
    m.shell.setFocus(true)
    ' The home page exists: AppShell's init builds the sidebar and the
    ' opening screen, and that screen builds its content, all before that
    ' createChild returns. So this is the moment the launch is done — stop
    ' the clock (certification 3.2, 15 seconds) before the deep link and
    ' update nudge below, neither of which is part of getting the member in.
    '
    ' "The opening screen" and not "Home" since H8: a profile may have asked
    ' to open on Live TV or the guide instead, which is that profile's home
    ' page and is what 3.2 measures to. Exactly ONE screen is built either
    ' way — AppShell decides the slot before it creates anything — so this
    ' beacon fires no later than it ever did.
    beaconLaunchComplete()
    ' Tell Roku the member is signed in (certification 4.3). Queued, not sent,
    ' so it can't get in front of the first painted frame — see the Roku Event
    ' Dispatcher section below. Every route in here is covered: signed in at
    ' launch, signed in just now during onboarding, or signed back in after a
    ' sign-out, because all three end up in showShell().
    scheduleRokuAuthEvent()
    ' A deep link that arrived before sign-in / profile choice waits here.
    tryPendingDeepLink()
    ' So does the "newer build available" nudge — this is the first moment
    ' the member is actually at Home rather than onboarding or picking a
    ' profile, and a nudge must never land on top of either.
    maybeShowUpdateDialog()
    ' A media server the member paired on kwickplayer.tv holds an address and
    ' a sign-in but no session until the app fetches one, and the box it lives
    ' on may well have been asleep when it was paired. So every launch quietly
    ' finishes the job for anything still waiting. It costs nothing when there
    ' is nothing to do, and it is started AFTER the launch beacon on purpose —
    ' the member is already at Home and this must never count against the
    ' fifteen seconds (certification 3.2).
    startMediaServerSignIn()
end sub

' Sign in to any of the member's own Jellyfin/Emby servers that still need it.
' Silent either way: a server that is switched off is not something to put in
' front of somebody who just opened the app, and the next launch tries again.
sub startMediaServerSignIn()
    if MediaServersNeedingSignIn().count() = 0 then return
    if m.msSignIn = invalid
        m.msSignIn = m.top.createChild("MediaServerSignIn")
    end if
    if m.msSignIn.state = "working" then return
    m.msSignIn.providerId = ""
    m.msSignIn.active = true
end sub

' All sources removed from Settings -> back to onboarding, same as Android.
sub onSignedOut()
    ' The KwickTV login is gone, so the next one is a fresh authentication and
    ' Roku should hear about it (certification 4.3). There is no documented
    ' "signed out" event to send — see the Roku Event Dispatcher section.
    m.redAuthSent = false
    showOnboarding()
end sub

' ---- Roku Event Dispatcher (Roku certification 4.3) ------------------------
' 4.3, verbatim: "Apps that require authentication (SVOD, TVE, and other
' subscription services) must use the Roku Event Dispatcher to communicate
' authentication status." Roku uses it so it never offers a member a paid
' transaction for something their sign-in already entitles them to.
'
' The API is documented on the "Prioritizing authenticated apps" page:
' https://developer.roku.com/docs/developer-program/discovery/search/prioritizing-authenticated-channels-in-roku-search.md
' and it is small: create Roku_Analytics:AnalyticsNode, init it with RED as a
' provider, then assign the event to trackEvent.
'
' ONE event exists — "Roku_Authenticated", sent each time an authenticated
' member launches the app. Roku publishes NO signed-out or unauthenticated
' counterpart, so we send none: the absence of the pixel on a launch IS the
' signed-out signal. Inventing "Roku_Unauthenticated" would be guessing at an
' API, and a wrong integration is worse than a missing one.
'
' Scoped to the KwickTV login, which is the only account this app has.
' Xtream/M3U sources are the member's own third-party playlists, not an
' entitlement to anything of ours, so they are not an authentication.
'
' WHETHER WE OWE ROKU THIS AT ALL IS ARGUABLE, and the argument is that we
' don't: the same Roku page says "AVOD apps are exempt from this requirement
' because they do not benefit from this integration", the certification
' document lists "Free" as its own app model type separate from SVOD and TVE,
' and the reviewer's test for 4.3 is written around a purchase ("successful
' firing of the Event Dispatcher pixel on successful entitlement"). We sell
' nothing through Roku. This is here anyway because it is fifteen lines of
' Roku's own published sample, needs no key, agreement or streaming-hours
' threshold, and costs a free app nothing — cheap insurance against a
' reviewer reading 4.3 as "any app with a login". If we ever DO adopt the
' Roku Advertising Framework, one call replaces all of this:
'   Roku_Ads().fireRokuMarketingPixel("Roku_Authenticated")
'
' >>> STILL NEEDS ONE LINE IN THE MANIFEST, WHICH THIS AGENT DOES NOT OWN <<<
'       sg_component_libs_required=roku_analytics
' Without it CreateObject returns invalid and everything below is a silent
' no-op that logs why. Nothing here can crash the app either way.

' Queue the event rather than sending it inline. Two reasons, both real:
' component libraries load asynchronously at startup and asking for the node
' too early gets invalid back; and this is called the instant Home is built,
' where anything on the render thread delays the first frame the member
' actually sees. A second's delay costs nothing — Roku only needs the event
' once per authenticated launch.
sub scheduleRokuAuthEvent()
    if m.redAuthSent = true then return
    if KwickTvProvider() = invalid then return
    if m.redTimer = invalid
        m.redTimer = CreateObject("roSGNode", "Timer")
        m.redTimer.duration = 1
        m.redTimer.repeat = false
        m.redTimer.observeField("fire", "onRedTimer")
    end if
    m.redTimer.control = "start"
end sub

sub onRedTimer()
    sendRokuAuthenticated()
end sub

' Roku's own sample keeps the analytics node on the global so it survives and
' is reused; this follows it. Certification 4.3 is verified by a reviewer
' watching port 8085 for proof the pixel fired, which is why debug is on and
' why the outcome is logged in plain words either way.
sub sendRokuAuthenticated()
    if m.redAuthSent = true then return
    if KwickTvProvider() = invalid then return
    rac = m.global.roku_event_dispatcher
    if rac = invalid
        rac = CreateObject("roSGNode", "Roku_Analytics:AnalyticsNode")
        if rac = invalid
            KLog("red", "Roku_Analytics:AnalyticsNode unavailable - the manifest is missing sg_component_libs_required=roku_analytics")
            return
        end if
        rac.debug = true   ' RACL's own console output - the reviewer's proof
        rac.init = { RED: {} }
        m.global.addFields({ roku_event_dispatcher: rac })
    end if
    m.redAuthSent = true
    rac.trackEvent = { RED: { eventName: "Roku_Authenticated" } }
    KLog("red", "Roku_Authenticated dispatched")
end sub

' ---- Performance beacons (Roku certification 3.2) --------------------------
' Roku times the launch from the app starting to the AppLaunchComplete beacon.
' Certification 3.2, verbatim: "Apps must launch to a fully rendered home
' screen within 15 seconds." Time the member spends answering a dialog before
' the home page is SUBTRACTED from that total — but only when the dialog is
' bracketed by an AppDialogInitiate/AppDialogComplete pair.
'   https://developer.roku.com/docs/developer-program/performance-guide/measuring-channel-performance.md
'   https://developer.roku.com/docs/references/brightscript/interfaces/ifsgnodefield.md
'
' >>> ONE PAIR PER LAUNCH. THE DOCS SAY OTHERWISE. THE DEVICE WINS. <<<
'
' This app has two stages that can stand in front of Home — the KwickTV
' sign-in screen, then "Who's watching?" — and it used to bracket both, on the
' strength of this sentence from the beacon page (Roku's typo, not ours):
'
'   "If the app displays more that one dialog before the home page, multiple
'    pairs of AppDialogInitiate/AppDialogComplete beacons may be fired."
'
' A Streaming Stick 4K on Roku OS 15.3 does not do that. On a fresh sign-in,
' with the sign-in pair correctly opened and closed first, the picker's
' AppDialogInitiate came back rejected:
'
'   BRIGHTSCRIPT: WARNING: roSGNode.signalBeacon: "AppDialogInitiate":
'   already signaled: pkg:/components/core/AppScene.brs(491)
'
' — that is return code 3, whose own documented description is narrower than
' its behaviour: "An event that can only be fired once (AppLaunchComplete) was
' signaled again." AppDialogInitiate is not listed as once-only anywhere, and
' the return-code table does not mention it. It is once-only regardless. The
' second pair was never subtracted, so the design's intent was already not
' happening; all the old code achieved was a console warning at submission
' time. Written down here because the docs will keep saying multiple pairs are
' fine and the next person will believe them.
'
' So: ONE pair, and it goes to the first stage that actually asks the member
' something. On a fresh sign-in that is the sign-in screen (a username and a
' password — much the longest wait); on a box that is already signed in there
' is no sign-in screen and the picker gets it instead. Whichever way, the pair
' lands on the longest genuinely interactive stage of that particular launch.
'
' NOT beacons, and this is the line we will not cross: the splash, the
' "Fetching your profiles…" step, spinners. The beacon page is explicit —
' "Do not fire AppDialog beacons on message dialogs that do not involve any
' user interaction (for example, a 'please wait' or 'loading' dialog)."
' Roku only ever sees two timestamps and could not tell, which is precisely
' why the rule has to be kept by us rather than by them. Stretching one pair
' from the sign-in screen across the profile fetch to the picker would balance,
' would silence the warning, and would be a lie about our launch time.
'
' Everything below is deliberately dull — a boolean test and one method call,
' no allocation, no network, nothing that can block the render thread. The
' whole point of this is launch timing, so it must not cost any.

' Open a pair. Three guards, because an unbalanced or refused beacon reads
' worse to Roku's tooling than no beacon at all:
'   * after AppLaunchComplete there is no launch clock left to pause, and both
'     of these screens come back mid-session (Settings -> Switch Profile,
'     and signing out of every source);
'   * never a second Initiate while one is already outstanding;
'   * never a second Initiate after one has been spent, even a closed one —
'     the box refuses it, so we do not ask.
sub beaconDialogOpen(what as string)
    if m.launchDone = true then return
    if m.dialogBeaconOpen = true then return
    ' ToStr for the same reason fireBeacon() uses it — this is the launch path,
    ' and comparing an unset field against "" would be a crash rather than a
    ' missed beacon.
    spent = ToStr(m.dialogBeaconSpentOn)
    if spent <> ""
        ' Not an error, and deliberately not a beacon: the box would refuse it,
        ' so we never ask. Logged all the same, because "this screen's seconds
        ' were NOT subtracted" is exactly the sort of thing someone reading a
        ' launch trace needs told.
        KLog("beacon", "AppDialogInitiate (" + what + ") not sent - this launch's one dialog pair was spent on " + spent)
        return
    end if
    m.dialogBeaconSpentOn = what
    m.dialogBeaconOpen = true
    fireBeacon("AppDialogInitiate", what)
end sub

' Close a pair — a no-op unless one is actually open, so the "the picker went
' away" and "onboarding finished" paths can call it unconditionally.
sub beaconDialogClose(what as string)
    if m.dialogBeaconOpen <> true then return
    m.dialogBeaconOpen = false
    fireBeacon("AppDialogComplete", what)
end sub

' Stop the launch clock, once per session.
sub beaconLaunchComplete()
    if m.launchDone = true then return
    ' Belt and braces: a pair must never still be open when the clock stops.
    ' Every route to Home closes its own, so this should always be a no-op.
    beaconDialogClose("still open at launch complete")
    m.launchDone = true
    fireBeacon("AppLaunchComplete", "home page rendered")
end sub

' signalBeacon() hands back a status, and it is worth reading: 0 success,
' 1 not ready, 2 invalid, 3 already signalled, 4 wrong order. Anything but 0
' means the pairing is wrong, so it goes in the log LOUDLY rather than being
' discovered by a certification reviewer. Whoever verifies this on a box
' should see nothing but "ok" lines under the [beacon] tag.
'
' This line is not decoration — an rc=3 printed here is the only reason we
' found out the second pair was being thrown away, because Roku's own docs
' said it would be accepted. Keep it. A REJECTED line means the rules have
' moved again and the section header above needs rewriting, not deleting.
'
' Compared as a string on purpose: this runs on the launch path, where a type
' mismatch would be the worst crash in the app, and ToStr() takes anything.
' A box that hands back nothing at all reads as "" and is treated as fine —
' the beacon still went out, we just weren't told how it landed.
sub fireBeacon(name as string, what as string)
    rc = ToStr(m.top.signalBeacon(name))
    if rc = "0" or rc = ""
        KLog("beacon", name + " (" + what + ") ok")
    else
        KLog("beacon", name + " (" + what + ") REJECTED rc=" + rc)
    end if
end sub

' Upload the previous (crashed) session's persisted log tail with the
' crash flag — the server files it as its own timestamped crash log and
' throttles per device, so fire-and-forget is safe. Skipped when there's
' nothing useful to send.
' This session's name: the second it started, plus a launch counter so that
' two launches inside the same second — which a crash loop will do — still
' get different names. The counter is read back out of the previous name and
' rolls over at a million, so the value can never grow past 17 characters.
function nextDiagSessionId(prev as string) as string
    n = 1
    at = Instr(1, prev, "#")
    if at > 0 then n = ToInt(Mid(prev, at + 1)) + 1
    if n < 1 or n > 999999 then n = 1
    return CreateObject("roDateTime").asSeconds().toStr() + "#" + n.toStr()
end function

sub uploadCrashLog(reason as string, forSession as string)
    ' ReadAsciiFile returns "" for a missing file — and unlike roFileSystem
    ' it's allowed on the render thread.
    tail = ReadAsciiFile("cachefs:/diag_tail.txt")
    if tail = "" then return

    ' ---- IS THIS LOG EVEN FROM THE SESSION THAT DIED? -----------------------
    '
    ' Nothing ever deletes diag_tail.txt — not after a report is sent, not at
    ' launch — so the file on disk is simply the last log that ANY session
    ' managed to save. A session that dies in its first few seconds never
    ' saves one, and that is exactly what a crash during launch does, so the
    ' report went out carrying the session before it. Report 191ED4 is a
    ' member closing the app normally, 22 hours earlier, printed underneath a
    ' crash header as though it were the crash.
    '
    ' v1.0.42 made that more dangerous rather than less: it taught the header
    ' to carry the real file and line of a caught fault, so a report now looks
    ' reliable while the log beneath it may belong to anybody.
    '
    ' So every saved log now starts with the name of the session that wrote
    ' it (AppShell.persistDiagTail) and this is where it is checked. If it
    ' does not match, the report still goes — the reason and the exit code are
    ' worth having on their own — but the log is left out and the report says
    ' so in words. A log saved by an older build carries no name and is
    ' treated the same way, once, on the first launch after the update.
    '
    ' THE FILE IS NEVER DELETED HERE, and that is deliberate. An upload that
    ' fails is one we want to be able to try again, and this lane has already
    ' lost crash reports to a flag being spent too eagerly.
    marker = "#kwick-session "
    tailSess = ""
    body = ""
    if Left(tail, Len(marker)) = marker
        nl = Instr(1, tail, Chr(10))
        if nl > Len(marker)
            tailSess = Mid(tail, Len(marker) + 1, nl - Len(marker) - 1)
            body = Mid(tail, nl + 1)
        end if
    end if
    trusted = (tailSess <> "" and forSession <> "" and tailSess = forSession)
    if trusted
        ' Scrubbed a second time on the way out. Every line in here was
        ' already scrubbed by KLog as it was written, so this is belt and
        ' braces - it costs one pass, once per launch, and it is the last
        ' chance to catch a credential before the file leaves the television.
        body = ScrubSecrets(body)
        KLog("app", "previous session crashed (" + reason + ") - sending crash log")
    else
        body = ""
        KLog("app", "previous session crashed (" + reason + ") - sending the report with NO log: the saved log is not this session's")
    end if
    ' BOTH FACTS, NOT ONE. A caught fault now outranks a bare OS exit code in
    ' crash_pending (see ArmCrashReport in Util.brs), so `reason` here is
    ' usually the named file and line - the part that was being lost. The OS's
    ' own code for how the session ended is a separate fact kept on its own
    ' key, and this is what puts it in the same report instead of only in the
    ' next session's log. Labelled separately on purpose: in a run of launch
    ' crashes the two lines can be from different deaths, so they are never
    ' presented as one event.
    head = "=== PREVIOUS SESSION CRASHED: " + reason + " (crash-on-next-launch report) ==="
    lastExit = RegRead("last_exit_reason")
    if lastExit <> "" and lastExit <> reason
        head = head + Chr(10) + "=== LAST OS EXIT CODE SEEN: " + lastExit + " ==="
    end if
    if not trusted
        ' Said in the report itself, not only in our own log, because the
        ' person reading the report is the one who needs to know the body is
        ' missing on purpose.
        whose = tailSess
        if whose = "" then whose = "an older build, which did not name it"
        mine = forSession
        if mine = "" then mine = "this one"
        head = head + Chr(10) + "=== NO LOG FOR THIS SESSION: the saved log was written by " + whose + ", not by the session being reported (" + mine + "), so it has been left out. The session that died saved nothing of its own, which almost always means it died within its first few seconds. ==="
    end if
    task = CreateObject("roSGNode", "ExportLogsTask")
    task.username = LogUsername()
    task.body = head
    if body <> "" then task.body = head + Chr(10) + body
    task.device = LogDeviceString()
    task.ver = KwickAppVersion()
    task.crash = true
    task.observeField("result", "onCrashLogSent")
    m.crashTask = task   ' keep a ref so the task isn't collected mid-flight
    task.control = "RUN"
end sub

sub onCrashLogSent()
    r = m.crashTask.result
    if GetField(r, "ok") = true
        KLog("app", "crash log filed, key " + ToStr(GetField(r, "key")))
    else
        KLog("app", "crash log upload failed: " + ToStr(GetField(r, "code")))
    end if
end sub

' ---- "Update available" nudge ----------------------------------------------
' Members install this app by sideloading a release zip, and a sideloaded
' channel updates itself never — so someone can sit on a build for weeks
' with the fix for the crash they keep hitting already published. Once per
' launch the app asks kwickplayer.tv what the newest build is, and if this
' one is older it says so, once, in plain language.
'
' STORE EDITION: COMPLETELY INERT — the check is never even fired. A channel
' installed from the Roku Channel Store updates itself through Roku, and
' certification takes a dim view of a channel pointing viewers at an update
' somewhere else. KwickEdition() (Theme.brs) reads the manifest's
' kwick_edition line, which `package.py --store` rewrites on its way into
' the zip; the working tree is always "sideload", so normal deploys always
' have the nudge.
sub startUpdateCheck()
    m.updateInfo = invalid
    if KwickEdition() = "store" then return
    m.updateTask = CreateObject("roSGNode", "UpdateCheckTask")   ' keep a ref so it isn't collected mid-flight
    m.updateTask.observeField("result", "onUpdateCheckDone")
    m.updateTask.control = "RUN"
end sub

' The answer is in. Anything short of "a build newer than this one, which
' this member hasn't already been told about" ends here, in silence.
sub onUpdateCheckDone()
    r = m.updateTask.result
    if GetField(r, "ok") <> true then return
    published = ToInt(GetField(r, "build"))
    mine = ToInt(CreateObject("roAppInfo").getValue("build_version"))
    if published <= mine then return
    ' Once per PUBLISHED build: someone who dismissed the 1.0.36 nudge is
    ' left alone until 1.0.37 exists, rather than being asked every launch.
    if UpdatePromptedBuild() >= published then return
    KLog("update", "build " + published.toStr() + " is published, this one is " + mine.toStr())
    m.updateInfo = r
    ' Onboarding or "Who's watching?" may still be on screen; showShell()
    ' calls back in once they aren't.
    maybeShowUpdateDialog()
end sub

' Shows the nudge, but only once the member is genuinely at Home: the shell
' exists (so onboarding and the profile picker are both done with) and no
' deep-link player is up in front of it. Nothing is retried — if this is the
' wrong moment, showShell() is the next and only other one.
sub maybeShowUpdateDialog()
    if m.updateInfo = invalid then return
    if m.shell = invalid then return       ' still onboarding / picking a profile
    if m.dlPlayer <> invalid then return   ' a deep link is playing - not now
    r = m.updateInfo
    m.updateInfo = invalid

    ' Remembered at SHOW time, not on the button. A member who dismisses
    ' this with Back never sends a buttonSelected event, and being nagged
    ' every launch for pressing the wrong key is exactly what "once per
    ' published build" is meant to prevent.
    SetUpdatePromptedBuild(ToInt(GetField(r, "build")))

    msg = "You have version " + KwickAppVersion() + ". Version " + ToStr(GetField(r, "version")) + " is out."
    notes = ToStr(GetField(r, "notes")).trim()
    if notes <> "" then msg = msg + Chr(10) + Chr(10) + shortNotes(notes)
    where = ToStr(GetField(r, "url")).trim()
    if where <> "" then msg = msg + Chr(10) + Chr(10) + "Get it at: " + plainAddress(where)

    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Update available"
    dialog.message = msg
    dialog.buttons = ["OK"]
    ' House rule: a D-pad user can't click, so the primary action is focused.
    dialog.focusButton = 0
    dialog.observeField("buttonSelected", "onUpdateDialogClosed")
    m.top.dialog = dialog
end sub

sub onUpdateDialogClosed()
    if m.top.dialog <> invalid then m.top.dialog.close = true
    ' The picker first: late-arriving profiles can raise it over the top of
    ' Home, and a nudge already on its way in would otherwise hand focus to the
    ' shell hidden behind it, leaving the member pressing keys at nothing.
    if m.picker <> invalid
        m.picker.setFocus(true)
    else if m.shell <> invalid
        m.shell.setFocus(true)
    end if
end sub

' Release notes as written on the server, but a Dialog has a finite box and
' an essay pasted into that field would push the address off the bottom of
' it. Cut at a readable length, on a space so a word isn't sliced in half.
function shortNotes(notes as string) as string
    limit = 320
    if Len(notes) <= limit then return notes
    cut = Left(notes, limit)
    at = 0
    for i = Len(cut) to 1 step -1
        if Mid(cut, i, 1) = " "
            at = i
            exit for
        end if
    end for
    ' Only honour a break that's near the end — a note with no spaces at all
    ' would otherwise be cut back to almost nothing.
    if at > limit - 60 then cut = Left(cut, at - 1)
    return cut.trim() + "…"
end function

' The address as a member would type it — no scheme, no trailing slash.
' Roku has no browser, so this is something to read off the TV and type into
' one somewhere else, exactly like the Get KwickTV dialog in AppShell.
function plainAddress(url as string) as string
    s = url.trim()
    if LCase(s.left(8)) = "https://" then s = Mid(s, 9)
    if LCase(s.left(7)) = "http://" then s = Mid(s, 8)
    if s.right(1) = "/" then s = Left(s, Len(s) - 1)
    return s
end function

' ---- How much memory this box will actually give the app --------------------
'
' WHAT IT IS FOR. Every memory decision in this app is a PERCENTAGE -- "stop
' at 70%", "no guide above 88%" -- and until now nobody had ever asked the box
' what those percentages are a percentage OF. One line at launch turns all of
' them into real megabytes, including every percentage already sitting in the
' logs we have kept: once a model's ceiling is known, every old reading from
' that model can be read as a size. Roku's own submission check has also asked
' for this call on every upload since v1.0.39 ("GetChannelMemoryLimit usage
' not found").
'
' IT WAS TRIED BEFORE, IT LOOKED BROKEN, AND IT WAS NOT. Crash reports used to
' end with "limitKB=" and nothing after it on all 146 logs in the archive, and
' the figure was removed as something no box would ever fill in. That was the
' wrong conclusion. The call hands back THREE numbers together, not one, and
' the old code pushed that set through a text converter that answers "" for
' anything which is not a single value. The boxes were answering all along.
'
' THE NUMBERS COME WITH NO UNITS. Roku's own documentation lists the three
' figures and never says whether they are megabytes, kilobytes or bytes, so
' the size of the number has to decide: a ceiling under about two thousand can
' only be megabytes, one under two million can only be kilobytes. The raw
' figure AND what it was taken to mean are both printed, so the first real log
' off a television settles it and nobody has to trust the guess.
'
' THIS IS A HEAP CEILING AND NOTHING MORE -- SAID PLAINLY SO NOBODY READS MORE
' INTO IT. Artwork is not heap. Posters, channel logos and media bar backdrops
' live in texture memory, Roku does not count one byte of them here, and that
' is where all five of this app's out-of-memory reports came from. A box that
' reports plenty of room on this line can still be killed by pictures.
'
' AND IT IS NOT A NEW TRIGGER FOR ANYTHING. Nothing reads this number; it is
' written down and that is all. The box's own alarm stays the only honest
' signal that memory is short -- a Streaming Stick 3800X was killed at about
' 55% of its stated limit, so a bigger ceiling would not have saved it.
'
' WHAT IT COSTS: three readings and one log line, once, at launch. The whole
' thing is wrapped so that a box which does not recognise one of these calls
' loses the line and nothing else -- a fault here would be a launch that never
' finishes, and no measurement is worth that.
' NO EARLY EXIT INSIDE THE try, deliberately: every branch is an if/else
' instead. Leaving a protected block part-way is the kind of thing that is
' fine on one BrightScript version and not another, and this sub cannot be
' compiled anywhere but on a television.
sub logMemoryCeiling()
    try
        mon = CreateObject("roAppMemoryMonitor")
        if mon <> invalid
            ' Read in the same breath as the ceiling, so a sweep can tie the
            ' two together: the percentage is what every guard in this app
            ' steers on, and the free figure is Roku's own kilobytes.
            pct = ToInt(mon.GetMemoryLimitPercent())
            freeKB = ToInt(mon.GetChannelAvailableMemory())
            tail = " - the app is using " + pct.toStr() + "% of it right now, " + freeKB.toStr() + " KB reported free"
            lim = mon.GetChannelMemoryLimit()
            fgN = ToInt(GetField(lim, "maxForegroundMemory"))
            bgN = ToInt(GetField(lim, "maxBackgroundMemory"))
            heapN = ToInt(GetField(lim, "maxRokuManagedHeapMemory"))
            if fgN <= 0 and heapN <= 0
                KLog("app", "memory ceiling: this box did not say what it allows" + tail)
            else
                ' Which unit the three numbers are in, decided by their size.
                ' This also keeps the arithmetic below inside a whole number:
                ' 2,000 megabytes and 2,000,000 kilobytes are both about two
                ' gigabytes, which is as large as a BrightScript whole number
                ' goes.
                biggest = fgN
                if heapN > biggest then biggest = heapN
                unitWord = "megabytes"
                mult = 1048576
                if biggest >= 2000
                    unitWord = "kilobytes"
                    mult = 1024
                end if
                if biggest >= 2000000
                    unitWord = "bytes"
                    mult = 1
                end if
                fgB = fgN * mult
                bgB = bgN * mult
                heapB = heapN * mult
                KLog("app", "memory ceiling (heap only - artwork is NOT counted here): foreground " + fgB.toStr() + " bytes, background " + bgB.toStr() + " bytes, Roku-managed heap " + heapB.toStr() + " bytes [raw " + fgN.toStr() + "/" + bgN.toStr() + "/" + heapN.toStr() + ", read as " + unitWord + "]" + tail)
            end if
        end if
    catch e
        ' Said out loud rather than swallowed. If a box ever does refuse one
        ' of these three calls, the reason is the whole finding, and a silent
        ' missing line would look exactly like the "limitKB=" dead end this
        ' replaces.
        KLog("app", "memory ceiling could not be read: " + ToStr(GetField(e, "message")))
    end try
end sub

' Roku says memory is short. Logged with the app's own reading beside it so
' the crash tail shows both what Roku saw and where this app actually was --
' and then, since v1.0.40, something is actually let go of. See
' shedOnMemWarning below for why this line on its own was the whole defect.
sub onMemWarning()
    line = ToStr(m.global.memWarning)
    if line = "" then return
    KLog("memory", "ROKU MEMORY ALARM " + line + " - app at " + M3uMemPercent().toStr() + "% of this device's limit")
    shedOnMemWarning(line)
end sub

' ---- Giving memory back when Roku asks for it -------------------------------
'
' MEASURED, member key D62C10, Roku Express (3910X), v1.0.39, 2026-09-23.
' They opened Live TV at 13:45:57 with the app holding 4% of what that box
' allows it. Over the next six minutes Roku raised the memory alarm TWENTY-
' THREE times -- "low", then "critical" over and over -- and the app's own
' headroom fell from 28,432 KB to 5,684 KB. At 13:52:21 Roku killed the app
' outright (EXIT_CHANNEL_MEM_LIMIT_FG). Seven of the twenty-two logs pulled
' that day end the same way on the same version.
'
' THE ALARM PLUMBING WAS NEVER THE PROBLEM. v1.0.38 made the box's own warning
' reach this scene and it worked perfectly -- all twenty-three arrived here.
' This sub wrote a log line and shed nothing, so the app watched itself die
' for six minutes. That was the defect, and this is the fix.
'
' WHAT IS LET GO OF, and why only this. m.global.xmltvById is the parsed TV
' guide: up to 12,000 programmes (XmltvTask.MAXKEPTPROGRAMMES), each a title,
' a description and two times, filed under the channel it belongs to. It is
' the biggest single thing this app keeps in memory, and it is a CACHE --
' every screen that reads it asks doesExist first and shows nothing when the
' answer is no. Dropping it cannot break anything; it can only empty the
' "what's on now" captions until the guide is read again. The callsign map
' beside it (xmltvAliases) goes with it, because it is only a set of pointers
' into the map that just went.
'
' HOW MUCH THAT IS WORTH, said honestly: single-digit megabytes. ESTIMATED,
' not measured -- 12,000 programmes, each an assocarray plus a title and an
' untruncated description (XmltvTask keeps <desc> whole), is somewhere around
' 6 MB. D62C10 lost 23 MB of headroom in their last thirty-four seconds. So
' this buys a session time; it is not a cure for whatever was actually growing
' on their Live TV screen. Texture memory -- the channel logos -- is not
' counted by roAppMemoryMonitor at all, so no heap shed will ever show against
' it.
'
' AND IT IS WORTH LESS ON THE TV GUIDE THAN ANYWHERE ELSE. GuideScreen's own
' m.epgCache holds THE SAME programme objects this map does (fillEpgFromXmltv
' pushes them straight across, it does not copy them), so with that screen on
' the television only the map's own structure is freed, not the programmes.
' On Live TV, on a channel page or in the player the guide screen has already
' been torn down by AppShell and the whole lot goes. Not worth reaching into
' another screen's cache from here to fix; worth knowing before anyone reads
' a log and concludes the shed did nothing.
'
' WHAT IS NOT TOUCHED: m.global.xmltvState keeps its value. GuideScreen,
' LiveTvScreen and ChannelDetailScreen all watch that field, and changing it
' here would kick all three into downloading a guide at the exact moment the
' box has said it has no room -- which is why this fix sat recorded and
' unshipped. Instead a separate flag, xmltvShed, is raised. Those three
' screens read the guide again the NEXT TIME the member opens one of them.
' Nothing downloads while the alarm is sounding.
'
' ONLY WHEN NO GUIDE IS BEING READ. A parse in flight is about to write into
' this map, and emptying it underneath would cost the download as well as the
' cache. INFERENCE, not measured -- no log shows that happening, because
' nothing has ever shed before.
'
' ONCE PER STORM. D62C10 got twenty-three alarms in six minutes. Re-dropping
' an already-empty map twenty-two more times is pointless work at the worst
' possible moment, so the flag is its own guard: while it is still raised,
' every further alarm returns on a single boolean. The five-minute wait and
' the three-a-launch ceiling guard the other direction -- a member who opens
' the TV Guide after a shed reloads the guide, and without them the next
' alarm would drop it again and a dying session would spend itself
' downloading guides in a circle.
'
' NOT GATED ON A PERCENTAGE, deliberately. GetMemoryLimitPercent() is not
' honest about when a box is in trouble: a Streaming Stick 3800X was killed
' at about 55% of it, and in this same 2026-09-23 batch member 44480F was
' killed at 29%. Roku's own alarm is the only trigger worth acting on, and it
' is already the only thing that reaches this sub.
sub shedOnMemWarning(alarm as string)
    if m.global = invalid then return
    if not m.global.hasField("xmltvShed") then return

    ' A guide is being read right now. Leave it be.
    '
    ' SAID OUT LOUD, because this is the only way out of this sub that can
    ' happen on a television which has never shed anything -- so it is the
    ' only one that could be mistaken for the handler not running. The three
    ' guards below it all require a "MEMORY SHED" line to be sitting in the
    ' same log already, which says plainly enough that the handler ran. Do
    ' not add lines to those three: they would cost a log write each on every
    ' alarm of a storm and tell nobody anything new.
    if LCase(ToStr(m.global.xmltvState)) = "loading"
        noteShedSkip("a guide is being read right now, so the guide in memory is left alone", -1)
        return
    end if

    ' Already let go of, and no screen has read one back in since. This is the
    ' once-per-storm guard and it costs one field read.
    if m.global.xmltvShed = true then return

    if m.memShedCount = invalid then m.memShedCount = 0
    if m.memShedCount >= MemShedMaxPerLaunch() then return
    if m.memShedAt = invalid then m.memShedAt = 0
    secs = CreateObject("roDateTime").asSeconds()
    if m.memShedAt > 0 and (secs - m.memShedAt) < MemShedCooldownSeconds() then return

    ' THE ONLY PLACE THAT TOUCHES THE MAP, and it touches it once. Reading a
    ' node field hands back a copy of the whole assocarray, which is the last
    ' thing to be doing at 97% -- so the count is taken once, the copy is
    ' dropped on the next line, and nothing else here reads the field. The
    ' invalid check is not paranoia for its own sake: this runs on the render
    ' thread with the box already in trouble, and a fault here would take the
    ' screen down harder than the memory would have.
    byId = m.global.xmltvById
    if byId = invalid then return
    held = byId.count()
    byId = invalid
    ' No guide loaded on this session -- nothing to give back, and nothing to
    ' flag either, or three screens would go and fetch one for no reason.
    '
    ' THIS IS THE LINE THE 2026-10-02 SWEEP WAS MISSING. Every member who set
    ' the alarm off that week left on this return, silently. See noteShedSkip.
    if held = 0
        noteShedSkip("there is no TV guide in memory to let go of", held)
        return
    end if

    ' Before and after on the same box in the same second. The ABSOLUTE figure
    ' is not trustworthy (see the note above) but the DIFFERENCE between two
    ' readings a moment apart is the only evidence the next member log can
    ' carry about whether this did anything at all.
    was = M3uMemPercent()
    m.global.xmltvById = {}
    m.global.xmltvAliases = {}
    m.global.xmltvShed = true
    m.memShedAt = secs
    m.memShedCount = m.memShedCount + 1
    KLog("memory", "MEMORY SHED " + m.memShedCount.toStr() + ": let go of the TV guide (" + held.toStr() + " channels) - " + memAlarmHeadroom(alarm) + " - app " + was.toStr() + "% -> " + M3uMemPercent().toStr() + "% of this device's limit")
end sub

' ---- Saying so when the shed lets go of nothing ------------------------------
'
' WHY THIS EXISTS. The 2026-10-02 sweep: thirteen member logs, twelve of them
' on v1.0.40, and NOT ONE of them carries a "MEMORY SHED" line -- while four
' televisions set Roku's memory alarm off between them. On all four there was
' no TV guide in memory to let go of, so the sub above reached "held = 0" and
' returned without saying a word. In plain words, what happened on each set:
'
'   21A1EB, a Roku Streaming Stick (3840X): six alarms, the app peaking at
'     93% of what that stick allows it. Their channel page wrote "guide 0
'     row(s)" twice -- a guide was asked for and came back with nothing in it.
'   B6DA8F, a Westinghouse WR70UT4212: twelve alarms, peaking at 95%. BOTH of
'     this member's guide files were turned away before they were read -- 66 MB
'     and 70 MB against the 24 MB this app will accept. Nothing was ever
'     parsed, so there was never anything to free.
'   74D974, an onn 100058007-CA: one alarm at 75%. Their guide address
'     answered "not found".
'   0717CB, a Roku Streaming Stick Plus: four alarms. No guide was ever read
'     at all on that session.
'
' Four for four, the members who run out of memory are the members with no
' guide -- so the one thing this app knows how to let go of is the one thing
' they are not holding. In the log, "the shed ran and found nothing" and "the
' shed never ran" looked exactly the same, and telling them apart took reading
' four members' logs against this file side by side. One line ends that.
'
' AND WHAT IT SAYS NEXT IS THE HALF THAT IS WORTH SOMETHING. This handler runs
' on the root scene's own thread, and the ONLY memory it can see -- or free --
' is the shared store every screen writes into, m.global. It cannot look
' inside a screen. So the line reports what the shared store is holding, and
' in doing so it says where the memory is NOT.
'
' >>> AND ON THESE FOUR TELEVISIONS THE SHARED STORE IS EMPTY. <<< Not one of
' the four logs has a single "playlists in memory" line. These are all Xtream
' panels, whose channels are fetched by the screen that needs them and never
' go into the shared store at all. Their real holdings sit INSIDE the screens,
' out of reach from here. B6DA8F's own log is the whole case on one set:
' 25,884 channels scanned for the Sports page, 3,823 fixtures across 11 sports
' built over 39 seconds, and an 11,047-row Search list -- none of it visible
' from this sub and none of it freeable from this sub. Whether any of that
' should be let go of is ledger RK-013's question; this line is the evidence
' for it, not the answer.
'
' WHAT IT COSTS. One log line. That is the same cost as the "ROKU MEMORY
' ALARM" line printed immediately above it, so the alarm path's logging
' roughly doubles -- six extra lines over 21A1EB's session, twelve over
' B6DA8F's. Nothing is created, nothing is parsed and NO MAP IS COPIED: the
' guide count is the one already taken above and handed in rather than read a
' second time, and the only two reads here are a short piece of text and a
' list the grid itself caps at a few hundred entries.
'
' guideChans is -1 for "not looked at". That is what the "a guide is being
' read" branch passes, because it returns BEFORE the one place allowed to
' touch the guide map and must never become a second place that does.
sub noteShedSkip(reason as string, guideChans as integer)
    glob = m.global
    if glob = invalid then return
    guideWord = "not looked at"
    if guideChans >= 0 then guideWord = guideChans.toStr() + " channel(s)"
    phase = "?"
    if glob.hasField("xmltvState")
        phase = ToStr(glob.xmltvState)
        if phase = "" then phase = "never asked for"
    end if
    liveWord = "unknown"
    if glob.hasField("liveLineup")
        lineup = ToArray(glob.liveLineup)
        liveWord = lineup.count().toStr()
        lineup = invalid
    end if
    KLog("memory", "MEMORY SHED skipped: " + reason + " - shared store holds: TV guide " + guideWord + " (guide state: " + phase + "), live channel list " + liveWord + " entry(s). Anything a screen is holding on its own cannot be seen or freed from here.")
end sub

' Long enough that a member who re-opens the guide straight after a shed is
' not immediately shed again; short enough that a session which runs on can
' still be helped a second time. XmltvTask allows one guide 300s of its own,
' so this is the same order as the thing it is protecting.
function MemShedCooldownSeconds() as integer
    return 300
end function

' A ceiling as well as a wait, so the worst a whole session can cost is three
' extra guide downloads rather than one per alarm.
function MemShedMaxPerLaunch() as integer
    return 3
end function

' Pull "appHeadroomKB=NNNN" back out of the alarm line main.brs built, so the
' shed line carries the same number the alarm line above it did without asking
' the box again. String work only -- nothing is created and nothing can fail.
function memAlarmHeadroom(alarm as string) as string
    hit = Instr(1, alarm, "appHeadroomKB=")
    if hit <= 0 then return "appHeadroomKB=?"
    return Mid(alarm, hit)
end function
