sub init()
    m.theme = KwickTheme()
    m.branding = KwickBranding()
    m.sidebar = m.top.findNode("sidebar")
    m.content = m.top.findNode("content")

    m.sidebar.observeField("itemSelected", "onSidebarSelect")

    ' Screen component per sidebar slot. "Get KwickTV" is an action, not a
    ' screen (Roku can't open a browser), so it's handled in onSidebarSelect.
    ' Must mirror Sidebar's item list exactly, guard included: the storefront
    ' is the LAST slot and only the sideload edition has it, so a store build
    ' ends one entry early on both sides and every index above is unmoved.
    m.screenNames = ["HomeScreen", "SearchScreen", "LiveTvScreen", "GuideScreen", "VodScreen", "SportsScreen", "SettingsScreen"]
    if ShowStorefront() then m.screenNames.push("")
    m.currentIndex = -1
    m.currentScreen = invalid
    ' The exit confirmation, while it is up. Declared HERE rather than on
    ' first use because onKeyEvent reads it, and a remote press can arrive
    ' before anything else has run - an undeclared m.field reads as invalid on
    ' this box, but relying on that is how the next person gets a surprise.
    m.exitDialog = invalid

    ' If focus ever lands on the shell itself (AppScene focuses us as a
    ' unit), hand it straight to the sidebar — a focused Group with no
    ' delegation swallows every remote press.
    m.top.observeField("focusedChild", "onShellFocus")

    ' AppScene tells us when the profile underneath us has changed.
    m.top.observeField("reloadProfile", "onReloadProfile")
    ' ...and when an overlay it raised over us has gone away again.
    m.top.observeField("focusContent", "onFocusContent")
    ' ...and when it is about to throw this whole shell away. See onTearDown.
    m.tornDown = false
    m.top.observeField("tearDown", "onTearDown")

    ' Which shell this is. Taken BEFORE showScreen() below: showScreen calls
    ' persistDiagTail(), which is where the number is first printed.
    m.shellNo = shellSerialNext()

    ' Open on the screen THIS PROFILE asked for rather than always Home —
    ' see the startup-screen section at the bottom of this file.
    '
    ' ONE screen is built, never two: the slot is decided before anything is
    ' created, so nothing is built and thrown away and this adds no step in
    ' front of the first painted frame. Certification 3.2 gives the whole
    ' launch 15 seconds and AppScene stops the clock the moment this init
    ' returns (beaconLaunchComplete) — what happens below has to be free,
    ' and it is: one registry read and a substring scan for a member who has
    ' never touched the setting.
    startIdx = startupIndex()
    showScreen(startIdx)
    ' Home keeps the launch feel it has always had — focus on the rail. A
    ' member who asked to open somewhere else is put INSIDE that screen,
    ' which is what they asked for, and which also keeps the rail from lying
    ' about where its cursor is (see the note in showScreen).
    if startIdx = 0 or m.currentScreen = invalid
        m.sidebar.setFocus(true)
    else
        m.currentScreen.setFocus(true)
    end if

    startBackgroundSync()
end sub

' ---- Which shell is this? ---------------------------------------------------
'
' The shell is NOT the app. AppScene throws it away and builds a new one on a
' profile switch (showPicker) and on sign-out (showOnboarding), so one session
' can print the same set of launch lines several times over.
'
' Nothing in the log said WHICH shell printed them. Dave's reading of crash
' report R3 (RK-006, 2026-09-19): a repeated launch banner with no way to tell
' whether the second shell had replaced the first or joined it, and no way to
' count how many were still ticking. One integer answers that, and it costs one
' field on a node that already exists.
'
' Counted on the global node because it has to outlive the shell being
' replaced. Created on first use, exactly like addOnSyncRequest further down:
' the session globals in AppScene.brs belong to another owner and this is not
' worth a line on theirs.
function shellSerialNext() as integer
    if m.global = invalid then return 1
    if not m.global.hasField("shellSerial") then m.global.addFields({ shellSerial: 0 })
    n = ToInt(m.global.shellSerial) + 1
    m.global.shellSerial = n
    return n
end function

' KwickSync in the background: one cycle at launch, then every 90s (matches
' the Android cadence). No-ops when the toggle is off or there's no KwickTV
' login. Shares the registry mirror with the manual "Sync now" in Settings.
sub startBackgroundSync()
    m.syncTask = CreateObject("roSGNode", "SyncTask")
    m.syncTask.observeField("result", "onBgSyncResult")
    if SyncEnabled() and SyncEligible()
        m.syncTask.control = "RUN"
    else
        ' Nothing is coming, so nothing is waiting on it. See markSyncPrimed.
        markSyncPrimed()
    end if

    m.syncTimer = CreateObject("roSGNode", "Timer")
    m.syncTimer.duration = 90
    m.syncTimer.repeat = true
    m.syncTimer.observeField("fire", "onSyncTick")
    m.syncTimer.control = "start"

    ' The log tail on its own timer, and a much shorter one.
    '
    ' Why: the tail was written on every navigation and then only every 90
    ' seconds, so a crash report named the screen the member was on and told
    ' us NOTHING about what happened there — everything after the nav line
    ' was still in memory when the app died. That is exactly backwards: the
    ' seconds after opening a screen are the ones worth having. A member's
    ' Roku Express crashed on the TV Guide (key 1AB8C3, v1.0.25) and the
    ' report ended at "opened GuideScreen".
    '
    ' persistDiagTail() no-ops when the buffer hasn't grown, so a quiet app
    ' still writes nothing — this costs a length comparison every 15s.
    m.tailTimer = CreateObject("roSGNode", "Timer")
    m.tailTimer.duration = 15
    m.tailTimer.repeat = true
    m.tailTimer.observeField("fire", "onTailTick")
    m.tailTimer.control = "start"

    ' First tail snapshot right away — a crash inside the first 90 seconds
    ' should still leave the launch log behind for the crash report.
    persistDiagTail()

    startAddOnWatchlists()
end sub

' ---- Going away -------------------------------------------------------------
'
' THE PROBLEM. Everything startBackgroundSync() and startAddOnWatchlists()
' create is made with CreateObject, which means it is NOT a child of this
' component. `removeChild(shell)` in AppScene reaches this component's own
' subtree — the sidebar and the content group — and reaches none of the rest:
' four Timers (90s sync, 15s crash-tail, 60s add-on, 5s add-on start), a
' SyncTask, an AddOnSyncTask, and one observer planted on m.global.
'
' Every one of those is half of a cycle. We hold the timer; the timer's
' observer holds this component. We observe m.global; m.global — which lives
' for the whole life of the app — holds this component back. BrightScript
' counts references and has no cycle collector, so neither end can be let go
' of by itself. Before this sub existed there was no unobserveField and no
' `control = "stop"` anywhere in this file.
'
' >>> WHAT IS MEASURED AND WHAT IS NOT. READ THIS BEFORE QUOTING IT. <<<
'
' MEASURED: nothing. Nobody has watched a second shell tick on a real box, and
' no memory reading has been taken across a profile switch. What is verified is
' only that the references above existed in the source and now do not.
'
' INFERENCE: that they were enough to keep an entire dead shell alive —
' sidebar, current screen and that screen's content — still running a
' 90-second KwickSync cycle and a 15-second flash write for the rest of the
' session, once per profile switch and once per sign-out.
'
' SO THIS DOES NOT CLAIM A LEAK IS FIXED. It removes the references that could
' cause one. The proof is on the television: switch profiles and the console
' must show "shell #1 torn down" before "shell #2 up", and nothing from #1 may
' be heard from again.
'
' The shape is the one the 2026-09-14 memory sweep settled on for observers
' planted on m.global — scoped registration, so the observer goes when the node
' goes even if a future caller forgets this sub exists (PlayerScreen.brs:4655,
' PosterCard.brs:184). The explicit unobserve is kept as well because, unlike a
' recycled card, a shell does have a close path to call it from.
sub onTearDown()
    reason = ToStr(m.top.tearDown)
    if reason = "" then return
    ' alwaysNotify, so this write comes straight back through here — the guard
    ' above catches it on the way in. Same idiom as onReloadProfile.
    m.top.tearDown = ""
    ' Once only. Everything below is safe to run twice, but the log line is
    ' not: two "torn down" lines for one shell would read as two shells.
    if m.tornDown = true then return
    m.tornDown = true
    tearDownShell(reason)
end sub

sub tearDownShell(reason as string)
    ' ---- The four timers. Stopped BEFORE they are unobserved, so a fire that
    ' is already on its way has nothing left to call.
    if m.syncTimer <> invalid
        m.syncTimer.control = "stop"
        m.syncTimer.unobserveField("fire")
        m.syncTimer = invalid
    end if
    if m.tailTimer <> invalid
        m.tailTimer.control = "stop"
        m.tailTimer.unobserveField("fire")
        m.tailTimer = invalid
    end if
    if m.addOnTimer <> invalid
        m.addOnTimer.control = "stop"
        m.addOnTimer.unobserveField("fire")
        m.addOnTimer = invalid
    end if
    if m.addOnStartTimer <> invalid
        m.addOnStartTimer.control = "stop"
        m.addOnStartTimer.unobserveField("fire")
        m.addOnStartTimer = invalid
    end if
    m.addOnStartPending = false

    ' ---- The two Task nodes: UNOBSERVED AND DROPPED, DELIBERATELY NOT STOPPED.
    '
    ' A cycle already in flight is left to finish on its own thread and release
    ' the single-flight slot the ordinary way, at the end of its own run.
    ' Killing a SyncTask mid-write would leave that claim standing and the
    ' registry half applied — a worse bug than the one this sub is for, and the
    ' task is not this department's to stop. Nothing here is waiting on the
    ' answer: the screen onBgSyncResult would have refreshed is being removed,
    ' and the next shell runs its own cycle as soon as it is built.
    if m.syncTask <> invalid
        m.syncTask.unobserveField("result")
        m.syncTask = invalid
    end if
    if m.addOnTask <> invalid
        m.addOnTask.unobserveField("result")
        m.addOnTask = invalid
    end if
    m.addOnSyncBusy = false

    ' ---- The one observer that points INTO this component from outside it,
    ' and the reason this sub is worth writing at all. m.global is never
    ' collected, so this registration outlives everything else here.
    ' unobserveFieldScoped, not unobserveField: the scoped form is what
    ' startAddOnWatchlists registers and the plain form does not remove it.
    if m.global <> invalid then m.global.unobserveFieldScoped("addOnSyncRequest")

    ' ---- Everything else this component observed. All of it is m.top itself or
    ' something inside our own subtree, so none of it is the suspected retention
    ' path — but a cycle sitting entirely inside a removed subtree is still a
    ' cycle a reference count cannot break, and undoing these costs nothing.
    if m.currentScreen <> invalid
        if m.currentScreen.hasField("backToNav") then m.currentScreen.unobserveField("backToNav")
        if m.currentScreen.hasField("signedOut") then m.currentScreen.unobserveField("signedOut")
    end if
    m.top.unobserveField("focusedChild")
    m.top.unobserveField("reloadProfile")
    m.top.unobserveField("focusContent")
    ' NOT "tearDown" — we are standing inside its own callback.
    '
    ' m.sidebar, m.content and m.currentScreen keep their references on purpose.
    ' Nulling them buys nothing (the whole subtree is released together the
    ' moment this component is) and onKeyEvent reads m.sidebar with no invalid
    ' guard at all, so an invalid there would be a render-thread kill for a
    ' tidiness that has no effect.

    ' ---- An exit confirmation left standing. It cannot happen on either of the
    ' two paths that call this — the dialog leads to the app closing or to
    ' itself closing — but it is parented to the SCENE, not to us, so if it ever
    ' did happen it would sit on screen forever with nobody left to dismiss it.
    ' Unobserved first, so onExitDialogClosed does not run against a shell that
    ' is being removed.
    if m.exitDialog <> invalid
        m.exitDialog.unobserveField("buttonSelected")
        m.exitDialog.unobserveField("wasClosed")
        m.exitDialog.close = true
        m.exitDialog = invalid
    end if

    ' Pairs with the "shell #N up" line in persistDiagTail. Flushed to disk
    ' straight away for the same reason every navigation is: a crash report is
    ' only as good as the tail that survived it, and "how many shells were
    ' alive" is exactly what R3 could not answer.
    KLog("app", "shell " + shellTag() + " torn down (" + reason + ") - timers stopped, observers dropped")
    persistDiagTail()
end sub

' "#2" — the shell's own number, for a log line. Guarded because m.shellNo is
' set in init and a crash before that would otherwise take the log with it.
function shellTag() as string
    if m.shellNo = invalid then return "#?"
    return "#" + m.shellNo.toStr()
end function

sub onSyncTick()
    ' Piggyback on the 90s heartbeat: persist the log tail so a crash
    ' leaves something for the next launch to report (crash detection).
    persistDiagTail()
    if not (SyncEnabled() and SyncEligible())
        markSyncPrimed()
        return
    end if
    if m.syncTask <> invalid and m.syncTask.state = "run" then return
    m.syncTask.control = "RUN"
end sub

' The newest ~30KB of the session log, written to cachefs so it survives
' the app dying. Read back (and uploaded with crash:true) by AppScene when
' a launch finds the previous session's alive-sentinel still set.
sub onTailTick()
    persistDiagTail()
end sub

sub persistDiagTail()
    if m.global = invalid or not m.global.hasField("diagLog") then return
    buf = m.global.diagLog
    if buf = "" then return
    ' Nothing new since the last write — don't burn a flash write on it.
    if m.tailLen <> invalid and buf.len() = m.tailLen then return
    m.tailLen = buf.len()
    if buf.len() > 30000 then buf = buf.right(30000)
    ' WHOSE SESSION THIS LOG IS, on its first line.
    '
    ' Nothing ever deletes this file - not after a crash report is sent,
    ' not at launch - so a session that dies before it gets this far leaves
    ' the PREVIOUS session's log sitting on disk, and the next launch used
    ' to send that up as the crash report. One report (key 191ED4) was a
    ' member closing the app normally 22 hours earlier, presented as a
    ' crash. The name written here is what the next launch compares
    ' against before it trusts this file - see uploadCrashLog in
    ' AppScene.brs, which is the only thing that reads it.
    '
    ' Costs about 26 bytes at the top of the file and nothing else. A
    ' missing name (which cannot happen once AppScene has run) reads back
    ' as blank and the next launch refuses the log, which is the safe way
    ' round.
    stamp = ""
    if m.global.hasField("sessId") then stamp = m.global.sessId
    ok = WriteAsciiFile("cachefs:/diag_tail.txt", "#kwick-session " + stamp + Chr(10) + buf)
    ' Note the outcome once per SHELL — m.tailNoted lives on this component, so
    ' a rebuilt shell says it again, and that is exactly what makes this the
    ' line the shell number belongs on. It is the first thing a new shell
    ' prints, so in a crash tail "shell #2 up" is the boundary between one
    ' shell's lines and the next one's. See shellSerialNext().
    if m.tailNoted = invalid
        m.tailNoted = true
        if ok
            KLog("app", "shell " + shellTag() + " up - crash-tail persistence active (" + buf.len().toStr() + "B)")
        else
            KLog("app", "shell " + shellTag() + " up - crash-tail write FAILED, crash reports will be empty")
        end if
    end if
end sub

' After a background sync applies remote changes, refresh the visible screen
' so new favorites/lists/profiles appear without a manual reload.
sub onBgSyncResult()
    markSyncPrimed()
    if m.currentScreen <> invalid and m.currentScreen.hasField("reloadFromSync")
        m.currentScreen.reloadFromSync = true
    end if
end sub

' ---- "This box has heard from the locker at least once this launch" ---------
'
' Home is drawn BEFORE the first sync cycle finishes — about two seconds
' before, measured off a real launch log. In that gap a film the member
' watched on their phone has no resume point HERE, so the box offers to play
' it from the beginning, and if they take that offer the position they were
' really at is overwritten by an honest, newer, wrong one. Their phone loses
' it permanently.
'
' Android settled the merge rule and it is NOT changing: "most recently
' updated wins" is right, because a deliberate rewind and a stale start
' produce byte-identical rows and no receiving-side rule can tell them apart
' without also refusing genuine rewinds. See
' [[Sync - Resume Merge Rule (Android Answer For Dave)]]. So the fix has to be
' here, on the device that is about to offer a starting point it has reason to
' doubt.
'
' This flag is that doubt, and it is deliberately coarse: one bit, per launch,
' set the first time a cycle ANSWERS — success or failure, both mean the
' waiting is over. PlayerScreen is the only thing that reads it.
'
' It is set for a box that is not syncing at all, too. A member with the
' toggle off or no KwickTV login is never going to hear anything, and
' something that waits forever for an answer that is not coming would hold
' back their resume points for the life of the session.
sub markSyncPrimed()
    if m.global = invalid then return
    if m.global.syncPrimed = true then return
    m.global.syncPrimed = true
end sub

' The active profile has changed while the shell stayed up. Favorites, lists,
' recents and resume points all live in that profile's own registry keys, so
' whatever is on screen is now showing somebody else's things.
'
' This happens on one path only: a fresh sign-in where the locker took longer
' than five seconds, so the home screen was rendered against no profile at all
' and the real ones landed afterwards (adoptLateProfiles in AppScene.brs).
'
' Rebuild the CURRENT SCREEN, not the shell. The sidebar is the same for every
' profile, and pulling the shell out from under a member who is looking at it
' is exactly the restart-flicker that whole path exists to avoid.
sub onReloadProfile()
    if m.top.reloadProfile <> true then return
    ' alwaysNotify, so this write comes straight back through here — the guard
    ' above catches it on the way in.
    m.top.reloadProfile = false
    idx = m.currentIndex
    if idx < 0 then return
    ' A profile has just been settled on, and a profile gets to say which
    ' screen it opens on. The phone navigates to exactly that after its own
    ' picker (profile_picker_screen.dart:30), so a switch here does the
    ' same. A profile that has not chosen leaves idx alone and this stays
    ' what it always was: rebuild the screen already on show.
    want = startupIndex()
    if want > 0 then idx = want
    ' showScreen() returns early when asked for the screen it is already on,
    ' which is normally right and is exactly wrong here.
    m.currentIndex = -1
    showScreen(idx)
    if idx = 0 or m.currentScreen = invalid
        m.sidebar.setFocus(true)
    else
        m.currentScreen.setFocus(true)
    end if
end sub

' AppScene raised something full-screen over the shell and it has gone away
' again without changing anything. m.top.setFocus() would hand focus to the
' rail (onShellFocus), so the member would come back from a cancelled
' "Who's watching?" standing somewhere they never were.
sub onFocusContent()
    if m.top.focusContent <> true then return
    ' alwaysNotify, so this write comes straight back through here — the
    ' guard above catches it on the way in. Same idiom as onReloadProfile.
    m.top.focusContent = false
    if m.currentScreen <> invalid
        m.currentScreen.setFocus(true)
    else
        m.sidebar.setFocus(true)
    end if
end sub

sub onShellFocus()
    if m.top.hasFocus() then m.sidebar.setFocus(true)
end sub

sub onSidebarSelect()
    idx = m.sidebar.itemSelected
    if m.screenNames[idx] = ""
        showStoreDialog()
        return
    end if
    showScreen(idx)
    if m.currentScreen <> invalid then m.currentScreen.setFocus(true)
end sub

' A film, series or channel page is a SCENE child, not a child of the screen
' that opened it: Home, Search, Movies & Series and the Guide all do
' `scene.createChild("...DetailScreen")` and hold it in their own m.detail,
' and the only thing that ever removes it is that screen's onDetailClosed.
' So if THIS shell swaps screens while a detail page is up - a profile reload
' (onReloadProfile, which is asynchronous and does not care where focus is),
' or the Multi-View hand-off's last-resort branch, which focuses the sidebar
' with the film page still attached behind it - the opener dies, its observer
' on `closed` dies with it, and the page stays on the scene for the life of
' the app holding a 1920 x 768 backdrop (5.6 MB) and everything under it.
' Nothing left in the app can ever remove it. Found on the 2026-09-14 memory
' sweep for a Streaming Stick 4K that read 70% on Settings after leaving VOD.
'
' So the shell sweeps the scene for the three detail page types before it
' throws the current screen away. Only those three: a PlayerScreen can be
' legitimately alive here (the hand-off case above) and is not ours to kill.
sub closeSceneDetails()
    scene = m.top.getScene()
    if scene = invalid then return
    kinds = { MovieDetailScreen: true, SeriesDetailScreen: true, ChannelDetailScreen: true }
    n = scene.getChildCount()
    ' Walk backwards: removing a child shifts everything after it.
    for i = n - 1 to 0 step -1
        child = scene.getChild(i)
        if child <> invalid and kinds.doesExist(child.subtype())
            KLog("nav", "closing a " + child.subtype() + " left on the scene by the screen being replaced")
            scene.removeChildIndex(i)
        end if
    end for
end sub

sub showScreen(idx as integer)
    if idx = m.currentIndex then return
    if m.currentScreen <> invalid
        closeSceneDetails()
        m.content.removeChild(m.currentScreen)
        m.currentScreen = invalid
    end if
    m.currentIndex = idx
    m.sidebar.selectedIndex = idx
    ' The rail's SELECTED item and the rail's CURSOR are two different
    ' things, and only the first has a way in. Sidebar keeps its cursor in
    ' its own m.focused and moves it on Up/Down alone — focusedIndex is a
    ' field it writes OUT when the cursor moves, not one it reads — so
    ' opening on a screen the member did not walk to leaves the cursor
    ' sitting on Home while the accent sits on, say, Live TV, and their
    ' first OK press goes to the wrong place.
    '
    ' Written anyway, because this is the field the fix belongs on: one line
    ' in Sidebar.brs (observe focusedIndex and set m.focused from it — init
    ' alone is too early, XML children are built before this one runs) and
    ' every route through here lines up. Reported to Sidebar's owner;
    ' harmless until then, and until then AppShell puts focus INSIDE the
    ' opened screen rather than on a rail that would point at the wrong item.
    m.sidebar.focusedIndex = idx
    m.currentScreen = m.content.createChild(m.screenNames[idx])
    ' Leave a breadcrumb AND flush it to disk on every navigation. A crash
    ' report is only as good as the log tail that survived it, and the tail
    ' was only written at launch and then every 90 seconds — so a crash in
    ' the first minute (the common case) filed a report containing nothing
    ' but the launch banner. A member's Roku Express crashed twice on
    ' 2026-08-09 and the reports were 254 bytes of "hello". Now the report
    ' at least names the screen they were on.
    ' THE MEMORY READING RIDES ALONG, and it is the line that was missing when
    ' six members on cheap boxes were killed with EXIT_CHANNEL_MEM_LIMIT_FG and
    ' every report could only say which screen they were on. One of them was
    ' holding 353 channels and 5% of the device - so size was never the story,
    ' and without a number per navigation there was no way to see that.
    KLog("nav", "opened " + m.screenNames[idx] + " - app at " + M3uMemPercent().toStr() + "% of this device's limit")
    persistDiagTail()
    if m.currentScreen.hasField("backToNav")
        m.currentScreen.observeField("backToNav", "onBackToNav")
    end if
    if m.currentScreen.hasField("signedOut")
        m.currentScreen.observeField("signedOut", "onScreenSignedOut")
    end if
end sub

' backToNav means LEFT, and only Left. Focus returns to the sidebar, same feel
' as the Android D-pad flow. Left is a DIRECTION, not an exit: it walks toward
' the rail and stops there.
'
' It used to mean Back as well. Every shell screen raised this field from a
' single `key = "back" or key = "left"` branch, so by the time it arrived here
' the key that caused it was gone — and the second Back, now on the rail, was
' handled by nothing in this file, in Sidebar.brs or in AppScene.brs, fell
' through the whole tree to the firmware, and closed the app. From VOD that was
' two presses and gone. Eleven sites across six screens were split in the
' 2026-08-26 pass; Back now returns FALSE from the screen and bubbles up to
' onKeyEvent below, which walks out toward Home and raises the one exit
' confirmation certification 4.6 permits.
'
' >>> TWO EXCEPTIONS, BOTH CORRECT. DO NOT "FINISH THE JOB". <<<
'
'   * HomeScreen.brs:1813 still spells it `key = "back" or key = "left"`, and
'     that is A RULING, NOT AN OVERSIGHT. The owner, verbatim: "back on home
'     takes you to sidebar, back again is close confirm". So on Home — and
'     ONLY on Home — Back parks on the rail exactly as Left does, and it is
'     the SECOND press, arriving here from the rail, that raises the exit
'     dialog. Making Home consistent with the other screens is the obvious
'     tidy-up and it breaks precisely what he asked for.
'
'   * LiveTvScreen.brs:1928 reaches the raise on Left alone, but by a
'     different shape: the line immediately above it is
'     `if key = "back" then return false`, so Back returns early and never
'     gets here. Same result, written as a guard rather than a second branch.
'     Do not "normalise" it into an `else if key = "left"` without reading
'     what the early return is protecting — flattening it would put the raise
'     back on Back.
'
' Everything else in components/screens/ raises this under `key = "left"`.
sub onBackToNav()
    m.sidebar.setFocus(true)
end sub

' ---- Back, from the rail outward (Roku certification 4.6) -------------------
'
' 4.6, verbatim: "Apps must directly return the user to the previous screen
' and/or state when the back button on the Roku remote is pressed. When the
' back button is pressed on the app's home screen, apps must exit the app and
' return the user to the Roku home screen. Apps may display a single
' confirmation dialog immediately before the user exits the app - and then
' return the user to the Roku home screen upon receiving confirmation that
' they want to leave the app."
'
' So the walk out is: Back inside a shell screen returns false and bubbles to
' onKeyEvent below -> Home -> one confirmation -> gone. Home itself is the
' exception described above: there, Back parks on the rail first and the second
' press raises the dialog. No screen is a dead end and no screen closes the app
' from under the member.
'
' WHAT THIS DOES NOT COVER, stated plainly: the nine overlay screens are
' children of the SCENE, not of this shell, so their Back never passes through
' here. They close themselves back to whoever opened them, which is correct.
' OnboardScreen used to be the hole in that — it returned false from Back with
' no source configured, which fell through to the firmware and closed the app
' from a non-home screen, a live 4.6 breach. It now routes through its own
' onboardBack() ladder and no path returns false.
'
' >>> THE TRAP THIS PATTERN SETS, AND IT BIT THREE TIMES IN ONE PASS. <<<
'
' A shell screen hands Back to this file by RETURNING FALSE. Several of those
' handlers are shaped as a dispatcher — `if m.focusArea = "chips" then return
' chipsKey(key)` — over per-area functions that end in a bare `return true`.
' A Back branch that merely stops raising backToNav and then FALLS THROUGH is
' reported as handled by that trailing `return true`, the key never bubbles,
' and Back becomes a dead button: no crash, no error, no log line, nothing to
' search for. Three of the eleven split sites had exactly this shape
' (SportsScreen searchKey and chipsKey, LiveTvScreen's filter bar) and one of
' them had already been signed off as a safe straight swap.
'
' THE RULE FOR ANYONE ADDING A SCREEN TO THIS PATTERN: return false
' EXPLICITLY, from inside the Back branch. Never by falling out of it. Check
' what the enclosing function returns at its end before you trust a
' fall-through.
sub showExitDialog()
    ' ONE dialog, and it must not be possible to stack a second. The Dialog
    ' node takes focus while it is up, so a second Back should reach the dialog
    ' and not this file at all - but "should" is doing work in that sentence,
    ' and the cost of being wrong is two dialogs the member has to dismiss, so
    ' the flag is kept and checked in onKeyEvent as well.
    if m.exitDialog <> invalid then return
    d = CreateObject("roSGNode", "Dialog")
    d.title = "Leave " + m.branding.appName + "?"
    ' Said in words, not implied by two bare buttons: the member is told what
    ' pressing the thing will actually do.
    d.message = "You are about to close " + m.branding.appName + " and go back to the Roku home screen."
    ' "Keep watching" is FIRST and therefore focused, so an accidental Back on
    ' the rail is never one OK press from closing the app. Leaving costs one
    ' Down - and the Roku Home button is still an instant exit either way, so
    ' nobody is ever trapped by this choice. WORTH A LOOK ON THE TELEVISION:
    ' if Back-Back-OK reads as "the app ignored me", the order flips.
    d.buttons = ["Keep watching", "Leave " + m.branding.appName]
    d.observeField("buttonSelected", "onExitDialogButton")
    ' Back while the dialog is up closes it. That is the Dialog node's own
    ' behaviour and it is the answer we want (cancel), but it does NOT come
    ' through buttonSelected, so the flag has to be cleared there too or the
    ' member could never raise the dialog a second time.
    d.observeField("wasClosed", "onExitDialogClosed")
    m.exitDialog = d
    ' NO BEACON PAIR, and not by oversight. Certification 3.2's
    ' AppDialogInitiate/AppDialogComplete pair exists to subtract a member's
    ' thinking time from the LAUNCH clock, and that clock was stopped the
    ' moment Home rendered (beaconLaunchComplete in AppScene.brs). This dialog
    ' can only appear long after that. beaconDialogOpen() would refuse it
    ' anyway - its first line is `if m.launchDone = true then return` - but the
    ' honest statement is that this is not a launch dialog and never asks.
    m.top.getScene().dialog = d
end sub

sub onExitDialogButton()
    if m.exitDialog = invalid then return
    picked = m.exitDialog.buttonSelected
    ' Button 0 is "Keep watching". Dismiss and put the member back where they
    ' were, which is the rail on Home. onExitDialogClosed does the focus.
    if picked = 0
        m.exitDialog.close = true
        return
    end if
    ' They confirmed. Close the dialog first so it is not left on screen during
    ' the tear-down, then ask the scene to end the session.
    m.exitDialog.close = true
    KLog("nav", "exit confirmed - closing the app")
    persistDiagTail()
    scene = m.top.getScene()
    ' hasField, not a bare write: if the scene half of this is ever missing the
    ' app must carry on running rather than die on the render thread. The
    ' member is left on Home, which is where they already were.
    if scene.hasField("exitApp") then scene.exitApp = true
end sub

' The dialog went away - by either button, or by Back, or by the scene taking
' it down. Clear the flag BOTH ways so the next Back can raise it again, and
' put focus somewhere real: a Dialog closing does not hand focus back on its
' own, and a shell with focus nowhere swallows every press after it.
sub onExitDialogClosed()
    m.exitDialog = invalid
    if m.currentIndex = 0 or m.currentScreen = invalid
        m.sidebar.setFocus(true)
    else
        m.currentScreen.setFocus(true)
    end if
end sub

sub onScreenSignedOut()
    m.top.signedOut = true
end sub

' Roku has no browser — the closest match to Android's "Get KwickTV" link
' is a dialog with the address, keeping the entry in the same nav slot.
sub showStoreDialog()
    if not ShowStorefront() then return
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Get KwickTV"
    dialog.message = "Premium live TV, movies & series." + Chr(10) + Chr(10) + "Visit us at:" + Chr(10) + m.branding.storeUrl
    dialog.buttons = ["Close"]
    dialog.observeField("buttonSelected", "closeDialog")
    m.top.getScene().dialog = dialog
end sub

sub closeDialog()
    m.top.getScene().dialog.close = true
end sub

' ---- Which screen the app opens on -----------------------------------------
' It is the PROFILE'S choice, not the app's. The phone has had this for as
' long as it has had profiles: startup_screen.dart:71 routes to
' userPreferences.startupScreen at launch, and its profile picker goes to the
' same place after a switch. This is the Roku honouring the same value.
'
' >>> WHERE THE VALUE COMES FROM, AND WHY NOTHING NEW IS STORED FOR IT <<<
'
' The phone writes pref_startup_screen into the per-profile settings blob it
' pushes to KwickSync — it is one row of ProfileSettings.all
' (android/lib/preference/profile_settings.dart:19), which is exactly the
' list SettingsSyncType.snapshot() reads to build the 'pset' payload.
'
' This device has been receiving it, and carrying it around, all along:
'   * every pset row pulled is written to the sync mirror VERBATIM
'     (applyChange in SyncTask.brs stores the whole row as JSON under
'     "pset:<profileSyncId>"), and only THEN are the keys this app knows
'     copied into registry keys (ApplyPsetMap over psetScalarMap);
'   * every pset row this device PUSHES starts from that stored blob so that
'     keys it does not understand survive the round trip untouched
'     (BuildPsetMap's baseS argument, and the phone does the same in
'     reverse).
' psetScalarMap() simply has no row for pref_startup_screen, so it was never
' copied anywhere and nothing ever read it. The blob has it; the registry
' does not.
'
' So this reads the mirror, and NO wire change and NO new stored setting were
' needed — confirmed by both halves above: the value already travels, and the
' Roku's own push already preserves it. Adding a psetScalarMap row would be
' tidier and would give Settings a registry key to write a locally chosen
' value into, but Store.brs belongs to another lane this build, so that is
' reported rather than done. Reading the mirror is not a workaround for it —
' it is the same value, one step earlier.

' The Android route this profile wants to open on, or "" when it has not
' asked for anything (much the common case).
'
' LAUNCH-PATH COST, and it is deliberately shaped: one registry read and one
' substring scan, and the JSON is parsed ONLY for a member who has actually
' chosen a startup screen. The mirror is the largest single value this app
' stores (the whole registry is 16-32 KB and the mirror shares it with
' everything else), and certification 3.2 gives the entire launch 15 seconds
' — nobody who has never touched this setting should pay a JSON parse for it.
'
' No try/catch, on purpose: this runs on the launch path, and every step
' below is type-guarded instead. Feed data has frozen this app once already
' (v1.0.8, s:[] instead of s:{}), so nothing here assumes a shape.
function startupRoute() as string
    raw = RegRead("sync_mirror")
    if raw = "" then return ""
    if Instr(1, raw, "pref_startup_screen") = 0 then return ""

    ' >>> ProfileById, NOT ActiveProfile(). <<<
    ' ActiveProfile() calls EnsureDefaultProfile(), and this runs on the one
    ' path where the profile store is deliberately EMPTY: the locker took
    ' longer than five seconds and AppScene opened Home pointing at NO
    ' profile rather than fabricating one. Read the note at AppScene.brs:364
    ' before changing this line — a blank "Default" created here would be
    ' pushed up and would overwrite the member's real profile name, colour,
    ' avatar and PIN on every device they own. ProfileById hands back
    ' invalid instead, which is the honest answer, and we open on Home.
    p = ProfileById(ActiveProfileId())
    if p = invalid then return ""
    sid = ToStr(p.syncId)
    if sid = "" then return ""

    mirror = ParseJson(raw)
    if mirror = invalid or type(mirror) <> "roAssociativeArray" then return ""
    row = mirror["pset:" + sid]
    if row = invalid or type(row) <> "roAssociativeArray" then return ""
    if GetField(row, "deleted") = true then return ""
    data = ToStr(GetField(row, "data"))
    if data = "" then return ""
    parsed = ParseJson(data)
    if parsed = invalid or type(parsed) <> "roAssociativeArray" then return ""
    s = GetField(parsed, "s")
    if s = invalid or type(s) <> "roAssociativeArray" then return ""
    if not s.doesExist("pref_startup_screen") then return ""
    return ToStr(s["pref_startup_screen"])
end function

' An Android route -> this shell's screen component.
'
' By NAME and never by index. The sidebar's item list and m.screenNames have
' to stay in lockstep already, storefront guard included (Sidebar.brs:15-21
' and the list at the top of this file); a number written down here would be
' a third list to keep in step, and it would be the one nobody remembers.
' Search has no Android counterpart and VOD has two spellings; both are
' handled rather than left to fall through as "unknown".
function startupScreenFor(route as string) as string
    r = LCase(route.trim())
    if r = "" then return ""
    if r = "/home" then return "HomeScreen"
    if r = "/channels" then return "LiveTvScreen"
    if r = "/guide" then return "GuideScreen"
    if r = "/vod-home" or r.left(4) = "/vod" then return "VodScreen"
    if r = "/sports" then return "SportsScreen"
    if r = "/settings" then return "SettingsScreen"
    if r = "/search" then return "SearchScreen"
    return ""
end function

' Which slot to open on — ALWAYS one this build actually has. An unknown
' route, a profile that has not chosen, a route for a screen this edition
' does not carry (or the phone's /recordings, which Roku OS has no local DVR
' for) all land on 0, which is exactly where this app has always opened.
function startupIndex() as integer
    name = startupScreenFor(startupRoute())
    if name = "" then return 0
    for i = 0 to m.screenNames.count() - 1
        if m.screenNames[i] = name
            if i <> 0 then KLog("nav", "this profile opens on " + name)
            return i
        end if
    end for
    return 0
end function

' ---- Trakt / Simkl watchlists: the schedule ----------------------------------
'
' ONE TIMER FOR BOTH ADD-ONS, ticking every minute and doing nothing unless
' something is due. Exactly the shape m.syncTimer above has carried for
' KwickSync since v1.0.29, in the one node that lives for the life of the app —
' a screen's own timer dies when the member walks off that screen, which is
' most of the time.
'
' DUE = now - max(last run, app-open) >= the gap the member chose.
' Measuring from app-open as well as from the last run is deliberate and is the
' difference between a schedule and "sync every time you open the app": a run
' from last night is older than three hours, so without the app-open floor
' every single launch would fire a pull. That is a request pattern, and request
' PATTERN is what got this house's provider access banned in August 2026
' ([[Roku - Anti-Share Bans]]).
'
' The hard floor of one hour lives inside nia's SyncEveryHours(), so whatever
' it hands back is trusted here and never re-clamped. 0 hours means off.
sub startAddOnWatchlists()
    m.addOnAppOpenAt = addOnNowS()
    m.addOnSyncBusy = false
    m.addOnSyncStartedAt = 0
    m.addOnTask = invalid
    ' Declared here rather than on first use: an undeclared m.field reads as
    ' invalid on this box, but relying on that is how the next person gets a
    ' surprise (see m.exitDialog in init).
    m.addOnMemMon = invalid
    ' When each service was last asked for BY HAND. The "Sync now" cooldown —
    ' see onAddOnSyncRequest.
    m.addOnForcedAt = {}

    ' >>> THE ENTRY POINT SETTINGS USES. <<<
    ' Settings cannot call into this component, so "Sync now" writes
    '     m.global.addOnSyncRequest = "<service>|<nonce>"
    ' where <service> is "trakt" or "simkl" and <nonce> is anything that
    ' changes — the seconds clock will do. The nonce is not decoration: a field
    ' created by addFields cannot be alwaysNotify, so writing the same string
    ' twice would not notify and the second press would do nothing at all.
    if m.global <> invalid
        if not m.global.hasField("addOnSyncRequest") then m.global.addFields({ addOnSyncRequest: "" })
        ' >>> observeFieldScoped, NOT observeField. <<<
        ' m.global is never collected, so a plain registration here is a hard
        ' reference from that permanent node back into this shell — and this
        ' shell is thrown away and rebuilt on every profile switch and every
        ' sign-out. Same defect and same fix as the 2026-09-14 memory sweep
        ' (PlayerScreen.brs:4655, PosterCard.brs:184). tearDownShell() removes
        ' it explicitly as well; the scoped form is what covers a future caller
        ' who removes the shell without going through removeShell in
        ' AppScene.brs.
        m.global.observeFieldScoped("addOnSyncRequest", "onAddOnSyncRequest")
    end if

    m.addOnTimer = CreateObject("roSGNode", "Timer")
    m.addOnTimer.duration = 60
    m.addOnTimer.repeat = true
    m.addOnTimer.observeField("fire", "onAddOnSyncTick")
    m.addOnTimer.control = "start"

    ' "Sync at startup" — ONE pull, after the first frame rather than in front
    ' of it. Certification 3.2 gives the whole launch 15 seconds and AppScene
    ' stops that clock when init returns, so nothing here may run inside init;
    ' five seconds also keeps it clear of the KwickSync cycle that starts
    ' immediately above. It still goes through the task's own 15-minute
    ' throttle, so a member who restarts the app four times in ten minutes
    ' costs the relay one pull, not four.
    m.addOnStartTimer = CreateObject("roSGNode", "Timer")
    m.addOnStartTimer.duration = 5
    m.addOnStartTimer.repeat = false
    m.addOnStartTimer.observeField("fire", "onAddOnStartTick")
    m.addOnStartTimer.control = "start"
end sub

sub onAddOnStartTick()
    m.addOnStartPending = true
    tryAddOnStartSync()
end sub

' The startup pull, which may have to wait. Five seconds in, the member can
' still be on the profile picker or a sign-in, and startAddOnSync defers while
' the shell does not hold focus - so this keeps asking on the minute tick until
' it actually goes, rather than losing "sync at startup" for the whole session.
sub tryAddOnStartSync()
    if m.addOnStartPending <> true then return
    due = []
    for each svcId in ["trakt", "simkl"]
        if SyncOnStart(svcId) and addOnSyncEligible(svcId) then due.push(svcId)
    end for
    if due.count() = 0
        ' Nobody asked for it. Not pending any more either.
        m.addOnStartPending = false
        return
    end if
    if startAddOnSync(due, false) then m.addOnStartPending = false
end sub

sub onAddOnSyncTick()
    if m.addOnStartPending = true
        tryAddOnStartSync()
        return
    end if
    due = []
    for each svcId in ["trakt", "simkl"]
        if addOnSyncDue(svcId) then due.push(svcId)
    end for
    if due.count() = 0 then return
    startAddOnSync(due, false)
end sub

' Signed in, with the Home row switched on. Turning the row off stops the PULL
' as well as the drawing — Android does the same, and a member who turns a row
' off has asked us to stop talking to the service, not to fetch quietly and
' hide the answer.
function addOnSyncEligible(svcId as string) as boolean
    if not WatchlistRowOn(svcId) then return false
    return AddOnSignedIn(svcId)
end function

function addOnSyncDue(svcId as string) as boolean
    if not addOnSyncEligible(svcId) then return false
    hours = SyncEveryHours(svcId)
    if hours <= 0 then return false          ' the member turned the schedule off
    ' max(last run, app-open). See the block above.
    since = LastSyncAt(svcId)
    if since < m.addOnAppOpenAt then since = m.addOnAppOpenAt
    return (addOnNowS() - since) >= (hours * 3600)
end function

' "Sync now", from the add-on's page in Settings.
sub onAddOnSyncRequest()
    if m.global = invalid then return
    raw = ToStr(m.global.addOnSyncRequest)
    if raw = "" then return
    svcId = LCase(raw.split("|")[0]).trim()
    if svcId <> "trakt" and svcId <> "simkl" then return
    if not addOnSyncEligible(svcId) then return
    ' >>> THE 30-SECOND COOLDOWN, HERE RATHER THAN ON THE BUTTON. <<<
    ' A held OK on a Roku remote repeats about every 400 ms, so a button with
    ' no cooldown is a burst of relay calls. It lives at this single entry
    ' point because this is the one place every path into a run passes through;
    ' a second press inside the window simply does nothing, which leaves the
    ' last summary on screen exactly as it was.
    last = ToInt(GetField(m.addOnForcedAt, svcId))
    if last > 0 and (addOnNowS() - last) < 30 then return
    m.addOnForcedAt[svcId] = addOnNowS()
    startAddOnSync([svcId], true)
end sub

' ONE RUN AT A TIME, whoever asked for it. False means "not now" - the caller
' decides whether that is worth trying again.
function startAddOnSync(services as object, forced as boolean) as boolean
    if services.count() = 0 then return false

    ' A run that never answered would otherwise wedge this for the life of the
    ' app. Ten minutes is longer than the longest run this can make (five relay
    ' calls plus four catalogues, each with its own deadline).
    if m.addOnSyncBusy = true
        if m.addOnSyncStartedAt > 0 and (addOnNowS() - m.addOnSyncStartedAt) > 600
            KLog("sync-addon", "previous run never answered - letting the next one start")
            m.addOnSyncBusy = false
        else
            return false
        end if
    end if

    ' NOT WHILE THE MEMBER IS SOMEWHERE ELSE. When a player or a detail page is
    ' up it holds focus and this shell does not, and a whole-catalogue download
    ' competing with a video stream is the one time this job could be felt.
    ' Deferred, not skipped — the next minute tick tries again. A forced "Sync
    ' now" always runs: the member is standing in Settings, which is under this
    ' shell, and they asked.
    if not forced and not m.top.isInFocusChain() then return false

    cap = addOnCatalogueCapBytes()
    if cap <= 0
        ' The box is already tight. Everything this run would do is optional,
        ' and a catalogue is the single biggest thing this app ever pulls into
        ' memory — two members' boxes were killed outright by one on v1.0.36.
        KLog("sync-addon", "skipping this run - the app is already short of memory")
        return false
    end if

    if m.addOnTask = invalid
        m.addOnTask = CreateObject("roSGNode", "AddOnSyncTask")
        m.addOnTask.observeField("result", "onAddOnSyncResult")
    end if
    m.addOnTask.servicesJson = FormatJson(services)
    m.addOnTask.forced = forced
    m.addOnTask.maxBytes = cap
    m.addOnSyncBusy = true
    m.addOnSyncStartedAt = addOnNowS()
    m.addOnTask.control = "RUN"
    return true
end function

sub onAddOnSyncResult(event as object)
    m.addOnSyncBusy = false
    res = event.getData()
    if res = invalid then return

    redraw = false
    for each rec in ToArray(GetField(res, "runs"))
        svcId = ToStr(GetField(rec, "service"))
        if svcId = "" then continue for

        ' Nothing happened, so nothing is recorded: a throttled run must not
        ' move the "Last synced" line, and a run dropped because the member
        ' signed out mid-pull must leave no trace at all.
        if GetField(rec, "throttled") = true then continue for
        if GetField(rec, "dropped") = true
            KLog("sync-" + svcId, "signed out while this was running - nothing recorded")
            continue for
        end if

        summary = ToStr(GetField(rec, "summary"))
        ' Failures record themselves too, so the Settings row can say what went
        ' wrong instead of showing yesterday's happy answer forever.
        SetLastSync(svcId, ToInt(GetField(rec, "at")), summary)

        ' ONE LINE PER RUN. Never the member's titles and never the token.
        hours = SyncEveryHours(svcId)
        every = "sync now"
        if m.addOnTask <> invalid and m.addOnTask.forced <> true
            if hours > 0 then every = "every " + hours.toStr() + "h"
        end if
        KLog("sync-" + svcId, every + " - " + summary)

        if GetField(rec, "changed") = true then redraw = true
    end for

    ' Only redraw when there is something new to draw. A failed pull wrote
    ' nothing, so the tiles already on screen are still the last good answer
    ' and must be left exactly where they are rather than blanked and refilled.
    if redraw and m.currentScreen <> invalid and m.currentScreen.hasField("reloadFromSync")
        m.currentScreen.reloadFromSync = true
    end if
end sub

' The most ONE catalogue answer may be, in bytes, or 0 for "not now". Worked
' out HERE because this is the render thread, where roAppMemoryMonitor tells
' the truth about the whole app; inside the task it would report only the
' task's own few percent, which is the trap that made the v1.0.29 Sports cap
' dead code ([[Roku - The Playlist Memory Budget]]).
'
' The arithmetic is SearchScreen.catalogueCapBytes() — 350,000 bytes per free
' percentage point, measured on the office stick rather than guessed (31 MB of
' catalogues moves the app 24 points, so a raw megabyte costs about 0.8 of a
' point). The one difference is the refusal at the top: Search is something the
' member asked for and is sitting in front of, so it degrades to partial
' results; this is housekeeping nobody is watching and simply waits for the
' next tick.
function addOnCatalogueCapBytes() as integer
    if m.addOnMemMon = invalid then m.addOnMemMon = CreateObject("roAppMemoryMonitor")
    if m.addOnMemMon = invalid then return 4000000
    used = m.addOnMemMon.GetMemoryLimitPercent()
    if used = invalid then return 4000000
    usedPct = ToInt(used)
    if usedPct >= 70 then return 0
    freePct = 100 - usedPct
    if freePct > 100 then freePct = 100
    return freePct * 350000
end function

function addOnNowS() as integer
    return CreateObject("roDateTime").asSeconds()
end function

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    ' Right from the sidebar enters the current screen.
    if key = "right" and m.sidebar.hasFocus()
        if m.currentScreen <> invalid
            m.currentScreen.setFocus(true)
            return true
        end if
    end if

    ' ---- Back (certification 4.6) - see the block above showExitDialog ------
    ' This is the LAST stop for Back inside the shell. AppScene has no
    ' onKeyEvent, so anything this returns false for reaches the firmware and
    ' closes the app - which is exactly the defect being fixed. Every branch
    ' below therefore returns true, and Back can no longer leave by accident
    ' from anywhere under this shell.
    if key = "back"
        ' The dialog is already up. Swallow, so a second press can never stack
        ' a second dialog. 4.6 permits ONE.
        if m.exitDialog <> invalid then return true
        ' Not on Home: walk one screen further out. Focus lands on the rail,
        ' which is where Home has always opened (see init) and where the next
        ' Back is expected from.
        if m.currentIndex <> 0
            showScreen(0)
            m.sidebar.setFocus(true)
            return true
        end if
        ' On Home. The one permitted confirmation, then out.
        showExitDialog()
        return true
    end if
    return false
end function
