' Kwick Player (Roku) — entry point.
' Boots the AppScene, which decides between onboarding and the main shell.

sub Main(args as dynamic)
    ' Crash detection: the OS reports how the previous session ended
    ' (Roku OS 13+). A crash reason arms a flag BEFORE the scene exists;
    ' AppScene's init consumes it and uploads the persisted log tail as a
    ' crash report. (A "session alive" sentinel was tried first, but Home
    ' presses kill the channel without any close event, so every normal
    ' exit looked like a crash.)
    reason = ""
    if args <> invalid and args.lastExitOrTerminationReason <> invalid
        reason = ToStr(args.lastExitOrTerminationReason)
    end if
    ' THE OS CODE ALWAYS LANDS, ON ITS OWN KEY. Unconditional, every launch.
    ' That is what lets the line below lose an argument without losing a fact.
    if reason <> "" then RegWrite("last_exit_reason", reason)
    ' Crash-like endings: a BrightScript crash, or the OS killing the
    ' channel for memory. (Home/Back report EXIT_USER_NAV — not a crash.)
    '
    ' THIS DOES NOT ALWAYS WIN, AND THAT IS DELIBERATE. If the previous
    ' session already caught a fault and wrote down the file and line that
    ' went wrong, ArmCrashReport keeps that and ignores this bare exit code -
    ' see the note on ArmCrashReport in Util.brs for why, and for what it
    ' cost when this call clobbered it. Nothing is lost: the exit code is
    ' already saved on the line above and AppScene reads that key as well.
    if Instr(1, UCase(reason), "CRASH") > 0 or Instr(1, UCase(reason), "MEM") > 0
        ArmCrashReport(reason)
    end if

    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.setMessagePort(port)

    scene = screen.CreateScene("AppScene")
    screen.show()
    scene.launchArgs = args

    ' Certification 4.6 lets the app show ONE confirmation before it exits, and
    ' AppShell does (showExitDialog). But a Roku app cannot close itself from
    ' the render thread — the only thing that can end the session is this loop
    ' letting Main return. So the scene raises exitApp and this is the wire
    ' across that boundary. Nothing else in this file changes.
    scene.observeField("exitApp", port)

    ' Deep link at LAUNCH (Roku certification 5.1): Roku passes contentId and
    ' mediaType as launch arguments. Hand them to the scene, which waits for
    ' sign-in / profile selection before acting on them.
    handOverDeepLink(scene, args)

    ' Deep link WHILE RUNNING — "Direct to Play" (certification 5.2). Roku
    ' delivers the ECP /input command as an roInput event, and the video must
    ' start without the app restarting, so it's picked up in this same loop.
    input = CreateObject("roInput")
    input.setMessagePort(port)

    ' Roku's own memory alarms, delivered to this same loop. Static analysis
    ' (2026-09-03, findings 7-10) asked for these, and it was right to: fifteen
    ' members on small Rokus were killed for memory in one week and not one
    ' report carried a reading, because nothing in the app was listening. The
    ' render thread cannot own an roAppMemoryMonitor port - only Main can - so
    ' the event lands here and is handed to the scene through the global node,
    ' where AppScene.onMemWarning writes it into the crash tail.
    ' TWO objects, because Roku split the alarms across two interfaces and the
    ' names are close enough to get wrong (the first cut called
    ' EnableLowGeneralMemoryEvent on the monitor and died at launch with
    ' "Member function not found"): the app-level warning is on
    ' roAppMemoryMonitor, the device-level "general memory low" is on
    ' roDeviceInfo.
    memMon = CreateObject("roAppMemoryMonitor")
    memMon.setMessagePort(port)
    memMon.enableMemoryWarningEvent(true)
    devInfo = CreateObject("roDeviceInfo")
    devInfo.setMessagePort(port)
    devInfo.enableLowGeneralMemoryEvent(true)
    glob = screen.getGlobalNode()

    while true
        msg = wait(0, port)
        msgType = type(msg)
        if msgType = "roSGScreenEvent"
            if msg.isScreenClosed() then return
        else if msgType = "roSGNodeEvent"
            ' The member confirmed the exit dialog. Returning ends Main, which
            ' closes the channel and puts them back on the Roku home screen.
            ' Guarded on BOTH the field name and the value so any other node
            ' event that ever reaches this port falls through harmlessly rather
            ' than quitting the app.
            if msg.getField() = "exitApp" and msg.getData() = true then return
        else if msgType = "roInputEvent"
            if msg.isInput() then handOverDeepLink(scene, msg.getInfo())
        else if msgType = "roAppMemoryNotificationEvent" or msgType = "roDeviceInfoEvent"
            ' Read the numbers while the alarm is fresh - by the time the scene
            ' hears about it the picture may already have moved on. roDeviceInfo
            ' raises other events too (caption mode, links, etc.); only the
            ' low-memory one is wanted here.
            ' ONLY getInfo() is called on the event. Both event types document
            ' it; nothing else is assumed. Two earlier cuts died at launch with
            ' "Member function not found" - once for a method that lives on a
            ' different interface, once for one that does not exist - and
            ' BrightScript evaluates both sides of an `and`, so a guard on the
            ' same line does not protect the call (see the vault note on
            ' BrightScript short-circuits). roDeviceInfo raises status events
            ' for other things too (captions, links); the low-memory one is the
            ' one whose info carries generalMemoryLevel.
            info = msg.getInfo()
            wanted = (msgType = "roAppMemoryNotificationEvent")
            if not wanted
                if ToStr(GetField(info, "generalMemoryLevel")) <> "" then wanted = true
            end if
            if wanted
                ' TWO SCOPES ON ONE LINE, SAID PLAINLY. `generalMemoryLevel`
                ' inside the event is the WHOLE BOX; the number beside it is
                ' only what is left for THIS APP. Written as "availableKB" next
                ' to a device-wide word, they read as a contradiction — on the
                ' 2026-09-18 logs the figure beside "critical" was TWICE the
                ' one beside "low" (119,556 against 56,340 on B888C3;
                ' 215,856 against 46,956 on C95C89), which cost an hour before
                ' anyone noticed the two halves are not measuring the same
                ' thing. Roku had just reclaimed memory from somewhere else,
                ' so the app's own headroom genuinely went UP as the box got
                ' worse. The name now says whose memory it is.
                '
                ' limitKB IS GONE, and the reason recorded here was WRONG.
                '
                ' CORRECTED 2026-10-13. This used to say getChannelMemoryLimit()
                ' "has never once returned a value on any member's box" — 200
                ' alarm lines across 146 logs, every one ending "limitKB=" with
                ' nothing after it. The call was never broken. It returns an
                ' roAssociativeArray of three Integers (maxForegroundMemory,
                ' maxBackgroundMemory, maxRokuManagedHeapMemory), and the old
                ' code pushed that map through ToStr(), which answers "" for
                ' anything that is not a scalar. We were printing our own
                ' mistake and reading it as the box staying silent.
                ' Measured on the office stick the same day: foreground
                ' 501760 KB, background 401408 KB, heap 363520 KB.
                ' AppScene.logMemoryCeiling() now writes it properly once per
                ' launch. Dropping the field from THIS line is still right —
                ' the crash tail keeps only the last few hundred bytes — but
                ' do not carry the old reason anywhere else.
                avail = memMon.getChannelAvailableMemory()
                line = msgType + " " + FormatJson(info) + " appHeadroomKB=" + ToStr(avail)
                if glob <> invalid and glob.hasField("memWarning") then glob.memWarning = line
                ' THE APP'S OWN ALARM IS THE ONE HONEST SIGNAL A TASK CAN ACT ON.
                ' roAppMemoryNotificationEvent fires at 80/85/90/95% of THIS
                ' app's limit, delivered here on the main thread - where the
                ' per-thread monitor a Task would read is useless (it reports
                ' the task's own few percent while the app is at 78%). A
                ' Hisense 6Series-50 on v1.0.37 (key EFD837, 2026-09-16) went
                ' from 2% at launch to 78% in fourteen seconds with nothing
                ' logged, then 93%, then was killed: the playlist parse at
                ' launch, building tens of thousands of rows on a thread that
                ' cannot see the app's total. So the alarm raises one flag on
                ' the global node, and every parser checks it as it goes.
                ' Cleared by PublishM3uParse once the render thread's honest
                ' reading is back under 70%.
                '
                ' AND THE BOX'S OWN ALARM RAISES IT TOO, which is the fix that
                ' came out of log duty on 2026-09-18. The flag above was only
                ' ever set by roAppMemoryNotificationEvent, and on the small
                ' streaming players THAT EVENT NEVER ARRIVES. Seven crash logs
                ' that day — a Streaming Stick 3800X (B888C3), a Roku Express
                ' 3960X (3E82F0) and four from one Roku Premiere+ 4630X
                ' (C95C89) — carried TWELVE roDeviceInfoEvent alarms between
                ' them and NOT ONE roAppMemoryNotificationEvent. Every one of
                ' those sessions was then killed with EXIT_CHANNEL_MEM_LIMIT_FG.
                ' So on exactly the boxes that die, every guard v1.0.38 built
                ' on this flag — the playlist parser, the Movies & Series
                ' catalogue build, Search — was dead code. The Roku TVs in the
                ' archive (Hisense, onn, Philco) do raise the app event, which
                ' is why the .38 work looked like it was working.
                '
                ' A box that says "low" or "critical" is in trouble whatever
                ' share this app holds, and there is nothing a parser should do
                ' about that except stop. Same flag, same clearing rule, so
                ' nothing downstream changes.
                if glob <> invalid and glob.hasField("memPressure")
                    if msgType = "roAppMemoryNotificationEvent"
                        if ToInt(GetField(info, "MemoryUsagePercent")) >= 80 then glob.memPressure = true
                    else
                        lvl = LCase(ToStr(GetField(info, "generalMemoryLevel")))
                        if lvl = "low" or lvl = "critical" then glob.memPressure = true
                    end if
                end if
            end if
        end if
    end while
end sub

' Pull contentId/mediaType out of a launch-args or ECP-input payload and pass
' them to the scene. Roku's keys are lowercase in launch args and can vary in
' case over ECP, so both spellings are accepted.
sub handOverDeepLink(scene as object, info as dynamic)
    if info = invalid then return
    contentId = ""
    mediaType = ""
    if info.contentId <> invalid then contentId = ToStr(info.contentId)
    if info.contentid <> invalid and contentId = "" then contentId = ToStr(info.contentid)
    if info.mediaType <> invalid then mediaType = ToStr(info.mediaType)
    if info.mediatype <> invalid and mediaType = "" then mediaType = ToStr(info.mediatype)
    if contentId = "" then return
    scene.deepLink = { contentId: contentId, mediaType: mediaType }
end sub
