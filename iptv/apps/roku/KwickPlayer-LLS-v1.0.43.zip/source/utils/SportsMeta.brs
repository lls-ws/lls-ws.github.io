' Sports hub logic — a port of the Android sports_events.dart /
' sports_dedupe.dart / sports_country.dart trio (shipped there in v1.0.90).
' Read those files' comments before changing rules here: every odd-looking
' guard below is a real bug someone already hit, and the Android file names
' the member log it came from.
'
' There is NO sports feed. Events come from channel NAMES (this provider
' bakes the fixture into the name) and the EPG. Because every event arrives
' attached to a channel, matching events to channels is free — the actual
' work is collapsing the same fixture, listed on a dozen channels, into ONE
' event carrying a selectable channel list.
'
' All regexes are compiled once into a context AA (SportsCtx()) because a
' Roku box compiles them slowly and the parser runs over thousands of names.

' ---- Compiled context -------------------------------------------------------

function SportsCtx() as object
    ctx = {}

    ' Keyword -> sport, checked in order, first hit wins: the specific
    ' competitions sit above the generic words they contain ("NFL" before
    ' "FOOTBALL", because plain "football" means soccer nearly everywhere).
    '
    ' AFL sits under Soccer on the owner's instruction (stated twice: "ALL
    ' AFL IS SOCCER"), and AUSTRALIAN RULES must sit beside it: the same
    ' match is listed both ways, and if the two land in different sports
    ' they stop merging and the game appears twice. Do not "fix" either
    ' without asking.
    rules = [
        { sport: "Fights", words: ["UFC", "BOXING", "BOXE", "FIGHT NIGHT", "MMA", "BELLATOR", "PFL", "KICKBOX", "MUAY THAI", "ONE CHAMPIONSHIP"] },
        { sport: "Wrestling", words: ["WWE", "AEW", "WRESTL", "NXT", "SMACKDOWN", "RAW IS"] },
        { sport: "Football", words: ["NFL", "NCAAF", "COLLEGE FOOTBALL", "SUPER BOWL", "CFL", "AMERICAN FOOTBALL", "GRIDIRON"] },
        { sport: "Basketball", words: ["NBA", "NCAAB", "WNBA", "EUROLEAGUE", "BASKETBALL", "BBL"] },
        { sport: "Baseball", words: ["MLB", "BASEBALL", "WORLD SERIES", "NPB", "KBO"] },
        { sport: "Hockey", words: ["NHL", "HOCKEY", "KHL", "STANLEY CUP"] },
        { sport: "Motorsport", words: ["FORMULA 1", "FORMULA1", "F1", "MOTOGP", "NASCAR", "INDYCAR", "MOTORSPORT", "RALLY", "SUPERBIKE", "DTM"] },
        { sport: "Golf", words: ["GOLF", "PGA", "LPGA", "RYDER CUP", "MASTERS TOURNAMENT", "OPEN CHAMPIONSHIP"] },
        { sport: "Tennis", words: ["TENNIS", "ATP", "WTA", "WIMBLEDON", "ROLAND GARROS", "US OPEN TENNIS", "AUSTRALIAN OPEN"] },
        { sport: "Cricket", words: ["CRICKET", "IPL", "TEST MATCH", "ODI", "T20", "BBL CRICKET"] },
        { sport: "Rugby", words: ["RUGBY", "NRL", "SIX NATIONS", "SUPER RUGBY"] },
        { sport: "Racing", words: ["HORSE RACING", "GREYHOUND", "RACING POST"] },
        { sport: "Soccer", words: ["SOCCER", "AFL", "AUSTRALIAN RULES", "FOOTBALL", "FUSSBALL", "FUTBOL", "FUTEBOL", "CALCIO", "VOETBAL", "PREMIER LEAGUE", "CHAMPIONS LEAGUE", "EUROPA LEAGUE", "LA LIGA", "SERIE A", "BUNDESLIGA", "LIGUE 1", "MLS", "EFL", "FA CUP", "COPA", "CONCACAF", "UEFA", "FIFA", "WORLD CUP", "EREDIVISIE", "PRIMEIRA", "SCOTTISH", "CARABAO"] }
    ]
    ctx.sportRules = rules

    ' WORD BOUNDARIES ARE LOAD-BEARING: plain substring matching filed
    ' "Washington Commanders" under Fights because "coMMAnders" contains
    ' "MMA". Every keyword is wrapped in \b...\b.
    matchers = []
    allWords = []
    for each r in rules
        for each w in r.words
            matchers.push({ sport: r.sport, rx: CreateObject("roRegex", "\b" + w + "\b", "i") })
            allWords.push(w)
        end for
    end for
    ctx.sportMatchers = matchers
    ctx.allLeagueWords = allWords

    ' Sports where a single named event IS a real event (a golf round, a
    ' race, a fight card). Team sports need two sides or it's programming.
    ctx.individualSports = { Golf: true, Motorsport: true, Racing: true, Fights: true, Wrestling: true, Tennis: true }

    ' Chip order (preference, not a fixed list — only sports actually
    ' present become chips).
    ctx.chipOrder = ["Soccer", "Football", "Basketball", "Baseball", "Hockey", "Fights", "Motorsport", "Golf", "Tennis", "Cricket", "Rugby", "Racing", "Wrestling", "Other"]

    ' "A vs B" / "A v B" / "A @ B" — separator surrounded by spaces so a
    ' team called "Vasco" can never split.
    ctx.rxVersus = CreateObject("roRegex", "^(.{2,60}?)\s+(?:vs?\.?|versus|@)\s+(.{2,60}?)$", "i")
    ' "Milan - Cagliari" — strict: neither side may contain another dash,
    ' which stops "The Boys - S04E04 - Wisdom of the Ages" splitting.
    ' (En dashes are normalised to "-" in sportsClean first.)
    ctx.rxDashVersus = CreateObject("roRegex", "^([^-]{2,60}?)\s+-\s+([^-]{2,60}?)$", "")
    ' Fixture with the competition tacked on after a dash.
    ctx.rxFixtureDashLeague = CreateObject("roRegex", "^(.+?\s+(?:vs?\.?|versus|@)\s+.+?)\s+-\s+(.{3,60})$", "i")
    ' Season/episode wreckage that must never be a team.
    ctx.rxEpisodeish = CreateObject("roRegex", "^(s\d{1,2}\s*e\d{1,2}|ep?\s*\d+|season\s*\d+|\d{4}[/-]?\d*)$", "i")

    ' Decoration strippers. ORDER MATTERS: anything that legitimately ends
    ' in digits (clock, numeric date) must be removed BEFORE the trailing
    ' stream-number rule, or the tail gets half-eaten ("Chelsea 19").
    ctx.rxDecorations = [
        CreateObject("roRegex", "^\s*[|\[(]?\s*[A-Z]{2,3}\s*[|\])]\s*", ""),
        CreateObject("roRegex", "\b(?:FHD|UHD|HD|SD|4K|1080P?|720P?)\b", "i"),
        CreateObject("roRegex", "\bPPV\s*\d*\s*:?\s*", "i"),
        CreateObject("roRegex", "\s*\d{1,2}[:.]\d{2}\s*(?:am|pm)?\s*[a-z]{0,3}\s*$", "i"),
        CreateObject("roRegex", "\s*\d{1,2}[./-]\d{1,2}(?:[./-]\d{2,4})?(?:\s+\d{1,4})?\s*$", ""),
        CreateObject("roRegex", "\s*\d{1,2}\s*$", ""),
        CreateObject("roRegex", "^\s*\d{1,3}\s+", "")
    ]
    ctx.rxManySpaces = CreateObject("roRegex", "\s{2,}", "")

    ' Month words, for spotting a date tail rather than guessing at one.
    ctx.rxMonthTail = CreateObject("roRegex", "^(.{3,}?)[\s,@-]+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s*\d.*$", "i")
    ctx.rxMonthWord = CreateObject("roRegex", "\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\b", "i")
    ' Broadcast notes in brackets — "(Live)", "(deutscher Kommentar)" — cut;
    ' short ALL-CAPS tags kept ("Chelsea (W)", "PFC Nasaf (UZB)"). No "i"
    ' flag: the keep-rule is specifically for uppercase tags.
    ctx.rxBracketNote = CreateObject("roRegex", "\s*\((?![A-Z]{1,3}\))[^)]{2,40}\)\s*$", "")
    ctx.rxNumericDateTail = CreateObject("roRegex", "[\s,@-]*\b\d{1,2}[./]\d{1,2}(?:[./]\d{2,4})?(?:\s+\d{1,4})?\s*$", "")
    ctx.rxTrailingClock = CreateObject("roRegex", "\s*[,@-]?\s*\d{1,2}[:.]\d{2}\s*(?:am|pm)?\s*[a-z]{0,3}\s*$", "i")
    ctx.rxCommaDigits = CreateObject("roRegex", "[,@]\s*\d{1,4}$", "")
    ctx.rxQualifierStart = CreateObject("roRegex", "^(round|game|match|day|week|part)\b", "i")
    ' A stream number left on the front of the HOME side. The whole-string
    ' rule in rxDecorations only fires when the number leads the WHOLE name;
    ' providers also write it after a prefix ("EVENTS: 00 Burton Albion v
    ' Derby County"), where it survives into the team. 1-3 digits only, so
    ' "1860 Munich" is untouched.
    ctx.rxLeadingStreamNo = CreateObject("roRegex", "^\d{1,3}\s+", "")
    ctx.rxDanglingV = CreateObject("roRegex", "\s+vs?\.?$", "i")
    ctx.rxThreeLetters = CreateObject("roRegex", "[A-Za-z]{3}", "")
    ctx.rxWordChars = CreateObject("roRegex", "[A-Za-z]{3,}", "")
    ' Matchday/highlights words in the languages providers actually use —
    ' matched ANYWHERE in a side ("Liga Inglesa Destaques v 37 Jornada").
    ctx.rxMatchday = CreateObject("roRegex", "\b(jornada|giornata|spieltag|journ[eé]e|matchday|fecha|rodada|destaques|highlights|resumen|resumo)\b", "i")

    ' Words a provider uses where a team name should be.
    ctx.notATeam = { upcoming: true, live: true, tbd: true, tba: true, "coming up": true, replay: true, encore: true, "pre game": true, pregame: true, "post game": true, postgame: true, highlights: true, preview: true, countdown: true, "the game": true, game: true, match: true, event: true, coverage: true, the: true, a: true, an: true, "and": true, vs: true, top: true, best: true }
    ' "next" is a BrightScript keyword, so it can't sit in the literal above.
    ctx.notATeam["next"] = true

    ' Words that continue a competition name after its acronym ("NBA
    ' Summer League Lakers" -> league "NBA Summer League", team "Lakers").
    ctx.leagueTail = { summer: true, winter: true, league: true, season: true, cup: true, championship: true, champions: true, series: true, tour: true, open: true, classic: true, trophy: true, division: true, conference: true, playoffs: true, finals: true, qualifiers: true, friendly: true, friendlies: true, preseason: true, pre: true, regular: true, today: true, tonight: true, live: true, gameday: true, week: true, round: true, game: true, match: true, day: true, night: true, vault: true, flashback: true, replay: true }

    ' Dedupe/merge helpers.
    ctx.rxClubWords = CreateObject("roRegex", "\b(FC|CF|AFC|SC|BC|CLUB|FOOTBALL|UNITED|CITY|THE)\b", "")
    ctx.rxNonAlnum = CreateObject("roRegex", "[^A-Z0-9]", "")
    ctx.qualityOrder = ["4K", "UHD", "FHD", "1080", "HD", "720", "SD"]
    ctx.rxQuality = []
    for each q in ctx.qualityOrder
        ctx.rxQuality.push(CreateObject("roRegex", "\b" + q + "\b", ""))
    end for
    ctx.rxRegionTag = CreateObject("roRegex", "[|\[(]\s*([A-Z]{2,3})\s*[|\])]", "")

    ' Country: provider tags that are not ISO codes or the wrong length.
    ctx.tagAliases = { USA: "US", UK: "GB", ENG: "GB", SCO: "GB", WAL: "GB", GER: "DE", DEU: "DE", SPA: "ES", ESP: "ES", ITA: "IT", FRA: "FR", NED: "NL", NLD: "NL", POR: "PT", PRT: "PT", BRA: "BR", ARG: "AR", MEX: "MX", CAN: "CA", AUS: "AU", NZL: "NZ", RSA: "ZA", ZAF: "ZA", IND: "IN", PAK: "PK", TUR: "TR", POL: "PL", ROM: "RO", GRE: "GR", SWE: "SE", NOR: "NO", DEN: "DK", DNK: "DK", FIN: "FI", RUS: "RU", UKR: "UA", UAE: "AE", KSA: "SA", EGY: "EG", MAR: "MA", NGA: "NG", JPN: "JP", KOR: "KR", CHN: "CN", PHI: "PH", THA: "TH", VIE: "VN", IDN: "ID", MYS: "MY", BEL: "BE", SUI: "CH", CHE: "CH", AUT: "AT", CZE: "CZ", CRO: "HR", SRB: "RS", COL: "CO", CHI: "CL", PER: "PE", URU: "UY", QAT: "QA", ISR: "IL", IRE: "IE", IRL: "IE", SEN: "SN", MOR: "MA", ALG: "DZ", KEN: "KE", GHA: "GH", CMR: "CM", UZB: "UZ" }

    ' Nationality words — checked FIRST and longest-match, because a
    ' combined longest-match got "South African Premier League" wrong: a
    ' nationality always beats a league name.
    ctx.countryAdjectives = { "south african": "ZA", "american": "US", "canadian": "CA", "english": "GB", "scottish": "GB", "welsh": "GB", "british": "GB", "irish": "IE", "german": "DE", "spanish": "ES", "italian": "IT", "french": "FR", "portuguese": "PT", "dutch": "NL", "belgian": "BE", "swiss": "CH", "austrian": "AT", "danish": "DK", "swedish": "SE", "norwegian": "NO", "finnish": "FI", "polish": "PL", "czech": "CZ", "croatian": "HR", "serbian": "RS", "romanian": "RO", "greek": "GR", "turkish": "TR", "russian": "RU", "ukrainian": "UA", "brazilian": "BR", "argentine": "AR", "argentinian": "AR", "mexican": "MX", "colombian": "CO", "chilean": "CL", "peruvian": "PE", "uruguayan": "UY", "paraguayan": "PY", "ecuadorian": "EC", "australian": "AU", "japanese": "JP", "korean": "KR", "chinese": "CN", "indian": "IN", "saudi": "SA", "qatari": "QA", "emirati": "AE", "egyptian": "EG", "moroccan": "MA", "nigerian": "NG", "kenyan": "KE", "ghanaian": "GH", "israeli": "IL" }

    ' Competitions whose home country is unambiguous.
    ctx.leagueHomes = { "premier league": "GB", "efl": "GB", "fa cup": "GB", "carabao": "GB", "championship": "GB", "bundesliga": "DE", "la liga": "ES", "laliga": "ES", "serie a": "IT", "serie b": "IT", "coppa italia": "IT", "ligue 1": "FR", "ligue1": "FR", "primeira": "PT", "eredivisie": "NL", "brasileir": "BR", "liga mx": "MX", "super lig": "TR", "j-league": "JP", "a-league": "AU", "afl": "AU", "nrl": "AU", "ipl": "IN", "cfl": "CA", "nfl": "US", "nba": "US", "wnba": "US", "mlb": "US", "nhl": "US", "mls": "US", "ncaa": "US", "pga": "US", "nascar": "US" }

    return ctx
end function

' ---- Sport classification ---------------------------------------------------

' The sport a piece of text describes, or "" when nothing matches. "" is a
' real answer — it keeps ordinary channels out of the Sports tab.
function SportOf(ctx as object, text as string) as string
    if text = "" then return ""
    for each mt in ctx.sportMatchers
        if mt.rx.isMatch(text) then return mt.sport
    end for
    return ""
end function

' ---- Cleanup ----------------------------------------------------------------

' Strips the noise a provider wraps around a fixture. Also normalises en
' dashes to "-" so one dash regex covers both.
function sportsClean(ctx as object, raw as string) as string
    s = raw.replace(Chr(8211), "-")   ' en dash
    s = s.replace(Chr(8212), "-")     ' em dash
    for each rx in ctx.rxDecorations
        s = rx.replaceAll(s, " ")
    end for
    s = ctx.rxManySpaces.replaceAll(s, " ")
    return s.trim()
end function

' Tidies a competition string: strips stray punctuation and provider
' wreckage off both ends, character by character — a regex is where bugs
' hide here. Also drops a trailing stream number and any non-ASCII marker
' glyph ("Scottish Premiership 03" with a box character after it).
function tidyLeague(raw as string) as string
    junk = " '" + Chr(8216) + Chr(8217) + Chr(34) + "-:|,."
    s = raw.trim()
    ' Trailing junk, unprintables and stray high characters.
    while s.len() > 0
        ch = s.right(1)
        c = Asc(ch)
        if Instr(1, junk, ch) > 0 or c < 32 or c > 126
            s = s.left(s.len() - 1)
        else
            exit while
        end if
    end while
    ' A trailing stream/episode number left on the competition.
    s = CreateObject("roRegex", "\s+\d{1,3}$", "").replaceAll(s.trim(), "")
    ' Leading junk.
    s = s.trim()
    while s.len() > 0 and Instr(1, junk, s.left(1)) > 0
        s = Mid(s, 2)
    end while
    return s.trim()
end function

' Strips leading punctuation a provider leaves in front of a team name
' ("- PSG v Arsenal"). Kept separate from tidyLeague so a club whose name
' genuinely starts with a bracket is unaffected.
function stripLeadingPunct(raw as string) as string
    s = raw.trim()
    while s.len() > 0
        ch = s.left(1)
        if Instr(1, "-:|,." + Chr(8211) + Chr(8212), ch) > 0
            s = Mid(s, 2).trim()
        else
            exit while
        end if
    end while
    if s.len() < 3 then return raw.trim()
    return s
end function

' Index of a league keyword inside UPPER, respecting word boundaries, or 0.
' Instr-based because roRegex reports matches but not positions.
function wordIndexOf(upper as string, word as string) as integer
    at = 1
    while true
        i = Instr(at, upper, word)
        if i <= 0 then return 0
        okBefore = (i = 1)
        if not okBefore
            prev = Mid(upper, i - 1, 1)
            okBefore = not isAlnumChar(prev)
        end if
        after = i + word.len()
        okAfter = (after > upper.len())
        if not okAfter
            nxt = Mid(upper, after, 1)
            okAfter = not isAlnumChar(nxt)
        end if
        if okBefore and okAfter then return i
        at = i + 1
    end while
    return 0
end function

function isAlnumChar(ch as string) as boolean
    c = Asc(ch)
    if c >= 48 and c <= 57 then return true
    if c >= 65 and c <= 90 then return true
    if c >= 97 and c <= 122 then return true
    return false
end function

' Strips a broadcast suffix off a side: "New York Yankees MLB In-Game Live"
' -> team "New York Yankees", league "MLB In-Game Live". Anything from a
' recognised league word onwards is the broadcast's labelling, not the team.
' Never cuts at position 1 — "Arsenal" must survive even if some competition
' contains it. Returns { team, league }.
function splitTrailingLeague(ctx as object, side as string) as object
    upper = UCase(side)
    cutAt = 0
    for each w in ctx.allLeagueWords
        i = wordIndexOf(upper, w)
        if i > 1 and (cutAt = 0 or i < cutAt) then cutAt = i
    end for
    if cutAt <= 1 then return { team: side, league: "" }
    head = side.left(cutAt - 1).trim()
    tail = tidyLeague(Mid(side, cutAt))
    if head.len() < 3 then return { team: side, league: "" }
    return { team: head, league: tail }
end function

' Splits a competition prefix off the home side: "NBA Summer League Lakers"
' -> league "NBA Summer League", team "Lakers". Only fires when the side
' STARTS with a recognised league word, and only consumes connector words.
function splitLeadingLeague(ctx as object, side as string) as object
    words = side.trim().split(" ")
    cleaned = []
    for each w in words
        if w.trim() <> "" then cleaned.push(w.trim())
    end for
    if cleaned.count() < 2 then return { team: side, league: "" }
    if SportOf(ctx, cleaned[0]) = "" then return { team: side, league: "" }
    take = 1
    while take < cleaned.count() and ctx.leagueTail.doesExist(LCase(cleaned[take]))
        take = take + 1
    end while
    if take >= cleaned.count() then return { team: side, league: "" }
    teamParts = []
    leagueParts = []
    for i = 0 to cleaned.count() - 1
        if i < take then leagueParts.push(cleaned[i]) else teamParts.push(cleaned[i])
    end for
    ' "UEFA - PSG" leaves the separator on the front of the team once the
    ' competition is cut off, so clean it here too — stripping before the
    ' split can't see it.
    team = stripLeadingPunct(teamParts.join(" ").trim())
    if team.len() < 3 then return { team: side, league: "" }
    return { team: team, league: tidyLeague(leagueParts.join(" ").trim()) }
end function

' Strips a date/time tail off a side ("Atlanta Falcons @ Oct 27, 6").
' Deliberately plain — each rule does one obvious thing.
function stripWhen(ctx as object, side as string) as string
    s = side.trim()
    s = ctx.rxBracketNote.replaceAll(s, " ").trim()

    ' "… @ Oct 27, 6" — only cut when the tail actually looks date/time-ish,
    ' so a fixture genuinely written "A @ B" is untouched.
    at = Instr(1, s, " @ ")
    if at > 1
        tail = Mid(s, at)
        hasDigit = CreateObject("roRegex", "\d", "").isMatch(tail)
        if hasDigit or ctx.rxMonthWord.isMatch(tail)
            s = s.left(at - 1).trim()
        end if
    end if

    ' "… Sat Oct 27" — everything from a month word followed by digits.
    if ctx.rxMonthTail.isMatch(s)
        s = ctx.rxMonthTail.replaceAll(s, "\1").trim()
    end if

    s = ctx.rxNumericDateTail.replaceAll(s, "").trim()
    s = ctx.rxTrailingClock.replaceAll(s, "").trim()
    ' A lone trailing number needs a comma/@ before it: "Schalke 04" is a
    ' real team name and bare space-then-digits must never be stripped.
    s = ctx.rxCommaDigits.replaceAll(s, "").trim()

    if s = "" then return side.trim()
    return s
end function

' True when a side is really a date/number fragment: "Aug 3 15", "11.07 05".
function isDateish(ctx as object, s as string) as boolean
    t = s.trim()
    if t.len() < 3 then return true
    letters = 0
    digits = 0
    for i = 1 to t.len()
        c = Asc(Mid(t, i, 1))
        if (c >= 65 and c <= 90) or (c >= 97 and c <= 122) then letters = letters + 1
        if c >= 48 and c <= 57 then digits = digits + 1
    end for
    if digits > 0 and letters <= 3 and digits >= letters then return true
    if CreateObject("roRegex", "^[A-Za-z]{3,9}\.?\s*\d", "").isMatch(t) and ctx.rxMonthWord.isMatch(t) then return true
    return false
end function

' True when a side reads like an actual competitor.
function isTeamLike(ctx as object, s as string) as boolean
    t = LCase(s.trim())
    if ctx.notATeam.doesExist(t) then return false
    if ctx.rxMatchday.isMatch(t) then return false
    ' Multi-word filler as a prefix; single words must match the WHOLE side
    ' ("The Strongest" is a real club).
    for each w in ctx.notATeam
        if Instr(1, w, " ") > 0 and t.left(w.len() + 1) = w + " " then return false
    end for
    return true
end function

function plausibleTeam(ctx as object, s as string) as boolean
    t = s.trim()
    if t.len() < 3 or t.len() > 48 then return false
    if not ctx.rxThreeLetters.isMatch(t) then return false
    if ctx.rxQualifierStart.isMatch(t) then return false
    return true
end function

' An event with no two sides still has to read like an event — this guards
' the fallback path so the wreckage of a refused fixture can't sneak in.
function plausibleHeadline(ctx as object, s as string) as boolean
    t = s.trim()
    if t.len() < 6 then return false
    if ctx.rxQualifierStart.isMatch(t) then return false
    if ctx.rxDanglingV.isMatch(t) then return false
    return ctx.rxWordChars.isMatch(t)
end function

' Splits the fixture segment from the competition segments (":" or "|").
function sportsSegments(s as string) as object
    norm = s.replace("|", ":")
    parts = norm.split(":")
    out = []
    for each p in parts
        t = p.trim()
        if t <> "" then out.push(t)
    end for
    return out
end function

' ---- Event parsing ----------------------------------------------------------

' Reads a fixture out of a free-text title. Returns an AA
' { title, sport, league, homeTeam, awayTeam, startS } or invalid.
' [known] is context (a channel's group+name) used ONLY to identify the
' sport, never to invent teams. startS = epoch seconds, 0 when unknown.
function ParseEventTitle(ctx as object, raw as string, known as string, startS as integer) as dynamic
    cleaned = sportsClean(ctx, raw)
    if cleaned.len() < 6 then return invalid

    sportInTitle = SportOf(ctx, cleaned)
    sportInContext = SportOf(ctx, known)

    parts = sportsSegments(cleaned)
    league = ""

    ' "Indiana vs Minnesota - Women's National Basketball Association":
    ' split the competition tail off, keep it as the league.
    reParts = []
    for each part in parts
        groups = ctx.rxFixtureDashLeague.match(part)
        if groups.count() >= 3
            if league = "" then league = tidyLeague(groups[2])
            reParts.push(groups[1].trim())
        else
            reParts.push(part)
        end if
    end for
    parts = reParts

    for idx = 0 to parts.count() - 1
        part = parts[idx]
        groups = ctx.rxVersus.match(part)
        if groups.count() < 3 then groups = ctx.rxDashVersus.match(part)
        if groups.count() >= 3
            home = stripWhen(ctx, groups[1])
            away = stripWhen(ctx, groups[2])
            home = stripLeadingPunct(home)
            stripped = ctx.rxLeadingStreamNo.replaceAll(home, "")
            if stripped.trim().len() >= 3 then home = stripped.trim()
            lead = splitLeadingLeague(ctx, home)
            if lead.league <> ""
                home = lead.team
                if league = "" then league = tidyLeague(lead.league)
            end if
            if isTeamLike(ctx, home) and isTeamLike(ctx, away)
                if not isDateish(ctx, home) and not isDateish(ctx, away)
                    cutAway = splitTrailingLeague(ctx, away)
                    away = cutAway.team
                    if cutAway.league <> "" and league = "" then league = cutAway.league
                    cutHome = splitTrailingLeague(ctx, home)
                    if cutHome.league <> ""
                        home = cutHome.team
                        if league = "" then league = cutHome.league
                    end if
                    if plausibleTeam(ctx, home) and plausibleTeam(ctx, away)
                        if not ctx.rxEpisodeish.isMatch(home) and not ctx.rxEpisodeish.isMatch(away)
                            ' A preceding segment that named the competition
                            ' becomes the league ("AFL 01: A v B").
                            if league = "" and idx > 0
                                cand = CreateObject("roRegex", "\s*\d+\s*$", "").replaceAll(parts[idx - 1], "")
                                if cand.len() >= 2 then league = tidyLeague(cand)
                            end if
                            ' Evidence order: sport in the TITLE, then the
                            ' COMPETITION, then the channel it's on.
                            sport = sportInTitle
                            if sport = "" then sport = SportOf(ctx, league)
                            if sport = "" then sport = sportInContext
                            if sport = "" then sport = "Other"
                            return { title: home + " v " + away, sport: sport, league: league, homeTeam: home, awayTeam: away, startS: startS, stopS: 0 }
                        end if
                    end if
                end if
            end if
        end if
    end for

    ' No two sides — a golf round, a fight card, a race. Real events, but
    ' ONLY when the title itself names the sport: a sports CHANNEL showing
    ' an ordinary programme is not a sporting event (the KSHB bug).
    if sportInTitle = "" then return invalid
    headline = cleaned
    if parts.count() > 0 then headline = parts[parts.count() - 1]
    if not plausibleHeadline(ctx, headline) then return invalid
    hl = ""
    if parts.count() > 1 then hl = parts[0]
    return { title: headline, sport: sportInTitle, league: hl, homeTeam: "", awayTeam: "", startS: startS, stopS: 0 }
end function

' Reads a fixture out of a CHANNEL name. Ordinary sports channels are not
' events. Times written into channel names are deliberately ignored: they
' carry a timezone and no safe year, and a wrong time files a game on the
' wrong day. Only EPG timestamps are trusted.
function ParseChannelName(ctx as object, name as string, groupName as string) as dynamic
    cleaned = sportsClean(ctx, name)
    eventful = ctx.rxVersus.isMatch(cleaned)
    if not eventful
        for each p in sportsSegments(cleaned)
            if ctx.rxVersus.isMatch(p) then eventful = true
        end for
    end if
    if not eventful then return invalid
    return ParseEventTitle(ctx, name, groupName, 0)
end function

' A real event is a fixture (two sides) or a named event in a sport with no
' sides. Everything else a provider files under sport is programming.
function IsRealSportsEvent(ctx as object, e as object) as boolean
    if e.homeTeam <> "" and e.awayTeam <> "" then return true
    return ctx.individualSports.doesExist(e.sport)
end function

' True when an EPG title is really just the channel's own name — placeholder
' guide entries ("USA SportsGrid" on the USA SportsGrid channel).
function TitleIsJustTheChannel(ctx as object, title as string, channelName as string) as boolean
    t = ctx.rxNonAlnum.replaceAll(UCase(title), "")
    c = ctx.rxNonAlnum.replaceAll(UCase(channelName), "")
    if t = "" or c = "" then return false
    if t = c then return true
    shorter = t
    longer = c
    if t.len() > c.len()
        shorter = c
        longer = t
    end if
    if Instr(1, longer, shorter) <= 0 then return false
    return shorter.len() >= Int(longer.len() * 0.6)
end function

' ---- Dedupe / merge ---------------------------------------------------------

function QualityOf(ctx as object, channelName as string) as string
    upper = UCase(channelName)
    for i = 0 to ctx.qualityOrder.count() - 1
        if ctx.rxQuality[i].isMatch(upper) then return ctx.qualityOrder[i]
    end for
    return ""
end function

function RegionOf(ctx as object, channelName as string) as string
    groups = ctx.rxRegionTag.match(channelName)
    if groups.count() >= 2 then return groups[1]
    return ""
end function

' Reduces a team name to something two spellings can agree on.
function NormaliseTeam(ctx as object, name as string) as string
    s = UCase(name)
    s = ctx.rxClubWords.replaceAll(s, " ")
    return ctx.rxNonAlnum.replaceAll(s, "")
end function

' The merge key. Sides sorted so "A v B" and "B v A" collapse; the start
' time bucketed to the half hour so listings minutes apart merge while a
' genuine repeat that evening does not.
'
' The bucket is a floor, exactly as on Android, so two listings a few
' minutes apart that happen to straddle :00 or :30 land in different
' buckets and stay separate. That is the accepted trade: widening it to a
' sliding window would merge a genuine 19:45 repeat into an 18:00 kick-off,
' which is the worse failure.
function SportsEventKey(ctx as object, e as object) as string
    whenPart = ""
    if e.startS > 0 then whenPart = "@" + Int(e.startS / 1800).toStr()
    if e.homeTeam <> "" and e.awayTeam <> ""
        sides = [NormaliseTeam(ctx, e.homeTeam), NormaliseTeam(ctx, e.awayTeam)]
        sides.sort()
        return e.sport + "|" + sides.join("~") + whenPart
    end if
    return e.sport + "|" + NormaliseTeam(ctx, e.title) + whenPart
end function

' Merges sightings [{event, channel}] into events, each carrying every
' channel that shows it, best quality first. Where sightings disagree the
' richest wins: a real time beats none, a named league beats none, the
' longest title is kept.
function MergeSightings(ctx as object, sightings as object) as object
    byKey = {}
    order = []
    for each s in sightings
        ' Longest-title-wins (below) actively prefers the DIRTIER spelling
        ' when one sighting kept a separator the other lost, so clean every
        ' title here — the last point they all pass through.
        s.event.title = stripLeadingPunct(s.event.title)
        k = SportsEventKey(ctx, s.event)
        ex = byKey[k]
        if ex = invalid
            byKey[k] = {
                key: k, title: s.event.title, sport: s.event.sport, league: s.event.league,
                homeTeam: s.event.homeTeam, awayTeam: s.event.awayTeam,
                startS: s.event.startS, stopS: s.event.stopS, country: "",
                channels: [s.event_channel], seen: {}
            }
            byKey[k].seen[s.event_channel.channelId] = true
            order.push(k)
        else
            if not ex.seen.doesExist(s.event_channel.channelId)
                ex.seen[s.event_channel.channelId] = true
                ex.channels.push(s.event_channel)
            end if
            if s.event.title.len() > ex.title.len() then ex.title = s.event.title
            if ex.league = "" then ex.league = s.event.league
            if ex.homeTeam = "" then ex.homeTeam = s.event.homeTeam
            if ex.awayTeam = "" then ex.awayTeam = s.event.awayTeam
            if ex.startS = 0 then ex.startS = s.event.startS
            if ex.stopS = 0 and s.event.stopS > 0 then ex.stopS = s.event.stopS
        end if
    end for
    out = []
    for each k in order
        e = byKey[k]
        e.delete("seen")
        sortEventChannels(ctx, e.channels)
        out.push(e)
    end for
    return out
end function

' Insertion sort by quality rank then name (channel lists per event are small).
sub sortEventChannels(ctx as object, arr as object)
    for i = 1 to arr.count() - 1
        cur = arr[i]
        curRank = channelRank(ctx, cur)
        j = i - 1
        while j >= 0
            cmp = arr[j]
            cmpRank = channelRank(ctx, cmp)
            swap = false
            if cmpRank > curRank
                swap = true
            else if cmpRank = curRank and cmp.channelName > cur.channelName
                swap = true
            end if
            if not swap then exit while
            arr[j + 1] = arr[j]
            j = j - 1
        end while
        arr[j + 1] = cur
    end for
end sub

function channelRank(ctx as object, c as object) as integer
    q = ToStr(c.quality)
    for i = 0 to ctx.qualityOrder.count() - 1
        if ctx.qualityOrder[i] = q then return i
    end for
    return ctx.qualityOrder.count()
end function

' Live window: start..stop, or start..start+3h when no stop is known —
' covers almost every sport and beats dropping the game off the list.
function EventIsLiveAt(e as object, nowS as integer) as boolean
    if e.startS = 0 then return false
    stopAt = ToInt(GetField(e, "stopS"))
    if stopAt = 0 then stopAt = e.startS + 3 * 3600
    return nowS >= e.startS and nowS < stopAt
end function

' ---- Country ----------------------------------------------------------------

' ISO code for the flag on the row, or "". Two rules that are the point:
' when the carrying channels' region tags disagree it is an international
' broadcast and NO flag is claimed; and a nationality word always beats a
' league name. Returns "" rather than guessing.
function SportsCountryOf(ctx as object, league as string, title as string, regions as object) as string
    tags = {}
    for each r in regions
        t = normaliseCountryTag(ctx, ToStr(r))
        if t <> "" then tags[t] = true
    end for
    if tags.count() = 1
        for each t in tags
            return t
        end for
    end if
    for each mapName in ["countryAdjectives", "leagueHomes"]
        mp = ctx[mapName]
        for each text in [league, title]
            if text <> ""
                lower = LCase(text)
                best = ""
                bestLen = 0
                for each k in mp
                    if Instr(1, lower, k) > 0 and k.len() > bestLen
                        best = mp[k]
                        bestLen = k.len()
                    end if
                end for
                if best <> "" then return best
            end if
        end for
    end for
    return ""
end function

function normaliseCountryTag(ctx as object, raw as string) as string
    t = UCase(raw)
    out = ""
    for i = 1 to t.len()
        ch = Mid(t, i, 1)
        c = Asc(ch)
        if c >= 65 and c <= 90 then out = out + ch
    end for
    if ctx.tagAliases.doesExist(out) then return ctx.tagAliases[out]
    if out.len() = 2 then return out
    return ""
end function

' ---- Channel-list labels ----------------------------------------------------

' What to call one stream in the "watch on" list. Event channels are named
' after the fixture itself — the member already knows what the game is —
' so show what actually differs: region, quality, "Stream N". A real
' broadcaster name keeps its own name.
function StreamLabel(ctx as object, c as object, index as integer) as object
    bits = []
    if ToStr(c.region) <> "" then bits.push(ToStr(c.region))
    if ToStr(c.quality) <> "" then bits.push(ToStr(c.quality))
    looksLikeEvent = (ParseChannelName(ctx, ToStr(c.channelName), "") <> invalid)
    if not looksLikeEvent
        sub_ = ""
        if bits.count() > 0 then sub_ = bits.join("  ")
        return { title: ToStr(c.channelName), subtitle: sub_ }
    end if
    lead = "Stream " + (index + 1).toStr()
    if bits.count() > 0 then lead = bits.join("  ")
    return { title: lead, subtitle: "" }
end function

' ---- Self-test --------------------------------------------------------------

' Every case below is a real bug from the Android build's iteration. Not
' called in normal running; call from anywhere and read the console.
function SportsSelfTest() as boolean
    ctx = SportsCtx()
    passed = 0
    total = 0

    ' --- fixture parsing from channel names ---
    cases = [
        { raw: "AU | AFL 01: Adelaide Crows v Collingwood | Thu 23rd Jul 10:30AM UK", sport: "Soccer", home: "Adelaide Crows", away: "Collingwood" },
        { raw: "00 Burnley v Torin", home: "Burnley", away: "Torin" },
        { raw: "EVENTS: 00 Burton Albion v Derby County", home: "Burton Albion", away: "Derby County" },
        { raw: "1860 Munich v Hansa Rostock", home: "1860 Munich", away: "Hansa Rostock" },
        { raw: "UEFA: - PSG v Arsenal", home: "PSG", away: "Arsenal", league: "UEFA" },
        { raw: "UEFA - PSG v arsenal", home: "PSG", away: "arsenal", league: "UEFA" },
        { raw: "Scottish Premiership 03: Aberdeen FC v Hearts FC", home: "Aberdeen FC", away: "Hearts FC", league: "Scottish Premiership" },
        { raw: "PPV 03: UFC Fight Night Medic v Rodriguez 10:00 am", sport: "Fights", home: "Fight Night Medic", away: "Rodriguez" },
        { raw: "Australian Rules Football: Collingwood vs Geelong Cats @ Jul 30 10:30 AM :MAX UK  03", sport: "Soccer", home: "Collingwood", away: "Geelong Cats" },
        { raw: "NBA Summer League Lakers v Bulls", sport: "Basketball", home: "Lakers", away: "Bulls" },
        { raw: "St. Louis Cardinals v New York Yankees MLB In-Game Live", sport: "Baseball", home: "St. Louis Cardinals", away: "New York Yankees" },
        { raw: "Tampa Bay Buccaneers v Atlanta Falcons @ Oct 27, 6", home: "Tampa Bay Buccaneers", away: "Atlanta Falcons" },
        { raw: "Washington Commanders v Chicago Bears NFL", sport: "Football", home: "Washington Commanders", away: "Chicago Bears" },
        { raw: "Chelsea (W) v Arsenal (W)", home: "Chelsea (W)", away: "Arsenal (W)" }
    ]
    for each c in cases
        total = total + 1
        e = ParseChannelName(ctx, c.raw, "")
        ok = (e <> invalid)
        if ok and c.doesExist("home") then ok = (e.homeTeam = c.home and e.awayTeam = c.away)
        if ok and c.doesExist("sport") then ok = (e.sport = c.sport)
        if ok and c.doesExist("league") then ok = (e.league = c.league)
        if ok
            passed = passed + 1
        else
            got = "invalid"
            if e <> invalid then got = e.sport + ": '" + e.homeTeam + "' v '" + e.awayTeam + "'"
            KLog("sportstest", "FAIL parse '" + c.raw + "' -> " + got)
        end if
    end for

    ' --- must be REJECTED ---
    rejects = [
        "USA Fox News",
        "|AU| 7AFL",
        "KSHB 41 News 5PM",
        "The Big Bang Theory",
        "American Ninja Warrior",
        "Liga Inglesa Destaques v 37 Jornada",
        "Upcoming v MLB Network Strike Zone",
        "The Boys - S04E04 - Wisdom of the Ages",
        "Premier League TV",
        "NFL Game Re-Airs"
    ]
    for each r in rejects
        total = total + 1
        e = ParseChannelName(ctx, r, "")
        keep = (e <> invalid and IsRealSportsEvent(ctx, e))
        if not keep
            passed = passed + 1
        else
            KLog("sportstest", "FAIL should reject '" + r + "' -> " + e.title)
        end if
    end for

    ' --- EPG title on a sports channel: programme is NOT sport (KSHB bug) ---
    total = total + 1
    e = ParseEventTitle(ctx, "American Ninja Warrior", "NFL Teams NBC Chiefs (KSHB) Kansas City MO", 0)
    if e = invalid or not IsRealSportsEvent(ctx, e)
        passed = passed + 1
    else
        KLog("sportstest", "FAIL sports-channel programme leaked: " + e.title)
    end if

    ' --- individual sport WITH sport in title is kept ---
    total = total + 1
    e = ParseEventTitle(ctx, "UFC 300: Main Card", "", 0)
    if e <> invalid and e.sport = "Fights" and IsRealSportsEvent(ctx, e)
        passed = passed + 1
    else
        KLog("sportstest", "FAIL UFC card rejected")
    end if

    ' --- merge cleans a leading separator even when it wins on length ---
    total = total + 1
    dirty = { title: "- PSG v arsenal", sport: "Soccer", league: "UEFA", homeTeam: "PSG", awayTeam: "arsenal", startS: 0, stopS: 0 }
    clean = { title: "PSG v arsenal", sport: "Soccer", league: "UEFA", homeTeam: "PSG", awayTeam: "arsenal", startS: 0, stopS: 0 }
    ch1 = { channelId: "a", channelName: "A", quality: "", region: "" }
    ch2 = { channelId: "b", channelName: "B", quality: "", region: "" }
    merged = MergeSightings(ctx, [{ event: clean, event_channel: ch1 }, { event: dirty, event_channel: ch2 }])
    if merged.count() = 1 and merged[0].title = "PSG v arsenal"
        passed = passed + 1
    else
        got = "?"
        if merged.count() > 0 then got = merged[0].title
        KLog("sportstest", "FAIL merged title kept wreckage: '" + got + "'")
    end if

    ' --- dedupe: A v B merges with B v A, and AFL merges with Australian Rules ---
    total = total + 1
    e1 = ParseChannelName(ctx, "AU | AFL 01: Adelaide Crows v Collingwood", "")
    e2 = ParseChannelName(ctx, "Australian Rules Football: Collingwood vs Adelaide Crows 02", "")
    if e1 <> invalid and e2 <> invalid and SportsEventKey(ctx, e1) = SportsEventKey(ctx, e2)
        passed = passed + 1
    else
        KLog("sportstest", "FAIL AFL/Australian Rules did not merge")
    end if

    ' --- half-hour bucket: minutes apart merge, hours apart do not ---
    ' Both timestamps sit INSIDE one bucket on purpose: the floor means a
    ' pair straddling :00/:30 legitimately does not merge (documented above).
    total = total + 1
    a = { title: "A v B", sport: "Soccer", league: "", homeTeam: "Alpha", awayTeam: "Beta", startS: 1000000200 }
    b = { title: "A v B", sport: "Soccer", league: "", homeTeam: "Beta", awayTeam: "Alpha", startS: 1000000500 }
    c2 = { title: "A v B", sport: "Soccer", league: "", homeTeam: "Alpha", awayTeam: "Beta", startS: 1000000200 + 4 * 3600 }
    if SportsEventKey(ctx, a) = SportsEventKey(ctx, b) and SportsEventKey(ctx, a) <> SportsEventKey(ctx, c2)
        passed = passed + 1
    else
        KLog("sportstest", "FAIL half-hour bucket")
    end if

    ' --- country ---
    total = total + 1
    if SportsCountryOf(ctx, "South African Premier League", "", []) = "ZA" and SportsCountryOf(ctx, "Premier League", "", []) = "GB"
        passed = passed + 1
    else
        KLog("sportstest", "FAIL nationality-beats-league")
    end if
    total = total + 1
    if SportsCountryOf(ctx, "", "", ["AU", "AU"]) = "AU" and SportsCountryOf(ctx, "", "", ["AU", "US"]) = "" and SportsCountryOf(ctx, "", "", ["UK"]) = "GB"
        passed = passed + 1
    else
        KLog("sportstest", "FAIL region-tag rules")
    end if

    KLog("sportstest", passed.toStr() + "/" + total.toStr() + " passed")
    return passed = total
end function
