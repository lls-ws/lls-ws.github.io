' QR code, written out by hand — Roku ships no QR library and the pairing
' screen needs one, so this is the encoder.
'
' FIXED at version 3 (a 29x29 grid) and error correction level M, because
' that is the one size the pairing screen ever asks for: the link address
' plus a six-character code is 38 bytes, and a version-3/M byte-mode symbol
' holds 42. Nothing here reads a table of other versions, so anything longer
' than 42 bytes is refused rather than encoded wrong — a QR that scans to
' the wrong thing is worse than no QR at all.
'
' Everything works on plain integers and strings: BrightScript has no XOR
' operator and its "and"/"or" short-circuit, so qrXor() does the bit work
' the long way and shifts are written as multiply/divide by powers of two.
'
' This runs on the Task thread (see SourceLinkTask), never on the render
' thread — it is a few hundred thousand small operations.
'
' Checked end to end the only way that really counts: a pairing code drawn
' by this encoder was photographed off a real TV screen and scanned with a
' phone, and it came back as the right link address. That is one code on one
' screen, not a sweep of every mask against a reference encoder — there is no
' test script for this in the repo.

' ---- Public -----------------------------------------------------------------

' Encodes text as a QR code and answers 29 strings of 29 characters, row 0
' first, "1" meaning a dark module. Answers invalid when the text is longer
' than this symbol size holds.
function QrEncode(text as string) as object
    data = qrDataCodewords(text)
    if data = invalid then return invalid
    ec = qrEcCodewords(data)
    cw = []
    for each b in data
        cw.push(b)
    end for
    for each b in ec
        cw.push(b)
    end for

    size = 29
    mat = []
    fnc = []
    for r = 0 to size - 1
        row = []
        frow = []
        for c = 0 to size - 1
            row.push(0)
            frow.push(0)
        end for
        mat.push(row)
        fnc.push(frow)
    end for

    qrDrawFunctions(mat, fnc, size)
    ' Drawn once with a throwaway mask so the format squares are marked as
    ' function modules before any data goes in; the real one is written at
    ' the end once a mask has been picked.
    qrDrawFormat(mat, fnc, size, 0)
    qrDrawData(mat, fnc, size, cw)

    best = 0
    bestScore = 0
    for msk = 0 to 7
        qrApplyMask(mat, fnc, size, msk)
        qrDrawFormat(mat, fnc, size, msk)
        s = qrPenalty(mat, size)
        if msk = 0 or s < bestScore
            best = msk
            bestScore = s
        end if
        ' Masking is its own undo — XOR twice and the grid is back.
        qrApplyMask(mat, fnc, size, msk)
    end for
    qrApplyMask(mat, fnc, size, best)
    qrDrawFormat(mat, fnc, size, best)

    rows = []
    for r = 0 to size - 1
        s = ""
        for c = 0 to size - 1
            if mat[r][c] = 1
                s = s + "1"
            else
                s = s + "0"
            end if
        end for
        rows.push(s)
    end for
    return rows
end function

' ---- Bit helpers ------------------------------------------------------------

' Exclusive-or, one bit at a time. BrightScript has no XOR operator, and
' 16 bits covers everything here (bytes for the error correction, 15 bits
' for the format information).
function qrXor(a as integer, b as integer) as integer
    out = 0
    bit = 1
    x = a
    y = b
    for i = 0 to 15
        if x mod 2 <> y mod 2 then out = out + bit
        x = Int(x / 2)
        y = Int(y / 2)
        bit = bit * 2
    end for
    return out
end function

function qrPow2(n as integer) as integer
    v = 1
    for i = 1 to n
        v = v * 2
    end for
    return v
end function

' Bit number i of x, counting from the least significant end.
function qrBitAt(x as integer, i as integer) as integer
    return Int(x / qrPow2(i)) mod 2
end function

' value written out as width bits, most significant first.
function qrBits(value as integer, width as integer) as string
    out = ""
    for i = width - 1 to 0 step -1
        if qrBitAt(value, i) = 1
            out = out + "1"
        else
            out = out + "0"
        end if
    end for
    return out
end function

function qrByteFromBits(bits as string, at as integer) as integer
    v = 0
    for i = 0 to 7
        v = v * 2
        if bits.mid(at + i, 1) = "1" then v = v + 1
    end for
    return v
end function

' ---- Data codewords ---------------------------------------------------------

' The 44 data codewords of a version-3/M symbol: byte mode, the length, the
' text, a terminator, then the standard alternating padding.
function qrDataCodewords(text as string) as object
    n = text.len()
    if n > 42 then return invalid
    bits = "0100"
    bits = bits + qrBits(n, 8)
    for i = 0 to n - 1
        bits = bits + qrBits(Asc(text.mid(i, 1)), 8)
    end for

    cap = 44 * 8
    room = cap - bits.len()
    term = 4
    if room < 4 then term = room
    for i = 1 to term
        bits = bits + "0"
    end for
    while bits.len() mod 8 <> 0
        bits = bits + "0"
    end while

    cw = []
    at = 0
    while at < bits.len()
        cw.push(qrByteFromBits(bits, at))
        at = at + 8
    end while
    pad = 236
    while cw.count() < 44
        cw.push(pad)
        if pad = 236
            pad = 17
        else
            pad = 236
        end if
    end while
    return cw
end function

' ---- Error correction (Reed-Solomon over GF(256)) ---------------------------

' The 26 error-correction codewords that follow the data. One block, which
' is why there is no interleaving anywhere in this file: version 3 at level
' M is a single block of 44 data and 26 error correction codewords.
function qrEcCodewords(data as object) as object
    ' Log and antilog tables for GF(2^8), primitive polynomial 0x11D (285).
    expT = []
    logT = []
    for i = 0 to 255
        logT.push(0)
    end for
    x = 1
    for i = 0 to 254
        expT.push(x)
        logT[x] = i
        x = x * 2
        if x >= 256 then x = qrXor(x, 285)
    end for

    ' Generator polynomial: (x - a^0)(x - a^1)...(x - a^25), highest power
    ' first.
    gen = [1]
    for i = 0 to 25
        nxt = []
        for j = 0 to gen.count()
            nxt.push(0)
        end for
        for j = 0 to gen.count() - 1
            nxt[j] = qrXor(nxt[j], gen[j])
            nxt[j + 1] = qrXor(nxt[j + 1], qrGfMul(gen[j], expT[i], expT, logT))
        end for
        gen = nxt
    end for

    remain = []
    for i = 0 to 25
        remain.push(0)
    end for
    for each b in data
        factor = qrXor(b, remain[0])
        remain.shift()
        remain.push(0)
        for j = 0 to 25
            remain[j] = qrXor(remain[j], qrGfMul(gen[j + 1], factor, expT, logT))
        end for
    end for
    return remain
end function

function qrGfMul(a as integer, b as integer, expT as object, logT as object) as integer
    if a = 0 or b = 0 then return 0
    return expT[(logT[a] + logT[b]) mod 255]
end function

' ---- The grid ---------------------------------------------------------------

' Sets a module AND marks it as part of the fixed pattern, so the data and
' the mask both leave it alone.
sub qrSetFn(mat as object, fnc as object, r as integer, c as integer, v as integer)
    mat[r][c] = v
    fnc[r][c] = 1
end sub

sub qrDrawFunctions(mat as object, fnc as object, size as integer)
    ' The dotted timing lines along row 6 and column 6.
    for i = 0 to size - 1
        v = 0
        if i mod 2 = 0 then v = 1
        qrSetFn(mat, fnc, 6, i, v)
        qrSetFn(mat, fnc, i, 6, v)
    end for
    ' The three big squares, drawn over the timing lines where they meet.
    qrFinder(mat, fnc, size, 3, 3)
    qrFinder(mat, fnc, size, 3, size - 4)
    qrFinder(mat, fnc, size, size - 4, 3)
    ' Version 3 has exactly one alignment square, centred at row 22 col 22.
    qrAlign(mat, fnc, 22, 22)
    ' The module that is always dark, whatever else happens.
    qrSetFn(mat, fnc, size - 8, 8, 1)
end sub

sub qrFinder(mat as object, fnc as object, size as integer, r as integer, c as integer)
    for dr = -4 to 4
        for dc = -4 to 4
            dist = Abs(dr)
            if Abs(dc) > dist then dist = Abs(dc)
            rr = r + dr
            cc = c + dc
            if rr >= 0 and rr < size and cc >= 0 and cc < size
                v = 1
                if dist = 2 or dist = 4 then v = 0
                qrSetFn(mat, fnc, rr, cc, v)
            end if
        end for
    end for
end sub

sub qrAlign(mat as object, fnc as object, r as integer, c as integer)
    for dr = -2 to 2
        for dc = -2 to 2
            dist = Abs(dr)
            if Abs(dc) > dist then dist = Abs(dc)
            v = 1
            if dist = 1 then v = 0
            qrSetFn(mat, fnc, r + dr, c + dc, v)
        end for
    end for
end sub

' The 15 bits that say which error correction level and which mask were
' used, written twice so a damaged corner doesn't lose them. Level M is 0,
' so the five data bits are just the mask number.
sub qrDrawFormat(mat as object, fnc as object, size as integer, msk as integer)
    d = msk
    remain = d
    for i = 1 to 10
        remain = qrXor(remain * 2, Int(remain / 512) * 1335)
    end for
    bits = qrXor(d * 1024 + remain, 21522)

    ' Copy one: down the column beside the top-left square, then left along
    ' the row under it.
    for i = 0 to 5
        qrSetFn(mat, fnc, i, 8, qrBitAt(bits, i))
    end for
    qrSetFn(mat, fnc, 7, 8, qrBitAt(bits, 6))
    qrSetFn(mat, fnc, 8, 8, qrBitAt(bits, 7))
    qrSetFn(mat, fnc, 8, 7, qrBitAt(bits, 8))
    for i = 9 to 14
        qrSetFn(mat, fnc, 8, 14 - i, qrBitAt(bits, i))
    end for

    ' Copy two: rightwards along row 8 from the far edge, then down column 8
    ' from the bottom-left square.
    for i = 0 to 7
        qrSetFn(mat, fnc, 8, size - 1 - i, qrBitAt(bits, i))
    end for
    for i = 8 to 14
        qrSetFn(mat, fnc, size - 15 + i, 8, qrBitAt(bits, i))
    end for
    qrSetFn(mat, fnc, size - 8, 8, 1)
end sub

' The zigzag: two columns at a time from the right edge, alternating up and
' down, skipping the fixed patterns and the timing column.
sub qrDrawData(mat as object, fnc as object, size as integer, cw as object)
    total = cw.count() * 8
    i = 0
    colRight = size - 1
    while colRight >= 1
        if colRight = 6 then colRight = 5
        for vert = 0 to size - 1
            for j = 0 to 1
                c = colRight - j
                r = vert
                if Int((colRight + 1) / 2) mod 2 = 0 then r = size - 1 - vert
                if fnc[r][c] = 0 and i < total
                    mat[r][c] = qrBitAt(cw[Int(i / 8)], 7 - (i mod 8))
                    i = i + 1
                end if
            end for
        end for
        colRight = colRight - 2
    end while
end sub

' Flips the data modules the chosen mask calls for. Running it twice with
' the same mask puts the grid back.
sub qrApplyMask(mat as object, fnc as object, size as integer, msk as integer)
    for r = 0 to size - 1
        for c = 0 to size - 1
            if fnc[r][c] = 0
                flip = false
                if msk = 0
                    flip = ((c + r) mod 2 = 0)
                else if msk = 1
                    flip = (r mod 2 = 0)
                else if msk = 2
                    flip = (c mod 3 = 0)
                else if msk = 3
                    flip = ((c + r) mod 3 = 0)
                else if msk = 4
                    flip = ((Int(c / 3) + Int(r / 2)) mod 2 = 0)
                else if msk = 5
                    flip = ((c * r) mod 2 + (c * r) mod 3 = 0)
                else if msk = 6
                    flip = (((c * r) mod 2 + (c * r) mod 3) mod 2 = 0)
                else
                    flip = (((c + r) mod 2 + (c * r) mod 3) mod 2 = 0)
                end if
                if flip then mat[r][c] = 1 - mat[r][c]
            end if
        end for
    end for
end sub

' ---- Mask scoring -----------------------------------------------------------

' The four penalties from the spec. Lower is better; whichever mask scores
' lowest is the one that gets shipped. Every mask produces a valid code, so
' this is about how easy the result is for a phone to read, not about
' whether it reads at all.
function qrPenalty(mat as object, size as integer) as integer
    p = 0

    ' 1: long runs of one colour along a row or a column.
    for r = 0 to size - 1
        runLen = 1
        for c = 1 to size - 1
            if mat[r][c] = mat[r][c - 1]
                runLen = runLen + 1
            else
                if runLen >= 5 then p = p + runLen - 2
                runLen = 1
            end if
        end for
        if runLen >= 5 then p = p + runLen - 2
    end for
    for c = 0 to size - 1
        runLen = 1
        for r = 1 to size - 1
            if mat[r][c] = mat[r - 1][c]
                runLen = runLen + 1
            else
                if runLen >= 5 then p = p + runLen - 2
                runLen = 1
            end if
        end for
        if runLen >= 5 then p = p + runLen - 2
    end for

    ' 2: any 2x2 block all one colour.
    for r = 0 to size - 2
        for c = 0 to size - 2
            v = mat[r][c]
            if mat[r][c + 1] = v and mat[r + 1][c] = v and mat[r + 1][c + 1] = v
                p = p + 3
            end if
        end for
    end for

    ' 3: anything that looks like the corner squares, in a row or a column.
    for r = 0 to size - 1
        p = p + qrFinderScore(mat[r], size)
    end for
    col = []
    for i = 0 to size - 1
        col.push(0)
    end for
    for c = 0 to size - 1
        for r = 0 to size - 1
            col[r] = mat[r][c]
        end for
        p = p + qrFinderScore(col, size)
    end for

    ' 4: how far off half-and-half the dark modules are.
    dark = 0
    for r = 0 to size - 1
        for c = 0 to size - 1
            dark = dark + mat[r][c]
        end for
    end for
    p = p + 10 * Int(Abs(dark * 100 / (size * size) - 50) / 5)

    return p
end function

' The dark-light-dark-dark-dark-light-dark run counts 40 every time it has
' four light modules on one side of it. Running off the end of the symbol
' counts as light, because the quiet zone around a code is.
function qrFinderScore(seq as object, size as integer) as integer
    score = 0
    idx = qrFindRun(seq, size, 0)
    while idx >= 0
        nextAt = idx + 7
        if qrAllLight(seq, size, idx - 4, idx) or qrAllLight(seq, size, idx + 7, idx + 11)
            score = score + 40
        else
            ' No light beside it, so this isn't a hit — but the run's own
            ' three dark modules can start the next one.
            nextAt = idx + 4
        end if
        idx = qrFindRun(seq, size, nextAt)
    end while
    return score
end function

function qrFindRun(seq as object, size as integer, start as integer) as integer
    pat = [1, 0, 1, 1, 1, 0, 1]
    at = start
    while at <= size - 7
        hit = true
        for i = 0 to 6
            if seq[at + i] <> pat[i] then hit = false
        end for
        if hit then return at
        at = at + 1
    end while
    return -1
end function

function qrAllLight(seq as object, size as integer, lo as integer, hi as integer) as boolean
    a = lo
    if a < 0 then a = 0
    b = hi
    if b > size then b = size
    for i = a to b - 1
        if seq[i] = 1 then return false
    end for
    return true
end function
