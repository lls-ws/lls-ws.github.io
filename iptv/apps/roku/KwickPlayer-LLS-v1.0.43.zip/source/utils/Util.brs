' Shared helpers. Xtream servers return sloppy JSON (numbers as strings,
' nulls where lists belong) — same tolerant coercion the Android app uses
' in lib/core/models/xtream_models.dart.

' NOTE: boxed values out of ParseJson report type "roInt" / "roFloat" /
' "roString" — NOT "roInteger". Missing "roInt" made every numeric
' stream_id convert to "" (played /live/user/pass/.m3u8 on device).
function ToStr(v as dynamic) as string
    if v = invalid then return ""
    vt = type(v)
    if vt = "roString" or vt = "String" then return v
    if vt = "roInt" or vt = "roInteger" or vt = "Integer" or vt = "LongInteger" or vt = "roLongInteger" then return v.toStr()
    if vt = "roFloat" or vt = "Float" or vt = "Double" or vt = "roDouble" then return Str(v).trim()
    if vt = "roBoolean" or vt = "Boolean"
        if v then return "true"
        return "false"
    end if
    return ""
end function

function ToInt(v as dynamic) as integer
    if v = invalid then return 0
    vt = type(v)
    if vt = "roInt" or vt = "roInteger" or vt = "Integer" or vt = "LongInteger" or vt = "roLongInteger" then return v
    if vt = "roFloat" or vt = "Float" or vt = "Double" or vt = "roDouble" then return Int(v)
    if vt = "roString" or vt = "String"
        if v = "" then return 0
        ' Val() yields a float, which has no .toInt() member — Int() +
        ' the declared integer return type does the conversion safely.
        return Int(Val(v))
    end if
    return 0
end function

' Safe member access on possibly-invalid associative arrays.
function GetField(obj as dynamic, key as string) as dynamic
    if obj = invalid then return invalid
    if type(obj) <> "roAssociativeArray" then return invalid
    return obj[key]
end function

' A playlist can live on a USB drive instead of behind a web address, so the
' one stored field holds either. Roku mounts drives as ext1: .. ext9:; a web
' address always carries a scheme, so anything without one is a path.
function IsLocalPath(s as string) as boolean
    t = LCase(s.trim())
    if t = "" then return false
    if t.instr(0, "://") > -1 then return false
    return t.left(3) = "ext"
end function

' The filename at the end of a path — "ext1:/tv/uk.m3u" -> "uk.m3u".
' Paths with no filename come back whole.
function FileTail(s as string) as string
    slash = -1
    for i = 0 to s.len() - 1
        if s.mid(i, 1) = "/" then slash = i
    end for
    if slash < 0 or slash = s.len() - 1 then return s
    return s.mid(slash + 1)
end function

' A source name cut down to fit the little corner tag on a channel tile or
' poster. Full names are as long as the member typed them — a USB playlist
' comes out "USB: crackerjack.m3u", which on a 284px tile is wider than the
' artwork and reads as the loudest thing on screen. The tag only has to say
' WHICH source, and the first few characters do that.
function ShortSrcLabel(s as string) as string
    t = s.trim()
    if Len(t) <= 14 then return t
    return Left(t, 13) + Chr(8230)   ' … (single glyph, not three dots)
end function

' What to show a member instead of a full path like "ext1:/tv/uk.m3u".
function LocalPathLabel(s as string) as string
    tail = FileTail(s)
    if tail = s then return s
    return "USB: " + tail
end function

' ---- Matching a custom EPG to a provider's channels -------------------------
'
' An XMLTV guide joins to channels by tvg-id, and when both sides come from
' the same stable those ids line up. Guides people actually upload often
' don't: a US over-the-air guide keys channels by numeric station id
' (28055) while a provider keys the same station cbs4wbzboston.us. Nothing
' matches and the guide looks broken.
'
' What DOES survive both sides is the station callsign — the guide calls it
' WBZDT, the provider calls the channel "MA | Boston | CBS 4 WBZ". So when
' ids fail, fall back to the callsign and to the channel name itself.

' Uppercase, letters and digits only. "MA | Boston | CBS 4 WBZ" -> "MABOSTONCBS4WBZ".
function EpgNormName(s as string) as string
    up = UCase(s)
    out = ""
    for i = 0 to up.len() - 1
        c = up.mid(i, 1)
        if (c >= "A" and c <= "Z") or (c >= "0" and c <= "9") then out = out + c
    end for
    return out
end function

' The station callsign inside a guide's display-name, or "" if it isn't one.
' US/Canadian callsigns start with W, K, C or X and run 3-4 more letters;
' broadcasters then bolt on the transmission suffix and a subchannel digit
' (WBZDT, WBZDT2, WGBHHD), none of which the provider's name will carry.
function EpgCallsign(s as string) as string
    t = EpgNormName(s)
    ' Drop a trailing subchannel digit or two.
    while t.len() > 0 and t.right(1) >= "0" and t.right(1) <= "9"
        t = t.left(t.len() - 1)
    end while
    for each suffix in ["DT", "HD", "TV", "SD"]
        if t.len() > 4 and t.right(2) = suffix then t = t.left(t.len() - 2)
    end for
    if t.len() < 3 or t.len() > 5 then return ""
    head = t.left(1)
    if head <> "W" and head <> "K" and head <> "C" and head <> "X" then return ""
    for i = 0 to t.len() - 1
        c = t.mid(i, 1)
        if c < "A" or c > "Z" then return ""   ' letters only
    end for
    return t
end function

' Splits a provider channel name into the words worth testing as callsigns.
function EpgNameTokens(s as string) as object
    up = UCase(s)
    out = []
    cur = ""
    for i = 0 to up.len() - 1
        c = up.mid(i, 1)
        if (c >= "A" and c <= "Z") or (c >= "0" and c <= "9")
            cur = cur + c
        else
            if cur <> "" then out.push(cur)
            cur = ""
        end if
    end for
    if cur <> "" then out.push(cur)
    return out
end function

' Which guide channel is this provider channel, using the alias index the
' guide was read into? Returns "" when there's no confident answer —
' ambiguity is left unmatched on purpose, because showing one station's
' programmes against another's is worse than showing none.
function EpgAliasLookup(aliases as object, channelName as string) as string
    if aliases = invalid or channelName = "" then return ""
    hit = ""
    ' Whole name first: an exact match is the strongest signal there is.
    full = EpgNormName(channelName)
    if full <> "" and aliases.doesExist(full) then return ToStr(aliases[full])
    for each tok in EpgNameTokens(channelName)
        cs = EpgCallsign(tok)
        if cs <> "" and aliases.doesExist(cs)
            g = ToStr(aliases[cs])
            if hit <> "" and hit <> g then return ""   ' two different stations
            hit = g
        end if
    end for
    return hit
end function

' Ensures we always iterate a list, even when the API returns junk.
function ToArray(v as dynamic) as object
    if v = invalid then return []
    if type(v) = "roArray" then return v
    return []
end function

' Pure-BrightScript percent-encoding. Deliberately NOT roUrlTransfer.escape:
' roUrlTransfer can't be created on the SceneGraph render thread, and URL
' building happens there (froze the sign-in button on device).
' `dynamic`, NOT `string`, AND THAT IS THE POINT. BrightScript raises the
' type mismatch at the CALL when a typed parameter is handed invalid, so a
' guard inside a `s as string` version can never run — the app is already
' halted. This encodes URLs, so its callers are field reads from providers,
' catalogues and API answers, and any one of those can be missing on a source
' the caller did not expect. On 2026-09-19 a media-server film reached
' XtreamVodUrl with no username and the app stopped dead on the Home screen
' (HomeScreen.resumeOrNext has the story and the real fix). A bad URL that
' fails and says so is recoverable; a halted app is not.
function UrlEncode(raw as dynamic) as string
    s = ToStr(raw)
    if s = "" then return ""
    unreserved = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.~"
    ba = CreateObject("roByteArray")
    ba.fromAsciiString(s)
    out = ""
    for i = 0 to ba.count() - 1
        b = ba[i]
        ch = Chr(b)
        if b < 128 and unreserved.instr(0, ch) > -1
            out = out + ch
        else
            hex = UCase(StrI(b, 16))
            if Len(hex) < 2 then hex = "0" + hex
            out = out + "%" + hex
        end if
    end for
    return out
end function

' Xtream endpoint builders — port of the Android XtreamClient URL logic.
'
' EVERY FIELD GOES THROUGH ToStr FIRST, and that is not defensive habit — it is
' a fix. UrlEncode declares `s as string`, so handing it a missing field throws
' "Type Mismatch. Unable to cast Invalid to String" and takes the whole app
' down, with the member seeing a crash-to-Home and a report that names
' Util.brs rather than whatever built the bad record. Reproduced exactly that
' way on 2026-09-12 by putting a Jellyfin (which has no username or password)
' through this function.
'
' A provider record can be short of a field for ordinary reasons: a source
' restored from the link service before it was fully written, a hand-made M3U
' row, an older record from before a field existed. None of those should be
' fatal — a request built with an empty username fails as a request, which the
' caller already knows how to report.
function XtreamApiUrl(p as object, action as string) as string
    url = ToStr(p.server) + "/player_api.php?username=" + UrlEncode(ToStr(p.username)) + "&password=" + UrlEncode(ToStr(p.password))
    if action <> "" then url = url + "&action=" + action
    return url
end function

' Live streams use HLS on Roku (raw continuous .ts is not supported by the
' Video node) — the closest match to the Android player's live behavior.
' A live stream id on the panel is a bare number ("1038"). But a channel row
' can reach us carrying its whole source-qualified id — "xt:kwick.cc:1038" —
' from KwickSync (the phone's live media id is exactly that colon form) or a
' deep link. Playing it verbatim builds .../live/user/pass/xt:kwick.cc:1038.m3u8,
' which the panel rejects, so EVERY synced channel "won't play". Take the
' trailing segment after the last colon; a bare numeric id is returned
' unchanged, so this is safe for ids that were already correct.
function BareStreamId(streamId as string) as string
    id = streamId
    last = 0
    for i = 1 to Len(id)
        if Mid(id, i, 1) = ":" then last = i
    end for
    if last > 0 and last < Len(id) then id = Mid(id, last + 1)
    return id
end function

' THE PANEL ADDRESS, or "" when this source hasn't got one.
'
' All three builders below used to open with `p.server + "..."`, and that is
' not a bad URL — it is a HALT. A source that is not an Xtream panel has no
' `server` field at all, and `Invalid + "/live/"` stops the whole app. It is
' the same lesson UrlEncode learned above, one operator further left: the
' fields were made safe and the thing they were glued onto was not.
'
' LOG KEY FCF117 — Hisense 6Series-58, v1.0.39, 29 September 2026. What
' happened on the member's television, in plain words: they took their source
' out in Settings, one came back from the website on its own three seconds
' later, and half a minute after that the first channel they pressed Play on
' froze the TV with the spinner still turning and nothing on screen to say
' why. The channel they pressed was left over from the source they had just
' removed, so the app had nothing to match it against and fell back to the
' one that had just arrived — a plain playlist, which has no panel address to
' build a stream from. Nothing was written wrong; the wrong KIND of source
' was handed to a panel-only builder.
'
' The parameters are `dynamic` for exactly the reason UrlEncode's is: a typed
' parameter raises the mismatch AT THE CALL, so a guard written inside a
' `streamId as string` version could never run. Several callers hand these
' straight out of a channel or episode row without converting them first.
'
' An empty answer means "no address could be built here". Callers already
' treat "" that way; the ones that pass it on unchecked are named in the
' FCF117 report and are not this file's to change.
function XtreamBase(p as dynamic) as string
    if p = invalid then return ""
    return ToStr(p.server)
end function

function XtreamLiveUrl(p as dynamic, streamId as dynamic) as string
    srv = XtreamBase(p)
    if srv = "" then return ""
    return srv + "/live/" + UrlEncode(p.username) + "/" + UrlEncode(p.password) + "/" + BareStreamId(ToStr(streamId)) + ".m3u8"
end function

function XtreamVodUrl(p as dynamic, streamId as dynamic, ext as dynamic) as string
    srv = XtreamBase(p)
    if srv = "" then return ""
    suffix = ToStr(ext)
    if suffix = "" then suffix = "mp4"
    return srv + "/movie/" + UrlEncode(p.username) + "/" + UrlEncode(p.password) + "/" + ToStr(streamId) + "." + suffix
end function

function XtreamSeriesEpisodeUrl(p as dynamic, episodeId as dynamic, ext as dynamic) as string
    srv = XtreamBase(p)
    if srv = "" then return ""
    suffix = ToStr(ext)
    if suffix = "" then suffix = "mp4"
    return srv + "/series/" + UrlEncode(p.username) + "/" + UrlEncode(p.password) + "/" + ToStr(episodeId) + "." + suffix
end function

' Roku streamformat from a URL/container hint.
function StreamFormatFor(url as string, ext as string) as string
    lower = LCase(url)
    if lower.instr(0, ".m3u8") > -1 then return "hls"
    if ext = "mkv" then return "mkv"
    if lower.instr(0, ".mkv") > -1 then return "mkv"
    return "mp4"
end function

' A playlist's live-channel address rewritten to something Roku can play.
' Xtream-made playlists hand out raw MPEG-TS urls — "/live/u/p/3606.ts" or
' extension-less "/live/u/p/3606" — and the Video node has no TS demuxer
' (crak3rjack's TCL, log 39B22F: every channel died with HTTP/malformed
' errors while the same playlist played in an ExoPlayer app). Every such
' panel serves the SAME stream as HLS at "<id>.m3u8", so ask for that.
' A url that already names .m3u8 (or any non-Xtream shape) passes through;
' a raw-TS url with no HLS twin was never playable here anyway.
function LivePlayUrl(url as string) as string
    u = url.trim()
    if u = "" or Instr(1, u, "?") > 0 then return url
    lower = LCase(u)
    if lower.right(3) = ".ts" then return u.left(u.len() - 3) + ".m3u8"
    if lower.instr(0, ".m3u8") > -1 then return url
    ' Extension-less Xtream shape: the last path segment is all digits.
    slash = 0
    for i = 1 to Len(u)
        if Mid(u, i, 1) = "/" then slash = i
    end for
    if slash > 8 and slash < Len(u)   ' past "http://x", not a trailing slash
        tail = Mid(u, slash + 1)
        allDigits = (tail <> "")
        for i = 1 to Len(tail)
            c = Mid(tail, i, 1)
            if c < "0" or c > "9" then allDigits = false
        end for
        if allDigits then return u + ".m3u8"
    end if
    return url
end function

' Named KLog because plain "Log" collides with BrightScript's built-in
' math function.
' Xtream sends EPG titles/descriptions base64-encoded.
function B64Decode(s as string) as string
    if s = "" then return ""
    ba = CreateObject("roByteArray")
    ba.fromBase64String(s)
    out = ba.toAsciiString()
    if out = invalid then return ""
    return out
end function

' Strip member credentials out of a log line. Xtream stream URLs embed the
' login in the PATH — .../live/<user>/<pass>/12345.m3u8 — and the panel API
' puts it in the QUERY (?username=&password=). The player quotes the whole
' failing URL in its error text, so this must happen at the single point
' every log line passes through (below): no call site can be trusted to
' remember, and the log uploads to the support server.
function ScrubSecrets(msg as string) as string
    out = msg
    ' MOST LOG LINES HAVE NO ADDRESS IN THEM AT ALL, and this runs on every
    ' single one — KLog on the way in, and the whole 30KB crash tail again on
    ' the way out. A substring search is far cheaper than building a regex
    ' object, so each rule below is only built when the line could possibly
    ' need it, and each test is something that rule's pattern genuinely
    ' cannot match without.
    '
    ' Measured over the 62,926 lines of member log we hold: 13.0% contain a
    ' slash, 2.9% contain "://" and 0.3% contain a "?" or an "&". So this
    ' builds about 0.16 regex objects per line where the old version built
    ' four, every time, whatever the line said.
    hasPath = (Instr(1, out, "/") > 0)
    hasUrl = (Instr(1, out, "://") > 0)
    hasQuery = (Instr(1, out, "?") > 0 or Instr(1, out, "&") > 0)
    if not hasPath and not hasQuery then return out

    ' PATH FORM, PANEL THAT NAMES THE SECTION: keep the section so the log
    ' still says what failed. One regex with the three words inside it, where
    ' this used to build a separate object per word.
    if hasPath
        rx = CreateObject("roRegex", "/(live|movie|series)/[^/?\s]+/[^/?\s]+/", "i")
        out = rx.replaceAll(out, "/\1/***/***/")
    end if

    ' PATH FORM, PANEL THAT NAMES NO SECTION — THE HOLE THIS CLOSES.
    '
    ' Plenty of Xtream panels serve http://host/<user>/<pass>/<id>.<ext> with
    ' no "live", "movie" or "series" in the address anywhere, and the rule
    ' above walks straight past those. Real member logins were sitting in
    ' clear text in seven of the logs we hold because of it — 15 lines, six
    ' different accounts, key 1BA32F among them.
    '
    ' WHAT MAKES IT A CREDENTIAL AND NOT AN ORDINARY ADDRESS IS THE SHAPE:
    ' straight after the host come exactly two path parts, and then a part
    ' that is all digits and ENDS the path, with or without a file extension.
    ' That is the same test LivePlayUrl() above already uses to recognise an
    ' extension-less Xtream address, and it is tight enough to leave
    ' everything else alone. Checked against all 62,926 lines of the member
    ' logs we hold: it redacts the 15 that really did carry a login and
    ' changes nothing else.
    '
    ' ANCHORING TO "://" IS WHAT MAKES IT SAFE. It means the two parts have to
    ' sit immediately after the host, the way a panel writes them — which is
    ' what keeps a media server's /Items/<id>/Images/Backdrop/0 and a poster's
    ' /t/p/w500/<file>.jpg out of it. Insisting the digits end the path is
    ' what keeps /hls/live/1234/index.m3u8 out of it.
    '
    ' An address the rule above already handled cannot match here, because
    ' "***" is not digits.
    if hasUrl
        rx = CreateObject("roRegex", "(://[^/?\s]+)/[^/?\s]+/[^/?\s]+/([0-9]+(?:\.[A-Za-z0-9]+)?)([?#\s""']|$)", "i")
        out = rx.replaceAll(out, "\1/***/***/\2\3")
    end if

    ' Query form, long AND short names: third-party M3U sources use ?u=&p=
    ' (a real member log leaked a password hash that way past a filter that
    ' only knew the long names). Anchored to ? or & so ordinary log text
    ' like "cleanup=done" is left alone. Longest names first — alternation
    ' is leftmost-wins, so "user" must not shadow "username". The pattern
    ' starts on a ? or an &, which is why the guard above tests for those.
    if hasQuery
        rx = CreateObject("roRegex", "([?&])(username|password|passwd|pass|user|token|auth|key|u|p)=[^&\s""']*", "i")
        out = rx.replaceAll(out, "\1\2=***")
    end if
    return out
end function

' ---- Why playback failed -----------------------------------------------------
' Roku reports the reason in Video.errorMsg. Most of those are transient — a
' hiccup, a dropped connection, a 5xx from the panel — and retrying is
' exactly right. A codec failure is NOT: the stream's audio or video is in a
' format this Roku has no decoder for, and it will fail identically every
' single time.
'
' Retrying those was worse than useless. A member on a Roku Express 4K hit
' "unsupported audio format" on three channels back to back (key 142055);
' each one burned four connection attempts over ~20 seconds and then said
' "Couldn't play this stream", which reads as a broken channel or a broken
' account. It is neither. Worse, four rapid connections against a
' max-connections-1 account is the exact pattern a provider's anti-share
' system bans for — the owner's own IP was banned this way.
'
' "audio" is by far the most common: European and many IPTV feeds carry MP2
' audio, which Roku has never decoded.
function StreamErrorKind(msg as string) as string
    t = LCase(msg)
    if Instr(1, t, "unsupported audio") > 0 then return "audio"
    if Instr(1, t, "unsupported video") > 0 then return "video"
    if Instr(1, t, "drm") > 0 then return "drm"
    if Instr(1, t, "license") > 0 then return "drm"
    if Instr(1, t, "unsupported") > 0 then return "format"
    ' "malformed data" is Roku's report for BOTH a real codec/container it has
    ' no decoder for AND the odd non-media response a busy panel sometimes
    ' returns. It is the wording Roku gives for AAC Main audio, which this
    ' hardware cannot decode though phones can (key 1599CA, USA CNN 1041: the
    ' stream is h264 High + AAC MAIN; the channels that play are AAC LC). The
    ' caller retries it ONCE for the transient case, then treats a repeat as
    ' the decoder and stops — see onVideoState.
    if Instr(1, t, "malformed") > 0 then return "malformed"
    return "retry"
end function

' What the member reads. Says plainly that neither the channel nor their
' account is at fault, because the old wording implied both.
function StreamErrorText(kind as string) as string
    if kind = "audio"
        return "This channel's sound is in a format this Roku can't play. The channel isn't broken and there's nothing wrong with your account — it's how this provider sends it. If they list the same channel more than once, another copy may work."
    end if
    if kind = "video"
        return "This channel's picture is in a format this Roku can't play. The channel isn't broken and there's nothing wrong with your account — it's how this provider sends it. If they list the same channel more than once, another copy may work."
    end if
    if kind = "drm"
        return "This stream is copy-protected in a way this app can't open."
    end if
    if kind = "format"
        return "This Roku can't play this stream's format. If your provider lists the same channel more than once, another copy may work."
    end if
    if kind = "malformed"
        return "This channel wouldn't play on this Roku. Its audio or video is likely in a format Roku can't decode — some channels use audio (AAC Main) that plays on phones but not on Roku hardware. The channel and your account are fine; the same channel may still play in the phone app. If your provider lists it more than once, another copy may work."
    end if
    return "Couldn't play this stream."
end function

' A dead stream, a flaky router or a third-party source that stopped
' answering is NOT a crash. Filing those would bury real bugs under noise
' from one member with a bad playlist (Android learned this the hard way).
' They still get logged — they're exactly what you want when diagnosing a
' stream — they just never become a crash report.
function IsNetworkErrorText(text as string) as boolean
    t = LCase(text)
    for each needle in ["timeout", "timed out", "socket", "connection reset", "connection refused", "connection closed", "econnreset", "dns", "could not resolve", "unreachable", "network", "ssl", "tls", "certificate", "http error", "no response", "curl"]
        if Instr(1, t, needle) > 0 then return true
    end for
    return false
end function

' The ONE place a crash report gets armed for the next launch. Every
' caller goes through here so the network filter can't be forgotten.
' ---- Guarded entry points ---------------------------------------------------
'
' A BrightScript fault on the render thread kills the app, and the report that
' goes up on the next launch carries no stack - only the last log lines. So
' the screens that keep dying without a word (the TV Guide, the channel page)
' run their event handlers under try/catch, and a fault comes HERE: one log
' line naming the file, the line and the function, and the same next-launch
' report the sync cycle arms for a caught fault, so the culprit is finally
' named instead of guessed at. The member keeps the app; the screen is left
' as it was a moment before.
function CrashLine(e as object) as string
    msg = ToStr(GetField(e, "message"))
    bt = GetField(e, "backtrace")
    where = ""
    if bt <> invalid and type(bt) = "roArray" and bt.count() > 0
        top = bt[bt.count() - 1]
        where = " @ " + ToStr(GetField(top, "filename")) + ":" + ToStr(GetField(top, "line_number")) + " " + ToStr(GetField(top, "function"))
    end if
    return msg + where
end function

sub GuardFailed(who as string, e as object)
    line = CrashLine(e)
    KLog("crash", "crash averted in " + who + ": " + line)
    ArmCrashReport("CAUGHT " + who + ": " + line)
end sub

' A REPORT ALREADY WAITING IS NEVER REPLACED. This is the v1.0.41 fix, and it
' is the whole reason the guards above are worth anything.
'
' WHAT THE BUG COST, IN PLAIN WORDS: v1.0.41 wrapped 41 handlers so that a
' fault which used to kill the app instead leaves the member's screen alone
' and writes down the exact file and line that went wrong. That note waits in
' the registry and is sent in on the next launch. But the note was being
' thrown away before anyone could read it. The member carried on using the app
' - which is the entire point of catching the fault - the session was later
' killed for memory, and the next launch wrote the plain "ran out of memory"
' code straight over the top of the note. In the 2026-10-12 log sweep 21 of 29
' reports were memory kills, so on exactly the boxes this mechanism was built
' for, the useful half of every report was being deleted. It also means that
' sweep's "no crash averted lines anywhere" is weaker evidence than it looks:
' some were armed and then overwritten.
'
' NOTHING IS LOST BY PREFERRING THE NOTE. main.brs:15 already writes the OS's
' own exit code to its OWN key, last_exit_reason, on every launch, with no
' condition on it - and AppScene reads that key too. The exit code survives
' either way. The file and line did not.
'
' TWO CAUGHT FAULTS IN ONE SESSION: THE FIRST IS KEPT. A fault usually causes
' the ones after it (one bad list is built once, then every handler that
' touches it trips over it), so the first is the one worth naming. The later
' ones are not lost - every caught fault prints its own "crash averted" line
' into the session log, and that log is what gets sent alongside the report.
' Keeping the first also means at most ONE registry write per session on this
' path instead of one per fault, which matters because the whole registry is
' only 16-32 KB and a write past that fails silently.
'
' NOTHING CAN GET STUCK HERE. AppScene.brs:129 deletes crash_pending on every
' launch that reaches its init, BEFORE it even tries to send it, so a note
' armed in one session is spent on the very next one whether the upload works
' or not. This check only ever SKIPS a write; it never adds one and never
' keeps one alive.
' THE "CAUGHT " PREFIX IS LOAD-BEARING. Three places arm a caught fault and
' all three stamp it: GuardFailed just above, M3uTask.brs:26 and
' SyncTask.brs:704. It is what tells a BrightScript fault with a file and a
' line apart from a bare OS exit code, and the network filter below turns on
' it. A fourth catch site that forgets the stamp still files - it just gets
' the network filter applied to it, which is the old behaviour, not a crash.
sub ArmCrashReport(reason as string)
    if reason = "" then return
    caught = (Left(reason, 7) = "CAUGHT ")
    ' THE NETWORK FILTER IS FOR BARE OS REASONS ONLY, AND THAT IS THE CHANGE.
    '
    ' The filter exists so a dead stream, a flaky router or a provider that
    ' stopped answering is never filed as a crash - one member with a bad
    ' playlist would otherwise bury every real bug. That reasoning is about
    ' network BLIPS and it still holds, untouched, for the OS exit codes it
    ' was written for.
    '
    ' A caught fault is not a blip. It is a BrightScript fault that already
    ' named its file, its line and its function, and it is the single most
    ' valuable thing this whole mechanism produces. But the filter matches
    ' "network", "timeout", "ssl", "dns" and "http error" ANYWHERE in the
    ' string - so a Type Mismatch inside an XMLTV or playlist helper whose
    ' message merely mentioned one of those words was silently dropped and
    ' never filed. The guards most likely to fault are the ones in the
    ' networking paths, so the filter was aimed straight at the reports worth
    ' having.
    '
    ' Two separate tests rather than one `and`: BrightScript evaluates BOTH
    ' sides of an `and`, so a combined guard reads as if it short-circuits
    ' when it does not. This way each branch says exactly what it decides.
    netNoise = IsNetworkErrorText(reason)
    if netNoise and not caught
        KLog("app", "network error - logged, not filed as a crash")
        return
    end if
    if netNoise and caught
        ' Said out loud, because this report only exists because of the
        ' exemption above and that is worth knowing when reading it back.
        KLog("crash", "caught fault mentions a network word - filing it anyway, it has a file and a line")
    end if
    pending = RegRead("crash_pending")
    if pending <> ""
        KLog("app", "crash report already armed (" + pending + ") - kept; NOT replaced by: " + reason)
        return
    end if
    ' Scrubbed on the way IN, not just on the way out. A fault message can
    ' carry the URL that caused it, and a provider URL carries the member's
    ' username and password in its query string. Everything else in the crash
    ' report is scrubbed (KLog on the way in, the log tail again on the way
    ' out) but this one string went into the registry raw and was pasted
    ' straight into the report header. The registry is the one place a leak
    ' would follow the member around until they reinstall.
    RegWrite("crash_pending", ScrubSecrets(reason))
end sub

sub KLog(tag as string, msg as string)
    msg = ScrubSecrets(msg)
    print "[KwickPlayer:" + tag + "] " + msg
    ' Mirror into the session log buffer for Export Logs. Best-effort: the
    ' global node exists after AppScene init; a lost line under races is
    ' fine for diagnostics. Kept to the newest ~200KB.
    if m.global <> invalid and m.global.hasField("diagLog")
        ' Flood suppression (Android parity): the same line repeating back-
        ' to-back is buffered 3 times, then dropped until it changes, with
        ' one "(N repeated lines suppressed)" marker. Console still prints
        ' every line. Best-effort across threads, like the buffer itself.
        line = "[" + tag + "] " + msg
        if m.global.hasField("diagRepLine") and m.global.diagRepLine = line
            n = m.global.diagRepN + 1
            m.global.diagRepN = n
            if n > 3 then return
        else
            if m.global.hasField("diagRepLine")
                lastN = m.global.diagRepN
                if lastN > 3
                    m.global.diagLog = m.global.diagLog + "(... " + (lastN - 3).toStr() + " repeated lines suppressed)" + Chr(10)
                end if
                m.global.diagRepLine = line
                m.global.diagRepN = 1
            end if
        end if
        dt = CreateObject("roDateTime")
        entry = dt.toISOString() + " " + line + Chr(10)
        buf = m.global.diagLog + entry
        if buf.len() > 200000 then buf = buf.right(160000)
        m.global.diagLog = buf
    end if
end sub

' App version from the manifest — "1.0.8".
function KwickAppVersion() as string
    ai = CreateObject("roAppInfo")
    return ai.getValue("major_version") + "." + ai.getValue("minor_version") + "." + ai.getValue("build_version")
end function

' How this app identifies itself on the wire — "Kwick Player Roku/1.0.43
' (Roku 15.3)" as of this build. A provider's panel lists its active
' connections by this string, so ours can be told apart from other clients
' the way TiviMate is. (The example above is illustrative only — the real
' value is built from the manifest below, so the app itself is never wrong.)
'
' THE ONLY PLACE THIS STRING IS BUILT. Every request — data AND video —
' must use it, so a new release identifies itself correctly without anyone
' remembering to update a literal. The version is read from the manifest at
' runtime for the same reason; never hardcode it here.
' What the member left in a StandardKeyboardDialog, typed or spoken. The
' dialog's own `text` is the documented place to read it; the text box is
' consulted only when that is empty, because dictation lands in the box first.
' Trimmed, so every caller can compare against "" for "cancelled or blank".
'
' Every keyboard in the app goes through StandardKeyboardDialog now. Roku's
' static analysis (2026-09-03, findings 11-15, certification 4.12) flagged the
' five remaining KeyboardDialog uses: that one has no voice entry, and 4.12
' requires the voice keyboard wherever a member types.
function StdKeyboardText(kb as object) as string
    if kb = invalid then return ""
    t = ToStr(kb.text)
    if t = "" and kb.textEditBox <> invalid then t = ToStr(kb.textEditBox.text)
    return t.trim()
end function

function KwickUserAgent() as string
    os = CreateObject("roDeviceInfo").getOSVersion()
    return "Kwick Player Roku/" + KwickAppVersion() + " (Roku " + ToStr(os.major) + "." + ToStr(os.minor) + ")"
end function

' The username log uploads file under: the KwickTV/Xtream login name;
' M3U-only setups send "roku".
function LogUsername() as string
    p = ActiveProvider()
    if p <> invalid and ToStr(p.username) <> "" then return ToStr(p.username)
    return "roku"
end function

' Device identity for log uploads — brand + display name + model code,
' e.g. "onn 4K Roku TV panel (7000X)". The dashboard maps the code to the
' device kind.
function LogDeviceString() as string
    di = CreateObject("roDeviceInfo")
    device = di.getModelDisplayName()
    details = di.getModelDetails()
    if details <> invalid and details.vendorName <> invalid
        vendor = ToStr(details.vendorName)
        if vendor <> ""
            if device = ""
                device = vendor
            else if Instr(1, LCase(device), LCase(vendor)) = 0
                device = vendor + " " + device
            end if
        end if
    end if
    if device = "" then device = "Roku"
    return device + " (" + di.getModel() + ")"
end function

' Host of a URL (no scheme, no port, no path) — matches Android's
' Uri.parse(source).host, used to build cross-device channel ids
' "xt:<host>:<streamId>".
function HostOf(url as string) as string
    s = url
    p = Instr(1, s, "://")
    if p > 0 then s = Mid(s, p + 3)
    p = Instr(1, s, "/")
    if p > 0 then s = Left(s, p - 1)
    p = Instr(1, s, ":")
    if p > 0 then s = Left(s, p - 1)
    return s
end function

' ---- Subtitle language names ------------------------------------------------
' VOD subtitle tracks arrive as bare ISO codes ("spa", "fre", "und") — show
' human names instead. Unknown codes pass through as-is.
function LangName(code as string) as string
    c = LCase(code).trim()
    names = {
        eng: "English", en: "English", spa: "Spanish", es: "Spanish"
        fre: "French", fra: "French", fr: "French", ger: "German", deu: "German", de: "German"
        ita: "Italian", it: "Italian", por: "Portuguese", pt: "Portuguese"
        dut: "Dutch", nld: "Dutch", nl: "Dutch", nor: "Norwegian", no: "Norwegian"
        swe: "Swedish", sv: "Swedish", dan: "Danish", da: "Danish", fin: "Finnish", fi: "Finnish"
        pol: "Polish", pl: "Polish", rus: "Russian", ru: "Russian", ukr: "Ukrainian"
        rum: "Romanian", ron: "Romanian", ro: "Romanian", hun: "Hungarian", hu: "Hungarian"
        cze: "Czech", ces: "Czech", cs: "Czech", slo: "Slovak", slk: "Slovak", slv: "Slovenian"
        gre: "Greek", ell: "Greek", el: "Greek", tur: "Turkish", tr: "Turkish"
        ara: "Arabic", ar: "Arabic", heb: "Hebrew", he: "Hebrew"
        hin: "Hindi", hi: "Hindi", tha: "Thai", th: "Thai", vie: "Vietnamese", vi: "Vietnamese"
        chi: "Chinese", zho: "Chinese", zh: "Chinese", jpn: "Japanese", ja: "Japanese"
        kor: "Korean", ko: "Korean", ind: "Indonesian", may: "Malay", msa: "Malay"
        bul: "Bulgarian", hrv: "Croatian", srp: "Serbian", est: "Estonian"
        lav: "Latvian", lit: "Lithuanian", cat: "Catalan", glg: "Galician", baq: "Basque", eus: "Basque"
        per: "Persian", fas: "Persian", urd: "Urdu", ben: "Bengali", tam: "Tamil", tel: "Telugu"
        und: "Unknown"
    }
    if names.doesExist(c) then return names[c]
    return code
end function

' ---- Poster sizing ----------------------------------------------------------
' The panel's TMDB artwork comes as w600_and_h900 — 2.25MB of texture RAM
' per poster, which exhausts the Roku's ~90MB texture budget after a few
' screens of browsing (posters then silently stop rendering). Rewrite TMDB
' urls to a size that matches what we actually draw; anything non-TMDB
' passes through untouched.

' Grid/row tiles (~220px wide on screen).
function PosterUrl(url as string) as string
    return tmdbSized(url, "w342")
end function

' Detail-page art (360x540 on screen).
function DetailPosterUrl(url as string) as string
    return tmdbSized(url, "w500")
end function

function tmdbSized(url as string, size as string) as string
    if Instr(1, url, "image.tmdb.org") = 0 then return url
    marker = "/w600_and_h900_bestv2/"
    at = Instr(1, url, marker)
    if at = 0 then return url
    return url.left(at - 1) + "/" + size + "/" + url.mid(at + marker.len() - 1)
end function

' Profile PIN hash — MUST match the Android app byte-for-byte so a PIN set on
' one device unlocks the profile on another:
'   sha256("kwickpin|" + profileSyncId + "|" + pin)  (lowercase hex)
function ProfilePinHash(syncId as string, pin as string) as string
    digest = CreateObject("roEVPDigest")
    digest.setup("sha256")
    ba = CreateObject("roByteArray")
    ba.fromAsciiString("kwickpin|" + syncId + "|" + pin)
    return digest.process(ba)
end function
