' ---- Jellyfin and Emby ("media servers") -------------------------------------
'
' A member's OWN server, alongside their IPTV sources. Ported from the Flutter
' app (lib/core/api/media_server_client.dart + emby_family_client.dart), which
' treats the two as one family because every call below is byte-identical
' between them except the four differences listed at MsIsEmby().
'
' WHAT THIS IS NOT. There is no transcoding and no PlaybackInfo call. Pressing
' Play costs ZERO requests: the stream address is formatted from what the
' catalogue already told us. The Flutter side pins that with a test that fails
' any request made during playback, for the reason this house learned the hard
' way — a request per Play press is the traffic shape that got our address
' banned by a provider (2026-08-14). Do not add one here either.
'
' THE TOKEN NEVER GOES IN A URL. It rides as a header on catalogue calls and on
' the stream itself. Addresses get written into watch history and printed in
' the diagnostic log, and a token in one of those is a token in a member's
' support email. Artwork needs no auth at all, so poster addresses are plain.
'
' Verified against Mason's own servers on 2026-09-12:
'   Jellyfin 10.11.11 at jellyfin.kwickflix.tv — 8 libraries, 4,599 films
'   Emby      4.9.5.0 at emby.kwickflix.tv     — 8 libraries, 4,555 films

function MsIsMediaServer(p as dynamic) as boolean
    if p = invalid then return false
    t = LCase(ToStr(p.ptype))
    return t = "jellyfin" or t = "emby"
end function

' Emby differs from Jellyfin in exactly four places, all handled here:
'   1. libraries come from /Users/{id}/Views, not /UserViews (404 on Emby)
'   2. the stream address must NOT carry mediaSourceId (Emby's own id is
'      "mediasource_<itemId>", and passing the item id is a 400 on every title)
'   3. the stream carries X-Emby-Token as well as the MediaBrowser header
'   4. item ids are plain decimal ("722685"), not 32-hex GUIDs — nothing here
'      parses an id, so this one costs no code, but see the sync note below.
function MsIsEmby(p as dynamic) as boolean
    if p = invalid then return false
    return LCase(ToStr(p.ptype)) = "emby"
end function

' "Jellyfin" / "Emby", for anything a member reads.
function MsBrandLabel(p as dynamic) as string
    if MsIsEmby(p) then return "Emby"
    return "Jellyfin"
end function

' The base address with any trailing slash removed, so every builder below can
' concatenate without thinking about it. Emby servers published under /emby
' keep that in the stored address — whichever form answered at sign-in is what
' was saved, exactly as the Flutter app does it.
function MsBase(p as dynamic) as string
    b = ToStr(p.server)
    while Len(b) > 0 and Right(b, 1) = "/"
        b = Left(b, Len(b) - 1)
    end while
    return b
end function

' This television, named to the server. It appears in the member's own
' "Devices" list on their dashboard, so it has to be stable and recognisable —
' getChannelClientId survives a reinstall, which is what makes one Roku one
' device there rather than a new row every time the app is opened.
function MsDeviceId() as string
    di = CreateObject("roDeviceInfo")
    id = ToStr(di.getChannelClientId())
    if id = "" then id = "kwickplayer-roku"
    return id
end function

' The identity header, the ONE spelling both servers take.
'
' NOT X-Emby-Authorization. On Jellyfin that form is legacy, can be switched
' off in 10.11 and is slated for removal in 10.12; on Emby 4.9.5 this form was
' measured answering 200 on sign-in and on catalogue reads. One header, both
' servers, no branch. Token is appended only once there is one.
function MsAuthHeader(token as string) as string
    h = "MediaBrowser Client=" + Chr(34) + "Kwick Player" + Chr(34)
    h = h + ", Device=" + Chr(34) + "Kwick Player" + Chr(34)
    h = h + ", DeviceId=" + Chr(34) + MsDeviceId() + Chr(34)
    h = h + ", Version=" + Chr(34) + KwickAppVersion() + Chr(34)
    if token <> "" then h = h + ", Token=" + Chr(34) + token + Chr(34)
    return h
end function

' Headers for a CATALOGUE call, as the "Name: value" lines roUrlTransfer and
' the Video node both take.
function MsHeaders(p as dynamic) as object
    tok = ToStr(p.token)
    out = ["Authorization: " + MsAuthHeader(tok)]
    ' Emby documents X-Emby-Token and its own clients send it; harmless on a
    ' request that already carries the header above, and it is what an Emby
    ' behind a strict proxy actually looks for.
    if MsIsEmby(p) and tok <> "" then out.push("X-Emby-Token: " + tok)
    return out
end function

' ---- Addresses ---------------------------------------------------------------

function MsAuthUrl(base as string) as string
    return base + "/Users/AuthenticateByName"
end function

function MsPublicInfoUrl(base as string) as string
    return base + "/System/Info/Public"
end function

' The member's libraries. Jellyfin answers /UserViews; Emby 404s that and wants
' /Users/{id}/Views.
function MsViewsUrl(p as dynamic) as string
    uid = ToStr(p.userId)
    if MsIsEmby(p) then return MsBase(p) + "/Users/" + uid + "/Views"
    return MsBase(p) + "/UserViews?userId=" + UrlEncode(uid)
end function

' One page of a library. kind is "Movie" or "Series" — never both at once, so a
' mixed library is walked twice and each pass knows what it is looking at.
'
' enableImageTypes MUST name Backdrop explicitly or BackdropImageTags comes back
' empty on both servers, which is indistinguishable from a library where nothing
' has a backdrop.
' Every genre the member's films are filed under, in name order.
'
' WHY FILMS ARE BROWSED BY GENRE AND SHOWS BY LIBRARY. A member keeps their
' shows in libraries that already read as categories — Anime, Classic TV,
' Kids TV, Reality TV — and browsing those by name is exactly how they think
' about them. Their films are almost always ONE library called Movies, so a
' category strip built from libraries offers them a single button reading
' "Movies" in front of four and a half thousand titles, which is no browsing
' at all. Their genres are the shelves that library actually has.
'
' ONE request per server per visit, the same as the library read beside it,
' and the same list both servers answer with: 22 genres on the owner's
' Jellyfin, 19 on his Emby, plain names in both.
function MsGenresUrl(p as dynamic, kind as string) as string
    u = MsBase(p) + "/Genres?userId=" + UrlEncode(ToStr(p.userId))
    u = u + "&recursive=true&includeItemTypes=" + kind
    u = u + "&sortBy=SortName"
    return u
end function

' The films of ONE genre, across every library on the server.
'
' Filtered by the genre's NAME and never by its id. Measured on both servers:
' `genres=Action` answers 1,287 films on each, while `genreIds=` answered
' nothing at all — and a name is the same string on every server a member
' owns, where an id is not.
' `libraryId` narrows the sweep to ONE library, and exists for certification
' 6.3: a genre is server-wide, so on a box where a library has been dropped as
' Adult (or hidden or locked by the member) a plain sweep would surface its
' films under "Action". The screen passes a library only when it has to —
' when at least one of the server's film libraries is being kept out — so the
' ordinary member with one Movies library still pays one request per genre.
function MsGenreItemsUrl(p as dynamic, genre as string, kind as string, startIndex as integer, limit as integer, libraryId = "" as string) as string
    u = MsBase(p) + "/Items?userId=" + UrlEncode(ToStr(p.userId))
    if libraryId <> "" then u = u + "&parentId=" + UrlEncode(libraryId)
    u = u + "&recursive=true&includeItemTypes=" + kind
    u = u + "&genres=" + UrlEncode(genre)
    u = u + "&startIndex=" + startIndex.toStr() + "&limit=" + limit.toStr()
    u = u + "&sortBy=SortName&fields=Overview,Genres,ProductionYear,DateCreated,Container,OfficialRating"
    u = u + "&enableImageTypes=Primary,Logo,Backdrop"
    return u
end function

function MsItemsUrl(p as dynamic, libraryId as string, kind as string, startIndex as integer, limit as integer) as string
    u = MsBase(p) + "/Items?userId=" + UrlEncode(ToStr(p.userId))
    if libraryId <> "" then u = u + "&parentId=" + UrlEncode(libraryId)
    u = u + "&recursive=true&includeItemTypes=" + kind
    u = u + "&startIndex=" + startIndex.toStr() + "&limit=" + limit.toStr()
    ' OfficialRating is the age certificate ("PG-13", "TV-MA"). It is NOT
    ' returned by default the way CommunityRating and the image tags are —
    ' leaving it off this list does not fail loudly, it just looks like a
    ' library where no title carries one. Measured against the owner's own
    ' Jellyfin: absent without it, "PG-13"/"TV-14" with it.
    u = u + "&sortBy=SortName&fields=Overview,Genres,ProductionYear,DateCreated,Container,OfficialRating"
    u = u + "&enableImageTypes=Primary,Logo,Backdrop"
    return u
end function

' Every episode of one show, in one request. There is deliberately no
' /Shows/{id}/Seasons call: the season number is already on each episode as
' ParentIndexNumber, and this is only ever asked for when a member opens the
' show — never during a library read, where 500 shows would be 500 requests.
' ONE title by id, with everything a detail page draws.
'
' The grid hands a whole mapped row to the detail page, so opening a film from
' Movies & Series costs NOTHING. This is for the other doors into that page —
' Continue Watching, Search, a favourite — which carry an id and a name and
' were never going to carry a synopsis. One request, on page open, only when
' the row did not come with one. Never per tile.
function MsItemUrl(p as dynamic, itemId as string) as string
    u = MsBase(p) + "/Items?userId=" + UrlEncode(ToStr(p.userId))
    u = u + "&ids=" + UrlEncode(itemId)
    ' People and MediaStreams on top of the library read's list: the cast line,
    ' the director and the Video / Audio / Bitrate rows of the information
    ' table. They are asked for HERE and never in the library read, because on
    ' a five-hundred-title page they would be most of the answer (a film
    ' carries twenty to forty people and three or four streams - about 10 KB
    ' per title, measured) and the grid draws none of it.
    u = u + "&fields=Overview,Genres,ProductionYear,DateCreated,Container,OfficialRating,People,MediaStreams,ProviderIds"
    u = u + "&enableImageTypes=Primary,Logo,Backdrop"
    return u
end function

' The TMDB id a media server already knows, out of `ProviderIds`.
'
' ASKED FOR HERE AND NEVER IN THE LIBRARY READ, for the same reason People and
' MediaStreams are: this is one title, the catalogue is five hundred, and this
' app has already killed members' boxes once by pulling an unmeasured answer
' into memory. It costs about forty bytes on a single-title answer.
'
' WHY IT IS NOT IN MsInfoMap: the note above that function is still right.
' The ratings strip labels a score "TMDB" only when an id proves where the
' number came from, and a media server's own score is not necessarily TMDB's.
' Feeding this id to the strip would make it print a confident label over a
' number it cannot vouch for. So the id travels beside that map, not inside
' it, and only the things that key on an id read it — the subtitle search,
' the scrobblers, the checkmarks.
'
' BOTH SPELLINGS. Jellyfin answers `Tmdb`; Emby has been seen with `TMDB` and
' with `tmdb` depending on which scraper filled it in, and BrightScript's
' associative arrays are case-insensitive on lookup but the JSON parser keeps
' whatever case arrived. Asking three ways costs nothing and saves a silent
' empty for half the Emby libraries out there.
function MsTmdbId(row as dynamic) as string
    ids = GetField(row, "ProviderIds")
    if ids = invalid then return ""
    for each k in ["Tmdb", "TMDB", "tmdb"]
        v = GetField(ids, k)
        if v <> invalid
            s = ToStr(v).trim()
            ' A non-numeric id is not a TMDB id. Better an empty answer than
            ' one that sends somebody else's film to a member's Trakt.
            if s <> "" and s = s.toInt().toStr() then return s
        end if
    end for
    return ""
end function

function MsEpisodesUrl(p as dynamic, seriesId as string) as string
    u = MsBase(p) + "/Shows/" + seriesId + "/Episodes?userId=" + UrlEncode(ToStr(p.userId))
    u = u + "&fields=Overview,Container&enableImageTypes=Primary"
    return u
end function

' Artwork. No token, on purpose: both servers serve /Items/{id}/Images to
' anyone who can reach them, and a poster address ends up in the catalogue and
' in watch history where a token must never be.
function MsImageUrl(p as dynamic, itemId as string, imageType as string, tag as string, maxWidth as integer) as string
    u = MsBase(p) + "/Items/" + itemId + "/Images/" + imageType
    if imageType = "Backdrop" then u = u + "/0"
    u = u + "?maxWidth=" + maxWidth.toStr()
    if tag <> "" then u = u + "&tag=" + UrlEncode(tag)
    return u
end function

' The file, exactly as it sits on the member's server.
'
' static=true means "send it as stored" — no transcode. A transcode is a live
' session on their own box that has to be torn down through /Videos/
' ActiveEncodings, and shipping half of that pair pins their server at full
' load. A file this Roku cannot decode fails instead, and says so.
'
' Emby must NOT be sent mediaSourceId: its media source is "mediasource_<id>",
' so passing the item id returns 400 on every title, while omitting it lets the
' server pick the file (measured on 4.9.5).
function MsStreamUrl(p as dynamic, itemId as string) as string
    u = MsBase(p) + "/Videos/" + itemId + "/stream?static=true"
    if not MsIsEmby(p) then u = u + "&mediaSourceId=" + UrlEncode(itemId)
    return u
end function

' WHICH DEMUXER THE VIDEO NODE SHOULD USE, from the container the catalogue
' reported — NOT from the address.
'
' This matters more here than anywhere else in the app: a media-server stream
' address carries no file extension ("/Videos/722685/stream?static=true"), so
' StreamFormatFor() falls through to its "mp4" default. Mason's Emby hands back
' video/x-matroska for a great many titles, and an mkv fed to the mp4 demuxer
' fails with "malformed data" — the same wording as an undecodable codec, which
' would have sent us hunting the wrong fault.
'
' Servers report the container ffmpeg-style ("mov,mp4,m4a,3gp,3g2,mj2"), so
' this looks for the name inside the string rather than comparing to it.
function MsStreamFormat(container as string) as string
    c = LCase(container)
    if Instr(1, c, "matroska") > 0 then return "mkv"
    if Instr(1, c, "mkv") > 0 then return "mkv"
    if Instr(1, c, "webm") > 0 then return "mkv"
    if Instr(1, c, "mpegts") > 0 then return "hls"
    if Instr(1, c, "m3u8") > 0 then return "hls"
    return "mp4"
end function

' ---- Reading what the server sent --------------------------------------------

' Ticks are hundred-nanosecond units: ten million to the second.
function MsTicksToSeconds(ticks as dynamic) as integer
    if ticks = invalid then return 0
    t = ticks
    if type(t) = "roString" or type(t) = "String" then t = Val(t)
    if t <= 0 then return 0
    return Int(t / 10000000.0)
end function

' Is this library one holding films or shows? Music, photos, books, box sets
' and the Playlists entry every Emby server carries are left alone — a playlist
' is the member's own arrangement of films they already have, and importing it
' would file the same film twice under a second heading.
'
' A library with no CollectionType at all is MIXED, and mixed is read for BOTH
' films and shows rather than skipped.
function MsLibraryHoldsVideo(collectionType as string) as boolean
    c = LCase(collectionType.trim())
    if c = "movies" then return true
    if c = "tvshows" then return true
    if c = "" then return true
    if c = "mixed" then return true
    if c = "unknown" then return true
    return false
end function

function MsLibraryIsShows(collectionType as string) as boolean
    return LCase(collectionType.trim()) = "tvshows"
end function

function MsLibraryIsMixed(collectionType as string) as boolean
    c = LCase(collectionType.trim())
    return c = "" or c = "mixed" or c = "unknown"
end function

' One catalogue row, flattened to the shape the VOD grid already draws for an
' Xtream title. Everything downstream — the poster card, the detail page, the
' favourite mark, the history row — then needs no idea a media server exists.
'
' kind is "movie" or "series" so it matches the app's own vocabulary rather
' than the server's ("Movie"/"Series").
function MsMapItem(p as dynamic, it as dynamic, kind as string) as object
    if it = invalid then return invalid
    id = ToStr(GetField(it, "Id"))
    name = ToStr(GetField(it, "Name"))
    if id = "" or name = "" then return invalid
    tags = GetField(it, "ImageTags")
    primary = ""
    if tags <> invalid then primary = ToStr(GetField(tags, "Primary"))
    row = {}
    row["id"] = id
    row["name"] = name
    row["kind"] = kind
    row["src"] = MsSrcToken(p)
    row["icon"] = MsImageUrl(p, id, "Primary", primary, 400)
    row["year"] = ToInt(GetField(it, "ProductionYear"))
    row["overview"] = ToStr(GetField(it, "Overview"))
    row["runtime"] = MsTicksToSeconds(GetField(it, "RunTimeTicks"))
    row["container"] = ToStr(GetField(it, "Container"))

    ' ---- What a detail page draws, off THIS answer and no other -------------
    '
    ' All four of these arrive in the library read the grid already paid for —
    ' the request names Logo and Backdrop in enableImageTypes and Genres and
    ' OfficialRating in fields, so carrying them here costs nothing at all. Not
    ' carrying them is what left media-server titles with no lettering, no
    ' backdrop and no ratings strip while every Xtream title had all three.
    '
    ' EMPTY IS A REAL ANSWER on every one of them, not a gap and not "not
    ' fetched yet". Most titles in most libraries have no logo, and a title
    ' with none shows its name as words, which is what the detail pages already
    ' fall back to.
    row["logo"] = ""
    if tags <> invalid
        lg = ToStr(GetField(tags, "Logo"))
        if lg <> "" then row["logo"] = MsImageUrl(p, id, "Logo", lg, 500)
    end if
    bd = MsFirstBackdropTag(it)
    row["backdrop"] = ""
    if bd <> "" then row["backdrop"] = MsImageUrl(p, id, "Backdrop", bd, 1280)
    ' The server's own community score, 0-10, exactly as the phone reads it.
    row["rating"] = ToStr(GetField(it, "CommunityRating"))
    row["cert"] = ToStr(GetField(it, "OfficialRating"))
    ' One string rather than the array, because the chip row draws one chip of
    ' genre the same way the Xtream page draws info.genre.
    row["genres"] = MsGenreLine(GetField(it, "Genres"))
    ' Only filled on an answer that was asked for People and MediaStreams
    ' (MsItemUrl); on a library row every field of it is simply empty.
    row["tech"] = MsTechInfo(it)
    return row
end function

' The cast, the director and the technical rows, in the SHAPE the film page's
' information table already reads off an Xtream get_vod_info answer:
'
'   { cast, director, video: { height, codec_name },
'     audio: [ { codec_name, channels, language,
'                disposition: { default } }, ... ],
'     bitrate }                    (bitrate in kbps, as the panels send it)
'
' Built to that shape on purpose, so mdVideoLine / mdAudioLine / mdBitrateLine
' and the cast line need no media-server branch at all - one table, two
' sources, drawn by one set of rules.
function MsTechInfo(it as dynamic) as object
    out = { cast: "", director: "", bitrate: 0 }
    actors = ""
    n = 0
    for each person in ToArray(GetField(it, "People"))
        nm = ToStr(GetField(person, "Name")).trim()
        if nm <> ""
            kind = LCase(ToStr(GetField(person, "Type")))
            if kind = "actor"
                ' Six, about what the Xtream page ends up with once a panel's
                ' cast string is cut to two lines at this size.
                if n < 6
                    if actors <> "" then actors = actors + ", "
                    actors = actors + nm
                    n = n + 1
                end if
            else if kind = "director"
                if out.director = "" then out.director = nm
            end if
        end if
    end for
    out.cast = actors
    ' ---- The soundtracks, as a LIST, in the server's OWN order (JB-31) ------
    '
    ' EVERY audio stream, not just the first one, because the Audio row can now
    ' say "English, Spanish - EAC3 5.1" and a media server is the only source
    ' we have that actually names the language. Eleven films off the KwickTV
    ' panel named none, so without this the row never shows a language at all.
    '
    ' THE ORDER IS THE SERVER'S AND IS LEFT ALONE. The film page reads two
    ' different things out of this list: the codec and the channel count come
    ' off the FIRST entry, and the languages come off the whole list with the
    ' default soundtrack moved to the front. Leaving the order as the server
    ' sent it means the codec and channels printed are the same stream this
    ' function has always picked, so the half of the row that was already
    ' there does not move.
    '
    ' TWO FIELD NAMES ARE TRANSLATED HERE rather than taught to the page:
    '   `Language`  -> `language`. The page tries an ffprobe `tags.language`
    '                  first and then a plain `language`; media servers have
    '                  no tags block, so the plain one is the one to write.
    '   `IsDefault` -> `disposition.default`. ffprobe's spelling, and the only
    '                  one the page understands. IT MUST BE THE NUMBER 1 AND
    '                  NOT true: the page tests the flag with ToInt, and ToInt
    '                  answers 0 for every boolean, so a `true` written here
    '                  would quietly never sort.
    '
    ' BOTH KEYS ARE ALWAYS WRITTEN, empty when the server says nothing, so a
    ' stream is never half a map. A film whose server names no language reads
    ' exactly as it does today - the page finds no language, prints the codec
    ' and the channels on their own, and nothing else about the row changes.
    auds = []
    for each stream in ToArray(GetField(it, "MediaStreams"))
        kind = LCase(ToStr(GetField(stream, "Type")))
        if kind = "video" and not out.doesExist("video")
            out.video = { height: ToInt(GetField(stream, "Height")), codec_name: ToStr(GetField(stream, "Codec")) }
            ' The video stream's own rate, which is what the panels' bitrate
            ' field means too. Bits per second on the wire; the table wants
            ' kbps.
            bps = ToInt(GetField(stream, "BitRate"))
            if bps > 0 then out.bitrate = Int(bps / 1000)
        else if kind = "audio"
            isDflt = 0
            if GetField(stream, "IsDefault") = true then isDflt = 1
            auds.push({
                codec_name: ToStr(GetField(stream, "Codec")),
                channels: ToInt(GetField(stream, "Channels")),
                language: ToStr(GetField(stream, "Language")).trim(),
                disposition: { default: isDflt }
            })
        end if
    end for
    ' No audio streams described leaves the key off entirely, the way it was
    ' left off before, so the page skips the Audio row rather than drawing an
    ' empty one.
    if auds.count() > 0 then out.audio = auds
    return out
end function

' The tag of a title's FIRST backdrop, or "" where it has none.
'
' A LIST, not an entry in ImageTags, and it is the one thing about backdrops
' that is not guessable from how posters and logos work. Both servers put
' Primary and Logo inside the ImageTags map, but a title can carry SEVERAL
' backdrops, so they come back as a separate top-level BackdropImageTags array
' — reading tags.Backdrop finds nothing on every title on either server.
'
' The FIRST is taken because that is the one the server itself lists first,
' which is the picture its own web page shows behind that title. Any other and
' a member sees a different backdrop on the television from the one on their
' own server.
function MsFirstBackdropTag(it as dynamic) as string
    for each t in ToArray(GetField(it, "BackdropImageTags"))
        tag = ToStr(t)
        if tag <> "" then return tag
    end for
    return ""
end function

' "Comedy, Drama, Romance" — the genre chip's line, cut to three.
'
' Three because the chip row is one line on a 1920 page shared with the year,
' the runtime and the source name, and a title carrying six genres (the owner's
' own 3 Body Problem carries six) would push the source chip off the end.
function MsGenreLine(genres as dynamic) as string
    out = ""
    n = 0
    for each g in ToArray(genres)
        name = ToStr(g).trim()
        if name <> ""
            if out <> "" then out = out + ", "
            out = out + name
            n = n + 1
            if n >= 3 then return out
        end if
    end for
    return out
end function

' The little map the shared ratings strip reads, built from a media-server row.
'
' RatingBadges.brs was written against an Xtream panel's get_vod_info answer and
' asks it for four things: a certificate, a score, a release year and a TMDB id.
' Three of those a media server sends in the library read, so the strip needs no
' media-server code of its own — it needs this shape.
'
' NO tmdb_id ON PURPOSE. The strip labels a score "TMDB" only when the panel
' also sent the id that proves where the number came from, and a media server
' sends no such id: Jellyfin's CommunityRating usually IS TMDB's, but "usually"
' is not something to print under a logo. With no id the strip labels it with
' the plain word "Rating", which is honest, and the IMDb / Rotten Tomatoes /
' Metacritic badges still arrive from the metadata service the same way they do
' for every Xtream title.
function MsInfoMap(row as dynamic) as object
    year = ""
    y = ToInt(GetField(row, "year"))
    if y > 0 then year = y.toStr()
    return {
        certification: ToStr(GetField(row, "cert")),
        rating: ToStr(GetField(row, "rating")),
        releasedate: year
    }
end function

' ---- The name this server answers to across devices --------------------------
'
' "jf:<serverId>" / "emby:<serverId>", matching the Flutter apps exactly
' (source_tokens.dart) — and deliberately NOT built from the address. One box
' reached at 192.168.1.50:8096 from the sofa and at a DDNS name from the bus is
' ONE server; two servers behind one host name are two. Only the server's own
' id gets that right, which is why it is read at sign-in and stored.
'
' A server whose id we have not learned YET gets a stand-in built from its
' address, "jf:@<host>", and never a blank one: a blank reads as the KwickTV
' login's own token ("") everywhere in this app, and would hand a member's
' Jellyfin favourites to their IPTV account. The "@" can never appear in a real
' server id (they are plain hex), so a stand-in and a real name can't collide.
'
' The stand-in lasts only until the app signs in — SaveMediaServerSession()
' writes the real id down and carries everything saved under the stand-in
' across to the real name, the same move an address change already does.
function MsSrcToken(p as dynamic) as string
    sid = ToStr(p.serverId)
    if sid = "" then return MsPendingSrcToken(p)
    if MsIsEmby(p) then return "emby:" + sid
    return "jf:" + sid
end function

' The stand-in name above, on its own so the sign-in can ask for it by name.
' Empty only for a server with no address at all, which cannot exist.
function MsPendingSrcToken(p as dynamic) as string
    host = HostOf(ToStr(p.server))
    if host = "" then return ""
    if MsIsEmby(p) then return "emby:@" + host
    return "jf:@" + host
end function

' Has this server been signed in to yet? Everything that reads a member's
' library needs a token, and a paired server arrives without one.
function MsNeedsSignIn(p as dynamic) as boolean
    if not MsIsMediaServer(p) then return false
    if ToStr(p.token) = "" then return true
    if ToStr(p.userId) = "" then return true
    if ToStr(p.serverId) = "" then return true
    return false
end function
