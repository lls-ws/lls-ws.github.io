' "Refresh TV Guide" — the mechanism half of the Settings row.
'
' Settings owns the ROW (the label, the spinner, the dialog). This file owns
' the DECISION: whether a refresh is allowed right now, and what happens when
' it is. Split that way because the guide is the single most ban-dangerous
' thing this app asks a provider for, and the rules that keep it safe belong
' next to the rest of the guide code rather than in a settings list.
'
' >>> THIS FILE IS NOT INHERITED. <<<
' A SceneGraph component gets ONLY the scripts its own XML names. Any
' component that calls GuideRefreshRequest() or GuideRefreshTake() must carry
'     <script type="text/brightscript" uri="pkg:/source/utils/GuideRefresh.brs" />
' or the call kills the render thread with "Function is not defined in
' component's namespace" and the screen locks up mid-spinner. Listed today by
' LiveTvScreen.xml and GuideScreen.xml. Util.brs must be listed too (KLog).
'
' ---------------------------------------------------------------------------
' HOW A REFRESH ACTUALLY HAPPENS, AND WHY IT COSTS THE PROVIDER NOTHING HERE
' ---------------------------------------------------------------------------
' Pressing Refresh starts NO request. Not one. All it does is raise a flag.
'
' The guide is read by a chain that lives in LiveTvScreen and GuideScreen —
' the member's own guides in their order, then each panel's batched
' xmltv.php, merged first-writer-wins and published once. Both screens are
' destroyed and rebuilt on every sidebar navigation (AppShell.showScreen
' removeChild/createChild), and both start that chain only when
' m.global.xmltvState is "". So the entire refresh is: drop the flag, and the
' next time a guide screen opens it reads everything again through the SAME
' bounded path it always uses — HEAD first, streamed to cachefs, cancelled
' past the 24 MB cap, one XmltvTask alive at a time.
'
' That is deliberate and it is the safety argument. A member hammering the
' Refresh row generates ZERO provider traffic, because nothing is fetched
' from Settings at all. There is no third copy of the chain to get the
' bounding wrong in, and a manual refresh can never be an unbounded one
' because it is not a download — it is a permission for the existing
' download to run once more.
'
' ---------------------------------------------------------------------------
' THE COOLDOWN: 15 MINUTES
' ---------------------------------------------------------------------------
' What bounds the REAL cost — the re-download the next screen open performs.
' 900 seconds, chosen against three things:
'
'   · The data. An XMLTV guide covers -1h/+18h and providers regenerate
'     xmltv.php on a schedule measured in hours. Re-reading it every quarter
'     hour is already far more often than it changes; anything shorter buys
'     the member nothing and buys the panel a pattern.
'   · The chain's own length. One guide is allowed 300 s by XmltvTask's
'     deadline and a chain can hold three. A cooldown shorter than a chain
'     would let a second refresh be granted while the first was still
'     downloading.
'   · The stale-claim bar. LiveTvScreen/GuideScreen take over a hung read
'     after 960 s. 900 sits just under it, so a cooldown expires at about the
'     moment a genuinely stuck read becomes recoverable — a member who waits
'     out the refusal is never told "try again" into a claim that still
'     cannot move.
'
' It is SESSION-LIVED, not written to the registry. Every launch reads the
' guide fresh anyway, so a launch already is a refresh; persisting the stamp
' would only refuse the first refresh after a cold start. It also keeps this
' feature entirely out of the 16-32 KB registry, where an over-budget write
' fails silently and takes whatever else was mid-write with it.
'
' A refusal is never silent. Every path returns a title and a sentence for
' the member, so the row can say "already up to date" rather than appear to
' do nothing — which is what makes somebody press it again.
'
' ---------------------------------------------------------------------------
' THE SHRUNK-LINEUP HAZARD (Android's refresh_guard_dialog, and why the guide
' does not get the same dialog)
' ---------------------------------------------------------------------------
' Android guards the PLAYLIST refresh: a panel that answers with 12 channels
' when the member has 900 would delete their lineup, so it refuses and asks.
' The guide cannot do that — a guide never supplies channels, only captions,
' and the lineup comes from the M3U/Xtream channel lists that Nia's playlist
' row refreshes. A smaller guide costs captions, never channels.
'
' There IS a smaller version of the same hazard and it is handled, in the two
' screens rather than here: a refresh whose every guide fails would replace a
' working guide with nothing for the rest of the session, so the member would
' have destroyed their own captions by pressing Refresh. So the old map is
' NOT cleared here. m.global.xmltvById keeps the guide the member already had
' until a new chain succeeds and overwrites it whole, and if the whole chain
' fails, finishLiveGuideChain / finishGuideChain keep the old one and report
' "ready" instead of "failed". No dialog, because there is no judgement call
' for the member to make: keeping what works is right every time.
'
' The one real cost is a gap. Between the chain starting and the chain
' landing, xmltvState is "loading" and every reader that gates on "ready"
' (PlayerScreen, MultiViewScreen, SportsTask, ChannelDetailScreen, both
' grids) shows no caption. That is why the flag is consumed by the SCREEN and
' not by this function — the guide stays live and readable for as long as the
' member is still in Settings, and the gap is only ever as long as the chain
' actually takes on the screen doing the work.

' Seconds between manual guide refreshes. See the block above.
function GuideRefreshCooldownSeconds() as integer
    return 900
end function

' Ask for the guide to be re-read.
'
' Returns, always:
'   {
'     ok:      boolean — true when the refresh was accepted
'     code:    "queued" | "busy" | "cooldown"
'     title:   short line for a dialog title / row status
'     message: one plain sentence for the member
'   }
'
' Never throws, never blocks, never touches the network, and returns inside a
' handful of instructions — certification 3.5 gives a remote press 250 ms and
' this is called straight off an OK.
function GuideRefreshRequest() as object
    if m.global = invalid
        return { ok: false, code: "busy", title: "Not just now", message: "The app is still starting up. Give it a moment and try again." }
    end if
    guideRefreshEnsureFields()

    ' ONE AT A TIME. "loading" means a chain is mid-download somewhere in the
    ' app — the launch read, or another screen's. Starting a second is the
    ' concurrent-connection shape a panel bans for, and Android says the same
    ' thing here (GuideBusyException -> "The guide is already updating").
    if m.global.xmltvState = "loading"
        return { ok: false, code: "busy", title: "Your guide is already updating", message: "It is being downloaded right now. Open the TV Guide in a minute and it will be there." }
    end if

    secs = CreateObject("roDateTime").asSeconds()
    asked = m.global.xmltvRefreshAt
    if asked > 0 and (secs - asked) < GuideRefreshCooldownSeconds()
        remain = GuideRefreshCooldownSeconds() - (secs - asked)
        return { ok: false, code: "cooldown", title: "Your guide is already up to date", message: "It was refreshed a few minutes ago and TV listings only change a few times a day. You can refresh it again in " + guideRefreshPlainMinutes(remain) + "." }
    end if

    m.global.xmltvRefreshAt = secs
    m.global.xmltvRefreshPending = true
    KLog("guide", "manual refresh asked for - the guide will be read again next time the TV Guide or Live TV is opened")
    return { ok: true, code: "queued", title: "Guide refresh scheduled", message: "Your guide will be downloaded again the next time you open the TV Guide or Live TV. Nothing has been lost in the meantime — the listings you have now stay on screen until the new ones arrive." }
end function

' Claim a pending refresh. TRUE means the caller should treat the shared guide
' as stale and read it again; the flag is cleared so only the first screen to
' ask acts on it.
'
' Called by LiveTvScreen.startXmltv and GuideScreen.startGuideXmltv, both of
' which run on the render thread — the only thread either of them has — so the
' read-then-clear cannot be raced.
function GuideRefreshTake() as boolean
    if m.global = invalid then return false
    if not m.global.hasField("xmltvRefreshPending") then return false
    if m.global.xmltvRefreshPending <> true then return false
    m.global.xmltvRefreshPending = false
    return true
end function

' Clears the cooldown, so the very next Refresh is granted.
'
' For ONE case: the member has just changed which guide the app should read
' (a Custom EPG address added, swapped or turned off in Settings). Refusing
' them a refresh then would be refusing them a look at the thing they just
' set up, and the reason for the cooldown — "the listings have not changed" —
' is exactly what is no longer true. Optional; nothing breaks without it.
sub GuideRefreshClearCooldown()
    if m.global = invalid then return
    guideRefreshEnsureFields()
    m.global.xmltvRefreshAt = 0
end sub

' The two fields this feature adds to m.global, created on first use.
'
' Added here rather than in AppScene's addFields list because AppScene belongs
' to another lane; the same runtime pattern is already used for liveEpgCount
' in LiveTvScreen.brs. Worth folding into AppScene.brs later — it is the one
' place a reader looks to see what the global holds.
'
' NEITHER TOUCHES xmltvById OR xmltvState. Their shape, and the
' "" -> "loading" -> "ready"/"failed" transition, are read by five other
' places in the app and are unchanged by any of this.
sub guideRefreshEnsureFields()
    if not m.global.hasField("xmltvRefreshAt") then m.global.addFields({ xmltvRefreshAt: 0 })
    if not m.global.hasField("xmltvRefreshPending") then m.global.addFields({ xmltvRefreshPending: false })
end sub

' "12 minutes" / "a minute" — for a sentence, not a countdown.
function guideRefreshPlainMinutes(seconds as integer) as string
    mins = Int(seconds / 60) + 1
    if mins <= 1 then return "a minute"
    return mins.toStr().trim() + " minutes"
end function
