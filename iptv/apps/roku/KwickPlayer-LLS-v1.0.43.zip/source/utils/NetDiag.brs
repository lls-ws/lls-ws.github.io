' ---- Why a connection failed ------------------------------------------------
' "Couldn't reach the server. timed out" is accurate and useless. It doesn't
' say whether the internet is down, the address won't resolve, the server
' refused us, or this Roku's clock is wrong — four problems with four
' different fixes, and the member is left thinking the app is broken.
'
' Two things make it actionable:
'
'   1. roUrlTransfer already reports the real reason as a NEGATIVE libcurl
'      code on the response. We were flattening every one of them into
'      "HTTP -6" and showing that to members — which also slipped past
'      IsNetworkErrorText(), so a plain DNS failure could be filed as a
'      crash.
'   2. One probe against a host we control separates "your internet is
'      down" from "your network is blocking this ONE host". The second is
'      the common case: routers and ISPs block kwick.cc while the rest of
'      the internet works, which is why members keep discovering on their
'      own that signing in works on mobile data. The app could never say
'      so, so it read as our fault.

' Roku surfaces libcurl error numbers as negative response codes. Anything
' from 100 up is a real HTTP status — the server answered, so reachability
' was never the problem.
function NetErrKind(code as integer) as string
    if code >= 200 and code < 300 then return "ok"
    if code >= 100 then return "http"
    c = code
    if c < 0 then c = 0 - c
    if c = 6 then return "dns"          ' couldn't resolve host
    if c = 5 then return "dns"          ' couldn't resolve proxy
    if c = 7 then return "connect"      ' refused
    if c = 28 then return "timeout"
    if c = 0 then return "timeout"      ' no response at all
    if c = 52 then return "reset"       ' empty reply
    if c = 55 then return "reset"       ' send failed
    if c = 56 then return "reset"       ' recv failed
    if c = 35 or c = 51 or c = 53 or c = 54 then return "ssl"
    if c = 58 or c = 59 or c = 60 or c = 77 or c = 83 then return "ssl"
    return "unknown"
end function

' Short technical wording for the log and for the inline status line. Every
' phrase here is one IsNetworkErrorText() recognises, so these never get
' mistaken for a crash.
function NetErrLabel(code as integer) as string
    kind = NetErrKind(code)
    if kind = "dns" then return "could not resolve host (dns)"
    if kind = "connect" then return "connection refused"
    if kind = "timeout" then return "connection timed out"
    if kind = "ssl" then return "secure connection failed (tls)"
    if kind = "reset" then return "connection reset by the server"
    if kind = "http" then return "HTTP " + code.toStr()
    return "network error (" + code.toStr() + ")"
end function

' Builds what the member actually reads: what went wrong, why it happened,
' and what to do about it. Pure on purpose — the two facts about the network
' are gathered by the caller on a task thread, because probing from the
' render thread would freeze the screen.
'
'   linkUp  this Roku has a network connection at all
'   netUp   something we control answered, i.e. the internet itself works
function NetDiagnose(host as string, kind as string, linkUp as boolean, netUp as boolean, seconds as integer) as object
    nl = Chr(10)
    site = host
    if site = "" then site = "the server"

    if not linkUp
        return {
            title: "This Roku isn't online"
            message: "It isn't connected to a network at all, so nothing can load." + nl + nl + "Open Settings > Network on the Roku home screen and reconnect, then try again."
        }
    end if

    if not netUp
        return {
            title: "Your internet isn't working"
            message: "This Roku is connected to your Wi-Fi, but nothing on the internet is answering — not just " + site + "." + nl + nl + "Restart your router, give it a minute to come back, then try again."
        }
    end if

    ' Everything below here has already established that the internet works,
    ' which is the fact that makes the rest of the message worth trusting.
    if kind = "dns"
        return {
            title: "Your network is blocking " + site
            message: "The rest of the internet works from this Roku, but it can't even look up the address for " + site + "." + nl + nl + "That is your router or your internet provider blocking it — the server itself is fine, and nothing is wrong with your account." + nl + nl + "What usually fixes it:" + nl + "1. Try signing in with your phone's hotspot. If it works there, it is definitely being blocked on this network." + nl + "2. Change your router's DNS to 1.1.1.1 or 8.8.8.8, then restart the router."
        }
    end if

    if kind = "timeout"
        return {
            title: site + " isn't answering"
            message: "Your internet is working — other sites answered fine from this Roku. " + site + " gave no reply at all within " + seconds.toStr() + " seconds." + nl + nl + "That is either the server being down, or your router or internet provider quietly blocking it." + nl + nl + "Try your phone's hotspot. If it signs in there but not on your Wi-Fi, your network is blocking it."
        }
    end if

    if kind = "connect"
        return {
            title: site + " refused the connection"
            message: "Your internet is working and the address was found, but the server turned this Roku away instead of answering." + nl + nl + "That nearly always means the server is down or restarting. Try again in a few minutes — if it keeps happening, your provider needs to look at it."
        }
    end if

    if kind = "ssl"
        return {
            title: "Secure connection failed"
            message: "This Roku found " + site + " but couldn't set up a secure connection to it." + nl + nl + "The usual cause is this Roku's clock being wrong. Check Settings > System > Time on the Roku home screen, then try again."
        }
    end if

    if kind = "reset"
        return {
            title: site + " dropped the connection"
            message: "The server started to answer and then cut this Roku off part way through." + nl + nl + "That is usually the server being overloaded, or the account already being watched on as many devices as it allows. Try again in a moment."
        }
    end if

    return {
        title: "Couldn't reach " + site
        message: "Your internet appears to be working, but the connection to " + site + " failed." + nl + nl + "Try again in a moment. If it keeps happening, test with your phone's hotspot — if it works there, something on this network is blocking it."
    }
end function
