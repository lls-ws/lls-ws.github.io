' The ratings strip, shared by the film page and the series page — and, since
' 2026-08-27, the title's own stylised lettering, which arrives in the SAME
' answer and is therefore reset and drawn by the same code. See "THE TITLE'S
' OWN LETTERING" near the bottom for that half and the fields it needs.
'
' Android's RatingBadgesRow (lib/ui/widgets/rating_badges.dart:9) — the row of
' IMDb / Rotten Tomatoes / Metacritic scores that sits under a title. Roku
' printed whatever single number the panel put in info.rating, with no idea
' what it was a score OUT OF or who gave it.
'
' ---- WHY THIS IS A FILE OF ITS OWN ------------------------------------------
'
' It started inside MovieDetailScreen.brs, because the film page was the only
' page that had it. The owner asked for the same thing on the series page, and
' there are exactly two honest ways to do that: copy two hundred lines into
' SeriesDetailScreen.brs, or lift them out here and let both components include
' the file. Two copies of a merge rule and a cache key is how the two pages
' quietly drift apart, so this is the one that got picked.
'
' A component sees a script it names in its own <script> tag, and every script
' a component names shares that component's `m`. So this reads and writes the
' SAME m the screen does, exactly as it did when it lived in the screen's own
' file. Nothing here is global state: two detail screens have two m's.
'
' WHAT EACH SCREEN HAS TO SET UP, in init(), before any of this is called:
'
'   m.theme      the palette (KwickTheme)
'   m.rbFont     the type the chips are set in — an EXISTING font on that
'                screen, never a new size. A new size is a new glyph atlas in
'                texture memory for the sake of five characters. The film page
'                hands over its information-table font (23) and the series page
'                its plot font (24); at ten feet nobody can tell, and neither
'                page pays for an atlas it did not already have.
'   m.rbWho      what the log lines call this screen
'   m.rbKind     "movie" or "series" — goes to the service and into the key
'   m.rbLane     how wide the strip is allowed to be. THE CENTRING IS ON THIS.
'   m.rbRowY     the row tops inside the group; its length is the row cap
'   m.rbScrim    draw the media bar's scrim under the strip (film page only)
'   m.rbScrimH   how tall that scrim is
'   m.memMon     roAppMemoryMonitor, for the gate and the measurement
'
' and a Group with id "ratings" in its XML, positioned where the strip goes.
'
' ---- WHERE THE ARTWORK CAME FROM --------------------------------------------
'
' The comment that used to sit here said there would never be any: bundling
' logos "spends the 4 MB package cap on somebody else's trademarks" and
' fetching them "costs one request AND one texture per badge, six pictures a
' page, which is the per-tile pattern this whole feature is forbidden from
' repeating".
'
' The second half of that is still true and is the reason these are BAKED IN
' rather than fetched. The phone pulls them off a CDN at draw time
' (rating_badges.dart -> _logoBase); a television must not, because six image
' requests per page open on a box with five out-of-memory reports is the shape
' of mistake that got this house's provider access banned on 2026-08-14.
'
' The first half was overturned by the owner, who asked for "the metadata
' provider images if possible" and supplied the set: eleven PNGs in images/,
' 44.5 KB the whole way, the same artwork the phone draws, re-encoded at draw
' height by tools/make_rating_logos.py. THE PACKAGE GREW BY NOTHING WHEN THIS
' SHIPPED — the files were already in the tree before a line of this was
' written, and this change adds no image of its own.
'
' ---- WHAT THE STRIP COSTS IN TEXTURE ----------------------------------------
'
' Read this before adding a twelfth logo. Texture memory is not heap, the
' ~90 MB budget (Util.brs:489-493) is where all five out-of-memory reports came
' from, and roAppMemoryMonitor cannot see one byte of it — so it has to be
' arithmetic done in advance, the way MediaBar.xml:47-62 had to do it.
'
' The files are 52 pixels tall, which is 2x the 26 they draw at, so the
' television is downscaling and the badge stays sharp. loadWidth/loadHeight are
' deliberately NOT set: setting them would decode at 26 and throw that away,
' and what it would save is not worth having. Each logo costs nativeW x 52 x 4
' bytes, once, however many chips point at it:
'
'   IMDb   78x52  16,224 B      Metacritic 52x52  10,816 B
'   TMDB   72x52  14,976 B      Trakt      52x52  10,816 B
'   Ebert  52x52  10,816 B      Letterboxd 52x52  10,816 B
'   MAL    52x52  10,816 B      RT         51x52  10,608 B
'   Audience 39x52  8,112 B
'
' A full strip is six chips (rbMaxBadges), and the six widest that can be on
' one come to 74,464 bytes — 72.7 KB, or 0.08% of the texture budget. The strip
' the server actually sends most often (IMDb, RT, Metacritic, Audience, Trakt,
' Letterboxd) is 65.8 KB. The text-only strip this replaces cost NOTHING at all
' — labels draw out of a glyph atlas the screen already had — so 73 KB is the
' whole price, and it is charged once per logo per app run rather than per
' page: the texture cache answers the second film that shows an IMDb chip.
'
' For scale, one media bar backdrop at loadWidth=360 is ~292 KB. The entire
' badge set, all eleven at once, which cannot happen, is 126.5 KB.

' ---- The label -> artwork mapping -------------------------------------------
'
' The server sends a WORD in `s`, not a key: titlemeta.php's $LABELS array
' turns MDBList's source strings into "IMDb", "RT", "Metacritic", "Audience",
' "Trakt", "Letterboxd", "Ebert", "MAL", "TMDB". That is deliberate and it is
' written down at both ends — "THE SERVER DECIDES THE WORDING", so a new rating
' source or a renamed one is a server edit and not an app release.
'
' Which is exactly why the mapping to a picture lives HERE and not there. The
' server would have to learn what artwork this app happens to carry, the phone
' would need the same field, and the two apps would be pinned to each other's
' release schedules. Mapping on the client keeps that promise intact: the wire
' format does not change, no server edit is needed, and nothing collides with
' the other work in kwicksync/ this week.
'
' AN UNMAPPED LABEL IS NOT AN ERROR AND MUST NOT VANISH. The server can add a
' source tomorrow, and it may add one with no artwork in this package at all.
' rbLogoFor answers invalid, rbChip draws the grey-text chip this feature
' shipped with, and the member sees "Ebert 4.0" instead of a hole. That
' fallback is the reason the wording can stay the server's business.
'
' `w` is what the logo draws at — its native width scaled to 26 tall, worked
' out once from the files rather than measured on the box. It only has to be
' right enough to lay chips out without them touching; rbChip sets the same
' number on the Poster, so the aspect it draws at is the aspect it was made at.
'
' TWO FILES IN THE SET ARE NOT LISTED, and this is a known gap rather than an
' oversight. rating_rt_rotten.png and rating_audience_rotten.png are the splat
' versions the phone swaps in below 60% (_mdblistRatings folds `tomatoes` to
' `tomatoes_rotten` on the number). The server does NOT make that split — its
' comment says so outright: "the fresh/rotten split the phone makes is a choice
' of logo, and there is no logo here, so both fold to one word". There is a
' logo here now, but one word still arrives, so a 12% film and a 96% film both
' land on `rt` and both draw the FRESH tomato. Telling them apart needs either
' a second word from the server or a rule on the number down here, and picking
' the second would put the app back in the business of deciding what the
' server's data means. Left alone, listed here, and worth an hour of the
' server's time later.
function rbLogos() as object
    if m.rbLogoMap = invalid
        m.rbLogoMap = {
            "imdb":       { u: "pkg:/images/rating_imdb.png",       w: 39 },
            "rt":         { u: "pkg:/images/rating_rt.png",         w: 26 },
            "metacritic": { u: "pkg:/images/rating_metacritic.png", w: 26 },
            "audience":   { u: "pkg:/images/rating_audience.png",   w: 20 },
            "trakt":      { u: "pkg:/images/rating_trakt.png",      w: 26 },
            "letterboxd": { u: "pkg:/images/rating_letterboxd.png", w: 26 },
            "ebert":      { u: "pkg:/images/rating_rogerebert.png", w: 26 },
            "mal":        { u: "pkg:/images/rating_mal.png",        w: 26 },
            "tmdb":       { u: "pkg:/images/rating_tmdb.png",       w: 36 }
        }
    end if
    return m.rbLogoMap
end function

' The artwork for one label, or invalid for "draw the words instead".
' Case-folded because the server's wording is for a member to read, not for
' this to match on exactly — "IMDb" and "imdb" are the same source. It arrives
' already trimmed (metaCleanBadges does it before the answer is even cached),
' and the two labels this app makes itself are literals.
function rbLogoFor(s as string) as object
    if s = "" then return invalid
    return rbLogos()[LCase(s)]
end function

function rbMaxBadges() as integer
    return 6
end function

' A chip is 34 tall, the logo inside it 26 — the height the phone draws at
' (rating_badges.dart: `height: 18` on a phone, which is the same apparent size
' at a television's viewing distance) and the height the files were encoded
' for. 10 either side of a chip, 10 between two chips.
function rbChipH() as integer
    return 34
end function

function rbLogoH() as integer
    return 26
end function

function rbChipGap() as integer
    return 10
end function

sub clearBadges()
    grp = m.top.findNode("ratings")
    if grp = invalid then return
    while grp.getChildCount() > 0
        grp.removeChildIndex(0)
    end while
end sub

' Called by each screen when a new title arrives, in place of emptying the
' three fields by hand. `id` is the title's own id on its screen — the stream
' id on the film page, the series id on the series page — and it is what stops
' a slow answer for the LAST title painting over this one. See onTitleMeta.
sub rbReset(id as string)
    m.badges = []        ' [{ s, v }] — what the strip draws, in order
    m.hasCert = false    ' the panel gave us a certificate of its own
    m.rbId = id
    m.rbTag = ""         ' no lookup is out for this title yet
    clearBadges()
    ' The lettering comes out of the SAME answer as the badges, so it is reset
    ' at the same moment and by the same call. Without this the previous film's
    ' wordmark stays up over the new film's page for as long as the lookup
    ' takes, and for ever on a title that has no logo of its own.
    tlReset()
end sub

' A panel with nothing to say for a field very often fills it in anyway — with
' "null", "N/A", "0", "unknown" or a run of spaces. Every one of those has to
' read as ABSENT.
'
' This is the same rule as mdClean in MovieDetailScreen.brs and it is a second
' copy on purpose. mdClean belongs to the information table, which is one
' screen's feature; this belongs to the strip, which is two screens'. Folding
' them together would make the series page depend on the film page's
' information table, which it has nothing else to do with.
function rbClean(v as dynamic) as string
    s = ToStr(v).trim()
    if s = "" then return ""
    l = LCase(s)
    if l = "null" or l = "n/a" or l = "na" or l = "none" or l = "unknown" or l = "undefined" or l = "0" or l = "-" then return ""
    return s
end function

' ---- The two badges the panel already paid for ------------------------------
'
' The certificate and the panel's own score are in the get_vod_info /
' get_series_info answer the screen has already fetched, so they are drawn the
' instant the details land, with no request and nothing to wait for. Only the
' multi-source scores need asking for.
'
' Certificate first — it is the chip that identifies the title rather than
' judges it — then the score.
sub rbApplyProviderBadges(info as dynamic)
    m.badges = []
    m.hasCert = false
    cert = rbCertOf(info)
    if cert <> ""
        m.badges.push({ s: "", v: cert })
        m.hasCert = true
    end if
    score = rbScoreOf(info)
    if score <> invalid then m.badges.push(score)
    rbDrawBadges()
end sub

' The title's certificate. Panels disagree about which field it goes in and
' most send none at all, so every spelling is tried and none is required. The
' length guard is not decoration: a fair number of panels use `age` as a
' free-text field and write a sentence into it.
'
' It has no logo and it is never meant to have one — it is not a rating source,
' so it falls through rbLogoFor to the plain chip, which is the right answer
' rather than a missing case.
function rbCertOf(info as dynamic) as string
    for each k in ["mpaa_rating", "age", "rating_mpaa", "certification"]
        v = rbClean(GetField(info, k))
        if v <> "" and Len(v) <= 8 then return v
    end for
    return ""
end function

' The panel's own score, with an HONEST label on it.
'
' Xtream panels scrape these out of TMDB, which is exactly why info.tmdb_id
' sits in the same map — so when the panel sent an id, naming TMDB as the
' source is a fact and not a guess, and the chip earns the TMDB logo. When it
' did not, the number is still worth showing but its provenance genuinely is
' not known: it is labelled with the plain word "Rating", which maps to no
' artwork and draws as text. That is the fallback doing exactly the job it is
' there for — a logo would be a claim we cannot back.
function rbScoreOf(info as dynamic) as object
    raw = rbClean(GetField(info, "rating"))
    if raw = "" then return invalid
    ' Panels send this as a string, a float or an int, and a few send it out of
    ' range or as junk. Anything not a sane 0-10 score is not drawn.
    n = Val(raw)
    if n <= 0 or n > 10 then return invalid
    src = "Rating"
    if rbClean(GetField(info, "tmdb_id")) <> "" then src = "TMDB"
    ' ONE decimal, like the phone (`rating.toStringAsFixed(1)`). Panels send
    ' whatever TMDB gave them, which is why this was reading "7.384" on the
    ' television: four decimals of precision nobody asked for.
    return { s: src, v: rbOneDecimal(n) }
end function

' ---- The lookup -------------------------------------------------------------
'
' ONE request, per page open, cached for a week. NEVER per tile and never per
' episode — see the note at the top of TitleMetaTask.brs and HomeScreen.brs:6-19
' for what that pattern cost this house in August 2026. The series page makes
' exactly the same single call the film page does, at the same moment in the
' page's life, off the same details answer: it is a page-level ask about the
' SHOW, and no episode row is ever allowed to trigger one.
sub rbStartLookup(info as dynamic)
    it = m.top.item
    if it = invalid then return

    ' THE GATE, and both halves of it are the house's existing numbers rather
    ' than new ones: the device's own "low"/"critical" reading that the media
    ' bar drops its backdrop on, and the 70% ceiling Search stops loading
    ' catalogue at. Badges are decoration. On a box already close enough to the
    ' edge to be killed, they are not worth one more allocation — and now that
    ' they carry pictures that is truer than it was, not less.
    if rbMemoryTight()
        KLog("meta", m.rbWho + ": skipping the metadata lookup - this box is short of memory")
        return
    end if

    tag = ToStr(m.rbId)
    if tag = "" then return

    tmdb = rbClean(GetField(info, "tmdb_id"))
    year = rbYearOf(info)

    ' What the answer is filed under. The panel's tmdb_id when there is one —
    ' it is the same title on every panel, so two sources carrying it share one
    ' cached answer. Otherwise the name and year, lowercased, which is the same
    ' key Android falls back to and the same SHAPE the Media Bar files its own
    ' answers under (MediaBar.brs: kind + ":" + LCase(name) + "|"). NO
    ' CREDENTIALS AND NO PANEL ADDRESS go anywhere near this: the file is a
    ' plain readable one on disk, and a stream id is meaningless off its panel.
    if tmdb <> ""
        key = m.rbKind + ":" + tmdb
    else
        nm = LCase(ToStr(it.name).trim())
        if nm = "" then return       ' nothing to look up and nothing to file
        key = m.rbKind + ":" + nm + "|" + year
    end if

    task = CreateObject("roSGNode", "TitleMetaTask")
    task.kind = m.rbKind
    task.tmdbId = tmdb
    task.title = ToStr(it.name)
    task.year = year
    task.cacheKey = key
    ' Which title asked, so a slow answer for the last one cannot paint over
    ' this one — the browsing screens keep ONE detail screen and re-set `item`
    ' on it, so that is a real sequence and not a theoretical one.
    task.tag = tag
    task.observeField("result", "onTitleMeta")
    m.rbTag = tag
    ' Replaces the previous one, which is what releases it. Never more than one.
    m.metaTask = task
    task.control = "RUN"
end sub

' The release year, from whatever the panel called the field. get_vod_info says
' `releasedate` and get_series_info usually says `releaseDate`, so both
' spellings are tried; a panel that sends neither simply looks the title up by
' name, which the server's own name gate still checks letter for letter.
function rbYearOf(info as dynamic) as string
    for each k in ["releasedate", "releaseDate", "release_date"]
        v = ToStr(GetField(info, k))
        if Len(v) >= 4 then return Left(v, 4)
    end for
    return ""
end function

sub onTitleMeta(event as object)
    res = event.getData()
    if res = invalid then return
    if m.top.item = invalid then return

    ' Late answer for a title that is no longer on screen — drop it silently.
    ' m.rbTag is emptied by rbReset the moment a new title arrives, so an
    ' answer that outlived its page can never match.
    if ToStr(m.rbTag) = "" then return
    node = event.getRoSGNode()
    if node <> invalid and ToStr(node.tag) <> ToStr(m.rbTag) then return

    if res.ok <> true
        ' "off" is the service having no address configured, which is the
        ' shipped state and not worth a line in the log on every title.
        if not res.doesExist("off")
            KLog("meta", m.rbWho + ": metadata lookup failed - " + ToStr(res.error))
        end if
        return
    end if

    ' Merge behind what the panel gave us. The certificate and the panel's own
    ' score describe THIS copy and keep the front of the strip; the service's
    ' scores queue up behind them, and a source already on the strip is never
    ' added twice.
    have = {}
    for each b in m.badges
        have[LCase(b.s)] = true
    end for
    for each b in ToArray(GetField(res.data, "badges"))
        s = ToStr(GetField(b, "s"))
        v = ToStr(GetField(b, "v"))
        if v <> "" and not have.doesExist(LCase(s))
            have[LCase(s)] = true
            m.badges.push({ s: s, v: v })
            if m.badges.count() >= rbMaxBadges() then exit for
        end if
    end for

    ' A certificate from the service only if the panel had none of its own.
    cert = ToStr(GetField(res.data, "cert"))
    if cert <> "" and not m.hasCert
        m.badges.unshift({ s: "", v: cert })
        m.hasCert = true
    end if

    rbDrawBadges()
    ' The title's own lettering, out of the same map. No second request and no
    ' second cache — see the block further down.
    tlApplyLogo(res.data)
    src = "fetched"
    if res.doesExist("cached") and res.cached = true then src = "cache"
    KLog("meta", m.rbWho + ": metadata answered from " + src)
    rbMemSample("enriched")
end sub

' ---- Drawing ----------------------------------------------------------------
'
' CENTRED, which is what the owner asked for, and centred ON THE LANE THE STRIP
' LIVES IN rather than on the screen. Android centres its row too
' (WrapAlignment.center, rating_badges.dart:21) but Android's detail page is
' ONE centred hero column, so there "the column" and "the page" are the same
' 400 points and the question never comes up. A television is 1920 wide and
' both of these pages are two columns: a poster and its table down the left, a
' title, a plot and a stack of FOCUSABLE buttons down the right. Centring on
' x=960 would hang the strip across the seam between them — half over artwork,
' half over the plot on one page and over the Play button's focus ring on the
' other — and would mean moving things that are load-bearing to move it out of
' the way. So each screen names its lane in m.rbLane and the rows centre in
' that: the film page's is the 360 of the poster the strip is drawn on, the
' series page's the 240 of the cover it is drawn under. Each strip is centred
' on the thing it is about, which is the same relationship Android's is in.
'
' Rows are measured before anything is created, because a row cannot be centred
' until it is known how wide it came out. Two passes over at most six chips.
sub rbDrawBadges()
    if m.badges = invalid then return
    if m.badges.count() = 0
        ' Nothing known about this title. The page is left exactly as bare as
        ' it was before this feature existed — no scrim, no empty strip.
        clearBadges()
        return
    end if
    grp = m.top.findNode("ratings")
    if grp = invalid then return
    clearBadges()

    lane = m.rbLane
    rowY = m.rbRowY

    ' Pass one: which chips land on which row, and how wide each row came out.
    rows = []
    cur = []
    curW = 0
    for each b in m.badges
        w = rbChipWidth(b.s, b.v)
        if cur.count() > 0 and curW + rbChipGap() + w > lane
            rows.push({ items: cur, w: curW })
            ' Out of rows. There are only ever as many as the screen declared —
            ' one more would run off the bottom of the poster on the film page
            ' and into the season list on the series page — so anything that
            ' does not fit is dropped rather than drawn somewhere it does not
            ' belong. The server sends its badges best-first (titlemeta.php
            ' sorts on `o`), so what gets dropped is the least-wanted.
            if rows.count() >= rowY.count() then exit for
            cur = []
            curW = 0
        end if
        if cur.count() > 0 then curW = curW + rbChipGap()
        cur.push({ b: b, w: w })
        curW = curW + w
    end for
    if cur.count() > 0 and rows.count() < rowY.count() then rows.push({ items: cur, w: curW })

    ' The scrim first so every chip lands on top of it. This is the media bar's
    ' own scrim_bottom.png, already in the package. Only the film page asks for
    ' one — its strip is drawn OVER the poster, where a chip would otherwise be
    ' sitting on somebody's face; the series page has clear space to draw in.
    if m.rbScrim = true
        scrim = grp.createChild("Poster")
        scrim.uri = "pkg:/images/scrim_bottom.png"
        scrim.width = lane
        scrim.height = m.rbScrimH
        scrim.translation = [0, 0]
    end if

    ' Pass two: draw each row centred in the lane.
    drawn = 0
    for i = 0 to rows.count() - 1
        r = rows[i]
        x = Int((lane - r.w) / 2)
        if x < 0 then x = 0
        for each c in r.items
            rbChip(grp, x, rowY[i], c.w, c.b.s, c.b.v)
            x = x + c.w + rbChipGap()
            drawn = drawn + 1
        end for
    end for
    KLog("meta", m.rbWho + ": rating badges - " + drawn.toStr() + " of " + m.badges.count().toStr() + " drawn")
end sub

' A score as one decimal: 7.384 -> "7.4", 8 -> "8.0".
function rbOneDecimal(n as float) as string
    tenths = Int(n * 10 + 0.5)
    whole = Int(tenths / 10)
    rest = tenths - whole * 10
    return whole.toStr() + "." + rest.toStr()
end function

' How wide a piece of text actually draws, measured rather than guessed.
'
' This used to assume 12 pixels a character, which is too narrow for 23pt
' capitals - so "TMDB" was given 48px, drew wider than that, and came out on the
' television as "T...". boundingRect on a Label with NO width set returns the
' real width; setting a width first would make it return the width you set,
' which is the trap MultiViewScreen.brs:471 records.
function rbTextWidth(t as string) as integer
    if t = "" then return 0
    if m.rbRuler = invalid
        m.rbRuler = CreateObject("roSGNode", "Label")
        m.rbRuler.font = m.rbFont
    end if
    m.rbRuler.text = t
    r = m.rbRuler.boundingRect()
    if r = invalid or r.width <= 0 then return Len(t) * 15
    return Int(r.width) + 1
end function

' 10 padding either side, then the source and the value with a gap between.
'
' A LOGO IS USUALLY NARROWER THAN THE WORD IT REPLACES, which is why more of
' them fit than used to: "Metacritic" measures about 110px at this size and its
' logo draws at 26, so a chip that was ~160 wide is now ~80. The gap after a
' logo is 8 rather than 6 because a picture has no side bearing the way a
' letter does and 6 read as touching.
function rbChipWidth(s as string, v as string) as integer
    w = 20 + rbTextWidth(v)
    lg = rbLogoFor(s)
    if lg <> invalid
        w = w + lg.w + 8
    else if s <> ""
        w = w + rbTextWidth(s) + 6
    end if
    if w > m.rbLane then w = m.rbLane
    return w
end function

sub rbChip(grp as object, x as integer, y as integer, w as integer, s as string, v as string)
    bg = grp.createChild("Rectangle")
    bg.width = w
    bg.height = rbChipH()
    bg.translation = [x, y]
    bg.color = m.theme.surfaceElevated

    tx = x + 10
    lg = rbLogoFor(s)
    if lg <> invalid
        ' The provider's own artwork, out of the package. scaleToFit is what
        ' every other badge and logo on this app uses (ChannelCard, SportsCard,
        ' MultiViewPickRow) and it cannot squash the picture: the width below is
        ' the file's own aspect at this height, so "fit" and "fill" land on the
        ' same pixels and fit is the one that stays honest if a file is ever
        ' re-cut at a different shape.
        im = grp.createChild("Poster")
        im.uri = lg.u
        im.width = lg.w
        im.height = rbLogoH()
        im.loadDisplayMode = "scaleToFit"
        im.translation = [tx, y + Int((rbChipH() - rbLogoH()) / 2)]
        tx = tx + lg.w + 8
    else if s <> ""
        ' No artwork for this label — the server named a source this package
        ' has no picture for, or it is the certificate chip, which never has
        ' one. The grey word this feature shipped with, which is why the server
        ' can still add a source whenever it likes.
        sl = grp.createChild("Label")
        sl.translation = [tx, y]
        sl.width = rbTextWidth(s)
        sl.height = rbChipH()
        sl.vertAlign = "center"
        sl.font = m.rbFont
        sl.color = m.theme.textSecondary
        sl.maxLines = 1
        sl.text = s
        tx = tx + rbTextWidth(s) + 6
    end if
    vl = grp.createChild("Label")
    vl.translation = [tx, y]
    vl.width = rbTextWidth(v)
    vl.height = rbChipH()
    vl.vertAlign = "center"
    vl.font = m.rbFont
    vl.color = m.theme.textPrimary
    vl.maxLines = 1
    vl.text = v
end sub

' ---- THE TITLE'S OWN LETTERING ----------------------------------------------
'
' Mason, 2026-08-27: "the only thing i see missing from movie VOD is that the
' logos dont load it just shows the text." The stylised title artwork — the
' film's own wordmark — was never wired into either detail page.
'
' IT COSTS NO NEW REQUEST AND NO NEW MACHINERY. titlemeta.php answers with `lg`
' in the SAME map as `bd` and the badges, through the SAME TitleMetaTask, into
' the SAME seven-day cachefs row. onTitleMeta below already has it in hand and
' was throwing it away. The Media Bar has drawn this field on real hardware
' since it shipped (MediaBar.brs applyTitle / onLogoLoad); this is that, with
' the geometry made a parameter so two pages with very different room can share
' one copy — the same argument that put the badge strip in this file.
'
' WHAT EACH SCREEN SETS UP, in init(), on top of the m fields listed at the top:
'
'   m.tlLogo     the Poster the lettering draws in
'   m.tlLabel    the Label holding the title AS WORDS, which the logo replaces
'   m.tlMaxW     widest the lettering may draw
'   m.tlMaxH     tallest
'   m.tlBottom   the y its box sits ON — its BOTTOM edge, in the parent
'   m.tlCentre   the x it centres on
'
' and then `m.tlLogo.observeField("loadStatus", "onTitleLogoLoad")`.
'
' THE WORDS ARE THE FALLBACK IN EVERY DIRECTION, which is Android's rule
' verbatim (detail_hero.dart:401-421 — `placeholder` and `errorWidget` are both
' `_titleText`): no logo for this title, no answer yet, an answer that never
' comes, a picture that will not decode. The Label holds the title the whole
' time in the right font at the right size; the logo simply hides it once the
' bitmap is actually up. Nothing has to be rebuilt when the picture never
' arrives, because it was already there underneath.
'
' NOTHING BELOW THE TITLE MOVES, EVER. The lettering is BOTTOM-aligned on
' m.tlBottom — the same edge the words ended on — and grows UPWARD into hero
' space that was empty anyway. Android can do this the other way because its
' hero is a Column that grows; a Roku page is fixed geometry and every y below
' the title is load-bearing, so the box that can change size is the one with
' nothing under it.

' TMDB's largest NAMED size for a logo path. The size list for logos is
' w45/w92/w154/w185/w300/w500/original — w780 and w1280 are BACKDROP sizes, and
' a size token the CDN does not serve for this path type is a 404, i.e. no
' picture at all rather than a soft one. The Media Bar asks for w300 because it
' decodes at 200 wide; these pages draw four times that.
function TitleLogoSize() as string
    return "w500"
end function

' Take the lettering down and put the words back. BOTH halves, every time: the
' uri as well as the visibility, because clearing the uri is what actually
' hands the texture back on this box, and the width and height as well as the
' uri, because a node that is only hidden keeps the LAST title's shape and
' flashes it for a frame when the next logo lands.
'
' Called from rbReset, so every screen that resets its badges resets this too
' and there is no second call site to forget.
sub tlReset()
    ' The pin belongs to the title that set it and to nothing after it.
    m.tlPinned = ""
    if m.tlLogo = invalid then return
    m.tlLogo.visible = false
    m.tlLogo.uri = ""
    m.tlLogo.width = m.tlMaxW
    m.tlLogo.height = m.tlMaxH
    m.tlLogo.translation = [m.tlCentre - Int(m.tlMaxW / 2), m.tlBottom - m.tlMaxH]
    m.tlOn = false
    if m.tlLabel <> invalid then m.tlLabel.visible = true
end sub

' The lettering for the title whose metadata just landed.
'
' `lg` arrives as TMDB's SHORT FORM — a leading slash and a file name, no host
' and no size — exactly as `bd` does, and metaCleanLogo in TitleMetaTask.brs has
' already held it to that shape and to .png. BackdropUrl() is the one function
' that puts the host and the size back on; it takes a size now, so no helper had
' to be added anywhere for this. Building the url inline here would be a second
' copy of that rule, which is the mistake that drew no hero at all on the film
' page on 2026-08-26.
sub tlApplyLogo(data as dynamic)
    if m.tlLogo = invalid then return
    ' A PINNED LOGO WINS, AND THIS IS THE RACE IT SETTLES. A media-server page
    ' puts the member's OWN lettering up the instant the page opens, off the
    ' library read; the metadata answer lands a second or two later and used to
    ' overwrite it. Two things driving one Poster meant the second uri could
    ' arrive while the first was still loading, and an interrupted load reports
    ' "failed" — which blacklisted the member's own perfectly good picture for
    ' the rest of the session and dropped the page back to plain words. Seen on
    ' the office stick: "(500) Days of Summer" showed text while "180", whose
    ' timings happened to differ, showed its wordmark.
    '
    ' So the page that has its own artwork says so once, and the service half
    ' stops touching the node. Everything else the answer carries — the badges,
    ' the backdrop — is unaffected.
    if ToStr(m.tlPinned) <> "" then return
    path = ToStr(GetField(data, "lg")).trim()
    url = ""
    if path <> "" then url = BackdropUrl(path, TitleLogoSize())
    tlApplyLogoUrl(url)
end sub

' The same thing when the address is already a whole url.
'
' A media server hosts its own lettering — Jellyfin and Emby both answer
' /Items/<id>/Images/Logo, and the tag for it rides in the SAME library read
' the poster's does, so a media-server title's logo costs no request that was
' not already made and no lookup at all. What comes out of MsImageUrl is a
' finished address, not TMDB's short form, so it must not go through
' BackdropUrl — which is the whole reason this half is split out.
'
' Everything below the split is shared and stays shared: the failed-url memory,
' the "hidden until its own load lands" rule, and tlReset putting the words
' back. Both callers therefore behave identically when there is no logo, when
' the picture never arrives, and when it will not decode.
' Put lettering up and keep it there: the caller owns this title's logo and
' the metadata service must not replace it. Clearing happens in tlReset, which
' every page open already runs, so a pin can never outlive its title.
sub tlPinLogoUrl(url as string)
    m.tlPinned = url
    tlApplyLogoUrl(url)
end sub

sub tlApplyLogoUrl(url as string)
    if m.tlLogo = invalid then return
    ' A url this session has already watched fail is not asked for again.
    if url <> "" and m.tlBad <> invalid and m.tlBad[url] <> invalid then url = ""
    if url = ""
        tlReset()
        return
    end if
    if url = ToStr(m.tlLogo.uri) then return
    ' Hidden until its OWN load says it is ready, so the node is never on
    ' screen at the previous title's size.
    m.tlOn = false
    m.tlLogo.visible = false
    m.tlLogo.uri = url
end sub

' The lettering has loaded, or it has not.
'
' READY is where the node finally gets its real size. A title logo can be
' anything from 2:1 to 10:1 and nothing on this box knows which until the bitmap
' is in hand, so the box is worked out here rather than written into the XML.
'
' FAILED is the same contract the Media Bar's has: remember the url for the
' session, take the picture down, let the words come back. The page reads
' correctly without one.
'
' loadStatus fires on EVERY state change, including the blanking this sub itself
' causes, so a blank url leaves immediately and an already-known bad one does
' not re-enter.
' ---- Guarded (v1.0.41) ------------------------------------------------------
'
' THE LAST UNGUARDED DOOR ON THE TWO DETAIL PAGES. The 2026-10-12 sweep wrapped
' every entry point on MovieDetailScreen.brs and SeriesDetailScreen.brs, and
' this one was left over because it is the only one of theirs that does not live
' in their own file - both of them set the observer for it (MovieDetailScreen
' .brs:72, SeriesDetailScreen.brs:81) and the body is here.
'
' WHY IT WAS WORTH COMING BACK FOR, IN PLAIN WORDS. Log key 96C9BD, a TCL
' 43S451 on v1.0.41: the app ran for an hour and a half, the member opened four
' film pages, it idled for eighty-three minutes and then the television stopped
' dead with only "EXIT_BRIGHTSCRIPT_CRASH" written down - no file, no line, no
' function. This is artwork loading on a film page, which is the right SHAPE for
' that crash. THAT IS NOT A CLAIM THAT IT IS THE CAUSE - 96C9BD was not traced
' and probably never will be. It is only that this was the last place on those
' two pages that could not tell us anything.
'
' GuardFailed IS REACHABLE FROM EVERY COMPONENT THAT CAN SEE THIS FILE. Three
' XMLs name RatingBadges.brs - MovieDetailScreen.xml, SeriesDetailScreen.xml
' and PlayerScreen.xml - and all three also name pkg:/source/utils/Util.brs
' (:14, :14 and :96). That had to be checked rather than assumed, because this
' file is SHARED: a sub in here is compiled into every one of those namespaces,
' so a helper that only two of them could resolve would be a landmine waiting
' for the third. GuardFailed sits in the same file as KLog, which this file
' already calls six times, so nothing new was plumbed anywhere.
'
' PLAYERSCREEN IS UNAFFECTED. It can see this sub but never calls it: it does
' not create a titleLogo node and PlayerScreen.brs mentions neither tlLogo nor
' onTitleLogoLoad anywhere. The only change inside its namespace is one extra
' sub it does not call, and a GuardFailed call it can already resolve.
'
' THE LABEL SAYS WHICH PAGE, worked out at the time rather than written in,
' because this one body serves both of them. m.rbWho is this file's own
' identifier for the screen it is drawing into - "movie detail" or "series
' detail", set at MovieDetailScreen.brs:236 and SeriesDetailScreen.brs:164 -
' and it is what every KLog line in here already prefixes with. Hard-coding one
' page's name would mislabel the other one's faults, which is exactly the
' misread-log problem the tag sweep on the film page was fixing.
sub onTitleLogoLoad()
    try
        onTitleLogoLoadInner()
    catch e
        ' The fallback is for a future caller that wires this observer without
        ' setting m.rbWho; the backtrace names this file either way.
        who = ToStr(m.rbWho)
        if who = "" then who = "ratingbadges"
        GuardFailed(who + "/onTitleLogoLoad", e)
        ' FALL BACK TO THE WORDS, which is this handler's own documented FAILED
        ' contract three lines up: take the picture down, let the lettering
        ' come back, the page reads correctly without one. tlReset() is safe to
        ' call from in here - it only touches m.* and its own node, and it
        ' never asks for the scene, which is the thing a catch must not do.
        '
        ' IT ALSO HANDS THE TEXTURE BACK. tlReset() sets m.tlLogo.uri = "",
        ' and that Poster's decode is pinned at 880x260 in both XMLs - 0.87 MB
        ' charged while it is held. On a detail page orphaned on the scene
        ' (AppShell.brs:431-445) that would otherwise sit there for the life of
        ' the app on top of the 5.6 MB backdrop it is already holding.
        '
        ' WHAT THE MEMBER LOSES: a title drawn as lettering instead of as the
        ' show's own logo. If the fault happened after a logo had already been
        ' fitted, this takes a working picture down - a real cost, accepted,
        ' because the alternative is leaving a half-placed image at whatever
        ' size and position the fault interrupted.
        tlReset()
    end try
end sub

sub onTitleLogoLoadInner()
    if m.tlLogo = invalid then return
    status = ToStr(m.tlLogo.loadStatus)
    url = ToStr(m.tlLogo.uri)
    if url = "" then return

    if status = "ready"
        if not tlFitLogo()
            ' Ready, and yet nothing to measure. Nothing should be able to
            ' produce this, which is exactly why the texture is handed back
            ' rather than left held by an invisible node.
            tlReset()
            return
        end if
        m.tlOn = true
        m.tlLogo.visible = true
        if m.tlLabel <> invalid then m.tlLabel.visible = false
        return
    end if

    if status <> "failed" then return
    if m.tlBad = invalid then m.tlBad = {}
    if m.tlBad[url] <> invalid then return
    m.tlBad[url] = true
    ' The ADDRESS is in the line, because "would not load" on its own cannot
    ' tell a TMDB path that 404s apart from a member's own media server
    ' refusing a picture — two completely different faults that read
    ' identically without it. No credential can appear here: a media
    ' server's image addresses carry no token (they need no sign-in at
    ' all) and a TMDB one is a public CDN path.
    KLog("meta", m.rbWho + ": the title logo would not load, showing the title in words - " + url)
    tlReset()
end sub

' The logo's box, from the bitmap's own shape: the largest that fits inside
' m.tlMaxW x m.tlMaxH at the picture's own aspect, centred on m.tlCentre and
' standing on m.tlBottom. Returns false when there is nothing usable to size,
' which the caller treats as "leave the words up".
'
' bitmapWidth/bitmapHeight report the DECODED size, not the file's — the decode
' is pinned in the XML — but the decode preserves aspect, so the ratio is the
' picture's own either way. That is the same thing mediaBarFitLogo relies on.
function tlFitLogo() as boolean
    bw = ToInt(m.tlLogo.bitmapWidth)
    bh = ToInt(m.tlLogo.bitmapHeight)
    if bw <= 0 or bh <= 0 then return false

    w = m.tlMaxW
    h = Int(m.tlMaxW * bh / bw)
    if h > m.tlMaxH
        h = m.tlMaxH
        w = Int(m.tlMaxH * bw / bh)
    end if
    if w < 1 or h < 1 then return false

    m.tlLogo.width = w
    m.tlLogo.height = h
    m.tlLogo.translation = [m.tlCentre - Int(w / 2), m.tlBottom - h]
    return true
end function

' ---- The measurement ---------------------------------------------------------
'
' GAP I1 was sized LARGE with exactly ONE unresolved question — memory headroom
' — and the instruction was to prototype before committing. These console lines
' are how that question gets answered, and they have to come off real hardware:
' the house rule is that a works-on-Roku claim "is only true once seen on the
' real device — console output or screenshot, never 'the code looks right'".
'
' WHAT THE INSTRUMENT CAN SEE. GetMemoryLimitPercent is a whole percent of THIS
' app's heap limit, and that limit is somewhere between about 100 and 190 MB
' depending on the box. One detail page is far under a single count, so the
' honest expectation is that "opened" and "enriched" read the SAME number. That
' is not a failed measurement, it is a bound.
'
' THE NUMBER ACTUALLY WORTH WATCHING is the "opened" line across MANY opens.
' Walk in and out of a dozen titles and read the sequence. Flat is correct.
' Ratcheting upward means something is being retained between pages.
'
' WHAT NO INSTRUMENT HERE CAN SEE, and it matters more now than it did: TEXTURE
' memory is not heap, and roAppMemoryMonitor does not report it at all. The
' ~90 MB texture budget (Util.brs:489-493) is where artwork lives and where all
' five out-of-memory reports came from. These badges used to be text and spent
' none of it; they now spend up to 72.7 KB of it for a full six-chip strip, and
' that number is arithmetic done in the block at the top of this file, not
' something the lines below will ever warn about.
sub rbMemSample(stage as string)
    if m.memMon = invalid then return
    used = m.memMon.GetMemoryLimitPercent()
    if used = invalid then return
    KLog("meta", m.rbWho + " memory [" + stage + "] " + ToInt(used).toStr() + "% of this device's limit")
end sub

' Is this box too close to the edge to spend anything on decoration?
function rbMemoryTight() as boolean
    ' The device's own reading — the same check the media bar drops its artwork
    ' on (Store.brs:3703).
    if MediaBarMemoryTight() then return true
    if m.memMon = invalid then return false
    used = m.memMon.GetMemoryLimitPercent()
    if used = invalid then return false
    ' 70%, the ceiling Search stops loading catalogue at (SearchScreen.brs).
    return ToInt(used) >= 70
end function

' ---- THE HERO ACTION BUTTONS ------------------------------------------------
'
' Android's DetailActionButton, terminal branch (detail_hero.dart
' _buildTerminalButton), drawn for BOTH detail pages out of one copy.
'
' ---- WHY THIS MOVED HERE ----------------------------------------------------
'
' It was written inside MovieDetailScreen.brs on 2026-08-26, because the film
' page was the only page that had it. On 2026-08-27 the owner asked for the
' series page to match, and that is the same fork this file's header describes
' for the badge strip: copy two hundred lines into SeriesDetailScreen.brs, or
' lift them out here and let both components include the file. Two copies of a
' focus ring, a contrast rule and a lift offset is how the two pages quietly
' stop looking like each other, which is the exact complaint this work exists
' to answer.
'
' THE FILM PAGE IS NOW DRAWN BY THIS CODE. The move was mechanical - the same
' nodes, the same numbers, the same order - but it IS the signed-off page's
' button grid, so it wants a look on the television alongside the new series
' page rather than being assumed.
'
' WHAT IS SHARED AND WHAT IS NOT. The DRAWING is shared: the plate, the frame,
' the hard offset shadow, the ink rule, the lift, the centring and the row
' layout. The WORDS are not - which button says "Mark as Watched" and which
' says "Shuffle Episodes" is each page's own business, and a shared function
' that knew both pages' vocabularies would be the coupling this is avoiding.
' So the caller writes b.lbl.text / b.ico.text / b.favInk and then asks for a
' repaint.
'
' WHAT EACH SCREEN SETS UP, in init():
'
'   m.theme           the palette
'   m.hbFont          the button label face
'   m.hbIconFontPri   the icon face on the primary   (Android 19dp -> 38)
'   m.hbIconFont      the icon face on a secondary   (Android 17dp -> 34)
'   m.hbEdgeOnLight   frame/shadow colour on a LIGHT-filled button - the
'                     accent-filled primary and the focusHighlight-filled
'                     focused one both take this
'   m.hbEdgeOnSurface frame/shadow colour on a quiet one
'
' >>> THE FRAME COLOUR IS DERIVED, exactly as Android derives it
' (detailButtonEdge). Nord Shell sets the theme border TO its accent, so an
' accent-filled button would otherwise have a frame and a shadow at 1.00:1
' against itself - a flat slab with no edge anywhere. Android walks the fill
' toward its own ink in 5% steps until it clears 3:1 (WCAG 1.4.11, non-text
' contrast); 13 steps of the page colour into the accent gives 0x4E6572, which
' is 3.1:1 against the accent and 3.9:1 against the focus yellow, so the ONE
' colour clears both light fills. Both pages pass that same pair in. <<<
'
' >>> IT COSTS NOTHING IN TEXTURE. Both plates are nine-patches that already
' ship - card_fill.9.png for the fill and the shadow slab, card_edge.9.png for
' the frame - at 42 x 42 x 4 = 7,056 bytes each, decoded ONCE for the whole app
' however many buttons point at them. Adding a second page of buttons adds no
' image and no decode. <<<

' Android terminal geometry, doubled for a 1080p television, in one place so
' the two pages cannot drift apart on it: actionSpacing 18 -> 36, horizontal
' padding 16/12 -> 32/24, icon gap 8/6 -> 16/12, the hard offset shadow 3 -> 6,
' the focus lift -2 -> -4.
function hbGap() as integer
    return 36
end function

function hbIconW() as integer
    return 44
end function

function hbIconGapPri() as integer
    return 16
end function

function hbIconGapSec() as integer
    return 12
end function

' The widest the secondary row may be before the gaps tighten: the hero
' column's 1824, i.e. 1920 less 48 of title-safe either side.
function hbLane() as integer
    return 1824
end function

' Build one row-0 primary and a centred row-1 of secondaries, and hand back the
' button records the screen keeps in m.buttons.
'
' `specs` is [{ key, text, icon, primary, widest }]. Index 0 is ALWAYS the
' primary and is always alone on row 0; everything after it is row 1, left to
' right. Both pages hand-wired D-pad chains depend on that and on nothing else
' about the list, so a title with a resume point and one without walk
' identically.
'
' `widest` IS THE WIDEST THAT LABEL CAN EVER GET, not what it says now. Three
' of these buttons change their words when they are pressed - Add to Favorites
' becomes Remove from Favorites, five characters longer. Sizing a button to its
' CURRENT text has two faults and the second is the bad one: the row would
' re-flow under the member's hand the moment they pressed anything, and until
' it did the new longer label would overrun the button it is drawn in. Sizing
' to the longer state costs a few pixels of air and makes the row static.
' It also has to be passed IN rather than read off the node, because this
' measures before the screen has written any of the stateful labels.
function hbLayout(col as object, specs as object, priY as integer, priH as integer, priW as integer, secY as integer, secH as integer) as object
    buttons = []
    if specs.count() = 0 then return buttons

    ' Row 0: the primary, centred on the page.
    priX = Int((1920 - priW) / 2)
    buttons.push(hbMakeButton(col, specs[0], priX, priY, priW, priH, m.hbIconFontPri, hbIconGapPri()))

    ' Row 1: each secondary sized to its own widest label, the row centred as a
    ' whole. Measured before any of them is placed, because centring needs the
    ' total first.
    gap = hbGap()
    widths = []
    total = 0
    for i = 1 to specs.count() - 1
        probe = CreateObject("roSGNode", "Label")
        probe.font = m.hbFont
        probe.text = ToStr(specs[i].widest)
        w = Int(probe.boundingRect().width) + 48
        if ToStr(specs[i].icon) <> "" then w = w + hbIconW() + hbIconGapSec()
        widths.push(w)
        total = total + w
    end for
    n = widths.count()
    if n = 0 then return buttons

    total = total + gap * (n - 1)
    ' The row is measured, so it can be CHECKED rather than hoped at. If a
    ' longer set ever arrives the gap tightens before anything runs off the
    ' edge; there is no wrap onto a second row, because a second row would move
    ' whatever sits under the hero.
    if total > hbLane()
        gap = 12
        total = 0
        for each w in widths
            total = total + w
        end for
        total = total + gap * (n - 1)
    end if
    x = Int((1920 - total) / 2)
    if x < 48 then x = 48
    for i = 1 to specs.count() - 1
        w = widths[i - 1]
        buttons.push(hbMakeButton(col, specs[i], x, secY, w, secH, m.hbIconFont, hbIconGapSec()))
        x = x + w + gap
    end for
    return buttons
end function

' One button: the hard offset shadow, the rounded plate, the frame, the icon
' and the label. Five nodes, and every one of them is written BOTH WAYS on
' every repaint - see hbPaint.
'
' THE SHADOW NEVER MOVES. Android translates the button itself by (-2,-2) on
' focus while growing the shadow offset from 3 to 5, so the shadow absolute
' position is identical in both states and the BUTTON is what lifts off it.
' Reproducing that is four translation writes rather than five, and it is what
' makes the effect read as depth instead of as sliding.
' A BUTTON MAY HAVE NO ICON AT ALL, and one on the series page does. The
' Material codepoints this app draws are only ever ones ALREADY PROVEN in the
' package - a wrong codepoint draws the wrong picture and this repo has been
' burned by exactly that (the E1A8/E1B8 note in PlayerScreen.brs) - and there
' is no proven `shuffle` glyph here. The house rule is to say it in words
' rather than guess at a picture, so Shuffle Episodes carries its words alone.
' The icon's width and its gap are then BOTH zero, so the label centres in the
' whole button instead of sitting off to one side of a 44px hole.
function hbMakeButton(col as object, spec as object, x as integer, y as integer, w as integer, h as integer, iconFont as object, iconGap as integer) as object
    iconW = hbIconW()
    if ToStr(spec.icon) = ""
        iconW = 0
        iconGap = 0
    end if
    shadow = col.createChild("Poster")
    shadow.uri = "pkg:/images/card_fill.9.png"
    shadow.width = w
    shadow.height = h
    shadow.translation = [x + 6, y + 6]
    fill = col.createChild("Poster")
    fill.uri = "pkg:/images/card_fill.9.png"
    fill.width = w
    fill.height = h
    edge = col.createChild("Poster")
    edge.uri = "pkg:/images/card_edge.9.png"
    edge.width = w
    edge.height = h
    ico = col.createChild("Label")
    ico.font = iconFont
    ico.width = iconW
    ico.height = h
    ico.horizAlign = "center"
    ico.vertAlign = "center"
    ico.text = spec.icon
    lbl = col.createChild("Label")
    lbl.font = m.hbFont
    lbl.height = h
    lbl.vertAlign = "center"
    lbl.text = spec.text
    return { key: spec.key, primary: spec.primary, shadow: shadow, fill: fill, edge: edge, ico: ico, lbl: lbl, x: x, y: y, w: w, h: h, iconW: iconW, iconGap: iconGap, favInk: false }
end function

' EVERY VISUAL SET BOTH WAYS, EVERY TIME. The fill, the frame, the shadow, the
' ink and the four translations are all written on every branch - a button that
' only ever ran its "focused" arm would keep the accent when the highlight moved
' on, and the highlight is the only thing on these pages telling the member
' where they are.
'
' The caller has already written b.lbl.text, b.ico.text and b.favInk. This does
' not know or care what any of them say.
'
' ==== THE FOCUS FILL IS THE FOCUS COLOUR (2026-08-27) =========================
'
' Reported: "when play, resume or watch now is hovered you cant really tell, we
' should use the orange for hover/highlight". He was right and the cause was
' plain - the primary button was filled with `accent` AT REST and focus filled
' with `accent` TOO, so a 4px lift was the entire difference between "this is
' the main action" and "the remote is on it". From a sofa that is nothing.
'
' So a FOCUSED button now fills with focusHighlight - the nord yellow the owner
' calls orange, the same colour every other focus cue in this app already uses,
' and changing Theme.brs's one line still reskins all of them together.
'
' MEASURED (and the same change Opal made to ChannelDetailScreen the same day,
' so the two pages cannot read a shade apart):
'
'   focused    focusHighlight fill, `background` ink      8.0:1
'   primary    accent fill, `background` ink              6.2:1
'   quiet      surfaceElevated fill, textPrimary ink      7.5:1
'
' THE DARK INK IS NOT OPTIONAL ON EITHER LIGHT FILL. focusHighlight is a LIGHT
' colour; textPrimary on it is about 1.9:1, i.e. unreadable. That is why the
' arms below each write the ink as well as the fill.
'
' THE FRAME AND THE SHADOW DO NOT CHANGE WITH THE FILL, and that is deliberate
' rather than an oversight: the derived edge 0x4E6572 measures 3.9:1 against the
' yellow and 3.1:1 against the accent, so ONE colour clears WCAG 1.4.11's 3:1
' against both fills and there is no second constant for the two pages to drift
' apart on. It is named m.hbEdgeOnLight now rather than m.hbEdgeOnAccent,
' because it is no longer only the accent it sits on.
'
' THREE ARMS, EACH WRITING ALL FOUR VALUES. The old shape wrote the fill in one
' shared "on an accent fill" block and the ink in a second one; that is how a
' button ends up with dark ink stranded on a dark fill when only one of the two
' blocks is reached.
sub hbPaint(buttons as object, focusIdx as integer)
    for i = 0 to buttons.count() - 1
        b = buttons[i]
        focused = (i = focusIdx)

        if focused
            b.fill.blendColor = m.theme.focusHighlight
            b.edge.blendColor = m.hbEdgeOnLight
            b.shadow.blendColor = m.hbEdgeOnLight
            ink = m.theme.background
        else if b.primary
            b.fill.blendColor = m.theme.accent
            b.edge.blendColor = m.hbEdgeOnLight
            b.shadow.blendColor = m.hbEdgeOnLight
            ink = m.theme.background
        else
            b.fill.blendColor = m.theme.surfaceElevated
            b.edge.blendColor = m.hbEdgeOnSurface
            b.shadow.blendColor = m.hbEdgeOnSurface
            ' The favourite colour on a favourited button that does not
            ' currently hold the highlight; textPrimary otherwise.
            if b.favInk = true
                ink = m.theme.favorite
            else
                ink = m.theme.textPrimary
            end if
        end if
        b.lbl.color = ink
        b.ico.color = ink

        ' ---- the lift, and the shadow it lifts off --------------------------
        ' The shadow own translation was fixed at build time and is never
        ' touched again; only the four nodes ON it move.
        if focused
            dx = b.x - 4
            dy = b.y - 4
        else
            dx = b.x
            dy = b.y
        end if
        b.fill.translation = [dx, dy]
        b.edge.translation = [dx, dy]
        ' The icon and the label sit as one block, centred together inside the
        ' button - Android centres its Row the same way. Measured here rather
        ' than at build time because the stateful labels change width when
        ' their state changes, and a block centred on the old text would sit
        ' off to one side.
        tw = Int(b.lbl.boundingRect().width) + b.iconW + b.iconGap
        tx = dx + Int((b.w - tw) / 2)
        if tx < dx + 12 then tx = dx + 12
        b.ico.translation = [tx, dy]
        b.lbl.translation = [tx + b.iconW + b.iconGap, dy]
    end for
end sub


' ---- THE METADATA CHIP ROW --------------------------------------------------
'
' Android's MetaChip row (detail_hero.dart: the Wrap under the title), drawn
' for BOTH detail pages out of one copy - same reason as the buttons above and
' the badge strip at the top of this file.
'
' `defs` is [{ text, icon, dot }] - icon and dot are "" when there is none.
' WHAT each page puts in the row is each page's own business (the film page
' says year / genre / runtime / ends-at, the series page says year / seasons
' and episodes); the measuring, the centring and the plate are shared.
'
' WHAT EACH SCREEN SETS UP, in init():
'
'   m.theme         the palette
'   m.chipFont      the chip label face
'   m.chipIconFont  the icon face inside a chip
'   m.chipFill      the plate colour (the theme surfaceElevated at 85%)
'
' The row is CENTRED, so it is measured before anything is created - centring
' needs the total before the first chip can be positioned. Two passes over a
' handful of chips.
sub hcDrawChips(grp as object, defs as object)
    while grp.getChildCount() > 0
        grp.removeChildIndex(0)
    end while
    if defs.count() = 0 then return
    ' Android: 10dp/4dp padding, 8dp dot + 5dp gap, 14dp icon + 4dp gap, all
    ' doubled. The chip is 50 tall, which is the row the hero reserves.
    padX = 20
    dotW = 16
    dotGap = 10
    iconW = 28
    iconGap = 8
    gap = 16
    chipH = 50

    ' Measure first, then place, because the row is CENTRED and centring needs
    ' the total before the first chip can be positioned.
    widths = []
    total = 0
    for each d in defs
        probe = CreateObject("roSGNode", "Label")
        probe.font = m.chipFont
        probe.text = d.text
        w = Int(probe.boundingRect().width) + padX * 2
        if d.dot <> "" then w = w + dotW + dotGap
        if d.icon <> "" then w = w + iconW + iconGap
        widths.push(w)
        total = total + w
    end for
    total = total + gap * (defs.count() - 1)
    ' A tighter gap before anything runs off the edge. 1824 is the hero
    ' column's own width (1920 less Android's 24dp -> 48px each side).
    if total > 1824
        gap = 8
        total = 0
        for each w in widths
            total = total + w
        end for
        total = total + gap * (defs.count() - 1)
    end if

    x = Int((1920 - total) / 2)
    if x < 48 then x = 48
    for i = 0 to defs.count() - 1
        d = defs[i]
        w = widths[i]
        ' The plate. card_fill.9.png, not a Rectangle: Roku cannot round a
        ' Rectangle, and this file is already resident for every card in the
        ' app - 42 x 42 x 4 = 7,056 bytes ONCE, however many chips are drawn.
        plate = grp.createChild("Poster")
        plate.uri = "pkg:/images/card_fill.9.png"
        plate.width = w
        plate.height = chipH
        plate.translation = [x, 0]
        plate.blendColor = m.chipFill
        tx = x + padX
        if d.dot <> ""
            ' circle.png with NO loadWidth/loadHeight on purpose: it is already
            ' decoded once for the app (the poster hearts use it), and pinning
            ' a size here would make a second cache entry for a texture the app
            ' already holds.
            dot = grp.createChild("Poster")
            dot.uri = "pkg:/images/circle.png"
            dot.width = dotW
            dot.height = dotW
            dot.translation = [tx, Int((chipH - dotW) / 2)]
            dot.blendColor = d.dot
            tx = tx + dotW + dotGap
        end if
        if d.icon <> ""
            ico = grp.createChild("Label")
            ico.font = m.chipIconFont
            ico.color = m.theme.accent
            ico.text = d.icon
            ico.width = iconW
            ico.height = chipH
            ico.horizAlign = "center"
            ico.vertAlign = "center"
            ico.translation = [tx, 0]
            tx = tx + iconW + iconGap
        end if
        lbl = grp.createChild("Label")
        lbl.font = m.chipFont
        lbl.color = m.theme.textPrimary
        lbl.text = d.text
        lbl.height = chipH
        lbl.vertAlign = "center"
        lbl.translation = [tx, 0]
        x = x + w + gap
    end for
end sub

' The source colour for this title's chip dot, or "" for no dot.
'
' Android's rule, the same one the poster tags and the VOD chip row follow:
' "The colour arrives as a dot and only as a dot." The member's own painted
' colour first (KwickSync, resolved once per cycle into m.global.srcColorIdx),
' this app's hashed guess second, and `mark` rather than `bg` so a source is
' the same pixel value here as it is on its poster.
'
' Called ONCE per page open, not per bind - neither detail page has recycled
' cards.
'
' NAMED hc* RATHER THAN srcDotColor, which is what it was called when it lived
' in MovieDetailScreen.brs. ChannelCard.brs and PosterCard.brs each carry their
' own srcDotColor(c) taking an argument; neither of them includes this file, so
' there is no collision today, but a same-named function with a different arity
' three components away is a trap waiting for whoever adds the fourth.
function hcSrcDotColor() as string
    if m.itemSrc = invalid then return ""
    tok = ToStr(m.itemSrc)
    k = "t" + tok
    if m.global <> invalid and m.global.hasField("srcColorIdx")
        idx = m.global.srcColorIdx
        if idx <> invalid
            if idx.doesExist(k) then return idx[k].mark
        end if
    end if
    return SrcColorsFor(tok).mark
end function


' ---- THE DESCRIPTION, AND THE PANEL THAT READS ALL OF IT ---------------------
'
' Reported by the owner (2026-08-27): "the details of the content sometimes are
' long and have '...' but there is no way to highlight and click it to expand or
' collapse". There is NO Android counterpart to port - DetailTextBox over there
' is static and never expands - so this is Roku's own, written once here and
' drawn identically by both detail pages.
'
' WHAT THE MEMBER SEES. The synopsis block on the page becomes a focus stop. It
' wears the always-on frost frame every card in this app already wears, that
' frame goes to focusHighlight when the highlight is on it, and beside (or
' under) the words sits a plate that SAYS WHAT THE PRESS DOES - "Press OK to
' read it all". Words rather than a bare "...", which is the house rule and the
' same correction the episode rows already took: an ellipsis the member has to
' interpret is a support ticket.
'
' AN OVERLAY, NOT A REFLOW. Expanding the block in place would move the action
' row under the member's hand between one frame and the next, and directional
' focus on Roku is decided purely by geometry - the highlight would go somewhere
' neither of us chose. The panel is built ONCE, in dpBuild() at init, and the
' press only makes it visible, so everything it shows exists in its final
' position on the very next frame.
'
' BACK COLLAPSES IT, AND ONLY CLOSES THE PAGE WHEN IT IS SHUT. dpKey() is asked
' FIRST by both screens' onKeyEvent and swallows every key while the panel is
' up, so nothing behind it can move while the member is reading.
'
' >>> IT COSTS NO NEW TEXTURE AT ALL. The dimmer is a Rectangle and spends
' nothing. The panel, its frame and the caption plate are card_fill.9.png and
' card_edge.9.png - 42 x 42 x 4 = 7,056 bytes each, decoded ONCE for the whole
' app however many nodes point at them, and every detail page already draws both
' for its buttons and its chips. No new image, no new decode, nothing added to
' the 4 MB certification budget. The three faces are ones the calling screen
' already uses, so there is no new glyph atlas either. <<<
'
' WHAT EACH SCREEN SETS UP, in init(), BEFORE calling dpBuild():
'
'   m.theme        the palette
'   m.dpHeadFont   the panel heading face   (each page bold 28)
'   m.dpBodyFont   the panel body face      (each page own plot face)
'   m.dpBodySize   that face point size, for the fallback measurement
'   m.dpHintFont   the panel footer face
'
' and, from its OWN xml, the three nodes that make the block a focus stop:
'
'   m.dpFrame      the frame around the synopsis block
'   m.dpCapPlate   the caption plate
'   m.dpCap        the caption label
'
' m.dpOn says whether there is anything to read at all. It is written on EVERY
' bind, both ways - a page whose details never arrive must not leave a focus
' stop the member can walk into and find empty.

' The panel own geometry, in one place. Inside the 54..1026 title-safe band with
' room to spare, and centred on the page like everything else these pages draw.
function dpPanelX() as integer
    return 180
end function

function dpPanelW() as integer
    return 1560
end function

' The reading window: where the words are, and how much of them is on screen.
function dpTextX() as integer
    return 220
end function

function dpTextY() as integer
    return 212
end function

function dpTextW() as integer
    return 1480
end function

function dpTextH() as integer
    return 660
end function

' One press of Up or Down. Three lines of the body face, near enough, on either
' page - small enough not to lose the reader place, big enough that a long
' synopsis does not take twenty presses.
function dpStep() as integer
    return 120
end function

' Build the panel once. Appended LAST so it draws over everything the page
' already has, and left invisible until something asks for it.
sub dpBuild()
    root = m.top.createChild("Group")
    root.visible = false
    m.dpRoot = root

    ' The page, taken right down. Not a texture - a Rectangle costs nothing at
    ' all, and there is no gradient to fake here.
    wash = root.createChild("Rectangle")
    wash.width = 1920
    wash.height = 1080
    wash.color = Left(m.theme.background, 8) + "E6"

    plate = root.createChild("Poster")
    plate.uri = "pkg:/images/card_fill.9.png"
    plate.width = dpPanelW()
    plate.height = 840
    plate.translation = [dpPanelX(), 120]
    plate.blendColor = m.theme.surface

    edge = root.createChild("Poster")
    edge.uri = "pkg:/images/card_edge.9.png"
    edge.width = dpPanelW()
    edge.height = 840
    edge.translation = [dpPanelX(), 120]
    edge.blendColor = m.theme.surfaceBorder

    head = root.createChild("Label")
    head.font = m.dpHeadFont
    head.color = m.theme.textPrimary
    head.width = dpTextW()
    head.height = 44
    head.translation = [dpTextX(), 152]
    head.maxLines = 1
    m.dpHead = head

    ' THE WINDOW SITS AT [0, 0] ON PURPOSE. clippingRect coordinate space is the
    ' one thing about that field worth being careful of, and at translation
    ' [0, 0] the two candidate readings are the same rectangle, so the question
    ' cannot be gotten wrong. The Media Bar backdrop window makes the same
    ' choice for the same reason (MediaBar.xml). If this Group is ever moved,
    ' that stops being true.
    win = root.createChild("Group")
    win.translation = [0, 0]
    win.clippingRect = [dpTextX(), dpTextY(), dpTextW(), dpTextH()]
    m.dpWin = win

    ' NO height, so the Label sizes itself to the whole synopsis; the window
    ' above is what decides how much of it is visible, and dpScrollTo moves the
    ' Label inside it.
    body = win.createChild("Label")
    body.font = m.dpBodyFont
    body.color = m.theme.textPrimary
    body.width = dpTextW()
    body.wrap = true
    body.lineSpacing = 8
    body.translation = [dpTextX(), dpTextY()]
    m.dpBody = body

    hint = root.createChild("Label")
    hint.font = m.dpHintFont
    hint.color = m.theme.textSecondary
    hint.width = dpTextW()
    hint.height = 36
    hint.translation = [dpTextX(), 890]
    hint.maxLines = 1
    m.dpHint = hint

    m.dpOpen = false
    m.dpScroll = 0
    m.dpMax = 0
    m.dpFocus = false
    if m.dpOn = invalid then m.dpOn = false
end sub

' The words this page is about, written on EVERY bind and both ways: a title
' whose details never arrive gets an empty string here, m.dpOn goes false with
' it, and the block stops being a focus stop rather than becoming an empty one.
'
' `heading` is what the panel calls itself - the title own name, so the member
' can see whose description they are reading.
sub dpSetText(heading as string, s as string)
    if m.dpBody = invalid then return
    m.dpBody.text = s
    ' ToStr() around both before .trim(): the same shape rbClean and tlApplyLogo
    ' use, rather than calling a method straight off a declared-string parameter.
    m.dpOn = (ToStr(s).trim() <> "")
    hd = ToStr(heading).trim()
    if hd = "" then hd = "Description"
    m.dpHead.text = hd
    m.dpScroll = 0
    dpMeasure()
    dpScrollTo(0)
    ' The footer says which keys do what, and it says it BOTH WAYS - a synopsis
    ' that fits must not promise a scroll that does nothing.
    if m.dpMax > 0
        m.dpHint.text = "Up and Down to scroll     OK or Back to close"
    else
        m.dpHint.text = "OK or Back to close"
    end if
    ' A page rebinding while the panel is up would leave the member looking at
    ' someone else words. Nothing on either page can do that today - both bind
    ' before the panel is reachable - but it costs one line to be certain of.
    if m.dpOpen and not m.dpOn then dpClose()
end sub

' How tall the whole synopsis is, and therefore how far it can scroll.
'
' The Label own boundingRect is the real answer and is used whenever it gives
' one. The arithmetic below is the fallback for the case where it does not:
' JetBrains Mono is a flat 0.6em, so characters-per-line is division rather than
' a guess - the same "estimate, then let the Label do the real wrapping"
' arrangement mdValueLines uses on the film page information table. Preferring
' the measurement matters: the estimate cannot see where words actually wrap, so
' it over-counts, and using it when a real number exists would scroll the reader
' off the end into blank space.
sub dpMeasure()
    h = 0
    if m.dpBody <> invalid then h = Int(m.dpBody.boundingRect().height)
    if h <= 0
        adv = Int(m.dpBodySize * 0.6)
        if adv < 1 then adv = 1
        per = Int(dpTextW() / adv)
        if per < 1 then per = 1
        lines = Int(Len(ToStr(m.dpBody.text)) / per) + 1
        h = lines * (m.dpBodySize + 15)
    end if
    m.dpMax = h - dpTextH()
    if m.dpMax < 0 then m.dpMax = 0
end sub

sub dpScrollTo(y as integer)
    if m.dpBody = invalid then return
    if y < 0 then y = 0
    if y > m.dpMax then y = m.dpMax
    m.dpScroll = y
    m.dpBody.translation = [dpTextX(), dpTextY() - y]
end sub

' Open, and the measurement that goes with it. Measured again here rather than
' trusted from bind time: the Label has certainly laid itself out by now, so
' this is where a real boundingRect replaces the fallback estimate.
sub dpShow()
    if m.dpRoot = invalid or not m.dpOn then return
    dpMeasure()
    dpScrollTo(0)
    if m.dpMax > 0
        m.dpHint.text = "Up and Down to scroll     OK or Back to close"
    else
        m.dpHint.text = "OK or Back to close"
    end if
    m.dpRoot.visible = true
    m.dpOpen = true
end sub

sub dpClose()
    if m.dpRoot = invalid then return
    m.dpRoot.visible = false
    m.dpOpen = false
end sub

function dpIsOpen() as boolean
    return (m.dpOpen = true)
end function

' Every key while the panel is up, and it swallows all of them: nothing behind
' an open panel may move.
function dpKey(key as string) as boolean
    if not dpIsOpen() then return false
    if key = "back" or key = "OK"
        dpClose()
    else if key = "down"
        dpScrollTo(m.dpScroll + dpStep())
    else if key = "up"
        dpScrollTo(m.dpScroll - dpStep())
    end if
    return true
end function

' The block on the page, painted BOTH WAYS on every call: the frame colour, the
' caption plate fill and the caption ink, plus whether any of it is drawn at
' all. A block with nothing to read shows no frame and no caption, so there is
' never a focus stop advertising an empty panel.
'
' focusHighlight on the frame is the SAME cue the posters, the channel tiles and
' the buttons use; cardIdleBorder is the same resting frost frame an unfocused
' card wears. Nothing new was invented for this.
sub dpPaintBlock(focused as boolean)
    if m.dpFrame = invalid then return
    on = (m.dpOn = true)
    m.dpFrame.visible = on
    m.dpCapPlate.visible = on
    m.dpCap.visible = on
    if focused and on
        m.dpFrame.blendColor = m.theme.focusHighlight
        m.dpCapPlate.blendColor = m.theme.focusHighlight
        ' The page colour on the focus yellow, 8.0:1 - the same pairing the
        ' focused button uses, and for the same reason: focusHighlight is a
        ' LIGHT colour and textPrimary on it is about 1.9:1.
        m.dpCap.color = m.theme.background
    else
        m.dpFrame.blendColor = m.theme.cardIdleBorder
        m.dpCapPlate.blendColor = m.theme.surfaceElevated
        m.dpCap.color = m.theme.textSecondary
    end if
    m.dpFocus = focused
end sub

' The caption words. One string, in one place, so the two pages cannot end up
' telling the member two different things about the same press.
function dpCaptionText() as string
    return "Press OK to read it all"
end function
