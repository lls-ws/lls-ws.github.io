' Guide genre buckets — port of the Android guideMetaCategory classifier
' (lib/data/viewmodels/guide_meta_categories.dart). Sums the provider's many
' raw groups ("CA | NEWS", "USA NEWS"...) into clean tabs. Cosmetic only;
' Live TV keeps the raw categories, exactly like Android.

' Tab order, left to right, after the All tab the guide adds itself.
' 24/7 sits near the end, between Music and Other — owner's call. It is NOT
' the same thing as the rule order below, which is about classification and
' does still test 24/7 first.
function GuideMetaOrder() as object
    return ["News", "Sports", "PPV", "Movies", "Entertainment", "Kids & Family", "Documentary", "Music", "24/7", "Faith", "Adult", "Other"]
end function

' First match wins (News beats network keywords), same order as Android.
' ORDER IS LOAD-BEARING, twice over:
'   · 24/7 must be tested FIRST. A loop channel is sorted by BEING a loop,
'     not by what it loops — "24/7 CARTOONS" used to match CARTOON and file
'     under Kids & Family, "24/7 MOVIES" under Movies, and so on, which
'     emptied the 24/7 tab of exactly the channels it exists for.
'   · PPV must be tested BEFORE Sports, or a category named both
'     ("USA PPV SPORTS") lands in Sports — exactly the groups the split was
'     meant to pull out.
' This is an array, not an associative array, so the order is guaranteed.
function GuideMetaRules() as object
    return [
        { name: "24/7", words: ["24/7", "24-7", "24 7"] },
        { name: "News", words: ["NEWS", "WEATHER"] },
        { name: "PPV", words: ["PPV", "PAY PER VIEW", "PAY-PER-VIEW", "PAYPERVIEW"] },
        { name: "Sports", words: ["SPORT", "ESPN", "NFL", "NBA", "MLB", "NHL", "UFC", "FIGHT", "BOXING", "WWE", "GOLF", "SOCCER", "FOOTBALL", "FUTBOL", "RACING", "MOTOR", "DAZN", "BEIN", "TENNIS", "CRICKET", "RUGBY", "ATHLETIC"] },
        { name: "Kids & Family", words: ["KID", "CARTOON", "NICK", "DISNEY", "FAMILY", "JUNIOR", "BABY", "ANIME"] },
        { name: "Movies", words: ["MOVIE", "CINEMA", "FILM", "BOX OFFICE", "HBO", "CINEMAX", "STARZ", "SHOWTIME", "MGM"] },
        { name: "Music", words: ["MUSIC", "MTV", "VEVO", "RADIO", "HITS"] },
        { name: "Documentary", words: ["DOCU", "DISCOVER", "HISTORY", "NAT GEO", "NATGEO", "NATURE", "SCIENCE", "CRIME", "INVESTIGAT"] },
        { name: "Faith", words: ["RELIGIO", "FAITH", "CHURCH", "GOSPEL", "CHRISTIAN"] },
        { name: "Adult", words: ["ADULT", "XXX"] },
        { name: "Entertainment", words: ["ENTERTAIN", "GENERAL", "VARIETY", "LIFESTYLE", "REALITY", "COMEDY", "DRAMA", "SERIES", "SHOWS", "NETWORK", "LOCAL", "FOOD", "COOKING", "TRAVEL", "HOME"] }
    ]
end function

function GuideMetaCategory(groupName as string) as string
    if groupName = "" then return "Other"
    g = UCase(groupName)
    for each rule in GuideMetaRules()
        for each word in rule.words
            if g.instr(0, word) > -1 then return rule.name
        end for
    end for
    return "Other"
end function

' Does this CHANNEL's name say pay-per-view?
' Needed because this service's provider gives PPV no category of its own —
' the events sit inside ordinary sports categories ("CA | SPORTS") and only
' the channel name says PPV ("PPV: UFC 300"). A category-only rule matches
' nothing here.
function LooksPpv(channelName as string) as boolean
    if channelName = "" then return false
    n = UCase(channelName)
    for each word in ["PPV", "PAY PER VIEW", "PAY-PER-VIEW", "PAYPERVIEW"]
        if n.instr(0, word) > -1 then return true
    end for
    return false
end function

' Bucket for one channel. Channel names are noisy, so ONLY PPV is allowed to
' win on the channel name — every other bucket still comes from the category,
' otherwise things like "Sports News Tonight" would jump tabs unpredictably.
function GuideMetaCategoryForChannel(groupName as string, channelName as string) as string
    if LooksPpv(channelName) then return "PPV"
    return GuideMetaCategory(groupName)
end function

' ---- Adult categories (certification 6.3) -----------------------------------
' Roku certification 6.3 forbids pornographic content. Parental controls in
' this app are opt-in and off out of the box, so a fresh install pointed at a
' provider that carries adult groups used to put an Adult tab in front of
' whoever turned the box on. Now an Adult-classified category is hidden
' EVERYWHERE unless AdultCatsAllowed() (Store.brs) says the member set a
' parental PIN and switched it on in Settings. Once it is on, the ordinary
' hide/lock rules govern and nothing here gets in the way.
'
' There is no single choke point that sees every category list — the guide
' classifies its own tabs and never calls ApplyCatPrefs, and Search holds raw
' catalog rows — so this is applied at each consumer. All of them:
'   · LiveTvScreen.mergeLiveCategories   (merged live categories)
'   · VodScreen.mergeVodCategories       (movie + series category strip)
'   · VodScreen.loadItems                (the All grid, which asks a source
'                                         for its WHOLE catalog — dropped
'                                         again by name inside VodContentTask)
'   · GuideScreen.mergeGuideCategories   (genre tabs AND the All tab)
'   · ReorderCategoriesScreen            (so the names stay off screen too)
'   · SearchScreen.onList / onM3uList    (results)
'   · HomeScreen.startPicks              (Kwick Picks' excluded categories)
' ADD ANY NEW CATEGORY LIST TO THAT LIST.
'
' Since the parental-gate block further down, the guide and Search reach this
' rule through ParentalGate()/ParentalAllowsCat() rather than calling
' IsAdultCatName themselves — the adult test is one of the three tests that
' helper makes. New screens should use the helper and not add a fourth
' hand-written copy of the rule.
function IsAdultCatName(name as string) as boolean
    return GuideMetaCategory(name) = "Adult"
end function

' Drops every Adult-classified entry from a [{id,name}] category list.
' Returns the list untouched when the member has allowed them.
function FilterAdultCats(cats as object) as object
    if AdultCatsAllowed() then return cats
    out = []
    for each c in cats
        if not IsAdultCatName(ToStr(c.name)) then out.push(c)
    end for
    return out
end function

' ---- Parental gate: ONE shared filter + PIN prompt --------------------------
'
' WHY THIS EXISTS. Before this, the parental locks were enforced in exactly
' three places — LiveTvScreen (its category list), VodScreen (its category
' strip) and HomeScreen (the Kwick Picks row) — and every one of them had
' written the rule out again by hand. Any screen that built its own lists
' therefore enforced nothing: the TV Guide classifies its own tabs and never
' calls ApplyCatPrefs, and Search holds whole raw catalogues. A PIN-locked
' channel opened from the guide, or a locked film found by searching for it,
' played with no PIN asked for at all.
'
' So the rule lives here now, once, next to the classifier it already needs.
' It is the SAME machinery the three screens use — the same registry keys,
' the same session unlock, the same PinDialog — deliberately NOT a second
' PIN system.
'
' THE RULE, in plain words:
'   · Locks are per CATEGORY, not per channel, and per profile. A category
'     name is either locked or it isn't (Store: LoadLockedCats / "cat_locked_").
'   · The lock MODE decides what a locked category looks like:
'       "hide" (the default) — it vanishes.
'       "pin"               — it stays on screen and asks for the PIN when
'                             it is opened.
'   · One correct PIN unlocks EVERY locked category until the app is closed
'     (Store: ParentalUnlocked / SetParentalUnlocked, cleared at launch).
'   · Adult categories (Roku certification 6.3) are a SEPARATE, stricter
'     rule that sits on top: unless AdultCatsAllowed() they are dropped
'     everywhere, and no PIN prompt gets you in — the switch is in Settings.
'   · Hidden categories and hidden channels are the member's own decluttering
'     and are simply left out, the same way LiveTvScreen leaves them out.
'
' HOW TO USE IT. Two moves, and every caller does one or both:
'   FILTER — building a list:
'       gate = ParentalGate("live")                    ' once per list build
'       if not ParentalAllowsCat(gate, catName, true) then continue for
'   GATE   — about to play, or about to open a detail screen:
'       if ParentalGuard(m.top, "movies", catName, "onParentalPin", "onParentalPinCancel") <> "allow" then return
'     plus the two small callbacks (see ParentalGuard's own comment).
'
' PERFORMANCE. ParentalGate() reads the registry a fixed handful of times —
' NOT once per row. The audit found per-tile registry reads are "a visible
' stutter on a stick" (Store.brs, RefreshFavVodIndex), so build the gate once
' per query or per tab build and then read it as many times as you like.

' Everything the lock rules need, read ONCE — the adult switch, whether a PIN
' exists, the session flag, the lock mode, and the hidden and locked category
' lists. About a dozen registry reads all told (each Store getter also pays
' for ProfileScopeSuffix), which is a fixed cost paid once per list build
' instead of a growing one paid per row. Hold it for the whole build; throw
' it away after — it is a snapshot, not live state.
function ParentalGate(scope as string) as object
    g = {
        scope: scope
        adultOk: AdultCatsAllowed()
        unlocked: ParentalUnlocked()
        mode: ParentalMode()
        hidden: {}          ' lowercased category name -> true
        locked: {}          ' lowercased category name -> true (empty if unlocked)
        blockedIds: {}      ' "scope|provId|strict" -> { catId: true }
        hiddenChans: {}     ' provId -> { streamId: true }
        suffix: ProfileScopeSuffix()
        kin: {}             ' other scopes, built on demand — see ParentalGateFor
    }
    for each h in LoadHiddenCats(scope)
        g.hidden[LCase(ToStr(h))] = true
    end for
    ' Nothing is locked once the session is unlocked, so don't even load it.
    if not g.unlocked
        for each l in LoadLockedCats(scope)
            g.locked[LCase(ToStr(l))] = true
        end for
    end if
    return g
end function

' What should happen to one category, by name:
'   "show" — nothing in the way.
'   "gate" — it may be listed, but opening it must ask for the PIN first
'            (this is "pin" mode).
'   "drop" — it must not appear at all: an adult category with the switch
'            off, a hidden category, or a locked one in "hide" mode.
function ParentalCatVerdict(gate as object, catName as string) as string
    if catName = "" then return "show"
    if not gate.adultOk and IsAdultCatName(catName) then return "drop"
    k = LCase(catName)
    if gate.hidden.doesExist(k) then return "drop"
    if gate.locked.doesExist(k)
        if gate.mode = "hide" then return "drop"
        return "gate"
    end if
    return "show"
end function

' The filtering shorthand: false means "leave it out of this list".
'
' strict = true also drops the "gate" case, and is for lists with nowhere
' sensible to put a PIN prompt — search results, the Multi-View picker, a
' recommendations row. That is the call HomeScreen's picks and MultiViewPicker
' already make in their own words: left out entirely rather than shown and
' then refused. strict = false keeps it, for a list whose screen WILL prompt
' on open (LiveTvScreen's category list, VodScreen's strip).
function ParentalAllowsCat(gate as object, catName as string, strict = false as boolean) as boolean
    v = ParentalCatVerdict(gate, catName)
    if v = "drop" then return false
    if v = "gate" and strict then return false
    return true
end function

' The same question for a panel row, which carries a numeric category_id and
' no name. Returns that source+scope's set of category ids to drop, built
' once and remembered on the gate.
'
' HONEST LIMITATION, inherited unchanged from Search and MultiViewPicker: the
' names come from the id->name cache that LiveTvScreen / VodScreen /
' GuideScreen write whenever they fetch a source's categories. A member who
' opens Search (or any other id-only list) FIRST on a brand-new install has
' no cache yet, so nothing is matched that time. It filters from the next
' launch, after anything has been browsed. Fetching category lists here
' instead is what put small Rokus over the memory limit in the first place.
function ParentalBlockedCatIds(gate as object, scope as string, provId as string, strict = true as boolean) as object
    strictKey = "loose"
    if strict then strictKey = "strict"
    key = scope + "|" + provId + "|" + strictKey
    if gate.blockedIds.doesExist(key) then return gate.blockedIds[key]
    ' Scoped gates: a "movies" list must be tested against the movies locks.
    sg = ParentalGateFor(gate, scope)
    ids = {}
    ' Nothing to block at all — skip the cache read entirely.
    if sg.adultOk and sg.hidden.count() = 0 and sg.locked.count() = 0
        gate.blockedIds[key] = ids
        return ids
    end if
    cache = loadCatNameCache(scope, provId)
    for each cid in cache
        if not ParentalAllowsCat(sg, ToStr(cache[cid]), strict) then ids[ToStr(cid)] = true
    end for
    gate.blockedIds[key] = ids
    return ids
end function

' A gate for another scope, sharing this one's caches. Search asks about
' three scopes at once ("live", "movies", "series") and should not pay for
' three separate reads of the switches that are the same for all of them.
' A sub-gate carries its OWN (empty) kin map rather than a link back to its
' parent. That is not tidiness: a child holding its parent would be a
' reference cycle, and BrightScript frees by reference count — the whole gate
' would leak, once per screen the member opens.
function ParentalGateFor(gate as object, scope as string) as object
    if scope = gate.scope then return gate
    if gate.kin.doesExist(scope) then return gate.kin[scope]
    g = {
        scope: scope
        adultOk: gate.adultOk
        unlocked: gate.unlocked
        mode: gate.mode
        hidden: {}
        locked: {}
        blockedIds: gate.blockedIds
        hiddenChans: gate.hiddenChans
        suffix: gate.suffix
        kin: {}
    }
    for each h in LoadHiddenCats(scope)
        g.hidden[LCase(ToStr(h))] = true
    end for
    if not g.unlocked
        for each l in LoadLockedCats(scope)
            g.locked[LCase(ToStr(l))] = true
        end for
    end if
    gate.kin[scope] = g
    return g
end function

' Channels the member has hidden in Settings. Loaded once per SOURCE, never
' per channel — the same rule ApplyChannelPrefs follows. (ApplyChannelPrefs
' itself is no use in a catalogue loop: it also sorts, and its insertion sort
' over thousands of rows would stall the render thread.)
function ParentalChannelHidden(gate as object, provId as string, streamId as string) as boolean
    if streamId = "" then return false
    if not gate.hiddenChans.doesExist(provId)
        hset = {}
        for each h in LoadJsonArray("chan_hidden_" + provId + gate.suffix)
            hset[ToStr(h)] = true
        end for
        gate.hiddenChans[provId] = hset
    end if
    return gate.hiddenChans[provId].doesExist(streamId)
end function

' ---- The gate half: check, and prompt if a PIN is what's missing -----------
'
' THE entry point for "may this open right now?". Call it the moment before
' playback starts, or before a detail screen is pushed. It answers:
'   "allow"   — go ahead.
'   "asked"   — the PIN pad is now on screen. Return; your onAccept callback
'               runs if the member gets it right.
'   "blocked" — an adult category with the switch off. There is no PIN for
'               this; say so or back out quietly.
'
' The caller supplies the names of two of its own subs, and they run in the
' calling screen's own context (a global function shares the caller's `m`,
' which is also why `m.pinDialog` below lands on the screen, exactly where
' LiveTvScreen and VodScreen already keep theirs):
'
'   sub onParentalPin()
'       if ParentalAcceptPin()
'           reloadWhateverThisScreenShows()   ' locks are gone for the session
'       else
'           ParentalWrongPinNote(m.top, "onParentalPinNote")
'       end if
'   end sub
'   sub onParentalPinCancel()
'       ParentalClosePin()
'       m.whatever.setFocus(true)
'   end sub
'   sub onParentalPinNote()
'       m.top.getScene().dialog.close = true
'       m.whatever.setFocus(true)
'   end sub
'
' FOR THE DETAIL SCREENS (MovieDetail / SeriesDetail / ChannelDetail): pass
' the title's own category name and the matching scope ("movies", "series",
' "live"). Nothing else needs to change there — this is the whole gate.
' A locked category still prompts even in "hide" mode, because a detail
' screen can be reached from a favourite or Continue Watching where the
' hiding never applied, and a dead end with no way in would be worse.
function ParentalGuard(screen as object, scope as string, catName as string, onAccept as string, onCancel as string) as string
    gate = ParentalGate(scope)
    return ParentalGuardWith(gate, screen, catName, onAccept, onCancel)
end function

' Same thing when the caller already holds a gate (a list build that gates
' on open, so it doesn't re-read the registry for every press).
function ParentalGuardWith(gate as object, screen as object, catName as string, onAccept as string, onCancel as string) as string
    v = ParentalCatVerdict(gate, catName)
    if v = "show" then return "allow"
    ' Locked is the one thing a PIN can fix — in either mode.
    if gate.locked.doesExist(LCase(catName))
        ParentalShowPin(screen, onAccept, onCancel)
        return "asked"
    end if
    ' Adult with the switch off, or a category the member hid themselves.
    ' Hiding is their own choice, so let it through rather than dead-end.
    if not gate.adultOk and IsAdultCatName(catName) then return "blocked"
    return "allow"
end function

' Raise the shared 4-digit PIN pad. Same node, same title and same two
' signals the three enforcing screens already use.
sub ParentalShowPin(screen as object, onAccept as string, onCancel as string)
    kb = CreateObject("roSGNode", "PinDialog")
    kb.title = "Enter PIN"
    kb.observeField("accepted", onAccept)
    kb.observeField("cancelled", onCancel)
    m.pinDialog = kb
    ' The scene's dialog slot, not a child — see PinDialog. Only the slot
    ' makes it modal, focused and closable with Back.
    screen.getScene().dialog = kb
end sub

' Read what was typed, close the pad, and unlock the session if it was right.
' True means the member is now unlocked and the screen should reload.
function ParentalAcceptPin() as boolean
    ok = false
    if m.pinDialog <> invalid
        if CheckParentalPin(ToStr(m.pinDialog.value))
            SetParentalUnlocked(true)
            ok = true
        end if
    end if
    ParentalClosePin()
    return ok
end function

sub ParentalClosePin()
    if m.pinDialog <> invalid
        m.pinDialog.close = true
        m.pinDialog = invalid
    end if
end sub

sub ParentalWrongPinNote(screen as object, onClosed as string)
    note = CreateObject("roSGNode", "Dialog")
    note.title = "Incorrect PIN"
    note.buttons = ["OK"]
    note.observeField("buttonSelected", onClosed)
    screen.getScene().dialog = note
end sub

' Regression check for the keyword lists — a bare list of words is exactly
' the kind of thing that silently rots. Not called in normal running; call
' it from anywhere and read the console. Mirrors Android's
' test/guide_ppv_tab_test.dart.
function GuideMetaSelfTest() as boolean
    cases = [
        ' PPV by CHANNEL name, sitting inside a sports category
        { grp: "CA | SPORTS", ch: "PPV: UFC 300", want: "PPV" }
        { grp: "USA | SPORTS HD", ch: "Pay-Per-View Event 1", want: "PPV" }
        ' PPV by CATEGORY name
        { grp: "USA | PPV", ch: "", want: "PPV" }
        { grp: "UK: PAY PER VIEW", ch: "", want: "PPV" }
        { grp: "PAYPERVIEW EN VIVO", ch: "", want: "PPV" }
        { grp: "EVENTS | PPV BOXING", ch: "", want: "PPV" }
        { grp: "USA PPV SPORTS", ch: "", want: "PPV" }
        { grp: "SPORTS PPV EVENTS", ch: "", want: "PPV" }
        ' Must STAY in Sports
        { grp: "CA | SPORTS HD", ch: "", want: "Sports" }
        { grp: "ESPN Networks", ch: "", want: "Sports" }
        { grp: "USA | NBA", ch: "", want: "Sports" }
        { grp: "UK | Sky Sports", ch: "", want: "Sports" }
        { grp: "DAZN", ch: "", want: "Sports" }
        { grp: "UFC FIGHT PASS", ch: "", want: "Sports" }
        { grp: "CA | SPORTS", ch: "CA TSN 1", want: "Sports" }
        { grp: "CA | SPORTS", ch: "Sportsnet Central", want: "Sports" }
        ' Channel names must not drag anything else around
        { grp: "USA | SPORTS", ch: "Sports News Tonight", want: "Sports" }
        { grp: "USA | NEWS", ch: "CNN Movies Special", want: "News" }
        ' 24/7 is sorted by BEING a loop, not by what it loops. Each of these
        ' matched a later rule before 24/7 was moved to the top.
        { grp: "24/7 CARTOONS", ch: "", want: "24/7" }
        { grp: "24/7 MOVIES", ch: "", want: "24/7" }
        { grp: "USA | 24/7 MARVEL", ch: "", want: "24/7" }
        { grp: "24-7 SHOWS", ch: "", want: "24/7" }
        { grp: "24 7 MUSIC", ch: "", want: "24/7" }
        ' Untouched routing
        { grp: "USA | KIDS", ch: "", want: "Kids & Family" }
        { grp: "HBO MOVIES", ch: "", want: "Movies" }
        { grp: "CA | NEWS", ch: "", want: "News" }
        { grp: "Random Junk", ch: "", want: "Other" }
    ]
    passed = 0
    for each c in cases
        got = GuideMetaCategoryForChannel(c.grp, c.ch)
        if got = c.want
            passed = passed + 1
        else
            KLog("guidetest", "FAIL grp=" + c.grp + " ch=" + c.ch + " want=" + c.want + " got=" + got)
        end if
    end for
    KLog("guidetest", passed.toStr() + "/" + cases.count().toStr() + " passed")
    return passed = cases.count()
end function
