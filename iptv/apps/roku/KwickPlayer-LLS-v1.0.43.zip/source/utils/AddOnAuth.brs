' ---- Renewing an add-on sign-in that ran out ---------------------------------
'
' THE GAP THIS FILLS. A Trakt access token stops working after about three
' months. The relay has had a `refresh` action since it was written and
' Store.brs has kept the refresh token beside every Trakt sign-in since the
' first build, but nothing in this app ever called it — so roughly three months
' after signing in, a member's watchlist row stopped updating, their scrobbles
' stopped landing and their checkmarks stopped filing, with nothing on screen
' to say why. This is the piece that was missing.
'
' >>> TASK THREADS ONLY, AND THAT IS WHY IT IS ITS OWN FILE. <<<
' Everything here blocks on a network round trip and then writes the registry.
' Only AddOnTask.xml and AddOnSyncTask.xml name it, and a component gets ONLY
' the scripts its own XML names — which is the one thing in this app that turns
' "never call this from the render thread" from a comment into a fact. Do not
' add this file to a screen's XML: a screen that sat here would miss
' certification 3.5's 250 ms answer-a-keypress rule by twenty seconds.
'
' ONE DECISION, ONE PLACE. Both relay paths (AddOnTask's node and
' AddOnSyncTask's inline relayGet) keep their own HTTP transport — that
' duplication is deliberate and predates this work — but the question "is this
' sign-in dead, can it be renewed, and does the member get signed out?" is
' answered here and nowhere else. Two copies of THAT drifting apart is how a
' member gets signed out of a working account.
'
' SIMKL IS NOT TRAKT AND MUST NOT BE TREATED LIKE IT. A Simkl token does not
' expire, Simkl has no refresh endpoint and simkl.php has no `refresh` action
' (Android says the same at simkl_service.dart:498). A Simkl 401 means signed
' out, full stop.
'
' WHAT IT COSTS IN THE REGISTRY: NOTHING NEW. No new key and no new field. A
' renewal rewrites the SAME addon_<id> row through Store.brs's
' SaveAddOnAccount, under the same 512-byte-per-account cap, swapping two
' tokens for two of the same length. A sign-out deletes rows, so it can only
' give bytes back.
'
' THE TOKEN IS THE MEMBER'S. It is never logged, never drawn and never on the
' KwickSync wire — the add-on rows are in neither psetScalarMap nor
' psetListMap, so BuildPsetMap cannot emit them and ApplyPsetMap cannot write
' them. Nothing in this file changes that. Every log line below carries the
' service and what happened, and nothing else.
'
' Contract: [[Site - Trakt Relay (trakt.php)]].

' Is this the relay saying the member's sign-in is no longer good?
'
' The contract's own error table: 401 `auth` means "upstream 401 — the token is
' gone; the app refreshes once, then signs out". Both spellings are checked
' because a refusal that never reached the relay arrives as a bare 401 with no
' body, and one that did arrives as { error: "auth" } — the same fact either
' way.
function AddOnSignInRefused(status as integer, errorCode as string) as boolean
    if status = 401 then return true
    return LCase(ToStr(errorCode)) = "auth"
end function

' A request came back refused. Work out what to do about the member's sign-in
' and do it.
'
' ANSWERS THE TOKEN TO USE FROM HERE ON, or "" for "there is nothing to try".
' A non-empty answer means the caller should send its ONE retry with that
' token. "" means the caller gives up — and by then the member has either been
' signed out here, or was never signed in to begin with.
'
' THE CALLER RETRIES ONCE, NEVER TWICE. Nothing in this file calls a caller
' back, so a retry cannot reach this function again within the same request:
' AddOnTask renews at most once per request, AddOnSyncTask at most once per
' run. That is structural, not a counter somebody has to remember to reset.
'
' `usedToken` is the token the failed request actually carried. It is the
' generation counter as well as the credential: if what is stored no longer
' matches it, something else on this box has already dealt with this — another
' scrobble in flight, or the member signing out — and this call must not
' second-guess it.
function RenewAddOnSignIn(svc as string, usedToken as string, timeoutMs as integer) as string
    service = LCase(ToStr(svc))
    sent = ToStr(usedToken)

    ' A request that carried no token cannot have been refused for having a
    ' stale one. This is what keeps the device-code sign-in itself out of here:
    ' `device_code`, `device_token` and Simkl's PIN poll all go out with no
    ' bearer, and a 401 during a sign-in means the sign-in failed, not that a
    ' stored token expired.
    if sent = "" then return ""

    ' Trackers only. OpenSubtitles has no refresh action in subs.php and its
    ' sign-in is a username and password the member can retype; signing them
    ' out of it on a 401 would be a change to a feature nobody asked us to
    ' touch.
    if service <> "trakt" and service <> "simkl" then return ""

    acct = AddOnAccount(service)
    if acct.signedIn <> true then return ""

    ' Somebody got here first. Two scrobbles and a watchlist pull can be in the
    ' air together, and the box has ONE sign-in between them. A stored token
    ' that is not the one this request used means either the member signed out
    ' (handled above) or another thread already renewed — so hand back what is
    ' stored now and let the caller retry with it, rather than spending a
    ' second renewal and racing the first.
    if acct.token <> sent then return acct.token

    if service = "simkl"
        ' Nothing to renew, by design. The token does not expire, so a refusal
        ' means the member took this app off their Simkl account.
        SignOutAddOnAccount(service, "the sign-in was refused, so this TV is now signed out of Simkl. Sign in again under Settings, Add-ons.")
        return ""
    end if

    if acct.refresh = ""
        ' A Trakt sign-in from before the refresh token was kept, or one
        ' stored by something that dropped it. There is no way back from here
        ' except signing in again.
        SignOutAddOnAccount(service, "the sign-in has run out and there is nothing stored to renew it with, so this TV is now signed out of Trakt. Sign in again under Settings, Add-ons.")
        return ""
    end if

    KLog("addon", "trakt: the sign-in has run out - asking kwickplayer.tv for a fresh one")
    fresh = addOnAuthRefresh(acct.refresh, timeoutMs)

    if fresh.ok <> true
        ' >>> A RENEWAL THAT DID NOT HAPPEN IS NOT A SIGN-IN THAT IS GONE. <<<
        ' Only `dead` signs the member out. Everything else — no internet, no
        ' answer in time, a 503 while kwickplayer.tv is having a bad minute,
        ' and in particular the relay's own 429 (refresh is capped at 20 an
        ' hour per household, same as revoke) — leaves the sign-in exactly
        ' where it is. This request fails silently and the next 401 tries
        ' again, which costs the member nothing; signing them out of a working
        ' Trakt account because the house Wi-Fi dropped would cost them the
        ' whole re-link.
        if fresh.dead <> true
            KLog("addon", "trakt: could not renew the sign-in just now - leaving it alone and trying again next time")
            return ""
        end if

        ' THE RACE, CLOSED AS FAR AS IT CAN BE. Trakt's refresh token is
        ' single-use: if two threads renewed at the same moment, the loser is
        ' told the sign-in is dead even though the member's is perfectly fine.
        ' Signing them out on that would be the worst possible outcome, so
        ' read the row again first — if anything about it has moved, the winner
        ' has already written and this is the loser, which carries on with the
        ' winner's token instead.
        again = AddOnAccount(service)
        if again.signedIn <> true then return ""
        if again.token <> sent
            KLog("addon", "trakt: this renewal was refused because another one on this TV had already gone through - carrying on with that one")
            return again.token
        end if
        if again.refresh <> acct.refresh then return ""
        SignOutAddOnAccount(service, "the sign-in could not be renewed, so this TV is now signed out of Trakt. Sign in again under Settings, Add-ons.")
        return ""
    end if

    if not RenewAddOnToken(service, fresh.token, fresh.refresh)
        ' A fresh sign-in arrived and this box could not keep it. RegWrite has
        ' already said why on its own line (the registry is full). Carrying on
        ' with a token that is not saved would work until the next launch and
        ' then read as this same bug all over again — and the refresh token we
        ' just spent is dead now, so the stored sign-in cannot be renewed ever
        ' again either. Signing out is the honest state, and it deletes keys,
        ' which is also the one thing that still works on a full registry.
        SignOutAddOnAccount(service, "a fresh sign-in arrived but this TV had no room to save it, so this TV is now signed out of Trakt. Sign in again under Settings, Add-ons.")
        return ""
    end if

    KLog("addon", "trakt: sign-in renewed - sending the same request again")
    return fresh.token
end function

' ---- The one call this app makes on its own behalf ---------------------------
'
' POST { refresh_token } to trakt.php?a=refresh. The answer is a new
' access/refresh pair, and it is the only thing in this app that can bring a
' three-month-old sign-in back.
'
' IT CANNOT SET OFF ANOTHER RENEWAL. This is a plain roUrlTransfer written out
' here rather than another trip through a caller's send path, so there is no
' route from a failed refresh back into the refresh code. That is what makes
' "once, never twice" a shape rather than a promise.
'
' A 400 IS A SIGN-OUT, NOT A BAD REQUEST. The relay note records it: a Trakt
' sign-in that has run out answers 400 with a completely empty body, so the
' relay turns that into 401 `auth` on our behalf rather than letting the app
' retry a dead sign-in forever. That conversion is the whole reason `dead`
' below can be trusted.
'
' `dead` IS THE ONLY THING THAT SIGNS A MEMBER OUT, and it is set on exactly
' one answer: the relay saying 401 / `auth`, which by contract means this
' sign-in is gone and no amount of trying again will help. Never on a timeout,
' never on "no internet", never on 429, never on 503 — those all mean "not
' now", and `ok` stays false without `dead`, which leaves the sign-in
' untouched. Both fields are set on every branch.
function addOnAuthRefresh(refreshToken as string, timeoutMs as integer) as object
    out = { ok: false, dead: false, token: "", refresh: "" }
    ms = timeoutMs
    if ms <= 0 then ms = 20000

    xfer = CreateObject("roUrlTransfer")
    xfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    ' The body of the refusal is where the relay SAYS why.
    xfer.retainBodyOnError(true)
    xfer.enableEncodings(true)
    xfer.setUrl(TraktUrl("refresh"))
    xfer.addHeader("User-Agent", KwickUserAgent())
    xfer.addHeader("Accept", "application/json")
    xfer.addHeader("Content-Type", "application/json")
    ' NO Authorization header, on purpose. The dead access token is not what
    ' identifies this call — the refresh token in the body is, and that is the
    ' only place it ever goes.
    port = CreateObject("roMessagePort")
    xfer.setMessagePort(port)
    if not xfer.asyncPostFromString(FormatJson({ "refresh_token": ToStr(refreshToken) }))
        KLog("addon", "trakt: could not reach kwickplayer.tv to renew the sign-in")
        return out
    end if

    msg = wait(ms, port)
    if type(msg) <> "roUrlEvent"
        xfer.asyncCancel()
        KLog("addon", "trakt: kwickplayer.tv did not answer in time when renewing the sign-in")
        return out
    end if

    code = msg.getResponseCode()
    parsed = ParseJson(ToStr(msg.getString()))
    ' Worked out before anything else is read, so a refusal with no body and a
    ' refusal with one land on the same answer.
    out.dead = AddOnSignInRefused(code, ToStr(GetField(parsed, "error")))

    if parsed = invalid
        ' Deliberately does NOT print the body: a renewal answer has the
        ' member's new token in it.
        KLog("addon", "trakt: the answer to the renewal was not something this app understands (status " + code.toStr() + ")")
        return out
    end if
    if code < 200 or code >= 300 or ToStr(GetField(parsed, "error")) <> ""
        KLog("addon", "trakt: kwickplayer.tv would not renew the sign-in (status " + code.toStr() + ")")
        return out
    end if

    out.token = ToStr(GetField(parsed, "access_token"))
    out.refresh = ToStr(GetField(parsed, "refresh_token"))
    out.ok = (out.token <> "")
    if not out.ok then KLog("addon", "trakt: the renewal answered without a new sign-in in it")
    return out
end function
