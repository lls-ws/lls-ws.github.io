' ---- Checkmarks on the member's OWN Trakt and Simkl accounts ------------------
'
' When a member ticks something watched in this app, it is also ticked on the
' tracking accounts they have signed in to. When they untick it, it comes off
' again. That is all this file does.
'
' ONE implementation for every checkmark in the app — the film page's button and
' all four of the series page's marks — and one for every service behind it.
' Each screen calls one of the two subs at the bottom and nothing else; what is
' sent, to whom, and what is written to the log all live here. It is the Roku
' half of Android's lib/core/services/trakt_checkmarks.dart, which is the
' reference for every decision below.
'
' THE RULES THIS FILE IS BUILT ON.
'
'  1. FIRE AND FORGET. The tick appears the instant the member presses the
'     button, whatever Trakt or Simkl is doing. Every request goes out through
'     AddOnTask, which is the one node in this app that speaks to these relays,
'     and nothing here ever waits for an answer or observes one.
'  2. NEVER ON THE RENDER THREAD. Same reason, same mechanism.
'  3. NO ID, NO CALL. Both services key on the TMDB id. A name is a guess, and a
'     guess here does not give somebody a poor search result they can ignore —
'     it marks the WRONG FILM as watched on their real account on a service we
'     do not own, and they have to go and unpick it by hand. A title whose panel
'     sent no id does nothing at all, and says nothing at all to the member.
'  4. A FAILURE IS SILENT. There is nothing the member can do about a refused
'     history call and nothing here worth interrupting them with. AddOnTask logs
'     the tag, the HTTP status and the relay's own code from its own thread;
'     that is the whole of the error handling.
'  5. ONE REQUEST PER SERVICE PER PRESS, however many episodes it covers. "Mark
'     This and All Before as Watched" over a whole season is ONE request with an
'     array in it, not forty. Trakt allows 1,000 calls per five minutes for the
'     WHOLE APP and Simkl 1,000 a DAY for the whole app until they approve us —
'     those limits are shared by every Kwick Player in the world.
'  6. THE ID IS ALREADY IN HAND. Android looks the title up once however many
'     services are signed in; here there is no lookup at all — both detail
'     screens already stash the id (m.subsTmdb) for the subtitle search, and it
'     is passed in. Nothing in this file makes a metadata request.
'  7. IT DOES NOT TOUCH KWICKSYNC. The tick reaches the member's own devices
'     exactly as it always did. This is a second, separate errand on the same
'     button, and the two never share a code path.
'
' WHAT IS NOT DOUBLE-FILED, AND THE ONE CASE THAT IS. Trakt and Simkl both mark
' an item watched THEMSELVES when a `stop` scrobble arrives at 80% or more, and
' PlayerScreen sends those. Nothing in this file is reachable from playback:
' every caller is a deliberate remote press on a menu or a button, and this
' app's own automatic 95% mark is written in the player and never comes
' through here. The one overlap left is a member who watches between 80% and
' 95% — the services have already filed it, our own mark has not appeared, and
' the member then ticks it by hand. Trakt records a second PLAY of the same
' title; the watched state itself is unchanged. Android behaves identically.
'
' EVERY KEY BELOW IS WRITTEN IN BRACKETS AND IN LOWER CASE. BrightScript folds
' a field name written as code to lower case while the relay reads the JSON
' case-sensitively, and this app has had at least four live bugs from exactly
' that mismatch. The bracket form removes the question, and every field these
' two relays take is lower case anyway. The NUMBERS are numbers, never strings:
' a quoted "1399" is not the same id upstream.
'
' Contracts, and the only authority for the shapes below:
'   [[Site - Trakt Relay (trakt.php)]]
'   [[Site - Simkl Relay (simkl.php)]]

' The two services that take a history call. In this order, so a member signed
' in to both always gets the same log lines in the same order.
function tkmServices() as object
    return ["trakt", "simkl"]
end function

' Never more than this many episodes in one request.
'
' It exists to stop one press putting a quarter of a megabyte of JSON on the
' wire, not to save the render thread: the two batch callers already walk every
' episode of the show writing registry rows, which costs far more than building
' this list. When it bites it keeps the LAST rows in show order — for "mark this
' and all before" those are the ones nearest the episode the member actually
' pressed, and dropping the pilot of a thousand-episode show is the least wrong
' thing available. It is logged when it happens, because the member is not told.
function tkmMaxEpisodes() as integer
    return 1000
end function

' Is this service switched on for CHECKMARKS?
'
' HistoryOn() is Nia's and lands in Store.brs beside the other per-profile
' preferences. It reads "pref_trakt_history" / "pref_simkl_history", all lower
' case, and it is NOT the same switch as ScrobbleOn() — a member can have
' scrobbling on and checkmark filing off, or the other way round, and neither
' implies the other.
'
' UNTIL IT LANDS, signed in counts as on, which is what the Add-ons page already
' promises. The try/catch is the guard PlayerScreen's scrobbleEnabled() uses for
' the same reason: a component only ever sees the scripts its own XML names, and
' calling a function it was not given does not fail politely — it kills the
' render thread and leaves the member looking at a locked screen. A checkmark
' that quietly is not filed is a far smaller problem than a detail page that
' stops answering the remote.
function tkmEnabled(svc as string) as boolean
    signedIn = false
    try
        signedIn = AddOnSignedIn(svc)
    catch e
        return false
    end try
    if not signedIn then return false
    try
        return HistoryOn(svc) = true
    catch e
        ' Expected until the Settings half lands. Not worth a log line on every
        ' tick of every episode.
        return true
    end try
end function

' The member's own token, which is THEIRS: never drawn, never logged, never put
' in a URL and never on the KwickSync wire. It goes into AddOnTask's `bearer`
' field, from there into one Authorization header, and nowhere else.
function tkmToken(svc as string) as string
    tok = ""
    try
        acct = AddOnAccount(svc)
        if acct <> invalid then tok = ToStr(GetField(acct, "token"))
    catch e
        tok = ""
    end try
    return tok
end function

' Which accounts this press is going to, worked out ONCE before anything is
' built. A member with neither signed in, or with both switched off, pays for
' nothing at all — not a body, not a log line.
function tkmWanted() as object
    out = []
    for each svc in tkmServices()
        if tkmEnabled(svc)
            tok = tkmToken(svc)
            if tok <> "" then out.push({ svc: svc, token: tok })
        end if
    end for
    return out
end function

' "Is anyone listening?"
'
' For a caller that would otherwise build a list of several hundred episodes for
' nobody — the two batch marks on the series page walk the whole show. A member
' with neither service signed in, or with both switches off, is the
' overwhelming majority, and Android takes the same reading before it queues
' anything (trakt_checkmarks.dart:48). Six registry reads at worst.
function TrackerMarksOn() as boolean
    return tkmWanted().count() > 0
end function

' Now, in the ISO-8601 UTC the two relays document. roDateTime is created at the
' current UTC moment, which is what toISOString() then renders.
function tkmNowIso() as string
    dt = CreateObject("roDateTime")
    return dt.toISOString()
end function

' `watched_at` rides on history_add and NOT on history_remove, matching Android
' (trakt_service.dart:625-629, simkl_service.dart:803-807) and both contracts —
' "same shape without dates".
function tkmStamp(watched as boolean) as string
    if watched then return tkmNowIso()
    return ""
end function

' The `movies` half of a body. Trakt is given the id and nothing else: it
' matches on the id, and a title beside it is only a second thing to get out of
' step. Simkl asks for as much as we have so its own matcher can confirm the id,
' so it also gets the name and the year when there is one.
function tkmMovieBody(svc as string, watched as boolean, id as integer, title as string, year as integer) as object
    mv = {}
    mv["tmdb"] = id
    if svc = "simkl"
        if title <> "" then mv["title"] = title
        if year > 0 then mv["year"] = year
    end if
    at = tkmStamp(watched)
    if at <> "" then mv["watched_at"] = at
    body = {}
    body["movies"] = [mv]
    return body
end function

' The `episodes` half, which is IDENTICAL for both services — neither takes a
' title on an episode (trakt_service.dart:224-231, simkl_service.dart:244-255),
' so one array is built and both requests carry it.
'
' An episode is filed under the SHOW's id plus the two numbers, never under the
' episode's own id, which is a different number entirely and is the mistake that
' files a watch against the wrong show. Season 0 is real — that is what both
' services call specials — but an episode number of 0 is a panel that did not
' say, and a row with no number is dropped rather than guessed at.
function tkmEpisodeRows(watched as boolean, showId as integer, eps as object) as object
    rows = []
    if eps = invalid then return rows
    total = eps.count()
    if total = 0 then return rows
    first = 0
    if total > tkmMaxEpisodes()
        first = total - tkmMaxEpisodes()
        KLog("addon", "history: " + first.toStr() + " of " + total.toStr() + " episode(s) dropped - one request carries at most " + tkmMaxEpisodes().toStr())
    end if
    at = tkmStamp(watched)
    for i = first to total - 1
        ep = eps[i]
        sNum = ToInt(GetField(ep, "season"))
        eNum = ToInt(GetField(ep, "number"))
        if sNum >= 0 and eNum > 0
            r = {}
            r["show_tmdb"] = showId
            r["season"] = sNum
            r["number"] = eNum
            if at <> "" then r["watched_at"] = at
            rows.push(r)
        end if
    end for
    return rows
end function

' One request, fired and forgotten.
'
' TWO THINGS HERE ARE NOT ORDINARY AND BOTH ARE DELIBERATE, and both are
' PlayerScreen's scrobbleFire() for the same reasons:
'
'  1. THE TASK IS HUNG ON THE SCENE, not just held in this call's local. A
'     member can press Mark as Watched and Back in the same second, and every
'     opener of these pages removes the page node on `closed`. A Task whose only
'     reference lived in a destroyed component would go with it, mid-request,
'     and the tick would never reach the member's account. The scene outlives
'     both detail pages, so the scene holds it. Appended BEFORE control = "RUN",
'     so the reference exists before the thread does.
'  2. THE RESULT IS NOT OBSERVED. An observer registered here points back into a
'     component that may be gone by the time the answer lands, and there is
'     nothing for it to do: a failure is silent by rule and AddOnTask already
'     logs the tag, the status and the relay's code from its own thread. The tag
'     set below is what makes that line readable.
'
' NO SCENE MEANS NO REQUEST. Firing a task nothing holds would spend the
' member's request and abandon it half way, which is worse than not trying.
sub tkmFire(scene as dynamic, svc as string, action as string, bodyJson as string, tok as string, tag as string)
    if scene = invalid
        KLog("addon", "history: no scene to hold the request - " + svc + " " + action + " not sent")
        return
    end if
    node = CreateObject("roSGNode", "AddOnTask")
    if node = invalid
        ' Only reachable in a build missing the task component.
        KLog("addon", "history: AddOnTask is missing - " + svc + " " + action + " not sent")
        return
    end if
    tkmSweep(scene)
    addr = SimklUrl(action)
    if svc = "trakt" then addr = TraktUrl(action)
    node.id = "khist"
    node.url = addr
    node.method = "POST"
    node.bodyJson = bodyJson
    node.bearer = tok
    ' A little under AddOnTask's 20s default. Nothing waits on this and nothing
    ' is retried, so a relay having a bad minute should let go of the thread
    ' rather than sit on it while the member carries on browsing.
    node.timeoutMs = 15000
    node.tag = "history-" + svc + "-" + action
    ' Which service this belongs to, said outright. AddOnTask needs it to know
    ' whether a refused sign-in can be renewed (Trakt) or means signed out
    ' (Simkl); it must not read that off the tag above, which is wording.
    node.service = svc
    scene.appendChild(node)
    node.control = "RUN"
    ' NUMBERS ONLY. What the member watched is their business and belongs in no
    ' support log, so this line carries the catalogue id and a count and never a
    ' title. The token is never anywhere near it.
    KLog("addon", action + " " + svc + " - " + tag)
end sub

' Take the finished ones back off the scene.
'
' The pairing for the appendChild above: without it every checkmark of every
' episode would leave a dead Task node hanging on the scene for the rest of the
' launch. Run on the way IN rather than on the way out, because the way out is
' the moment the caller is about to stop existing. Only ever touches nodes this
' file made — nothing else in the app gives a node the id "khist", and the
' player's own scrobble sweep looks for "kscrob".
sub tkmSweep(scene as dynamic)
    if scene = invalid then return
    i = scene.getChildCount() - 1
    while i >= 0
        ch = scene.getChild(i)
        if ch <> invalid and ToStr(ch.id) = "khist"
            if LCase(ToStr(ch.state)) = "done" then scene.removeChild(ch)
        end if
        i = i - 1
    end while
end sub

' ---- The two doors the screens use -------------------------------------------

' A film the member ticked, or unticked, by hand.
'
' `scene` is the caller's m.top.getScene(). `tmdbId` and `year` are the strings
' the detail page already holds for the subtitle search; `title` is the film's
' own name and is read by Simkl only.
sub TrackerMarkMovie(scene as dynamic, watched as boolean, tmdbId as string, title as string, year as string)
    wanted = tkmWanted()
    if wanted.count() = 0 then return
    id = ToInt(ToStr(tmdbId).trim())
    if id <= 0
        ' Media-server titles and panels that sent no id land here. One line,
        ' and nothing at all in front of the member.
        KLog("addon", "history: no TMDB id for this film - nothing sent")
        return
    end if
    action = "history_remove"
    if watched then action = "history_add"
    nm = ToStr(title).trim()
    yr = ToInt(ToStr(year).trim())
    tag = "movie:" + id.toStr()
    for each w in wanted
        tkmFire(scene, w.svc, action, FormatJson(tkmMovieBody(w.svc, watched, id, nm, yr)), w.token, tag)
    end for
end sub

' One episode, a run of them, or a whole show — always ONE request per service.
'
' `showTmdbId` is the SERIES' id. `eps` is an array of { season, number } in
' show order; a single tick passes one entry and the two batch marks pass all of
' theirs, which is what keeps a binge to one request instead of forty.
sub TrackerMarkEpisodes(scene as dynamic, watched as boolean, showTmdbId as string, eps as object)
    wanted = tkmWanted()
    if wanted.count() = 0 then return
    if eps = invalid or eps.count() = 0 then return
    id = ToInt(ToStr(showTmdbId).trim())
    if id <= 0
        KLog("addon", "history: no TMDB id for this show - nothing sent")
        return
    end if
    rows = tkmEpisodeRows(watched, id, eps)
    if rows.count() = 0 then return
    action = "history_remove"
    if watched then action = "history_add"
    body = {}
    body["episodes"] = rows
    ' Built once: neither service takes anything extra on an episode, so both
    ' requests carry the same bytes.
    bodyJson = FormatJson(body)
    tag = "episode:" + id.toStr() + " x" + rows.count().toStr()
    for each w in wanted
        tkmFire(scene, w.svc, action, bodyJson, w.token, tag)
    end for
end sub
