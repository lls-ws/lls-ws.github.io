' Persistent storage (roRegistry) — the Roku counterpart of the Android
' app's playlist database + preferences. Providers mirror the Android
' model: type "kwicktv" | "xtream" | "m3u", plus an active id.

function RegRead(key as string) as string
    sec = CreateObject("roRegistrySection", "kwickplayer")
    if sec.exists(key) then return sec.read(key)
    return ""
end function

' A REFUSED WRITE IS NOW SAID OUT LOUD.
'
' The registry is 16-32 KB for the WHOLE app, and when it is full `flush()`
' returns false and the write simply does not happen. Nothing above here
' checked that, so an over-quota box carried on believing it had saved the
' member's favourites, their resume points, their profiles — every store in
' this file goes through this one sub. The member sees things they changed
' quietly revert, and it reads exactly like a sync bug.
'
' This does not FIX a full registry; it makes it visible, which is the part
' that was missing. Nothing can be raised from here — the quota is Roku's —
' so the answer when this line shows up is to stop something from hoarding
' (see the unknown-kind rule in SyncTask.applyRemote, the first thing that
' was found doing it).
'
' The key is named and the value's size given, because that pair is what
' identifies the hoarder. The VALUE is never logged: these rows carry
' profile names and the member's own library.
sub RegWrite(key as string, value as string)
    sec = CreateObject("roRegistrySection", "kwickplayer")
    sec.write(key, value)
    ' Compared against true rather than negated. EVERY store in this file
    ' funnels through here, so a throw on an unexpected return value would
    ' take the whole app down to report a failed save — the reporting must
    ' never be able to cost more than the thing it reports.
    ok = sec.flush()
    if ok <> true
        KLog("store", "registry write REFUSED for '" + key + "' (" + value.len().toStr() + "B) - the registry is full and this change was NOT saved")
    end if
end sub

sub RegDelete(key as string)
    sec = CreateObject("roRegistrySection", "kwickplayer")
    sec.delete(key)
    sec.flush()
end sub

' ---- Providers ------------------------------------------------------------

function LoadProviders() as object
    raw = RegRead("providers")
    if raw = ""
        return [{
            id: "lls_tv_default",
            ptype: "m3u",
            name: "LLS TV",
            m3uUrl: "https://lls-ws.github.io/iptv/LLS_TV.m3u",
            epgUrl: "https://lls-ws.github.io/iptv/guide.xml.gz"
        }]
    end if
    parsed = ParseJson(raw)
    if parsed = invalid then return []
    return ToArray(parsed)
end function

sub SaveProviders(providers as object)
    RegWrite("providers", FormatJson(providers))
end sub

function ActiveProviderId() as string
    return RegRead("active_provider")
end function

sub SetActiveProviderId(id as string)
    RegWrite("active_provider", id)
end sub

function ActiveProvider() as dynamic
    id = ActiveProviderId()
    providers = LoadProviders()
    for each p in providers
        if p.id = id then return p
    end for
    if providers.count() > 0 then return providers[0]
    return invalid
end function

' ---- Source identity (multi-source keying) ----------------------------------
' Which source a favorite, recent, or resume point belongs to. Every store
' entry that names content by id carries this token in a "src" field —
' without it, movie 1234 on one source and movie 1234 on another are the
' same row, and switching sources scrambles favorites and resume points.
'
' The token is the PORTABLE form KwickSync already speaks — the Android app
' builds the identical strings from its playlists — so local storage and the
' sync wire agree without a translation layer:
'   KwickTV login        -> ""            (the primary source syncs bare;
'                                          also exactly what every existing
'                                          install already has saved)
'   another Xtream login -> "xt:<host>"
'   a web M3U playlist   -> "m3u:<host>"
'   a USB playlist       -> "file:<name>" (no host to build a portable id
'                                          from; its rows stay on this box)
function SrcTokenFor(p as dynamic) as string
    if p = invalid then return ""
    pt = ToStr(p.ptype)
    if pt = "kwicktv" then return ""
    if pt = "xtream" then return "xt:" + HostOf(ToStr(p.server))
    ' A member's own Jellyfin/Emby is named by the SERVER'S OWN ID, never by its
    ' address — "jf:<serverId>" / "emby:<serverId>", the same strings the phone
    ' and the PC build (source_tokens.dart). One box reached at 192.168.1.50
    ' from the sofa and at a DDNS name from the bus is ONE server; HostOf would
    ' make it two, and two servers behind one host name would collapse into one.
    '
    ' THIS ARM IS LOAD-BEARING, not tidiness. The fall-through at the bottom of
    ' this function returns "", which is the KwickTV login's own token — so a
    ' media server without an arm here would quietly share identity with the
    ' member's IPTV account: same favourite keys, same resume keys, same seen
    ' keys, and ProviderForSrcToken("") would route its playback to KwickTV.
    if pt = "jellyfin" or pt = "emby" then return MsSrcToken(p)
    if pt = "m3u"
        ' Dot access on purpose — the stored key is dot-folded lowercase
        ' ("m3uurl"), which GetField's exact-case lookup would miss.
        u = ToStr(p.m3uUrl)
        if IsLocalPath(u) then return "file:" + FileTail(u)
        return "m3u:" + HostOf(u)
    end if
    return ""
end function

function ActiveSrcToken() as string
    return SrcTokenFor(ActiveProvider())
end function

' The sources that can carry LIVE channels: everything except a media server.
'
' A Jellyfin or an Emby holds films and shows and no channels at all, but this
' app has no ptype switch — it has ONE test, `= "m3u"`, repeated across
' nineteen files, and everything that is not an M3U falls into an `else` that
' builds a player_api.php address. Left alone, a media server would not merely
' show nothing on Live TV: it would fire Xtream category and lineup requests at
' a Jellyfin, once per screen, forever.
'
' So every live-side screen (Live TV, the TV Guide, Sports, Multi-View, Manage
' Channels) reads its sources through here instead of LoadProviders(). The VOD
' side deliberately does NOT — that is where a media server belongs.
function LiveProviders() as object
    out = []
    for each p in LoadProviders()
        if not MsIsMediaServer(p) then out.push(p)
    end for
    return out
end function

' The member's media servers, in the order they were added.
function MediaServerProviders() as object
    out = []
    for each p in LoadProviders()
        if MsIsMediaServer(p) then out.push(p)
    end for
    return out
end function

' Write down what a media server told us when the app signed in. `session` is
' { ptype, server, token, userId, userName, serverId } — everything the sign-in
' learned, including corrections to the brand and the address.
'
' The id is the important one. Until it arrives the source answers to a
' stand-in name built from its address (MsPendingSrcToken), so anything the
' member marked in the meantime is filed under that stand-in — this carries it
' across to the real name in the same move an address change already uses.
'
' Answers true when something actually changed.
function SaveMediaServerSession(providerId as string, session as object) as boolean
    if providerId = "" or session = invalid then return false
    RunPendingSrcTokenMove()
    providers = LoadProviders()
    for i = 0 to providers.count() - 1
        if ToStr(providers[i].id) = providerId
            p = providers[i]
            if not MsIsMediaServer(p) then return false
            oldTok = SrcTokenFor(p)
            ' What the SERVER said it is beats what the website guessed. The
            ' pairing page cannot tell a Jellyfin from an Emby and files both
            ' as "jellyfin"; the address may also have gained the /emby the
            ' probe had to add before anything answered.
            brand = ToStr(GetField(session, "ptype"))
            if brand = "jellyfin" or brand = "emby" then p.ptype = brand
            base = ToStr(GetField(session, "server"))
            if base <> "" then p.server = base
            uname = ToStr(GetField(session, "userName"))
            if uname <> "" then p.userName = uname
            p.token = ToStr(GetField(session, "token"))
            p.userId = ToStr(GetField(session, "userId"))
            p.serverId = ToStr(GetField(session, "serverId"))
            newTok = SrcTokenFor(p)
            moving = (oldTok <> newTok and oldTok <> "" and newTok <> "")
            if moving then NoteSrcTokenMove(oldTok, newTok)
            providers[i] = p
            SaveProviders(providers)
            if moving then RunPendingSrcTokenMove()
            return true
        end if
    end for
    return false
end function

' The media servers that have not been signed in to yet, oldest first. What
' the app works through on its own after a pairing lands or the app starts.
function MediaServersNeedingSignIn() as object
    out = []
    for each p in LoadProviders()
        if MsNeedsSignIn(p) then out.push(p)
    end for
    return out
end function

' Does this store entry belong to the source the token names? An entry with
' no src field is the KwickTV login's (token "").
function SrcMatches(entry as dynamic, token as string) as boolean
    s = ""
    v = GetField(entry, "src")
    if v <> invalid then s = ToStr(v)
    return s = token
end function

' The token an item being SAVED belongs to: its own src when the builder
' set one (merged screens tag every item, "" meaning KwickTV), else the
' active source (legacy callers that predate the merged lineup). The
' doesExist check matters — for KwickTV the explicit value IS "", which
' GetField can't tell apart from the field being absent.
function ItemSrcToken(item as dynamic) as string
    if type(item) = "roAssociativeArray" and item.doesExist("src") then return ToStr(item.src)
    return ActiveSrcToken()
end function

' Only xt:/m3u: tokens mean anything on another device. "file:" (USB) rows
' never go on the wire, and "" (KwickTV) syncs bare rather than as a src.
'
' A media server's token ("jf:"/"emby:"/"plex:") is portable too, but NOT
' through here: it travels under its own two sync kinds (favmedia/medhist), so
' anything asking this question is asking about the IPTV wire and must get
' "no". Adding a media prefix to this line would put a Jellyfin favourite on
' the favvod wire, which is the ONE shape that corrupts an account — an older
' client reads a media favourite as an Xtream one, flattens its GUID id to
' zero, and re-pushes that over the real record every cycle for as long as the
' member owns the device.
function IsPortableSrcToken(token as string) as boolean
    return token.left(3) = "xt:" or token.left(4) = "m3u:"
end function

' Is this token a member's OWN media server rather than an IPTV panel or a
' playlist?
'
' The three prefixes are the ones the phone and the PC build write
' (favorite_sync_types.dart's sourceTokenPrefix over SourceKind.mediaServers:
' "jf", "emby", "plex"). All three are recognised here even though this box can
' only connect to two of them — a Plex row still has to be TOLD APART from an
' Xtream favourite so it can be let go of cleanly rather than mistaken for one.
function IsMediaSrcToken(token as string) as boolean
    if token.left(3) = "jf:" then return true
    if token.left(5) = "emby:" then return true
    if token.left(5) = "plex:" then return true
    return false
end function

' Does this wire token name a media server that is actually ON THIS BOX?
'
' This is the whole gate on the two media sync kinds, and it is a registry
' decision rather than a tidiness one. A member who leans on their phone's
' media-server features carries roughly 48 KB of favmedia and medhist rows on
' their account; this box has 16-32 KB of registry for EVERYTHING, and a write
' past it fails silently and takes whatever else was mid-write with it. So the
' rule is: keep the rows for the server sitting in this living room, let go of
' the rest. A member with no media server on their Roku keeps exactly today's
' behaviour — every one of those rows is dropped, and nothing they can see
' changes.
'
' Letting go is NOT deleting. The rows stay in the locker and on every other
' device; this box simply stops carrying a copy of something it cannot draw.
'
' A server that has been paired but not signed in to yet answers to a stand-in
' name ("jf:@<host>", MsPendingSrcToken) which can never equal a real wire
' token, because a real server id is plain hex and cannot contain "@". Its rows
' are therefore let go of until the sign-in lands and the real id is written
' down.
function MediaSrcTokenIsHere(token as string) as boolean
    if token = "" then return false
    if not IsMediaSrcToken(token) then return false
    for each p in MediaServerProviders()
        if MsSrcToken(p) = token then return true
    end for
    return false
end function

' The poster address for one item on the media server `token` names, built from
' THIS box's own copy of the server. Costs no request. Empty when the server is
' not here, which the caller reads as "no artwork".
'
' A media favourite deliberately carries no artwork address on the wire: the
' sending device's address for that server may not even be reachable from here,
' so every device rebuilds its own. Building it matters for more than looks —
' Home asks EnrichTask to go hunting for missing artwork whenever ANY favourite
' has a blank one, and EnrichTask answers by pulling an Xtream panel's entire
' film and series catalogue. A favourite whose artwork could never be filled in
' would set that off on every single visit to Home, for ever, against the
' member's IPTV provider. So this is what keeps that from happening.
function MediaSrcPosterUrl(token as string, itemId as string) as string
    if itemId = "" then return ""
    if not IsMediaSrcToken(token) then return ""
    for each p in MediaServerProviders()
        if MsSrcToken(p) = token then return MsImageUrl(p, itemId, "Primary", "", 400)
    end for
    return ""
end function

' The ACTIVE source's slice of a mixed store list. A read-only view: never
' write a filtered list back to the registry, or every other source's rows
' silently vanish — writers must load the full list.
function FilterActiveSrc(arr as object) as object
    token = ActiveSrcToken()
    out = []
    for each e in arr
        if SrcMatches(e, token) then out.push(e)
    end for
    return out
end function

' The provider a source token names — the reverse of SrcTokenFor. Token ""
' is the KwickTV login (or, on a box without one, the first source, which
' is what bare rows meant there). Unknown tokens (source since removed)
' return invalid; callers fall back to ActiveProvider() so old rows still
' try to play rather than dead-ending.
function ProviderForSrcToken(token as string) as dynamic
    providers = LoadProviders()
    if token = ""
        k = KwickTvProvider()
        if k <> invalid then return k
        if providers.count() > 0 then return providers[0]
        return invalid
    end if
    for each p in providers
        if SrcTokenFor(p) = token then return p
    end for
    return invalid
end function

function SourceCount() as integer
    return LoadProviders().count()
end function

' Publish one M3U source's parse into the session cache: its own slot in
' m3uByProv plus the merged all-sources list (m3uChannels) every consumer
' reads. Slots merge in provider order so the lineup is stable no matter
' which playlist finished parsing first.
' ---- The playlist memory budget ---------------------------------------------
'
' THIS IS WHERE THE APP DECIDES HOW MUCH OF THE MEMBER'S LINE-UP IT CAN HOLD,
' and it is the fix for nine crash reports in three days.
'
' Between 29 and 31 August, NINE reports came back as memory kills - seven
' EXIT_CHANNEL_MEM_LIMIT_FG and two EXIT_OUT_OF_MEMORY - across SIX device
' models (Roku Streaming Stick 3840X, Stick Plus 3830X, TCL 32RS520K,
' Westinghouse WR32HX2210, SEMP 43R6610, Roku 43R4AX). They died on four
' different screens - Search, VOD, Live TV, the Guide - which is why it read
' as four separate bugs. It was one, and none of those screens was at fault.
'
' MEASURED on the office Streaming Stick 4K, the ROOMIEST box we own, just
' loading playlists costs:
'
'      2,059 channels, 1 source  ->  13-18% of the device limit
'     16,255 channels, 2 sources ->  47-53%
'     30,565 channels, 3 sources ->  56-60%
'
' Nearly two thirds gone before the member touches anything, on the best
' hardware there is. On a 32-inch Westinghouse there is nothing left, so
' whichever screen they opened next was simply the one holding the parcel.
'
' WHY THE CHECK LIVES HERE and not in M3uTask, where it started: a Task
' thread's roAppMemoryMonitor reports only THAT THREAD'S usage. Measured, a
' parse task read 14-17% while the app was really at 47-56%, so a task cannot
' see the app it is filling up. Worse, playlists parse CONCURRENTLY, so no
' task can know what the others are about to add. This sub is the one place
' every playlist passes through, on the render thread, where the reading is
' honest and the additions are serialised.
'
' PARTIAL AND ALIVE BEATS COMPLETE AND DEAD. A member whose playlists do not
' fit gets the channels that do, and an app that works.
sub PublishM3uParse(provId as string, channels as object, tvgUrl as string)
    if m.global = invalid or not m.global.hasField("m3uByProv") then return
    channels = TrimPlaylistToBudget(provId, channels)
    slots = m.global.m3uByProv        ' node reads hand back a copy — mutate + reassign
    slots[provId] = { channels: channels, tvgUrl: tvgUrl }
    m.global.m3uByProv = slots
    merged = []
    for each p in LoadProviders()
        pid = ToStr(p.id)
        if slots.doesExist(pid)
            for each c in slots[pid].channels
                merged.push(c)
            end for
        end if
    end for
    m.global.m3uChannels = merged
    ' Published as well as logged so the next decision has a number to work
    ' from, and so a crash report can finally say how full the app was.
    pct = M3uMemPercent()
    m.global.appMemPct = pct
    ' The alarm flag the parsers stop on (main.brs) is cleared here, on the
    ' render thread, once the honest reading says there is room again - and
    ' nowhere else, so a parse that starts while the app is still high finds
    ' the flag still up.
    if pct < 70 and m.global.hasField("memPressure") then m.global.memPressure = false
    KLog("m3u", "playlists in memory: " + merged.count().toStr() + " channel(s) across " + slots.count().toStr() + " source(s) - app at " + pct.toStr() + "% of this device's limit")
    ' Legacy single-guide field: first playlist to carry a guide address
    ' claims it (the per-source guide flow reads the slots instead).
    if tvgUrl <> "" and m.global.m3uTvgUrl = "" then m.global.m3uTvgUrl = tvgUrl
end sub

' Is there room for this playlist?
'
' DELIBERATELY A GATE, NOT A RATION. The first cut tried to work out what a
' channel costs (memory used / channels held) and keep a proportional slice.
' It was badly wrong in practice - on the office stick it kept 1,400 of 14,196
' channels on a box with room for all of them - because the memory reading
' includes everything the app is doing, not just the line-up, so dividing by
' it wildly understates what a channel actually costs. A wrong ration is worse
' than none: it quietly throws away most of a member's channels on hardware
' that was never in trouble.
'
' So the rule is simply: if the app is already past the ceiling, this playlist
' does not go in. If it is not, the playlist goes in WHOLE.
'
' That is exactly the shape of the failures in the reports - members with
' SEVERAL sources, where each one is fine and the total is not. The first
' playlists load, and the one that would have killed the box is refused
' instead. A single playlist so huge that it kills the box on its own is a
' different case and is caught while parsing, by the coarse device reading in
' m3uRoomForMore.
'
' 70% leaves a third of the box for what comes after the line-up: the screen
' the member opens, its posters, a guide, a player.
function TrimPlaylistToBudget(provId as string, channels as object) as object
    if channels = invalid then return []
    used = M3uMemPercent()
    if used < 0 then return channels          ' device will not say - do not guess
    if used < 70 then return channels
    KLog("m3u", "no room for the '" + provId + "' playlist - the app is already at " + used.toStr() + "% of this device's limit, so its " + channels.count().toStr() + " channel(s) were left out")
    return []
end function

' How much of this device's memory limit the app is using, as a whole number.
' roAppMemoryMonitor measures against THIS box's ceiling, so one number reads
' the same from a 2017 Roku TV to a Streaming Stick 4K. Returns -1 when the
' device will not say.
function M3uMemPercent() as integer
    mon = CreateObject("roAppMemoryMonitor")
    if mon = invalid then return -1
    used = mon.GetMemoryLimitPercent()
    if used = invalid then return -1
    return ToInt(used)
end function

' The short name shown on source tags ("KwickTV", "USB: uk.m3u"). Only
' meaningful when more than one source exists — callers gate on that.
function SourceLabelFor(token as string) as string
    p = ProviderForSrcToken(token)
    if p = invalid then return ""
    return ToStr(p.name)
end function

' An M3U channel id from before stable ids — "m3u" + its playlist position.
' Stable ids are "m3uh<hex>", which this can never match.
function IsLegacyM3uId(id as string) as boolean
    if id.left(3) <> "m3u" then return false
    rest = Mid(id, 4)
    if rest = "" then return false
    return isAllDigits(rest)
end function

' "123" as its source stores it: bare on KwickTV, "<src>~123" anywhere
' else — the same "<src>~<id>" shape Android puts in synced watch-history
' media ids, so resume keys line up across devices with no translation.
' Pass the item's own token; omitted means the active source (callers that
' predate the merged lineup).
function SrcQualifiedId(id as string, token = invalid as dynamic) as string
    t = ""
    if token = invalid then t = ActiveSrcToken() else t = ToStr(token)
    if t = "" then return id
    return t + "~" + id
end function

' The inverse of SrcQualifiedId: "<src>~<id>" -> { src, id }, and a bare id
' -> { src: "", id }. Android writes the same shape into synced media ids and
' takes it apart the same way (`ref.split('~').last`), so this is the one
' place the Roku side has to agree with it.
function SplitSrcQualifiedId(s as string) as object
    at = Instr(1, s, "~")
    if at <= 0 then return { src: "", id: s }
    return { src: Left(s, at - 1), id: Mid(s, at + 1) }
end function

' ---- Custom TV Guide (XMLTV) per provider -----------------------------------
' A source can point at an XMLTV guide of its own instead of the one its
' provider supplies. Per provider, not per app: an XMLTV file matches channels
' by their tvg-id, and those ids belong to the source the channels came from.
'
' Absent or empty means "use the provider's own guide", which is what every
' existing install has and must keep doing — the field simply isn't in their
' stored JSON, and GetField returns invalid for it.

' CASE TRAP: assigning with dot notation (p.customEpgUrl = x) folds the key
' to lowercase, but ParseJson hands back a CASE-SENSITIVE map — so a value
' written one way reads back as invalid the other way, and the setting
' silently refused to stick. Write with brackets to keep the exact case, and
' read both spellings so records saved by the older code still work.
function ProviderCustomEpgUrl(p as dynamic) as string
    if p = invalid then return ""
    v = GetField(p, "customEpgUrl")
    if v = invalid then v = GetField(p, "customepgurl")
    return ToStr(v).trim()
end function

' Set the FIRST guide on a source, the one-address way. Since a source can
' hold several (see the block above), this now goes through the list rather
' than writing the single field on its own — writing that field alone would
' leave the list saying something different from the field every screen reads,
' and the next save from the list would put the old address back.
'
' An empty address means "no guides at all", which is what it always meant.
sub SetProviderCustomEpgUrl(providerId as string, url as string)
    u = url.trim()
    guides = ProviderCustomEpgGuidesById(providerId)
    if u = ""
        SaveProviderCustomEpgGuides(providerId, [])
    else if guides.count() = 0
        SaveProviderCustomEpgGuides(providerId, [{ u: u }])
    else
        ' A changed address is a different guide, so last time's coverage
        ' counts go with the old one.
        guides[0] = { u: u }
        SaveProviderCustomEpgGuides(providerId, guides)
    end if
    KLog("guide", "custom guide save for " + providerId + " -> [" + u + "]")
end sub

' ---- More than one guide per source ----------------------------------------
' A source can be pointed at SEVERAL guides now, in an order the member sets.
' The phone has had this for a while (custom_epg_screen.dart: "Several per
' source, in the order they were added. Each claims the channels it can match
' and passes the rest on; the provider's own guide is always last") and this
' is the storage and the settings half of the same feature on this side.
'
' STORED ON THE PROVIDER RECORD, beside the single address that was there
' before, as `customEpgUrls`: a list of { u, m, t }.
'
'   u   the address
'   m   how many of the member's own channels it covered last time it was read
'   t   how many channels were checked against it
'
' m and t are what the coverage line under each row reads out, and they are
' stored rather than worked out because working them out means downloading and
' parsing the whole guide — which is a minute of somebody's time, not a label.
' Absent (never checked) is a state of its own and says so.
'
' THE OLD SINGLE FIELD IS STILL WRITTEN, always, and that is load-bearing:
' GuideScreen and LiveTvScreen read `customEpgUrl` through
' ProviderCustomEpgUrl and neither of those files is this one's to change. So
' the FIRST guide in the list is mirrored into it and everything that exists
' today keeps working exactly as it does today, whether or not anything ever
' teaches those screens about the rest. A source with no guides at all mirrors
' back to empty, which is the "use the provider's own" state they already
' understand.
'
' THE CAP: CustomEpgMaxGuides(). An address runs sixty to a hundred and twenty
' characters and the whole app has 16-32 KB of registry, shared with the
' providers, the favorites, the lists, the recents and the sync mirror — the
' provider list is one registry value and every guide address sits inside it.
' Three per source is roughly 300 bytes a source on top of the ~75 the single
' address already cost, so about 225 bytes each of new storage, and a member
' with two sources pays about 450. Past three, adding is refused with a reason
' rather than the write quietly failing.

function CustomEpgMaxGuides() as integer
    return 3
end function

' Every guide set against this source, in order. Reads the new list, and falls
' back to the single legacy address so a source set up before this existed
' comes back as a one-guide list rather than none.
'
' Same CASE TRAP as ProviderCustomEpgUrl below — both spellings are read.
function ProviderCustomEpgGuides(p as dynamic) as object
    if p = invalid then return []
    v = GetField(p, "customEpgUrls")
    if v = invalid then v = GetField(p, "customepgurls")
    out = []
    if v <> invalid and isArrayType(v)
        for each g in ToArray(v)
            u = ToStr(GetField(g, "u")).trim()
            if u <> ""
                row = { u: u }
                if GetField(g, "m") <> invalid then row.m = ToInt(GetField(g, "m"))
                if GetField(g, "t") <> invalid then row.t = ToInt(GetField(g, "t"))
                out.push(row)
            end if
        end for
    end if
    if out.count() > 0 then return out
    legacy = ProviderCustomEpgUrl(p)
    if legacy <> "" then return [{ u: legacy }]
    return []
end function

function ProviderCustomEpgGuidesById(providerId as string) as object
    for each p in LoadProviders()
        if ToStr(p.id) = providerId then return ProviderCustomEpgGuides(p)
    end for
    return []
end function

' Write the whole list back, capped, de-duplicated, and with the first address
' mirrored into the legacy field the guide screens read.
sub SaveProviderCustomEpgGuides(providerId as string, guides as object)
    kept = []
    seen = {}
    for each g in guides
        u = ToStr(GetField(g, "u")).trim()
        if u <> "" and not seen.doesExist(LCase(u))
            seen[LCase(u)] = true
            kept.push(g)
            if kept.count() >= CustomEpgMaxGuides() then exit for
        end if
    end for
    providers = LoadProviders()
    out = []
    for each p in providers
        if ToStr(p.id) = providerId
            ' Brackets, not dot notation — see the note on
            ' ProviderCustomEpgUrl below. Dot-assignment folds the key to
            ' lowercase and the exact-case read above would never find it.
            p["customEpgUrls"] = kept
            p.delete("customepgurls")
            first = ""
            if kept.count() > 0 then first = ToStr(kept[0].u)
            p["customEpgUrl"] = first
            p.delete("customepgurl")
        end if
        out.push(p)
    end for
    SaveProviders(out)
    KLog("guide", "custom guides for " + providerId + ": " + kept.count().toStr() + " saved")
end sub

' Add one. Returns "" on success, or the reason it was refused — full, or
' already there — so the caller can say it out loud rather than doing nothing
' visible.
function AddProviderCustomEpgGuide(providerId as string, url as string) as string
    u = url.trim()
    if u = "" then return "That address was empty."
    guides = ProviderCustomEpgGuidesById(providerId)
    for each g in guides
        if LCase(ToStr(g.u)) = LCase(u) then return "That guide is already on this source."
    end for
    if guides.count() >= CustomEpgMaxGuides()
        return "This source already has " + CustomEpgMaxGuides().toStr() + " guides, which is as many as this Roku can hold. Remove one first."
    end if
    guides.push({ u: u })
    SaveProviderCustomEpgGuides(providerId, guides)
    return ""
end function

sub RemoveProviderCustomEpgGuideAt(providerId as string, idx as integer)
    guides = ProviderCustomEpgGuidesById(providerId)
    if idx < 0 or idx >= guides.count() then return
    kept = []
    for i = 0 to guides.count() - 1
        if i <> idx then kept.push(guides[i])
    end for
    SaveProviderCustomEpgGuides(providerId, kept)
end sub

' Order matters: the first guide that can name a channel claims it, so moving
' one up is how a member says "trust this one".
sub MoveProviderCustomEpgGuide(providerId as string, idx as integer, delta as integer)
    guides = ProviderCustomEpgGuidesById(providerId)
    if idx < 0 or idx >= guides.count() then return
    SaveProviderCustomEpgGuides(providerId, moveInArray(guides, idx, idx + delta))
end sub

' Remember how a guide did the last time it was actually read.
sub SetProviderCustomEpgCoverage(providerId as string, url as string, matched as integer, total as integer)
    guides = ProviderCustomEpgGuidesById(providerId)
    hit = false
    for each g in guides
        if LCase(ToStr(g.u)) = LCase(url.trim())
            g.m = matched
            g.t = total
            hit = true
        end if
    end for
    if hit then SaveProviderCustomEpgGuides(providerId, guides)
end sub

' The line under a guide row. Said in the member's own channels, because a
' programme count says nothing about whether any of it lands on something they
' can watch — the same measure the phone settled on (custom_epg_screen.dart).
function CustomEpgCoverageLabel(g as dynamic) as string
    if g = invalid then return ""
    m_ = GetField(g, "m")
    t_ = GetField(g, "t")
    if m_ = invalid or t_ = invalid then return "Not read yet"
    matched = ToInt(m_)
    total = ToInt(t_)
    if total <= 0 then return "No channels to match it against"
    if matched = 0 then return "Covers none of your " + total.toStr() + " channels"
    return "Covers " + matched.toStr() + " of your " + total.toStr() + " channels"
end function

' Roku can only read a plain, uncompressed XMLTV file under 15 MB (no gunzip
' API, and a DOM parse of anything bigger takes the box down). Checked before
' anything is saved so the reason arrives while they can still act on it,
' rather than as an empty guide later.
function CustomEpgUrlProblem(url as string) as string
    u = url.trim()
    if u = "" then return ""
    lu = LCase(u)
    if lu.left(7) <> "http://" and lu.left(8) <> "https://"
        return "That doesn't look like a web address. It needs to start with http:// or https://."
    end if
    if lu.right(3) = ".gz"
        return "Compressed guides (.gz) can't be read on Roku. Ask for the plain XML version of the same guide."
    end if
    return ""
end function

' Adds a provider and makes it active; returns its id.
function AddProvider(p as object) as string
    providers = LoadProviders()
    p.id = "p" + CreateObject("roDateTime").asSeconds().toStr() + providers.count().toStr()
    providers.push(p)
    SaveProviders(providers)
    ' A MEDIA SERVER NEVER BECOMES THE ACTIVE SOURCE. "Active" means the
    ' Xtream/M3U source the live side asks for channels, lineups and EPG, and
    ' ActiveProvider() feeds XtreamApiUrl, the deep-link player and the live
    ' failure diagnosis. Handing it a Jellyfin would point every one of those
    ' at a server that has no player_api.php — the same class of fault
    ' LiveProviders() exists to prevent, one layer down.
    if not MsIsMediaServer(p) then SetActiveProviderId(p.id)
    ' A brand-new M3U source has nothing saved under the old ordinal ids —
    ' mark the one-time rekey done so its first parse never runs it.
    if ToStr(p.ptype) = "m3u" then RegWrite("m3u_rekey_" + p.id, "1")
    return p.id
end function

' Removing the active source hands active to the first remaining one —
' same behavior as the Android manage-sources screen.
sub RemoveProvider(id as string)
    providers = LoadProviders()
    kept = []
    for each p in providers
        if p.id <> id then kept.push(p)
    end for
    SaveProviders(kept)
    if ActiveProviderId() = id
        if kept.count() > 0
            SetActiveProviderId(kept[0].id)
        else
            RegDelete("active_provider")
        end if
    end if
    DropProviderFromMemory(id)
end sub

' A removed source used to stay in memory. RemoveProvider only rewrote the
' registry; m.global.m3uByProv keeps one slot per source and PublishM3uParse
' only ever ADDS to it, so the removed source's whole channel array lived on
' until the app died. A member on a 512MB Streaming Stick (key 0B9231, v1.0.33)
' tried five providers in a row with "clear this TV" between them: the app sat
' at 16% after a clear, took a 29,000-channel playlist to 56%, cleared THAT and
' opened Home at 50% - nothing had been freed - and was killed on Search. The
' legacy single-guide address m3uTvgUrl was never cleared either, so a guide
' belonging to a source that no longer existed was re-read (Philco, F68625).
' This drops the slot, rebuilds the merged lineup from what is left, resets the
' guide address to a surviving source's, and lets the parsed guide and the live
' lineup go - they described a set of channels that is gone. Called on the
' render thread from Settings, where no player is open to need liveLineup.
sub DropProviderFromMemory(id as string)
    if m.global = invalid or not m.global.hasField("m3uByProv") then return
    slots = m.global.m3uByProv        ' node reads hand back a copy - mutate + reassign
    if slots.doesExist(id) then slots.delete(id)
    m.global.m3uByProv = slots
    merged = []
    tvg = ""
    for each p in LoadProviders()     ' already saved without id
        pid = ToStr(p.id)
        if slots.doesExist(pid)
            for each c in slots[pid].channels
                merged.push(c)
            end for
            if tvg = "" then tvg = ToStr(GetField(slots[pid], "tvgUrl"))
        end if
    end for
    m.global.m3uChannels = merged
    m.global.m3uTvgUrl = tvg
    ' A guide parse in flight is about to write into xmltvById; leave it be.
    if LCase(ToStr(m.global.xmltvState)) <> "loading"
        m.global.xmltvById = {}
        m.global.xmltvAliases = {}
        m.global.xmltvState = ""
    end if
    if m.global.hasField("liveLineup") then m.global.liveLineup = []
    pct = M3uMemPercent()
    m.global.appMemPct = pct
    KLog("m3u", "source removed - " + merged.count().toStr() + " channel(s) left across " + slots.count().toStr() + " source(s) - app at " + pct.toStr() + "% of this device's limit")
end sub

' ---- Asking a source for its lineup again -----------------------------------
' The member pressing Refresh channel list in Settings. Two things live here:
' the guard that stops a bad answer replacing a good lineup, and the clock
' that stops the row being leaned on.
'
' THE GUARD IS ANDROID'S, NUMBER FOR NUMBER — channel_repository.dart's
' shrinkFloor 50, shrinkRatio 4 and isDestructiveShrink, copied rather than
' invented. It must not drift: the phone and the television have to refuse
' the same refresh, or the same member gets two different answers about the
' same provider on the same afternoon. What it caught in the field was a
' provider having a bad minute and handing back eleven channels where the
' member had thirty-one thousand — not empty, so an empty-only check sails
' straight past it and the good list is gone.
'
' Below fifty stored channels the guard stays out of the way: a hand-made
' playlist of eight going to three is somebody editing their own file, and
' guarding that would block a real edit to buy nothing.
'
' WHAT THIS COSTS IN THE REGISTRY. Two keys, both device-level and both bare
' — this is bookkeeping about one television, not a member preference, so it
' is deliberately NOT profile-suffixed and deliberately NOT on
' psetScalarMap(): none of it goes near the wire or the member's phone.
'
'   refresh_last_at   one count of seconds, at most 10 digits.
'                     key 15 + value 10                          = 25 bytes
'   refresh_counts    {"<providerId>": <channels>} for M3U sources only.
'                     A row is a 13-character provider id, two quotes, a
'                     colon, up to 6 digits and a comma = 24 bytes. Pruned
'                     to the sources that still exist on every write and
'                     hard-capped at 12 rows.
'                     key 14 + braces 2 + 12 x 24                = 304 bytes
'
' Ceiling for the whole feature: 329 bytes, and it cannot grow past that
' however many times anybody presses the row.

function ChannelShrinkFloor() as integer
    return 50
end function

function ChannelShrinkRatio() as integer
    return 4
end function

' Is replacing `stored` channels with `offered` a collapse rather than an
' update? Android's isDestructiveShrink, same two numbers, same shape.
function IsDestructiveChannelShrink(stored as integer, offered as integer) as boolean
    if stored < ChannelShrinkFloor() then return false
    return offered * ChannelShrinkRatio() < stored
end function

' Five minutes between one refresh and the next. A refresh is a request to
' the member's provider and repeated taps are the pattern that got this
' house's access banned, so the row refuses rather than asks. Stamped on
' every attempt, successful or not — a provider that is answering with junk
' is exactly the one that must not be asked again straight away — and it is
' short enough to live alongside the guard's own "try again in a few
' minutes".
function ChannelRefreshCooldownSecs() as integer
    return 300
end function

function ChannelRefreshLastAt() as integer
    return ToInt(RegRead("refresh_last_at"))
end function

sub SetChannelRefreshLastAt(secs as integer)
    RegWrite("refresh_last_at", secs.toStr())
end sub

' Seconds still to wait, 0 when the row is ready. A clock that has gone
' backwards (the box resyncing its time) reads as ready rather than as
' hours of waiting.
function ChannelRefreshSecsRemaining() as integer
    last = ChannelRefreshLastAt()
    if last <= 0 then return 0
    now = CreateObject("roDateTime").asSeconds()
    if now < last then return 0
    remaining = ChannelRefreshCooldownSecs() - (now - last)
    if remaining < 0 then return 0
    return remaining
end function

function RefreshCountsMaxRows() as integer
    return 12
end function

function LoadRefreshCounts() as object
    raw = RegRead("refresh_counts")
    if raw = "" then return {}
    parsed = ParseJson(raw)
    if parsed = invalid then return {}
    return parsed
end function

' What this source's playlist held the last time it was accepted. The guard
' needs a number the moment Settings opens, before any screen has parsed a
' playlist this session, and that is the whole reason it is written down.
function RefreshedChannelCount(providerId as string) as integer
    counts = LoadRefreshCounts()
    if counts.doesExist(providerId) then return ToInt(counts[providerId])
    return 0
end function

' Rebuilt from the CURRENT provider list every time, so a removed source
' takes its row with it and the map can never outgrow the sources on the
' box. The cap is belt and braces on top of that.
sub SetRefreshedChannelCount(providerId as string, n as integer)
    if providerId = "" then return
    counts = LoadRefreshCounts()
    kept = {}
    rows = 0
    for each p in LoadProviders()
        if rows >= RefreshCountsMaxRows() then exit for
        pid = ToStr(p.id)
        if pid = providerId
            kept[pid] = n
            rows = rows + 1
        else if counts.doesExist(pid)
            kept[pid] = ToInt(counts[pid])
            rows = rows + 1
        end if
    end for
    RegWrite("refresh_counts", FormatJson(kept))
end sub

' How many categories this source's cache remembers. The guard's baseline
' for an Xtream source: nothing on this box stores its channels, but the
' id->name cache IS overwritten by a refresh and the parental locks and the
' hide/reorder lists are translated through it.
function CachedCategoryCount(scope as string, provId as string) as integer
    return loadCatNameCache(scope, provId).count()
end function

' ---- Sources added from the web (kwickplayer.tv/link) -----------------------
' The store edition can't put a keyboard in front of a member and take a web
' address (Distribution Agreement §10.3(a)), so Xtream and M3U sources are
' added on the website and this box collects them. Everything here is about
' remembering which ones it has already taken, so nothing is added twice and
' a source deleted on the website goes away here too.

' This box's name at the link service.
'
' It is WORKED OUT, not invented and saved. A random token kept in the
' registry would be lost the moment somebody uninstalled the app, and with
' it every source they had added on the website — so the id has to be
' something this box can arrive at again from nothing.
'
' The starting point is the channel client id, which Roku documents as
' persistent and impossible to reset (unlike the advertising id, which a
' member can reset from Settings). That raw value never goes on the wire and
' is never what we send: it is salted and hashed first, so the link service
' sees a one-way derivation, and the string is deliberately different from
' the one KwickSync uses even though both start in the same place.
'
' The registry copy is a shortcut and nothing more. An empty one means a
' cold start, not a new device — recomputing gives the same answer it always
' gave, which is exactly what makes a reinstall pick the member's sources
' back up on its own.
function LinkDeviceId() as string
    id = RegRead("link_device_id")
    if id <> "" then return id
    id = linkDeriveDeviceId()
    RegWrite("link_device_id", id)
    return id
end function

' sha256("kwicklink|" + channelClientId), first 40 hex characters behind an
' "rk" — 42 characters, well inside the 8..64 the link service accepts, and
' 160 bits of a 256-bit digest is far more than enough to keep two boxes
' apart. Same box, same answer, for as long as the box exists.
function linkDeriveDeviceId() as string
    di = CreateObject("roDeviceInfo")
    seed = ToStr(di.getChannelClientId())
    if seed = "" then return linkFallbackDeviceId()
    digest = CreateObject("roEVPDigest")
    digest.setup("sha256")
    ba = CreateObject("roByteArray")
    ba.fromAsciiString("kwicklink|" + seed)
    hex = LCase(digest.process(ba))
    return "rk" + Left(hex, 40)
end function

' Only reachable on a box that won't give us a channel client id at all,
' which shouldn't happen. A random id keeps the feature working; it just
' can't survive an uninstall, so it is stored under its own key and never
' allowed to overwrite a derived one.
function linkFallbackDeviceId() as string
    id = RegRead("link_device_random")
    if id <> "" then return id
    digits = "0123456789abcdef"
    out = "rk" + CreateObject("roDateTime").asSeconds().toStr()
    while out.len() < 42
        out = out + digits.mid(Rnd(16) - 1, 1)
    end while
    RegWrite("link_device_random", out)
    return out
end function

' The highest change number this box has taken from the link service. Fed
' back as "since" so a poll only ever returns what is new.
function LinkCursor() as integer
    raw = RegRead("link_cursor")
    if raw = "" then return 0
    return raw.toInt()
end function

sub SetLinkCursor(n as integer)
    RegWrite("link_cursor", n.toStr())
end sub

' ---- This TV's permanent key ------------------------------------------------
' The link service gives every box a sixteen-character key that never
' changes and never runs out. It is what a member types at
' kwickplayer.tv/link when they come back later — on any phone — to manage
' the playlists on THIS television. The pairing code above is for setting up
' now; this is for coming back.
'
' Kept in the grouped form the member reads off the screen
' ("ABCD-EFGH-JKLM-NPQR"), because that is the only form anything in the app
' ever shows.

' Cached, not fetched, because it is the same value it was the day this box
' was paired: Settings draws it the instant it opens instead of making
' somebody wait on the network for an answer that cannot have changed. Empty
' means nobody has paired this box yet — a blank line, not a fault.
function LinkDeviceKey() as string
    return RegRead("link_device_key")
end function

sub SetLinkDeviceKey(keyFmt as string)
    if keyFmt = "" then return
    ' Same answer as last time is the normal case; don't spend a flash
    ' write on it.
    if keyFmt = RegRead("link_device_key") then return
    RegWrite("link_device_key", keyFmt)
end sub

' The secret that came back with the pairing code, kept because the link
' service will not hand the key over again without it. A box that loses this
' can still get everything back — claiming a fresh pairing code returns the
' same permanent key — it just can't do it quietly in the background.
'
' It stays here. Nothing draws it, nothing logs it, and it only ever travels
' back to the one service it came from.
function LinkSecret() as string
    return RegRead("link_secret")
end function

sub SetLinkSecret(secret as string)
    if secret = "" then return
    if secret = RegRead("link_secret") then return
    RegWrite("link_secret", secret)
end sub

' The source this TV came with, in the shape the link service wants it, or
' an empty one when there is nothing to report — the task turns that empty
' one into an explicit "forget what I told you" on the way out, so signing
' out of KwickTV here takes the row off the website too. Same
' KwickTvProvider() the rest of the app asks — one answer to "is KwickTV
' signed in", not two.
'
' Lives here rather than on the pairing screen because both screens that
' claim a code have to answer this question the same way: the pairing screen
' the member opened on purpose, and the silent restore on the onboarding
' screen after a reinstall. Two copies would be two chances to drift.
'
' NO ACCOUNT NAME TRAVELS WITH IT. "account" is only there to tell two rows
' of the same kind apart on the website, there is only ever one KwickTV
' login on a box, and the member's KwickTV username is half of what signs
' them in. That page opens to anybody holding the key — and the key is
' sixteen characters printed on a television. The name stays on the TV.
function LinkBuiltinSource() as object
    if KwickTvProvider() = invalid then return {}
    return { kind: "kwicktv", label: "KwickTV", account: "" }
end function

' The link service's id for a source -> { rev, provider } where provider is
' the local source id AddProvider handed back.
function LoadLinkedSources() as object
    raw = RegRead("link_sources")
    if raw = "" then return {}
    parsed = ParseJson(raw)
    if parsed = invalid then return {}
    return parsed
end function

sub SaveLinkedSources(map as object)
    RegWrite("link_sources", FormatJson(map))
end sub

' The map above, read the other way round: given a LOCAL source id, what does
' the link service call it? Empty means this source never came from the
' service — a USB playlist, or (in the sideload build) one typed in on the
' remote — and nothing about it is any of the service's business.
'
' This is the only thing that tells the two apart, and it has to be: a source
' added on kwickplayer.tv and one typed in by hand are stored identically on
' purpose (see ApplyLinkedSource), so the provider itself carries no clue.
function LinkedSourceIdFor(localId as string) as string
    if localId = "" then return ""
    known = LoadLinkedSources()
    for each id in known
        if ToStr(GetField(known[id], "provider")) = localId then return id
    end for
    return ""
end function

' Forget that a local source ever came from the service. Called the moment
' the source is removed here, so the service's id for it cannot be sent
' anywhere later — a source id that no longer belongs to anything on this box
' is exactly the thing that must never travel.
'
' Note what this DOESN'T do: it doesn't remember the removal. If the box was
' offline when it happened the website still lists the playlist, and the next
' time a pairing screen polls, the service will offer it again and it will
' come back. That is the honest outcome — the website is where these
' playlists live, and it is still showing this one.
sub ForgetLinkedSource(localId as string)
    if localId = "" then return
    known = LoadLinkedSources()
    ' Collected first and deleted after: taking keys out of an associative
    ' array while walking it is asking for trouble.
    going = []
    for each id in known
        if ToStr(GetField(known[id], "provider")) = localId then going.push(id)
    end for
    if going.count() = 0 then return
    for each id in going
        known.delete(id)
    end for
    SaveLinkedSources(known)
end sub

' Forget the lot, and go back to the start of the service's change feed. This
' is the clean slate in Settings > Account & help and nothing else uses it.
'
' It says NOTHING TO THE SERVICE. The member's playlists live on
' kwickplayer.tv and clearing a television is not asking to lose them — this
' box simply stops remembering that it ever collected any of them.
'
' THE CURSOR HAS TO GO WITH THE MAP. "since" is how a poll asks for only what
' is new, so a box that forgot its sources but kept its place in the feed would
' ask for changes it has already seen, be told there are none, and never get
' the member's playlists back — while kwickplayer.tv carried on listing them.
' Back to zero, the next poll is a box asking for everything from the
' beginning, which is what a reinstalled box already does and is exactly what
' makes "they come back the next time you pair" true.
sub ForgetEveryLinkedSource()
    SaveLinkedSources({})
    SetLinkCursor(0)
end sub

' Makes the local sources match one entry from the link service.
'
' Adding goes through AddProvider — the SAME call the Connect Your Provider
' screen makes when somebody types a source in by hand — so a source that
' arrives this way is stored identically and Live TV, Movies & Series, the
' Guide and KwickSync can't tell the two apart. Removing goes through
' RemoveProvider, which is what the Settings source dialog uses.
'
' Answers { action: "added" | "updated" | "removed" | "none", name: "..." }.
function ApplyLinkedSource(entry as dynamic) as object
    out = { action: "none", name: "" }
    id = ToStr(GetField(entry, "id"))
    if id = "" then return out
    revNo = ToInt(GetField(entry, "rev"))
    known = LoadLinkedSources()
    have = GetField(known, id)

    ' A tombstone: the member deleted it on the website.
    if ToInt(GetField(entry, "deleted")) = 1
        if have = invalid then return out
        localId = ToStr(GetField(have, "provider"))
        out.name = linkProviderName(localId)
        RemoveProvider(localId)
        known.delete(id)
        SaveLinkedSources(known)
        out.action = "removed"
        return out
    end if

    kind = ToStr(GetField(entry, "kind"))
    name = ToStr(GetField(entry, "name"))
    if name = ""
        if kind = "xtream"
            name = "Xtream Source"
        else if kind = "jellyfin"
            name = "Jellyfin Server"
        else if kind = "emby"
            name = "Emby Server"
        else
            name = "M3U Source"
        end if
    end if
    out.name = name

    if have <> invalid
        ' Already here and nothing has changed since last time.
        if revNo <= ToInt(GetField(have, "rev")) then return out
        ' Changed on the website — rewrite the copy that's already here
        ' rather than adding a second one.
        if linkUpdateProvider(ToStr(GetField(have, "provider")), entry, kind, name)
            have.rev = revNo
            known[id] = have
            SaveLinkedSources(known)
            out.action = "updated"
            return out
        end if
        ' The local copy is gone (removed in Settings) — fall through and
        ' add it back.
    end if

    provider = linkProviderFrom(entry, kind, name)
    if provider = invalid then return out
    known[id] = { rev: revNo, provider: AddProvider(provider) }
    SaveLinkedSources(known)
    out.action = "added"
    return out
end function

' Built field for field the way OnboardScreen's finishAdd() builds one,
' dot assignment and all — the registry keys have to come out character for
' character the same as a hand-added source's.
function linkProviderFrom(entry as dynamic, kind as string, name as string) as dynamic
    provider = { id: "", ptype: kind, name: name }
    if kind = "m3u"
        playlist = ToStr(GetField(entry, "url"))
        if playlist = "" then return invalid
        provider.m3uUrl = playlist
        provider.epgUrl = ToStr(GetField(entry, "epg"))
    else if kind = "xtream"
        host = ToStr(GetField(entry, "host"))
        user = ToStr(GetField(entry, "username"))
        pass = ToStr(GetField(entry, "password"))
        if host = "" or user = "" or pass = "" then return invalid
        if Right(host, 1) = "/" then host = Left(host, Len(host) - 1)
        provider.server = host
        provider.username = user
        provider.password = pass
    else if kind = "jellyfin" or kind = "emby"
        ' A member's own Jellyfin/Emby, paired from kwickplayer.tv because a
        ' Roku app may not take a typed web address (Distribution Agreement
        ' 10.3(a)). What arrives is the address and the sign-in; the token,
        ' the user id and the server id are things only the SERVER can tell
        ' us, so they are left empty here and filled in by the sign-in the
        ' app performs on its own (see MediaServerSignIn). Until that lands
        ' this source has no token and no serverId — and MsSrcToken()
        ' deliberately returns "" for a server with no id, which is why
        ' nothing may sync until it has one.
        host = ToStr(GetField(entry, "url"))
        user = ToStr(GetField(entry, "username"))
        pass = ToStr(GetField(entry, "password"))
        if host = "" or user = "" or pass = "" then return invalid
        while Len(host) > 0 and Right(host, 1) = "/"
            host = Left(host, Len(host) - 1)
        end while
        provider.server = host
        provider.username = user
        provider.password = pass
        provider.token = ""
        provider.userId = ""
        provider.serverId = ""
    else
        ' A kind this build doesn't know about. Left alone, not guessed at.
        return invalid
    end if
    return provider
end function

function linkUpdateProvider(localId as string, entry as dynamic, kind as string, name as string) as boolean
    ' Anything left over from an edit that was cut short finishes FIRST. The
    ' note below only has room for one move at a time, and a second edit must
    ' never write over one that hasn't been carried out yet.
    RunPendingSrcTokenMove()
    providers = LoadProviders()
    for i = 0 to providers.count() - 1
        if ToStr(providers[i].id) = localId
            fresh = linkProviderFrom(entry, kind, name)
            if fresh = invalid then return false
            fresh.id = localId
            ' A media server's sign-in belongs to the app, not to the website:
            ' the token, the user id and the server id were learned by signing
            ' in and never travel through kwickplayer.tv. An edit that leaves
            ' the address and the username alone must keep them, or the source
            ' would go back to being signed out every time the member renamed
            ' it. Change either one and they are dropped on purpose, because
            ' they would no longer be true.
            if MsIsMediaServer(fresh) and MsIsMediaServer(providers[i])
                sameAddr = (LCase(ToStr(fresh.server)) = LCase(ToStr(providers[i].server)))
                sameUser = (ToStr(fresh.username) = ToStr(providers[i].username))
                if sameAddr and sameUser
                    fresh.token = ToStr(providers[i].token)
                    fresh.userId = ToStr(providers[i].userId)
                    fresh.serverId = ToStr(providers[i].serverId)
                end if
            end if
            ' The member may have changed the server address or the playlist
            ' address, and the source's token is worked out FROM that address
            ' — so everything saved against the old token has to follow the
            ' source across to the new one. The note is written BEFORE the
            ' swap on purpose: once the stored source holds the new address
            ' there is no way left to work out what the old token was.
            oldTok = SrcTokenFor(providers[i])
            newTok = SrcTokenFor(fresh)
            moving = (oldTok <> newTok and oldTok <> "" and newTok <> "")
            if moving then NoteSrcTokenMove(oldTok, newTok)
            providers[i] = fresh
            SaveProviders(providers)
            if moving then RunPendingSrcTokenMove()
            return true
        end if
    end for
    return false
end function

function linkProviderName(localId as string) as string
    for each p in LoadProviders()
        if ToStr(p.id) = localId then return ToStr(p.name)
    end for
    return "that source"
end function

' ---- A source edited on the website keeps its favorites ---------------------
' Editing an Xtream server address or a playlist address on kwickplayer.tv
' rewrites the source in place — and the source TOKEN is worked out from that
' address (see SrcTokenFor), so the token changes underneath everything keyed
' to it: favorite channels, favorite movies & series, items inside favorite
' lists, recently watched, resume points and watch-history metadata. Left
' alone, all of it would still be saved but would belong to a source that no
' longer exists, which to the member looks exactly like losing it.
'
' What happens is a plain RENAME. Every row carrying the old token is
' rewritten to carry the new one. Nothing is created, nothing is deleted, and
' a row already carrying the new token is left exactly as it is — so running
' this a second time does nothing, and a run cut short by a power cut is
' simply finished by the next one.
'
' The move is written down before the source is swapped and rubbed out only
' once it has finished, so there is always something to finish from.

' Remember a move that hasn't been carried out yet.
sub NoteSrcTokenMove(fromTok as string, toTok as string)
    RegWrite("src_token_move", FormatJson({ from: fromTok, to: toTok }))
end sub

' Carry out whatever move is written down, then rub the note out. Cheap
' enough to call at launch: one registry read when there is nothing to do.
sub RunPendingSrcTokenMove()
    raw = RegRead("src_token_move")
    if raw = "" then return
    note = ParseJson(raw)
    if note = invalid
        RegDelete("src_token_move")
        return
    end if
    moveSrcToken(ToStr(GetField(note, "from")), ToStr(GetField(note, "to")))
    RegDelete("src_token_move")
end sub

' Rewrite everything that names fromTok so it names toTok instead.
sub moveSrcToken(fromTok as string, toTok as string)
    if fromTok = "" or toTok = "" then return   ' "" is the KwickTV login's own namespace — never ours to move
    if fromTok = toTok then return
    ' Two sources now answering to the same address would have their saved
    ' items blended together, and one member's two sources merging is worse
    ' than a source's favorites sitting still. Counting is the honest test:
    ' after the swap the edited source itself answers to the new token, so
    ' one is expected and two is a clash.
    clash = 0
    for each p in LoadProviders()
        if SrcTokenFor(p) = toTok then clash = clash + 1
    end for
    if clash > 1
        KLog("link", "source edit: two sources now share one address - saved items left where they are")
        return
    end if
    KLog("link", "source edit: moving saved items across to the new address")

    ' The sync mirror goes FIRST, before a single stored row is renamed. The
    ' mirror is what the sync engine compares the real stores against, so a
    ' half-done rename with the mirror untouched reads as "the member deleted
    ' these" — see forgetSyncedRowsFor. Done in this order, a run cut short
    ' leaves rows that are merely re-sent, never rows that are deleted.
    RetireSrcToken(fromTok, toTok)
    forgetSyncedRowsFor(fromTok)

    for each prof in EnsureDefaultProfile()
        suffix = ProfileSuffixFor(ToStr(prof.id))
        moveTokenInRows("fav_channels" + suffix, fromTok, toTok)
        moveTokenInRows("recent_channels" + suffix, fromTok, toTok)
        moveTokenInRows("fav_vod" + suffix, fromTok, toTok)
        moveTokenInRows("recent_vod" + suffix, fromTok, toTok)
    end for
    moveTokenInLists(fromTok, toTok)
    moveTokenInResumeKeys(fromTok, toTok)
end sub

' One stored list: rows whose src is the old token now carry the new one.
' Rows already on the new token, and rows belonging to any other source, are
' not touched — which is what makes a second run a no-op.
sub moveTokenInRows(key as string, fromTok as string, toTok as string)
    entries = LoadJsonArray(key)
    if entries.count() = 0 then return
    changed = false
    for each e in entries
        if ToStr(GetField(e, "src")) = fromTok
            e.src = toTok
            changed = true
        end if
    end for
    if changed then SaveJsonArray(key, entries)
end sub

' Favorite lists are stored per source (fav_lists_<providerId>...), so every
' one of those keys is walked rather than just the active source's — a list
' saved under a source that has since gone still names its items by source.
' Channel items also keep the wire key and route they arrived with, and both
' of those spell the source token out in full.
'
' CASE TRAP, the same one ProviderCustomEpgUrl warns about: "wireKey" was
' written with dot notation, which folds it to "wirekey", but ParseJson hands
' the saved list back as a CASE-SENSITIVE map — so both spellings are looked
' for and whichever one is actually there is the one written back.
sub moveTokenInLists(fromTok as string, toTok as string)
    oldKey = "channel:" + fromTok + ":"
    oldRoute = "/channel/" + fromTok + ":"
    sec = CreateObject("roRegistrySection", "kwickplayer")
    for each k in sec.getKeyList()
        ks = ToStr(k)
        if ks.left(10) = "fav_lists_"
            lists = LoadJsonArray(ks)
            changed = false
            for each l in lists
                items = ToArray(l.items)
                for each it in items
                    if ToStr(GetField(it, "src")) = fromTok
                        it["src"] = toTok
                        for each spelling in ["wireKey", "wirekey"]
                            wk = ToStr(GetField(it, spelling))
                            if wk.left(Len(oldKey)) = oldKey then it[spelling] = "channel:" + toTok + ":" + Mid(wk, Len(oldKey) + 1)
                        end for
                        rt = ToStr(GetField(it, "route"))
                        if rt.left(Len(oldRoute)) = oldRoute then it["route"] = "/channel/" + toTok + ":" + Mid(rt, Len(oldRoute) + 1)
                        changed = true
                    end if
                end for
                l.items = items
            end for
            if changed then SaveJsonArray(ks, lists)
        end if
    end for
end sub

' Resume points, watch-history metadata and finished marks are named by the
' registry key itself ("movie:<src>~<id>", "ep:<src>~<id>", with the profile
' id and a bar in front for every profile but the default), so these are
' RENAMED rather than rewritten. Same shape as requalifyResumeKeys further
' down.
'
' "kwick_seen" rides along here for free, and it HAS to: a finished mark is
' keyed by the same string as the resume point it replaced, so a source whose
' address was edited would leave every mark naming a source that no longer
' exists — episode ticks and Continue Watching would quietly forget an entire
' source's viewing. The rename is value-agnostic (sec.write(nk, sec.read(ks))),
' so it does not care that this section's values are not the same shape.
sub moveTokenInResumeKeys(fromTok as string, toTok as string)
    for each section in ["kwick_resume", "kwick_hist", "kwick_seen"]
        sec = CreateObject("roRegistrySection", section)
        changed = false
        for each k in sec.getKeyList()
            ks = ToStr(k)
            at = Instr(1, ks, "|")
            prefix = ""
            bare = ks
            if at > 0
                prefix = Left(ks, at)     ' the profile id AND its bar
                bare = Mid(ks, at + 1)
            end if
            newBare = ""
            if bare.left(6) = "movie:" and Mid(bare, 7, Len(fromTok) + 1) = fromTok + "~"
                newBare = "movie:" + toTok + "~" + Mid(bare, 7 + Len(fromTok) + 1)
            else if bare.left(3) = "ep:" and Mid(bare, 4, Len(fromTok) + 1) = fromTok + "~"
                newBare = "ep:" + toTok + "~" + Mid(bare, 4 + Len(fromTok) + 1)
            end if
            if newBare <> ""
                nk = prefix + newBare
                ' Never write over something already sitting under the new
                ' name: it can only have come from another device that made
                ' the same move first, and its position is the newer one.
                if not sec.exists(nk) then sec.write(nk, sec.read(ks))
                sec.delete(ks)
                changed = true
            end if
        end for
        if changed then sec.flush()
    end for
end sub

' ---- Retired source tokens (the sync side of a source edit) -----------------
' The KwickSync mirror is this device's record of what the locker holds. Rows
' keyed to the old token are FORGOTTEN — dropped from the mirror, never
' tombstoned.
'
' Dropping is the whole point. The mirror is what reconcile() compares the
' real stores against: leave an old-token row in it and the next cycle sees a
' row this device once sent that is no longer among the things it holds,
' reads that as "the member deleted this", and tombstones it — taking the
' favorite off the member's other devices as well. A row gone from the mirror
' cannot be tombstoned by anything, and because the renamed rows are missing
' from the mirror too, the next cycle sends them up as fresh additions under
' the new token. The old rows stay in the locker as harmless leftovers.
'
' A background sync can be halfway through a cycle while all this happens,
' and it will save its own (older) copy of the mirror when it finishes, old
' rows and all. So the old token is also written down as RETIRED, and the
' sync engine sweeps retired rows out of the mirror at the top of every
' cycle — the forgetting is a one-off, the retired list is what makes it
' stick. A token that comes back into use is taken off the list, so nothing
' is ever swept while a real source answers to it.

function RetiredSrcTokens() as object
    raw = RegRead("src_tokens_retired")
    if raw = "" then return []
    p = ParseJson(raw)
    if p = invalid then return []
    return ToArray(p)
end function

' Retire the token being moved away from, and un-retire the one being moved
' to (a member can edit an address back to what it was). Capped, oldest
' first, so the list can never grow without end.
sub RetireSrcToken(fromTok as string, toTok as string)
    kept = [fromTok]
    for each t in RetiredSrcTokens()
        ts = ToStr(t)
        if ts <> "" and ts <> fromTok and ts <> toTok and kept.count() < 8 then kept.push(ts)
    end for
    RegWrite("src_tokens_retired", FormatJson(kept))
end sub

' Is this a token a source was moved off, with nothing answering to it now?
' Both halves matter: the second one is what stops rows churning if the
' member edits an address back to one that used to be retired.
function IsRetiredSrcToken(token as string) as boolean
    if token = "" then return false
    found = false
    for each t in RetiredSrcTokens()
        if ToStr(t) = token then found = true
    end for
    if not found then return false
    return ProviderForSrcToken(token) = invalid
end function

' Drop this device's memory of every synced row belonging to one token.
sub forgetSyncedRowsFor(token as string)
    mirror = LoadSyncMirror()
    drop = []
    for each key in mirror
        if SyncKeyNamesSrc(ToStr(key), token) then drop.push(ToStr(key))
    end for
    if drop.count() = 0 then return
    for each k in drop
        mirror.delete(k)
    end for
    SaveSyncMirror(mirror)
    KLog("link", "source edit: " + drop.count().toStr() + " synced row(s) will be sent again under the new address")
end sub

' Does a sync key name this source? The token sits in a different place in
' each kind of key:
'   favvod:<profile>:<src>:<kind>:<id>
'   favch:<profile>:<src>:<streamId>
'   hist:<profile>:vod:<src>~<id>      (also episode:, and bare for live)
' favlist rows carry the token inside their items instead of in the key —
' their contents change with those items, so the next cycle sends them again
' on its own. pset rows never carry a source token at all.
function SyncKeyNamesSrc(key as string, token as string) as boolean
    if token = "" then return false
    for each kind in ["favvod:", "favch:", "hist:"]
        if key.left(Len(kind)) = kind
            tail = srcKeyTail(key, kind)
            if tail = "" then return false
            if kind = "hist:"
                if tail.left(4) = "vod:" then tail = Mid(tail, 5)
                if tail.left(8) = "episode:" then tail = Mid(tail, 9)
                return tail.left(Len(token) + 1) = token + "~"
            end if
            return tail.left(Len(token) + 1) = token + ":"
        end if
    end for
    return false
end function

' Everything past "<kind>:<profile>:" — the profile id never holds a colon.
function srcKeyTail(key as string, kindPrefix as string) as string
    rest = Mid(key, Len(kindPrefix) + 1)
    at = Instr(1, rest, ":")
    if at <= 1 then return ""
    return Mid(rest, at + 1)
end function

' ---- One-time migration: existing rows learn their source -------------------
' Runs once at launch (AppScene init), before any screen reads a store.
'
' Bare rows (no src field) have always meant "the KwickTV login's" on the
' sync wire, so with a KwickTV login present they stay untouched — which is
' the entire installed base doing nothing, the safest possible migration.
' Without one, bare rows can only have come from whatever sources the box
' has, so they're tagged with the best owner available: ordinal M3U ids
' name an M3U source by their shape; anything else goes to the active
' Xtream source (or the first one).
sub RunSrcKeyMigration()
    if RegRead("srckey_migrated") = "1" then return
    RegWrite("srckey_migrated", "1")
    providers = LoadProviders()
    if providers.count() = 0 then return   ' fresh install — nothing saved yet
    hasKwick = (KwickTvProvider() <> invalid)
    active = ActiveProvider()

    xtToken = ""
    if not hasKwick
        if active <> invalid and ToStr(active.ptype) = "xtream"
            xtToken = SrcTokenFor(active)
        else
            for each p in providers
                if ToStr(p.ptype) = "xtream"
                    xtToken = SrcTokenFor(p)
                    exit for
                end if
            end for
        end if
    end if

    ' Only when there's exactly ONE M3U source is an ordinal id's owner
    ' certain. With several, the rows are left untagged for the per-playlist
    ' rekey to claim by url match — guessing here would bind them to the
    ' wrong playlist permanently.
    m3uToken = ""
    m3uCount = 0
    for each p in providers
        if ToStr(p.ptype) = "m3u"
            m3uCount = m3uCount + 1
            if m3uCount = 1 then m3uToken = SrcTokenFor(p)
        end if
    end for
    if m3uCount <> 1 then m3uToken = ""

    for each prof in EnsureDefaultProfile()
        suffix = ProfileSuffixFor(ToStr(prof.id))
        tagChannelEntries("fav_channels" + suffix, xtToken, m3uToken)
        tagChannelEntries("recent_channels" + suffix, xtToken, m3uToken)
        tagVodEntries("fav_vod" + suffix, xtToken)
        tagVodEntries("recent_vod" + suffix, xtToken)
        if xtToken <> "" then requalifyResumeKeys(ToStr(prof.id), xtToken)
    end for
end sub

' Channel rows: ordinal M3U ids belong to the M3U source regardless of what
' else is signed in; other bare ids go to the Xtream token when one was
' chosen (i.e. no KwickTV login), else stay bare.
sub tagChannelEntries(key as string, xtToken as string, m3uToken as string)
    entries = LoadJsonArray(key)
    if entries.count() = 0 then return
    changed = false
    for each e in entries
        if ToStr(GetField(e, "src")) = ""
            if IsLegacyM3uId(ToStr(GetField(e, "streamId")))
                if m3uToken <> ""
                    e.src = m3uToken
                    changed = true
                end if
            else if xtToken <> ""
                e.src = xtToken
                changed = true
            end if
        end if
    end for
    if changed then SaveJsonArray(key, entries)
end sub

' VOD rows only ever come from Xtream-style sources.
sub tagVodEntries(key as string, xtToken as string)
    if xtToken = "" then return
    entries = LoadJsonArray(key)
    if entries.count() = 0 then return
    changed = false
    for each e in entries
        if ToStr(GetField(e, "src")) = ""
            e.src = xtToken
            changed = true
        end if
    end for
    if changed then SaveJsonArray(key, entries)
end sub

' Rewrite one profile's bare resume/history keys ("movie:123" / "ep:456")
' to the source-qualified shape ("movie:<src>~123"). Only reached when the
' box has no KwickTV login — bare keys are KwickTV's otherwise.
'
' "kwick_seen" is swept with them for the same reason moveTokenInResumeKeys
' sweeps it: finished marks use the identical key strings, so a mark left
' bare here would never again match the key its callers build.
sub requalifyResumeKeys(profileId as string, token as string)
    prefix = ""
    if profileId <> "default" and profileId <> "" then prefix = profileId + "|"
    for each section in ["kwick_resume", "kwick_hist", "kwick_seen"]
        sec = CreateObject("roRegistrySection", section)
        changed = false
        for each k in sec.getKeyList()
            ks = ToStr(k)
            mine = false
            if prefix = ""
                mine = (Instr(1, ks, "|") = 0)
            else
                mine = (Len(ks) > Len(prefix) and ks.left(Len(prefix)) = prefix)
            end if
            if mine
                bare = Mid(ks, Len(prefix) + 1)
                newBare = ""
                if bare.left(6) = "movie:" and Instr(1, bare, "~") = 0
                    newBare = "movie:" + token + "~" + Mid(bare, 7)
                else if bare.left(3) = "ep:" and Instr(1, bare, "~") = 0
                    newBare = "ep:" + token + "~" + Mid(bare, 4)
                end if
                if newBare <> ""
                    sec.write(prefix + newBare, sec.read(ks))
                    sec.delete(ks)
                    changed = true
                end if
            end if
        end for
        if changed then sec.flush()
    end for
end sub

' ---- KwickSync (cross-device sync) ------------------------------------------
' Gated on a first-class KwickTV login (a provider with ptype "kwicktv") plus
' the per-device toggle. Talks to the same locker the Android app uses
' (Branding.syncApiUrl). Keys are per-profile: <kind>:<profileSyncId>:<item>.

function SyncDeviceId() as string
    id = RegRead("sync_device")
    if id <> "" then return id
    di = CreateObject("roDeviceInfo")
    id = di.getChannelClientId()   ' stable UUID, unique per device+channel
    if id = "" then id = "roku" + CreateObject("roDateTime").asSeconds().toStr()
    RegWrite("sync_device", id)
    return id
end function

' KwickSync is ON until the member turns it off — the Android app has always
' defaulted it true (user_preferences.dart), and Roku read an unset registry
' key as OFF, which quietly broke the whole feature on any fresh install.
'
' What that cost: signing in with KwickTV on a new box skipped the profile
' fetch in AppScene.startProfiles() (it is gated on SyncEnabled), so
' EnsureDefaultProfile made ONE local profile, the picker never appeared,
' and members with several profiles landed in a stranger's empty account
' with no sign anything was wrong. Background sync never started either.
'
' Only an explicit "0" counts as off, so anyone who deliberately turned it
' off keeps their choice.
function SyncEnabled() as boolean
    raw = RegRead("sync_enabled")
    if raw = "" then return true
    return raw = "1"
end function

sub SetSyncEnabled(v as boolean)
    if v then RegWrite("sync_enabled", "1") else RegWrite("sync_enabled", "0")
end sub

' Cursor is a small server-assigned rev counter (fits a 32-bit int).
function SyncCursor() as integer
    raw = RegRead("sync_cursor")
    if raw = "" then return 0
    return raw.toInt()
end function

sub SetSyncCursor(n as integer)
    RegWrite("sync_cursor", n.toStr())
end sub

' Stored in epoch SECONDS (32-bit safe) — used only for the "last synced X
' ago" label, so second precision is plenty.
function SyncLastAt() as integer
    raw = RegRead("sync_last_at")
    if raw = "" then return 0
    return raw.toInt()
end function

sub SetSyncLastAt(secs as integer)
    RegWrite("sync_last_at", secs.toStr())
end sub

' ---- Single-flight slot (only one sync cycle at a time) ---------------------
' A SyncTask is started from four places — AppShell's 90s background timer,
' Settings' "Sync now", AppScene's fetch-before-create profile fetch, and
' Settings' final push before sign-out. Each of those used to check only its
' OWN task node's state, so none of them could see another's, and two cycles
' could run side by side.
'
' That was silent data loss, not just wasted work. Both cycles read the mirror
' with LoadSyncMirror(), rewrite it in memory, and write it back with
' SaveSyncMirror() — last writer wins, so the loser's applied rows vanish. But
' BOTH cycles call SetSyncCursor(), so the locker has been told those rows were
' received. They are never sent again. The member sees a favorite that never
' turned up on the other device, with no error to report.
'
' Everything below lives on m.global (session only, see AppScene.init) so a
' crash mid-cycle costs one relaunch instead of locking sync out permanently.
'
' Fail OPEN if the fields are missing: an older AppScene without them should
' behave exactly as it does today, not lose sync entirely.

' How long a claim may sit untouched before the next cycle assumes the holder
' is dead and takes it. There has to be a steal: a task node collected mid-run
' never reaches its release, and with no steal that is sync switched off for
' the rest of the session.
'
' 40s is measured against ONE step, not a whole cycle, because runSync touches
' the claim as it goes (SyncTouchSlot). The longest step is a single push
' request, capped at 25s by the wait() in SyncTask.httpPost, plus reading the
' mirror and projecting the feed either side of it. A big first sync is several
' 400-op chunks and so several of those 25s waits — with the touches it is
' nowhere near stale, which is exactly why they are there. Without them a plain
' 40s would declare a healthy long cycle dead and start a second one on top of
' it, which is the bug this section exists to stop.
function SyncSlotStaleSecs() as integer
    return 40
end function

' Take the slot, or report that someone else has it. Silent either way — a
' refused cycle is not an error, the next tick picks the work up.
function SyncClaimSlot() as boolean
    if m.global = invalid or not m.global.hasField("syncRunning") then return true
    now = CreateObject("roDateTime").asSeconds()
    if m.global.syncRunning = true
        age = now - m.global.syncClaimedAt
        ' A negative age means the clock moved backwards under us, so the age
        ' says nothing. Treat that as "still running" rather than stealing: a
        ' live cycle re-times the claim on its next touch and the number comes
        ' right, whereas stealing on a number we don't trust is the double-run
        ' this whole section exists to stop.
        if age < 0 then return false
        if age < SyncSlotStaleSecs() then return false
        KLog("sync", "previous cycle left the slot held for " + age.toStr() + "s - taking it")
    end if
    ' Write, then read back. Each field write is safe on its own, but this is a
    ' read-modify-write across threads — every claim happens on a task thread
    ' and each SyncTask is its own thread — so two cycles can both get past the
    ' test above. Whoever's stamp is still in the field afterwards owns the
    ' slot; the other one loses here and backs off instead of running.
    '
    ' Honest about the limit: the stamp is epoch SECONDS (32-bit safe, same
    ' convention as sync_last_at), so two claims inside the same second read
    ' back the same number and both believe they won. That window is
    ' microseconds wide and needs two task threads to reach this line at once,
    ' while the overlap being fixed is seconds to minutes wide and happens on
    ' every tick that lands on a manual sync. Roku gives BrightScript no
    ' compare-and-swap, so this is as tight as the platform allows.
    m.global.syncRunning = true
    m.global.syncClaimedAt = now
    if m.global.syncClaimedAt <> now then return false
    m.syncSlotStamp = now
    return true
end function

' Say we are still alive, so a long but healthy cycle is never mistaken for a
' dead one. No-op if the slot was stolen out from under us — the thief owns it
' now and must not have its clock reset by us.
sub SyncTouchSlot()
    if m.global = invalid or not m.global.hasField("syncRunning") then return
    if m.syncSlotStamp = invalid or m.global.syncClaimedAt <> m.syncSlotStamp then return
    now = CreateObject("roDateTime").asSeconds()
    m.global.syncClaimedAt = now
    m.syncSlotStamp = now
end sub

' Give the slot back. Ownership-checked for the same reason as the touch: a
' cycle whose claim was stolen would otherwise clear the new owner's flag on
' the way out and let a third cycle in beside it.
'
' Called with no stamp of our own (from the render thread, not from inside a
' cycle) it releases unconditionally — see AppScene.startProfiles, the one
' caller that needs that.
sub SyncReleaseSlot()
    if m.global = invalid or not m.global.hasField("syncRunning") then return
    if m.syncSlotStamp <> invalid and m.global.syncClaimedAt <> m.syncSlotStamp then return
    m.syncSlotStamp = invalid
    m.global.syncClaimedAt = 0
    m.global.syncRunning = false
end sub

' ---- "This device doesn't know the account's profiles yet" ------------------
' Straight after a first sign-in this box holds NO profiles, while the account's
' real ones are still sitting in the locker. For that window anything this
' device could say about profiles is wrong, so a sync cycle is allowed to
' LISTEN and not to SPEAK.
'
' What "not speaking" means is two skipped steps in SyncTask.runSync — no
' buildSnapshot(), no reconcile(). A cycle that never takes a snapshot cannot
' mark a row dirty, so it pushes nothing new; a cycle that never reconciles
' cannot tombstone anything, so it deletes nothing. The pull and the projection
' run in full, which is the entire point of the cycle at that moment.
'
' SESSION-SCOPED ON PURPOSE, on m.global and never the registry — the same
' reasoning as syncRunning above and linkJustCleared beside it, and more so. A
' persisted flag that ever failed to clear would suppress this device's pushes
' FOREVER and silently: the member would go on favoriting things on their
' television and none of it would ever reach their phone, with nothing on
' screen to say why. Lost to a crash it costs one relaunch, and the second net
' in SyncPullOnly() still holds.
'
' Fail OPEN when the field is missing, like every other m.global helper here:
' an older AppScene without it must behave exactly as it does today.
function SyncProfilesUnknown() as boolean
    if m.global = invalid or not m.global.hasField("profilesUnknown") then return false
    return m.global.profilesUnknown = true
end function

sub SetSyncProfilesUnknown(v as boolean)
    if m.global = invalid or not m.global.hasField("profilesUnknown") then return
    m.global.profilesUnknown = v
end sub

' Is this cycle pull-only? Two independent reasons, and the second one is the
' important one:
'
'   1. The flag above — we are mid fetch-before-create and know it.
'   2. There are NO local profiles at all. That test needs no flag, no timing
'      and no cooperation from whoever started the cycle, and it closes a hole
'      that is there on its own: buildSnapshot() loops over LoadProfiles(), so
'      with none it hands back an EMPTY snapshot, and reconcile() reads an
'      empty snapshot as "the member deleted every last thing" — profile rows
'      included, because profiles are exempt from the ownership rule. One cycle
'      at the wrong moment would tombstone the account's whole locker on every
'      device the member owns. A box with no profiles has nothing of its own to
'      push anyway, so keeping it quiet costs it precisely nothing.
function SyncPullOnly() as boolean
    if SyncProfilesUnknown() then return true
    return LoadProfiles().count() = 0
end function

' ---- Sign-out safety --------------------------------------------------------
' Profiles, favorites, recents and watch history belong to the ACCOUNT, not
' to a source, and carry no provider id — so after signing out they would
' replay against whatever source is connected next, offering items that only
' existed in the catalogue that was just removed. Sign-out therefore clears
' them, but ONLY when KwickSync definitely holds a copy: for a member with no
' working backup the local copy is the ONLY copy.
'
' Deliberately NOT gated on "is this a KwickTV account" — having an account
' is not the same as having a backup (someone who signed in five minutes ago,
' or whose sync keeps failing, or who is offline, has one and not the other).

' Is any local change still sitting in the mirror waiting to upload?
function SyncHasPendingChanges() as boolean
    mirror = LoadSyncMirror()
    for each key in mirror
        if mirror[key].dirty = true then return true
    end for
    return false
end function

' All of these must hold before the local copy may be cleared.
function SyncBackupIsCurrent() as boolean
    if not SyncEnabled() then return false          ' member turned sync off
    if not SyncEligible() then return false         ' no KwickTV login = no locker
    if SyncLastAt() <= 0 then return false          ' never completed a sync
    if SyncHasPendingChanges() then return false    ' still waiting to upload
    return true
end function

' Drop this device's copy of everything that belongs to the account: profiles
' and their favorites, lists, recents, per-profile settings, resume points and
' watch history. Signing back in restores it all from KwickSync.
'
' The sync cursor and mirror MUST go too. Leaving a cursor behind would make
' the next sign-in ask the server only for changes SINCE that point, receive
' nothing, and leave the member with an empty app — turning this into
' permanent data loss. Device-level things (sync on/off, this device's sync
' id, the providers themselves) are left alone.
sub ClearAccountDataOnSignOut()
    ' Prefix matches, so "chan_order" catches every profile's copy of it and
    ' "pref_merge_" catches both of the two-rows-or-one switches.
    '
    ' "pref_media_bar_" was simply missing — the four Media Bar settings are
    ' per-profile account settings that travel over KwickSync exactly like the
    ' three Home-row switches beside them, so a sign-out that left them behind
    ' handed the next member to sign in on this box somebody else's choices.
    '
    ' "src_colors" and "seen_unmark_q" are both account data too. The first is
    ' the colours the member painted their sources with, pulled down from their
    ' phone; the second is a queue of "I have not actually watched this" that
    ' has not been uploaded yet. Left behind, the first would paint the next
    ' member's sources with somebody else's choices, and the second would push
    ' a stranger's unmarks into the new account the moment sync ran.
    '
    ' "pref_controls_timeout" (JB-10) is here for the same reason the Media Bar
    ' four are: it is a per-profile account setting that travels over KwickSync,
    ' so leaving it behind would hand the next member to sign in on this box
    ' somebody else's choice.
    '
    ' THE ADD-ON ACCOUNTS ("addon_") ARE DELIBERATELY NOT IN THIS LIST, which is
    ' the opposite of the rule above and needs saying. This sub also runs on the
    ' small sign-out — the KwickTV row in Sources, which Mason's own words scope
    ' as "the account, and nothing else" — and a member's OpenSubtitles or Trakt
    ' sign-in is not part of their KwickTV account: it is their login on
    ' somebody else's service, it is not in the KwickSync locker, and unlike
    ' everything above it could not be restored by signing back in. The case
    ' this leaves open is a television changing hands, and that is answered
    ' where it belongs — the clean slate ("Sign out and clear this TV") signs
    ' the add-ons out too, in SettingsCategoryScreen's clearEverySource, and its
    ' confirmation says so before anything is cleared.
    '
    ' THE TRACKING SWITCHES ("pref_trakt_" / "pref_simkl_") ARE NOT IN THIS LIST
    ' EITHER, and for the same reason: they govern that same add-on sign-in and
    ' are device-level with it. Check any new prefix added below against them —
    ' none of the twelve above is a prefix of either, and none may become one,
    ' or a KwickTV sign-out would silently switch a member's scrobbling off.
    ' They go where the sign-ins go: ClearTrackerSettings, called from the
    ' add-on's own Sign out and from the clean slate.
    prefixes = ["profiles", "active_profile", "fav_channels", "fav_vod", "recent_channels", "recent_vod", "fav_lists_", "cat_order_", "cat_hidden_", "cat_locked_", "cat_names_", "chan_hidden_", "chan_order", "parental_pin", "parental_mode", "parental_session", "adult_allowed", "pref_channel_sort", "pref_caption_lang", "pref_start_muted", "pref_captions_auto", "pref_show_recents", "pref_show_favorites", "pref_show_picks", "pref_merge_", "pref_media_bar_", "pref_recent_channels_max_age_days", "pref_recent_vod_max_age_days", "pref_controls_timeout", "subs_pick", "sync_mirror", "sync_cursor", "sync_last_at", "src_colors", "seen_unmark_q"]
    sec = CreateObject("roRegistrySection", "kwickplayer")
    changed = false
    for each k in sec.getKeyList()
        ks = ToStr(k)
        for each p in prefixes
            if Len(ks) >= Len(p) and ks.left(Len(p)) = p
                sec.delete(ks)
                changed = true
                exit for
            end if
        end for
    end for
    if changed then sec.flush()
    ' Resume points, watch-history metadata and finished marks live in their
    ' own sections. Finished marks belong to the ACCOUNT exactly like the
    ' other two — they sync — so signing out has to drop this device's copy
    ' with the rest, or the next member to sign in on this box inherits
    ' somebody else's watched ticks.
    for each section in ["kwick_resume", "kwick_hist", "kwick_seen"]
        s = CreateObject("roRegistrySection", section)
        keys = s.getKeyList()
        if keys.count() > 0
            for each k in keys
                s.delete(ToStr(k))
            end for
            s.flush()
        end if
    end for
end sub

' The KwickTV login that unlocks sync (username/password/server), or invalid.
function KwickTvProvider() as dynamic
    for each p in LoadProviders()
        if ToStr(p.ptype) = "kwicktv" then return p
    end for
    return invalid
end function

function SyncEligible() as boolean
    return KwickTvProvider() <> invalid
end function

' Generic JSON-array registry IO (used by the sync engine to read/write a
' specific profile's scoped stores by explicit key).
function LoadJsonArray(key as string) as object
    raw = RegRead(key)
    if raw = "" then return []
    p = ParseJson(raw)
    if p = invalid then return []
    return ToArray(p)
end function

sub SaveJsonArray(key as string, arr as object)
    RegWrite(key, FormatJson(arr))
end sub

' The content-namespace suffix for a given profile id (default = legacy "").
function ProfileSuffixFor(id as string) as string
    if id = "default" or id = "" then return ""
    return "_" + id
end function

' Create/update a profile by its cross-device syncId (used by the sync
' projector). Local id is kept equal to syncId.
sub UpsertProfileBySyncId(syncId as string, name as string, color as integer, pin as string, avatar as string)
    if syncId = "" then return
    profiles = LoadProfiles()
    found = false
    for each p in profiles
        if ToStr(p.syncId) = syncId
            p.name = name
            p.color = color
            p.pin = pin
            p.avatar = avatar
            found = true
        end if
    end for
    if not found
        profiles.push({ id: syncId, syncId: syncId, name: name, color: color, pin: pin, avatar: avatar })
    end if
    SaveProfiles(profiles)
end sub

' Guarantees a profile row exists for a syncId (placeholder for feed-ordering
' gaps); never overwrites an existing one.
sub EnsureProfileExists(syncId as string)
    if syncId = "" then return
    for each p in LoadProfiles()
        if ToStr(p.syncId) = syncId then return
    end for
    UpsertProfileBySyncId(syncId, "Profile", 0, "", "")
end sub

sub DeleteProfileBySyncId(syncId as string)
    if syncId = "" or syncId = "default" then return
    DeleteProfile(syncId)   ' local id == syncId
end sub

' Fill in name/logo for the active profile's favorite channels that arrived
' via sync without metadata, matching them against a freshly loaded channel
' list. Returns true if anything was enriched.
function EnrichFavoriteChannels(chans as object) as boolean
    favs = LoadFavoriteChannels()
    if favs.count() = 0 then return false
    ' Merged lists mix sources, so the lookup key carries each channel's own
    ' source — a favorite may only take name/logo from ITS source's channel,
    ' never from a same-numbered channel elsewhere. Channels without a src
    ' field (single-source callers) count as the active source's.
    activeTok = ActiveSrcToken()
    byId = {}
    for each c in chans
        ctok = activeTok
        if type(c) = "roAssociativeArray" and c.doesExist("src") then ctok = ToStr(c.src)
        byId[ctok + "|" + ToStr(c.streamId)] = c
    end for
    changed = false
    for each f in favs
        fkey = ToStr(GetField(f, "src")) + "|" + ToStr(f.streamId)
        if (ToStr(f.name) = "" or ToStr(f.logo) = "") and byId.doesExist(fkey)
            src = byId[fkey]
            if ToStr(f.name) = "" then f.name = ToStr(src.name)
            if ToStr(f.logo) = "" then f.logo = ToStr(src.logo)
            changed = true
        end if
    end for
    if changed then RegWrite(FavChannelsKey(), FormatJson(favs))
    return changed
end function

' The whole local sync mirror, a map of key -> { kind, data, ts, deleted, dirty }.
function LoadSyncMirror() as object
    raw = RegRead("sync_mirror")
    if raw = "" then return {}
    p = ParseJson(raw)
    if p = invalid then return {}
    return p
end function

sub SaveSyncMirror(mirror as object)
    RegWrite("sync_mirror", FormatJson(mirror))
end sub

' ---- Profiles ("Who's watching") --------------------------------------------
' Viewing profiles. Each: { id, syncId, name, color (palette index),
' pin (sha256 hash or ""), avatar (asset path or "") }. The default profile
' uses id/syncId "default" so it merges across devices via KwickSync AND
' keeps the legacy (pre-profile) registry keys — existing favorites, lists,
' resume, and recents carry over to it with no migration.
'
' Per-profile CONTENT (favorites, lists, resume, recents) is namespaced by
' ProfileScopeSuffix(); the default profile's suffix is "" (legacy keys).
' Per-profile SETTINGS land here when KwickSync's pset kind is wired.

function LoadProfiles() as object
    raw = RegRead("profiles")
    if raw = "" then return []
    p = ParseJson(raw)
    if p = invalid then return []
    return ToArray(p)
end function

sub SaveProfiles(profiles as object)
    RegWrite("profiles", FormatJson(profiles))
end sub

' True when the profile list is nothing but the untouched profile
' EnsureDefaultProfile() creates — i.e. this device has never really had
' profiles, whatever the count says.
'
' It matters because the auto-created default is deliberately keyed
' "default" on EVERY platform, so the same person's Default profile merges
' across devices instead of duplicating (Android's app_database.dart
' migration 7). A blank local copy of a shared identity is dangerous: push
' it and newest-wins overwrites the real profile's name, colour, avatar and
' PIN everywhere else.
function HasOnlyPristineDefaultProfile() as boolean
    profs = LoadProfiles()
    if profs.count() <> 1 then return false
    p = profs[0]
    if ToStr(p.syncId) <> "default" then return false
    if ToStr(p.name) <> "Default" then return false
    if ToStr(p.pin) <> "" then return false
    if ToStr(p.avatar) <> "" then return false
    return ToInt(p.color) = 0
end function

' Guarantees the default profile exists; returns the full list.
function EnsureDefaultProfile() as object
    profiles = LoadProfiles()
    if profiles.count() > 0 then return profiles
    profiles = [{ id: "default", syncId: "default", name: "Default", color: 0, pin: "", avatar: "" }]
    SaveProfiles(profiles)
    return profiles
end function

function ActiveProfileId() as string
    id = RegRead("active_profile")
    if id = "" then return "default"
    return id
end function

sub SetActiveProfileId(id as string)
    RegWrite("active_profile", id)
end sub

function ActiveProfile() as object
    id = ActiveProfileId()
    for each p in LoadProfiles()
        if ToStr(p.id) = id then return p
    end for
    profiles = EnsureDefaultProfile()
    return profiles[0]
end function

function ProfileById(id as string) as dynamic
    for each p in LoadProfiles()
        if ToStr(p.id) = id then return p
    end for
    return invalid
end function

' Registry-key suffix isolating this profile's content. Default = "" so the
' pre-profile keys keep working untouched.
function ProfileScopeSuffix() as string
    id = ActiveProfileId()
    if id = "default" then return ""
    return "_" + id
end function

function CreateProfile(name as string, color as integer) as string
    profiles = LoadProfiles()
    id = "pf" + CreateObject("roDateTime").asSeconds().toStr() + profiles.count().toStr()
    profiles.push({ id: id, syncId: id, name: name, color: color, pin: "", avatar: "" })
    SaveProfiles(profiles)
    return id
end function

sub UpdateProfile(id as string, name as string, color as integer)
    profiles = LoadProfiles()
    for each p in profiles
        if ToStr(p.id) = id
            p.name = name
            p.color = color
        end if
    end for
    SaveProfiles(profiles)
end sub

sub SetProfileAvatar(id as string, avatar as string)
    profiles = LoadProfiles()
    for each p in profiles
        if ToStr(p.id) = id then p.avatar = avatar
    end for
    SaveProfiles(profiles)
end sub

sub SetProfilePinHash(id as string, pinHash as string)
    profiles = LoadProfiles()
    for each p in profiles
        if ToStr(p.id) = id then p.pin = pinHash
    end for
    SaveProfiles(profiles)
end sub

' Removes a profile and all its scoped content. Any profile can go —
' including Default (its content lives under the legacy un-suffixed keys) —
' as long as at least one profile remains.
sub DeleteProfile(id as string)
    profiles = LoadProfiles()
    if profiles.count() <= 1 then return   ' always keep one profile
    kept = []
    for each p in profiles
        if ToStr(p.id) <> id then kept.push(p)
    end for
    if kept.count() = profiles.count() then return   ' not found
    SaveProfiles(kept)
    ' Wipe that profile's content namespace (Default owns the legacy keys).
    if id = "default" then suffix = "" else suffix = "_" + id
    RegDelete("fav_channels" + suffix)
    RegDelete("fav_vod" + suffix)
    RegDelete("recent_channels" + suffix)
    RegDelete("recent_vod" + suffix)   ' Kwick Picks seed — was being left behind
    RegDelete("fav_lists_" + ActiveProviderId() + suffix)
    clearProfileSettings(id, kept)
    ClearResumeForProfile(id)
    ' Deliberately NOT folded into ClearResumeForProfile: that call is also
    ' what Settings' "Clear resume points" runs (ClearAllResume), and a
    ' member clearing where they were up to has not asked to be shown every
    ' episode they already finished again. A profile being DELETED is the
    ' one case where the marks really are going too.
    ClearSeenForProfile(id)
    if ActiveProfileId() = id then SetActiveProfileId(ToStr(kept[0].id))
end sub

' Wipe a deleted profile's settings + per-provider keys (parental, prefs,
' category order/hidden/locked, hidden channels, lists on every provider).
' Non-default profiles: sweep every key ending in "_<id>". Default: its keys
' are the bare legacy names, so delete anything matching a settings name that
' does NOT carry a surviving profile's suffix.
sub clearProfileSettings(id as string, kept as object)
    sec = CreateObject("roRegistrySection", "kwickplayer")
    ' "pref_controls_timeout" (JB-10) is per-profile, so a deleted profile's
    ' copy goes with it. The add-on accounts are NOT here on purpose: they are
    ' device-level (see the block above AddOnAccountMaxBytes), so deleting one
    ' profile must not sign the television out of OpenSubtitles. The tracking
    ' switches beside them ("pref_trakt_" / "pref_simkl_") are device-level for
    ' the same reason and are deliberately absent from both lists below —
    ' deleting a profile must not switch somebody's scrobbling off.
    bare = ["parental_pin", "parental_mode", "parental_session", "adult_allowed", "pref_channel_sort", "pref_caption_lang", "pref_start_muted", "pref_captions_auto", "pref_show_recents", "pref_show_favorites", "pref_show_picks", "pref_merge_recently_watched", "pref_merge_favorites", "pref_recent_channels_max_age_days", "pref_recent_vod_max_age_days", "chan_order", "pref_media_bar_enabled", "pref_media_bar_count", "pref_media_bar_seconds", "pref_media_bar_content", "pref_controls_timeout"]
    families = ["cat_order_", "cat_hidden_", "cat_locked_", "chan_hidden_", "fav_lists_"]
    changed = false
    for each k in sec.getKeyList()
        ks = ToStr(k)
        del = false
        if id <> "default" and id <> ""
            tail = "_" + id
            if Len(ks) > Len(tail) and ks.right(Len(tail)) = tail
                for each b in bare
                    if ks = b + tail then del = true
                end for
                if not del
                    for each f in families
                        if Len(ks) > Len(f) and ks.left(Len(f)) = f then del = true
                    end for
                end if
            end if
        else
            ' Default profile: bare names, or family keys with no other
            ' profile's suffix on the end.
            for each b in bare
                if ks = b then del = true
            end for
            if not del
                for each f in families
                    if Len(ks) > Len(f) and ks.left(Len(f)) = f then del = true
                end for
                if del
                    for each p in kept
                        tail = "_" + ToStr(p.id)
                        if ToStr(p.id) <> "default" and Len(ks) > Len(tail) and ks.right(Len(tail)) = tail then del = false
                    end for
                end if
            end if
        end if
        if del
            sec.delete(ks)
            changed = true
        end if
    end for
    if changed then sec.flush()
end sub

' ---- Parental Controls ------------------------------------------------------
' A PIN, a lock mode ("hide" = locked categories vanish; "pin" = they show
' but ask for the PIN), and a locked-category set per scope. One correct PIN
' unlocks everything until the app restarts (session flag cleared at launch).

' Parental controls are PER PROFILE (Phase 1 of pset, T7): each profile has
' its own content-lock PIN, mode, and locked categories — a kid profile can
' be locked down while the adult profile stays open.
'
' TWO separate PINs, matching Android: the profile row's pin hash gates
' profile ENTRY only ("Who's Watching"), while the parental PIN below is
' its own device-local PIN — deliberately never synced (Android keeps its
' parental PIN in secure storage, off the wire; and parents hand kids the
' profile PIN, so it must not unlock locked categories).
function HasParentalPin() as boolean
    return RegRead("parental_pin" + ProfileScopeSuffix()) <> ""
end function

function CheckParentalPin(entered as string) as boolean
    stored = RegRead("parental_pin" + ProfileScopeSuffix())
    return stored <> "" and entered = stored
end function

sub SetParentalPin(pin as string)
    if pin = ""
        RegDelete("parental_pin" + ProfileScopeSuffix())
    else
        RegWrite("parental_pin" + ProfileScopeSuffix(), pin)
    end if
end sub

function ParentalMode() as string
    m = RegRead("parental_mode" + ProfileScopeSuffix())
    if m = "" then return "hide"
    return m
end function

sub SetParentalMode(mode as string)
    RegWrite("parental_mode" + ProfileScopeSuffix(), mode)
end sub

' Category prefs are keyed by category NAME under the "all" (merged)
' namespace since phase 2 of multi-source — the Android model exactly: one
' merged lineup, so hiding "Sports" hides every source's Sports. The old
' per-provider id-keyed keys are read through once and translated to names
' via the cat-name caches, so nobody's saved order/hidden/locks reset.
function LockedCatsKey(scope as string) as string
    return "cat_locked_" + scope + "_all" + ProfileScopeSuffix()
end function

' Read a category-pref list (kind: "order"|"hidden"|"locked"): the new
' name-keyed key, falling back ONCE to the legacy per-provider id-keyed key
' translated through that provider's id->name cache. A successful
' translation is written forward so the legacy key is never consulted again.
function catPrefRead(kind as string, scope as string, suffix as string) as object
    newKey = "cat_" + kind + "_" + scope + "_all" + suffix
    raw = RegRead(newKey)
    if raw <> ""
        p = ParseJson(raw)
        if p <> invalid then return ToArray(p)
        return []
    end if
    prov = ProviderForSrcToken("")
    if prov = invalid then return []
    provId = ToStr(prov.id)
    legacy = RegRead("cat_" + kind + "_" + scope + "_" + provId + suffix)
    if legacy = "" then return []
    ids = ParseJson(legacy)
    if ids = invalid then return []
    cache = loadCatNameCache(scope, provId)
    names = []
    seen = {}
    for each cid in ToArray(ids)
        nm = catIdToName(cache, ToStr(cid))
        if nm <> "" and not seen.doesExist(LCase(nm))
            names.push(nm)
            seen[LCase(nm)] = true
        end if
    end for
    ' Cold cache (never browsed this section on this build) translates to
    ' nothing — leave the legacy key alone and retry once the cache warms.
    if names.count() > 0 then RegWrite(newKey, FormatJson(names))
    return names
end function

function LoadLockedCats(scope as string) as object
    return catPrefRead("locked", scope, ProfileScopeSuffix())
end function

function IsCatLocked(scope as string, id as string) as boolean
    for each l in LoadLockedCats(scope)
        if ToStr(l) = id then return true
    end for
    return false
end function

sub ToggleCatLocked(scope as string, id as string)
    locked = LoadLockedCats(scope)
    kept = []
    found = false
    for each l in locked
        if ToStr(l) = id then found = true else kept.push(l)
    end for
    if not found then kept.push(id)
    RegWrite(LockedCatsKey(scope), FormatJson(kept))
end sub

' Session unlock — set true after a correct PIN, cleared at every launch.
' Per profile, like the PIN itself.
function ParentalUnlocked() as boolean
    return RegRead("parental_session" + ProfileScopeSuffix()) = "1"
end function

sub SetParentalUnlocked(v as boolean)
    key = "parental_session" + ProfileScopeSuffix()
    if v then RegWrite(key, "1") else RegDelete(key)
end sub

' Launch-time clear must cover EVERY profile's session flag, not just the
' active one — a stale flag would silently auto-unlock a profile later.
sub ClearParentalSession()
    RegDelete("parental_session")
    for each p in LoadProfiles()
        if ToStr(p.id) <> "default" then RegDelete("parental_session_" + ToStr(p.id))
    end for
end sub

' Wipe every locked-category set (all scopes, active provider). Called when
' the PIN is removed so nothing stays stranded behind a lock with no PIN.
sub ClearAllLocks()
    RegDelete(LockedCatsKey("live"))
    RegDelete(LockedCatsKey("movies"))
    RegDelete(LockedCatsKey("series"))
end sub

' Adult categories: OFF unless somebody with the PIN turned them on.
'
' Roku certification 6.3 forbids pornographic content, and everything above
' is opt-in — a fresh install pointed at a provider that carries adult
' categories used to show them to whoever switched the box on, reviewer
' included. So an Adult-classified category is now filtered out of every
' list unless BOTH of these are true: a parental PIN exists, and the member
' entered it against "Show adult categories" in Settings. With them on, the
' ordinary hide/lock rules take over and nothing else behaves differently.
'
' Per profile like the PIN, and deliberately NOT synced (the same reasoning
' as the parental PIN itself: it must not ride the wire to another device).
' The classifier that decides what counts as Adult lives in GuideMeta.brs,
' which also lists every screen that has to ask.
function AdultCatsAllowed() as boolean
    if not HasParentalPin() then return false
    return RegRead("adult_allowed" + ProfileScopeSuffix()) = "1"
end function

sub SetAdultCatsAllowed(v as boolean)
    key = "adult_allowed" + ProfileScopeSuffix()
    if v then RegWrite(key, "1") else RegDelete(key)
end sub

' ---- Boolean preferences (app-wide) -----------------------------------------

' PER-PROFILE since Phase 1 of pset (T7): every preference read/written
' through these belongs to the ACTIVE profile. The default profile keeps
' the legacy un-suffixed keys, so existing settings carry over untouched.
function GetPrefBool(key as string, dflt as boolean) as boolean
    raw = RegRead(key + ProfileScopeSuffix())
    if raw = "" then return dflt
    return (raw = "1")
end function

sub SetPrefBool(key as string, value as boolean)
    if value then RegWrite(key + ProfileScopeSuffix(), "1") else RegWrite(key + ProfileScopeSuffix(), "0")
end sub

' Wipe the active profile's saved VOD resume points.
sub ClearAllResume()
    ClearResumeForProfile(ActiveProfileId())
end sub

' Delete every resume key belonging to one profile. The default profile owns
' the un-prefixed keys ("movie:..."/"ep:..."); others own "<id>|...".
sub ClearResumeForProfile(profileId as string)
    clearProfileKeysIn("kwick_resume", profileId)
    clearProfileKeysIn("kwick_hist", profileId)
end sub

sub clearProfileKeysIn(section as string, profileId as string)
    sec = CreateObject("roRegistrySection", section)
    prefix = ""
    if profileId <> "default" and profileId <> "" then prefix = profileId + "|"
    keys = sec.getKeyList()
    changed = false
    for each k in keys
        ks = ToStr(k)
        del = false
        if prefix = ""
            del = (Instr(1, ks, "|") = 0)   ' default: keys with no profile prefix
        else
            del = (Len(ks) >= Len(prefix) and ks.left(Len(prefix)) = prefix)
        end if
        if del
            sec.delete(ks)
            changed = true
        end if
    end for
    if changed then sec.flush()
end sub

' Wipe recently-watched channels (active profile).
sub ClearRecentChannels()
    RegDelete(RecentChannelsKey())
end sub

function RecentChannelsKey() as string
    return "recent_channels" + ProfileScopeSuffix()
end function

' ---- "Update available" nudge -----------------------------------------------
' The newest published build this device has already been told about, so the
' same one is never mentioned twice. DEVICE level, not per profile — which
' build is installed belongs to the box, not to whoever is watching.
'
' 0 means "never told about anything", which is every existing install. The
' key deliberately does NOT match any prefix in ClearAccountDataOnSignOut —
' it survives a sign-out, because it is not part of anyone's account and
' signing out doesn't make an old build new again.

function UpdatePromptedBuild() as integer
    raw = RegRead("update_prompted_build")
    if raw = "" then return 0
    return raw.toInt()
end function

sub SetUpdatePromptedBuild(n as integer)
    RegWrite("update_prompted_build", n.toStr())
end sub

' ---- Add-on accounts --------------------------------------------------------
' The member's OWN sign-in on OpenSubtitles, Trakt and Simkl (JB-7, JB-9). One
' registry key per add-on, holding the token the relay handed back and the name
' to print on the Settings row. AddOns.brs is the contract for the relays and
' for what each service allows; this is the only place any of it is stored.
'
' MASON'S RULE is why there is a token here at all: members use THEIR OWN
' logins on every add-on, no shared Kwick account behind any of them. So what
' is in these keys is a credential belonging to the member, on somebody else's
' service.
'
' REGISTRY ONLY — NEVER LOGGED, NEVER ON THE KWICKSYNC WIRE. That is not a
' promise, it is a property of how this file reaches the wire: BuildPsetMap
' emits the rows of psetScalarMap and psetListMap and nothing else, these keys
' are in neither list, and nothing in SyncTask sweeps this registry section
' (its two getKeyList calls are on "kwick_hist" and "kwick_seen"). ApplyPsetMap
' can only write keys that are in those same two lists, so an incoming blob
' cannot reach them either. Anyone adding a key here must keep it that way.
'
' NOT PER PROFILE, which is the opposite of nearly everything else in this
' file, so here is the reason written down. An add-on account is the box
' owner's account on another service, not a taste like a theme or a sort order:
' a household's child profile does not have its own OpenSubtitles login, and
' Trakt has no notion of our profiles at all, so a per-profile copy would be
' the SAME credential written three or four times over. It would also multiply
' the registry cost by the number of profiles, in a registry of 16-32 KB for
' the whole app. The honest cost of this decision, so nobody is surprised by
' it: two people who share a television and each have their own Trakt cannot
' both be signed in — the second sign-in replaces the first. Nobody has asked
' for that yet; if Mason ever does, the answer is a profile suffix here and in
' the four calls below, not a second key.
'
' WHAT IT COSTS. Each account is one JSON object with five short fields —
' about 36 bytes of scaffolding, plus the token, plus the page's `extra` map
' (a VIP flag, an account type, a quota line: 40 to 90 bytes in practice). A
' Trakt access and refresh pair is 64 hex characters each, so 128 bytes before
' anything else and about 240 for the whole row; Simkl has no refresh token
' and comes to about 150; OpenSubtitles' token is the long one and is not a
' fixed length.
'
' SO IT CAPS ITSELF, because "about 240 bytes" is not a guarantee. One account
' may not exceed AddOnAccountMaxBytes(). Over it, `extra` is dropped first —
' it is decoration the page fetches again on every visit, and losing a
' member's sign-in to save a badge would be the wrong way round — and only if
' the token ALONE is still over is the write REFUSED and said out loud. Never
' truncated: a cut-off token saves, looks signed in, and fails every call
' after. So the whole feature cannot cost more than 512 B x 3 add-ons plus 41
' bytes of key names = 1.6 KB worst case on this build (2.1 KB if TMDB is
' added later), against a registry the whole app shares. Typical, with real
' tokens and all three signed in: ~700 B. AddOnAccountsBytes() answers what it
' is actually costing on a given box.

' One account may not take more than this much of the registry. 512 rather
' than something tighter because an OpenSubtitles token is not a fixed length
' and a cap that refuses a real sign-in is worse than the bytes it saves.
function AddOnAccountMaxBytes() as integer
    return 512
end function

' The registry key for one add-on id. Sanitised rather than trusted: this file
' cannot ask AddOns.brs whether an id is real (a component gets only the
' scripts its own XML names, and plenty of screens load Store.brs without
' AddOns.brs), so anything that is not a plain lowercase id gets no key at all
' instead of writing junk into a registry this small.
function addOnAccountKey(id as string) as string
    s = LCase(ToStr(id))
    if s = "" or Len(s) > 20 then return ""
    for i = 1 to Len(s)
        ch = Mid(s, i, 1)
        ok = (ch >= "a" and ch <= "z") or (ch >= "0" and ch <= "9")
        if not ok then return ""
    end for
    return "addon_" + s
end function

' What is stored for one add-on, as
'   { signedIn, token, refresh, name, extra, since }
' `since` is the moment they signed in, in seconds, 0 when they are not, and
' `extra` is the small map of service-specific decoration the add-on page puts
' on the screen — VIP, account type, what is left of today's allowance. It is
' always a map, never invalid, so a page can ask it doesNotExist questions
' without guarding first.
'
' EVERY FIELD IS SET ON BOTH BRANCHES. A Settings row or an add-on page reads
' `.name` whether or not anybody is signed in, and a shape that only grew its
' fields on the signed-in branch would leave the previous add-on's name on the
' next add-on's row.
function AddOnAccount(id as string) as object
    out = { signedIn: false, token: "", refresh: "", name: "", extra: {}, since: 0 }
    k = addOnAccountKey(id)
    if k = "" then return out
    raw = RegRead(k)
    if raw = "" then return out
    p = ParseJson(raw)
    if p = invalid then return out
    ' ParseJson hands back a CASE-SENSITIVE map, so these are read by exactly
    ' the names they were written with. They are one lowercase letter each,
    ' which is also the only spelling BrightScript cannot fold to something
    ' else when a field name is written as code.
    out.token = ToStr(GetField(p, "t"))
    out.refresh = ToStr(GetField(p, "r"))
    out.name = ToStr(GetField(p, "n"))
    ' A nested object, handed back as the map it was stored as. Anything else
    ' in that slot (an older row, a hand-edited registry) becomes an empty map
    ' rather than being passed on as a type the page cannot read.
    x = GetField(p, "x")
    if type(x) = "roAssociativeArray" then out.extra = x
    out.since = ToInt(GetField(p, "s"))
    out.signedIn = (out.token <> "")
    return out
end function

' Store one add-on account. `acct` takes the same field names AddOnAccount
' hands back; only token, refresh, name and extra are read from it.
'
' HOW A CALLER KNOWS IT WORKED: call AddOnSignedIn(id) afterwards. It answers
' false both when the account was over the cap below and when the registry is
' full, which are the two ways a save can fail on this box, and a page that
' says "Signed in" without checking will be lying on the next visit.
sub SaveAddOnAccount(id as string, acct as object)
    k = addOnAccountKey(id)
    if k = "" or acct = invalid then return
    token = ToStr(GetField(acct, "token"))
    if token = ""
        ' No token is not an account. Saving one would leave a row reading
        ' "Signed in as" with nobody's name after it and every call failing.
        ClearAddOnAccount(id)
        return
    end if
    since = ToInt(GetField(acct, "since"))
    if since <= 0 then since = CreateObject("roDateTime").asSeconds()
    rec = {}
    rec["t"] = token
    rec["r"] = ToStr(GetField(acct, "refresh"))
    rec["n"] = ToStr(GetField(acct, "name"))
    ' The service's own decoration, stored as the nested object it is. Only a
    ' real map goes in: FormatJson would refuse to serialise anything odd here
    ' and take the whole account down with it.
    rec["x"] = {}
    x = GetField(acct, "extra")
    if type(x) = "roAssociativeArray" then rec["x"] = x
    rec["s"] = since
    raw = FormatJson(rec)
    if Len(raw) > AddOnAccountMaxBytes()
        ' Over the cap with the decoration on. THE DECORATION IS WHAT GOES,
        ' not the sign-in: `extra` is a VIP badge and a quota line, the page
        ' asks the service for it again on every visit, and losing a member's
        ' sign-in to save a badge would be the wrong way round.
        rec["x"] = {}
        raw = FormatJson(rec)
    end if
    nBytes = Len(raw)
    if nBytes > AddOnAccountMaxBytes()
        ' REFUSED, NOT TRUNCATED, and said out loud. A cut-off token would
        ' save, look signed in, and fail on every call afterwards. The size is
        ' named because that is what identifies the offender; the value never
        ' is, because the value is the member's credential.
        capBytes = AddOnAccountMaxBytes()
        KLog("store", "add-on account '" + k + "' NOT saved - " + nBytes.toStr() + "B is over the " + capBytes.toStr() + "B one account is allowed")
        return
    end if
    RegWrite(k, raw)
end sub

sub ClearAddOnAccount(id as string)
    k = addOnAccountKey(id)
    if k = "" then return
    RegDelete(k)
end sub

function AddOnSignedIn(id as string) as boolean
    acct = AddOnAccount(id)
    return acct.signedIn = true
end function

' Swap a sign-in's stored pair for the fresh one the relay just handed back,
' keeping the name and the decoration that were already on the row. Trakt is
' the only service that has a refresh to swap; AddOnAuth.brs is the only
' caller, and it runs on a Task thread.
'
' COSTS NOTHING NEW. Same key, same fields, same 512-byte cap — a Trakt access
' and refresh token are 64 hex characters each whether they are the first pair
' or the fifth, so the row does not grow. Nothing is added to the registry by
' renewing; the only way this changes the total is downwards, when it fails
' and the account is signed out instead.
'
' THE SIGN-IN MOMENT DOES NOT MOVE. `since` is when the member linked the
' service, which is what the page shows them; renewing a token is not signing
' in again and must not read as it.
'
' ANSWERS WHETHER IT ACTUALLY STUCK, by reading the row back rather than
' assuming. SaveAddOnAccount refuses an over-cap account and RegWrite cannot
' save anything at all into a full registry — and a caller that carried on
' using a token this box did not keep would work until the next launch and
' then look like the very bug it was fixing.
function RenewAddOnToken(id as string, token as string, refreshToken as string) as boolean
    tok = ToStr(token)
    if tok = "" then return false
    was = AddOnAccount(id)
    if was.signedIn <> true then return false
    ' An answer with no new refresh token in it keeps the one already stored,
    ' rather than dropping the only thing that can ever renew this sign-in
    ' again. (The contract always sends one; this is the belt.)
    rt = ToStr(refreshToken)
    if rt = "" then rt = was.refresh
    acct = {
        "token": tok,
        "refresh": rt,
        "name": was.name,
        "extra": was.extra,
        "since": was.since
    }
    SaveAddOnAccount(id, acct)
    saved = AddOnAccount(id)
    return saved.token = tok
end function

' What is LEFT of the member's daily downloads, written back after the
' service has actually said. It is the only place that number can come from:
' OpenSubtitles does not report it at sign-in, only on a download, so an
' account page that never heard about a download either says the allowance or
' says nothing (see quotaLine in AddOnDetailScreen).
'
' Signed-out or unknown service: does nothing at all. A quota with no account
' under it is not worth a registry write, and the registry is 16-32 KB for
' the whole app.
sub UpdateAddOnQuota(id as string, remaining as string, resetUtc as string)
    if remaining.trim() = "" then return
    was = AddOnAccount(id)
    if was.signedIn <> true then return
    extra = was.extra
    if type(extra) <> "roAssociativeArray" then extra = {}
    extra["remaining"] = ToInt(remaining)
    ' THE MARK THAT SAYS THIS NUMBER WAS EARNED. A build before 2026-09-19
    ' wrote remaining = 0 at sign-in, because the relay sends null there and
    ' ToInt(invalid) is 0 — so every member who signed in on one of those
    ' builds has a stored zero that means nothing, and would go on being told
    ' "0 of 1000 downloads left today" in red until they signed out and in
    ' again. quotaLine trusts the count only with this mark on it, so those
    ' accounts quietly fall back to the allowance and heal on their first
    ' download. One short key, and the registry is 16-32 KB for the whole app.
    extra["rem_src"] = "dl"
    ' Kept when the answer did not carry one — a reset time already stored is
    ' better than none, and it is the same day's.
    if resetUtc.trim() <> "" then extra["reset_utc"] = resetUtc
    acct = {
        "token": was.token,
        "refresh": was.refresh,
        "name": was.name,
        "extra": extra,
        "since": was.since
    }
    SaveAddOnAccount(id, acct)
end sub

' Sign one add-on out on this box — THE one way it happens, so that the Sign
' out button and a sign-in that could not be renewed leave the television in
' exactly the same state. The account row and that service's seven switches,
' and never the other add-on's.
'
' `why` is one plain sentence for the member's log: what happened and what to
' do about it. It never carries a token, a name or a title. A blank one falls
' back to the words the Sign out button has always used.
sub SignOutAddOnAccount(id as string, why as string)
    ClearAddOnAccount(id)
    ' ClearTrackerSettings ignores an id that is not a tracker, so signing out
    ' of OpenSubtitles through here clears the account and nothing else.
    ClearTrackerSettings(id)
    reason = ToStr(why).trim()
    if reason = "" then reason = "signed out on this TV"
    KLog("addon", ToStr(id) + ": " + reason)
end sub

' What every add-on account on this box is costing right now, key names
' included. Nothing member-facing reads it — it is here so the question "is
' this feature the thing filling the registry up?" has an answer on a real
' television instead of an estimate.
function AddOnAccountsBytes() as integer
    sec = CreateObject("roRegistrySection", "kwickplayer")
    total = 0
    for each k in sec.getKeyList()
        ks = ToStr(k)
        if Len(ks) > 6 and ks.left(6) = "addon_"
            total = total + Len(ks) + Len(ToStr(sec.read(ks)))
        end if
    end for
    return total
end function

' ---- Tracking add-ons: what they do, and how often --------------------------
' The seven switches behind Trakt and Simkl — what gets sent, what appears on
' Home, and how often the list is pulled. Read by the player (scrobbling), by
' the detail screens (checkmarks), by Home (the watchlist row) and by whatever
' ends up scheduling the pull; written only by the add-on's own page and by the
' one Settings row that shares the watchlist switch.
'
' OPENSUBTITLES IS NOT ONE OF THESE. It finds subtitles; it tracks nothing, so
' none of these keys exist for it and TrackerIds() below is what says so. Every
' function here answers the safe thing ("no") for any id that is not one of the
' two, rather than inventing a key for it.
'
' DEVICE LEVEL — NO PROFILE SUFFIX. The reasoning is already written out above
' AddOnAccountMaxBytes() and is not repeated here: this is the box owner's
' account on somebody else's service, Trakt has no notion of our profiles, and
' a per-profile copy would be the same setting written three or four times over
' in a registry of 16-32 KB. These switches govern that one sign-in, so they
' are scoped exactly as it is. Android reached the same conclusion and wrote it
' down in the same words (preference_constants.dart, the Trakt block:
' "DEVICE-level, every one of them"). None of them therefore goes anywhere near
' ProfileScopeSuffix() or clearProfileSettings().
'
' NOT ON THE WIRE, and that is a property rather than a promise, the same one
' the add-on accounts have: BuildPsetMap emits the rows of psetScalarMap and
' psetListMap and nothing else, none of these keys is in either list, and
' ApplyPsetMap can only write keys that are in those same two lists. So a phone
' can neither read these nor overwrite them. That is also why the SECONDS note
' below is safe.
'
' THE KEY NAMES ARE ANDROID'S, name for name (preference_constants.dart:338-368
' for Trakt, 383-422 for Simkl), so the two lanes read side by side. THE UNIT
' OF pref_<svc>_last_sync_at IS NOT: Android stores epoch MILLISECONDS and this
' box stores epoch SECONDS, because a 13-digit millisecond stamp does not fit
' in the 32-bit integer BrightScript hands back and this app has already been
' bitten by that once (see mediaBarIdxPut). The two values never meet — the key
' is device-level on both platforms and on neither wire — but LastSyncAt()
' below still refuses a value that is too long to be seconds rather than
' reading a member's stamp as a date in the year 56000.
'
' WHAT IT COSTS. The seven key names come to 163 bytes per service. The values:
' four booleans at one byte, the hours at two, the stamp at ten, and the
' summary capped at TrackerSummaryMaxBytes() — 56 bytes per service at the
' absolute worst. So the whole feature's CEILING is 438 bytes for both services
' with every switch moved off its default, against a registry of 16-32 KB that
' the whole app shares.
'
' A MEMBER WHO NEVER SIGNS IN PAYS NOTHING AT ALL, because every default costs
' zero: turning a switch back ON deletes its key rather than writing "1", and
' an absent key already reads back as ON — the same trick the background effect
' uses. Typical is one service signed in, the switches left alone and one sync
' done: the stamp and the summary only, about 73 bytes.
'
' AND IT CAPS ITSELF. The hours setter refuses anything that is not one of the
' six choices, and SetLastSync truncates the summary at 40 bytes, so no caller
' now or later can put a longer value in any of these keys. The summary is a
' line of text on a screen, so cutting it short is safe — unlike a token, which
' is why SaveAddOnAccount refuses instead of truncating.

' The add-ons that track what you watch. OpenSubtitles is deliberately not one.
function TrackerIds() as object
    return ["trakt", "simkl"]
end function

' The registry key for one tracker setting, or "" when the id is not one of the
' two. Sanitised rather than trusted, for the same reason addOnAccountKey() is:
' this file cannot ask AddOns.brs anything (a component gets only the scripts
' its own XML names), so an id it does not recognise gets no key at all instead
' of writing junk into a registry this small.
function trackerKey(service as string, leaf as string) as string
    s = LCase(ToStr(service))
    for each id in TrackerIds()
        if s = id then return "pref_" + s + "_" + leaf
    end for
    return ""
end function

function IsTrackerId(service as string) as boolean
    return trackerKey(service, "x") <> ""
end function

' Every one of the four switches is ON unless the member turned it off, and ON
' writes nothing. Not signed in answers false — see the note on ScrobbleOn.
function trackerBool(service as string, leaf as string) as boolean
    k = trackerKey(service, leaf)
    if k = "" then return false
    if not AddOnSignedIn(service) then return false
    raw = RegRead(k)
    if raw = "" then return true
    return (raw = "1")
end function

sub setTrackerBool(service as string, leaf as string, v as boolean)
    k = trackerKey(service, leaf)
    if k = "" then return
    ' THE DEFAULT COSTS NOTHING: back ON deletes the key rather than writing
    ' "1", and an absent key already reads back as ON.
    if v then RegDelete(k) else RegWrite(k, "0")
end sub

' Send what is being watched to this service while it plays. Default ON: a
' member who signed in to Trakt signed in so that this would happen.
'
' IT ANSWERS FALSE FOR A SERVICE THAT IS NOT SIGNED IN, and every switch here
' does. That is deliberate and it is the difference between this and a plain
' preference read: the switch defaults to ON, so a bare registry read would say
' "yes, scrobble" about a Simkl the member has never signed in to or has just
' signed out of, and the caller would go and try. Callers may still check
' AddOnSignedIn themselves — PlayerScreen.scrobbleEnabled does, and belt and
' braces is fine.
function ScrobbleOn(service as string) as boolean
    return trackerBool(service, "scrobble")
end function

sub SetScrobbleOn(service as string, v as boolean)
    setTrackerBool(service, "scrobble", v)
end sub

' Pass a checkmark ticked by hand through to the service's watched history, and
' take it off again when the member unticks it. Default ON.
'
' A DIFFERENT SWITCH FROM ScrobbleOn AND NOT IMPLIED BY IT. A member is allowed
' to have scrobbling on and checkmark filing off; do not collapse the two.
function HistoryOn(service as string) as boolean
    return trackerBool(service, "history")
end function

sub SetHistoryOn(service as string, v as boolean)
    setTrackerBool(service, "history", v)
end sub

' Show this service's watchlist as a row on Home. Default ON.
'
' ONE PREFERENCE, TWO DOORS. The add-on's own page and Settings -> Home screen
' both show this switch and both write this key, exactly as Android does. There
' is no second key and there must never be one.
function WatchlistRowOn(service as string) as boolean
    return trackerBool(service, "watchlist_row")
end function

sub SetWatchlistRowOn(service as string, v as boolean)
    setTrackerBool(service, "watchlist_row", v)
end sub

' Pull the list when the app opens. Default ON.
function SyncOnStart(service as string) as boolean
    return trackerBool(service, "sync_on_start")
end function

sub SetSyncOnStart(service as string, v as boolean)
    setTrackerBool(service, "sync_on_start", v)
end sub

' What "Sync every..." offers, in hours. Zero is off. Android's own list and
' order (TrackerSyncSettings.hourChoices) — THERE IS NO THIRTY MINUTES, and the
' floor below is why.
function TrackerHourChoices() as object
    return [0, 1, 2, 3, 6, 12]
end function

' The shortest gap this app will ever pull at, whatever is stored: ONE HOUR.
' Android's minimumInterval, and the reason is Simkl's — the whole app gets
' 1,000 requests a day until they approve it, and this house has already had a
' provider's access banned once for asking too often. A watchlist a member
' edits a few times a week is not a live feed.
function TrackerMinHours() as integer
    return 1
end function

' "Off", "Every hour", "Every 3 hours" — Android's wording, used by the picker
' and by the row's own line.
function TrackerHoursLabel(hours as integer) as string
    if hours <= 0 then return "Off"
    if hours = 1 then return "Every hour"
    return "Every " + hours.toStr() + " hours"
end function

' The same gap in the two or three characters the row's value column can
' actually hold. The column is 276px at 23 mono (SettingRow.brs:23-26) and
' "Every 12 hours" does not fit it; a value that truncates on a television is
' worse than a shorter word that does not.
function TrackerHoursShortLabel(hours as integer) as string
    if hours <= 0 then return "Off"
    if hours = 1 then return "1 hour"
    return hours.toStr() + " hours"
end function

' How often the list is pulled, in hours. 0 is off. Default 3.
'
' THE ONE-HOUR FLOOR IS IN HERE, NOT AT THE CALL SITES, so nobody can schedule
' a pull every few minutes by reading the number and forgetting to clamp it.
' Anything stored that is not one of the six choices reads back as the default
' rather than as a gap no picker in this app can produce — an older build, a
' hand-edited registry, a future build offering a seventh. Exactly what
' Android's TrackerSyncSettings.syncEveryHours does with the same value.
function SyncEveryHours(service as string) as integer
    k = trackerKey(service, "sync_every_hours")
    if k = "" then return 0
    raw = RegRead(k)
    if raw = "" then return 3
    n = raw.toInt()
    ok = false
    for each c in TrackerHourChoices()
        if n = c then ok = true
    end for
    if not ok then return 3
    if n <= 0 then return 0
    if n < TrackerMinHours() then return TrackerMinHours()
    return n
end function

' Ignores anything that is not one of the six: the picker is the only thing
' that writes this, and a stray value would be a gap the member never chose.
' Writing the default DELETES the key, so the common case costs nothing.
sub SetSyncEveryHours(service as string, hours as integer)
    k = trackerKey(service, "sync_every_hours")
    if k = "" then return
    for each c in TrackerHourChoices()
        if hours = c
            if hours = 3 then RegDelete(k) else RegWrite(k, hours.toStr())
            return
        end if
    end for
end sub

' The longest a last-sync summary may be. It is one line under a row, so it is
' TRUNCATED rather than refused — the opposite of a token, which is refused
' because half a token looks signed in and fails every call after it.
'
' RAISED FROM 40 TO 80 ON 2026-09-18, because 40 cut the sentences that matter
' most in half. The successes all fit inside 32 ("14 titles · 9 in your
' playlists" is the longest), so 40 only ever bit the FAILURES — the lines a
' member actually needs to read. "Could not reach Trakt. Check the connection
' and try again." is 58 characters and came out as "Could not reach Trakt.
' Check the connecti"; "Nothing to sync while the Home row is off" is 41 and
' lost its last letter. A relay's own message can run to about 70. 80 covers
' every string either lane writes today with room to spare, and the cost is
' forty more bytes in a registry where this whole feature's ceiling is under
' half a kilobyte.
function TrackerSummaryMaxBytes() as integer
    return 80
end function

' A second press of "Sync now" inside this many seconds gives back the last
' summary and makes no call. A held OK on a Roku remote repeats about every
' 400 ms, so without this one lean on the button is a burst of requests.
' Android's syncNowCooldown, same 30 seconds.
function TrackerSyncNowCooldownSecs() as integer
    return 30
end function

' When this service last synced, in SECONDS since 1970, 0 when it never has.
'
' SECONDS, not Android's milliseconds — see the unit note at the top of this
' block. A stored value too long to be seconds is read as "never" rather than
' trusted: 11 digits is seconds until the year 5138, so anything longer is
' either a millisecond stamp that should not be here or a hand-edited registry,
' and toInt() would hand back a wrapped negative for it.
function LastSyncAt(service as string) as integer
    k = trackerKey(service, "last_sync_at")
    if k = "" then return 0
    raw = RegRead(k)
    if raw = "" or Len(raw) > 11 then return 0
    n = raw.toInt()
    if n < 0 then return 0
    return n
end function

' The one line the last run left behind — "14 titles", "Nothing changed", or
' what went wrong. "" until it has run.
function LastSyncSummary(service as string) as string
    k = trackerKey(service, "last_sync_summary")
    if k = "" then return ""
    return RegRead(k)
end function

' ONE setter for both keys, so a half-written pair cannot happen: a stamp with
' last run's summary beside it would put a sentence on the member's screen that
' was true an hour ago.
sub SetLastSync(service as string, atSecs as integer, summary as string)
    kAt = trackerKey(service, "last_sync_at")
    if kAt = "" then return
    if atSecs <= 0
        ' "It has never synced" is said by deleting the pair, not by writing a
        ' zero into a registry this small.
        RegDelete(kAt)
        RegDelete(trackerKey(service, "last_sync_summary"))
        return
    end if
    RegWrite(kAt, atSecs.toStr())
    s = ToStr(summary).trim()
    kSum = trackerKey(service, "last_sync_summary")
    if s = ""
        RegDelete(kSum)
        return
    end if
    if Len(s) > TrackerSummaryMaxBytes() then s = Left(s, TrackerSummaryMaxBytes())
    RegWrite(kSum, s)
end sub

' Drop all seven of one service's keys. Signing out of Trakt must not touch
' Simkl's, which is why this takes a service and never sweeps by prefix.
'
' The SIGN-IN itself is not cleared here — the caller does that with
' ClearAddOnAccount, because the two are separate stores and a page may want to
' keep one without the other during a re-sign-in.
sub ClearTrackerSettings(service as string)
    if not IsTrackerId(service) then return
    for each leaf in ["scrobble", "history", "watchlist_row", "sync_on_start", "sync_every_hours", "last_sync_at", "last_sync_summary"]
        RegDelete(trackerKey(service, leaf))
    end for
end sub

' What these switches are costing on this box right now, key names included.
' Nothing member-facing reads it — it is here so "is this feature the thing
' filling the registry up?" has an answer on a real television, the same way
' AddOnAccountsBytes() does for the sign-ins themselves.
function TrackerSettingsBytes() as integer
    sec = CreateObject("roRegistrySection", "kwickplayer")
    total = 0
    for each service in TrackerIds()
        for each leaf in ["scrobble", "history", "watchlist_row", "sync_on_start", "sync_every_hours", "last_sync_at", "last_sync_summary"]
            k = trackerKey(service, leaf)
            raw = ToStr(sec.read(k))
            if raw <> "" then total = total + Len(k) + Len(raw)
        end for
    end for
    return total
end function

' ---- Background effect ------------------------------------------------------
' The decorative wash drawn behind every screen — grid paper, CRT scanlines,
' both, or neither. The Roku half of Android's BackgroundEffect
' (packages/kwicktv_design/lib/src/theme/background_effect.dart:31-45). The
' four stored strings below are ANDROID'S OWN and are STABLE: members are
' running installed copies, so these are added to, never renamed.
'
' FOUR CHOICES HERE, FIVE ON THE PHONE. Android's fifth is "theme", meaning
' "whatever the chosen theme brings" — it exists because the phone has 24
' themes that differ on this. This app has exactly ONE theme (Nord Shell, see
' the top of Theme.brs), so "whatever the theme brings" would always mean the
' same one thing and the row would carry a choice that does nothing. It is
' left off the picker, and a stored "theme" is read as "grid" below.
'
' THE DEFAULT IS "grid", NOT "none". Nord Shell draws grid paper and always
' has (AppScene's bgFxHost, BuildGridOverlay in Theme.brs). A member who never
' opens this row must see exactly what they see today; a default of "none"
' would strip the grid off every television on the next update, which reads as
' a fault rather than a feature.
'
' DEVICE LEVEL, and deliberately so — no ProfileScopeSuffix, and not in
' psetScalarMap. Android's own comment calls it device-level: it describes
' the television it is drawn on, not the member watching, so it neither
' carries a profile suffix nor goes near the sync wire. It is therefore not
' a wire change and needs nobody's agreement at the far end. It is also not
' account data: like update_prompted_build it is left alone by
' ClearAccountDataOnSignOut and by clearProfileSettings, because signing out
' does not change what the television should look like.
'
' WHAT IT COSTS. Key "bgfx" is 4 bytes and the longest value it can ever
' hold is "grid_crt", 8 bytes — 12 bytes, once, for the whole app, and it
' caps itself: SetBgEffect refuses anything that is not one of the four, so
' nothing longer can reach the registry from any caller, now or later. The
' default costs NOTHING at all — choosing "grid" DELETES the key rather than
' writing it, and an absent key already reads back as "grid". Only a member
' who has actively chosen one of the other three spends the 12 bytes.

function BgEffectChoices() as object
    return ["none", "grid", "crt", "grid_crt"]
end function

' How the choice reads on screen. Android's labels for the first three; the
' fourth is "Both" rather than the phone's "Grid + CRT", which is the owner's
' own word for it and the one this app's row uses.
function BgEffectLabel(v as string) as string
    if v = "none" then return "None"
    if v = "crt" then return "CRT Lines"
    if v = "grid_crt" then return "Both"
    return "Grid Lines"
end function

' What the Settings row shows, and what its picker opens on.
'
' READ OFF m.global, NOT OUT OF THE REGISTRY. `bgfx` is read from the
' registry exactly once in the whole app — AppScene.brs:65, which seeds
' m.global.bgfxKey at launch — and SetBgEffect below writes both halves on
' every change, so the global is never behind. A second RegRead here would
' be a second answer that can disagree with the one every painter is using.
'
' Anything unrecognised is "grid": an empty registry, a half-written value,
' a stray one off a copied registry or a test box, and Android's own "theme",
' which should never reach a Roku but is a real string the phone writes. With
' one theme on this platform "theme" and "grid" mean the same thing anyway.
' Same rule, same default, as BgFxResolve() in Theme.brs.
function BgEffect() as string
    raw = ""
    if m <> invalid and m.global <> invalid and m.global.hasField("bgfxKey")
        ' .Trim() is a METHOD on the string, not a global Trim(). There is no
        ' global Trim() in BrightScript — writing it that way resolves to
        ' nothing and faults with "Function Call Operator ( ) attempted on
        ' non-function" the moment this line runs. It reads as plausible and
        ' package.py cannot catch it: the gate checks reserved identifiers and
        ' packaging, not whether a called name resolves. It cost a launch on
        ' 2026-08-27. LCase() and ToStr() ARE real and are fine as they are.
        raw = LCase(ToStr(m.global.bgfxKey).Trim())
    end if
    for each c in BgEffectChoices()
        if raw = c then return raw
    end for
    return "grid"
end function

sub SetBgEffect(v as string)
    ok = false
    for each c in BgEffectChoices()
        if v = c then ok = true
    end for
    if not ok then return
    if v = "grid"
        RegDelete("bgfx")
    else
        RegWrite("bgfx", v)
    end if
    ' Tell the app that is already running, so the wash changes while the
    ' member is looking at it rather than on the next launch. Writing the
    ' registry alone changes nothing until relaunch — AppScene seeds
    ' m.global.bgfxKey from this key ONCE, at launch, and repaints from the
    ' global (AppScene.brs onBgFxChanged / BgFxResolve in Theme.brs). This
    ' write is the only thing that closes that gap, and it is guarded so a
    ' build whose scene has not declared the field simply falls back to
    ' next-launch instead of faulting a render thread.
    if m <> invalid and m.global <> invalid and m.global.hasField("bgfxKey")
        m.global.bgfxKey = v
    end if
end sub

' NO READER FOR THE PAINTERS LIVES HERE. Anything DRAWING the effect asks
' BgFxGridOn() / BgFxCrtOn() in Theme.brs, which read the resolved answer off
' m.global. A painter must not call BgEffect() above, or any other RegRead:
' several components that draw the wash (AvatarPickerScreen among them) do not
' name Store.brs in their XML, and a component gets only the scripts its own
' XML names — the call would come back "Function is not defined in component's
' namespace" and take that screen's render thread down. The four functions
' above are for the SETTINGS ROW, which does include Store.brs, and nothing
' else.

' ---- Category prefs (hide + reorder), scoped per section + provider --------
' scope is "live" | "movies" | "series". Mirrors the Android Hide/Reorder
' Categories screens: a custom order (ids first) plus a hidden set.

' Name-keyed under "all" — see the note on LockedCatsKey.
function CatOrderKey(scope as string) as string
    return "cat_order_" + scope + "_all" + ProfileScopeSuffix()
end function

function CatHiddenKey(scope as string) as string
    return "cat_hidden_" + scope + "_all" + ProfileScopeSuffix()
end function

function LoadCatOrder(scope as string) as object
    return catPrefRead("order", scope, ProfileScopeSuffix())
end function

sub SaveCatOrder(scope as string, ids as object)
    RegWrite(CatOrderKey(scope), FormatJson(ids))
end sub

function LoadHiddenCats(scope as string) as object
    return catPrefRead("hidden", scope, ProfileScopeSuffix())
end function

function IsCatHidden(scope as string, id as string) as boolean
    for each h in LoadHiddenCats(scope)
        if ToStr(h) = id then return true
    end for
    return false
end function

sub ToggleCatHidden(scope as string, id as string)
    hidden = LoadHiddenCats(scope)
    kept = []
    found = false
    for each h in hidden
        if ToStr(h) = id then found = true else kept.push(h)
    end for
    if not found then kept.push(id)
    RegWrite(CatHiddenKey(scope), FormatJson(kept))
end sub

sub MoveCatToTop(scope as string, id as string, allIds as object)
    order = LoadCatOrder(scope)
    if order.count() = 0 then order = allIds
    newOrder = [id]
    for each o in order
        if ToStr(o) <> id then newOrder.push(o)
    end for
    SaveCatOrder(scope, newOrder)
end sub

' Nudge one category up or down by one place. Move to Top was the only move
' this app had, and it makes the fifteenth category the first — the Android
' screen (hidden_categories_screen.dart) has always had a pair of arrows for
' putting one category just above another, which is what somebody tidying a
' list actually wants.
'
' `allIds` is the list as the member is looking at it. The saved order can be
' shorter than the real one (a category the panel has added since, a member
' who has only ever pressed Move to Top), so the drawn order is what the move
' is measured against and what gets written back.
sub MoveCatBy(scope as string, id as string, allIds as object, delta as integer)
    order = []
    seen = {}
    for each o in allIds
        s = ToStr(o)
        if s <> "" and not seen.doesExist(s)
            seen[s] = true
            order.push(s)
        end if
    end for
    at = -1
    for i = 0 to order.count() - 1
        if order[i] = id
            at = i
            exit for
        end if
    end for
    if at < 0 then return
    SaveCatOrder(scope, moveInArray(order, at, at + delta))
end sub

' Reorder + filter a [{id,name}] category list by the saved prefs. When
' includeHidden is true (the reorder screen), hidden ones stay in flagged.
' Since the merged lineup, category ids ARE their names ({id: name}) —
' every screen passes name-keyed cats, matching the name-keyed prefs. The
' per-provider id->name caches are saved where categories are FETCHED per
' source (the screens' fetch handlers, via SaveCatNameCacheFor), not here —
' merged cats would overwrite a provider's numeric-id cache with a useless
' name->name map and destroy the legacy-pref translation source.
function ApplyCatPrefs(scope as string, cats as object, includeHidden as boolean) as object
    order = LoadCatOrder(scope)
    byId = {}
    for each c in cats
        byId[ToStr(c.id)] = c
    end for
    ordered = []
    used = {}
    for each oid in order
        key = ToStr(oid)
        if byId.doesExist(key) and not used.doesExist(key)
            ordered.push(byId[key])
            used[key] = true
        end if
    end for
    for each c in cats
        key = ToStr(c.id)
        if not used.doesExist(key)
            ordered.push(c)
            used[key] = true
        end if
    end for
    mode = ParentalMode()
    unlocked = ParentalUnlocked()
    out = []
    for each c in ordered
        cid = ToStr(c.id)
        h = IsCatHidden(scope, cid)
        locked = IsCatLocked(scope, cid)
        if includeHidden
            ' Reorder/manage screen: show everything, flagged.
            c.hidden = h
            c.locked = locked
            out.push(c)
        else if not h
            if not locked or unlocked
                c.locked = false
                out.push(c)
            else if mode <> "hide"
                ' pin mode: keep it, flagged so the screen gates on open.
                c.locked = true
                out.push(c)
            end if
            ' hide mode + locked (and not unlocked): dropped.
        end if
    end for
    return out
end function

' ---- Hidden channels + sort order (per provider) ----------------------------

function HiddenChanKey() as string
    return "chan_hidden_" + ActiveProviderId() + ProfileScopeSuffix()
end function

function LoadHiddenChannels() as object
    raw = RegRead(HiddenChanKey())
    if raw = "" then return []
    p = ParseJson(raw)
    if p = invalid then return []
    return ToArray(p)
end function

function IsChannelHidden(streamId as string) as boolean
    for each h in LoadHiddenChannels()
        if ToStr(h) = streamId then return true
    end for
    return false
end function

' Hidden channels stay per provider (the key carries the provider id, and
' since stable ids a channel id names exactly one source's channel). Merged
' screens pass the channel's own provider; legacy callers get the active one.
'
' EXPRESSED THROUGH THE BULK PATH, with its budget deliberately switched off.
' One id is one write either way, so there is nothing to save by keeping a
' second copy of the logic - but this call has shipped uncapped and is reached
' from Live TV's options menu and from the sync projector, neither of which can
' show a reason. Refusing here would be a press that silently does nothing. The
' 30 bytes a single toggle costs is not what fills a registry; a bulk write of
' a thousand is, and that is the one SetChannelsHidden caps.
sub ToggleChannelHidden(streamId as string, provId = "" as string)
    if streamId = "" then return
    nowHidden = false
    for each h in loadHiddenChannelsFor(provId)
        if ToStr(h) = streamId
            nowHidden = true
            exit for
        end if
    end for
    setChannelsHiddenInner([streamId], not nowHidden, provId, true)
end sub

' "Unhide all channels" WRITES AN EMPTY LIST, it does not delete the key. The
' difference is the phone: BuildPsetMap only puts the hidden list into the
' sync blob when the key exists (`if rawHidden <> ""`), so a deleted key left
' the phone's last-known hidden list standing in the blob and a member who
' unhid everything on the television found every channel still hidden on
' the phone. Found on the 2026-09-15 bulk-hide work (Nia); the same rule
' SetChannelsHidden follows when its list empties.
sub ClearHiddenChannels()
    RegWrite(HiddenChanKey(), "[]")
end sub

' ---- Whole-category and multi-select hiding ---------------------------------
' Mason's ruling, 2026-09-15: "under categories on roku in settings for ALL the
' hide menus we need a better system than scrolling through a list of sometimes
' 30k plus and hiding 1 by one." The Settings screens are getting whole-category
' actions and multi-select, so the store now has to take hundreds or thousands
' of ids in ONE call. Everything below exists to make that ONE registry write
' instead of N, and to refuse out loud instead of overflowing in silence.
'
' ---- WHAT A HIDDEN CHANNEL COSTS, MEASURED ----------------------------------
' The whole app lives in 16-32 KB of registry (see RegWrite above) and a write
' past the limit fails SILENTLY, taking whatever else was mid-write with it. So
' this feature states its price.
'
' A hidden channel is written down in TWO places, and both are registry:
'
'   1. the local list, chan_hidden_<providerId><profileSuffix>, a JSON array of
'      raw ids as the source gave them:
'         numeric Xtream id   "123456",                          =  9 bytes
'         M3U id              "m3uh1a2b3c4d",                    = 15 bytes
'
'   2. the KwickSync mirror. BuildPsetMap copies the KwickTV source's hidden
'      ids into the pset blob as portable ids, and SaveSyncMirror stores that
'      whole blob in the registry under sync_mirror:
'         "xt:kwick.cc:123456",                                  = 21 bytes
'
' So the dearest realistic id — a KwickTV member with sync on, which is the
' common case and the one that must not break — costs 9 + 21 = 30 bytes. An
' id on a plain Xtream or M3U source costs only the 9-15, because BuildPsetMap
' reads KwickTvProvider() alone and nothing else reaches the wire.
'
' HiddenChannelMaxPerSet() is therefore 150: 150 x 30 = 4,500 bytes, about a
' quarter of the 16 KB floor. That is deliberately in the same class as the
' 4,096 bytes SeenMaxBytes() already claims for finished-marks, and it leaves
' the providers, the profiles, the favourites (which are UNCAPPED and carry a
' name and a logo address each, the biggest real spender in this file), the
' recents and the resume points their room.
'
' AND a second gate, because the first one is per profile per source. A
' four-profile household each hiding 150 channels would be 18 KB and the
' registry would be gone. HiddenChannelTotalMaxBytes() caps what the FEATURE
' costs the whole box — every chan_hidden_* key on the device plus its wire
' copy — at 6 KB, whichever binds first. Same two-gate shape as
' SeenMaxRows/SeenMaxBytes, for the same reason: a count alone is a 3x swing
' in what it actually costs.
'
' THE CHEAP PATH IS THE POINT. Hiding a whole category costs ONE name in
' cat_hidden_<scope>_all — about 17 bytes — however many hundreds of channels
' sit inside it, and it costs nothing on the wire beyond that name. That is why
' the refusal sentence below tells the member to do that instead: it is not a
' consolation prize, it is the better answer.

' Per profile, per source. See the arithmetic above.
function HiddenChannelMaxPerSet() as integer
    return 150
end function

' What this feature may cost the WHOLE box, across every profile and every
' source, local list plus its sync-mirror copy. 6 KB of a 16 KB floor.
function HiddenChannelTotalMaxBytes() as integer
    return 6144
end function

' Bytes one more hidden id costs, worst realistic case: 9 in the local list
' plus 21 in the pset blob inside sync_mirror. Named rather than inlined so
' the number above and the number used are provably the same one.
function HiddenChannelBytesPerId() as integer
    return 30
end function

' The registry key for one source's hidden set. HiddenChanKey() is the active
' source; this is the same string for an explicit one, and it is the ONLY
' place that string is built so the two can never drift apart.
function hiddenChanKeyFor(provId as string) as string
    if provId = "" then return HiddenChanKey()
    return "chan_hidden_" + provId + ProfileScopeSuffix()
end function

function loadHiddenChannelsFor(provId as string) as object
    raw = RegRead(hiddenChanKeyFor(provId))
    if raw = "" then return []
    p = ParseJson(raw)
    if p = invalid then return []
    return ToArray(p)
end function

' How many channels are hidden in the ACTIVE profile's active source — the
' number the Settings row reads out.
function HiddenChannelCount() as integer
    return LoadHiddenChannels().count()
end function

' How many this profile's active source may hold. Normally
' HiddenChannelMaxPerSet(), reduced when the rest of the box has already spent
' the device-wide allowance — another profile's set, another source's set.
'
' It NEVER returns less than what is already stored here. A budget that read as
' smaller than the current count would make a screen say "you are over the
' limit" about channels the member hid legitimately, and there is no honest
' action to offer them: nothing here un-hides anything on its own.
function HiddenChannelBudget() as integer
    here = HiddenChannelCount()
    spentElsewhere = hiddenChannelDeviceBytes() - (here * HiddenChannelBytesPerId())
    if spentElsewhere < 0 then spentElsewhere = 0
    roomBytes = HiddenChannelTotalMaxBytes() - spentElsewhere
    allowed = 0
    if roomBytes > 0 then allowed = Int(roomBytes / HiddenChannelBytesPerId())
    if allowed > HiddenChannelMaxPerSet() then allowed = HiddenChannelMaxPerSet()
    if allowed < here then allowed = here
    return allowed
end function

' What every hidden set on this box costs together. Walks the profiles and the
' sources rather than the registry, because roRegistrySection.getKeyList() is
' not something to lean on for a budget check that runs on a Settings open.
function hiddenChannelDeviceBytes() as integer
    total = 0
    suffixes = [""]
    for each p in LoadProfiles()
        pid = ToStr(p.id)
        if pid <> "" and pid <> "default" then suffixes.push("_" + pid)
    end for
    for each sfx in suffixes
        for each prov in LoadProviders()
            pv = ToStr(prov.id)
            if pv = "" then continue for
            raw = RegRead("chan_hidden_" + pv + sfx)
            if raw = "" then continue for
            parsed = ParseJson(raw)
            if parsed = invalid then continue for
            total = total + (ToArray(parsed).count() * HiddenChannelBytesPerId())
        end for
    end for
    return total
end function

' The sentence a screen shows when a bulk hide did not all fit. Plain words on
' purpose — the member is looking at a list of thirty thousand channels and
' needs to be told the cheaper way, not a byte count.
function hiddenChannelRefusalText(budget as integer, atNow as integer) as string
    return "This TV can remember about " + budget.toStr() + " hidden channels and is at " + atNow.toStr() + ". Hide whole categories instead - that costs nothing."
end function

' Hide or show MANY channels in ONE registry write.
'
' Returns { applied: n, refused: n, reason: "" }.
'   applied  ids whose state actually CHANGED because of this call. An id
'            already in the state asked for is counted in neither number —
'            nothing happened to it, and a screen saying "hid 40" when 38 were
'            already hidden would be a lie.
'   refused  ids that would have been hidden but did not fit the budget.
'   reason   empty unless something was refused.
'
' SHOWING NEVER REFUSES. Un-hiding only ever makes the stored list shorter, so
' there is no budget to check and no way for it to fail.
'
' ORDER IS PRESERVED EXACTLY, and that is a sync requirement, not tidiness.
' Hidden channels ride to the phone inside the pset blob, which BuildPsetMap
' rebuilds from this list in list order, and both reconcilers compare rows as
' raw serialised strings. Existing entries keep their places and new ones are
' appended in the order given, so hiding 40 channels in one call writes the
' byte-identical value that 40 single toggles in that same order would have —
' no extra push, no ping-pong with the phone.
function SetChannelsHidden(ids as object, hidden as boolean, provId as string) as object
    return setChannelsHiddenInner(ids, hidden, provId, false)
end function

' The real worker. `ignoreBudget` exists for ToggleChannelHidden alone, which
' has shipped uncapped and is called from Live TV's options menu and from the
' sync projector; capping it would make a single press silently do nothing on
' a full box, with no screen able to say why. One id is 30 bytes and is not
' what kills the registry — a thousand-id bulk write is — so the single-item
' path keeps its behaviour to the letter and says so in the log instead.
function setChannelsHiddenInner(ids as object, hidden as boolean, provId as string, ignoreBudget as boolean) as object
    result = { applied: 0, refused: 0, reason: "" }
    if ids = invalid or not isArrayType(ids) then return result
    key = hiddenChanKeyFor(provId)
    current = loadHiddenChannelsFor(provId)

    ' The set of what is hidden now, so the whole call is one pass over `ids`
    ' rather than a scan of the stored list per id. A member multi-selecting
    ' a 30,000-channel category would otherwise be a 30,000 x 150 comparison
    ' on the render thread, and certification 3.5 gives the UI 250 ms.
    present = {}
    for each h in current
        hs = ToStr(h)
        if hs <> "" then present[hs] = true
    end for

    ' Dedupe the incoming list first: the same id twice must not spend the
    ' budget twice, and must not be written twice.
    wanted = []
    askedFor = {}
    for each i in ids
        s = ToStr(i)
        if s = "" then continue for
        if askedFor.doesExist(s) then continue for
        askedFor[s] = true
        wanted.push(s)
    end for

    if hidden
        budget = HiddenChannelMaxPerSet()
        if not ignoreBudget then budget = HiddenChannelBudget()
        room = budget - current.count()
        if room < 0 then room = 0
        kept = []
        for each o in current
            kept.push(ToStr(o))
        end for
        for each s in wanted
            if present.doesExist(s) then continue for
            if not ignoreBudget and room <= 0
                result.refused = result.refused + 1
                continue for
            end if
            kept.push(s)
            present[s] = true
            room = room - 1
            result.applied = result.applied + 1
        end for
        if result.refused > 0
            result.reason = hiddenChannelRefusalText(budget, kept.count())
        end if
        if result.applied > 0
            RegWrite(key, FormatJson(kept))
            if ignoreBudget and kept.count() > HiddenChannelMaxPerSet()
                KLog("store", "hidden channels for '" + key + "' is now " + kept.count().toStr() + ", past the stated budget of " + HiddenChannelMaxPerSet().toStr() + " - a single toggle is deliberately never refused, but the registry is finite")
            end if
        end if
        return result
    end if

    ' Showing. Rebuild the list minus everything asked for, in one pass, and
    ' only write when something actually went.
    kept = []
    for each o in current
        os = ToStr(o)
        if askedFor.doesExist(os)
            result.applied = result.applied + 1
        else
            kept.push(os)
        end if
    end for
    if result.applied = 0 then return result
    ' An emptied list is written as "[]" and the key is NOT deleted, which
    ' looks like two wasted bytes and is not. BuildPsetMap only puts
    ' pref_hidden_channel_ids on the wire when this key exists ("if rawHidden
    ' <> ''"), so deleting it would leave the phone's last-known hidden list
    ' standing in the pset blob - the member un-hides their last channel on the
    ' TV and the phone never hears about it. ToggleChannelHidden has always
    ' written "[]" here; this keeps that exactly.
    RegWrite(key, FormatJson(kept))
    return result
end function

' How many of these channels are hidden. ONE registry read for the whole
' category, so a Settings row can print "12 of 340 hidden" without a read per
' row — a read per row down a list of hundreds is the same shape of mistake as
' a network call per tile, and certification 3.5 gives the UI 250 ms to answer
' a remote press.
function ChannelsHiddenInCategory(provId as string, streamIds as object) as integer
    if streamIds = invalid or not isArrayType(streamIds) then return 0
    present = {}
    for each h in loadHiddenChannelsFor(provId)
        hs = ToStr(h)
        if hs <> "" then present[hs] = true
    end for
    if present.count() = 0 then return 0
    total = 0
    counted = {}
    for each i in streamIds
        s = ToStr(i)
        if s = "" then continue for
        if counted.doesExist(s) then continue for
        counted[s] = true
        if present.doesExist(s) then total = total + 1
    end for
    return total
end function

' ---- Hiding MANY categories at once -----------------------------------------
' The cheap half of Mason's ruling. One category name in cat_hidden_<scope>_all
' hides every channel inside it for about 17 bytes, however many hundreds that
' is, and this makes sure a whole-category action costs exactly that and not a
' byte more: ONE read, ONE write, no channel ids written down at all.
'
' Matching is by exact string, character for character the same test
' ToggleCatHidden makes, so a bulk change and N single toggles agree. Category
' prefs have been name-keyed under the "all" namespace since the merged
' lineup, and names are what the wire carries, so nothing is translated here.
'
' THE CAP, and why it is generous. A name is about 17 bytes on the wire and the
' same again in the pset copy inside sync_mirror, so call it 34. Two and a half
' kilobytes is roughly 75 hidden categories per scope — more than any real
' panel's whole category list, so in practice it cannot bind, which is the
' point: the screens steer members here and this path must not be the one that
' says no. Past it the extra names are dropped and the log says so.
'
' KNOWN GAP, deliberately not papered over: this is a `sub` because that is the
' agreed signature, so it has no way to tell the screen a name was dropped.
' Given the cap cannot realistically bind that is a log line rather than a
' silent failure, but if the 2,560 bytes ever needs lowering this has to become
' a function first.
function CatHiddenMaxBytes() as integer
    return 2560
end function

sub SetCatsHidden(scope as string, ids as object, hidden as boolean)
    if ids = invalid or not isArrayType(ids) then return
    current = LoadHiddenCats(scope)

    asked = {}
    wanted = []
    for each i in ids
        s = ToStr(i)
        if s = "" then continue for
        if asked.doesExist(s) then continue for
        asked[s] = true
        wanted.push(s)
    end for
    if wanted.count() = 0 then return

    kept = []
    changed = false

    if hidden
        present = {}
        for each h in current
            hs = ToStr(h)
            if hs <> "" and not present.doesExist(hs)
                present[hs] = true
                kept.push(hs)
            end if
        end for
        ' Measured for real rather than estimated from a count: category names
        ' are the member's provider's words and their length is not this file's
        ' to assume.
        bytesNow = FormatJson(kept).len()
        dropped = 0
        for each s in wanted
            if present.doesExist(s) then continue for
            cost = s.len() + 3
            if (bytesNow + cost) > CatHiddenMaxBytes()
                dropped = dropped + 1
                continue for
            end if
            kept.push(s)
            present[s] = true
            bytesNow = bytesNow + cost
            changed = true
        end for
        if dropped > 0
            KLog("store", "hidden categories for scope '" + scope + "' is full at " + CatHiddenMaxBytes().toStr() + "B - " + dropped.toStr() + " were NOT hidden")
        end if
    else
        for each h in current
            hs = ToStr(h)
            if asked.doesExist(hs)
                changed = true
            else
                kept.push(hs)
            end if
        end for
    end if

    if not changed then return
    if kept.count() = 0
        RegDelete(CatHiddenKey(scope))
        return
    end if
    RegWrite(CatHiddenKey(scope), FormatJson(kept))
end sub

' ---- Hand-set channel order --------------------------------------------------
' Until now a channel could only be hidden or sorted A-Z; a member who wanted
' their five channels at the top had no way to say so. The Android app has had
' it all along (content_order.dart, applyCustomOrder) and this is the same
' rule: the ids listed here come first, in this order, and every channel not
' listed keeps the order its source gave it, underneath.
'
' ONLY THE MOVED ONES ARE STORED, and that is what makes it affordable. Saving
' a full running order would mean one id per channel — a member with a
' two-thousand-channel package would be asking the registry to hold roughly
' twenty kilobytes for a preference, and the whole app has sixteen to
' thirty-two thousand bytes to live in (see the note above SeenMaxRows). A
' "these first" list is the same thing a member actually does — push a handful
' of channels to the top — for the price of the handful.
'
' THE CAP: ChanOrderMax() ids. At ~9 bytes for a numeric Xtream id and ~15 for
' an M3U one ("m3uh1a2b3c4d"), sixty ids is roughly 550 to 900 bytes, which is
' a price worth naming out loud. Past the cap the oldest arrangement falls off
' the end rather than the write failing silently.
'
' DEVICE-LOCAL, DELIBERATELY. Android syncs its channel order under
' pref_channel_order, and this does NOT join it, for two reasons that both
' have to be wrong before it would be safe. First, the phone stores the FULL
' order and this stores a short head of it, so pushing ours would replace a
' member's complete phone ordering with sixty ids and throw the rest away.
' Second, a full order arriving from the phone is exactly the twenty kilobytes
' this design exists to avoid, and a write past the quota fails silently and
' takes whatever else was mid-write with it. Honouring it in one direction
' only would be worse than either: the phone's order would be re-applied over
' the member's Roku arrangement on every cycle, so a reorder made on the TV
' would quietly undo itself. It stays here, on this box, and says so.

function ChanOrderKey() as string
    return "chan_order" + ProfileScopeSuffix()
end function

function ChanOrderMax() as integer
    return 60
end function

function LoadChanOrder() as object
    raw = RegRead(ChanOrderKey())
    if raw = "" then return []
    p = ParseJson(raw)
    if p = invalid then return []
    return ToArray(p)
end function

sub SaveChanOrder(ids as object)
    kept = []
    seen = {}
    for each i in ids
        s = ToStr(i)
        if s <> "" and not seen.doesExist(s)
            seen[s] = true
            kept.push(s)
            if kept.count() >= ChanOrderMax() then exit for
        end if
    end for
    if kept.count() = 0
        RegDelete(ChanOrderKey())
        return
    end if
    RegWrite(ChanOrderKey(), FormatJson(kept))
end sub

' Put one channel at the top of the running order.
sub MoveChannelToTop(streamId as string)
    newOrder = [streamId]
    for each o in LoadChanOrder()
        if ToStr(o) <> streamId then newOrder.push(o)
    end for
    SaveChanOrder(newOrder)
end sub

' Can this channel be nudged up or down at all?
'
' Moving one channel past another means writing down BOTH of them and
' everything above them, because the stored list is a "these first" head and
' nothing in it can be described without the ids in front of it. So a channel
' sitting at position 900 cannot be moved by one without a 901-long list, and
' the cap is ChanOrderMax(). Rather than truncate that list — which would
' silently drop the very move being asked for and leave a button that appears
' to do nothing — the move is not offered at all past the cap, and Move to
' Top, which needs one id and no context, is offered instead.
function CanMoveChannelBy(at as integer) as boolean
    return at >= 0 and at < ChanOrderMax() - 1
end function

' Nudge one channel up or down by one place. `allIds` is the running order the
' member is looking at (the whole channel list as it is currently drawn) —
' without it there is nothing to move RELATIVE to, because the stored list
' only holds the channels somebody has already moved.
sub MoveChannelBy(streamId as string, allIds as object, delta as integer)
    cur = []
    seen = {}
    for each o in LoadChanOrder()
        s = ToStr(o)
        if not seen.doesExist(s)
            seen[s] = true
            cur.push(s)
        end if
    end for
    ' Anything above the moving channel in the drawn list has to be written
    ' down too, or "move up one" would jump it past every channel that was
    ' only sitting there by its source's own ordering.
    at = -1
    for i = 0 to allIds.count() - 1
        if ToStr(allIds[i]) = streamId
            at = i
            exit for
        end if
    end for
    if at < 0 then return
    ' Past the cap the move cannot be written down at all — see
    ' CanMoveChannelBy. Refuse rather than save a truncated list that would
    ' quietly leave the channel exactly where it was.
    if not CanMoveChannelBy(at) then return
    limit = at + 2
    if limit > allIds.count() then limit = allIds.count()
    merged = []
    mseen = {}
    for i = 0 to limit - 1
        s = ToStr(allIds[i])
        if not mseen.doesExist(s)
            mseen[s] = true
            merged.push(s)
        end if
    end for
    for each s in cur
        if not mseen.doesExist(s)
            mseen[s] = true
            merged.push(s)
        end if
    end for
    idx = -1
    for i = 0 to merged.count() - 1
        if merged[i] = streamId
            idx = i
            exit for
        end if
    end for
    if idx < 0 then return
    SaveChanOrder(moveInArray(merged, idx, idx + delta))
end sub

sub ClearChannelOrder()
    RegDelete(ChanOrderKey())
end sub

' Reorder a channel list by the saved running order. Listed ids first, in that
' order; everything else keeps its source's order, underneath.
'
' NOTHING IS EVER DROPPED and nothing is ever doubled, which is why this fills
' numbered slots rather than looking channels up by id. Two Xtream panels can
' both call a channel 143, and an id->channel map would keep one of them and
' lose the other off the end of Live TV entirely. Here the first channel to
' claim a slot gets it and the second falls through to the tail, so the worst
' a collision can do is order one channel by another one's wishes.
function applyChanOrder(arr as object) as object
    order = LoadChanOrder()
    if order.count() = 0 then return arr
    rank = {}
    for i = 0 to order.count() - 1
        rank[ToStr(order[i])] = i
    end for
    head = []
    for i = 0 to order.count() - 1
        head.push(invalid)
    end for
    tail = []
    for each c in arr
        k = ToStr(c.streamId)
        if rank.doesExist(k) and head[rank[k]] = invalid
            head[rank[k]] = c
        else
            tail.push(c)
        end if
    end for
    out = []
    for each h in head
        if h <> invalid then out.push(h)
    end for
    for each t in tail
        out.push(t)
    end for
    return out
end function

' Preferred subtitle language (ISO code) — auto-on picks this track on VOD.
function PreferredCaptionLang() as string
    l = RegRead("pref_caption_lang" + ProfileScopeSuffix())
    if l = "" then return "eng"
    return l
end function

sub SetPreferredCaptionLang(code as string)
    RegWrite("pref_caption_lang" + ProfileScopeSuffix(), code)
end sub

' ---- How long the player's controls stay on screen ---------------------------
' JB-10. MASON, 2026-09-17: "add a option in settings -> playback -> add a
' option to choose how long the player controls show before they fade out —
' 5s, 10s, 15s", and earlier the same day the reason — "that way if I want the
' buttons set to stay showing long, I can set it."
'
' THREE CHOICES AND NO MORE, because three is what he asked for. There is
' deliberately no "Never": a bar that never goes is a picture with a bar across
' it, and a member who wants that has the pause button.
'
' THE DEFAULT IS 5, and that is arithmetic rather than taste. Every player in
' this app hid its controls after 4 seconds before this setting existed
' (PlayerScreen.xml, the hideTimer) and 5 is the nearest of the three, so a
' member who never opens this row sees what they have always seen.
'
' PER PROFILE, like the playback preferences either side of it, with the
' default profile keeping the bare key name as everything per-profile here
' does. Android scoped its own copy the same way and wrote down why
' (preference_constants.dart, `controlsHideSeconds`): how long you want the
' buttons in front of the picture is a taste, not a fact about the hardware.
'
' IT TRAVELS OVER KWICKSYNC, under Android's own key name — see psetScalarMap
' at the foot of this file for the checking that went into claiming it.
'
' WHAT IT COSTS. "pref_controls_timeout" is 21 bytes and the value is one or
' two ("5", "10", "15"): 23 bytes per profile that has ever changed it, and
' NOTHING at all for a profile that has not, because an absent key already
' reads back as 5. Four profiles that have all changed it is 92 bytes. It caps
' itself — the setter below refuses anything that is not one of the three, so
' no caller now or later can put a longer value in the registry, and
' psetChoiceOk refuses the same values in both directions on the wire.
function ControlsTimeoutChoices() as object
    return [5, 10, 15]
end function

function ControlsTimeoutSecs() as integer
    raw = RegRead("pref_controls_timeout" + ProfileScopeSuffix())
    if raw = "" then return 5
    n = raw.toInt()
    for each c in ControlsTimeoutChoices()
        if n = c then return n
    end for
    ' A number no picker in this app can produce — an older build, a
    ' hand-edited registry, a future build offering a fourth choice — is read
    ' as the default rather than trusted, which is exactly what Android's
    ' ControlsTimeout.fromSeconds does with the same value. The player must
    ' never be handed a timer it cannot arm.
    return 5
end function

sub SetControlsTimeoutSecs(n as integer)
    for each c in ControlsTimeoutChoices()
        if n = c
            RegWrite("pref_controls_timeout" + ProfileScopeSuffix(), n.toStr())
            return
        end if
    end for
end sub

' Channel sort: "default" | "az" | "za".
function ChannelSort() as string
    s = RegRead("pref_channel_sort" + ProfileScopeSuffix())
    if s = "" then return "default"
    return s
end function

sub SetChannelSort(mode as string)
    RegWrite("pref_channel_sort" + ProfileScopeSuffix(), mode)
end sub

' Filter hidden + apply sort to a [{streamId,name,...}] channel list. Each
' channel is checked against ITS OWN provider's hidden set (merged lists mix
' sources); channels without a provId fall back to the active provider —
' the pre-merge behavior. Hidden sets load once per provider, not per channel.
function ApplyChannelPrefs(chans as object) as object
    hiddenBy = {}
    activeId = ActiveProviderId()
    suffix = ProfileScopeSuffix()
    out = []
    for each c in chans
        pid = ToStr(GetField(c, "provId"))
        if pid = "" then pid = activeId
        if not hiddenBy.doesExist(pid)
            hset = {}
            for each h in LoadJsonArray("chan_hidden_" + pid + suffix)
                hset[ToStr(h)] = true
            end for
            hiddenBy[pid] = hset
        end if
        if not hiddenBy[pid].doesExist(ToStr(c.streamId)) then out.push(c)
    end for
    mode = ChannelSort()
    if mode = "az" or mode = "za"
        sortChannelsByName(out, mode = "za")
        ' A-Z is a whole-list rule and a hand-set order is a per-channel one,
        ' so the hand-set one is applied last and wins for the channels it
        ' names — exactly like the category screen, where Move to Top beats
        ' whatever order the panel sent.
    end if
    return applyChanOrder(out)
end function

' Simple insertion sort by lowercased name (channel lists are modest).
sub sortChannelsByName(arr as object, descending as boolean)
    for i = 1 to arr.count() - 1
        cur = arr[i]
        curName = LCase(ToStr(cur.name))
        j = i - 1
        while j >= 0
            cmpName = LCase(ToStr(arr[j].name))
            swap = false
            if descending then swap = (cmpName < curName) else swap = (cmpName > curName)
            if not swap then exit while
            arr[j + 1] = arr[j]
            j = j - 1
        end while
        arr[j + 1] = cur
    end for
end sub

' ---- Favorite Lists ---------------------------------------------------------
' Named lists holding channels, movies, and series (Android's Favorite
' Lists). Each list: { id, name, homeRow (bool), items:[{kind,id,name,icon,ext}] }.
' Stored per provider so lists follow the source.

function ListsKey() as string
    return "fav_lists_" + ActiveProviderId() + ProfileScopeSuffix()
end function

function LoadLists() as object
    raw = RegRead(ListsKey())
    if raw = "" then return []
    p = ParseJson(raw)
    if p = invalid then return []
    return ToArray(p)
end function

sub SaveLists(lists as object)
    RegWrite(ListsKey(), FormatJson(lists))
end sub

function CreateList(name as string) as string
    lists = LoadLists()
    id = "l" + CreateObject("roDateTime").asSeconds().toStr() + lists.count().toStr()
    lists.push({ id: id, name: name, homeRow: true, items: [] })
    SaveLists(lists)
    return id
end function

sub RenameList(id as string, name as string)
    lists = LoadLists()
    for each l in lists
        if l.id = id then l.name = name
    end for
    SaveLists(lists)
end sub

sub DeleteList(id as string)
    lists = LoadLists()
    kept = []
    for each l in lists
        if l.id <> id then kept.push(l)
    end for
    SaveLists(kept)
end sub

sub ToggleListHomeRow(id as string)
    lists = LoadLists()
    for each l in lists
        if l.id = id then l.homeRow = not (l.homeRow = true)
    end for
    SaveLists(lists)
end sub

' Is an item (kind+id) in a given list? Items carry src since the merged
' lineup; token invalid means "any source" (legacy callers), otherwise the
' same id on a different source is a different item.
function IsInList(listId as string, kind as string, itemId as string, token = invalid as dynamic) as boolean
    for each l in LoadLists()
        if l.id = listId
            for each it in ToArray(l.items)
                if ToStr(it.kind) = kind and ToStr(it.id) = itemId
                    if token = invalid then return true
                    if ToStr(GetField(it, "src")) = ToStr(token) then return true
                end if
            end for
        end if
    end for
    return false
end function

' Is an item in ANY list? (for the "In lists" indicator)
function IsInAnyList(kind as string, itemId as string, token = invalid as dynamic) as boolean
    for each l in LoadLists()
        for each it in ToArray(l.items)
            if ToStr(it.kind) = kind and ToStr(it.id) = itemId
                if token = invalid then return true
                if ToStr(GetField(it, "src")) = ToStr(token) then return true
            end if
        end for
    end for
    return false
end function

' Add/remove an item from a list (toggle). Same kind+id on two sources is
' two distinct items — the src field (absent = "", the KwickTV login)
' takes part in the match.
sub ToggleItemInList(listId as string, item as object)
    lists = LoadLists()
    for each l in lists
        if l.id = listId
            kept = []
            found = false
            for each it in ToArray(l.items)
                if ToStr(it.kind) = ToStr(item.kind) and ToStr(it.id) = ToStr(item.id) and ToStr(GetField(it, "src")) = ToStr(GetField(item, "src"))
                    found = true
                else
                    kept.push(it)
                end if
            end for
            if not found then kept.push(item)
            l.items = kept
        end if
    end for
    SaveLists(lists)
end sub

' ---- Favorites (channels) -------------------------------------------------
' Per-profile (Android's favch kind).

function FavChannelsKey() as string
    return "fav_channels" + ProfileScopeSuffix()
end function

function LoadFavoriteChannels() as object
    raw = RegRead(FavChannelsKey())
    if raw = "" then return []
    parsed = ParseJson(raw)
    if parsed = invalid then return []
    return ToArray(parsed)
end function

' Favorites are matched per source: the same numeric id on two different
' sources is two different channels.
function IsFavoriteChannel(streamId as string, token = invalid as dynamic) as boolean
    t = ""
    if token = invalid then t = ActiveSrcToken() else t = ToStr(token)
    for each f in LoadFavoriteChannels()
        if ToStr(f.streamId) = streamId and SrcMatches(f, t) then return true
    end for
    return false
end function

sub ToggleFavoriteChannel(channel as object)
    token = ItemSrcToken(channel)
    favs = LoadFavoriteChannels()
    kept = []
    found = false
    for each f in favs
        if ToStr(f.streamId) = ToStr(channel.streamId) and SrcMatches(f, token)
            found = true
        else
            kept.push(f)
        end if
    end for
    if not found
        if token <> "" then channel.src = token
        kept.push(channel)
    end if
    RegWrite(FavChannelsKey(), FormatJson(kept))
end sub

' ---- Favorites (movies & series) --------------------------------------------
' Items: { kind: "movie"|"series", id, name, icon, ext }. Per-profile.

function FavVodKey() as string
    return "fav_vod" + ProfileScopeSuffix()
end function

function LoadFavoriteVod() as object
    raw = RegRead(FavVodKey())
    if raw = "" then return []
    parsed = ParseJson(raw)
    if parsed = invalid then return []
    return ToArray(parsed)
end function

function IsFavoriteVod(kind as string, id as string, token = invalid as dynamic) as boolean
    t = ""
    if token = invalid then t = ActiveSrcToken() else t = ToStr(token)
    for each f in LoadFavoriteVod()
        if ToStr(f.kind) = kind and ToStr(f.id) = id and SrcMatches(f, t) then return true
    end for
    return false
end function

' A "kind:id" -> true lookup of the profile's favorites, held on m.global so
' every poster tile can consult it for free.
'
' WHY THIS EXISTS: IsFavoriteVod() above does a registry read AND a JSON
' parse on every single call. A category grid holds hundreds of tiles and
' MarkupGrid recycles them continuously while scrolling, so asking it per
' tile would mean a registry read per poster per scroll — a visible stutter
' on a stick. Build the map once, read it a thousand times.
'
' Rebuilt by ToggleFavoriteVod below, so it cannot drift from the registry
' as long as everything goes through that one function.
' Index keys carry each entry's OWN source ("src:kind:id", or bare "kind:id"
' for KwickTV — the same shape as KwickSync's vodKeys), and lookups build
' theirs from the active source — so a switch needs no index rebuild, and a
' title favorited on one source never lights a heart on another.
sub RefreshFavVodIndex()
    idx = {}
    for each f in LoadFavoriteVod()
        key = ToStr(f.kind) + ":" + ToStr(f.id)
        s = ToStr(GetField(f, "src"))
        if s <> "" then key = s + ":" + key
        idx[key] = true
    end for
    ' Same guard KLog uses: the global node only exists after AppScene init.
    if m.global <> invalid and m.global.hasField("favVodIndex") then m.global.favVodIndex = idx
end sub

' The key a poster tile looks up. Channels deliberately return "" — a channel
' favorite is a different list and must never draw the mark. Callers building
' keys in a loop should fetch ActiveSrcToken() once and pass it, rather than
' paying a registry read per item.
function FavVodKeyFor(kind as string, id as string, token = invalid as dynamic) as string
    k = LCase(kind)
    if k <> "movie" and k <> "series" then return ""
    if id = "" then return ""
    t = ""
    if token = invalid then t = ActiveSrcToken() else t = ToStr(token)
    if t = "" then return k + ":" + id
    return t + ":" + k + ":" + id
end function

sub ToggleFavoriteVod(item as object)
    token = ItemSrcToken(item)
    favs = LoadFavoriteVod()
    kept = []
    found = false
    for each f in favs
        if ToStr(f.kind) = ToStr(item.kind) and ToStr(f.id) = ToStr(item.id) and SrcMatches(f, token)
            found = true
        else
            kept.push(f)
        end if
    end for
    if not found
        if token <> "" then item.src = token
        kept.push(item)
    end if
    RegWrite(FavVodKey(), FormatJson(kept))
    RefreshFavVodIndex()
end sub

' ---- Putting saved rows in the member's own order ---------------------------
' Favorites and Favorite Lists have always come out in the order they went in
' (Store kept whatever push() gave it), while the Android app lets a member
' drag them about. These three do the same job on this side.
'
' THE ORDER IS THE ARRAY. There is no second "order" list in the registry,
' because there doesn't need to be one: these rows are already stored as a
' JSON array, and rewriting that array in a different order costs exactly the
' same number of bytes it cost before. A separate order key would be the only
' part of this work with a price, and it would have to be paid for a list the
' registry is already holding in full. So it isn't paid.
'
' WHAT SYNC DOES TO IT. Nothing, until the same row changes on another
' device: SyncTask's projectors drop the row they are updating and push the
' new one on the end (projectFavChannel / projectFavVod / projectFavList).
' That is the pre-existing behaviour of an ADD and it reads correctly — a
' favorite added on the phone lands at the bottom of the row on the TV — but
' it does mean a title re-favorited elsewhere leaves the spot the member put
' it in. Everything else the member ordered stays exactly where they left it.

' Move one entry of an array from where it is to where it is going, keeping
' everything else in order. Out-of-range asks are no-ops rather than errors —
' the screens work off a list they drew a moment ago, and a row can go away
' underneath them (a sync cycle, another profile switching in).
function moveInArray(arr as object, fromIdx as integer, toIdx as integer) as object
    n = arr.count()
    if fromIdx < 0 or fromIdx >= n then return arr
    dest = toIdx
    if dest < 0 then dest = 0
    if dest > n - 1 then dest = n - 1
    if dest = fromIdx then return arr
    item = arr[fromIdx]
    out = []
    for i = 0 to n - 1
        if i <> fromIdx then out.push(arr[i])
    end for
    ' Rebuild rather than shuffle in place: BrightScript arrays have no
    ' insert-at, and a hand-rolled shuffle is where an off-by-one silently
    ' duplicates somebody's favorite.
    final = []
    for i = 0 to out.count()
        if i = dest then final.push(item)
        if i < out.count() then final.push(out[i])
    end for
    return final
end function

sub MoveFavoriteChannelTo(fromIdx as integer, toIdx as integer)
    RegWrite(FavChannelsKey(), FormatJson(moveInArray(LoadFavoriteChannels(), fromIdx, toIdx)))
end sub

sub MoveFavoriteVodTo(fromIdx as integer, toIdx as integer)
    RegWrite(FavVodKey(), FormatJson(moveInArray(LoadFavoriteVod(), fromIdx, toIdx)))
    RefreshFavVodIndex()
end sub

sub MoveListTo(fromIdx as integer, toIdx as integer)
    SaveLists(moveInArray(LoadLists(), fromIdx, toIdx))
end sub

' ---- VOD resume positions ---------------------------------------------------
' One registry section keyed by content id ("movie:123" / "ep:456"),
' storing "{positionS}|{durationS}". Cleared when finished (past 95%).

' Resume keys are prefixed per profile ("<id>|movie:..."); the default
' profile keeps the bare legacy keys so existing resume points carry over.
function ResumePrefix() as string
    id = ActiveProfileId()
    if id = "default" then return ""
    return id + "|"
end function

' A resume key with the profile prefix taken off, so what is left always starts
' "movie:" or "ep:" whoever is watching.
'
' THIS EXISTS BECAUSE THE SAME MISTAKE HAS NOW BEEN MADE THREE TIMES, and each
' time it was worked around where it was found rather than fixed where it came
' from. The default profile's keys are bare ("ep:jf:ab12~9f8e"), so
' `key.left(3) = "ep:"` reads correctly for the member who never made a second
' profile — and silently calls every episode a movie for everyone who did,
' because their keys start "pf17559990|". markFinished hit it and stripped the
' prefix itself; MediaBarEpisodeIndex hit it and stopped trusting the stored
' kind at all; the media-server watch history collector hit it and read the
' kind off the key instead. Only the place that WRITES the kind was never
' corrected, so the wrong value kept being produced and every reader had to
' know. It is corrected now, and this is the one rule.
'
' A bare key with no prefix comes back unchanged, which is the default
' profile's case and must stay exactly as it is: those keys are the legacy
' ones and a member's existing resume points are filed under them.
function BareResumeKey(key as string) as string
    bar = Instr(1, key, "|")
    if bar <= 0 then return key
    return Mid(key, bar + 1)
end function

' Is this resume key an episode rather than a film? Asked of the bare key, so
' it answers the same on every profile. See BareResumeKey for why that needs
' saying at all.
function ResumeKeyIsEpisode(key as string) as boolean
    return BareResumeKey(key).left(3) = "ep:"
end function

' "episode" or "movie" for a resume key — the value that goes in a history
' row's `kind` and travels to the phone under that name.
function ResumeKeyKind(key as string) as string
    if ResumeKeyIsEpisode(key) then return "episode"
    return "movie"
end function

' The content id inside a resume key is source-qualified ("<src>~<id>") on
' every source but KwickTV — a movie half-watched on one source must not
' show a resume bar on the same-numbered movie of another.
function ResumeKeyMovie(streamId as string, token = invalid as dynamic) as string
    return ResumePrefix() + "movie:" + SrcQualifiedId(streamId, token)
end function

function ResumeKeyEpisode(episodeId as string, token = invalid as dynamic) as string
    return ResumePrefix() + "ep:" + SrcQualifiedId(episodeId, token)
end function

' THE 95% RULE, AND THE ONE CASE IT CANNOT REACH (asked and answered
' 2026-08-26; PlayerScreen.brs:790 points here for the fix and is wrong).
'
' While a duration IS reported this already does the whole job, on every
' tick of the player's save timer: past 95% the point is thrown away and
' never written again, so the player's own end-of-stream ClearResume is
' belt-and-braces, not the mechanism.
'
' It cannot reach a title whose duration the player NEVER reports. durationS
' arrives as 0, so there is no end to be 95% of, and the last position looks
' the same whether the film ran out or the download died. Nothing here can
' tell those apart, so nothing here fixes it: such a film keeps its resume
' point and goes on offering Resume at the very end. Deliberate, and the
' safe side of Mason's rule — "do not reset an existing playback position
' unless the user intentionally chooses to start from the beginning".
'
' It is also what the phone does. Android's progressOf returns null on an
' unknown duration, so isFinished is false and shouldResume stays true
' (watch_state.dart:32-72). Both devices offer Resume forever on a
' duration-less title; they agree, and that is the behaviour to keep.
'
' A member who wants rid of one has Settings' Clear resume points, and
' Remove from history on the row itself. Costs no registry bytes: this
' branch only ever deletes.
sub SaveResume(key as string, positionS as integer, durationS as integer)
    if positionS < 15 then return ' too early to bother
    if durationS > 0 and positionS > Int(durationS * 0.95)
        ClearResume(key) ' finished — forget it
        return
    end if
    sec = CreateObject("roRegistrySection", "kwick_resume")
    sec.write(key, positionS.toStr() + "|" + durationS.toStr())
    ' Same silent-failure check RegWrite makes, and this is the section where
    ' it matters most: a full registry drops the member's place in a film and
    ' tells nobody, which is indistinguishable from the sync bug we spent a
    ' week chasing. Compared against true rather than negated so a surprise
    ' return value can never take the player down mid-playback.
    if sec.flush() <> true
        KLog("store", "registry write REFUSED for resume point '" + key + "' - the registry is full and this position was NOT saved")
    end if
end sub

' Returns { positionS, durationS } or invalid if none saved.
function LoadResume(key as string) as dynamic
    sec = CreateObject("roRegistrySection", "kwick_resume")
    if not sec.exists(key) then return invalid
    parts = sec.read(key).split("|")
    if parts.count() < 2 then return invalid
    return { positionS: ToInt(parts[0]), durationS: ToInt(parts[1]) }
end function

sub ClearResume(key as string)
    sec = CreateObject("roRegistrySection", "kwick_resume")
    if sec.exists(key)
        sec.delete(key)
        sec.flush()
    end if
    hsec = CreateObject("roRegistrySection", "kwick_hist")
    if hsec.exists(key)
        hsec.delete(key)
        hsec.flush()
    end if
end sub

' ---- Watch-history metadata (KwickSync hist push, T7) -----------------------
' Written by the player alongside each resume point for LOCALLY watched
' titles (title/poster/etc — everything the phone's Continue Watching needs).
' Entries pulled from other devices never get one; only locally watched
' titles push back, which keeps re-syncs from churning.

sub SaveHistMeta(resumeKey as string, meta as object)
    sec = CreateObject("roRegistrySection", "kwick_hist")
    sec.write(resumeKey, FormatJson(meta))
    sec.flush()
end sub

function LoadHistMeta(resumeKey as string) as dynamic
    sec = CreateObject("roRegistrySection", "kwick_hist")
    if not sec.exists(resumeKey) then return invalid
    return ParseJson(sec.read(resumeKey))
end function

' "54m left" / "12m left" for the Resume button label.
function ResumeLeftText(positionS as integer, durationS as integer) as string
    if durationS <= 0 then return "Resume"
    leftS = durationS - positionS
    if leftS < 60 then return "Resume"
    mins = Int(leftS / 60)
    if mins >= 60
        hrs = Int(mins / 60)
        remMins = mins mod 60
        return "Resume - " + hrs.toStr() + "h " + remMins.toStr() + "m left"
    end if
    return "Resume - " + mins.toStr() + "m left"
end function

' ---- Finished marks ("seen") ------------------------------------------------
' The record that something was watched TO THE END.
'
' Until now this app kept none. The only trace of finishing a title was its
' resume point being thrown away at 95% (see SaveResume) — and "has no resume
' point" cannot be told apart from "never started it", which is why
' MediaBarEntries has to treat the two the same. Episode ticks, auto-play
' next, "Mark as watched" and Continue Watching advancing all need to know the
' difference, so it gets written down properly here.
'
' Its own registry section, "kwick_seen", keyed with EXACTLY the string a
' resume point uses:
'
'     "<profileId>|"  (blank for the default profile)
'   + "movie:<src>~<id>"  /  "ep:<src>~<id>"
'
' The same key on purpose, not by coincidence. A caller that already holds a
' resume key already holds a seen key; the per-profile namespacing and the
' source-qualifying are the rules already proven on resume points rather than
' a second set that could drift out of step; and the three places that rewrite
' resume keys — a source address edited on the website
' (moveTokenInResumeKeys), the one-time source-qualifying migration
' (requalifyResumeKeys), and a profile being deleted (clearProfileKeysIn) —
' sweep this section in the same loop for one word of change each.
'
' VALUE: "<atMs>|<parent>"
'   atMs    when it was finished, milliseconds since 1970, kept as TEXT
'           because it does NOT fit in the 32-bit integer ToInt() returns —
'           the same trap the "at" in kwick_hist carries (see mediaBarIdxPut).
'   parent  for an episode, the series it belongs to ("series:<src>~<id>");
'           blank for a film.
'
' Parent is stored rather than looked up later, and that is load-bearing:
' ClearResume deletes the kwick_hist row at the same moment the mark is
' written, so the only other place that knew which show an episode belonged
' to is gone by the time anything reads the mark. Without it, "which episodes
' of this show are finished" could only be answered by asking the panel for
' the episode list — a per-tile network call on every Home build, which is
' the exact loop that got this house's address banned on 2026-08-14.
'
' ---- Size, and why there is a cap -------------------------------------------
' The registry is 16-32 KB for the WHOLE app — providers, favorites, lists,
' recents, settings and the sync mirror all share it — and a write past the
' limit fails SILENTLY, taking whatever else was mid-write with it. So this
' store states its own price and refuses to grow past it.
'
' One mark costs its key plus its value:
'
'   cheapest  default profile, KwickTV source, film
'             key   "movie:12345"                                   = 11
'             value "1756039200000|"                                = 14
'                                                                    ~25 bytes
'   dearest   named profile, xt: source, episode
'             key   "pf17559990123|ep:xt:panel.example.com~987654"  = 44
'             value "1756039200000|series:xt:panel.example.com~432" = 51
'                                                                    ~95 bytes
'
' A cap by COUNT alone would therefore be a four-fold swing in what it
' actually costs, so BOTH are capped and whichever binds first wins:
' SeenMaxRows() rows, and SeenMaxBytes() of key+value measured for real.
' In practice that is ~160 marks for a plain KwickTV member and ~45 for a
' member on a long-hostname extra source — deliberately modest, because this
' store is a nicety and the member's providers and favorites are not.
'
' Eviction drops the OLDEST marks first, and losing one is the safe failure:
' a forgotten mark shows somebody an episode they have already seen, while a
' wrong mark HIDES an episode they have not. Every doubt in here resolves
' towards "not finished".

function SeenMaxRows() as integer
    return 200
end function

function SeenMaxBytes() as integer
    return 4096
end function

' The registry key a finished mark for the ACTIVE profile lives under —
' character for character the string ResumeKeyMovie/ResumeKeyEpisode build,
' so the two stores line up with no translation.
function SeenKeyMovie(streamId as string, token = invalid as dynamic) as string
    return ResumePrefix() + "movie:" + SrcQualifiedId(streamId, token)
end function

function SeenKeyEpisode(episodeId as string, token = invalid as dynamic) as string
    return ResumePrefix() + "ep:" + SrcQualifiedId(episodeId, token)
end function

' The "<profileId>|" a key for a NAMED profile carries (blank for default) —
' for the sync projector, which writes into a profile that is not necessarily
' the active one. Same rule as ResumePrefix, spelled out for an explicit id.
function SeenPrefixFor(profileId as string) as string
    if profileId = "default" or profileId = "" then return ""
    return profileId + "|"
end function

' Write a mark. atMs omitted means "now"; parent is the series ref for an
' episode ("series:<src>~<id>") and blank for a film.
'
' Re-marking something already marked keeps the ORIGINAL time. Finishing an
' episode twice is not new information, and refreshing the timestamp would
' quietly move it to the back of the eviction queue and push out a mark that
' really is older.
sub MarkSeen(key as string, parent = "" as string, atMs = invalid as dynamic)
    if not MarkSeenRaw(key, parent, atMs) then return
    TrimSeen()
end sub

' The same write WITHOUT holding the section to its caps, and saying whether
' it actually added anything.
'
' For the sync projector, which applies a whole feed in one go: TrimSeen
' walks the entire section, so trimming per row would do that work once per
' row instead of once per cycle. The projector calls this and trims itself,
' ONCE, at the end.
function MarkSeenRaw(key as string, parent = "" as string, atMs = invalid as dynamic) as boolean
    if key = "" then return false
    sec = CreateObject("roRegistrySection", "kwick_seen")
    if sec.exists(key) then return false
    at = atMs
    if at = invalid then at = CreateObject("roDateTime").asSeconds() * 1000&
    sec.write(key, seenValue(at, parent))
    sec.flush()
    return true
end function

' The stored value, built in one place so the reader and the writer cannot
' disagree about it. A parent carrying a bar would split the value in two
' when it is read back, so one is refused rather than stored — no id shape
' this app builds contains a bar, and a mark with no parent is merely less
' useful, while a mis-parsed one is wrong.
function seenValue(atMs as dynamic, parent as string) as string
    p = parent
    if Instr(1, p, "|") > 0 then p = ""
    return ToStr(atMs) + "|" + p
end function

' Take a mark off.
'
' "byMember" says WHO decided. It is true for the two screens that offer "Mark
' as unwatched" (MovieDetailScreen, SeriesDetailScreen) and false for the sync
' projector applying somebody else's unmark, and the difference is the whole
' safety of the push half — see the note above QueueSeenUnmark. Defaulting to
' true is deliberate: every existing caller IS a member pressing a button, and
' a caller added later that forgets the argument gets the honest answer rather
' than a silent one.
sub UnmarkSeen(key as string, byMember = true as boolean)
    if key = "" then return
    sec = CreateObject("roRegistrySection", "kwick_seen")
    if sec.exists(key)
        sec.delete(key)
        sec.flush()
        ' Queued only when there was really a mark to take off, so a stray
        ' unmark of something that was never marked cannot fill the queue.
        if byMember then QueueSeenUnmark(key)
    end if
end sub

' ---- "I have not actually watched this" — the outgoing unmark queue ----------
'
' THE ONLY THING THAT MAY EVER DELETE A FINISHED MARK ON ANOTHER DEVICE.
'
' The reason this queue exists rather than the obvious alternative is the whole
' F2 problem. KwickSync's reconciler decides a row was deleted by noticing it
' has gone MISSING from a device's snapshot — and this box's finished-marks
' store is capped (SeenMaxRows/SeenMaxBytes above) and quietly evicts its
' oldest marks, while the phone's is deliberately uncapped for exactly that
' reason (watched_items_repository.dart:168-177). So "missing from the Roku"
' means two completely different things — "the member unmarked it" and "this
' small box ran out of room" — and a protocol that cannot tell them apart
' would delete a member's oldest checkmarks off every device they own, every
' time this Roku evicted one.
'
' So absence is never a deletion here. A mark leaves the account only when the
' member SAYS SO, and this queue is that sentence, written down at the moment
' they press the button and carried until the next sync cycle can post it.
' Eviction (TrimSeen) deletes from the section directly and never comes
' through here, which is what makes the two distinguishable at all.
'
' Keys are this device's own registry keys ("<profile>|ep:<src>~<id>"); the
' sync cycle turns them into wire keys, because only it knows the profile's
' sync id. A key it cannot place is dropped rather than guessed at.
'
' SIZE: one key of 11-44 bytes plus JSON punctuation, capped at 64 entries and
' 2048 bytes — a few hundred bytes at worst, and normally empty, because a
' cycle drains it within 90 seconds. The cap is real rather than decorative:
' the registry is 16-32 KB for the whole app and a write past it fails
' SILENTLY, taking the member's providers with it. Overflow drops the OLDEST
' pending unmark and says so in the log; that costs a stale checkmark on
' another device, which is the smaller of the two failures by a long way.
function SeenUnmarkMaxRows() as integer
    return 64
end function

function SeenUnmarkMaxBytes() as integer
    return 2048
end function

function SeenUnmarkQueue() as object
    raw = RegRead("seen_unmark_q")
    if raw = "" then return []
    p = ParseJson(raw)
    if p = invalid then return []
    return ToArray(p)
end function

sub QueueSeenUnmark(key as string)
    if key = "" then return
    q = SeenUnmarkQueue()
    ' Unmarking the same thing twice before a cycle runs is one intention, not
    ' two, and a duplicate would only cost registry space.
    for each e in q
        if ToStr(e) = key then return
    end for
    q.push(key)
    ' +3 for the quotes and the comma each entry costs inside the JSON array.
    bytes = 0
    for each e in q
        bytes = bytes + Len(ToStr(e)) + 3
    end for
    dropped = 0
    while q.count() > 1 and (q.count() > SeenUnmarkMaxRows() or bytes > SeenUnmarkMaxBytes())
        bytes = bytes - (Len(ToStr(q[0])) + 3)
        q.shift()
        dropped = dropped + 1
    end while
    if dropped > 0
        ' Plain ASCII on purpose: this line ends up in uploaded member logs.
        KLog("store", "unmark queue full - dropped " + dropped.toStr() + " of the oldest, they will stay ticked on other devices")
    end if
    RegWrite("seen_unmark_q", FormatJson(q))
end sub

sub ClearSeenUnmarkQueue()
    if RegRead("seen_unmark_q") = "" then return
    RegDelete("seen_unmark_q")
end sub

function IsSeen(key as string) as boolean
    if key = "" then return false
    sec = CreateObject("roRegistrySection", "kwick_seen")
    return sec.exists(key)
end function

' { at, parent } for one mark, or invalid if it is not marked. "at" is handed
' back as the TEXT it was stored as — see the value note above; comparing two
' of them is a string comparison against equal-length millisecond stamps,
' which is what mediaBarIdxPut already does.
function LoadSeen(key as string) as dynamic
    if key = "" then return invalid
    sec = CreateObject("roRegistrySection", "kwick_seen")
    if not sec.exists(key) then return invalid
    return parseSeenValue(sec.read(key))
end function

function parseSeenValue(raw as string) as dynamic
    if raw = "" then return invalid
    at = raw
    parent = ""
    bar = Instr(1, raw, "|")
    if bar > 0
        at = Left(raw, bar - 1)
        parent = Mid(raw, bar + 1)
    end if
    if at = "" then return invalid
    return { at: at, parent: parent }
end function

' Every mark belonging to one profile, as
' { <full registry key>: { at, parent, key } }.
'
' For screens that ask about a whole list at once — a season of episodes is
' twenty questions, and twenty roRegistrySection reads on a screen build is
' twenty more than one walk. The keys handed back are the FULL keys, the same
' ones SeenKeyEpisode/SeenKeyMovie return, so a caller has exactly one way to
' name a mark and never has to know about the profile prefix.
function LoadSeenSet(profileId as string) as object
    out = {}
    prefix = SeenPrefixFor(profileId)
    sec = CreateObject("roRegistrySection", "kwick_seen")
    for each k in sec.getKeyList()
        ks = ToStr(k)
        mine = false
        if prefix = ""
            mine = (Instr(1, ks, "|") = 0)   ' default profile owns the bare keys
        else
            mine = (Len(ks) > Len(prefix) and ks.left(Len(prefix)) = prefix)
        end if
        if mine
            v = parseSeenValue(sec.read(ks))
            if v <> invalid
                ' The exact registry key goes in the VALUE as well as being
                ' the map key. A map built with {} is case-INSENSITIVE and
                ' hands its keys back folded, so anything that takes an id
                ' apart must read it from here — a Jellyfin guid or a host
                ' with a capital in it would otherwise come back lowercased
                ' and name nothing. (Looking a key UP stays case-insensitive,
                ' which is only ever helpful.)
                v.key = ks
                out[ks] = v
            end if
        end if
    end for
    return out
end function

' "<src>~<seriesId>" -> { count, at, epIds } for that show's finished
' episodes: how many are marked, the newest mark's time, and the
' source-qualified episode ids themselves.
'
' What Continue Watching and auto-play-next need to tell "kept up with this
' show" from "stopped watching it", WITHOUT an episode list and WITHOUT the
' network — the whole reason parent is stored on the mark. Films contribute
' nothing, having no parent.
function SeenSeriesIndex(profileId as string) as object
    idx = {}
    marks = LoadSeenSet(profileId)
    for each key in marks
        v = marks[key]
        parent = ToStr(v.parent)
        if parent.left(7) = "series:"
            ref = Mid(parent, 8)
            if ref <> ""
                ' The episode id as every other store here names it:
                ' source-qualified, with the "ep:" and the profile prefix off.
                ' Read off v.key, NOT the map key — see LoadSeenSet on case.
                bare = ToStr(v.key)
                bar = Instr(1, bare, "|")
                if bar > 0 then bare = Mid(bare, bar + 1)
                if bare.left(3) = "ep:"
                    epId = Mid(bare, 4)
                    row = idx[ref]
                    if row = invalid
                        idx[ref] = { count: 1, at: ToStr(v.at), epIds: [epId] }
                    else
                        row.count = row.count + 1
                        row.epIds.push(epId)
                        ' Newest wins, compared as text — see TrimSeen.
                        if ToStr(v.at) > ToStr(row.at) then row.at = ToStr(v.at)
                    end if
                end if
            end if
        end if
    end for
    return idx
end function

sub ClearSeenForProfile(profileId as string)
    clearProfileKeysIn("kwick_seen", profileId)
end sub

' How many marks this box holds, every profile counted. For the sync log,
' where "the mirror had 300 rows and we hold 4" is the difference between a
' working backfill and a broken one.
function SeenCount() as integer
    sec = CreateObject("roRegistrySection", "kwick_seen")
    return sec.getKeyList().count()
end function

' Hold the section to BOTH caps, oldest finished first out of the door.
'
' Walks the section, which is only worth doing on a write that actually added
' a row — MarkSeen returns early when the mark was already there, so this runs
' about once per title finished, not once per tick of the save timer.
'
' A row whose value will not parse is dropped first and for free: it can only
' have come from a half-finished write, and "unreadable" is not something to
' spend the member's registry on.
sub TrimSeen()
    sec = CreateObject("roRegistrySection", "kwick_seen")
    rows = []
    bytes = 0
    changed = false
    for each k in sec.getKeyList()
        ks = ToStr(k)
        raw = sec.read(ks)
        v = parseSeenValue(raw)
        if v = invalid
            sec.delete(ks)
            changed = true
        else
            rows.push({ key: ks, at: v.at, cost: Len(ks) + Len(raw) })
            bytes = bytes + Len(ks) + Len(raw)
        end if
    end for
    if rows.count() <= SeenMaxRows() and bytes <= SeenMaxBytes()
        if changed then sec.flush()
        return
    end if
    ' Oldest first. "at" is a millisecond stamp kept as text and never
    ' converted (it does not fit a 32-bit integer), so these are compared as
    ' strings — correct while the stamps are the same length, which they are
    ' for every date between 2001 and 2286.
    rows.sortBy("at")
    i = 0
    while (rows.count() - i) > SeenMaxRows() or bytes > SeenMaxBytes()
        if i >= rows.count() then exit while
        sec.delete(rows[i].key)
        bytes = bytes - rows[i].cost
        changed = true
        i = i + 1
    end while
    if changed then sec.flush()
    if i > 0 then KLog("store", "finished marks: dropped " + i.toStr() + " oldest to stay inside the registry budget")
end sub

' ---- Synced source colours ("srccol") ---------------------------------------
' The colour the member painted a source WITH ON THEIR PHONE.
'
' Set Kwick Jelly to purple on the phone and it should be purple on the TV.
' That is the whole feature. This box already paints every source a colour of
' its own (SrcPalette/SrcColorIndex in Theme.brs, a hash of the source token),
' which is a decent guess and nobody's choice; when the member has actually
' made a choice, theirs wins and the hash is the fallback.
'
' PULL ONLY. Nothing here ever goes on the wire. There is no picker on this
' box, so this device has no opinion to push — and a device with no opinion
' that spoke anyway is exactly how the reconciler is made to delete things.
' See the note in SyncTask.rebuildSrcColors for what a picker would have to
' add before that could change.
'
' WHAT SYNCS IS AN INDEX, NOT A COLOUR — the phone's own ruling
' (source_color_sync_types.dart, "THE COLOUR IS AN INDEX, NOT A COLOUR"). It
' names a swatch in the shared six-colour palette, and each device renders
' that swatch in the way its own screen needs. That is why what is stored here
' is a small integer and the hex values never leave this file.
'
' KEYED BY SOURCE TOKEN, with the same "t" prefix the cards use for their own
' memo — the KwickTV source's token is the empty string, and "t" turns it into
' an ordinary associative-array key like any other rather than a special case
' every reader has to remember.

' The six swatches, in the SAME ORDER as the profile palette, because that is
' what makes index 5 mean the same colour on the phone and here. Android's
' `sourceColorPalette` IS its `profileColors` (source_color.dart:23) and
' ProfilePalette() in Theme.brs is that same list already ported, so the
' "mark" column below is those exact values and nothing new was invented.
'
' The "bg" column is derived rather than picked, and it has a job: it is the
' plate behind the WHITE text on a card's corner tag, so it has to sit in the
' same luminance band the hashed palette holds itself to (see SrcPalette in
' Theme.brs — 0.087 to 0.105, about 7:1 against white). Each one is its
' swatch's own hue scaled down until it lands there, so the colour is
' recognisably the one the member picked and the tag stays readable:
'
'   idx 0 #2086FF -> #1556A5   7.23:1        idx 3 #FFB74D -> #705122   7.27:1
'   idx 1 #4FC3F7 -> #255D75   7.24:1        idx 4 #E57373 -> #864444   7.18:1
'   idx 2 #81C784 -> #3D5E3F   7.31:1        idx 5 #BA68C8 -> #774380   7.24:1
'
' Alpha E6 on the plate and FF on the mark, matching SrcPalette exactly, so a
' painted source and a hashed one sit at the same weight on the artwork.
'
' The marks are LEFT AT FULL STRENGTH, unlike the hashed palette which pulls
' every swatch into a narrow band so that "no source looks louder than
' another". That rule is about colours this app handed out on its own and had
' no business making one of them shout. These are the member's own choices,
' and dimming somebody's chosen yellow to match a green they never picked
' would be answering a question they already answered.
function SyncedSrcPalette() as object
    pal = []
    pal.push({ bg: "0x1556A5E6", mark: "0x2086FFFF" })   ' 0  blue
    pal.push({ bg: "0x255D75E6", mark: "0x4FC3F7FF" })   ' 1  light blue
    pal.push({ bg: "0x3D5E3FE6", mark: "0x81C784FF" })   ' 2  green
    pal.push({ bg: "0x705122E6", mark: "0xFFB74DFF" })   ' 3  amber
    pal.push({ bg: "0x864444E6", mark: "0xE57373FF" })   ' 4  red
    pal.push({ bg: "0x774380E6", mark: "0xBA68C8FF" })   ' 5  purple
    return pal
end function

' What the KwickTV source is called on the srccol wire.
'
' Every other sync kind spells "this is the KwickTV login's" by leaving the
' src field OUT of the payload. That trick is not available to a kind whose
' whole payload IS the source, and a blank token is the one shape that could
' corrupt an account — so the phone reserves a name for it instead
' (source_color_sync_types.dart:108, kKwickTvSourceToken). It cannot collide
' with a real token because every one of those has a colon in it.
function KwickTvSrcWireToken() as string
    return "kwicktv"
end function

' The local memo key for a source token — "t" + the token, so the KwickTV
' source's empty-string token is an ordinary key. The cards build the same
' string (srcDotColor in PosterCard.brs / ChannelCard.brs) and look this map
' up with it, which is why it is built in one place.
function SrcColorMemoKey(token as string) as string
    return "t" + token
end function

' "t<token>" -> palette index, for the sources THIS box actually has. Rebuilt
' from the sync mirror once per cycle; see SyncTask.rebuildSrcColors.
function LoadSyncedSrcColors() as object
    raw = RegRead("src_colors")
    if raw = "" then return {}
    p = ParseJson(raw)
    if p = invalid then return {}
    if type(p) <> "roAssociativeArray" then return {}
    return p
end function

' Write the map, and say whether it actually changed.
'
' The comparison is not thrift for its own sake. This runs every cycle, i.e.
' every 90 seconds for as long as the box is on, and a registry write that
' stores the identical bytes is still a flash write and still a chance for the
' whole section to fail; the honest answer nearly every time is "nothing
' changed", so that is the cheap path.
'
' SIZE: one entry is the token plus a single digit — `"txt:panel.example.com":3`
' is 25 bytes, the KwickTV one (`"t":0`) is 6. A member with four sources
' costs well under 150 bytes all in. It is capped anyway, at 32 sources, for
' the same reason everything else here is: a write past the app's 16-32 KB
' registry budget fails silently and takes whatever else was mid-write with
' it. Nobody has 32 playlists; the cap is there so that "nobody does" never
' has to be true.
function SaveSyncedSrcColors(map as object) as boolean
    kept = {}
    n = 0
    for each k in map
        if n >= 32 then exit for
        kept[k] = ToInt(map[k])
        n = n + 1
    end for
    out = ""
    if kept.count() > 0 then out = FormatJson(kept)
    if out = RegRead("src_colors") then return false
    if out = ""
        RegDelete("src_colors")
    else
        RegWrite("src_colors", out)
    end if
    return true
end function

' Publish the resolved colours where a recycling card can reach them.
'
' CARDS MUST NOT READ THE REGISTRY. A registry read per tile while a grid
' recycles under a held-down arrow key is "a visible stutter on a stick" (see
' RefreshFavVodIndex above), so the answer is worked out once, here, and left
' on the global node as a plain map of token -> { bg, mark } that costs the
' card one associative-array hit at bind time and nothing else. The card also
' watches this field, so a colour that arrives mid-scroll repaints the tiles
' already on screen instead of waiting for the next screen build.
'
' The field is only SET, never created — same guard RefreshFavVodIndex uses,
' and for a stronger reason here: this is called from the sync task's thread
' as well as the render thread, and creating fields on the global node is the
' render thread's job. The cards create it themselves at init if nobody has
' yet (the "first one in makes it" arrangement they already use for
' resumeVodIndex), so by the time there is anything on screen to paint, there
' is a field to publish into.
sub RefreshSrcColorIndex()
    if m.global = invalid or not m.global.hasField("srcColorIdx") then return
    pal = SyncedSrcPalette()
    idx = {}
    stored = LoadSyncedSrcColors()
    for each k in stored
        i = ToInt(stored[k])
        if i >= 0 then idx[k] = pal[i mod pal.count()]
    end for
    m.global.srcColorIdx = idx
end sub

' ---- Recently watched (channels) -------------------------------------------

function LoadRecentChannels() as object
    raw = RegRead(RecentChannelsKey())
    if raw = "" then return []
    parsed = ParseJson(raw)
    if parsed = invalid then return []
    ' Drop entries with no playable identity — early builds saved a few
    ' with empty stream ids, and playing one asks the panel for nothing.
    cleaned = []
    dirty = false
    for each r in ToArray(parsed)
        if ToStr(r.streamId) <> "" or ToStr(r.url) <> ""
            cleaned.push(r)
        else
            dirty = true
        end if
    end for
    kept = pruneStaleRecents(cleaned, RecentChannelsMaxAgeDays())
    if dirty or kept.count() <> cleaned.count() then RegWrite(RecentChannelsKey(), FormatJson(kept))
    return kept
end function

' ---- Recently watched (movies & series) -------------------------------------
' Feeds the Kwick Picks recommendations. Per-profile. Items:
' { kind: "movie"|"series", id, name, icon, ext }, most-recent-first, cap 30.

function RecentVodKey() as string
    return "recent_vod" + ProfileScopeSuffix()
end function

function LoadRecentVod() as object
    raw = RegRead(RecentVodKey())
    if raw = "" then return []
    p = ParseJson(raw)
    if p = invalid then return []
    all = ToArray(p)
    kept = pruneStaleRecents(all, RecentVodMaxAgeDays())
    kept = dedupeRecents(kept)
    if kept.count() <> all.count() then RegWrite(RecentVodKey(), FormatJson(kept))
    return kept
end function

' The SAME title can sit on two configured sources - the KwickTV login (src "")
' and a separate Xtream source that is really the same panel (e.g.
' src "xt:www.kwick.cc") share the provider's id space - so Continue Watching
' showed one film twice: "Minions & Monsters" id 847733 under both. PushRecentVod
' only dedupes within a source (SrcMatches), so cross-source doubles survive.
' Collapse rows that are the same kind + id + name, keeping the FIRST (recents are
' newest-first, so that is the most recent play). A genuinely different title that
' only happens to share a numeric id on another panel keeps its own row, because
' its name differs.
'
' A MEDIA SERVER'S ROWS ARE EXEMPT, and keep their source in the key. Two
' Xtream sources really can be the same panel, which is the whole reason this
' function exists; a member's Jellyfin or Emby never is. Without the exemption
' an Emby film and an IPTV film could be folded into one row and the member
' would lose one of them from Continue Watching — Emby item ids are plain
' decimal numbers ("722685", measured on a real 4.9.5 server), not the GUIDs
' Jellyfin uses, so they sit in exactly the same id space as an Xtream stream
' id and a same-named film on both would collide. Whichever row came second
' would simply vanish, and it would be the one that still played.
function dedupeRecents(list as object) as object
    seen = {}
    out = []
    for each r in list
        rsrc = ToStr(GetField(r, "src"))
        k = LCase(ToStr(GetField(r, "kind"))) + "|" + ToStr(GetField(r, "id")) + "|" + LCase(ToStr(GetField(r, "name")).trim())
        if IsMediaSrcToken(rsrc) then k = rsrc + "|" + k
        if not seen.doesExist(k)
            seen[k] = true
            out.push(r)
        end if
    end for
    return out
end function

' Recents are tagged with their source and capped per source (30) — one
' source's viewing must never push another's recents off the list. Home
' shows them all mixed (merged lineup), each routing by its own src.
sub PushRecentVod(item as object)
    if ToStr(item.id) = "" then return
    token = ItemSrcToken(item)
    if token <> "" then item.src = token
    item.d = TodayDayNumber()
    ' A caller may hand us a backdrop (the two detail screens do, off the
    ' get_vod_info / get_series_info answer they already had). Fold it to the
    ' short stored form here rather than trusting whatever came in — see the
    ' backdrop block below.
    if item.doesExist("bd")
        bd = NormalizeBackdrop(ToStr(item.bd))
        if bd = "" then item.delete("bd") else item.bd = bd
    end if
    recents = LoadRecentVod()
    kept = [item]
    own = 1
    for each r in recents
        same = SrcMatches(r, token) and ToStr(r.kind) = ToStr(item.kind) and ToStr(r.id) = ToStr(item.id)
        if same
            ' The row being replaced may already know this title's backdrop
            ' (its page was opened once) while this press does not — playing
            ' the same film again from a Home tile carries no artwork with it.
            ' Inherit rather than forget: losing it would blank the Media Bar's
            ' picture for a title the member just watched, which reads as a bug.
            if ToStr(GetField(item, "bd")) = ""
                was = ToStr(GetField(r, "bd"))
                if was <> "" then item.bd = was
            end if
        else
            if SrcMatches(r, token)
                if own < 30
                    kept.push(r)
                    own = own + 1
                end if
            else
                kept.push(r)   ' another source's recents aren't ours to trim
            end if
        end if
    end for
    ' ...but the registry is (16-32KB for the whole app, writes past it fail
    ' silently), so the list as a whole is still capped: oldest off the end,
    ' whichever source they came from.
    while kept.count() > 60
        kept.pop()
    end while
    trimRecentBackdrops(kept)
    RegWrite(RecentVodKey(), FormatJson(kept))
end sub

' ---- Backdrops (the Media Bar's artwork) ------------------------------------
'
' THE PROBLEM. The Media Bar draws a 1690x330 strip — five to one — and the
' only artwork a recents row has ever carried is the PORTRAIT poster, roughly
' two to three. It has been faking a backdrop out of that poster by smearing it
' across the bar and drawing it again on the right, and it looks like what it
' is: a stretched poster.
'
' THE FACT THAT FIXES IT. Xtream panels DO return a backdrop. `get_vod_info`
' and `get_series_info` both carry `backdrop_path`, and the phone has read it
' since day one (xtream_models.dart:352 and :412, via firstBackdrop). This app
' never captured it. It costs NO NEW REQUEST to start: both detail screens
' already make that call when a member opens a title, and the field is sitting
' unread in the answer they get back.
'
' It must stay that way. The panel rotates through up to twenty titles, so a
' lookup per rotation is one request every ten seconds — the exact shape of the
' loop that got this house's provider access banned on 2026-08-14. Nothing in
' here reaches the network. A title HAS a backdrop because its page was opened
' at some point, or it does not have one and the bar falls back to the poster.
'
' ---- WHAT IS STORED, AND WHAT IT COSTS --------------------------------------
' The registry is 16-32 KB for the WHOLE app and a write past the limit fails
' SILENTLY, taking whatever else was mid-write with it. A url per recents row
' is not free, so two things are done about it.
'
' FIRST, the url is folded to its shortest honest form. Panels hand these out
' as TMDB addresses, and a TMDB address is a fixed host, a size the app picks
' for itself anyway, and one file name:
'
'     https://image.tmdb.org/t/p/w1280/9xE7uEpUZLuqIsyOroDJOAtOnaS.jpg   67
'                                     /9xE7uEpUZLuqIsyOroDJOAtOnaS.jpg   32
'
' so only the tail is kept and BackdropUrl() puts the rest back at the size the
' Media Bar actually decodes. In the recents JSON that is
' `,"bd":"/9xE7uEpUZLuqIsyOroDJOAtOnaS.jpg"` = 42 BYTES PER ROW. A panel that
' hosts its own stills instead is kept whole, capped at 80 characters — beyond
' that the row simply gets no backdrop, because at some length a nicer picture
' stops being worth the risk of a silent failed write somewhere else.
'
' SECOND, there is a hard ceiling on the lot of them regardless: 1200 bytes,
' spent newest-first, and every row past it has its backdrop dropped (the
' picture, not the row). At the 42 bytes above that is about twenty-eight rows
' — comfortably more than the twenty the panel can show — and at the 90-byte
' worst case about thirteen. Either way the total is bounded at ~1.2 KB and
' cannot creep.
'
' Sixty rows carrying a full url with no ceiling would have been 4 KB or more,
' which on a 16 KB box is a quarter of everything the app owns.

function TmdbImageHost() as string
    return "image.tmdb.org/t/p/"
end function

' Longest foreign url worth a registry slot. See the note above.
function BackdropMaxLen() as integer
    return 80
end function

' Total bytes all the stored backdrops may occupy between them.
function BackdropByteBudget() as integer
    return 1200
end function

' The panel's answer -> the short stored form, or "" for anything unusable.
'
'   ".../t/p/<size>/<file>"  ->  "/<file>"    (rebuilt by BackdropUrl)
'   "/<file>"                ->  "/<file>"    (the raw TMDB field's own shape)
'   "http://somewhere/x.jpg" ->  kept whole if it is short enough
'
' The leading slash is what tells the two apart on the way back out, which is
' why a foreign url without a scheme is refused rather than guessed at.
function NormalizeBackdrop(url as string) as string
    u = url.trim()
    if u = "" then return ""
    ' A MEDIA SERVER'S BACKDROP IS STORED AS TWO CHARACTERS. The address is
    ' about 130 characters long - host, item id, "Images/Backdrop/0", a size
    ' and a tag - which is past BackdropMaxLen() and would burn a tenth of the
    ' whole byte budget on one row. But every part of it is already on the row
    ' it belongs to: the server is the row's src, the item is the row's id, and
    ' the size is the reader's choice. So "ms" is stored, meaning "this row's
    ' own server has one", and RecentBackdropUrl() rebuilds the address from
    ' the row when the Media Bar comes to draw it. Nothing else in the registry
    ' knows or cares.
    if Instr(1, u, "/Items/") > 0 and Instr(1, u, "/Images/Backdrop") > 0 then return "ms"
    at = Instr(1, u, TmdbImageHost())
    if at > 0
        rest = Mid(u, at + Len(TmdbImageHost()))   ' "w1280/9xE7...jpg"
        slash = Instr(1, rest, "/")
        if slash = 0 then return ""
        path = Mid(rest, slash)                    ' "/9xE7...jpg"
        if Len(path) < 2 or Len(path) > BackdropMaxLen() then return ""
        return path
    end if
    if Left(u, 1) = "/"
        if Instr(1, u, "://") > 0 then return ""
        if Len(u) > BackdropMaxLen() then return ""
        return u
    end if
    if Instr(1, u, "://") = 0 then return ""
    if Len(u) > BackdropMaxLen() then return ""
    return u
end function

' A RECENTS ROW's backdrop -> something a Poster can load. This is the one
' readers of a stored row should call, because a media server's backdrop is
' stored as the marker "ms" (see NormalizeBackdrop) and only the row can say
' which server and which title that means. Everything else falls through to
' BackdropUrl below, unchanged.
'
' No tag on the rebuilt address. The tag is a cache-buster the server puts on
' its own urls, and without it the server simply serves the title's current
' backdrop - measured on both Jellyfin and Emby. A member who replaces a
' backdrop sees the new one; nobody sees a stale one.
function RecentBackdropUrl(rec as dynamic, size = "w500" as string) as string
    bd = ToStr(GetField(rec, "bd"))
    if bd <> "ms" then return BackdropUrl(bd, size)
    p = ProviderForSrcToken(ToStr(GetField(rec, "src")))
    if p = invalid then return ""
    id = ToStr(GetField(rec, "id"))
    if id = "" then return ""
    width = 500
    if size = "w1280" then width = 1280
    return MsImageUrl(p, id, "Backdrop", "", width)
end function

' The stored form -> something a Poster can load.
'
' THE SIZE IS THE CALLER'S CHOICE, and it has to be: this rebuilds a url for
' whatever box is going to draw it, and the two callers draw at wildly
' different sizes. It defaults to w500 so the Media Bar — which is what this
' was written for and was its only caller — is unchanged.
'
'   w500 (default), the Media Bar. It decodes at 360 pixels wide (MediaBar.xml
'        states the arithmetic), so anything past 500 is bytes off the wire the
'        decoder throws away again, and this is fetched fresh on EVERY
'        ROTATION.
'   w1280, the film page's hero (MovieDetailScreen). That draws 1920 wide, so
'        w500 would be a 3.8x upscale — soft enough to look broken on a
'        television. w1280 is the size the panels themselves quote, so it is
'        certainly served, and it is fetched ONCE PER PAGE OPEN rather than per
'        rotation, which is what makes the extra bytes affordable there.
'
' Anything that is not a leading-slash TMDB fragment is a foreign url the panel
' hosts itself and passes through whole, at whatever size its host chose. That
' rule lives here, in ONE place, which is the reason a caller that wants a
' different size should pass one rather than build the url itself.
function BackdropUrl(stored as string, size = "w500" as string) as string
    s = stored.trim()
    if s = "" then return ""
    if Left(s, 1) = "/" then return "https://" + TmdbImageHost() + size + s
    return s
end function

' Android's firstBackdrop (xtream_models.dart:427-430). `backdrop_path` is an
' ARRAY of urls on most panels and a bare string on a few, and either can hold
' blanks — so the first USABLE one wins rather than the first one.
function BackdropFromInfo(info as dynamic) as string
    raw = GetField(info, "backdrop_path")
    if raw = invalid then return ""
    if type(raw) = "roArray"
        for each v in raw
            s = NormalizeBackdrop(ToStr(v))
            if s <> "" then return s
        end for
        return ""
    end if
    return NormalizeBackdrop(ToStr(raw))
end function

' Stamp a backdrop onto a recents row that ALREADY EXISTS, in place.
'
' Deliberately not PushRecentVod: opening a page is not watching something, and
' pushing would shove the title to the front of Continue Watching for a member
' who only wandered past it. Nothing is created either — a title the member has
' never played has no row to decorate and does not get one.
'
' Returns whether anything was written, and writes NOTHING when the row already
' held this exact backdrop. That matters: this runs every time a detail page's
' details land, which is every time a page is opened, and a registry write on
' each of those would be a write per page view for no change at all.
function AttachRecentBackdrop(kind as string, id as string, srcToken as dynamic, backdrop as string) as boolean
    if id = "" then return false
    bd = NormalizeBackdrop(backdrop)
    if bd = "" then return false
    ' Resolved exactly the way PushRecentVod resolves it, so the row this finds
    ' is the row that press would have replaced: the item's own source when it
    ' has one ("" IS KwickTV's), else the active one.
    probe = {}
    if srcToken <> invalid then probe.src = ToStr(srcToken)
    token = ItemSrcToken(probe)

    rows = LoadRecentVod()
    changed = false
    hits = []
    for each r in rows
        if ToStr(r.kind) = kind and ToStr(r.id) = id and SrcMatches(r, token)
            hits.push(r)
            if ToStr(GetField(r, "bd")) <> bd
                r.bd = bd
                changed = true
            end if
        end if
    end for
    if not changed then return false

    ' The budget is spent newest-first, so a row far enough down the list can
    ' have the backdrop taken straight back off it again. Writing then would
    ' store nothing new AND do it once per page view for the rest of time,
    ' which is exactly the write-per-open this sub exists to avoid. So the trim
    ' runs first and the write only happens if it survived.
    trimRecentBackdrops(rows)
    kept = false
    for each r in hits
        if ToStr(GetField(r, "bd")) = bd then kept = true
    end for
    if not kept then return false

    RegWrite(RecentVodKey(), FormatJson(rows))
    return true
end function

' The ceiling described above, applied newest-first. Rows keep their place and
' their poster; only the backdrop is dropped.
sub trimRecentBackdrops(rows as object)
    spent = 0
    budget = BackdropByteBudget()
    for each r in rows
        bd = ToStr(GetField(r, "bd"))
        if bd <> ""
            ' The field as it lands in the JSON: `,"bd":"..."` is ten
            ' characters of scaffolding around the value.
            cost = Len(bd) + 10
            if spent + cost > budget
                r.delete("bd")
            else
                spent = spent + cost
            end if
        end if
    end for
end sub

' Most-recent-first, capped at 20 per source — mirrors the Android recents
' rows. Entries without a playable identity are dropped (early builds saved
' a few broken ones).
sub PushRecentChannel(channel as object)
    if ToStr(channel.streamId) = "" and ToStr(channel.url) = "" then return
    token = ItemSrcToken(channel)
    if token <> "" then channel.src = token
    channel.d = TodayDayNumber()
    recents = LoadRecentChannels()
    kept = [channel]
    own = 1
    for each r in recents
        if ToStr(r.streamId) = "" and ToStr(r.url) = "" then goodEntry = false else goodEntry = true
        if goodEntry
            same = SrcMatches(r, token) and ToStr(r.streamId) = ToStr(channel.streamId)
            if not same
                if SrcMatches(r, token)
                    if own < 20
                        kept.push(r)
                        own = own + 1
                    end if
                else
                    kept.push(r)
                end if
            end if
        end if
    end for
    ' Overall bound too — see PushRecentVod on the registry quota.
    while kept.count() > 40
        kept.pop()
    end while
    RegWrite(RecentChannelsKey(), FormatJson(kept))
end sub

' ---- How long recently-watched rows are kept --------------------------------
' The Roku has always had FIXED caps — forty channels, sixty films and shows,
' oldest off the end — and nothing else. The phone lets a member choose in
' days instead (settings_screen.dart, _RetentionTile), and this is the same
' choice under the phone's own two key names, so it travels over KwickSync and
' means the same thing at both ends.
'
' The caps do not go away. They are what keeps the registry inside its budget
' when somebody picks Forever, and a member who watches forty channels in a
' week still gets the oldest dropped whatever the day count says. The two
' rules stack: a row goes when it is too old OR when it has been pushed off
' the end, whichever happens first.
'
' 0 IS FOREVER, exactly as on the phone. Defaults match the phone too — thirty
' days for channels, sixty for films and shows — which for this box is a
' registry SAVING rather than a cost: rows that used to sit there until forty
' newer ones arrived now go once they are a month old.
'
' WHAT IT COSTS: one "d" per stored row. Days since 1970, five digits, so
' `,"d":20325` is eleven bytes — at the existing caps (forty channels, sixty
' titles) a hundred rows is about 1.1 KB at the very most, and less than that
' for anyone whose retention actually bites. It is days and not a timestamp on
' purpose: the setting is in days, so anything finer would be paying for
' precision nothing reads.
'
' ROWS SAVED BEFORE THIS EXISTED have no "d" and are never aged out. Their age
' is genuinely not known, and throwing away a member's history on a guess is
' the one outcome that cannot be undone.

function RetentionChoices() as object
    return [0, 1, 3, 7, 14, 30, 60]
end function

function RecentChannelsMaxAgeDays() as integer
    return retentionPref("pref_recent_channels_max_age_days", 30)
end function

sub SetRecentChannelsMaxAgeDays(n as integer)
    RegWrite("pref_recent_channels_max_age_days" + ProfileScopeSuffix(), n.toStr())
end sub

function RecentVodMaxAgeDays() as integer
    return retentionPref("pref_recent_vod_max_age_days", 60)
end function

sub SetRecentVodMaxAgeDays(n as integer)
    RegWrite("pref_recent_vod_max_age_days" + ProfileScopeSuffix(), n.toStr())
end sub

' Same shape as mediaBarIntPref: a value neither picker can produce falls back
' to the default rather than being trusted, and BuildPsetMap applies the same
' test so it can never reach the wire either.
function retentionPref(key as string, dflt as integer) as integer
    raw = RegRead(key + ProfileScopeSuffix())
    if raw = "" then return dflt
    n = raw.toInt()
    for each c in RetentionChoices()
        if c = n then return n
    end for
    return dflt
end function

' Whole days since 1970. Five digits until the year 2243.
function TodayDayNumber() as integer
    return Int(CreateObject("roDateTime").asSeconds() / 86400)
end function

function RetentionLabel(days as integer) as string
    if days = 0 then return "Forever"
    if days = 1 then return "1 day"
    if days = 7 then return "1 week"
    if days = 14 then return "2 weeks"
    if days = 30 then return "1 month"
    if days = 60 then return "2 months"
    return days.toStr() + " days"
end function

' Drop rows older than maxDays. 0 keeps everything; a row with no day stamp is
' from before this existed and is kept.
function pruneStaleRecents(rows as object, maxDays as integer) as object
    if maxDays <= 0 then return rows
    cutoff = TodayDayNumber() - maxDays
    out = []
    for each r in rows
        d = GetField(r, "d")
        if d = invalid
            out.push(r)
        else if ToInt(d) >= cutoff
            out.push(r)
        end if
    end for
    return out
end function

' ---- Watch history (the whole list, and clearing part of it) ----------------
' The Roku had no way to LOOK at a watch history — one Settings row wiped the
' lot and that was the entire feature. The phone has a screen listing what was
' watched, with a cross on each row and a separate clear for channels, films
' and shows (watch_history_screen.dart, settings_screen.dart).
'
' Nothing new is stored for any of this. The rows are assembled from what the
' player and the recents lists already write down:
'
'   films & shows   the kwick_hist section, which the player fills in beside
'                   every resume point (title, poster, kind, and "at" in
'                   milliseconds). One row per title, newest first.
'   channels        the recent_channels list, which is already in the order it
'                   should be shown in and carries no clock of its own beyond
'                   the day stamp above.
'
' A row's `key` is its resume key, so removing one is ClearResume — which
' takes the resume point and the history row together, which is what a member
' pressing a cross on a title means.

' The "<profileId>|" that keys in the per-content sections carry for one
' profile (blank for the default profile, which owns the bare legacy keys).
function historyKeyPrefix(profileId as string) as string
    if profileId = "default" or profileId = "" then return ""
    return profileId + "|"
end function

' Does this section key belong to the named profile?
function historyKeyIsMine(ks as string, prefix as string) as boolean
    if prefix = "" then return (Instr(1, ks, "|") = 0)
    return (Len(ks) >= Len(prefix) and ks.left(Len(prefix)) = prefix)
end function

' Every film and show the active profile has watched, newest first:
' [{ key, kind ("movie"|"episode"), title, sub, poster, atMs, positionS,
'    durationS }].
'
' Sorted with a plain insertion sort, and that is a deliberate choice rather
' than laziness: the list is bounded by what the registry can hold — a few
' dozen rows at the very most, because kwick_hist shares the same 16-32 KB as
' everything else — so the simple sort that cannot get an index wrong is worth
' more here than one that would be quicker on data this section can never hold.
function LoadWatchHistory() as object
    prefix = historyKeyPrefix(ActiveProfileId())
    sec = CreateObject("roRegistrySection", "kwick_hist")
    rows = []
    for each k in sec.getKeyList()
        ks = ToStr(k)
        if historyKeyIsMine(ks, prefix)
            meta = ParseJson(sec.read(ks))
            if meta <> invalid
                ' "at" is milliseconds and does NOT fit in the 32-bit integer
                ' ToInt() returns — the same trap mediaBarIdxPut carries. It
                ' is kept EXACTLY as ParseJson handed it over and never
                ' converted; the sort below only ever compares one against
                ' another, and the screen divides by a thousand at the last
                ' moment to get a seconds figure roDateTime will take.
                atMs = GetField(meta, "at")
                kind = ToStr(GetField(meta, "kind"))
                if kind = "" then kind = "movie"
                ' Not `pos` — that is a reserved BrightScript word and naming
                ' a variable after one fails to compile on the device.
                posS = 0
                dur = 0
                r = LoadResume(ks)
                if r <> invalid
                    posS = r.positionS
                    dur = r.durationS
                end if
                rows.push({
                    key: ks
                    kind: kind
                    title: ToStr(GetField(meta, "title"))
                    sub: ToStr(GetField(meta, "sub"))
                    poster: ToStr(GetField(meta, "poster"))
                    atMs: atMs
                    positionS: posS
                    durationS: dur
                })
            end if
        end if
    end for
    for i = 1 to rows.count() - 1
        cur = rows[i]
        j = i - 1
        while j >= 0 and histNewer(cur.atMs, rows[j].atMs)
            rows[j + 1] = rows[j]
            j = j - 1
        end while
        rows[j + 1] = cur
    end for
    return rows
end function

' Is `a` more recent than `b`? A row with no clock at all (written before the
' player started stamping them) sorts to the bottom rather than the top —
' claiming an unknown date is today would put the oldest rows in the app at
' the front of the list.
function histNewer(a as dynamic, b as dynamic) as boolean
    if a = invalid then return false
    if b = invalid then return true
    return a > b
end function

' Just how many rows there are, for the Settings row that says so. Counting
' keys, not building rows: LoadWatchHistory parses a JSON value and reads a
' resume point for every row, and the Settings list rebuilds itself every time
' anything on it is pressed.
function WatchHistoryCount() as integer
    prefix = historyKeyPrefix(ActiveProfileId())
    sec = CreateObject("roRegistrySection", "kwick_hist")
    n = 0
    for each k in sec.getKeyList()
        if historyKeyIsMine(ToStr(k), prefix) then n = n + 1
    end for
    return n
end function

' Remove one film or show from the history. Its resume point goes with it —
' the two are the same row as far as a member is concerned.
sub RemoveWatchHistoryRow(key as string)
    ClearResume(key)
end sub

' Remove one channel from the recently-watched channels list.
sub RemoveRecentChannel(streamId as string, token as string)
    kept = []
    for each r in LoadRecentChannels()
        if ToStr(r.streamId) = streamId and SrcMatches(r, token)
            ' dropped
        else
            kept.push(r)
        end if
    end for
    RegWrite(RecentChannelsKey(), FormatJson(kept))
end sub

' Clear one KIND of history for the active profile, the way the phone's three
' separate rows do. kind is "live" | "movie" | "episode".
'
'   live      the recently-watched channels list, and nothing else — a channel
'             has no resume point to lose.
'   movie     every "movie:" resume point and history row, plus the films out
'             of Kwick Picks' recents list.
'   episode   every "ep:" resume point and history row, plus the shows out of
'             the recents list. Episodes are held there as their SERIES (see
'             PushRecentVod's callers), so "series" is what comes out.
'
' Finished marks are deliberately left alone. "I have seen this" is a
' different fact from "this is in my history", and clearing the list should
' not make a show start offering episodes the member has already watched.
sub ClearHistoryKind(kind as string)
    if kind = "live"
        ClearRecentChannels()
        KLog("store", "watch history: cleared channels")
        return
    end if
    idPrefix = "movie:"
    recentKind = "movie"
    if kind = "episode"
        idPrefix = "ep:"
        recentKind = "series"
    end if
    prefix = historyKeyPrefix(ActiveProfileId())
    for each section in ["kwick_resume", "kwick_hist"]
        sec = CreateObject("roRegistrySection", section)
        changed = false
        for each k in sec.getKeyList()
            ks = ToStr(k)
            if historyKeyIsMine(ks, prefix)
                tail = Mid(ks, Len(prefix) + 1)
                if tail.left(Len(idPrefix)) = idPrefix
                    sec.delete(ks)
                    changed = true
                end if
            end if
        end for
        if changed then sec.flush()
    end for
    kept = []
    for each r in LoadRecentVod()
        if ToStr(r.kind) <> recentKind then kept.push(r)
    end for
    RegWrite(RecentVodKey(), FormatJson(kept))
    KLog("store", "watch history: cleared " + recentKind)
end sub

' ---- Home rows: one row or two ----------------------------------------------
' The phone can fold its two Recently Watched rows into one, and its two
' Favorites rows into one (settings_screen.dart). Both are stored under the
' phone's own key names and both are plain switches at both ends, so a member
' who folds them on one device finds them folded on the other.
'
' CONFIRMED BEFORE CLAIMING THE NAMES, because a shared key with a different
' encoding is worse than no sharing at all — the two devices would hand the
' setting back and forth forever. On the Android side both are declared
' PrefKind.boolean in profile_settings.dart (lines 39-40, the pset descriptor
' list KwickSync reads and writes), stored through BoolPreference defaulting
' to false (user_preferences.dart:165-168), and the writer takes the value
' only `if (v is bool)`. That is a real JSON boolean in the blob, which is
' exactly what psetScalarMap's "bool" kind puts there and reads back, and
' false is exactly the default below. Nothing to translate; the names are the
' real ones.
'
' NEITHER SWITCH MERGES ANYTHING ON ITS OWN. Home builds its rows in
' HomeScreen.refresh, which this file does not own — see the report.

function MergeRecentsRow() as boolean
    return GetPrefBool("pref_merge_recently_watched", false)
end function

sub SetMergeRecentsRow(v as boolean)
    SetPrefBool("pref_merge_recently_watched", v)
end sub

function MergeFavoritesRow() as boolean
    return GetPrefBool("pref_merge_favorites", false)
end function

sub SetMergeFavoritesRow(v as boolean)
    SetPrefBool("pref_merge_favorites", v)
end sub

' ---- Home row order ---------------------------------------------------------
' The order the rows UNDER the Media Bar are drawn in, as the member chose it.
' Mason, 2026-09-16: "on the home -> everything under the media bar we need to
' be able to re-order this how we want to."
'
' WHAT IT COSTS. One key per profile, "pref_home_row_order" (19 bytes) plus a
' JSON list of ids. All ten ids this build draws is 179 bytes; with Android's
' three extra ids riding along (below) the worst real value is 211. The value
' is HARD CAPPED at 512 bytes in both directions — SaveHomeRowOrder drops the
' ids it did not draw rather than write past it, and psetScalarMap's "max"
' refuses an over-long value arriving from another device. So the ceiling is
' ~531 bytes per profile, and the DEFAULT COSTS NOTHING AT ALL: nothing is
' written until the member actually moves a row. The registry is 16-32 KB for
' the whole app and a write past the end fails silently, which is why this
' paragraph exists.
'
' THE VALUE IS ANDROID'S, EXACTLY. Key "pref_home_row_order", a JSON list of
' HomeRow.id strings, "[]" meaning "the app's own order" — preference_constants
' .dart:178-185 and home_row_order.dart. It travels on the wire under that same
' real Android name: confirmed before claiming it, not assumed. Android declares
' it PrefKind.string in ProfileSettings.all (profile_settings.dart:68), its
' reader is store.getString and its writer takes the value only `if (v is
' String)` — so the JSON TEXT is the wire value, a quoted string, which is what
' psetScalarMap's "str" kind sends and reads. A bare JSON array would be
' dropped at the far end, re-pushed as a string by the phone, overwritten as an
' array by us, and the two devices would hand the setting back and forth every
' cycle forever.

function HomeRowOrderKey() as string
    return "pref_home_row_order" + ProfileScopeSuffix()
end function

' Every row THIS BUILD can draw under the Media Bar, in Android's own
' declaration order — which IS the default order (home_row_order.dart:34-85).
' The ids are Android's and never change; the labels are the titles HOME
' ACTUALLY DRAWS on this box, which is not always Android's label:
'
'   * "recentVod" is "Recently Watched VOD" on the phone and has always been
'     "Continue Watching" here (see the naming note in HomeScreen.refresh).
'   * "favoriteMovies" is one of two rows on the phone; this box has a single
'     combined "Favorite Movies & Series" row built from LoadFavoriteVod(), so
'     the combined row takes that slot and "favoriteSeries" is carried but
'     never drawn.
'
' A screen for rearranging rows has to name the rows the member can see.
'
' NOT HERE ON PURPOSE: Android's "tmdbWatchlist" and "tmdbFavorites", because
' this box has no way to sign in to TMDB — a row you can focus and press that
' then does nothing is the trap the settings screens spent a long time
' removing. They are still PRESERVED in what gets saved; see SaveHomeRowOrder.
function HomeRowDefs() as object
    return [
        { rid: "recentChannels", label: "Recently Watched Channels", hint: "" }
        { rid: "recentVod", label: "Continue Watching", hint: "Films and shows you are partway through" }
        { rid: "recentMerged", label: "Recently Watched", hint: "Channels and VOD together in one row" }
        { rid: "kwickPicks", label: "Kwick Picks", hint: "Recommendations based on your recent movies & shows" }
        { rid: "traktWatchlist", label: "Your Trakt watchlist", hint: "" }
        { rid: "simklWatchlist", label: "Your Simkl watchlist", hint: "" }
        { rid: "favoriteChannels", label: "Favorite Channels", hint: "" }
        { rid: "favoriteMovies", label: "Favorite Movies & Series", hint: "" }
        { rid: "favoritesMerged", label: "Favorites", hint: "Channels, movies and series together in one row" }
        { rid: "favoriteLists", label: "Your lists", hint: "One row for each favorite list with its Home row on" }
    ]
end function

function homeRowKnown(rid as string) as boolean
    for each d in HomeRowDefs()
        if d.rid = rid then return true
    end for
    return false
end function

function homeRowIndexOf(ids as object, rid as string) as integer
    for i = 0 to ids.count() - 1
        if ToStr(ids[i]) = rid then return i
    end for
    return -1
end function

' BrightScript arrays have no insert-at (the same reason moveInArray rebuilds
' rather than shuffles), so this rebuilds. Out of range goes on the end.
function homeRowInsertAt(ids as object, at as integer, rid as string) as object
    dest = at
    if dest < 0 or dest > ids.count() then dest = ids.count()
    outIds = []
    for i = 0 to ids.count()
        if i = dest then outIds.push(rid)
        if i < ids.count() then outIds.push(ToStr(ids[i]))
    end for
    return outIds
end function

' The stored ids, tolerantly. Anything that is not a JSON list of strings —
' an empty key, hand-edited sync payload, an object, junk — means "nothing
' stored", which is Android's own rule (decodeHomeRowOrder). A repeated id
' counts once.
function LoadHomeRowOrder() as object
    raw = RegRead(HomeRowOrderKey())
    if raw = "" then return []
    parsed = ParseJson(raw)
    if parsed = invalid then return []
    if not isArrayType(parsed) then return []
    ids = []
    seen = {}
    seen.setModeCaseSensitive()
    for each e in parsed
        t = type(e)
        if t = "roString" or t = "String"
            s = ToStr(e)
            if s <> "" and not seen.doesExist(s)
                seen[s] = true
                ids.push(s)
            end if
        end if
    end for
    return ids
end function

' The finished order: the stored ids this build knows, in their stored order,
' then every row the stored list does not mention slotted in BESIDE THE
' NEIGHBOUR IT HAS BY DEFAULT — directly under the row in front of it in
' HomeRowDefs(), wherever the member has put that one.
'
' A straight port of Android's resolveHomeRowOrder (home_row_order.dart:101-123,
' pinned by its own tests), and the reason it is a port rather than an
' approximation is that the two devices have to agree the first time either of
' them gains a row. A row added in a later build lands where its neighbours
' are, NEVER on the bottom of a list somebody has carefully arranged. An id
' this build does not know is ignored here (it is still saved — see below).
function ResolveHomeRowOrder(stored as object) as object
    defs = HomeRowDefs()
    outIds = []
    for each s in stored
        sid = ToStr(s)
        if homeRowKnown(sid) and homeRowIndexOf(outIds, sid) < 0 then outIds.push(sid)
    end for
    for i = 0 to defs.count() - 1
        rid = defs[i].rid
        if homeRowIndexOf(outIds, rid) < 0
            at = -1
            ' The rows in front of this one have all been placed by now (this
            ' loop walks the defaults in order), so the nearest one above is
            ' simply the previous default — unless this is the very first row
            ' of all, which goes directly above the nearest row that follows
            ' it by default.
            if i > 0 then at = homeRowIndexOf(outIds, defs[i - 1].rid) + 1
            j = i + 1
            while j < defs.count() and at < 0
                k = homeRowIndexOf(outIds, defs[j].rid)
                if k >= 0 then at = k
                j = j + 1
            end while
            outIds = homeRowInsertAt(outIds, at, rid)
        end if
    end for
    return outIds
end function

' What Home builds from and what the order screen draws. Always every row this
' build knows, in the member's order.
function HomeRowOrderIds() as object
    return ResolveHomeRowOrder(LoadHomeRowOrder())
end function

' Write a new order.
'
' THE IDS THIS BUILD DOES NOT DRAW ARE PUT BACK. Android's two TMDB rows and
' its separate Favorite Series row are real rows on the member's phone; if the
' television wrote only what it draws, saving here would delete the phone's
' placement for those three every single time. So each one is re-inserted
' directly after the nearest id in front of it in the STORED order that this
' build does draw — which also keeps a run of them (tmdbWatchlist then
' tmdbFavorites) in their own order, and keeps favoriteSeries next to
' favoriteMovies wherever the combined row is moved to.
'
' AND IT CAPS ITSELF. If carrying them would take the value past 512 bytes
' they are dropped and only the drawn ids are written, because a silent
' registry overflow damages the member's real data and a lost placement on
' another device does not — Android's own resolve puts a missing row back
' beside its neighbours.
sub SaveHomeRowOrder(ids as object)
    drawn = []
    for each x in ids
        s = ToStr(x)
        if homeRowKnown(s) and homeRowIndexOf(drawn, s) < 0 then drawn.push(s)
    end for
    outIds = []
    for each d in drawn
        outIds.push(d)
    end for
    anchor = ""
    for each s in LoadHomeRowOrder()
        sid = ToStr(s)
        if homeRowKnown(sid)
            anchor = sid
        else
            if homeRowIndexOf(outIds, sid) < 0
                at = 0
                if anchor <> ""
                    ai = homeRowIndexOf(outIds, anchor)
                    if ai >= 0 then at = ai + 1
                end if
                outIds = homeRowInsertAt(outIds, at, sid)
            end if
            anchor = sid
        end if
    end for
    json = FormatJson(outIds)
    if Len(json) > 512
        json = FormatJson(drawn)
        KLog("store", "home row order: over 512B, saved without the ids this build does not draw")
    end if
    RegWrite(HomeRowOrderKey(), json)
end sub

' Move one row up or down by one place. `fromIdx` and `toIdx` index the list
' the member is looking at, which is HomeRowOrderIds(); out of range is a
' no-op, the same as every other move in this file.
sub MoveHomeRowTo(fromIdx as integer, toIdx as integer)
    SaveHomeRowOrder(moveInArray(HomeRowOrderIds(), fromIdx, toIdx))
end sub

' Back to the app's own order.
'
' THE SENTINEL "[]" IS WRITTEN, NOT THE KEY DELETED, and not a copy of today's
' default either. Two reasons, both learned the hard way elsewhere in this
' file. A copy of today's default freezes a member on a list that a later build
' has changed. And a DELETED key does not travel: BuildPsetMap starts from the
' last synced blob and only overlays keys that are actually set, so deleting
' would leave the old order in the blob to be pushed back at us forever. 21
' bytes buys a reset that reaches the member's other devices. Android does
' exactly this (home_row_order_screen.dart:132).
sub ResetHomeRowOrder()
    RegWrite(HomeRowOrderKey(), "[]")
end sub

' Why this row is not going to be drawn, in the member's own words, or "" when
' it will be. Android's strings (homeRowHiddenReasons, home_row_order.dart:161)
' with three differences, all forced by this box rather than chosen:
'
'   * the quoted names are ROKU'S switch labels where they differ in case from
'     the phone's, because the sentence is pointing at a switch on THIS screen;
'   * "Show Favorites" is off has no Android counterpart — that master switch
'     is Roku-only (roku_show_favorites on the wire);
'   * the lists row says "its Home row" because "Show on Home" is what the
'     PHONE calls that switch; here it reads "Row ON" / "Row OFF".
'
' HIDDEN IS A SETTING, NEVER AN EMPTY ROW. No favourites yet is not a reason:
' that row appears the moment there is something to put in it.
function HomeRowHiddenReason(rid as string) as string
    q = Chr(34)
    if rid = "recentChannels" or rid = "recentVod" or rid = "recentMerged"
        if not GetPrefBool("pref_show_recents", true) then return q + "Show Recently Watched" + q + " is off"
        if MergeRecentsRow()
            if rid <> "recentMerged" then return "Merged into the " + q + "Recently Watched" + q + " row"
        else
            if rid = "recentMerged" then return "Only shown when " + q + "Merge Recently Watched into one row" + q + " is on"
        end if
        return ""
    end if
    if rid = "kwickPicks"
        if not GetPrefBool("pref_show_picks", true) then return "Show " + q + "Kwick Picks" + q + " is off"
        return ""
    end if
    if rid = "traktWatchlist" or rid = "simklWatchlist"
        svc = "trakt"
        who = "Trakt"
        if rid = "simklWatchlist"
            svc = "simkl"
            who = "Simkl"
        end if
        if not AddOnSignedIn(svc) then return "Not signed in to " + who
        if not WatchlistRowOn(svc) then return q + "Show my " + who + " watchlist" + q + " is off"
        return ""
    end if
    if rid = "favoriteChannels" or rid = "favoriteMovies" or rid = "favoritesMerged"
        if not GetPrefBool("pref_show_favorites", true) then return q + "Show Favorites" + q + " is off"
        if MergeFavoritesRow()
            if rid <> "favoritesMerged" then return "Merged into the " + q + "Favorites" + q + " row"
        else
            if rid = "favoritesMerged" then return "Only shown when " + q + "Merge Favorites into one row" + q + " is on"
        end if
        return ""
    end if
    if rid = "favoriteLists"
        for each l in LoadLists()
            if l.homeRow = true then return ""
        end for
        return "No list has its Home row turned on"
    end if
    return ""
end function

' ---- Media Bar (the Continue Watching panel at the top of Home) -------------
' The Roku half of Android's ContinueWatchingSpotlight. Four settings, per
' profile, under ANDROID'S OWN KEY NAMES so a choice made on either device
' means exactly the same thing when it travels over KwickSync.

function MediaBarEnabled() as boolean
    return GetPrefBool("pref_media_bar_enabled", true)
end function

sub SetMediaBarEnabled(v as boolean)
    SetPrefBool("pref_media_bar_enabled", v)
end sub

' The four numbers both pickers offer, and nothing else. Anything outside
' this set is treated as unset — see mediaBarIntPref below.
function MediaBarChoices() as object
    return [5, 10, 15, 20]
end function

function MediaBarCount() as integer
    return mediaBarIntPref("pref_media_bar_count", 5)
end function

sub SetMediaBarCount(n as integer)
    RegWrite("pref_media_bar_count" + ProfileScopeSuffix(), n.toStr())
end sub

function MediaBarSeconds() as integer
    return mediaBarIntPref("pref_media_bar_seconds", 10)
end function

sub SetMediaBarSeconds(n as integer)
    RegWrite("pref_media_bar_seconds" + ProfileScopeSuffix(), n.toStr())
end sub

function MediaBarContentChoices() as object
    return ["both", "movies", "series"]
end function

function MediaBarContent() as string
    raw = RegRead("pref_media_bar_content" + ProfileScopeSuffix())
    for each c in MediaBarContentChoices()
        if raw = c then return raw
    end for
    return "both"
end function

sub SetMediaBarContent(v as string)
    RegWrite("pref_media_bar_content" + ProfileScopeSuffix(), v)
end sub

' Is the device running short of memory right now?
'
' The same coarse check XmltvTask uses (MemoryTight, XmltvTask.brs:264-267)
' and MultiViewRules copies as MvMemoryTight. It is duplicated rather than
' shared because that one lives inside a Task component and is not in scope
' anywhere else; giving it the same name here would be a second definition
' in every component that loads both.
function MediaBarMemoryTight() as boolean
    lvl = LCase(ToStr(CreateObject("roDeviceInfo").GetGeneralMemoryLevel()))
    return lvl = "low" or lvl = "critical"
end function

' A whole-number preference held to the known choices. A value the pickers
' can't produce (an older build, something odd off the wire) falls back to
' the default rather than being trusted — and, because BuildPsetMap applies
' the same test, can never be put onto the sync wire either.
function mediaBarIntPref(key as string, dflt as integer) as integer
    raw = RegRead(key + ProfileScopeSuffix())
    if raw = "" then return dflt
    n = raw.toInt()
    for each c in MediaBarChoices()
        if n = c then return n
    end for
    return dflt
end function

' Everything still worth continuing, newest first — the Roku port of
' ContinueWatchingSpotlight.pickAll.
'
' Each row comes back as
'   { kind, id, name, icon, ext, src, bd, pos, dur, sub, epId, finished }
' where pos/dur/sub/epId describe the EPISODE a show is up to (blank for a
' film, which is its own progress), and `bd` is the landscape backdrop in its
' short stored form — "" for every title whose page has not been opened since
' backdrops started being kept (see the backdrop block above PushRecentVod).
'
' A FILM needs a live resume point to appear here. Android works "finished"
' out from the stored position; this app throws a film's resume point away
' the moment it passes 95% (see SaveResume), so on the Roku "has no resume
' point" already IS "finished, or never really started" — and neither is
' something to continue. An EPISODE is kept either way, exactly as Android
' keeps it: once you finish an episode the SHOW is what comes next, which is
' the whole point of the panel.
'
' Nothing in here touches the network. Every lookup is a registry read of
' something this app already holds.
function MediaBarEntries() as object
    maxN = MediaBarCount()
    content = MediaBarContent()
    out = []
    epIndex = invalid
    for each v in LoadRecentVod()
        if out.count() < maxN
            kind = ToStr(v.kind)
            series = (kind = "series")
            take = true
            ' Settings > Home screen > Media Bar > Show. Somebody who only
            ' ever finishes films does not want half the panel to be
            ' episodes, and the reverse.
            if content = "movies" and series then take = false
            if content = "series" and not series then take = false
            if take
                id = ToStr(v.id)
                src = ToStr(GetField(v, "src"))
                e = {
                    kind: kind
                    id: id
                    name: ToStr(v.name)
                    icon: ToStr(v.icon)
                    ext: ToStr(v.ext)
                    src: src
                    ' The landscape artwork, in its short stored form, or "".
                    ' Carried straight off the recents row — the panel's whole
                    ' rule is that it never asks anyone for anything, and this
                    ' is a field that was already read.
                    bd: ToStr(GetField(v, "bd"))
                    pos: 0
                    dur: 0
                    sub: ""
                    epId: ""
                    finished: false
                }
                if series
                    if epIndex = invalid then epIndex = MediaBarEpisodeIndex()
                    ep = epIndex[SrcQualifiedId(id, src)]
                    if ep <> invalid
                        e.pos = ToInt(ep.pos)
                        e.dur = ToInt(ep.dur)
                        e.sub = ToStr(ep.sub)
                        e.epId = ToStr(ep.epId)
                        e.finished = (e.dur > 0 and e.pos >= Int(e.dur * 0.95))
                    end if
                    out.push(e)
                else
                    r = LoadResume(ResumeKeyMovie(id, src))
                    if r <> invalid
                        e.pos = r.positionS
                        e.dur = r.durationS
                        out.push(e)
                    end if
                end if
            end if
        end if
    end for
    return out
end function

' "<src>~<seriesId>" -> the episode this profile is up to on that show:
' { epId, sub, pos, dur, at }. epId is source-qualified, like every other
' media id here.
'
' Two places already know this, and NEITHER IS A REQUEST:
'   kwick_hist   what the player wrote for episodes watched ON THIS ROKU.
'   sync_mirror  the blob KwickSync last pulled, which carries the phone's
'                watch-history rows (parent, "S01E13", position, duration).
'
' The mirror earns its place: a position pulled from another device writes a
' resume point but deliberately never writes a kwick_hist row (SyncTask
' keeps it that way so pulled rows can't churn back out). Without it, a show
' watched on the phone would sit on Home with no progress bar and no episode
' number — the one case this panel exists for.
'
' READS NOTHING OFF THE NETWORK, and that is not an optimisation. Asking a
' panel which episode a show is up to, per tile, on every Home build, is the
' loop that got this house's address banned on 2026-08-14.
function MediaBarEpisodeIndex() as object
    idx = {}
    profileId = ActiveProfileId()
    prefix = ""
    if profileId <> "default" and profileId <> "" then prefix = profileId + "|"

    ' 1. Episodes watched on this Roku.
    hsec = CreateObject("roRegistrySection", "kwick_hist")
    rsec = CreateObject("roRegistrySection", "kwick_resume")
    for each hk in hsec.getKeyList()
        hks = ToStr(hk)
        mine = false
        if prefix = ""
            mine = (Instr(1, hks, "|") = 0)
        else
            mine = (Len(hks) >= Len(prefix) and hks.left(Len(prefix)) = prefix)
        end if
        if mine
            bare = Mid(hks, Len(prefix) + 1)
            ' The KEY, not meta.kind: saveProgress() decides "episode" from
            ' a resume key that still has the profile prefix on it, so on a
            ' second profile every row calls itself a movie.
            if bare.left(3) = "ep:"
                meta = ParseJson(hsec.read(hks))
                if meta <> invalid
                    parent = ToStr(GetField(meta, "parent"))
                    if parent.left(7) = "series:"
                        posS = 0
                        dur = 0
                        if rsec.exists(hks)
                            rp = rsec.read(hks).split("|")
                            if rp.count() >= 2
                                posS = ToInt(rp[0])
                                dur = ToInt(rp[1])
                            end if
                        end if
                        mediaBarIdxPut(idx, Mid(parent, 8), {
                            epId: Mid(bare, 4)
                            sub: ToStr(GetField(meta, "sub"))
                            pos: posS
                            dur: dur
                            at: GetField(meta, "at")
                        })
                    end if
                end if
            end if
        end if
    end for

    ' 2. Episodes watched on another device. Skipped when the box is already
    ' short of memory: the mirror is one big blob and parsing it is the most
    ' expensive thing on this path, while all it adds is a nicer label.
    if MediaBarMemoryTight() then return idx
    sid = ""
    for each p in LoadProfiles()
        if ToStr(p.id) = profileId then sid = ToStr(p.syncId)
    end for
    if sid = "" then return idx
    pfx = "hist:" + sid + ":episode:"
    mirror = LoadSyncMirror()
    for each key in mirror
        ks = ToStr(key)
        if Len(ks) > Len(pfx) and ks.left(Len(pfx)) = pfx
            row = mirror[key]
            if row <> invalid and row.deleted <> true and ToStr(row.data) <> ""
                d = ParseJson(ToStr(row.data))
                if d <> invalid
                    parent = ToStr(GetField(d, "parent"))
                    if parent.left(7) = "series:"
                        mediaBarIdxPut(idx, Mid(parent, 8), {
                            epId: Mid(ks, Len(pfx) + 1)
                            sub: ToStr(GetField(d, "sub"))
                            pos: ToInt(GetField(d, "pos"))
                            dur: ToInt(GetField(d, "dur"))
                            at: GetField(d, "at")
                        })
                    end if
                end if
            end if
        end if
    end for
    return idx
end function

' Newest wins. "at" is milliseconds since 1970, which does NOT fit in the
' 32-bit integer ToInt() hands back — so it is compared exactly as it
' arrived and never converted.
sub mediaBarIdxPut(idx as object, seriesRef as string, row as object)
    if seriesRef = "" then return
    if ToStr(row.epId) = "" then return
    ex = idx[seriesRef]
    if ex = invalid
        idx[seriesRef] = row
    else if row.at <> invalid and (ex.at = invalid or row.at > ex.at)
        idx[seriesRef] = row
    end if
end sub

' 1..99. A 0% or 100% "continue watching" is a contradiction, and rounding
' alone produces both at the edges. Returns -1 when there is no duration to
' work from — providers do not always report one.
function MediaBarPercent(posS as integer, dur as integer) as integer
    if dur <= 0 then return -1
    p = Int((posS * 100.0 / dur) + 0.5)
    if p < 1 then p = 1
    if p > 99 then p = 99
    return p
end function

' "52% watched  (S01E13)" — the episode code rides along with the progress
' rather than owning a row of its own. A film has no episode and an
' unmeasured title has no percentage, so a row for each would move the
' buttons below every time the panel rotated between the two.
function MediaBarProgressLabel(pct as integer, subText as string) as string
    ep = subText.trim()
    if pct < 0 then return ep
    if ep = "" then return pct.toStr() + "% watched"
    return pct.toStr() + "% watched  (" + ep + ")"
end function

' ---- Per-profile settings sync (pset, T7 phase 2) ---------------------------
' Translates between the Roku's per-profile registry keys and the Android
' app's pset blob (one flat map per profile, key "pset:<profileSyncId>").
' Shared settings use Android's exact pref_* names and values; Roku-only
' ones ride under a roku_ prefix and Android round-trips them untouched.
' Category lists travel by NAME (the portable form) via a device-level
' id->name cache refreshed whenever a screen loads categories; hidden
' channels travel as xt:<host>:<streamId>.

' Shared scalars: Roku registry key base <-> Android pset key. kind:
' "bool" | "str" | "sort" (default<->provider) | "mode" (hide|pin) |
' "int" | "choice". The last two carry a `choices` list and refuse anything
' that isn't on it, in BOTH directions — see psetChoiceOk below.
function psetScalarMap() as object
    return [
        { reg: "pref_start_muted", pk: "pref_start_playback_muted", kind: "bool" }
        { reg: "pref_captions_auto", pk: "pref_subtitles_enabled", kind: "bool" }
        { reg: "pref_show_recents", pk: "pref_show_recently_watched", kind: "bool" }
        { reg: "pref_show_picks", pk: "pref_show_because_you_watched", kind: "bool" }
        { reg: "pref_show_favorites", pk: "roku_show_favorites", kind: "bool" }
        { reg: "pref_channel_sort", pk: "pref_channel_sort", kind: "sort" }
        { reg: "parental_mode", pk: "pref_parental_lock_mode", kind: "mode" }
        { reg: "pref_caption_lang", pk: "roku_caption_lang", kind: "str" }
        ' Media Bar (the Continue Watching panel at the top of Home). Same
        ' four settings the phone has, under the phone's own key names.
        '
        ' The two numbers MUST travel as real JSON numbers, not as "10" in
        ' quotes: Android's writer takes an integer setting only when the
        ' value `is num` and silently drops anything else. A quoted one would
        ' be ignored there, re-pushed as a number by the phone, overwritten
        ' as a string by us, and the two devices would hand the same setting
        ' back and forth on every cycle forever. That is what kind "int" is
        ' for, and why both directions also refuse a value that isn't one of
        ' the four the pickers offer.
        { reg: "pref_media_bar_enabled", pk: "pref_media_bar_enabled", kind: "bool" }
        { reg: "pref_media_bar_count", pk: "pref_media_bar_count", kind: "int", choices: [5, 10, 15, 20] }
        { reg: "pref_media_bar_seconds", pk: "pref_media_bar_seconds", kind: "int", choices: [5, 10, 15, 20] }
        { reg: "pref_media_bar_content", pk: "pref_media_bar_content", kind: "choice", choices: ["both", "movies", "series"] }
        ' Home rows: one row or two. Both names are the phone's real ones and
        ' both are checked, not assumed — see the note above MergeRecentsRow
        ' for the evidence (profile_settings.dart declares both
        ' PrefKind.boolean and its writer takes them only `if (v is bool)`,
        ' which is precisely what kind "bool" writes and reads here).
        { reg: "pref_merge_recently_watched", pk: "pref_merge_recently_watched", kind: "bool" }
        { reg: "pref_merge_favorites", pk: "pref_merge_favorites", kind: "bool" }
        ' How long recently-watched rows are kept, in days, 0 meaning forever.
        ' Declared PrefKind.integer on the phone and written there only when
        ' the value `is num`, so these travel as REAL JSON numbers for the
        ' same reason the two Media Bar numbers above do — a quoted one would
        ' be ignored at the far end and re-pushed on every cycle forever. The
        ' choice list is the phone's own dropdown, refused in both directions.
        { reg: "pref_recent_channels_max_age_days", pk: "pref_recent_channels_max_age_days", kind: "int", choices: [0, 1, 3, 7, 14, 30, 60] }
        { reg: "pref_recent_vod_max_age_days", pk: "pref_recent_vod_max_age_days", kind: "int", choices: [0, 1, 3, 7, 14, 30, 60] }
        ' JB-10, how long the player's controls stay up. The registry name is
        ' this app's own; the WIRE name is Android's real one, and claiming a
        ' real pref_ name was checked before it was claimed rather than assumed
        ' — Android's `pref_controls_hide_seconds` is declared
        ' PrefKind.integer in ProfileSettings.all (profile_settings.dart:27),
        ' its writer takes the value only `if (v is num)` (the same file's
        ' write()), and its three choices are 5 / 10 / 15 with 5 as the
        ' fallback (playback/controls_timeout.dart). So it is kind "int": a
        ' REAL JSON number, never a quoted one. A quoted "10" would be dropped
        ' at the far end, re-pushed as a number by the phone, overwritten as a
        ' string by us, and the two devices would hand the same setting back
        ' and forth every cycle forever.
        { reg: "pref_controls_timeout", pk: "pref_controls_hide_seconds", kind: "int", choices: [5, 10, 15] }
        ' The order the rows under the Media Bar are drawn in. Android's real
        ' key name, claimed only after checking: it is declared PrefKind.string
        ' in ProfileSettings.all (profile_settings.dart:68), read with
        ' store.getString and written only `if (v is String)`. So the JSON TEXT
        ' travels as a STRING — '["kwickPicks","recentMerged"]' in quotes — and
        ' kind "str" is exactly that. Sending a bare JSON array instead would
        ' be dropped at the far end, re-pushed as a string by the phone,
        ' overwritten as an array by us, and the two devices would hand the
        ' setting back and forth on every cycle forever.
        '
        ' `max` is the only capped string on this map and the reason is the
        ' registry: this is a value another device composes, the whole app
        ' shares 16-32 KB, and a write past the end fails silently. 512 bytes
        ' is more than double the 211 a full order costs. See HomeRowOrderKey.
        { reg: "pref_home_row_order", pk: "pref_home_row_order", kind: "str", max: 512 }
    ]
end function

' Is this value one of the choices the map row allows? A row with no
' `choices` list allows anything. Used on the way OUT (nothing unknown gets
' onto the wire) and on the way IN (nothing unknown gets written to the
' registry), so a value neither app can produce simply never travels.
function psetChoiceOk(e as object, v as dynamic) as boolean
    if not e.doesExist("choices") then return true
    for each c in e.choices
        if ToStr(c) = ToStr(v) then return true
    end for
    return false
end function

' Category lists: which registry list maps to which pset key. Movies/series
' hide + all locks are shared with Android; live-hide and the VOD orders
' have no Android counterpart yet, so they ride under roku_ names.
function psetListMap() as object
    return [
        { scope: "live", what: "order", pk: "pref_category_order" }
        { scope: "movies", what: "order", pk: "roku_vod_category_order" }
        { scope: "series", what: "order", pk: "roku_series_category_order" }
        { scope: "live", what: "hidden", pk: "roku_hidden_live_categories" }
        { scope: "movies", what: "hidden", pk: "pref_hidden_vod_categories" }
        { scope: "series", what: "hidden", pk: "pref_hidden_series_categories" }
        { scope: "live", what: "locked", pk: "pref_locked_live_categories" }
        { scope: "movies", what: "locked", pk: "pref_locked_vod_categories" }
        { scope: "series", what: "locked", pk: "pref_locked_series_categories" }
    ]
end function

' Since the merged lineup, local category prefs are name-keyed under the
' "all" namespace — the same portable form the wire uses, so pset list
' translation is now a pass-through. (provId kept in the signature for the
' call sites' sake; it no longer picks the key.)
function psetCatRegKey(what as string, scope as string, provId as string, suffix as string) as string
    return "cat_" + what + "_" + scope + "_all" + suffix
end function

' Cache one scope's {id: name} so the sync engine can translate category
' ids to portable names without the catalog loaded. Device-level (the
' catalog is the same for every profile). Called from ApplyCatPrefs, which
' every screen funnels its freshly loaded category list through.
sub SaveCatNameCache(scope as string, cats as object)
    SaveCatNameCacheFor(scope, ActiveProviderId(), cats)
end sub

' Called wherever ONE source's categories are fetched (the merged screens
' fetch per source) — keeps each provider's id->name cache warm for the
' legacy-pref translation and Kwick Picks' name->id lookups.
sub SaveCatNameCacheFor(scope as string, provId as string, cats as object)
    if provId = "" then return
    nameMap = {}
    for each c in cats
        cid = ToStr(c.id)
        if cid <> "" then nameMap[cid] = ToStr(c.name)
    end for
    if nameMap.count() > 0 then RegWrite("cat_names_" + scope + "_" + provId, FormatJson(nameMap))
end sub

function loadCatNameCache(scope as string, provId as string) as object
    raw = RegRead("cat_names_" + scope + "_" + provId)
    if raw = "" then return {}
    parsed = ParseJson(raw)
    if parsed = invalid then return {}
    return parsed
end function

function catIdToName(cache as object, cid as string) as string
    if cache.doesExist(cid) then return ToStr(cache[cid])
    if not isAllDigits(cid) then return cid   ' M3U groups: the id IS the name
    return ""
end function

function catNameToId(cache as object, nm as string) as string
    for each k in cache
        if LCase(ToStr(cache[k])) = LCase(nm) then return ToStr(k)
    end for
    return ""
end function

function isAllDigits(txt as string) as boolean
    if txt = "" then return false
    for i = 1 to Len(txt)
        ch = Mid(txt, i, 1)
        if ch < "0" or ch > "9" then return false
    end for
    return true
end function

function isArrayType(v as dynamic) as boolean
    t = type(v)
    return (t = "roArray" or t = "roList")
end function

' ISO 639-1 -> the 639-2 codes the Roku uses, for applying the phone's
' preferred-subtitle-language (confirmed: Android stores 2-letter codes).
function langTo3(code as string) as string
    c = LCase(code)
    if Len(c) = 3 then return c
    two = { en: "eng", es: "spa", fr: "fre", de: "ger", it: "ita", pt: "por", ru: "rus", ar: "ara", zh: "chi", ja: "jpn", ko: "kor", hi: "hin", nl: "dut", pl: "pol", tr: "tur", sv: "swe", da: "dan", fi: "fin", el: "gre", he: "heb", cs: "cze", hu: "hun", ro: "rum", th: "tha", vi: "vie", uk: "ukr" }
    if two.doesExist(c) then return ToStr(two[c])
    return ""
end function

' Reverse map, restricted to the ten languages Android's picker offers —
' only those are pushed into the shared key; anything else stays Roku-only
' under roku_caption_lang.
function langTo2Android(code as string) as string
    three = { eng: "en", spa: "es", fre: "fr", ger: "de", ita: "it", por: "pt", dut: "nl", swe: "sv", ara: "ar", tur: "tr" }
    c = LCase(code)
    if three.doesExist(c) then return ToStr(three[c])
    return ""
end function

' Build one profile's pset "s" map: start from the last synced blob (base)
' so keys other platforms own survive, then overlay every locally-set
' setting. Unset locals never materialize (matches Android: defaults are
' never in the blob).
function BuildPsetMap(profileId as string, baseS as dynamic) as object
    s = {}
    ' Type guard: PHP's JSON round-trip turns an empty {} into [] — treat
    ' anything that isn't a real map as an empty base.
    if baseS <> invalid and type(baseS) = "roAssociativeArray"
        for each k in baseS
            s[k] = baseS[k]
        end for
    end if
    suffix = ProfileSuffixFor(profileId)
    for each e in psetScalarMap()
        raw = RegRead(e.reg + suffix)
        if raw <> ""
            if e.kind = "bool"
                s[e.pk] = (raw = "1")
            else if e.kind = "sort"
                if raw = "default" then s[e.pk] = "provider" else s[e.pk] = raw
            else if e.kind = "int"
                ' A NUMBER on the wire, not a quoted one — see the note on
                ' psetScalarMap. Bracket assignment, so the key keeps its
                ' exact case.
                n = raw.toInt()
                if psetChoiceOk(e, n) then s[e.pk] = n
            else if e.kind = "choice"
                if psetChoiceOk(e, raw) then s[e.pk] = raw
            else
                s[e.pk] = raw
            end if
        end if
    end for
    ' Preferred subtitle language: the Roku's 3-letter value rides under
    ' roku_caption_lang (in the map above); when it maps to one of the ten
    ' 2-letter values Android's picker offers, the shared key travels too.
    rawLang = RegRead("pref_caption_lang" + suffix)
    if rawLang <> ""
        two = langTo2Android(rawLang)
        if two <> "" then s["pref_preferred_subtitle_language"] = two
    end if
    prov = KwickTvProvider()
    if prov = invalid then return s
    provId = ToStr(prov.id)
    host = HostOf(ToStr(prov.server))
    ' Category lists are stored BY NAME (the wire's portable form) since
    ' the merged lineup — they travel as-is. Base names this device can't
    ' resolve to a known category are still preserved, never dropped
    ' (another device's categories are not this device's to delete).
    for each e in psetListMap()
        keyRaw = RegRead(psetCatRegKey(e.what, e.scope, provId, suffix))
        localNames = catPrefRead(e.what, e.scope, suffix)
        if keyRaw <> "" or localNames.count() > 0
            names = []
            seen = {}
            for each nm in localNames
                nms = ToStr(nm)
                if nms <> "" and not seen.doesExist(LCase(nms))
                    names.push(nms)
                    seen[LCase(nms)] = true
                end if
            end for
            if s.doesExist(e.pk) and isArrayType(s[e.pk])
                cache = loadCatNameCache(e.scope, provId)
                for each bn in s[e.pk]
                    bns = ToStr(bn)
                    if catNameToId(cache, bns) = "" and not seen.doesExist(LCase(bns))
                        names.push(bns)
                        seen[LCase(bns)] = true
                    end if
                end for
            end if
            s[e.pk] = names
        end if
    end for
    ' Hidden channels: local streamIds -> portable xt: ids; other hosts'
    ' entries in the base are preserved.
    rawHidden = RegRead("chan_hidden_" + provId + suffix)
    if rawHidden <> "" and host <> ""
        outIds = []
        seenIds = {}
        localIds = ParseJson(rawHidden)
        if localIds <> invalid
            for each cid in localIds
                wireId = "xt:" + host + ":" + ToStr(cid)
                if not seenIds.doesExist(wireId)
                    outIds.push(wireId)
                    seenIds[wireId] = true
                end if
            end for
        end if
        if s.doesExist("pref_hidden_channel_ids") and isArrayType(s["pref_hidden_channel_ids"])
            pfx = "xt:" + host + ":"
            for each bh in s["pref_hidden_channel_ids"]
                bhs = ToStr(bh)
                if bhs.left(Len(pfx)) <> pfx and not seenIds.doesExist(bhs)
                    outIds.push(bhs)
                    seenIds[bhs] = true
                end if
            end for
        end if
        s["pref_hidden_channel_ids"] = outIds
    end if
    return s
end function

' Apply an incoming pset blob to one profile's registry. Only keys the Roku
' understands are written (type-checked, Android-style); everything else
' just rides along in the blob. Returns true when category names could not
' be resolved yet (cold cache) so the sync engine retries next cycle.
function ApplyPsetMap(profileId as string, s as dynamic, listsOnly as boolean) as boolean
    ' Type guard: the server's PHP JSON round-trip returns an empty {} as
    ' [] — and crashing on feed data froze the whole app once (v1.0.8).
    if s = invalid or type(s) <> "roAssociativeArray" then return false
    suffix = ProfileSuffixFor(profileId)
    if not listsOnly
        for each e in psetScalarMap()
            if s.doesExist(e.pk)
                v = s[e.pk]
                t = type(v)
                if e.kind = "bool"
                    if t = "roBoolean" or t = "Boolean"
                        if v then RegWrite(e.reg + suffix, "1") else RegWrite(e.reg + suffix, "0")
                    end if
                else if e.kind = "sort"
                    vs = ToStr(v)
                    if vs = "provider" then RegWrite(e.reg + suffix, "default")
                    if vs = "az" or vs = "za" then RegWrite(e.reg + suffix, vs)
                else if e.kind = "mode"
                    vs = ToStr(v)
                    if vs = "hide" or vs = "pin" then RegWrite(e.reg + suffix, vs)
                else if e.kind = "int"
                    ' Every numeric shape ParseJson can hand back, because
                    ' which one it picks for a bare number is not something
                    ' to bet a member's setting on. Anything else (a quoted
                    ' number from an older push, a value off the choice
                    ' list) is left alone rather than half-applied.
                    if t = "Integer" or t = "roInt" or t = "LongInteger" or t = "roLongInteger" or t = "Float" or t = "roFloat" or t = "Double" or t = "roDouble"
                        n = Int(v)
                        if psetChoiceOk(e, n) then RegWrite(e.reg + suffix, n.toStr())
                    end if
                else if e.kind = "choice"
                    if t = "roString" or t = "String"
                        vs = ToStr(v)
                        if psetChoiceOk(e, vs) then RegWrite(e.reg + suffix, vs)
                    end if
                else
                    if t = "roString" or t = "String"
                        sv = ToStr(v)
                        ' A row carrying `max` refuses a longer value instead
                        ' of writing it. This is the one value on this map
                        ' that another device composes rather than picks off
                        ' a list, the registry is 16-32 KB for the whole app,
                        ' and a write past the end fails silently and takes
                        ' whatever else was mid-write with it. No `max` = no
                        ' limit, which is every other row here.
                        if (not e.doesExist("max")) or Len(sv) <= e.max
                            RegWrite(e.reg + suffix, sv)
                        else
                            KLog("sync", "pset: refused " + e.pk + " - " + Len(sv).toStr() + "B is over its " + ToStr(e.max) + "B limit")
                        end if
                    end if
                end if
            end if
        end for
        ' The phone's preferred subtitle language (2-letter, confirmed),
        ' normalized to the Roku's 3-letter codes.
        if s.doesExist("pref_preferred_subtitle_language")
            l3 = langTo3(ToStr(s["pref_preferred_subtitle_language"]))
            if l3 <> "" then RegWrite("pref_caption_lang" + suffix, l3)
        end if
    end if
    ' Incoming category lists are names and local prefs are name-keyed —
    ' write straight through. (No cold-cache retry needed anymore; the
    ' pending flag survives only for the hidden-channel host path below.)
    for each e in psetListMap()
        if s.doesExist(e.pk) and isArrayType(s[e.pk])
            names = []
            for each nm in s[e.pk]
                names.push(ToStr(nm))
            end for
            RegWrite(psetCatRegKey(e.what, e.scope, "", suffix), FormatJson(names))
        end if
    end for
    pending = false
    prov = KwickTvProvider()
    if prov = invalid then return false
    host = HostOf(ToStr(prov.server))
    provId = ToStr(prov.id)
    if s.doesExist("pref_hidden_channel_ids") and isArrayType(s["pref_hidden_channel_ids"]) and host <> ""
        pfx = "xt:" + host + ":"
        ids = []
        for each ch in s["pref_hidden_channel_ids"]
            chs = ToStr(ch)
            if chs.left(Len(pfx)) = pfx then ids.push(Mid(chs, Len(pfx) + 1))
        end for
        RegWrite("chan_hidden_" + provId + suffix, FormatJson(ids))
    end if
    return pending
end function

