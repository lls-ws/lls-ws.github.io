' ---- Telling the website what this TV came with -----------------------------
' The website's "On this TV" list shows a locked KwickTV row for any box that
' told it there was a KwickTV login here. That report only ever rode along
' with a pairing code, and a pairing code is only minted when somebody opens
' Add a source — so the list was wrong in BOTH directions:
'
'   signed out   the row stood on the website forever, pointing at a
'                television that hasn't had KwickTV on it for months.
'   signed in    the row didn't appear at all. The owner signed in on the
'                TV, opened kwickplayer.tv/link on his phone and saw
'                nothing; it turned up minutes later only because the
'                pairing screen happened to be opened while debugging.
'
' So both ends say so themselves, through this one helper: sign-in calls it
' the moment the login exists, sign-out calls it the moment the login is
' gone. It reports whatever is true right now and makes no assumptions about
' which way the change went — which is why it lives here, in source, rather
' than in either screen. OnboardScreen's finishAdd() and
' SettingsCategoryScreen's finishSignOut() are the only two callers, and
' neither could see the other's copy.
'
' A plain claim from a box with nothing to report IS the "forget what I told
' you": SourceLinkTask turns an empty builtin into an explicit
' { kind: "none" }, which is what the service clears the row on. Nothing
' about the wire format changes here — this is a second trigger for a body
' the shipped client has always sent. It is the same two things every claim
' has ever carried, this box's device id and that key. No account name, no
' username, no password, nothing the member hasn't already been sending
' every time they paired.
'
' Store edition only, same gate as the silent restore on the onboarding
' screen: the link service exists to get sources onto a build that can't take
' a typed web address, and the sideload build never talks to it at all.
'
' FIRE AND FORGET, in the strongest sense. Nothing is observed, nothing is
' waited on, nothing can fail out loud. The request lives entirely on the
' task's own thread; the caller carries on down the very next line whether
' the service answers, refuses, takes all twelve seconds to time out, or the
' box has been off the internet since Tuesday. A member signing in or out on
' a dead connection sees exactly what they see today.
'
' CALL IT AFTER THE REGISTRY IS ALREADY RIGHT, both ways round. It reads the
' truth rather than being told it, so a call one line early on the sign-in
' path reports "no KwickTV" and a call one line early on the sign-out path
' reports the login that is about to be deleted. Either one writes the exact
' stale row this exists to stop.
sub ReportBuiltinToLinkService()
    if AllowWebAddressEntry() then return
    t = CreateObject("roSGNode", "SourceLinkTask")
    ' Nothing on this path is allowed to take a sign-in or a sign-out down
    ' with it, so even the one failure that shouldn't be possible gets a way
    ' out.
    if t = invalid then return
    t.action = "claim"
    t.device = LinkDeviceId()
    ' Worked out from the same one helper the pairing screen and the silent
    ' restore use — the KwickTV row when there is a login, empty when there
    ' isn't, and the task spells an empty one out as { kind: "none" } on the
    ' way onto the wire.
    builtin = LinkBuiltinSource()
    t.builtin = builtin
    ' The reference has to outlive the screen that made it. Both callers are
    ' on their way out the moment they call: sign-in tears the onboarding
    ' screen down, and a sign-out that takes the last source routes straight
    ' back to onboarding and throws the shell away a heartbeat later. A task
    ' held only in a component's m would be collected mid-request. The global
    ' node lasts as long as the app does, which is longer than any
    ' twelve-second request.
    '
    ' ONE SLOT is still enough with two callers. Signing in and signing out
    ' are the only two, they are opposite ends of a session, and getting from
    ' one to the other means picking a profile, reaching Home and walking
    ' into Settings > Sources — minutes, not the twelve seconds a request
    ' lives for. (addFields refuses to overwrite a field that already exists,
    ' hence the two ways in.)
    if m.global.hasField("linkBuiltinTask")
        m.global.linkBuiltinTask = t
    else
        m.global.addFields({ linkBuiltinTask: t })
    end if
    if builtin.count() > 0
        KLog("link", "signed in with KwickTV - telling the link service this TV has one")
    else
        KLog("link", "signed out of KwickTV - telling the link service this TV has none")
    end if
    t.control = "RUN"
end sub
