' Theme tokens — a direct port of the Android app's NORD SHELL scheme
' (packages/kwicktv_design/lib/src/theme/theme_registry.dart:286-317).
' Every screen pulls colors from here so the two apps stay visually
' identical. 42 files call KwickTheme(); only twelve colours in the whole
' app are hard-coded outside this file, so changing the values here reskins
' essentially everything at once.
'
' WHY NORD SHELL. The owner asked for the Android app's terminal-chrome
' look rather than "just another bland UI". Nord Shell is one of four
' terminal skins over there (with Midnight Shell, Matrix Green and Amber
' CRT); on Android the skin is a runtime choice, on Roku there is one
' theme object, so this file simply IS Nord Shell now. The previous
' KwickTV Dark values are in the git-free history of this file only —
' they are written out at the bottom of this comment so nothing is lost:
'
'     accent 2086FF  accentAlt 4FC3F7  background 101113  surface 1A1C1F
'     surfaceElevated 25272B  textPrimary F4F5F6  textSecondary 9DA2A9
'     focusRing 5CA8FF  liveBadge E53956  error FF5C6C  favorite E53956
'
' THE TERMINAL SKIN IS MORE THAN COLOURS. On Android `terminalChrome`
' also switches the type to JetBrains Mono, gives idle posters a thin
' slate frame instead of no frame at all, and turns row and section
' titles into shell prompts ("❯ ~/favorites/movies ls"). The font uris
' and ShellPrompt() below are this app's half of that; the cards that use
' them are PosterCard, ChannelCard and HomeScreen's row titles.

function KwickTheme() as object
    return {
        ' AppColorScheme (nord_shell)
        accent: "0x88C0D0FF"        ' nord frost
        accentAlt: "0xA3BE8CFF"     ' nord green
        background: "0x2E3440FF"    ' nord0
        surface: "0x3B4252FF"       ' nord1
        surfaceElevated: "0x434C5EFF" ' nord2
        textPrimary: "0xECEFF4FF"   ' nord6
        ' >>> THE ONE DELIBERATE DEPARTURE FROM ANDROID'S NORD SHELL. <<<
        ' Android sets textSecondary to nord4, 0xD8DEE9. Against this
        ' file's textPrimary (0xECEFF4) that is a 13:1 versus 11:1 step —
        ' i.e. no visible step at all from a sofa. Roku uses the pair as a
        ' STATE cue in places (ChannelCard paints an unfocused tile's name
        ' textSecondary and a focused one textPrimary), so porting nord4
        ' verbatim would delete a focus cue on a ten-foot screen. This is a
        ' muted Nord slate sitting between nord3 (0x4C566A) and nord4: 5.3:1
        ' on the nord0 page, plainly dimmer than textPrimary.
        textSecondary: "0x9BA9BFFF"
        focusRing: "0x88C0D0FF"     ' nord frost
        liveBadge: "0xBF616AFF"     ' nord red
        errorColor: "0xBF616AFF"    ' nord red
        ' >>> SETTLED 2026-08-26: NORD YELLOW. <<<
        ' The ring was warm orange (0xFF9E45) by an earlier ruling. The
        ' owner has now taken Android's own Nord Shell value instead,
        ' knowing it overrides that earlier call. Nord yellow against the
        ' nord0 page measures 8.0:1, near enough identical to the orange it
        ' replaces (8.2:1) — this is not a step down in visibility.
        '
        ' TWO PLACES DEPEND ON THIS BEING A LIGHT COLOUR, not just on it
        ' being the focus colour: the Media Bar's focused button fills its
        ' plate with focusHighlight and writes the label in `background`
        ' (paintButton), and PosterCard/ChannelCard draw it as a ring on
        ' dark artwork. Both still work — yellow is lighter than the orange
        ' was, so the dark ink on it gained contrast. Anything that ever
        ' puts WHITE on this colour would not; there is nothing that does.
        '
        ' Changing this ONE line reskins every focus ring in the app.
        focusHighlight: "0xEBCB8BFF"   ' nord yellow (nord13)
        favorite: "0xB48EADFF"      ' nord purple
        ' The lifted plate a FOCUSED channel tile wears, hoisted out of
        ' ChannelCard.brs so it is on the palette with everything else.
        ' Nord's bright slate ("nord3 bright" in every Nord port): relative
        ' luminance 0.152 against surface's 0.054, i.e. about 2.8x, which
        ' is a step you can see from a sofa. surfaceElevated is NOT this —
        ' that token is a one-step lift for a panel resting on the page and
        ' is only a hair off surface, which is invisible at ten feet.
        surfaceLift: "0x616E88FF"
        ' A surface TINTED WITH THE ACCENT, one step brighter than
        ' surfaceElevated. The Guide's "on now" block is what wants it
        ' (GuideScreen.brs) and Nord ships nothing for the job: frost is far
        ' too light to sit under text, and surfaceElevated is the exact
        ' colour the block has to differ from.
        '
        ' DERIVED, not picked: nord2 (0x434C5E) mixed 25% toward nord frost
        ' (0x88C0D0). That keeps the accent hue the role asks for and keeps
        ' it inside the palette rather than leaving a KwickTV-blue relic
        ' (the old literal was 0x2E4A78, from the retired blue scheme).
        '
        ' >>> ONE THING TO CHECK ON THE TELEVISION. <<< The step from
        ' surfaceElevated is 1.9x in luminance, where the OLD pair was 3.4x
        ' — not because this value is timid but because Nord's whole Polar
        ' Night ramp is lighter and more compressed than the scheme it
        ' replaces, so there is no room left below readable text for a 3.4x
        ' jump. Going brighter costs the text: this holds textPrimary at
        ' 5.0:1 and 30% more mix would drop it to 4.6:1. If "on now" stops
        ' jumping out on the TV, the answer is a SECOND cue (an accent bar
        ' down the block's leading edge, which SportsRow already does for a
        ' live fixture), not a brighter tint.
        surfaceAccent: "0x54697AFF"

        ' ---- Terminal chrome ------------------------------------------
        ' Android: ThemeSpec.surfaceBorderColor (theme_registry.dart:292)
        ' — the "terminal window" outline every surface wears on a shell
        ' theme. Full strength for a rule or a window edge.
        surfaceBorder: "0x88C0D0FF"
        ' The same frost at 60%, for the thin resting frame a card wears
        ' when it is NOT focused (Android media_card.dart:98-101 gives an
        ' idle poster a slate border at 1.5 where a normal theme gives it
        ' none). Dimmed on purpose: at full strength an always-on frame
        ' competes with the focus ring, and the ring has to win from ten
        ' feet.
        cardIdleBorder: "0x88C0D099"
        ' The grid-paper wash Android lays over the page on this theme
        ' (gridLineColor 0x0D88C0D0 — frost at alpha 13/255, about 5%).
        ' DRAWN, as of 2026-08-26: see BuildGridOverlay() further down, and
        ' the note there about why the earlier "this needs a full-screen
        ' texture" reading of it was wrong.
        gridLine: "0x88C0D00D"

        ' The shell theme's type. Android sets fontFamily "JetBrainsMono"
        ' on every terminal skin (theme_registry.dart:290) and ships the
        ' same two files this app now carries in pkg:/fonts. JetBrains Mono
        ' 2.305 is SIL Open Font License 1.1 (the licence string is in the
        ' font's own name table), so it is ours to redistribute.
        '
        ' USE UiFont()/UiBoldFont() BELOW rather than these strings — a
        ' Font node has to be built either way and the helpers keep the
        ' size in one place with the uri.
        fontUri: "pkg:/fonts/JetBrainsMono-Regular.ttf"
        fontUriBold: "pkg:/fonts/JetBrainsMono-Bold.ttf"

        ' Layout tokens (FHD 1920x1080)
        sidebarWidth: 110
        screenW: 1920
        screenH: 1080

        ' Material icon codepoints (same icon font as the Android app)
        iconHome: Chr(&hE88A)
        iconLiveTv: Chr(&hE639)
        iconGuide: Chr(&hE936)
        iconVod: Chr(&hE02C)
        iconSettings: Chr(&hE8B8)
        iconStore: Chr(&hEA12)
        iconSearch: Chr(&hE8B6)
        iconStar: Chr(&hE838)
        iconFavorite: Chr(&hE87D)
        iconPlay: Chr(&hE037)
        iconBack: Chr(&hE5C4)
        iconCheck: Chr(&hE5CA)
        iconRefresh: Chr(&hE5D5)
        iconPerson: Chr(&hE7FD)
        ' Material "sports_soccer". If the bundled font predates it this
        ' renders as a box — checked on a real device before shipping.
        iconSports: Chr(&hEA2F)

        ' Settings grid tiles. Every codepoint below was read out of the
        ' bundled fonts/MaterialIcons-Regular.ttf character map before it was
        ' used here, so none of them can come out as an empty box the way an
        ' invented codepoint would.
        iconPlaylist: Chr(&hE05F)   ' playlist_play
        iconPeople: Chr(&hE7FB)     ' people
        iconCategory: Chr(&hE574)   ' category
        iconLock: Chr(&hE897)       ' lock
        iconSync: Chr(&hE627)       ' sync
        iconRestore: Chr(&hE8BA)    ' settings_backup_restore
        iconAccount: Chr(&hE853)    ' account_circle
    }
end function

' ---- Editions ---------------------------------------------------------------
' Two builds from ONE codebase, the same split as Android's Play vs public
' sideload editions:
'
'   "sideload"  the public sideload build — everything, including the
'               Get KwickTV storefront. THIS IS THE DEFAULT and what the
'               repo always is; the sideload build must never change.
'   "store"     the Roku Channel Store build. Identical except the
'               storefront is omitted, because Roku certification 5.3
'               forbids "directing users to exit the app to purchase
'               content, goods or other services".
'
' The value lives in the manifest (kwick_edition) and is swapped ONLY inside
' the zip that `package.py --store` produces — the working tree is never
' touched, so normal deploys always build the sideload edition.
'
' The KwickTV login itself is in BOTH editions: KwickSync depends on it, and
' an on-device username/password sign-in is exactly what Roku asks for
' (certification 2.2). It's the sign-up and payment routes that have to go,
' not the login.
'
' STORE SUBMISSION IS LIVE WORK AGAIN as of 2026-08-23 — the owner's earlier
' "one edition, never submitting" call is reversed. See the wiki note
' [[Roku - Store Certification Strategy]]. Everything below branches for
' real again; the sideload build is unchanged and members keep running it.

' The manifest's edition marker.
function KwickEdition() as string
    e = CreateObject("roAppInfo").getValue("kwick_edition")
    if e = "" then return "sideload"
    return e
end function

' Should this build show the Get KwickTV storefront (sidebar entry, store
' dialog, "Don't have an account?" link, sign-up/pricing dialog)?
'
' Sideload only. Roku certification 2.5 / 5.3 forbid directing viewers out
' of a channel to purchase content, goods or services, and a storefront
' entry is an automatic rejection.
function ShowStorefront() as boolean
    return KwickEdition() <> "store"
end function

' May this build put a keyboard in front of the member and take a web
' address? Sideload only. The Roku Distribution Agreement §10.3(a) says a
' channel may not "enable end users to enter web addresses" — which rules
' out the Xtream server URL, the M3U playlist URL, the EPG URL, and the
' Custom EPG row in Settings. Picking a playlist FILE off a USB drive is
' not a web address, so that path stays in both editions.
function AllowWebAddressEntry() as boolean
    return KwickEdition() <> "store"
end function

' Off-device destinations that aren't a storefront — the Discord and
' Telegram rows in Settings. They still send a viewer somewhere that isn't
' this Roku, which is exactly what certification 2.5 / 5.3 are about, so
' the store edition does without them.
function ShowOffDeviceLinks() as boolean
    return KwickEdition() <> "store"
end function

' Branding — port of lib/core/branding.dart (public build values).
function KwickBranding() as object
    return {
        appName: "Kwick Player"
        fullAppName: "Kwick Player"
        serviceName: "KwickTV"
        ' PORT 80, NOT 8080 (v1.0.32, 2026-09-05). The panel's own server_info
        ' advertises port "80" and answers player_api.php there with a
        ' byte-identical body on both of its IPs; streams 302 to the same
        ' port-80 edge nodes either way. Roku's certification lab failed to
        ' sign in on five runs while the link service (HTTPS, 443) worked from
        ' the same box; a non-standard port is the one thing about this address
        ' a lab firewall would plausibly block. Members already signed in keep
        ' the base stored in their provider record; nothing else keys on the
        ' port (HostOf strips it). Android still uses :8080 - align it next
        ' release (lib/core/branding.dart).
        serverUrl: "http://kwick.cc"
        signupUrl: "https://kwickflix.shop/iptv-pricing.php"
        storeUrl: "https://kwickflix.shop/"
        syncApiUrl: "https://kwickplayer.tv/kwicksync/api.php"
        logsApiUrl: "https://kwickplayer.tv/kwicksync/logs.php"
        discordUrl: "discord.gg/ruGAfxUmZ3"
        telegramUrl: "t.me/+8ifZv6x0sgAzOWE5"
    }
end function

' Profile avatar palette — the six colors from the Android app
' (profile_avatar.dart profileColors), as Roku RRGGBBAA.
function ProfilePalette() as object
    return ["0x2086FFFF", "0x4FC3F7FF", "0x81C784FF", "0xFFB74DFF", "0xE57373FF", "0xBA68C8FF"]
end function

function ProfileColorAt(index as integer) as string
    pal = ProfilePalette()
    if index < 0 then index = 0
    return pal[index mod pal.count()]
end function

' ---- The ink that goes ON a profile swatch ----------------------------------
' The initial drawn inside a profile's coloured square, per colour.
'
' WHY THIS IS NOT JUST "white". Three of the six above are LIGHT — the sky
' blue, the green and the amber sit at relative luminance 0.47, 0.47 and 0.56
' — and white on them measures 2.0:1, 2.0:1 and 1.7:1. That is not a letter
' you can read, it is a smudge, and it is on the first thing the member sees
' at launch. This was NOT caused by the Nord port (the six avatar colours are
' the phone's and predate it); it was simply never right.
'
' THE RULE, applied once here and written out as a table so nothing does
' colour maths per bind: if the swatch's own relative luminance is above 0.30
' the ink is the page colour, otherwise it is white. That is the same "dark
' ink on a light fill" answer the accent buttons landed on. Measured results,
' before -> after:
'
'     0 blue   0x2086FF  white 3.6:1  ->  white   3.6:1   (unchanged)
'     1 sky    0x4FC3F7  white 2.0:1  ->  nord0   6.2:1
'     2 green  0x81C784  white 2.0:1  ->  nord0   6.2:1
'     3 amber  0xFFB74D  white 1.7:1  ->  nord0   7.2:1
'     4 red    0xE57373  white 3.0:1  ->  nord0   4.2:1
'     5 purple 0xBA68C8  white 3.6:1  ->  white   3.6:1   (unchanged)
'
' Slots 0 and 5 are mid-tones that clear neither ink at 4.5:1; they keep white
' because it is the better of the two, and the initial is a 34px BOLD glyph,
' which is "large text" and wants 3:1. Both clear that. Fixing those two
' properly means changing the avatar colours themselves, which are shared with
' the phone and are not this app's to redefine.
'
' The dark ink is the theme's own background so it tracks a reskin; the light
' one is plain white rather than textPrimary because nord6 on these swatches
' is DIMMER than white, not brighter.
function ProfileInkAt(index as integer) as string
    ' true = this swatch is light and takes dark ink. Index-aligned with
    ' ProfilePalette() above; if a colour there ever changes, re-measure.
    darkInk = [false, true, true, true, true, false]
    if index < 0 then index = 0
    if darkInk[index mod darkInk.count()] then return KwickTheme().background
    return "0xFFFFFFFF"
end function

' ---- Colour arithmetic ------------------------------------------------------
' Every colour in this file is the string "0xRRGGBBAA", and a screen that needs
' a VARIANT of one — the same red at a quarter opacity, the same red brightened
' — used to have no choice but to write a second hex string beside the first
' and hope someone remembers both if the theme is ever reskinned. These two
' derive the variant instead, so there is still only one authored colour.
'
' They take and return that same "0xRRGGBBAA" shape. Nothing here validates the
' input: a short or malformed string gives a wrong colour, not a crash, which
' is the right trade on the render thread.

' The same colour at a different opacity, 0-255. The alpha byte is REPLACED
' rather than appended, because the theme's colours already carry one.
function ColorWithAlpha(color as string, alpha as integer) as string
    a = alpha
    if a < 0 then a = 0
    if a > 255 then a = 255
    return Left(color, 8) + HexByte(a)
end function

' The same colour moved `pct` percent of the way to white, alpha untouched.
' Mixing toward white rather than simply using white is what keeps a "lit"
' element recognisably the theme's own hue: at 42% the guide's Nord red
' BF616A becomes D9A3A8, which still reads as red but has the brightness of
' something giving off light rather than something painted.
function ColorLiftToWhite(color as string, pct as integer) as string
    p = pct
    if p < 0 then p = 0
    if p > 100 then p = 100
    lifted = "0x"
    for i = 0 to 2
        c = HexByteValue(Mid(color, 3 + i * 2, 2))
        c = c + Int((255 - c) * p / 100)
        lifted = lifted + HexByte(c)
    end for
    return lifted + Right(color, 2)
end function

' 0-255 as two uppercase hex digits.
function HexByte(v as integer) as string
    h = "0123456789ABCDEF"
    return Mid(h, Int(v / 16) + 1, 1) + Mid(h, (v mod 16) + 1, 1)
end function

' Two hex digits back as 0-255. Anything that is not a hex digit counts as 0.
function HexByteValue(s as string) as integer
    h = "0123456789ABCDEF"
    hi = Instr(1, h, UCase(Mid(s, 1, 1))) - 1
    lo = Instr(1, h, UCase(Mid(s, 2, 1))) - 1
    if hi < 0 then hi = 0
    if lo < 0 then lo = 0
    return hi * 16 + lo
end function

' ---- Source colours ---------------------------------------------------------
' A member with several playlists can't tell at a glance which source a title
' or channel came from — the corner tag says "Hello Kwick M…" on one poster
' and "KwickTV" on the next, and at ten feet those are two grey smudges. So
' every source gets a COLOUR, and the same colour is painted on both places
' the source is named: the VOD source chips and the corner tag on each card.
'
' Keyed on the SOURCE TOKEN (SrcTokenFor in Store.brs: "" for KwickTV,
' "xt:<host>", "m3u:<host>", "file:<name>"), never on the display name. The
' name is whatever the member typed and they can rename it in Settings; the
' token only changes if they repoint the source at a different server, which
' genuinely IS a different source. Hashing the token means the colour is the
' same on every launch, on both editions, and on Android too if it ever
' ports — no state is stored anywhere.
'
' KwickTV (token "") is RESERVED: it takes the app accent, so the house
' source always looks like the house. The other eight are handed out by
' hash. With only eight slots two sources CAN land on the same colour —
' that's accepted: the colour is a hint that rides alongside the name, not
' a replacement for it, and the name is still written on the tag.
'
' Each entry is:
'   bg   — the tag background on a card. Deep and slightly transparent
'          (alpha E6) so poster art still shows through a little. Every one
'          of these sits at a relative luminance of 0.087-0.105, i.e. about
'          7:1 against white text, so (a) the existing white tag text stays
'          legible on all of them with no per-colour text switching, and
'          (b) no source looks louder or more "important" than another.
'          Even composited over a pure-white poster the worst case is still
'          better than 5:1.
'   mark — the same hue lifted to a mid-tone, opaque. This is the chip dot,
'          which sits on a dark pill and has to carry across a room. These
'          all land at luminance 0.23-0.29, again so no source shouts.
'
' No new image assets: this is nine pairs of colour values, and the chip dot
' reuses the circle.png that the favourite heart already sits on.
function SrcPalette() as object
    pal = []
    pal.push({ bg: "0x1D5697E6", mark: "0x2086FFFF" })   ' 0  KwickTV — reserved, the app accent
    pal.push({ bg: "0x1A6360E6", mark: "0x2FA39EFF" })   ' 1  teal
    pal.push({ bg: "0x2F6634E6", mark: "0x4CA353FF" })   ' 2  green
    pal.push({ bg: "0x6B5218E6", mark: "0xB08A32FF" })   ' 3  olive
    pal.push({ bg: "0x8A4622E6", mark: "0xD06F3EFF" })   ' 4  rust
    pal.push({ bg: "0x96354DE6", mark: "0xD05E80FF" })   ' 5  crimson
    pal.push({ bg: "0x67429BE6", mark: "0x9878D0FF" })   ' 6  purple
    pal.push({ bg: "0x6D4C3DE6", mark: "0xB0806AFF" })   ' 7  brown
    pal.push({ bg: "0x8E3277E6", mark: "0xCB61B0FF" })   ' 8  magenta
    return pal
end function

' Which palette slot a source token owns. Slot 0 is KwickTV's and nothing
' else may land there; the rest hash into 1..8.
'
' The hash is the plain "multiply by 31 and add the character" rolling sum,
' taken mod a prime so it can't overflow a 32-bit integer (h stays under
' 1000003, so h*31 + 255 stays under 31 million). Pure integer arithmetic on
' a string that is already in hand — no registry read, no file read, no node
' created — which is what makes it safe to call while a grid is recycling
' cards under a held-down arrow key.
function SrcColorIndex(token as string) as integer
    if token = "" then return 0
    h = 0
    for i = 0 to token.len() - 1
        h = (h * 31 + Asc(token.mid(i, 1))) mod 1000003
    end for
    return 1 + (h mod 8)
end function

' The { bg, mark } pair for a source token. Convenience for the callers that
' only do this once (the VOD chip row). Cards must NOT call this per bind —
' it rebuilds the whole palette array each time; they cache SrcPalette() at
' init and index it with SrcColorIndex().
function SrcColorsFor(token as string) as object
    return SrcPalette()[SrcColorIndex(token)]
end function

' Maps a profile's avatar value to a renderable pkg: uri. Profiles store the
' ANDROID-style asset path ("assets/avatars/<Show>/<Name NN>.webp") so the
' value syncs cleanly between devices; the Roku bundle carries the same pack
' converted to JPG under pkg:/avatars/ (Roku can't draw webp). Anything else
' (a phone's device-local photo path) returns "" → colored-initial fallback.
function AvatarUri(path as string) as string
    if path = "" then return ""
    prefix = "assets/avatars/"
    if path.left(prefix.len()) <> prefix then return ""
    p = "pkg:/avatars/" + path.mid(prefix.len())
    if LCase(p.right(5)) = ".webp" then p = p.left(p.len() - 5) + ".jpg"
    return p
end function

' Font nodes for the bundled Material icon font at a given size.
function IconFont(size as integer) as object
    font = CreateObject("roSGNode", "Font")
    font.uri = "pkg:/fonts/MaterialIcons-Regular.ttf"
    font.size = size
    return font
end function

' ---- The shell theme's type -------------------------------------------------
' JetBrains Mono, the same face Android's terminal skins use. Two things to
' know before pointing anything else at these:
'
'   1. MONO IS WIDER THAN ROBOTO. JetBrains Mono's advance is a flat 0.6em;
'      Roboto-Medium averages roughly 0.5em. The same string at the same
'      point size needs about 20% more room, so a Label with a fixed width
'      and maxLines=1 will start truncating sooner. Every call site added in
'      this pass was checked against its own box; anything else that is
'      switched over has to be checked the same way, ON THE TELEVISION.
'   2. It has the glyphs the shell look needs — U+276F "❯" was read out of
'      the file's character map before ShellPrompt() below was written, the
'      same check the Material codepoints above got. Roboto does NOT have
'      it, so a prompt Label must be given one of these fonts or it draws a
'      missing-character box.
function UiFont(size as integer) as object
    font = CreateObject("roSGNode", "Font")
    font.uri = "pkg:/fonts/JetBrainsMono-Regular.ttf"
    font.size = size
    return font
end function

function UiBoldFont(size as integer) as object
    font = CreateObject("roSGNode", "Font")
    font.uri = "pkg:/fonts/JetBrainsMono-Bold.ttf"
    font.size = size
    return font
end function

' ---- LabelLists, which nobody had themed ------------------------------------
' A Roku LabelList draws its rows in the PLATFORM'S OWN DEFAULT FONT unless it
' is given one, and no LabelList in this app ever was. That did not show while
' everything else was Roboto; once the rest of the app is JetBrains Mono, every
' unthemed LabelList is the last thing on screen still in the old face, and it
' looks like a bug rather than a choice.
'
' IT CAN BE THEMED. LabelList carries four fields for exactly this — `font`
' and `color` for a resting row, `focusedFont` and `focusedColor` for the one
' under the highlight — so this is a convention that was missing, not a
' platform limitation.
'
' Call it ONCE, at init, after findNode and before the list is filled:
'
'     ThemeLabelList(m.top.findNode("categories"), 26)
'
' Passing 0 for pts leaves the sizes alone and only sets the faces and
' colours, for a list that has already been sized deliberately.
'
' The focused row is BOLD as well as brighter. On a mono face the two weights
' are the same width to the pixel (JetBrains Mono's advance is a flat 0.600 em
' in Regular and Bold alike), so switching weight on focus cannot reflow a row
' or shift a single character — which is precisely why this is safe here and
' would not have been on Roboto.
'
' Every field is written whether or not it was already set, and both the
' resting and the focused pair are written every time, so a list can never end
' up half themed.
'
' hasField guards every write because this is called on nodes another lane
' owns: a MarkupList has none of these fields, and a silent no-op is a better
' outcome than a warning in somebody else's log.
sub ThemeLabelList(lst as object, pts = 26 as integer)
    if lst = invalid then return
    th = KwickTheme()
    if pts > 0
        if lst.hasField("font") then lst.font = UiFont(pts)
        if lst.hasField("focusedFont") then lst.focusedFont = UiBoldFont(pts)
    end if
    if lst.hasField("color") then lst.color = th.textSecondary
    ' THE FOCUSED ROW'S TEXT IS THE PAGE COLOUR, NOT WHITE. Roku's own focus
    ' bar under a LabelList row is a light fill, and near-white text on it is
    ' under 2:1 - Mason, on the rebuilt Hide & Reorder screens (2026-09-15):
    ' "hard to read what is highlighted", with a photo of a row you could not
    ' read at all. The same rule the VOD pills already follow (nord0 on the
    ' frost fill is about 6:1 where white was under 2:1); it applies to every
    ' list this helper themes, so the series page and Watch History get it too.
    if lst.hasField("focusedColor") then lst.focusedColor = th.background
    ' A section divider, where a list has them, is a heading and not a row.
    if lst.hasField("sectionDividerFont") and pts > 0
        lst.sectionDividerFont = UiBoldFont(pts - 4)
    end if
    if lst.hasField("sectionDividerColor") then lst.sectionDividerColor = th.accent
end sub

' ---- The member's Background Effect -----------------------------------------
' Settings -> Appearance -> Background Effect, ported from Android
' (packages/kwicktv_design/lib/src/theme/background_effect.dart:31-45). FOUR
' choices, and the STORED STRINGS ARE ANDROID'S, character for character, so
' the two apps mean the same thing by the same word:
'
'     none       None          -> neither
'     grid       Grid Lines    -> grid only          <- the default
'     crt        CRT Lines     -> scanlines only
'     grid_crt   Both          -> both
'
' >>> ANDROID HAS A FIFTH, "theme" / Theme default, AND ROKU DELIBERATELY
' DOES NOT. <<< Over there it means "whatever the skin in force brings",
' resolved at paint time against 24 skins — nine bring grid paper, two bring
' scanlines, thirteen bring nothing — so it is a real choice with a real
' answer that changes. THIS app has exactly ONE skin and it is Nord Shell
' (see the top of this file, and theme_registry.dart:288-291:
' `gridOverlay: true, crtOverlay: false`). A deferral that can only ever
' resolve one way is not an option, it is a fifth row that means "Grid Lines"
' and makes the member work that out. The owner ruled it out on 2026-08-27.
'
' WHICH IS WHY THE DEFAULT IS `grid`. Nord Shell draws the mesh, so grid-on
' is what this app does today and has always done. A member who never opens
' this row must see exactly what they see now — an update that silently took
' the gridlines away would read as a bug, and it would be reported as one.
'
' AN UNSET, UNRECOGNISED OR ANDROID-WRITTEN VALUE IS ALSO `grid`, and the
' "theme" string specifically is TOLERATED rather than treated as a fault.
' It should never appear on a Roku box, but Android writes it, and a value
' copied off a test box or restored from somewhere else is exactly the sort
' of thing that turns up eighteen months later. Landing it on the default is
' the answer that changes nothing.
'
' >>> WHERE THE ANSWER COMES FROM, AND WHY IT IS NOT RegRead("bgfx"). <<<
' The obvious code here is a RegRead. It would kill the app, and it is worth
' writing down exactly how. RegRead lives in Store.brs;
' AvatarPickerScreen.xml does NOT name Store.brs among its scripts, but it
' DOES call AddPageGrid() below — and a component gets only the scripts its
' own XML names, inheriting nothing from the scene around it. The call would
' come back "Function is not defined in component's namespace" and take that
' screen's render thread down with it, spinner still turning.
'
' So the registry is read ONCE, in AppScene.init(), and the resolved answer is
' published on m.global — which every component has without including
' anything at all. These two readers are the only supported way to ask.
' Do not "simplify" either of them back into a RegRead.
'
' THE FALLBACK WHEN THE GLOBALS ARE MISSING is the default, grid on /
' scanlines off, i.e. the app as it looked yesterday. A painter that somehow
' ran before AppScene published gets today's picture rather than a blank page.
function BgFxGridOn() as boolean
    if m.global = invalid then return true
    if not m.global.hasField("bgFxGrid") then return true
    return m.global.bgFxGrid = true
end function

function BgFxCrtOn() as boolean
    if m.global = invalid then return false
    if not m.global.hasField("bgFxCrt") then return false
    return m.global.bgFxCrt = true
end function

' The stored string -> the two booleans. AppScene calls this; nothing else
' needs to.
'
' EVERY UNKNOWN ANSWER FALLS OUT OF THE BOTTOM ONTO `grid`, which is the
' default and today's picture: an empty registry, a half-written value, and
' Android's own "theme" string if one ever arrives here. Deliberately NOT an
' error path — there is nothing to tell the member and nothing for them to do.
' >>> Trim IS A METHOD HERE, NOT A FUNCTION. <<< `Trim(storedKey)` is not a
' typo, it is a thing that does not exist: BrightScript has no global Trim(),
' only the ifStringOps method `storedKey.Trim()`. A bare Trim() resolves to
' nothing and faults on the call operator — "Function Call Operator ( )
' attempted on non-function, runtime error &he0" — at LAUNCH, before a single
' screen draws. It shipped here once (2026-08-27) and cost a build.
'
' AND package.py WILL NOT CATCH IT. The gate checks reserved identifiers and
' packaging; it does not resolve called names. The report came back clean on
' a build that could not start. Nothing but the television proves this line.
function BgFxResolve(storedKey as string) as object
    k = LCase(storedKey.Trim())
    if k = "none" then return { grid: false, crt: false }
    if k = "crt" then return { grid: false, crt: true }
    if k = "grid_crt" then return { grid: true, crt: true }
    return { grid: true, crt: false }   ' "grid", "theme", empty, unrecognised
end function

' ---- The CRT scanlines ------------------------------------------------------
' Android's CrtOverlay (packages/kwicktv_design/lib/src/effects/crt_overlay
' .dart:47-77), the retro raster the two neon skins wear.
'
' COSTS NOTHING AGAINST THE IMAGE BUDGET, for the same reason the mesh below
' does not: a Roku Rectangle is a solid fill with no bitmap behind it, so it
' never touches the ~90 MB texture pool that has five out-of-memory reports
' behind it. Drawn as an asset this would have been a 1920 x 1080 x 4 = 7.9 MB
' full-screen texture, which would be indefensible. It is 135 Rectangles.
'
' THE BAND SIZE, DERIVED RATHER THAN COPIED, exactly as the mesh cell was.
' Android repeats a 4 LOGICAL pixel band: 2px darkened, 2px clear. The
' Android->Roku factor this app has already agreed on (tools/make_card_art.py:
' a 110dp media card is a 232px poster over here) is
'
'     232 / 110 = 2.11    and    4 x 2.11 = 8.4
'
' Rounded to 8, which is within 5% of that AND divides 1080 exactly, so the
' last band meets the bottom edge instead of being sliced. The 50/50 duty
' cycle is kept, so 4px dark + 4px clear — scaling only one half would change
' how dark the effect reads, which is the thing a member actually sees.
' Copying 4 verbatim would have drawn a raster twice as fine as the phone's,
' and at 2px on a 1080 line that is close to invisible from a sofa anyway.
'
' UNLIKE THE MESH, THE FIRST BAND IS AT y = 0. The mesh starts one cell in
' because a line hard against the edge reads as a border. A scanline hard
' against the edge reads as a scanline — a raster with a gap at the top is
' the thing that would look wrong.
'
' Colour is Android's 0x24000000 unchanged — black at alpha 36/255, about
' 14% — written the way Roku wants it, RGBA rather than ARGB.
'
' >>> THE TUBE VIGNETTE IS DELIBERATELY NOT HERE. <<< Android also paints a
' radial gradient that darkens the corners. SceneGraph has no radial gradient
' and no gradient primitive of any kind, so the only ports available were a
' generated corner asset or nothing. A corner asset was rejected on the
' budget: even four quarter-size 480 x 270 corners decode to 4 x 518 KB = 2.07
' MB of texture, on top of package weight against the 4 MB cert 3.7 limit, and
' the corners cannot meet in the middle of an edge without a visible seam.
' The scanlines are the half of this effect people recognise; the vignette is
' the half nobody could name. It is dropped.
'
' STATIC, AND THAT IS A RULE RATHER THAN A SHORTCUT. Android's own file
' records that an earlier version swept an animated phosphor beam down the
' screen every frame, pegged the CPU on weak devices and — sitting over
' fullscreen video — stole frames from the decoder: stutter with clean audio.
' The beam was removed. Nothing here may be animated or repainted per frame.
function BuildCrtOverlay(parent as object) as object
    th = KwickTheme()
    crt = parent.createChild("Group")
    crt.id = "crtWash"
    bandPx = 8
    darkPx = 4
    w = th.screenW
    h = th.screenH

    yy = 0
    while yy < h
        bar = crt.createChild("Rectangle")
        bar.width = w
        bar.height = darkPx
        bar.color = "0x00000024"
        bar.translation = [0, yy]
        yy = yy + bandPx
    end while
    ' 1080 / 8 = 135 nodes, and that is the whole cost.
    return crt
end function

' Both effects, in one container, built to whatever the member chose. The
' container exists so a caller that has to place these among a screen's own
' children places ONE child and not two — see AddPageGrid below, whose index
' assumption would otherwise have to change in eleven screens, three of which
' belong to other people this week.
'
' ORDER: scanlines first (lower), mesh second (higher). That is Android's own
' relative order — GridOverlay wraps CrtOverlay, so the mesh paints last.
' SyncBackgroundEffects below keeps that order however the two halves arrive:
' the scanlines are forced to index 0 inside the container whenever they are
' built, so a member who turns them on later still gets them UNDER the mesh
' rather than over it.
'
' THE CONTAINER IS NOW CREATED EVEN ON "None", empty. It is one Group node and
' it is what makes the effect changeable while a screen is up: with nothing
' placed there is nothing for a later change to find, which is exactly the bug
' this had — a change made while standing in Settings only appeared after
' backing out to the scene.
function BuildBackgroundEffects(parent as object) as object
    fx = parent.createChild("Group")
    fx.id = "bgFxWash"
    SyncBackgroundEffects(fx)
    return fx
end function

' >>> THE ONE PLACE A PER-SCREEN COPY IS PAINTED. <<< Called on the way in
' (BuildBackgroundEffects, i.e. AddPageGrid) and again on every change
' (RepaintPageGrids, driven by AppScene.onBgFxChanged). Both entry points run
' the same code, so a screen opened AFTER a change and a screen already open
' WHEN the change lands end up identical — that symmetry is the fix.
'
' BUILD LAZILY, HIDE CHEAPLY. Turning an effect off is two boolean writes and
' the Rectangles are kept, exactly as AppScene does, because they cost no
' texture memory and rebuilding them per press is the work certification 3.5's
' 250 ms cannot afford. Turning one ON for the first time on this screen has
' to build it — 45 nodes for the mesh, 135 for the scanlines — and that cost
' is paid ONCE per screen, on the press whose whole purpose is that change,
' rather than on every screen open. It is not paid at all by the member who
' never changes the setting, which is the case the open path was tuned for.
'
' BOTH BRANCHES ARE WRITTEN FOR BOTH EFFECTS. A `visible` set only in its "on"
' branch is the mistake this codebase keeps making; here it would strand a
' mesh on screen after the member chose "None".
'
' RESOLVED FROM m.global.bgfxKey, NOT FROM bgFxGrid / bgFxCrt. Those two are
' derived by AppScene's own observer on the same field, and two observers on
' one field have no guaranteed order — reading them here could read the
' previous answer. bgfxKey is the thing that actually changed. Still no
' RegRead: this runs inside screens that do not include Store.brs.
sub SyncBackgroundEffects(host as object)
    if host = invalid then return
    want = BgFxPageWant()
    playing = false
    if m.global <> invalid and m.global.hasField("fxPaused")
        playing = (m.global.fxPaused = true)
    end if

    crt = BgFxChildById(host, "crtWash")
    if crt = invalid and want.crt
        crt = BuildCrtOverlay(host)
        host.removeChild(crt)
        host.insertChild(crt, 0)      ' scanlines stay UNDER the mesh
    end if
    if crt <> invalid then crt.visible = want.crt and (not playing)

    grid = BgFxChildById(host, "gridWash")
    if grid = invalid and want.grid then grid = BuildGridOverlay(host)
    if grid <> invalid then grid.visible = want.grid and (not playing)
end sub

' The member's choice as two booleans, for the page-level painters.
' Falls back to the two published booleans (and through them to the default,
' mesh on / scanlines off) if the scene has not published bgfxKey at all.
function BgFxPageWant() as object
    if m.global <> invalid and m.global.hasField("bgfxKey")
        return BgFxResolve(m.global.bgfxKey)
    end if
    return { grid: BgFxGridOn(), crt: BgFxCrtOn() }
end function

' A DIRECT child by id, walked by hand. >>> NOT findNode. <<< The scene-level
' wash uses the SAME two ids ("crtWash", "gridWash") on nodes that are not in
' this container, and findNode's search root is the sort of thing that is easy
' to be wrong about and invisible when you are — it would toggle the scene's
' copy while the member stares at an unchanged screen, which is this bug over
' again. Walking getChild() cannot reach outside the container.
function BgFxChildById(host as object, wantId as string) as object
    if host = invalid then return invalid
    total = host.getChildCount()
    if total <= 0 then return invalid
    for i = 0 to total - 1
        kid = host.getChild(i)
        if kid <> invalid and kid.id = wantId then return kid
    end for
    return invalid
end function

' >>> HOW A SETTINGS CHANGE REACHES THE SCREEN THE MEMBER IS LOOKING AT. <<<
' AppScene.onBgFxChanged calls this with the scene. Every overlay screen that
' calls AddPageGrid is created with getScene().createChild(...), so all of them
' are DIRECT children of the scene — this walks that one level and repaints any
' "bgFxWash" container it finds.
'
' WHY IT IS DONE FROM THE SCENE RATHER THAN BY EACH SCREEN OBSERVING FOR
' ITSELF: eleven screens call AddPageGrid and this lane may not edit them, and
' a per-screen observer on m.global outlives the screen that registered it
' unless it is unobserved on the way out — which would need a line in each of
' those eleven files. The scene already has an observer, it already runs on the
' same render thread as every screen it created, and it can see all of them.
'
' COST: one pass over the scene's own children (a handful — the shell, the
' player, whatever overlay is up) and their direct children. No searching, no
' recursion, no registry, no network.
sub RepaintPageGrids(scene as object)
    if scene = invalid then return
    total = scene.getChildCount()
    if total <= 0 then return
    for i = 0 to total - 1
        kid = scene.getChild(i)
        if kid <> invalid
            host = BgFxChildById(kid, "bgFxWash")
            if host <> invalid then SyncBackgroundEffects(host)
        end if
    end for
end sub

' ---- The grid-paper wash ----------------------------------------------------
' Android's GridOverlay (packages/kwicktv_design/lib/src/effects/grid_overlay
' .dart:67-85), the faint graph-paper mesh every terminal skin lays over the
' page. The owner asked for it by name after seeing the reskin on the TV.
'
' AN EARLIER NOTE IN THIS FILE SAID THIS COULD NOT BE PORTED. That was wrong,
' and the mistake is worth recording so nobody repeats it: it was costed as a
' FULL-SCREEN TEXTURE (1920 x 1080 x 4 = 7.9 MB against a ~90 MB budget with
' five out-of-memory reports behind it), which would indeed have been
' indefensible. But a mesh is not a picture. A Roku Rectangle is a solid fill
' with no bitmap behind it, so it costs NOTHING against the image budget —
' which is exactly why Android draws this as stroked lines rather than as an
' asset. 45 Rectangles, built once, never touched again.
'
' THE CELL SIZE, DERIVED RATHER THAN COPIED. Android's cell is 32 LOGICAL
' pixels, which is not 32 pixels on this screen. The conversion this app has
' already agreed on is the one the owner ruled on for the card corner
' (tools/make_card_art.py): Nord Shell's media card is about 110dp wide and
' this app's poster is 232px, so the Android->Roku factor is
'
'     232 / 110 = 2.11    and    32 x 2.11 = 67.5
'
' Rounded to 64, which is within 5% of that and divides 1920 exactly, so the
' mesh meets the right-hand edge on a line instead of on a ragged part-cell.
' Copying 32 verbatim would have drawn a mesh twice as dense as the phone's.
'
' LINES START ONE CELL IN, never at 0, exactly as Android's loops do — a line
' hard against the screen edge reads as a border, which this is not.
'
' Colour is the palette's own `gridLine`, frost at alpha 13/255 (~5%), which
' is Android's gridLineColor for Nord Shell unchanged.
'
' WHERE IT GOES: directly over the page background and UNDER everything else.
' It is a wash on the paper, not a film over the cards.
function BuildGridOverlay(parent as object) as object
    th = KwickTheme()
    grid = parent.createChild("Group")
    grid.id = "gridWash"
    cell = 64
    w = th.screenW
    h = th.screenH

    x = cell
    while x < w
        v = grid.createChild("Rectangle")
        v.width = 1
        v.height = h
        v.color = th.gridLine
        v.translation = [x, 0]
        x = x + cell
    end while

    y = cell
    while y < h
        r = grid.createChild("Rectangle")
        r.width = w
        r.height = 1
        r.color = th.gridLine
        r.translation = [0, y]
        y = y + cell
    end while
    ' 29 vertical + 16 horizontal = 45 nodes, and that is the whole cost.
    return grid
end function

' ---- The grid on a screen that paints its OWN page background ---------------
' >>> WHY THIS EXISTS, AND IT IS NOT WHAT IT LOOKS LIKE. <<<
'
' AppScene draws the wash once, between its page background and everything
' else, and on Home / VOD / Live TV / Search that is the whole story: those
' screens live inside AppShell's content group and paint no backdrop of their
' own, so the mesh shows through them. Verified on the television.
'
' NINE OTHER SCREENS DO PAINT A FULL-SCREEN BACKDROP, and they cover it. The
' obvious reading is that those backdrops are redundant duplicates of
' AppScene's own and should simply be deleted. THAT READING IS WRONG and
' deleting them would break all nine: every one of these screens is created
' with `getScene().createChild(...)`, i.e. as an overlay ON TOP of the still
' present AppShell. Their backdrop is what hides the sidebar and the screen
' the member came from. Take it away and a film page is drawn over Home.
'
' So a second page background genuinely exists, and the wash has to be drawn
' on it too. That is this. One line in each such screen's init():
'
'     AddPageGrid(m.top)
'
' WHERE IT GOES: index 1, immediately above the screen's own backdrop and
' below everything else it draws. That is the same relationship the scene-level
' wash has to the scene's background, which is the point — the mesh stays a
' wash on the paper and never a film over the cards.
'
' THE INDEX ASSUMPTION, stated plainly: this puts the grid at child 1, so it
' assumes the screen's backdrop is child 0. It is, in all nine — every one of
' them declares its full-screen Rectangle as the first child in its XML. A
' screen that does otherwise would draw the mesh over whatever it declared
' first, which is visible immediately and not subtle.
'
' NOT FOR A SCRIM SCREEN. AddToListScreen, EventChannelsScreen and
' ProfileEditorScreen open with a semi-transparent black rectangle rather than
' a page colour, on purpose — they are modal panels and the dimmed screen
' behind them shows through, mesh included. Adding a grid to those would draw
' a second mesh on top of the first.
'
' COST: 45 Rectangles for the mesh, 135 for the scanlines, no texture memory,
' built once. These screens are modal and only one is up at a time.
'
' >>> THIS PATH BUILDS ONLY WHAT IS SWITCHED ON, AND THE SCENE-LEVEL ONE DOES
' NOT. That difference is deliberate. <<< A screen here is created in answer
' to a remote press, and certification 3.5 gives the UI 250 ms to respond, so
' the work has to be the minimum: an empty container on "None", 45 nodes on
' the default, 180 only for a member who asked for both. AppScene builds both
' unconditionally at LAUNCH — where there is no 250 ms clock, only cert 3.6's
' eight seconds to first frame — and toggles `visible`, because the setting
' can change while it is up and rebuilding 180 nodes inside a Settings press
' is exactly the work this path is avoiding.
'
' THE EMPTY CONTAINER IS PLACED EVEN ON "None", and that is the 2026-08-27 fix
' rather than an oversight. Changing the effect while standing in Settings used
' to repaint only the scene BEHIND the Settings overlay: the copy in front of
' the member was built to whatever was on when that screen opened and was never
' touched again, so the new choice appeared only after backing out. AppScene's
' handler now calls RepaintPageGrids(m.top), which needs a container to find —
' one Group node, always placed, so "None" is changeable too.
'
' THE NAME STAYS AddPageGrid even though it now places the scanlines too.
' Eleven screens call it; three of them are open in other people's hands this
' week. Renaming it would be a rename across files this lane must not touch.
'
' THE PAUSE GATE. These did not used to be wired to m.global.fxPaused and did
' not need to be: the player is itself a scene-level child created after these
' screens, so it covers them completely while anything is playing. They ARE
' wired now, only because the repaint that fixes the Settings bug runs through
' the same handler that carries the pause — SyncBackgroundEffects applies it
' the same way AppScene does, and clears it on every path out of the player.
' Under a player that covers them this is invisible either way.
sub AddPageGrid(screen as object)
    if screen = invalid then return
    if screen.getChildCount() = 0 then return
    fx = BuildBackgroundEffects(screen)   ' appended last, i.e. on top
    screen.removeChild(fx)
    screen.insertChild(fx, 1)             ' just above the screen's own backdrop
end sub

' ---- Shell prompt titles ----------------------------------------------------
' A port of Android's TerminalPromptTitle (lib/ui/widgets/terminal_prompt.dart
' :25-53). On a terminal skin a row or page heading is not "Favorites", it is
'
'     ❯ ~/favorites ls -la
'
' drawn as TWO Labels: the arrow and the path in the theme accent, the command
' in textSecondary. Returns { arrow, path, cmd } so the caller can colour them
' separately; the arrow is kept out of the path string so a caller that wants
' the path alone can have it.
'
' The map is Android's, title for title, so the same row reads the same on a
' phone and on the television. Two Roku-only headings are added at the end
' because Home over here has rows Android's map never saw — without them they
' would fall through to the generic "~/lists/<slug> cat", which is what an
' unrecognised member-named list correctly gets.
'
' NOT a glyph puzzle: the path is words, spelled out. The member does not have
' to decode anything to know that "~/favorites/channels" is their favourite
' channels.
function ShellPrompt(title as string) as object
    known = {
        "Home": ["~/home", "./init.sh"]
        "Live TV": ["~/live-tv", "ls"]
        "TV Guide": ["~/tv-guide", "cat epg.xml"]
        "VOD": ["~/vod", "ls -la"]
        "Recordings": ["~/recordings", "ls -la"]
        "Settings": ["~/settings", "./configure"]
        "Recently Watched": ["~/recent", "ls -la"]
        "Recently Watched Channels": ["~/recent/channels", "ls"]
        "Recently Watched VOD": ["~/recent/vod", "ls"]
        "Kwick Picks": ["~/kwick-picks", "./suggest.sh"]
        "Favorites": ["~/favorites", "ls -la"]
        "Favorite Channels": ["~/favorites/channels", "ls"]
        "Favorite Movies": ["~/favorites/movies", "ls"]
        "Favorite Series": ["~/favorites/series", "ls"]
        ' Roku-only Home rows. Android has no row by either name, so these
        ' are this app's own additions rather than a port.
        "Continue Watching": ["~/continue", "ls"]
        "Favorite Movies & Series": ["~/favorites/vod", "ls"]
        ' The add-ons' own rows. WITHOUT THESE TWO LINES they fall through to
        ' the catch-all below and read "~/lists/your-trakt-watchlist cat",
        ' which is the shape a member's OWN named list gets — so the one row
        ' they did not make would look like one they did. The path says whose
        ' list it is, which is the whole point of the row.
        "Your Trakt watchlist": ["~/trakt/watchlist", "ls"]
        "Your Simkl watchlist": ["~/simkl/watchlist", "ls"]
    }
    hit = known[title]
    if hit <> invalid
        return { arrow: "❯ ", path: hit[0], cmd: " " + hit[1] }
    end if
    return { arrow: "❯ ", path: "~/lists/" + ShellSlug(title), cmd: " cat" }
end function

' "Favorite Movies & Series" -> "favorite-movies-series". Android's
' TerminalPromptTitle.slugOf, which is a regex; this is the same rule written
' out longhand because BrightScript's roRegex would mean creating an object
' per call and this can run once per row while a page builds.
function ShellSlug(s as string) as string
    out = ""
    dash = false
    low = LCase(s)
    for i = 0 to low.len() - 1
        ch = low.mid(i, 1)
        code = Asc(ch)
        ok = (code >= 97 and code <= 122) or (code >= 48 and code <= 57)
        if ok
            out = out + ch
            dash = false
        else
            ' Collapse any run of punctuation or spaces into ONE dash, and
            ' never start with one.
            if out <> "" and not dash
                out = out + "-"
                dash = true
            end if
        end if
    end for
    ' Trailing dash, from a title that ends in punctuation.
    if out <> "" and out.right(1) = "-" then out = out.left(out.len() - 1)
    if out = "" then out = "list"
    return out
end function
