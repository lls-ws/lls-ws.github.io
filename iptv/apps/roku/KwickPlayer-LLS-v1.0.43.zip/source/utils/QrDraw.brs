' Painting a QR grid onto a Group — the one copy, shared by every screen
' that puts a pairing square on the TV.
'
' Nothing here encodes anything. The rows come from QrEncode() (QrCode.brs),
' which runs on the task thread inside SourceLinkTask; this only draws what
' came back.
'
' One rectangle per unbroken run of dark modules, not one per module: the
' grid is 841 modules but only a couple of hundred runs, and every one of
' them is a node the scene has to carry and draw.
'
' Answers false when there was nothing to paint, so the caller can hide the
' white plate and its caption instead of leaving an empty square on screen.
function DrawQrModules(grid as object, rows as object, modulePx as integer) as boolean
    if grid = invalid then return false
    while grid.getChildCount() > 0
        grid.removeChildIndex(0)
    end while
    if rows = invalid or rows.count() = 0 then return false
    for r = 0 to rows.count() - 1
        oneRow = ToStr(rows[r])
        c = 0
        while c < oneRow.len()
            if oneRow.mid(c, 1) = "1"
                runTo = c
                while runTo + 1 < oneRow.len() and oneRow.mid(runTo + 1, 1) = "1"
                    runTo = runTo + 1
                end while
                block = grid.createChild("Rectangle")
                block.color = "0x000000FF"
                block.width = (runTo - c + 1) * modulePx
                block.height = modulePx
                block.translation = [c * modulePx, r * modulePx]
                c = runTo + 1
            else
                c = c + 1
            end if
        end while
    end for
    return true
end function
