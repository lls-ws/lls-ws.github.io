' ---- Add-ons: the member's own accounts on other services ---------------------
'
' OpenSubtitles, Subdl, Trakt and Simkl. Everything here is a URL builder and a
' shape reader; the requests themselves go through AddOnTask, and what comes
' back is stored by Store.brs. Nothing in this file talks to a service
' directly and nothing in it holds a secret.
'
' ONE RELAY PER SERVICE, ON OUR OWN SERVER, and the app never sees an API key.
' kwickplayer.tv/kwicksync/subs.php, trakt.php and simkl.php hold the keys that
' identify KWICK PLAYER; the token that identifies the MEMBER is theirs and
' lives in this box's registry. Contracts:
'   [[Site - OpenSubtitles Relay (subs.php)]]
'   [[Site - Subdl In The Subtitle Relay (subs.php)]]
'   [[Site - Trakt Relay (trakt.php)]]
'   [[Site - Simkl Relay (simkl.php)]]
'
' MASON'S RULE, and it is the reason this file has no "sign in with our
' account" anywhere: members use THEIR OWN logins on every add-on. No shared
' Kwick account behind any of them.
'
' HOW A MEMBER SIGNS IN, PER SERVICE — this is what the service allows, not
' what we chose:
'   OpenSubtitles  username + password, which its API actually accepts. The
'                  ONLY one that does. Roku has an on-screen keyboard (the
'                  KwickTV sign-in uses it), so this happens on the box.
'   Trakt / Simkl  OAuth only: the service shows a short code, the member
'                  types it on the service's own page and signs in THERE.
'                  Nothing is ever typed into this app for those two, which
'                  is also why they are fine under Roku's rules: the box
'                  shows a code and a QR square, never a password box for
'                  somebody else's service.
'   Subdl          no member login exists at all. Mason, 2026-09-16: "do not
'                  make people sign in with an api key", and then "if people
'                  aren't logging into their own subdl account, it should be
'                  baked in and not actually listed in Add-ons". So Subdl has
'                  no page, no switch and no row in Add-ons — only a search
'                  row in the player's subtitle menu.

function AddOnRelayBase() as string
    return "https://kwickplayer.tv/kwicksync/"
end function

' ---- OpenSubtitles -----------------------------------------------------------

function SubsUrl(action as string) as string
    return AddOnRelayBase() + "subs.php?a=" + action
end function

' The member's own sign-in. POST { username, password }; the answer carries
' their token, the base url their account uses (VIP members get a different
' one) and their quota.
function SubsLoginUrl() as string
    return SubsUrl("login")
end function

' A search for the title being played. THREE shapes, and the type is never
' left off: a TMDB id alone is ambiguous because films and episodes are
' numbered separately upstream, and a film's id once returned ten Dexter
' episodes. `source` is "" for OpenSubtitles and "subdl" for Subdl, which
' answers the same fifteen-field row shape.
function SubsSearchUrlMovie(tmdbId as string, langs as string, source = "" as string) as string
    u = SubsUrl("search") + "&tmdb_id=" + UrlEncode(tmdbId) + "&type=movie"
    return subsSearchTail(u, langs, source)
end function

function SubsSearchUrlEpisode(showTmdbId as string, season as integer, episode as integer, langs as string, source = "" as string) as string
    u = SubsUrl("search") + "&parent_tmdb_id=" + UrlEncode(showTmdbId)
    u = u + "&season=" + season.toStr() + "&episode=" + episode.toStr() + "&type=episode"
    return subsSearchTail(u, langs, source)
end function

function SubsSearchUrlQuery(title as string, year as string, langs as string, source = "" as string) as string
    u = SubsUrl("search") + "&query=" + UrlEncode(title)
    if year <> "" then u = u + "&year=" + UrlEncode(year)
    return subsSearchTail(u, langs, source)
end function

function subsSearchTail(u as string, langs as string, source as string) as string
    if langs <> "" then u = u + "&languages=" + UrlEncode(langs)
    if source <> "" then u = u + "&source=" + UrlEncode(source)
    return u
end function

' OpenSubtitles only. POST { file_id } with the member's bearer token; the
' answer is a short-lived link the box fetches itself, plus what is left of
' their daily allowance. Subdl answers 400 here on purpose — its files come
' straight off dl.subdl.com with no key, spending that member's own anonymous
' allowance rather than the app's shared one.
function SubsDownloadUrl() as string
    return SubsUrl("download")
end function

function SubsLogoutUrl() as string
    return SubsUrl("logout")
end function

' "Searches today: N of 2,000" on the Subdl half of the picker. The whole
' membership shares one free key for SEARCHES, so this number is everyone's,
' not this member's, and the relay stops at 1,950 to leave room.
function SubsQuotaUrl(source as string) as string
    return SubsUrl("quota") + "&source=" + UrlEncode(source)
end function

' ---- Trakt and Simkl ---------------------------------------------------------
'
' Both sign in the same way from a television's point of view: ask the relay
' for a code, show the code and a QR square of the page with the code already
' in it, then ask the relay every few seconds whether the member has finished.
' The QR is the whole reason this works on Roku: the member signs in on their
' own phone, on the service's own page.

function TraktUrl(action as string) as string
    return AddOnRelayBase() + "trakt.php?a=" + action
end function

function SimklUrl(action as string) as string
    return AddOnRelayBase() + "simkl.php?a=" + action
end function

' The page a member goes to, with their code already in it, which is what the
' QR square carries. Scanning it on a phone lands on the service's own sign-in
' with the code filled in, so they only type their own username and password
' there — never here.
'
' BOTH FIT THE ENCODER. QrCode.brs is version 3-M and holds 42 bytes; these
' come to about 30. TMDB's approve link is ~95 bytes and would NOT fit, which
' is why TMDB is not in this build — see JB-9.
function TraktActivateUrl(userCode as string) as string
    return "https://trakt.tv/activate/" + userCode
end function

function SimklPinUrl(userCode as string) as string
    return "https://simkl.com/pin/" + userCode
end function

' ---- What the app calls each one ---------------------------------------------

function AddOnLabel(id as string) as string
    if id = "opensubtitles" then return "OpenSubtitles"
    if id = "trakt" then return "Trakt"
    if id = "simkl" then return "Simkl"
    if id = "subdl" then return "Subdl"
    return id
end function

' The add-ons that get a row in Settings. Subdl is deliberately absent: it has
' no member login, so there is nothing for a member to do on a page.
function AddOnIds() as object
    return ["opensubtitles", "trakt", "simkl"]
end function

' ---- Reading what a relay answered -------------------------------------------
'
' Every relay answers { error: <code>, message: <plain words> } on a fault, and
' the message is already written for a member — show it rather than inventing
' one. These are the codes worth acting on differently.

function AddOnErrorText(code as string, message as string, service as string) as string
    msg = ToStr(message).trim()
    c = LCase(ToStr(code))
    if c = "auth"
        return "That sign-in was not accepted. Check the username and password and try again."
    else if c = "quota"
        return "You have used all of today's downloads on " + service + ". They come back when the count resets."
    else if c = "rate"
        return "Too many requests for the moment. Wait a little and try again."
    else if c = "upstream"
        return service + " is not answering right now. Try again in a few minutes."
    end if
    if msg <> "" then return msg
    return "Something went wrong talking to " + service + "."
end function

' A subtitle row, from either source, cut down to what a picker draws. The two
' sources answer the same fifteen fields; `source` says which one it came from
' and `url` is set on Subdl rows only (its files are fetched straight from
' dl.subdl.com, with no key and no relay).
function SubsMapRow(it as dynamic) as object
    if it = invalid then return invalid
    row = {}
    row["fileId"] = ToStr(GetField(it, "file_id"))
    row["language"] = ToStr(GetField(it, "language"))
    row["release"] = ToStr(GetField(it, "release"))
    row["downloads"] = ToInt(GetField(it, "downloads"))
    row["hearing"] = (GetField(it, "hearing_impaired") = true)
    row["trusted"] = (GetField(it, "from_trusted") = true)
    row["machine"] = (GetField(it, "machine_translated") = true)
    row["featureTitle"] = ToStr(GetField(it, "feature_title"))
    row["featureYear"] = ToStr(GetField(it, "feature_year"))
    row["source"] = ToStr(GetField(it, "source"))
    if row.source = "" then row.source = "opensubtitles"
    row["url"] = ToStr(GetField(it, "url"))
    if row.fileId = "" and row.url = "" then return invalid
    return row
end function

' What the member reads on a row: the language, then the release name, then
' the badges that actually change whether a subtitle is worth picking.
function SubsRowLabel(row as dynamic) as string
    lang = UCase(ToStr(GetField(row, "language")))
    rel = ToStr(GetField(row, "release")).trim()
    if rel = "" then rel = "(no release name)"
    out = lang + "  " + rel
    tags = []
    if GetField(row, "hearing") = true then tags.push("hearing impaired")
    if GetField(row, "trusted") = true then tags.push("trusted")
    if GetField(row, "machine") = true then tags.push("machine translated")
    n = ToInt(GetField(row, "downloads"))
    if n > 0 then tags.push(n.toStr() + " downloads")
    if tags.count() > 0
        out = out + "  ("
        for i = 0 to tags.count() - 1
            if i > 0 then out = out + ", "
            out = out + tags[i]
        end for
        out = out + ")"
    end if
    return out
end function
